package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.evaluation.ComparisonAssetListResponseDto;
import com.cms.assetmanagement.model.evaluation.ComparisonDetailResponseDto;
import com.cms.assetmanagement.model.evaluation.CountDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import org.springframework.stereotype.Service;

@Service
public interface EvaluationService {

    ComparisonAssetListResponseDto getProgramList(FilterRequestDto filterRequestDto);

    ComparisonDetailResponseDto getDetail(String contentId, String cpId);

    CountDto getCount(FilterRequestDto filterRequestDto);
}