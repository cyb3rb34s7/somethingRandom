package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Content {
    private Integer id;
    private String contentId;
    private String countryCode;
    private String programType;
    private String mainTitle;
    private String shortTitle;
    private String genres;
    private String director;
    private String starring;
    private String description;
    private Integer episodeNo;
    private Integer seasonNo;
    private String releaseDate;
    private String windowStartDate;
    private String windowEndDate;
    private String imgLandscapeOriginal;
    private String imgPortraitOriginal;
    private String imgLandscapeIconic;
    private String imgPortraitIconic;
    private String imgLandscapeWH;
    private String imgPortraitWH;
    private String imgLandscapeIconicWH;
    private String imgPortraitIconicWH;
}
