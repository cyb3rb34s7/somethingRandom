package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VodAssetImageMapper {


    void deleteImagesByContentId(List<AssetKeyDto> assetList);

    void insertImagesByContentId(List<AssetImageDto> imageList);

    List<AssetImageDto> getAllImageByContentId(AssetKeyDto assetKeyDto);
}