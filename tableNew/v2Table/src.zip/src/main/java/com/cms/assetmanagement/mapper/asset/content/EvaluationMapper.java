package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.evaluation.ComparisonDto;
import com.cms.assetmanagement.model.evaluation.CountDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import com.cms.assetmanagement.model.evaluation.StatusDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EvaluationMapper {
    List<ComparisonDto> findAllWithUmd(@Param(Constants.FILTER_BDDY) FilterRequestDto filterRequestDto);
    CountDto findCount(@Param(Constants.FILTER_BDDY) FilterRequestDto filterRequestDto);
    StatusDto findStatus(@Param(Constants.CONTENT_ID) String contentId);
}
