package com.cms.assetmanagement.service;

import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.ValidateWindowDto;
import java.util.List;

public interface VodAssetValidationService {

    List<String> validateExternalId(List<AssetExternalIdDto> externalIdDtoList);

    boolean validateDeltaSync(String contentId, String countryCode, String vcCpId,
        String eventType);

    boolean validateAssetDetails(EditValidationDto editValidation);

    boolean validateBulkQCPass(List<AssetKeyDto> assetList);

    <T extends DateRangeWindow> ValidateWindowDto validateDateRangeWindow(
        List<T> newList, String programId, String cpId, String countryCode, boolean shouldMerge);
}