package com.cms.assetmanagement.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class LoggingDto {

    private String startTime;
    private String endTime;
    private String transactionId;
    private Integer executionTime;
    private String url;
    private Object headers;
    private String payload;
    private String responseCode;
    private String params;
    private String method;
}
