package com.cms.assetmanagement.common.util;

//! ErrorCode Class
public class ErrorCode {

    public static final String CMS_SERVICE_CODE = "241";
    /* 400 Error */
    public static final String MISSING_REQUIRED_HEADER = CMS_SERVICE_CODE + "4001";
    public static final String UNSUPPORTED_HEADER = CMS_SERVICE_CODE + "4002";
    public static final String INVALID_HEADER_VALUE = CMS_SERVICE_CODE + "4003";
    public static final String MISSING_REQUIRED_QUERY_PARAM = CMS_SERVICE_CODE + "4004";
    public static final String UNSUPPORTED_QUERY_PARAM = CMS_SERVICE_CODE + "4005";
    public static final String INVALID_QUERY_PARAM_VALUE = CMS_SERVICE_CODE + "4006";
    public static final String INVALID_PATH_VARIABLE = CMS_SERVICE_CODE + "4007";
    public static final String MALFORMED_BODY_CONTENT = CMS_SERVICE_CODE + "4008";
    public static final String COUNTRY_NOT_ASSIGNED = CMS_SERVICE_CODE + "4009";
    public static final String INVALID_INPUT_DATA = CMS_SERVICE_CODE + "4010";
    /* 401 Error */
    public static final String INVALID_APPKEY = CMS_SERVICE_CODE + "4101";
    public static final String INVALID_TOKEN = CMS_SERVICE_CODE + "4102";
    public static final String INVALID_USERTOKEN = CMS_SERVICE_CODE + "4105";
    public static final String USERTOKEN_EXPIRED = CMS_SERVICE_CODE + "4106";
    /* 403 ERROR */
    public static final String PERMISSION_DENIED = CMS_SERVICE_CODE + "4151";
    public static final String ACCESS_DENIED = CMS_SERVICE_CODE + "4152";
    public static final String HTTPS_ONLY = CMS_SERVICE_CODE + "4153";
    public static final String DUID_OR_IP_DENIED = CMS_SERVICE_CODE + "4154";
    /* 404 ERROR */
    public static final String REQUIRED_URI_NOT_EXISTS = CMS_SERVICE_CODE + "4163";
    public static final String DATA_NOT_FOUND = CMS_SERVICE_CODE + "4202";
    public static final String DATA_NOT_EDITABLE = CMS_SERVICE_CODE + "4203";
    public static final String DATA_NOT_UNIQUE = CMS_SERVICE_CODE + "4204";
    public static final String DATA_IS_CYCLIC = CMS_SERVICE_CODE + "4205";
    public static final String DATA_INTEGRITY_VIOLATION = CMS_SERVICE_CODE + "4206";
    /* 405 ERROR */
    public static final String UNSUPPORTED_HTTP_METHOD = CMS_SERVICE_CODE + "4221";
    public static final String UNSUPPORTED_ACTION = CMS_SERVICE_CODE + "4222";
    public static final String MODIFYING_ROLE_OF_SELF = CMS_SERVICE_CODE + "4223";
    /* 406 ERROR */
    public static final String NOT_ACCEPTABLE = CMS_SERVICE_CODE + "4241";
    /* 408 ERROR */
    public static final String REQUEST_TIMEOUT = CMS_SERVICE_CODE + "4261";
    /* 409 ERROR */
    public static final String DATA_ALREADY_EXISTS = CMS_SERVICE_CODE + "4281";
    /* 411 ERROR */
    public static final String NO_CONTENT_LENGTH = CMS_SERVICE_CODE + "4301";
    /* 413 ERROR */
    public static final String REQUEST_TOO_LARGE = CMS_SERVICE_CODE + "4321";
    /* 415 ERROR */
    public static final String INVALID_CHARACTER_SET = CMS_SERVICE_CODE + "4342";
    /* 500 ERROR */
    public static final String INTERNAL_SERVER_ERROR = CMS_SERVICE_CODE + "5001";
    public static final String IMS_ERROR = CMS_SERVICE_CODE + "5002";
    /* 501 ERROR */
    public static final String NOT_IMPLEMENTED = CMS_SERVICE_CODE + "5101";
    /* 503 ERROR */
    public static final String SERVICE_UNAVAILABLE = CMS_SERVICE_CODE + "5163";
    /* 504 ERROR */
    public static final String TIMEOUT_EXCEPTION = CMS_SERVICE_CODE + "5301";

    private ErrorCode() {
        throw new IllegalStateException("Utility class");
    }
}
