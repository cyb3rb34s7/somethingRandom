package com.cms.assetmanagement.common.util;

public class ErrorMsg {

    /* 400 Error */
    public static final String MISSING_REQUIRED_HEADER = "Missing Required Header";
    public static final String UNSUPPORTED_HEADER = "Unsupported Header";
    public static final String INVALID_HEADER_VALUE = "Invalid Header Value";
    public static final String MISSING_REQUIRED_QUERY_PARAM = "Missing Required Query Parameter";
    public static final String UNSUPPORTED_QUERY_PARAM = "Unsupported Query Parameter";
    public static final String INVALID_QUERY_PARAM_VALUE = "Invalid Query Parameter Value";
    public static final String INVALID_PATH_VARIABLE = "Invalid Path Variable";
    public static final String MALFORMED_BODY_CONTENT = "Malformed Body Content";
    public static final String COUNTRY_NOT_ASSIGNED = "Country Not Assigned To The User";
    public static final String INVALID_INPUT_DATA = "Invalid Input Data";
    /* 401 Error */
    public static final String INVALID_APPKEY = "Invalid userId";
    public static final String INVALID_TOKEN = "Invalid Token";
    public static final String INVALID_USERTOKEN = "Invalid UserToken";
    public static final String USERTOKEN_EXPIRED = "UserToken Expired";
    /* 403 ERROR */
    public static final String PERMISSION_DENIED = "Permission Denied";
    public static final String ACCESS_DENIED = "Access Denied";
    public static final String HTTPS_ONLY = "HTTPS Only";
    public static final String DUID_OR_IP_DENIED = "DUID or IP Denied";
    /* 404 ERROR */
    public static final String REQUIRED_URI_NOT_EXISTS = "Requested URI Not Exists";
    public static final String DATA_NOT_FOUND = "Data Not Found";
    public static final String DATA_NOT_EDITABLE = "Data Not Editable";
    public static final String DATA_NOT_UNIQUE = "Text is not unique";
    public static final String DATA_IS_CYCLIC = "GOG has cycle in it";
    public static final String DATA_INTEGRITY_VIOLATION = "Data Integrity Violation Occurred (Database constraint violated)";
    public static final String INTEGRITY_VIOLATION = "Cannot be deleted. Key is utilized as FK in other table";
    /* 405 ERROR */
    public static final String UNSUPPORTED_HTTP_METHOD = "Unsupported HTTP Method";
    public static final String MODIFYING_ROLE_OF_SELF = "Modifying Role of Self";
    /* 406 ERROR */
    public static final String NOT_ACCEPTABLE = "Not Acceptable";
    /* 408 ERROR */
    public static final String REQUEST_TIMEOUT = "Request Timeout";
    /* 409 ERROR */
    public static final String DATA_ALREADY_EXISTS = "Data Already Exists";
    /* 411 ERROR */
    public static final String NO_CONTENT_LENGTH = "No Content Length";
    /* 413 ERROR */
    public static final String REQUEST_TOO_LARGE = "Request Too Large";
    /* 415 ERROR */
    public static final String INVALID_CHARACTER_SET = "Invalid Character Set";
    /* 500 ERROR */
    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String INTERNAL_SERVER_ERROR_BASE_MESSAGE = ": Exception Occurred in API";
    public static final String IMS_ERROR = "Internal Server Error in IMS System";
    /* 501 ERROR */
    public static final String NOT_IMPLEMENTED = "Not Implemented";
    /* 503 ERROR */
    public static final String SERVICE_UNAVAILABLE = "Service Unavailable";
    /* 504 ERROR */
    public static final String TIMEOUT_EXCEPTION = "Timeout Exception";
    public static final String UNSUPPORTED_ACTION = "Unsupported Action";

    private ErrorMsg() {
        throw new IllegalStateException("Utility class");
    }
}
