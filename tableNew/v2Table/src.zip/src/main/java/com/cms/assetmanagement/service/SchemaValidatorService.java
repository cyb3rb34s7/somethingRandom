package com.cms.assetmanagement.service;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ErrorConstants;
import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.exception.JsonSchemaValidationException;
import com.cms.assetmanagement.mapper.asset.content.JsonValidatorMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.filter.ContentKeyDto;
import com.cms.assetmanagement.model.filter.ContentProviderDto;
import com.cms.assetmanagement.model.filter.ParentalRatingsDto;
import com.cms.assetmanagement.model.media.MediaAssetDto;
import com.cms.assetmanagement.model.smf.AssetDto;
import com.cms.assetmanagement.model.smf.AssetParentalRatingDto;
import com.cms.assetmanagement.model.smf.AssetTitleDto;
import com.cms.assetmanagement.model.util.ErrorDto;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class SchemaValidatorService {

    private final JsonValidatorMapper jsonValidatorMapper;
    private final DateRangeWindowService dateRangeWindowService;
    private final VodAssetMapper vodAssetMapper;

    ObjectMapper objMapper = new ObjectMapper();

    @Value("${FEED_WORKERS:cms}")
    private String feedWorkers;

    @Value("${PARENTAL_RATINGS_CHECK_FLAG}")
    private String parentalRatingsCheckFlag;

    @Value("${TITLE_BYTE_LENGTH}")
    private int titleByteLength;


    @Autowired
    public SchemaValidatorService(JsonValidatorMapper jsonValidatorMapper,
        DateRangeWindowService dateRangeWindowService, VodAssetMapper vodAssetMapper) {
        this.jsonValidatorMapper = jsonValidatorMapper;
        this.dateRangeWindowService = dateRangeWindowService;
        this.vodAssetMapper = vodAssetMapper;
    }

    public Map<String, Object> validateAsset(JsonNode jsonNode, String countryCode,
        String providerId) throws SQLException {
        ArrayList<ErrorDto> errorList = new ArrayList<>();
        AssetDto assetObject;
        try {
            assetObject = objMapper.convertValue(jsonNode, AssetDto.class);
        } catch (Exception err) {
            throw new JsonSchemaValidationException("Invalid Json provided");
        }

        boolean assetValidationCheck = processValidations(assetObject, countryCode, providerId,
            errorList);

        Map<String, Object> payload = new HashMap<>();
        payload.put("assetValidation", assetValidationCheck ? Constants.PASS : Constants.FAIL);
        if (!assetValidationCheck) {
            payload.put("error", errorList);
        }
        return payload;
    }

    public Map<String, Object> validateMedia(JsonNode jsonNode, String countryCode,
        String providerId, String programId) throws SQLException {
        ArrayList<ErrorDto> errorList = new ArrayList<>();
        try {
            objMapper.convertValue(jsonNode, MediaAssetDto.class);
        } catch (Exception err) {
            throw new JsonSchemaValidationException("Invalid Json provided");
        }

        boolean mediaValidationCheck = processMediaValidations(programId, countryCode, providerId,
            errorList);

        Map<String, Object> payload = new HashMap<>();
        payload.put("assetValidation", mediaValidationCheck ? Constants.PASS : Constants.FAIL);
        if (!mediaValidationCheck) {
            payload.put("error", errorList);
        }
        return payload;
    }

    public boolean processMediaValidations(String programId, String countryCode, String providerId,
        List<ErrorDto> errorList) throws SQLException {
        ContentProviderDto contentProviderDto = jsonValidatorMapper.getAssetDetailByContentId(
            programId, countryCode);

        boolean duplicateProviderCountryCheck = duplicateProviderIdAndCountryCheck(providerId,
            countryCode, errorList, false, contentProviderDto);

        if (!duplicateProviderCountryCheck) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PROGRAM_ID_ERROR)
                .message("Invalid Program Id - " + programId).build());
            // Program Id does not exist
            return false;
        }

        boolean assetStatusCheck = assetStatusValidation(contentProviderDto, errorList, true);

        boolean providerCountryCheck = processProvider(programId, countryCode, providerId,
            errorList);

        boolean validationStatus = providerCountryCheck && assetStatusCheck;

        log.info("Media asset validation status: {} for programId {}", validationStatus, programId);
        return validationStatus;
    }

    public boolean processValidations(AssetDto asset, String countryCode, String providerId,
        List<ErrorDto> errorList) throws SQLException {

        ContentProviderDto contentProviderDto = jsonValidatorMapper.getAssetDetailByContentId(
            asset.getProgramId(), countryCode);

        // Check for if query params matches with DB data
        boolean duplicateProviderCountryCheck = duplicateProviderIdAndCountryCheck(providerId,
            countryCode, errorList, true, contentProviderDto);

        if (!duplicateProviderCountryCheck) {
            return false;
        }

        // Feed worker + SVC_YN check (VOD_CP table)
        boolean providerCountryCheck = processProvider(asset.getProgramId(), countryCode,
            providerId, errorList);

        if (!providerCountryCheck) {
            return false;
        }

        boolean playbackItemCheck = playbackItemsCheck(asset, countryCode, errorList);

        // Parent Hierarchy check
        boolean parentAssetCheck = parentAssetValidation(asset, countryCode, errorList);

        // Status should not be QC_PASS or TEMP_QC_PASS (Extra invalid state REVOKED for media)
        boolean assetStatusCheck = assetStatusValidation(contentProviderDto, errorList, false);

        // For provided (countryCd, Rating Type, Rating Organization) is the rating code valid or not
        // Valid rating codes are from STD_VC_PARENTAL_RATING table
        boolean parentalRatingsCheck = processParentalRatings(asset, errorList);

        // ContentID and Country are same but different vcCpID provided
        boolean duplicateIdFromDifferentCpCheck = processDuplicateIdFromDifferentCp(asset,
            countryCode, providerId, errorList);

        // At least one title should have type "main"
        // Title length check
        // Title lang code check (master list from STD_VC_CNTY_CD_LANG_MAP)
        boolean titleCheck = processTitlesCheck(asset, countryCode, errorList);

        boolean validationStatus =
            playbackItemCheck && parentalRatingsCheck && duplicateIdFromDifferentCpCheck
                && assetStatusCheck && parentAssetCheck && titleCheck;

        log.info("Asset validation status: {} for asset {}", validationStatus,
            asset.getProgramId());

        return validationStatus;
    }

    public boolean validateProviderAndCountry(String countryCode, String providerId)
        throws SQLException {
        var isValid = false;
        List<ContentProviderDto> validProviders = getContentProviderList();
        for (ContentProviderDto provider : validProviders) {
            if (provider.getVcCpId().equalsIgnoreCase(providerId) && provider.getCountryCd()
                .equalsIgnoreCase(countryCode)) {
                return true;
            }
        }
        return isValid;
    }

    public boolean duplicateProviderIdAndCountryCheck(String providerId, String countryCode,
        List<ErrorDto> errorList, boolean isAsset, ContentProviderDto contentProviderDto) {
        if (contentProviderDto == null) {
            return isAsset;
        }

        if (!providerId.equals(contentProviderDto.getVcCpId()) || !countryCode.equals(
            contentProviderDto.getCountryCd())) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PROVIDER_COUNTRY_ERROR)
                .message("The requested Program ID already exists on TVPlus with "
                    + "Provider ID " + contentProviderDto.getVcCpId() + " and "
                    + "Country Code " + contentProviderDto.getCountryCd())
                .build());
            return false;
        }

        return true;
    }

    public boolean processProvider(String programId, String countryCode, String providerId,
        List<ErrorDto> errorList) throws SQLException {
        boolean providerCheck = this.validateProviderAndCountry(countryCode, providerId);
        if (!providerCheck) {
            log.error("Media Validation Failure: Provider Check failed for Program Id: {} ",
                programId);
            errorList.add(ErrorDto.builder().type(ErrorConstants.PROVIDER_COUNTRY_COMBO_ERROR)
                .message(ErrorConstants.ERROR_PROVIDER_CHECK).build());
        }
        return providerCheck;
    }

    public List<ContentProviderDto> getContentProviderList() throws SQLException {
        return jsonValidatorMapper.getContentProviderList(List.of(feedWorkers.split(",")));
    }

    public boolean processParentalRatings(AssetDto asset, List<ErrorDto> errorList)
        throws SQLException {
        var parentalRatingsCheck = true;
        if (Constants.STRING_Y.equals(this.parentalRatingsCheckFlag)
            && asset.getParentalRatings() != null && !asset.getParentalRatings().isEmpty()) {
            parentalRatingsCheck = validateParentalRatings(asset.getParentalRatings(),
                asset.getType());

            if (!parentalRatingsCheck) {
                log.error(
                    "Asset DB Validation Failure: Parental Ratings Check failed for Program Id: {} ",
                    asset.getProgramId());
                errorList.add(ErrorDto.builder().type("parental_ratings_error")
                    .message(ErrorConstants.ERROR_PARENTAL_RATINGS_CHECK).build());
            } else {
                log.info("Asset DB Validation: Parental Ratings Check passed for Program Id: {} ",
                    asset.getProgramId());
            }
        }

        return parentalRatingsCheck;
    }

    public boolean validateParentalRatings(List<AssetParentalRatingDto> assetParentalRatingsList,
        String assetType) throws SQLException {

        List<ParentalRatingsDto> parentalRatingsList = jsonValidatorMapper.getParentalRatingsList();
        if (parentalRatingsList == null || parentalRatingsList.isEmpty()) {
            return false;
        }

        for (AssetParentalRatingDto assetParentalRatings : assetParentalRatingsList) {
            List<ParentalRatingsDto> filteredParentalRatingCodes = parentalRatingsList.stream()
                .filter(item -> assetParentalRatings.getCountryCode().equals(item.getCntyCd())
                    && assetType.toLowerCase().equals(item.getType())
                    && assetParentalRatings.getBody().equals(item.getOrganization())).toList();
            if (filteredParentalRatingCodes.isEmpty()) {
                return false;
            } else {
                ParentalRatingsDto parentalRatingAsset = filteredParentalRatingCodes.get(0);
                List<String> codelist = new ArrayList<>();
                if (parentalRatingAsset.getCode() != null) {
                    codelist = Arrays.stream(parentalRatingAsset.getCode().split(","))
                        .toList();
                }
                if (!codelist.contains(assetParentalRatings.getCode())) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean processDuplicateIdFromDifferentCp(AssetDto asset, String countryCode,
        String cpName, List<ErrorDto> errorList) {

        boolean duplicateIdFromDifferentCpCheck = validateDuplicateIdFromDifferentCp(
            asset.getProgramId(), countryCode, cpName);
        if (!duplicateIdFromDifferentCpCheck) {
            log.error(
                "Asset DB Validation Failure: Duplicate Program Id is present from other CP for Program Id: {} ",
                asset.getProgramId());
            errorList.add(ErrorDto.builder().type("duplicate_id_from_different_cp_error")
                .message(ErrorConstants.ERROR_DUPLICATE_ID_FROM_DIFFERENT_CP_CHECK).build());
        } else {
            log.info(
                "Asset DB Validation: There are no duplicate Program Ids from other CPs present in DB for Program Id: {} ",
                asset.getProgramId());
        }
        return duplicateIdFromDifferentCpCheck;
    }

    public boolean validateDuplicateIdFromDifferentCp(String programId, String countryCode,
        String cpId) {
        List<ContentKeyDto> contentIdsList = jsonValidatorMapper.getContentIdDetail(programId,
            countryCode);

        if (contentIdsList != null && !contentIdsList.isEmpty()) {
            for (ContentKeyDto content : contentIdsList) {
                if (!cpId.equals(content.getVcCpId())) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean processProgramIdCheck(String programId, List<ErrorDto> errorList) {
        boolean isProgramIdValid = validateProgramId(programId);

        if (!isProgramIdValid) {
            log.error("Asset DB Validation Failure: No Program Id {} present in DB", programId);
            errorList.add(
                ErrorDto.builder().type(ErrorConstants.PROGRAM_ID_ERROR)
                    .message(ErrorConstants.PROGRAM_ID_NOT_PRESENT_IN_DB).build());
        }

        return isProgramIdValid;
    }

    public boolean validateProgramId(String programId) {
        Integer assetCount = jsonValidatorMapper.countAssetByContentId(programId);
        return assetCount != null && assetCount > 0;
    }

    public boolean assetStatusValidation(ContentProviderDto contentProviderDto,
        List<ErrorDto> errorList, boolean isMedia) {
        if (contentProviderDto == null) {
            return true;
        }

        List<String> invalidStatus = isMedia ? Constants.INVALID_MEDIA_VALIDATION_STATUS
            : Constants.INVALID_ASSET_VALIDATION_STATUS;

        String assetStatus = contentProviderDto.getStatus();
        if (assetStatus != null && invalidStatus.contains(assetStatus)) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.STATUS_ERROR)
                .message("Asset cannot be updated as asset is in '" + assetStatus
                    + "' state for ProgramId - " + contentProviderDto.getContentId()).build());
            return false;
        }
        return true;
    }

    public boolean parentAssetValidation(AssetDto asset, String countryCode,
        List<ErrorDto> errorList) {
        // Checks for season
        if (asset.getType().equalsIgnoreCase(Constants.SEASON)) {
            if (asset.getSeriesInfo() == null) {
                errorList.add(ErrorDto.builder().type(ErrorConstants.INSUFFICIENT_INFO_ERROR)
                    .message("Series Info not provided").build());
                return false;
            }

            // Parent content should be there in DB
            // Parent asset's type should match
            ContentProviderDto contentProviderDto = parentShowValidation(
                asset.getSeriesInfo().getShowId(), countryCode, errorList);
            return contentProviderDto != null;
        }

        // Checks for episode
        else if (asset.getType().equalsIgnoreCase(Constants.EPISODE)) {
            if (asset.getSeriesInfo() == null) {
                errorList.add(ErrorDto.builder().type(ErrorConstants.INSUFFICIENT_INFO_ERROR)
                    .message("Series Info not provided").build());
                return false;
            }

            ContentProviderDto parentShow = parentShowValidation(asset.getSeriesInfo().getShowId(),
                countryCode, errorList);
            ContentProviderDto parentSeason = parentSeasonValidation(
                asset.getSeriesInfo().getSeasonId(), countryCode, errorList);

            if (parentShow == null || parentSeason == null) {
                return false;
            }

            if (!parentSeason.getShowId().equals(parentShow.getContentId())) {
                errorList.add(ErrorDto.builder().type(ErrorConstants.HIERARCHY_ERROR)
                    .message("Season Id to Show Id mapping not valid").build());
                return false;
            }

            if (!parentSeason.getSeasonNumber().equals(asset.getSeriesInfo().getSeasonNumber())) {
                errorList.add(ErrorDto.builder().type(ErrorConstants.HIERARCHY_ERROR)
                    .message("Parent season number does not match").build());
                return false;
            }

            return true;
        }

        return true;
    }

    public ContentProviderDto parentShowValidation(String showId, String countryCode,
        List<ErrorDto> errorList) {
        if (showId == null) {
            errorList.add(
                ErrorDto.builder().type(ErrorConstants.PARENT_SHOW_ERROR).message("Show ID is null")
                    .build());
            return null;
        }

        ContentProviderDto parentShow = jsonValidatorMapper.getAssetDetailByContentId(showId,
            countryCode);

        if (parentShow == null) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PARENT_SHOW_ERROR)
                .message("Parent Show does not exist").build());
            return null;
        } else if (!Constants.SHOW.equalsIgnoreCase(parentShow.getType())) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PARENT_SHOW_TYPE_ERROR)
                .message("Parent Show exists but is of not type SHOW").build());
            return null;
        }

        return parentShow;
    }

    public ContentProviderDto parentSeasonValidation(String seasonId, String countryCode,
        List<ErrorDto> errorList) {
        if (seasonId == null) {
            errorList.add(
                ErrorDto.builder().type(ErrorConstants.PARENT_SEASON_ERROR)
                    .message("Season ID is null").build());
            return null;
        }

        ContentProviderDto parentSeason = jsonValidatorMapper.getAssetDetailByContentId(seasonId,
            countryCode);

        if (parentSeason == null) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PARENT_SEASON_ERROR)
                .message("Parent Season does not exist").build());
            return null;
        } else if (!Constants.SEASON.equalsIgnoreCase(parentSeason.getType())) {
            errorList.add(ErrorDto.builder().type(ErrorConstants.PARENT_SEASON_TYPE_ERROR)
                .message("Parent Season exists but is of not type SEASON").build());
            return null;
        }

        return parentSeason;
    }

    public <T extends DateRangeWindow> boolean processValidWindowTest(List<T> windows,
        List<ErrorDto> errorList, String windowErrorType) {

        try {
            dateRangeWindowService.addTzToTimestamps(windows);
        } catch (Exception ex) {
            errorList.add(ErrorDto.builder().type(windowErrorType)
                .message("Invalid Date Error: " + ex.getMessage()).build());
            return false;
        }

        if (!dateRangeWindowService.areWindowsValid(windows)) {
            errorList.add(ErrorDto.builder().type(windowErrorType)
                .message(ErrorConstants.ERROR_INVALID_WINDOWS).build());
            return false;
        }

        dateRangeWindowService.sortWindows(windows);

        if (!dateRangeWindowService.areWindowsNonOverlapping(windows)) {
            errorList.add(ErrorDto.builder().type(windowErrorType)
                .message(ErrorConstants.ERROR_OVERLAPPING_WINDOWS).build());
            return false;
        }

        return true;
    }

    public boolean playbackItemsCheck(AssetDto asset, String countryCode,
        List<ErrorDto> errorList) {
        String assetType = asset.getType();

        // NO playback item check if SEASON
        // For SHOW, do playback items validation if Not NULL
        // For others, playback items are mandatory and validation should be done

        if (assetType.equalsIgnoreCase(Constants.SEASON)) {
            return true;
        }

        if (assetType.equalsIgnoreCase(Constants.SHOW) && asset.getPlaybackItems() == null) {
            return true;
        }

        if (!assetType.equalsIgnoreCase(Constants.SHOW) && asset.getPlaybackItems() == null) {
            errorList.add(
                ErrorDto.builder().type(ErrorConstants.PLAYBACK_ITEMS_ERROR).message(
                    "No Playback-items for type: " + assetType).build());
            return false;
        }

        // Do validation for list item where country matches (with query param country), ignore others
        // If no country matches, then validation fails

        for (var playbackItem : asset.getPlaybackItems()) {
            if (playbackItem.getCountryCode() != null
                && playbackItem.getCountryCode().equals(countryCode)) {

                // In playback items, license window and event windows are validated only
                boolean areLicenseWindowsValid = processValidWindowTest(
                    playbackItem.getLicenseWindows(), errorList,
                    ErrorConstants.LICENSE_WINDOW_ERROR);

                boolean areEventWindowsValid = processValidWindowTest(
                    playbackItem.getEventWindows(), errorList,
                    ErrorConstants.EVENT_WINDOW_ERROR);

                return areLicenseWindowsValid && areEventWindowsValid;
            }
        }

        errorList.add(
            ErrorDto.builder().type(ErrorConstants.PLAYBACK_ITEMS_ERROR).message(
                    "There are no playback items available for input country or playback items are available for different country.")
                .build());
        return false;
    }

    public boolean processTitlesCheck(AssetDto asset, String countryCode, List<ErrorDto> errorList)
        throws SQLException {
        boolean titleCheck = false;
        if (asset.getTitles() != null && !asset.getTitles().isEmpty()) {
            List<String> errorInTitle = checkTitle(asset.getTitles(), countryCode);

            if (errorInTitle.isEmpty()) {
                titleCheck = true;
            }
            if (!titleCheck) {
                log.error("Asset DB Validation Failure: Title Check failed for Program Id: {} ",
                    asset.getProgramId());
                String errorMessage =
                    "Asset DB Validation Failure: Title Check failed for Program Id: "
                        + asset.getProgramId() + ". " + String.join(". ", errorInTitle);
                errorList.add(
                    ErrorDto.builder().type(ErrorConstants.ERROR_TITLE_NOT_PRESENT).message(
                            errorMessage)
                        .build());
            } else {
                log.info("Asset DB Validation: Title Check passed for Program Id: {} ",
                    asset.getProgramId());
            }
        } else {
            log.error("Asset DB Validation Failure: Titles not present for Program Id: {} ",
                asset.getProgramId());
            errorList.add(ErrorDto.builder().type(ErrorConstants.ERROR_TITLE_NOT_PRESENT).message(
                    "Asset DB Validation Failure: Titles not present for Program Id: "
                        + asset.getProgramId())
                .build());
        }
        return titleCheck;
    }


    private List<String> checkTitle(List<AssetTitleDto> titles, String countryCode) {
        boolean isMainTitle = false;
        boolean isLangCodeMatch = false;
            /* It is assumed that instead of individual title object mapping, if any title object has main title, any
             title object has matching lang code, then it is validated as true */
        List<String> errorList = new ArrayList<>();
        for (AssetTitleDto title : titles) {
            if (getStringByteSize(title.getTitle()) > this.titleByteLength) {
                errorList.add(ErrorConstants.ERROR_TITLE_LENGTH_EXCEED_TITLE_BYTE_LENGTH
                    + (this.titleByteLength) + "bytes");
            }
            if (Constants.TITLE_TYPE_MAIN.equals(title.getType())) {
                isMainTitle = true;
            }
            List<String> filteredCountryLangMappingList = vodAssetMapper.getLangCodeByCountryCode(
                countryCode);
            if (!filteredCountryLangMappingList.isEmpty() && title.getLanguage()
                .equals(filteredCountryLangMappingList.get(0))) {
                isLangCodeMatch = true;
            }
        }

        if (!isMainTitle) {
            errorList.add(ErrorConstants.ERROR_NO_MAIN_TITLE_FOUND);
        }

        if (!isLangCodeMatch) {
            errorList.add(ErrorConstants.ERROR_LANGCODE_MATCH_FAIL);
        }

        return errorList;
    }

    public String validateExternalIdPerIdType(List<AssetExternalIdDto> assetExternalIdList) {
        if (assetExternalIdList == null || assetExternalIdList.isEmpty()) {
            return Constants.VALID;
        }

        return jsonValidatorMapper.getExternalIdDataByProviderAndTypeAndCountry(assetExternalIdList)
            .isEmpty()
            ? Constants.VALID
            : Constants.INVALID;
    }

    private int getStringByteSize(String field) {
        byte[] byteArray = field.getBytes(StandardCharsets.UTF_8);
        return byteArray.length;
    }

}
