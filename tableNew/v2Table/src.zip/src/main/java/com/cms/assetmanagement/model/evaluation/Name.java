package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Name {
    private String first;
    private String last;
}
