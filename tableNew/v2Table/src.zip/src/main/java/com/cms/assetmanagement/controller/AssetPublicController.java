package com.cms.assetmanagement.controller;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.config.LogExecutionTime;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.publicapi.QueryParamDto;
import com.cms.assetmanagement.service.VodAssetPublicService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/cms/v1")
@RestController
@Slf4j
@Validated
public class AssetPublicController {

    private final VodAssetPublicService vodAssetPublicService;

    @Autowired
    public AssetPublicController(VodAssetPublicService vodAssetPublicService) {
        this.vodAssetPublicService = vodAssetPublicService;
    }

    @LogExecutionTime
    @GetMapping("/tvplus/asset")
    public ResponseDto assets(@RequestParam(value = "country_code") String countryCode,
        @RequestParam(value = "provider_id") String providerId,
        @RequestParam(value = "media_status", required = false) String mediaStatus,
        @RequestParam(value = "program_id", required = false) String programId,
        @RequestParam(value = "program_type", required = false) String programType,
        @RequestParam(value = "sort", defaultValue = "-updateDate") String sortBy,
        @RequestParam(value = "offset", defaultValue = Constants.OFFSET_DEFAULT) int offset,
        @RequestParam(value = "limit", defaultValue = Constants.LIMIT_DEFAULT) int limit) {
        log.info("Request received for getting filtered assets for public /asset API. "
            + "providerId: {}, countryCode: {}", providerId, countryCode);

        QueryParamDto queryParamDto = QueryParamDto.builder()
            .countryCode(countryCode)
            .providerId(providerId)
            .programId(programId)
            .mediaStatus(mediaStatus)
            .programType(programType)
            .sortBy(sortBy)
            .limit(limit)
            .offset(offset).build();
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetPublicService.getAssets(queryParamDto));
    }

}
