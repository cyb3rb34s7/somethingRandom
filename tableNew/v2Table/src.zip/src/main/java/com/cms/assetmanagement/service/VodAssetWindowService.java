package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.EventDeleteDto;
import com.cms.assetmanagement.model.VodAssetDto;

public interface VodAssetWindowService {

    void updateEventWindows(VodAssetDto vodAssetDto);

    void updateLicenseWindows(VodAssetDto vodAssetDto);

    void removeEventWindows(EventDeleteDto eventDeleteDto);

}