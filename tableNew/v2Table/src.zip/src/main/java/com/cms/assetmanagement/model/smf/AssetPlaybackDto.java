package com.cms.assetmanagement.model.smf;

import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetPlaybackDto {

    @JsonProperty("deeplink_payload")
    private String deeplinkPayload;

    @JsonProperty("country_code")
    private String countryCode;

    @JsonProperty("stream_url")
    private String streamUrl;

    @JsonProperty("license")
    private String licenseType;

    @JsonProperty("price")
    private Double price;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("quality")
    private String quality;

    @JsonProperty("audio_languages")
    private List<String> audioLanguages;

    @JsonProperty("subtitle_languages")
    private List<String> subtitleLanguages;

    @JsonProperty("available_starting")
    private String availableStarting;

    @JsonProperty("available_ending")
    private String availableEnding;

    @JsonProperty("drm")
    private List<AssetDrmDto> drms;

    @JsonProperty("license_window")
    private List<LicenseWindowDto> licenseWindows;

    @JsonProperty("event_window")
    private List<EventWindowDto> eventWindows;
}
