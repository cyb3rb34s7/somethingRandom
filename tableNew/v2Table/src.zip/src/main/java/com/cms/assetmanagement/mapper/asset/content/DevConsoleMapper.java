package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.model.devconsole.TiDto;
import com.cms.assetmanagement.model.devconsole.TiFeedworkerUpdateDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

@Mapper
public interface DevConsoleMapper {

    List<TiDto> getTiData(@Param("feedWorker") String feedWorker, RowBounds rowBounds);

    void updateTiFeedworker(TiFeedworkerUpdateDto tiFeedworkerUpdateDto);

}
