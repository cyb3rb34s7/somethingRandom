package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AdBreaksDto {

    private String programId;
    private String countryCode;
    private String providerId;
    private String markIn;
    private String markOut;
    private String duration;
    private Integer order;
    private String insertAdMarkers;
    private Double adBreakDurationSeconds;
    private Date regDate;
    private Date updateDate;
    private String regrId;
    private String crctrId;
    private String feedWorker;
}
