package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ShowHierarchyDto {

    private String contentId;
    private String mainTitle;
    private String status;
    private Integer seasonNo;
    private Integer episodeNo;
}

