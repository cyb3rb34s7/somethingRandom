package com.cms.assetmanagement.model.filter;

import com.cms.assetmanagement.common.Constants;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SortDto {

    @JsonProperty(defaultValue = Constants.DEFAULT_FILTER_FIELD)
    private String field;
    @JsonProperty(defaultValue = Constants.DEFAULT_SORT_ORDER)
    private String order;
}
