package com.cms.assetmanagement.service;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetImageMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetLockedFieldDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.AssetSubtitleDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.GeoRestrictionsDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@RequiredArgsConstructor
@Slf4j
public class AssetInsertHelper {

    private final VodAssetMapper vodAssetMapper;

    private final VodAssetImageMapper vodAssetImageMapper;

    private final VodAssetColumnLockMapper vodAssetColumnLockMapper;

    public void insertDrmData(List<AssetDrmDto> drmDtoList) {
        if (drmDtoList == null || drmDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertDRMData(drmDtoList);
    }

    public void insertExternalIdData(List<AssetExternalIdDto> assetExternalIdDtoList) {
        if (assetExternalIdDtoList == null || assetExternalIdDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertExternalIdData(assetExternalIdDtoList);
    }

    public void insertAdBreakData(List<AdBreaksDto> adBreaksDtoList) {
        if (adBreaksDtoList == null || adBreaksDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertAdBreakData(adBreaksDtoList);
    }

    public void insertPlatformData(List<PlatformTagData> platformTagDataList) {
        if (platformTagDataList == null || platformTagDataList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertPlatformData(platformTagDataList);
    }

    public void insertRatingData(List<AssetRatingDto> assetRatingDtoList) {
        if (assetRatingDtoList == null || assetRatingDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertRatingData(assetRatingDtoList);
    }

    public void insertCastData(List<AssetCastDto> assetCastDtoList) {
        if (assetCastDtoList == null || assetCastDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertCastData(assetCastDtoList);
    }

    public void insertGracenoteMap(GracenoteMapDto gracenoteMapDto) {
        if (gracenoteMapDto == null) {
            return;
        }

        vodAssetMapper.insertGracenoteMap(gracenoteMapDto);
    }

    public void insertLicenseWindowData(List<LicenseWindowDto> licenseWindowDtoList) {
        if (licenseWindowDtoList == null || licenseWindowDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertLicenseWindowData(licenseWindowDtoList);
    }

    public void insertEventWindowData(List<EventWindowDto> eventWindowDtoList) {
        if (eventWindowDtoList == null || eventWindowDtoList.isEmpty()) {
            return;
        }

        vodAssetMapper.insertEventWindowData(eventWindowDtoList);
    }

    public void insertSubtitles(List<AssetSubtitleDto> subtitleList) {
        if (subtitleList == null || subtitleList.isEmpty()) {
            return;
        }
        vodAssetMapper.insertSubtitles(subtitleList);
    }

    public void insertGeoRestrictions(List<GeoRestrictionsDto> geoRestrictionsList) {
        if (geoRestrictionsList == null || geoRestrictionsList.isEmpty()) {
            return;
        }
        vodAssetMapper.insertGeoRestrictions(geoRestrictionsList);
    }

    public void deleteAndInsertRatingData(List<AssetKeyDto> assetKeyList,
        List<ParentalRatingsDto> parentalRatingsDtoList) {
        if (parentalRatingsDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Parental Ratings Data");
        vodAssetMapper.deleteRatingData(assetKeyList);

        if (parentalRatingsDtoList.isEmpty()) {
            return;
        }

        List<AssetRatingDto> updatedRatingsList = parentalRatingsDtoList.stream()
            .map(ratingsData -> AssetRatingDto.builder()
                .programId(assetKeyList.get(0).getContentId())
                .countryCode(assetKeyList.get(0).getCountryCode())
                .provider(assetKeyList.get(0).getVcCpId())
                .code(ratingsData.getRatings())
                .body(ratingsData.getBody())
                .regrId(Constants.CMS_STRING)
                .feedWorker(Constants.CMS_STRING)
                .crctrId(Constants.CMS_STRING).build()
            ).toList();

        vodAssetMapper.insertRatingData(updatedRatingsList);
    }

    public void deleteAndInsertPlatformTagData(List<AssetKeyDto> assetKeyList,
        List<PlatformTagData> platformTagDataList) {
        if (platformTagDataList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Platform Tag Data");
        vodAssetMapper.deletePlatforms(assetKeyList);

        if (platformTagDataList.isEmpty()) {
            return;
        }

        platformTagDataList.forEach(platformTagData -> {
            platformTagData.setContentId(assetKeyList.get(0).getContentId());
            platformTagData.setCountryCode(assetKeyList.get(0).getCountryCode());
            platformTagData.setVcCpId(assetKeyList.get(0).getVcCpId());
            platformTagData.setCrctrId(Constants.CMS_STRING);
            platformTagData.setRegrId(Constants.CMS_STRING);
            platformTagData.setFeedWorker(Constants.CMS_STRING);
        });

        vodAssetMapper.insertPlatformData(platformTagDataList);
    }

    public void deleteAndInsertExternalIdData(List<AssetKeyDto> assetKeyList,
        List<ExternalProviderDto> externalProviderDtoList) {
        if (externalProviderDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating External Provider Data");
        vodAssetMapper.deleteExternalIdData(assetKeyList);

        if (externalProviderDtoList.isEmpty()) {
            return;
        }

        List<AssetExternalIdDto> updatedExternalProviderList = externalProviderDtoList.stream()
            .map(externalProviderData -> AssetExternalIdDto.builder()
                .programId(assetKeyList.get(0).getContentId())
                .countryCode(assetKeyList.get(0).getCountryCode())
                .idProvider(assetKeyList.get(0).getVcCpId())
                .idType(externalProviderData.getIdType())
                .externalProgramId(externalProviderData.getExternalProgramId())
                .provider(externalProviderData.getProvider())
                .regrId(Constants.CMS_STRING)
                .feedWorker(Constants.CMS_STRING)
                .crctrId(Constants.CMS_STRING).build()
            ).toList();

        vodAssetMapper.updateExternalIdData(updatedExternalProviderList);
    }

    public void deleteAndInsertCastData(List<AssetKeyDto> assetKeyList,
        List<AssetCastDto> assetCastDtoList) {
        if (assetCastDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Cast Data");
        vodAssetMapper.deleteCastData(assetKeyList);

        if (assetCastDtoList.isEmpty()) {
            return;
        }

        List<AssetCastDto> updatedCastsList = assetCastDtoList.stream()
            .map(castData -> AssetCastDto.builder()
                .contentId(assetKeyList.get(0).getContentId())
                .countryCode(assetKeyList.get(0).getCountryCode())
                .vcCpId(assetKeyList.get(0).getVcCpId())
                .name(castData.getName())
                .role(castData.getRole())
                .characterName(castData.getCharacterName())
                .regrId(castData.getRegrId() != null
                    ? castData.getRegrId()
                    : Constants.CMS_STRING
                ).crctrId(castData.getCrctrId() != null
                    ? castData.getCrctrId()
                    : Constants.CMS_STRING
                ).feedWorker(castData.getFeedWorker() != null
                    ? castData.getFeedWorker()
                    : Constants.CMS_STRING
                ).build()
            ).toList();

        vodAssetMapper.insertCastData(updatedCastsList);
    }

    public void deleteAndInsertLicenseWindowData(List<AssetKeyDto> assetKeyList,
        List<LicenseWindowDto> licenseWindowDtoList) {
        if (licenseWindowDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating License Window Data");
        vodAssetMapper.deleteLicenseWindowData(assetKeyList);

        if (licenseWindowDtoList.isEmpty()) {
            return;
        }

        List<LicenseWindowDto> updatedWindowList = licenseWindowDtoList.stream()
            .map(windowData -> LicenseWindowDto.builder()
                .programId(assetKeyList.get(0).getContentId())
                .countryCode(assetKeyList.get(0).getCountryCode())
                .providerId(assetKeyList.get(0).getVcCpId())
                .licenseId(windowData.getLicenseId())
                .identifierId(UUID.randomUUID().toString())
                .availableStarting(windowData.getAvailableStarting())
                .availableEnding(windowData.getAvailableEnding())
                .regrId(windowData.getRegrId() != null
                    ? windowData.getRegrId()
                    : Constants.CMS_STRING
                ).crctrId(windowData.getCrctrId() != null
                    ? windowData.getCrctrId()
                    : Constants.CMS_STRING
                ).feedWorker(windowData.getFeedWorker() != null
                    ? windowData.getFeedWorker()
                    : Constants.CMS_STRING
                ).build()
            ).toList();

        vodAssetMapper.insertLicenseWindowData(updatedWindowList);
    }

    public void deleteAndInsertEventWindowData(List<AssetKeyDto> assetKeyList,
        List<EventWindowDto> eventWindowDtoList) {
        if (eventWindowDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Event Window Data");
        vodAssetMapper.deleteEventWindowData(assetKeyList);

        if (eventWindowDtoList.isEmpty()) {
            return;
        }

        List<EventWindowDto> updatedWindowList = eventWindowDtoList.stream()
            .map(windowData -> EventWindowDto.builder()
                .programId(assetKeyList.get(0).getContentId())
                .countryCode(assetKeyList.get(0).getCountryCode())
                .providerId(assetKeyList.get(0).getVcCpId())
                .eventId(windowData.getEventId())
                .identifierId(UUID.randomUUID().toString())
                .eventStarting(windowData.getEventStarting())
                .eventEnding(windowData.getEventEnding())
                .regrId(windowData.getRegrId() != null
                    ? windowData.getRegrId()
                    : Constants.CMS_STRING
                ).crctrId(windowData.getCrctrId() != null
                    ? windowData.getCrctrId()
                    : Constants.CMS_STRING
                ).feedWorker(windowData.getFeedWorker() != null
                    ? windowData.getFeedWorker()
                    : Constants.CMS_STRING
                ).build()
            ).toList();

        vodAssetMapper.insertEventWindowData(updatedWindowList);
    }

    public void deleteAndInsertImageData(List<AssetKeyDto> assetKeyList,
        List<AssetImageDto> assetImageDtoList) {
        if (assetImageDtoList == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Image Data");
        vodAssetImageMapper.deleteImagesByContentId(assetKeyList);

        if (assetImageDtoList.isEmpty()) {
            return;
        }

        vodAssetImageMapper.insertImagesByContentId(assetImageDtoList);
    }

    public void deleteAndInsertGracenoteData(List<AssetKeyDto> assetKeyList,
        String gracenoteAction) {
        if (gracenoteAction == null || assetKeyList == null || assetKeyList.isEmpty()) {
            return;
        }

        log.info("Updating Gracenote Map Table for comparison Data");

        GracenoteMapDto gracenote = GracenoteMapDto.builder().
            contentId(assetKeyList.get(0).getContentId()).
            vcCpId(assetKeyList.get(0).getVcCpId()).
            countryCode(assetKeyList.get(0).getCountryCode()).
            regrId(Constants.CMS_STRING).
            crctrId(Constants.CMS_STRING).build();

        if (Constants.ADD.equals(gracenoteAction)) {
            log.info("Deleting contentId {} from Map Table to insert new",
                assetKeyList.get(0).getContentId());
            vodAssetMapper.deleteGracenoteMap(gracenote);
            log.info("Adding contentId {} in Map Table", assetKeyList.get(0).getContentId());
            vodAssetMapper.insertGracenoteMap(gracenote);
        } else if (Constants.DELETE.equals(gracenoteAction)) {
            log.info("Deleting contentId {} from Map Table", assetKeyList.get(0).getContentId());
            vodAssetMapper.deleteGracenoteMap(gracenote);
        }
    }

    public void deleteAndInsertLockedColumnData(List<AssetKeyDto> assetKeyList,
        List<AssetLockedFieldDto> lockedFieldDtoList) {
        if (lockedFieldDtoList == null || CollectionUtils.isEmpty(assetKeyList)) {
            return;
        }
        log.info("Updating Locked Columns Data");
        vodAssetColumnLockMapper.deleteColumnLockByContentId(assetKeyList);
        if (!CollectionUtils.isEmpty(lockedFieldDtoList)) {
            vodAssetColumnLockMapper.insertColumnLockByContentId(lockedFieldDtoList);
        }

    }

    public void deleteAndInsertLastStatusData(List<AssetKeyDto> assetKeyList) {
        if (assetKeyList == null || CollectionUtils.isEmpty(assetKeyList)) {
            return;
        }
        log.info("Deleting Last Status table Data");
        vodAssetMapper.deleteLastStatusData(assetKeyList);
        log.info("Inserting Last Status table Data");
        vodAssetMapper.insertLastStatusData(assetKeyList);

    }

    public void insertLockedColumnData(
        List<AssetLockedFieldDto> lockedFieldDtoList) {
        log.info("Inserting Locked Columns Data");
        if (!CollectionUtils.isEmpty(lockedFieldDtoList)) {
            vodAssetColumnLockMapper.insertColumnLockByContentId(lockedFieldDtoList);
        }

    }
}
