package com.cms.assetmanagement.model;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DRMDto {

    @Size(max = 20)
    private String type;
    @Size(max = 2000)
    private String licenseUrl;
    @Size(max = 200)
    private String customHeaderName;
    @Size(max = 4000)
    private String customHeaderValue;
}
