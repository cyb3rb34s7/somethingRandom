package com.cms.assetmanagement.common.util;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.AlertRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class NotificationUtil {

    private static final String ECS = "ECS";

    @Value("${CMS_NOTIFICATION_SVR_URL}")
    private String notificationServerUrl;

    @Value("${AWS_REGION}")
    private String region;

    @Value("${CURRENT_ENV}")
    private String env;

    @Value("${ERROR_SOURCE:CMS-ASSET-MANAGEMENT}")
    private String errorSource;

    private static final String CALLING_THE_API_WITH_ENDPOINT_AND_METHOD = "Calling the API with endpoint: {} and method: {}";

    private final RestTemplate restTemplate;

    public NotificationUtil(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Async
    public void sendErrorMail(Exception ex, String errorType, String errorCode) {
        log.info("Sending error mail");
        AlertRequestDto alertRequestDto = AlertRequestDto.builder().errorCode(errorCode)
            .errorMessage(ErrorMessageUtil.generateErrMessage(ex))
            .errorType(errorType).resourceType(ECS).region(region).env(env)
            .sourceService(errorSource).build();
        try {

            handleHttpExchange(notificationServerUrl + Constants.NOTIFICATION_URL,
                HttpMethod.POST.name(), new HttpEntity<>(alertRequestDto)
            );
            log.info("Notification: Mail successfully sent");
        } catch (Exception exe) {
            log.error("Notification Error: Error in sending mail:{}",
                ErrorMessageUtil.generateErrMessage(
                    exe));
        }
    }

    @Async
    public void sendAlarm(Exception ex, String errorType, String errorCode, String... description) {
        AlertRequestDto alertRequestDto = AlertRequestDto.builder().errorCode(errorCode)
            .errorMessage(ErrorMessageUtil.generateErrMessage(ex) + String.join(",", description))
            .errorType(errorType).resourceType(ECS).region(region).env(env)
            .sourceService(errorSource).build();
        try {
            handleHttpExchange(notificationServerUrl + Constants.ALARM_URL,
                HttpMethod.POST.name(), new HttpEntity<>(alertRequestDto)
            );
            log.info("Alarm: Alarm triggered successfully");
        } catch (Exception exe) {
            log.error("Alarm Error: Error in triggering alarm:{}",
                ErrorMessageUtil.generateErrMessage(
                    exe));
        }
    }

    private void handleHttpExchange(String endPoint,
        String httpMethod,
        HttpEntity<?> httpEntity) {
        log.info(CALLING_THE_API_WITH_ENDPOINT_AND_METHOD, endPoint, httpMethod);
        restTemplate.exchange(
            endPoint,
            HttpMethod.valueOf(httpMethod),
            httpEntity,
            Object.class);
    }
}