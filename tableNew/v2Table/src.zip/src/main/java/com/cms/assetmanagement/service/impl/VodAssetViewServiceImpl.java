package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.enums.AssetImageType;
import com.cms.assetmanagement.common.enums.ExternalSourceEnum;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetImageMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EpisodeHierarchyDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetViewFilterDto;
import com.cms.assetmanagement.service.VodAssetViewService;
import jakarta.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class VodAssetViewServiceImpl implements VodAssetViewService {

    private final VodAssetMapper vodAssetMapper;
    private final VodAssetImageMapper vodAssetImageMapper;
    private final VodAssetColumnLockMapper vodAssetColumnLockMapper;
    private final Utils utils;

    @Value("${CMS_FEED_WORKERS}")
    public String cmsFeedWorkers;

    @Value("${EXTERNAL_FEED_WORKERS}")
    public String externalFeedWorkers;

    List<String> feedWorkerList = new ArrayList<>();
    List<String> extFeedWorkersList = new ArrayList<>();

    //    @Autowired
    public VodAssetViewServiceImpl(VodAssetMapper vodAssetMapper,
        @Autowired(required = false)
        VodAssetImageMapper vodAssetImageMapper,
        VodAssetColumnLockMapper vodAssetColumnLockMapper,
        Utils utils) {
        this.vodAssetMapper = vodAssetMapper;
        this.vodAssetImageMapper = vodAssetImageMapper;
        this.vodAssetColumnLockMapper = vodAssetColumnLockMapper;
        this.utils = utils;
    }

    @PostConstruct
    public void init() {
        feedWorkerList = Arrays.asList(cmsFeedWorkers.split(","));
        extFeedWorkersList = Arrays.asList(externalFeedWorkers.split(","));

    }

    @Override
    @Transactional("contentTransactionManager")
    public VodAssetDto getAssetView(String contentId, String cpId, String countryCode) {
        log.info("Getting asset view for contentId : {}", contentId);

        VodAssetDto asset = vodAssetMapper.getAssetView(contentId, cpId, countryCode,
            extFeedWorkersList);
        if (asset != null) {
            setServiceLevelFields(asset);
            List<AssetImageDto> assetImageDtos = vodAssetImageMapper.getAllImageByContentId(
                AssetKeyDto.builder().contentId(contentId).countryCode(countryCode).vcCpId(cpId)
                    .build());
            asset.setLockedFields(vodAssetColumnLockMapper.getAllColumnLockByContentId(
                AssetKeyDto.builder().contentId(contentId).countryCode(countryCode).vcCpId(cpId)
                    .build()));

            this.handleDefaultImageValue(asset, assetImageDtos);

        }

        return asset;
    }

    @Override
    public VodAssetDto getAssetCPView(String contentId, String cpId, String countryCode) {
        log.info("Getting asset CP view for contentId : {}", contentId);

        VodAssetDto assetDetails = vodAssetMapper.getAssetDetails(contentId, cpId, countryCode);
        VodAssetDto assetCpView = null;
        if (assetDetails != null) {
            if (utils.isTvplusDeltaFeedWorker(assetDetails)) {
                assetCpView = vodAssetMapper.getAssetFullFeedView(contentId, cpId,
                    countryCode, extFeedWorkersList);
            } else {
                assetCpView = vodAssetMapper.getAssetCPView(contentId, cpId, countryCode,
                    extFeedWorkersList);
            }
        }
        if (assetCpView != null) {
            setServiceLevelFields(assetCpView);
        }
        return assetCpView;
    }

    @Override
    public VodAssetDto getAssetGracenoteView(String contentId, String cpId, String countryCode) {
        log.info("Getting asset gracenote view for contentId : {}", contentId);

        VodAssetDto asset = null;
        String externalSource = vodAssetMapper.getCpExternalSource(countryCode, cpId);
        if (ExternalSourceEnum.GVD.getValue().equalsIgnoreCase(externalSource)) {
            asset = vodAssetMapper.getAssetGracenoteView(contentId, cpId, countryCode,
                extFeedWorkersList);
        }
        if (ExternalSourceEnum.ONAPI.getValue().equalsIgnoreCase(externalSource)) {
            asset = vodAssetMapper.getAssetONAPIView(contentId, cpId, countryCode,
                extFeedWorkersList);
        }
        if (asset != null) {
            asset.setExternalSource(externalSource);
        }
        return asset;
    }

    @Override
    public VodAssetDto getAssetGracenoteOnView(String contentId, String cpId, String countryCode) {
        log.info("Getting asset gracenote on view for contentId : {}", contentId);

        VodAssetDto asset = vodAssetMapper.getAssetGracenoteOnView(contentId, cpId, countryCode,
            extFeedWorkersList);
        if (asset != null) {
            setServiceLevelFields(asset);
        }
        return asset;
    }

    @Override
    public AssetViewFilterDto getViewFilters(AssetKeyDto assetKeyDto) {
        log.info("Getting View Filters and other data");
        AssetViewFilterDto viewFilters = AssetViewFilterDto.builder().build();
        viewFilters.setLanguages(vodAssetMapper.getLanguages());
        viewFilters.setPlatforms(
            vodAssetMapper.getPlatforms(assetKeyDto, Constants.PLATFORM_DEVICE));

        assetKeyDto.setType(Constants.SINGLEVOD.equals(assetKeyDto.getType())
            ? Constants.SHOW : assetKeyDto.getType());
        viewFilters.setParentalRatings(vodAssetMapper.getParentalRatings(assetKeyDto));

        return viewFilters;
    }

    @Override
    public EpisodeHierarchyDto getViewEpisodeHierarchy(AssetKeyDto assetKeyDto) {
        log.info("Getting episode hierarchy for asset key: {}", assetKeyDto.getContentId());
        EpisodeHierarchyDto episodeHierarchy = EpisodeHierarchyDto.builder().build();

        if (assetKeyDto.getSeasonId() != null) {
            episodeHierarchy.setSeason(
                vodAssetMapper.getEpisodeDetails(assetKeyDto.getSeasonId()));
        }
        if (assetKeyDto.getShowId() != null) {
            episodeHierarchy.setShow(vodAssetMapper.getEpisodeDetails(assetKeyDto.getShowId()));
        }
        return episodeHierarchy;
    }

    private void handleDefaultImageValue(VodAssetDto asset, List<AssetImageDto> assetImageDtos) {
        if (asset.getImageLandscape() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.LANDSCAPE_BANNER.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImageLandscape())
                    .imageUrlOriginal(asset.getImageLandscapeOriginal()).crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImageLandscapeDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        if (asset.getImagePortrait() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.PORTRAIT_BANNER.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImagePortrait())
                    .imageUrlOriginal(asset.getImagePortraitOriginal()).crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImagePortraitDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        if (asset.getImagePortraitIconic() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.PORTRAIT_ICONIC.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImagePortraitIconic())
                    .imageUrlOriginal(asset.getImagePortraitIconicOriginal())
                    .crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImagePortraitIconicDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        if (asset.getImageLandscapeIconic() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.LANDSCAPE_ICONIC.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImageLandscapeIconic())
                    .imageUrlOriginal(asset.getImageLandscapeIconicOriginal())
                    .crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImageLandscapeIconicDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        if (asset.getImageTitleTreatment() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.TITLE_TREATMENT.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImageTitleTreatment())
                    .imageUrlOriginal(asset.getImageTitleTreatmentOriginal())
                    .crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImageTitleTreatmentDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        if (asset.getImageLandscapeBackdrop() != null) {
            assetImageDtos.add(
                AssetImageDto.builder().imageType(AssetImageType.LANDSCAPE_BACKDROP.value)
                    .isDefault("Y").imageUrlProcessed(asset.getImageLandscapeBackdrop())
                    .imageUrlOriginal(asset.getImageLandscapeBackdropOriginal())
                    .crctrId(asset.getCrctrId())
                    .contentId(asset.getContentId()).countryCode(asset.getCountryCode())
                    .feedWorker(asset.getFeedWorker())
                    .imgDimension(asset.getImageLandscapeBackdropDimension())
                    .providerId(asset.getVcCpId()).regrId(asset.getRegrId()).build());
        }
        asset.setAssetImageList(assetImageDtos);
    }

    private void setServiceLevelFields(VodAssetDto asset) {
        String licenseWindow = utils.getLicenseWindow(asset.getAvailableStarting(),
            asset.getExpiryDate());
        String status = utils.getStatus(licenseWindow, asset.getStatus());
        status = utils.checkExternalAsset(status, asset.getFeedWorker(),
            feedWorkerList);
        utils.setExternalProviderData(asset);
        asset.setLicenseWindowList(filterNullWindows(asset.getLicenseWindowList()));
        asset.setLicenseWindow(licenseWindow);
        asset.setEventWindowList(filterNullWindows(asset.getEventWindowList()));
        asset.setStatus(status);
        asset.setLanguage(vodAssetMapper.getDescriptionLanguage(asset.getCountryCode()));
    }

    private <T extends DateRangeWindow> List<T> filterNullWindows(List<T> windowList) {
        if (windowList != null && !windowList.isEmpty()) {
            windowList = windowList.stream()
                .filter(window -> window.getStartingTime() != null).toList();
        }
        return windowList;
    }
}
