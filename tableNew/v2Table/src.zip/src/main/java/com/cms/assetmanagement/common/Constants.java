package com.cms.assetmanagement.common;

import java.util.List;

public class Constants {

    public static final String SUCCESS = "success";
    public static final String ADD = "add";
    public static final String DELETE = "delete";
    public static final String VALID = "valid";
    public static final String INVALID = "invalid";
    public static final String HEATHCHECK_SUCCESS = "Heathcheck successful";
    public static final String ASSET_UPDATE_SUCCESS = "Asset Updated Successfully";
    public static final String CP_UPDATE_SUCCESS = "CP Data Updated Successfully";
    public static final String ASSET_INSERT_SUCCESS = "Asset Inserted Successfully";
    public static final String ASSET_DELETE_SUCCESS = "Asset Deleted Successfully";
    public static final String IMAGE_PROCESS_SUCCESS = "Image Processed Successfully";
    public static final String IMAGE_DELETE_SUCCESS = "Image Deleted Successfully";
    public static final String EXTERNALID_INSERT_SUCCESS = "ExternalIds Inserted Successfully";
    public static final String DRM_INSERT_SUCCESS = "DRMs Inserted Successfully";

    public static final String AVAILABLE_START_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String EXPIRY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String STATUS_OK = "ok";
    public static final String STATUS_FAIL = "fail";
    public static final String STRING_Y = "Y";
    public static final String STRING_YES = "Yes";
    public static final String STRING_NO = "No";
    public static final String STRING_ALL = "ALL";
    public static final String DB_STATUS_PRD = "PRD & STG";
    public static final String DB_STATUS_STG = "STG";


    public static final String FEED_WORKERS = "feedWorkers";
    public static final String FEED_WORKER_PRIORITY = "feedWorkerOrder";
    public static final String DEFAULT_FILTER_FIELD = "updateDate";
    public static final String DEFAULT_SORT_ORDER = "DESC";
    public static final String ASC_SORT_ORDER = "ASC";
    public static final String METHOD_POST = "POST";

    public static final String ASSETS = "assets";
    public static final String ASSET_DETAILS = "assetDetails";
    public static final String FILTERS = "filters";
    public static final String COUNTRY = "countries";
    public static final String TYPE_FILTER = "filter";
    public static final String TYPE_SEARCH = "search";
    public static final String ASSET_COUNT = "assetCount";
    public static final String PROCESSED_IMAGES = "processedImages";
    public static final String EXTERNAL_ID_STR = "externalIds";
    public static final String VALIDATION = "validation";
    public static final String ID_TYPE_VALIDATION_STATUS = "validationStatus";
    public static final String STREAM_URIS = "streamUris";
    public static final String EVALUATION = "evaluation";
    public static final String LANGUAGE_STR = "LANGUAGE";

    // Column types
    public static final String COLUMN_STR = "column";
    public static final String SORT_STR = "sort";
    public static final String FILTER_STR = "filter";

    //    Asset Types
    public static final String EPISODE = "EPISODE";
    public static final String SEASON = "SEASON";
    public static final String SHOW = "SHOW";
    public static final String SINGLEVOD = "SINGLEVOD";
    public static final String MUSIC = "MUSIC";
    public static final String MOVIE = "MOVIE";

    public static final String CMS_STRING = "CMS";
    public static final String UPDATED_STATUS = "updatedStatus";
    public static final String ASSET_KEY_DTO = "assetKeyDto";
    public static final String DRM_DETAILS_STRING = "drmDetailsList";
    public static final String EXTERNAL_DETAILS_STRING = "externalDetailsList";
    public static final String ADBREAK_STRING = "adBreakList";
    public static final String PLATFORM_TAG_DATA = "platformDataList";
    public static final String STATUS_UPDATE_SUCCESS = "Status Updated Successfully";
    public static final String CONTENT_ID = "contentId";
    public static final String ASSETS_UPDATED_SUCCESSFULLY = "Assets updated successfully";
    public static final String VOD_ASSET_DTO = "vodAssetDto";
    public static final String LIMIT_DEFAULT = "1000";
    public static final String OFFSET_DEFAULT = "0";

    public static final int LIMIT_DEFAULT_VALUE = 1000;
    public static final int OFFSET_DEFAULT_VALUE = 0;
    public static final String FILTER_BDDY = "filterBody";
    public static final String CP_ID = "cpId";

    public static final String ACTIVE = "Active";
    public static final String UPCOMING_IN = "Upcoming in ";
    public static final String EXPIRING_IN = "Expiring in ";
    public static final String UPCOMING_AFTER_300_DAYS = "Upcoming after 300 days";
    public static final String EXPIRED = "Expired";
    public static final String DAY = "day";
    public static final String DAYS = "days";

    public static final String SINGLE_QUOTE = "'";
    public static final String DOUBLE_QUOTES = "\"";

    // License Window Update
    public static final String MESSAGE = "message";
    public static final String WIN_UPDATE_SUCCESS = "Asset license window update was successful.";
    public static final String WIN_UPDATE_FAIL = "Asset license window was not updated as no active slot was found.";
    public static final String ACTIVE_WINDOW = "activeWindow";
    public static final String VALIDATION_RESULT = "validationResult";

    // Filters Literals
    public static final String GENRE = "genres";
    public static final String TI_NAME = "tiName";
    public static final String RATINGS = "ratings";
    public static final String PLATFORMS = "platforms";
    public static final String LANGUAGES = "languages";
    public static final String AUDIO_LANG = "audioLang";
    public static final String SUBTITLE_LANG = "subtitleLang";
    public static final String COUNTRY_CODE = "countryCode";
    public static final String EXT_FEED_WORKER = "extFeedWorkers";
    public static final String CONTENT_PARTNER = "contentPartner";
    public static final String UPDATE_DATE = "updateDate";

    public static final String STATUS_COLUMN = "ASSET_CURRENT_STATUS";
    public static final String ALL_TAB = "all";
    public static final String QC_TAB = "qc";
    public static final String PROD_TAB = "prod";

    public static final String AUDIO_LANG_TEXT = "Audio Language";
    public static final String SUBTITLE_LANG_TEXT = "Subtitle Language";
    public static final String COUNTRY_TEXT = "Country";
    public static final String GENRE_TEXT = "Genres";
    public static final String TECH_INTEGRATOR_TEXT = "Tech Integrator";
    public static final String CONTENT_PARTNER_TEXT = "Content Partner";
    public static final int EXPIRY_THRESHHOLD = 30;
    public static final int UPCOMING_THRESHHOLD = 300;
    public static final int VALUE_ONE = 1;

    //    All Statuses
    public static final String READY_FOR_QC = "Ready for QC";
    public static final String QC_IN_PROGRESS = "QC in Progress";
    public static final String QC_PASS = "QC Pass";
    public static final String TEMP_QC_PASS = "Temp QC Pass";
    public static final String TRANSFERRING = "Transferring";
    public static final String QC_FAIL = "QC Fail";
    public static final String REVOKED = "Revoked";
    public static final String UNTRACKABLE = "Untrackable";
    public static final String RELEASED = "Released";
    public static final String UPCOMING = "Upcoming";
    public static final String SMF_IMPORTED = "SMF Imported";
    public static final String READY_FOR_RELEASE = "Ready for Release";

    public static final List<String> INVALID_ASSET_VALIDATION_STATUS = List.of(QC_PASS,
        TEMP_QC_PASS, TRANSFERRING);
    public static final List<String> INVALID_MEDIA_VALIDATION_STATUS = List.of(QC_PASS,
        TEMP_QC_PASS, REVOKED, TRANSFERRING);
    public static final List<String> ALL_STATUS = List.of(
        Constants.READY_FOR_QC, Constants.QC_IN_PROGRESS, Constants.QC_PASS, Constants.TEMP_QC_PASS,
        Constants.QC_FAIL, Constants.READY_FOR_RELEASE, Constants.RELEASED, Constants.REVOKED,
        Constants.UNTRACKABLE, Constants.SMF_IMPORTED);
    public static final List<String> IN_QC_STATUS = List.of(Constants.READY_FOR_QC,
        Constants.QC_IN_PROGRESS, Constants.QC_PASS, Constants.TEMP_QC_PASS, Constants.QC_FAIL,
        Constants.SMF_IMPORTED);
    public static final List<String> IN_PRODUCTION_STATUS = List.of(
        Constants.RELEASED, Constants.READY_FOR_RELEASE);
    public static final List<String> PLATFORM_DEVICE = List.of(
        "TV", "MOB", "FHUB", "WEB");

    public static final List<String> EXPORT_COLUMNS_LIST = List.of(
        Constants.CONTENT_ID, "assetId", "type", Constants.COUNTRY_CODE, "mainTitle",
        "mainTitleLanguage", "shortTitle", "shortTitleLanguage", "runningTime", "adTag",
        "streamUri", "description", Constants.TI_NAME, "showTitle", "seasonTitle", "showId",
        "seasonId", "seasonNo", "episodeNo", "vcCpId", "ingestionType", "releaseDate",
        Constants.GENRE, "parentalRatings", "cast", "artist", "deeplinkPayload", "chapterTime",
        "chapterDescription", Constants.AUDIO_LANG, Constants.SUBTITLE_LANG, "drm",
        "quality", "webVttUrl", "attributes", "externalProvider", "licenseWindowList",
        "eventWindowList", Constants.CONTENT_PARTNER, "contentTier", "airType", "subType",
        "matchInformation", "geoRestrictions", "language");

    // Public API constants
    public static final List<String> PUBLIC_API_COLUMNS_LIST = List.of(Constants.COUNTRY_CODE,
        Constants.TI_NAME, Constants.CONTENT_ID, "assetId", Constants.CONTENT_PARTNER, "mainTitle",
        "showTitle", "seasonTitle", "type", "showId", "seasonId", "seasonNo", "episodeNo",
        Constants.GENRE, "starring", Constants.RATINGS, "vcCpId", "description", "releaseDate",
        "licenseWindow", "availableStarting", "expiryDate", "runningTime", "status", "dbStatus",
        "regDate", Constants.UPDATE_DATE, "qcPassReason", "externalProgramId", "externalIdProvider",
        "onDeviceTrans", "liveOnDevice", "director", "streamUri", "webVttUrl",
        Constants.AUDIO_LANG, Constants.SUBTITLE_LANG, "deeplinkPayload", "audioCode",
        "subtitleCode", "quality", "drm", "thumbnailUrl");


    public static final String DESC_SORT_DELIMITER = "-";

    // Validation Constants
    public static final String VALID_SMF = "Through Schema Validator, SMF validation passed";
    public static final String INVALID_SMF = "Through Schema Validator, SMF validation failed";
    public static final String PASS = "PASS";
    public static final String FAIL = "FAIL";
    public static final String REQUIRED_STR = "required";
    public static final String MAX_LENGTH_STR = "maxLength";


    public static final List<String> VALID_TYPES = List.of(EPISODE, SEASON, MOVIE, SHOW, MUSIC);

    public static final int REQ_BODY_MAX_SIZE = 10240;

    public static final String DEEPLINK_BODY_START = "{\"deeplink_data\":";
    public static final String DEEPLINK_BODY_END = "}";
    public static final String DEEPLINK_CONTENT_TYPE = "tvshow";

    public static final String TITLE_TYPE_MAIN = "main";

    // Delete event window request
    public static final String REMOVE = "REMOVE";
    public static final String REMOVE_ALL = "REMOVE_ALL";
    public static final String EVENT_WINDOWS_DELETE_SUCCESSFUL = "Event windows deleted successfully";
    public static final String EVENT_WINDOWS_UPDATED_SUCCESSFUL = "Event windows updated successfully";
    public static final String LICENSE_WINDOWS_UPDATED_SUCCESSFUL = "License windows updated successfully";

    public static final String CNTR_CD_US = "US";

    // for Mail Notifications
    public static final String ALARM_URL = "/cms/monitoring/alarm";
    public static final String NOTIFICATION_URL = "/cms/monitoring/notification";


    private Constants() {
        throw new IllegalStateException("Constants class, only static access");
    }
}
