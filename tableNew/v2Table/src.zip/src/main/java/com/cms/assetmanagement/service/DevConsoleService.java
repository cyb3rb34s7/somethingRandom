package com.cms.assetmanagement.service;

import com.cms.assetmanagement.common.util.DevConsoleUtil;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.mapper.asset.content.DevConsoleMapper;
import com.cms.assetmanagement.model.devconsole.TiDto;
import com.cms.assetmanagement.model.devconsole.TiFeedworkerUpdateDto;
import com.cms.assetmanagement.model.devconsole.TiRequestDto;
import java.util.List;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DevConsoleService {

    private final DevConsoleMapper devConsoleMapper;
    private final DevConsoleUtil devConsoleUtil;

    @Autowired
    public DevConsoleService(DevConsoleMapper devConsoleMapper, DevConsoleUtil devConsoleUtil) {
        this.devConsoleMapper = devConsoleMapper;
        this.devConsoleUtil = devConsoleUtil;
    }

    public List<TiDto> getTiData(TiRequestDto tiRequestDto) {
        RowBounds rowBounds = tiRequestDto.getPagination() != null ?
            new RowBounds(
                tiRequestDto.getPagination().getOffset(),
                tiRequestDto.getPagination().getLimit()
            )
            : new RowBounds();

        String feedWorker = devConsoleUtil.parseFeedWorker(tiRequestDto.getFeedWorker());

        return devConsoleMapper.getTiData(feedWorker, rowBounds);
    }

    public void updateTiFeedworker(TiFeedworkerUpdateDto tiFeedworkerUpdateDto) {
        tiFeedworkerUpdateDto.setFeedworker(tiFeedworkerUpdateDto.getFeedworker().toUpperCase());
        if (!devConsoleUtil.isValidFeedWorker(tiFeedworkerUpdateDto.getFeedworker())) {
            throw new InvalidInputDataException(
                "Invalid Feed Worker provided. Feedworker can be 'CMS' or 'TVPLUS'");
        }

        devConsoleMapper.updateTiFeedworker(tiFeedworkerUpdateDto);
    }
}