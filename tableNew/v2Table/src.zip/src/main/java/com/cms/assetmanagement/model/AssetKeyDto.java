package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AssetKeyDto {

    @NotNull(message = "contentId can not be null")
    private String contentId;
    @NotNull(message = "countryCode can not be null")
    private String countryCode;
    @NotNull(message = "vcCpId can not be null")
    private String vcCpId;
    private String type;
    private String showId;
    private String seasonId;
    private String lastAssetStatus;

    @JsonIgnore
    public String getCompositeKey() {
        return contentId + "|" + vcCpId + "|" + countryCode;
    }

}