package com.cms.assetmanagement.common;

import java.util.List;

public class DevConsoleConstants {

    public static final String CONTENT_PARTNER = "contentPartners";

    private DevConsoleConstants() {
        throw new IllegalStateException("Constants class, only static access");
    }

    public static final String TECH_INTEGRATOR = "techIntegrators";

    // Feed Workers
    public static final String CMS_FEED_WORKER = "CMS";
    public static final String TVPLUS_FEED_WORKER = "TVPLUS";
    public static final String ANY_FEED_WORKER = "ALL";
    public static final List<String> VALID_FEED_WORKERS = List.of(CMS_FEED_WORKER,
        TVPLUS_FEED_WORKER, ANY_FEED_WORKER);
}
