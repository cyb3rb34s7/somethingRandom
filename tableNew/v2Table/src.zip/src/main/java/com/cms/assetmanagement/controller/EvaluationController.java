package com.cms.assetmanagement.controller;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.config.LogExecutionTime;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import com.cms.assetmanagement.service.EvaluationService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cms/tvplus/evaluation")
@Validated
@Slf4j
public class EvaluationController {

    @Autowired
    EvaluationService evaluationService;

    @LogExecutionTime
    @PostMapping("/comparison/program/list")
    public ResponseDto getProgramList(
        @Valid @RequestBody FilterRequestDto filterRequestDto) {
        log.info("Request received for asset evaluation view. Request body: {}", filterRequestDto);
        return ResponseHandler.processMethodResponse(Constants.EVALUATION,
            evaluationService.getProgramList(filterRequestDto));
    }

    @LogExecutionTime
    @GetMapping("/comparison/detail")
    public ResponseDto getDetail(@RequestParam String contentId,
        @RequestParam String cpId) {
        log.info("Request received for asset evaluation detail view. Content Id: {}, CP Id: {}",
            contentId, cpId);
        return ResponseHandler.processMethodResponse(Constants.EVALUATION,
            evaluationService.getDetail(contentId, cpId));
    }

    @LogExecutionTime
    @PostMapping("/comparison/count")
    public ResponseDto getCount(@Valid @RequestBody FilterRequestDto filterRequestDto) {
        log.info("Request received for asset evaluation count");
        return ResponseHandler.processMethodResponse(Constants.EVALUATION,
            evaluationService.getCount(filterRequestDto));
    }

}
