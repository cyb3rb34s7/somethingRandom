package com.cms.assetmanagement.model.devconsole;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class TiFeedworkerUpdateDto {

    @NotNull
    private String vcCpId;
    @NotNull
    private String countryCode;
    @NotNull
    private String feedworker;
}
