package com.cms.assetmanagement.model;

import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EventDeleteDto {

    @NotNull
    private String contentId;
    @NotNull
    private String vcCpId;
    @NotNull
    private String countryCode;

    private String eventStarting;
    private String eventEnding;

    @NotNull
    private String eventYn;
    @NotNull
    private String crctrId;
    @NotNull
    private String deeplinkPayload;

    //For event removal api
    @NotNull
    private String action;
    private List<String> eventIds;
}
