package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class GeoRestrictionsDto {

    private String contentId;
    private String providerId;
    private String countryCode;
    private String accessType;
    private String restrictionType;
    private String teamRegion;
    private Date regDate;
    private Date updateDate;
    private String crctrId;
    private String feedWorker;
    private String regrId;
}
