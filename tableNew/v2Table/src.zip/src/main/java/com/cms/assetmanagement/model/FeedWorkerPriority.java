package com.cms.assetmanagement.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FeedWorkerPriority {

    private String feedWorker;
    private int priority;
}
