package com.cms.assetmanagement.common.util;


import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.exception.DataNotFoundException;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.exception.JsonSchemaValidationException;
import com.cms.assetmanagement.model.BaseResponseDto;
import com.cms.assetmanagement.model.ErrorResponseDto;
import com.cms.assetmanagement.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@Slf4j
public class ResponseHandler {

    private ResponseHandler() {
        log.info("ResponseHandler constructor called");
    }

    public static ResponseDto processMethodResponse(boolean isSuccess, Object payloadObj,
        String payloadKey, Exception err) {
        if (isSuccess) {
            //Success
            if (payloadKey == null) {
                return processSuccess(null);
            } else {
                Map<String, Object> payload = new HashMap<>();
                payload.put(payloadKey, payloadObj);
                return processSuccess(payload);
            }
        } else {
            // Error
            return processError(
                setResponseDetails(err)
            );
        }
    }

    public static ResponseDto processMethodResponse(String payloadKey, Object payloadObj) {
        if (payloadKey == null) {
            return processSuccess(null);
        } else {
            Map<String, Object> payload = new HashMap<>();
            payload.put(payloadKey, payloadObj);
            return processSuccess(payload);
        }
    }

    public static ResponseDto processMethodResponse(Exception err) {
        return processError(
            setResponseDetails(err)
        );
    }

    public static ResponseDto processSuccess(Map<String, Object> daoResponse) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_OK).payload(daoResponse).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }

    private static ResponseDto processError(ErrorResponseDto errorDto) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_FAIL).err(errorDto).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }

    private static ErrorResponseDto setResponseDetails(Exception e) {
        if (e == null) {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR);
        }

        String baseMessage = ": " + e.getMessage();

        if (e instanceof MethodArgumentTypeMismatchException
            || e instanceof MethodArgumentNotValidException
            || e instanceof ConstraintViolationException
            || e instanceof InvalidInputDataException) {
            return new ErrorResponseDto(ErrorCode.INVALID_INPUT_DATA,
                ErrorMsg.INVALID_INPUT_DATA + baseMessage);
        } else if (e instanceof NoHandlerFoundException || e instanceof NoResourceFoundException) {
            return new ErrorResponseDto(ErrorCode.REQUIRED_URI_NOT_EXISTS,
                ErrorMsg.REQUIRED_URI_NOT_EXISTS + baseMessage);
        } else if (e instanceof DataIntegrityViolationException) {
            return new ErrorResponseDto(ErrorCode.DATA_INTEGRITY_VIOLATION,
                ErrorMsg.DATA_INTEGRITY_VIOLATION);
        } else if (e instanceof JsonSchemaValidationException) {
            return new ErrorResponseDto(ErrorCode.MALFORMED_BODY_CONTENT,
                ErrorMsg.MALFORMED_BODY_CONTENT + baseMessage);
        } else if (e instanceof MissingServletRequestParameterException) {
            return new ErrorResponseDto(ErrorCode.MISSING_REQUIRED_QUERY_PARAM,
                ErrorMsg.MISSING_REQUIRED_QUERY_PARAM + baseMessage);
        } else if (e instanceof HttpRequestMethodNotSupportedException) {
            return new ErrorResponseDto(ErrorCode.UNSUPPORTED_HTTP_METHOD,
                ErrorMsg.UNSUPPORTED_HTTP_METHOD + baseMessage);
        } else if (e instanceof DataNotFoundException) {
            return new ErrorResponseDto(ErrorCode.DATA_NOT_FOUND,
                ErrorMsg.DATA_NOT_FOUND + baseMessage);
        } else {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR + ErrorMsg.INTERNAL_SERVER_ERROR_BASE_MESSAGE);
        }
    }

}
