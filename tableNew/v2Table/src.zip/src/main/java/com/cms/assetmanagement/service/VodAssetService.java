package com.cms.assetmanagement.service;

import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetCountDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.BulkRevokeHierarchy;
import com.cms.assetmanagement.model.CountryDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.RatingsDto;
import com.cms.assetmanagement.model.ShowHierarchyDto;
import com.cms.assetmanagement.model.StreamURIDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetStatusDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import java.util.List;

public interface VodAssetService {

    String getOracleHealthcheck();

    List<VodAssetDto> getFilteredAssets(AssetFilterBodyDto filterBody);

    AssetCountDto getFilteredAssetsCount(AssetFilterBodyDto filterBody, String tab);

    VodAssetDetailedDto getAssetDetails(String contentId, String cpId, String countryCode);

    List<VodAssetDto> getAssetsForExport(AssetFilterBodyDto filterBody);

    long getExportAssetCount(AssetFilterBodyDto filterBody);

    List<FilterDto> getFilters();

    List<CountryDto> getCountryCodes();

    List<VodAssetStatusDto> getAssetListDetailsforUpload(AssetKeyListDto assetKeyList);

    List<ShowHierarchyDto> getShowHierarchy(AssetKeyDto assetKeyDto);

    List<LanguageDto> getLanguages();

    List<RatingsDto> getRatings();

    List<RatingsDto> getAllRatings();

    List<VodAssetDto> assetDetailsByColumns(AssetByColumnsReqDto assetReqByColumns);

    BulkRevokeHierarchy bulkRevokeHierarchy(List<AssetKeyDto> assetsList);

    LicenseWindowDto getActiveWindow(List<LicenseWindowDto> licenseWindows);

    List<StreamURIDto> getStreamUris(String contentId, String cpId, String countryCode);
}