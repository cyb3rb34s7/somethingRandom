package com.cms.assetmanagement.model.imageprocessing;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedImageDto {

    private String originalUrl;
    private String processedUrl;
}
