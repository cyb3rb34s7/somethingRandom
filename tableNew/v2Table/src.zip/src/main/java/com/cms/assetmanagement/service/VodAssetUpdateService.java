package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetUpdateDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.List;

public interface VodAssetUpdateService {

    // Update
    void updateAsset(VodAssetDto vodAssetDto) throws JsonProcessingException;

    void updateCPAsset(VodAssetDto vodAssetDto);

    void updateVodAsset(VodAssetUpdateDto vodAssetUpdateDto) throws JsonProcessingException;

    void updateAssetDetails(VodAssetDetailedDto assetDetails) throws JsonProcessingException;

    void updateAssetStatus(AssetStatusUpdateDto updatedStatus);

    void updateAssetByBulk(AssetUpdateByBulkDto assetUpdateByBulkDto)
        throws JsonProcessingException;

    void bulkUpdateAssets(List<VodAssetDto> updatedAssets) throws JsonProcessingException;

    // Insert
    void insertAsset(VodAssetDto vodAssetDto) throws JsonProcessingException;

    void insertAssetDetails(VodAssetDetailedDto assetDetails) throws JsonProcessingException;

    void insertExternalIdData(List<AssetExternalIdDto> assetExternalIdList);

    void insertDRMData(List<AssetDrmDto> assetDrmList);

    // Delete
    void deleteAsset(AssetKeyListDto assetKeyList);

    void softDeleteAsset(String contentId, String vcCpId, String countryCode);
}
