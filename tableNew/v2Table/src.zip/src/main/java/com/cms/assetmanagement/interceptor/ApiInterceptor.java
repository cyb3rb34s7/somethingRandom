package com.cms.assetmanagement.interceptor;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.LoggingDto;
import com.cms.assetmanagement.model.LoggingDto.LoggingDtoBuilder;
import com.google.gson.Gson;
import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Instant;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;
import org.springframework.web.util.WebUtils;

@Component
@Slf4j
public class ApiInterceptor implements HandlerInterceptor {

    private static final String TRANSACTION_ID = "TXN_ID";
    private static final String START_TIME = "START_TIME";
    private static final String END_TIME = "END_TIME";
    private final Gson gsonObject = new Gson();
    @Value("${logging.api.header.enabled:#{true}}")
    private boolean isHeaderLoggingEnabled;
    @Value("${logging.api.body.enabled:#{true}}")
    private boolean isBodyLoggingEnabled;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
        Object handler) {
        request.setAttribute(TRANSACTION_ID, UUID.randomUUID().toString());
        request.setAttribute(START_TIME, Instant.now());
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response,
        Object handler, ModelAndView modelAndView) {

        request.setAttribute(END_TIME, Instant.now());
        var wrappedRequest = new ContentCachingRequestWrapper(request);
        var wrapperResponse = new ContentCachingResponseWrapper(response);
        String logContent = getLogContent(wrappedRequest, wrapperResponse);
        log.info(logContent);

    }

    private boolean isIncludeHeaders() {
        return isHeaderLoggingEnabled;
    }

    private boolean isIncludePayload() {
        return isBodyLoggingEnabled;
    }

    private int getMaxPayloadLength() {
        return Constants.REQ_BODY_MAX_SIZE;
    }

    private String getLogContent(HttpServletRequest request, HttpServletResponse response) {
        LoggingDtoBuilder logBuilder = LoggingDto.builder();
        logBuilder.method(request.getMethod())
            .url(request.getRequestURI().replaceAll("[\n|\t]", "_"))
            .transactionId(request.getAttribute(TRANSACTION_ID).toString())
            .startTime(request.getAttribute(START_TIME).toString())
            .endTime(request.getAttribute(END_TIME).toString())
            .method(request.getMethod())
            .responseCode(String.valueOf(response.getStatus()));

        var queryString = request.getQueryString();
        if (queryString != null) {
            logBuilder.params(request.getQueryString());
        }

        if (isIncludeHeaders()) {
            HttpHeaders headers = new ServletServerHttpRequest(request).getHeaders();
            logBuilder.headers(headers);
        }

        if (isIncludePayload()) {
            String payload = getMessagePayload(request);
            if (StringUtils.isNotEmpty(payload)) {
                logBuilder.payload(payload);
            }
        }
        return gsonObject.toJson(logBuilder.build());
    }

    private String getMessagePayload(HttpServletRequest request) {
        ContentCachingRequestWrapper wrapper =
            WebUtils.getNativeRequest(request, ContentCachingRequestWrapper.class);
        if (wrapper != null) {
            byte[] buf = wrapper.getContentAsByteArray();
            if (buf.length > 0) {
                int length = Math.min(buf.length, getMaxPayloadLength());
                try {
                    return new String(buf, 0, length, wrapper.getCharacterEncoding());
                } catch (Exception ex) {
                    return "[unknown]";
                }
            }
        }
        return null;
    }

}
