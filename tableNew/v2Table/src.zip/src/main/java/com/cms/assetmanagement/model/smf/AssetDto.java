package com.cms.assetmanagement.model.smf;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetDto {

    @JsonProperty("identifier_id")
    private String identifierId;

    @JsonProperty("program_id")
    private String programId;

    @JsonProperty("playback_items")
    private List<AssetPlaybackDto> playbackItems;

    @JsonProperty("type")
    private String type;

    @JsonProperty("series_info")
    private AssetSeriesInfo seriesInfo;

    @JsonProperty("titles")
    private List<AssetTitleDto> titles;

    @JsonProperty("descriptions")
    private List<AssetDescriptionDto> descriptions;

    @JsonProperty("images")
    private List<AssetImageDto> images;

    @JsonProperty("parental_ratings")
    private List<AssetParentalRatingDto> parentalRatings;

    @JsonProperty("genres")
    private List<String> genres;

    @JsonProperty("release_date")
    private String releaseDate;

    @JsonProperty("running_time")
    private int runningTime;

    @JsonProperty("casts")
    private List<AssetCastDto> casts;

    @JsonProperty("promotion_score")
    private int promoScore;

    @JsonProperty("external_ids")
    private List<SmfExternalIdDto> externalIds;

    @JsonProperty("logo")
    private String logo;

    @JsonProperty("scenepreview_webvtt")
    private String screenPreview;

    @JsonProperty("service_id")
    private String serviceId;

    @JsonProperty("content_partner")
    private String contentPartner;

    @JsonProperty("ad_breaks")
    private List<AssetAdBreakDto> adBreaks;

    @JsonProperty("asset_id")
    private String assetId;

    @JsonProperty("content_tier")
    private String contentTier;

    @JsonProperty("chapter_time")
    private String chapterTime;

    @JsonProperty("chapter_description")
    private String chapterDescription;

    private AssetCountryCpLangDto countryCpLangMap;

    private String requestType;
}
