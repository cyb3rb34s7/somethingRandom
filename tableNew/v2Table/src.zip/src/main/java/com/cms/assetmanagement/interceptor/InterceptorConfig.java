package com.cms.assetmanagement.interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    private final ApiInterceptor apiInterceptor;

    public InterceptorConfig(ApiInterceptor apiInterceptor) {
        this.apiInterceptor = apiInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(apiInterceptor)
            .addPathPatterns("/cms/tvplus/asset/sync/insert", "/cms/tvplus/asset/sync/update",
                "/cms/tvplus/asset/status", "/cms/tvplus/asset/delete");
    }
}
