package com.cms.assetmanagement.config;

import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Around("@annotation(LogExecutionTime)")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object proceed = joinPoint.proceed();
        long endTime = System.currentTimeMillis();

        Map<String, String> aopLogs = new HashMap<>();
        aopLogs.put("Method", joinPoint.getSignature().toString());
        aopLogs.put("StartTime", String.valueOf(startTime));
        aopLogs.put("EndTime", String.valueOf(endTime));
        aopLogs.put("Time Taken", String.valueOf(endTime - startTime));
        log.info("Performance Logging: {}", aopLogs);
        
        return proceed;
    }
}