package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.publicapi.QueryParamDto;
import java.util.List;

public interface VodAssetPublicService {

    List<VodAssetDto> getAssets(QueryParamDto queryParamDto);
}
