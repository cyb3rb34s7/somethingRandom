package com.cms.assetmanagement.exception;

public class CustomException extends RuntimeException {

    public CustomException(String message) {
        super(message);
    }
}
