package com.cms.assetmanagement.model;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExternalProviderDto {

    @Size(max = 125)
    private String externalProgramId;
    private String idType;
    private String idProvider;
    private String provider;
}
