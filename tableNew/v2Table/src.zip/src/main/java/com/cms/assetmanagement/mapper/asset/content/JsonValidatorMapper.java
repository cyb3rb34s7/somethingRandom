package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.filter.ContentKeyDto;
import com.cms.assetmanagement.model.filter.ContentProviderDto;
import com.cms.assetmanagement.model.filter.ParentalRatingsDto;
import java.sql.SQLException;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface JsonValidatorMapper {

    List<ContentProviderDto> getContentProviderList(List<String> feedWorkers) throws SQLException;

    List<ParentalRatingsDto> getParentalRatingsList() throws SQLException;

    List<ContentKeyDto> getContentIdDetail(@Param("assetId") String assetId,
        @Param("countryCode") String countryCode);

    ContentProviderDto getAssetDetailByContentId(String contentId, String countryCode);

    ContentProviderDto getAssetDetailByContentIdAndType(String contentId, String type,
        String countryCode);

    List<String> getValidLanguagesByCountryCode(String countryCode) throws SQLException;

    Integer countAssetByContentId(String contentId);

    String getTypeByContentId(String contentId);

    List<Boolean> getExternalIdDataByProviderAndTypeAndCountry(
        List<AssetExternalIdDto> assetExternalIdList);
}
