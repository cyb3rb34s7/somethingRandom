package com.cms.assetmanagement.model.evaluation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@AllArgsConstructor
@ToString(callSuper = true)
public class ComparisonDetailRequestDto {
    @NotNull
    private String programId;
    @NotNull
    private String cpId;
    @NotNull
    private String countryCode;
}
