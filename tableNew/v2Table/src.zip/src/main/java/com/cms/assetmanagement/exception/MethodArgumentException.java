package com.cms.assetmanagement.exception;


public class MethodArgumentException extends RuntimeException {

    public MethodArgumentException(String message) {
        super(message);
    }

}