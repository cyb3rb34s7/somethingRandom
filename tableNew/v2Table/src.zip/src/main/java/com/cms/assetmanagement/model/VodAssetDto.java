package com.cms.assetmanagement.model;

import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class VodAssetDto {

    @NotNull
    @Size(max = 125)
    private String contentId;
    @NotNull
    @Size(max = 2)
    private String countryCode;
    @Size(max = 20)
    private String type;
    @Size(max = 200)
    private String mainTitle;
    @Size(max = 200)
    private String shortTitle;
    @Max(value = 21600)
    private Integer runningTime;
    @Size(max = 200)
    private String genres;
    @Size(max = 1000)
    private String director;
    @Size(max = 1000)
    private String starring;
    @Size(max = 30)
    private String ratings;
    @Size(max = 4000)
    private String description;
    @Max(value = 99999)
    private Integer episodeNo;
    @Max(value = 99999)
    private Integer seasonNo;
    @Size(max = 125)
    private String seasonId;
    @Size(max = 2000)
    private String streamUri;
    @Size(max = 2000)
    private String imageLandscape;
    @Size(max = 30)
    private String expiryDate;
    @Size(max = 125)
    private String showId;
    @Size(max = 20)
    private String releaseDate;

    private Date regDate;

    private Date updateDate;
    @Size(max = 15)
    private String regrId;
    @Size(max = 15)
    private String crctrId;
    @Size(max = 2000)
    private String imagePortrait;
    @NotNull
    @Size(max = 50)
    private String vcCpId;
    @Size(max = 2000)
    private String imageCircle;
    @Size(max = 2000)
    private String webVttUrl;
    @Size(max = 2000)
    private String thumbnailUrl;
    @Size(max = 2000)
    private String audioLang;
    @Size(max = 2000)
    private String subtitleLang;
    @Size(max = 1000)
    private String deeplinkPayload;
    @Size(max = 2000)
    private String audioCode;
    @Size(max = 2000)
    private String subtitleCode;
    @Size(max = 10)
    private String quality;
    @Size(max = 50)
    private String vcSvcId;
    @Size(max = 400)
    private String deeplinkId;
    @Size(max = 100)
    private String fileName;
    @Size(max = 2)
    private String dataplusYn;
    @Size(max = 2000)
    private String nonAdStreamUri;
    @Size(max = 2000)
    private String imageLandscapeOriginal;
    @Size(max = 2000)
    private String imagePortraitOriginal;
    @Size(max = 2000)
    private String imageCircleOriginal;
    @Size(max = 2000)
    private String processedImageUrl;
    @Size(max = 1000)
    private String artist;
    @Size(max = 30)
    private String availableStarting;
    @Size(max = 200)
    private String contentPartner;
    @Size(max = 2000)
    private String imagePortraitIconic;
    @Size(max = 2000)
    private String imageLandscapeIconic;
    @Size(max = 2000)
    private String imagePortraitIconicOriginal;
    @Size(max = 2000)
    private String imageLandscapeIconicOriginal;
    @Size(max = 100)
    private String addedFrom;
    @Size(max = 100)
    private String identifierId;
    @Size(max = 100)
    private String contentTier;
    @Size(max = 100)
    private String chapterTime;
    @Size(max = 2000)
    private String chapterDescription;
    @Size(max = 100)
    private String assetId;
    @Size(max = 100)
    private String status;
    @Size(max = 2000)
    private String adTag;
    @Size(max = 10)
    private String platformTag;
    @Size(max = 100)
    private String qcPassReason;
    @Size(max = 30)
    private String feedWorker;
    private String cpName;
    private String tiName;
    private String licenseWindow;
    private String adBreak;
    private String drm;
    private String externalId;
    private String seriesDescription;
    private Integer isCmsProd;
    private Boolean isSyncBlocked;
    private Boolean isReleased;
    private List<ExternalProviderDto> externalProvider;
    private List<AdBreaksDto> adBreaks;
    private List<PlatformTagData> platformTagData;
    private List<AssetDrmDto> drmData;
    private List<ParentalRatingsDto> parentalRatings;
    private List<AssetCastDto> cast;
    private List<LicenseWindowDto> licenseWindowList;
    private List<EventWindowDto> eventWindowList;
    private List<AssetImageDto> assetImageList;
    private String showTitle;
    private String seasonTitle;
    private String imageLandscapeDimension;
    private String imagePortraitDimension;
    private String imageLandscapeIconicDimension;
    private String imagePortraitIconicDimension;
    private String license;
    private String language;
    private String mainTitleLanguage;
    private String shortTitleLanguage;
    @Size(max = 20)
    private String umdId;     // Added for Gracenote Content Table
    private String feedType;
    private String gracenoteAction;
    private String externalProgramId;
    private String externalIdProvider;

    private String onDeviceTrans;
    private String eventStarting;
    private String eventEnding;
    private String streamType;
    private String dbStatus;
    @Size(max = 30)
    private String totalAvailableStarting;
    @Size(max = 30)
    private String totalAvailableEnding;
    private String liveOnDevice;

    @Size(max = 2000)
    private String imageTitleTreatment;
    @Size(max = 2000)
    private String imageTitleTreatmentOriginal;
    private String imageTitleTreatmentDimension;
    @Size(max = 2000)
    private String imageLandscapeBackdrop;
    @Size(max = 2000)
    private String imageLandscapeBackdropOriginal;
    private String imageLandscapeBackdropDimension;

    private String eventYn;
    private String realLive;

    private List<AssetLockedFieldDto> lockedFields;

    // For Delta Sync
    private String isDelete;
    private String deltaType;
    private String ingestionType;
    private String attributes;
    private String subType;
    private String airType;
    private String team1;
    private String team2;
    private String geoRestrictionYn;
    private String matchInformation;
    private List<GeoRestrictionsDto> geoRestrictions;

    //For GVD vs ONAPI source
    private String externalSource;
    private Boolean isSynced;

    @JsonIgnore
    public String getCompositeKey() {
        return contentId + "|" + vcCpId + "|" + countryCode;
    }
}
