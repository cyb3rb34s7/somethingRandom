package com.cms.assetmanagement.model.filter;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssetFilterBodyDto {

    private List<FilterDto> filters;
    private List<String> columns;

    private List<SortDto> sortBy;
    private PaginationDto pagination;
}
