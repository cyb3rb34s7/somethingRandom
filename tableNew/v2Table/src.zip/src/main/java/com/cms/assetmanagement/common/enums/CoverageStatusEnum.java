package com.cms.assetmanagement.common.enums;

import lombok.Getter;

@Getter
public enum CoverageStatusEnum {
    COVERED("COVERED"),
    NON_COVERED("NONCOVERED");

    private final String value;

    CoverageStatusEnum(String value) {
        this.value = value;
    }
}
