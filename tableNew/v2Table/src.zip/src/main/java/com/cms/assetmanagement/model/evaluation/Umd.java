package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Umd {
    private String contentId;
    private String countryCode;
    private String umdId;
    private String programType;
    private Integer episodeNo;
    private Integer seasonNo;
    private String genres;
    private String releaseDate;
    private String mainTitle;
    private String shortTitle;
    private String starring;
    private String director;
    private String description;
    private String imgBannerLandscape;
    private String imgBannerPortrait;
    private String imgIconicLandscape;
    private String imgIconicPortrait;
    private String imgBannerLandscapeWH;
    private String imgBannerPortraitWH;
    private String imgIconicLandscapeWH;
    private String imgIconicPortraitWH;
}
