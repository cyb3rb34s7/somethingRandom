package com.cms.assetmanagement.common.window_util.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class EventWindowDto implements DateRangeWindow {

    @NotNull
    @JsonAlias({"eventId", "event_id"})
    private String eventId;

    @NotNull
    @JsonAlias({"eventStarting", "event_starting"})
    private String eventStarting;

    @NotNull
    @JsonAlias({"eventEnding", "event_ending"})
    private String eventEnding;

    private String identifierId;
    private String programId;
    private String providerId;
    private String countryCode;
    private String regrId;
    private String crctrId;
    private String feedWorker;

    @Override
    public String getWindowId() {
        return eventId;
    }

    @Override
    public String getStartingTime() {
        return eventStarting;
    }

    @Override
    public String getEndingTime() {
        return eventEnding;
    }

    @Override
    public WindowType getWindowType() {
        return WindowType.EVENT_WINDOW;
    }

    @Override
    public void setWindowId(String id) {
        eventId = id;
    }

    @Override
    public void setStartingTime(String startingTime) {
        eventStarting = startingTime;
    }

    @Override
    public void setEndingTime(String endingTime) {
        eventEnding = endingTime;
    }
}
