package com.cms.assetmanagement.model.devconsole;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class TiDto {

    private String vcCpId;
    private String countryCode;
    private String cpName;
    private String bucketName;
    private String bucketKey;
    private Boolean isSvc;
    private String serviceUrl;
    private String feedWorker;
}
