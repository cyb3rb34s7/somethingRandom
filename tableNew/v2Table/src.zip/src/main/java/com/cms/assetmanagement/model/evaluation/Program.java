package com.cms.assetmanagement.model.evaluation;

import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Program {

    private List<Title> titles;
    private List<Desc> descriptions;
    private List<Member> casts;
    private String programType;
    private String subType;
    private List<String> countries;
    private List<String> genres;
    private List<Rating> ratings;
    private String originalAirDate;
    private String colorCode;
    private EpisodeInfo episodeInfo;
    private List<Asset> assets;
    private List<Release> releases;
    private String originalAudioLanguage;
    // audioOriginalLangs, sourceType, originalNetwork 생략
    private String duration;
}
