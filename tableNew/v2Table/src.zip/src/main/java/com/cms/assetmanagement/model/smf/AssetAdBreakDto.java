package com.cms.assetmanagement.model.smf;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetAdBreakDto {
    @JsonProperty("mark_in")
    private String markIn;

    @JsonProperty("mark_out")
    private String markOut;

    @JsonProperty("duration")
    private String duration;

    @JsonProperty("order")
    private Integer order;

    @JsonProperty("insert_ad_markers")
    private boolean insertAdMarkers;

    @JsonProperty("ad_break_duration_seconds")
    private Double adBreakDurationSeconds;
}
