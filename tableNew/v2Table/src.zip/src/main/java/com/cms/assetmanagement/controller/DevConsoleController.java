package com.cms.assetmanagement.controller;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.DevConsoleConstants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.config.LogExecutionTime;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.devconsole.TiFeedworkerUpdateDto;
import com.cms.assetmanagement.model.devconsole.TiRequestDto;
import com.cms.assetmanagement.service.DevConsoleService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cms/tvplus/dev")
@Validated
@Slf4j
public class DevConsoleController {

    private final DevConsoleService devConsoleService;

    @Autowired
    public DevConsoleController(DevConsoleService devConsoleService) {
        this.devConsoleService = devConsoleService;
    }

    @LogExecutionTime
    @PostMapping("/getTiData")
    public ResponseDto getTiData(@NotNull @Valid @RequestBody TiRequestDto tiRequestDto) {
        log.info("Got request to get Ti data");
        return ResponseHandler.processMethodResponse(DevConsoleConstants.TECH_INTEGRATOR,
            devConsoleService.getTiData(tiRequestDto));
    }

    @LogExecutionTime
    @PostMapping("/updateTiFeedworker")
    public ResponseDto updateTiFeedworker(
        @NotNull @Valid @RequestBody TiFeedworkerUpdateDto tiFeedworkerUpdateDto) {
        log.info("Got request to update Ti Feedworker");
        devConsoleService.updateTiFeedworker(tiFeedworkerUpdateDto);
        return ResponseHandler.processMethodResponse(Constants.MESSAGE,
            "Successfully updated feedworker data for the given Tech Integrator.");
    }

}
