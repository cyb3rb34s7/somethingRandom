package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Generated
public class AlertRequestDto {

    private String sourceService;
    private String region;
    private String errorMessage;
    private String errorType;
    private String resourceType;
    private String errorCode;
    private String env;
}