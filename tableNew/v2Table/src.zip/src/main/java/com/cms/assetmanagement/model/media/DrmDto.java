package com.cms.assetmanagement.model.media;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DrmDto {

    @Size(max = 20)
    @JsonProperty("type")
    private String type;
    @Size(max = 2000)
    @JsonProperty("license_url")
    private String licenseUrl;
    @Size(max = 200)
    @JsonProperty("custom_header_name")
    private String customHeaderName;
    @Size(max = 4000)
    @JsonProperty("custom_header_value")
    private String customHeaderValue;
}
