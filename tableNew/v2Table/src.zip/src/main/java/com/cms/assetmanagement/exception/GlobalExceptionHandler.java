package com.cms.assetmanagement.exception;

import com.cms.assetmanagement.common.util.ErrorMessageUtil;
import com.cms.assetmanagement.common.util.NotificationUtil;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private final NotificationUtil notificationUtil;

    public GlobalExceptionHandler(NotificationUtil notificationUtil) {
        this.notificationUtil = notificationUtil;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleMethodArgumentNotValidException(
        MethodArgumentNotValidException ex) {

        var sb = new StringBuilder();

        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            sb.append(fieldName).append(": ").append(errorMessage).append(", ");
        });

        var errorMessage = sb.toString();
        log.error("MethodArgumentNotValidException: {}", errorMessage);
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return generateErrorResponse(new InvalidInputDataException(errorMessage));
    }

    @ExceptionHandler(JsonSchemaValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) //400
    public ResponseDto handleJsonSchemaValidationException(Exception ex) {
        log.error("JsonSchemaValidationException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return ResponseHandler.processMethodResponse(ex);
    }

    @ExceptionHandler({ConstraintViolationException.class,
        MethodArgumentTypeMismatchException.class, InvalidInputDataException.class,
        DataIntegrityViolationException.class}
    )
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleConstraintViolationException(
        Exception ex) {
        log.error("ConstraintViolationException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(DataNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND) // 404
    public ResponseDto handleDataNotFoundException(DataNotFoundException ex) {
        log.error("DataNotFoundException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    public ResponseDto handleHttpRequestMethodNotSupportedException(
        HttpRequestMethodNotSupportedException ex) {
        log.error("HttpRequestMethodNotSupportedException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseDto handleMissingServletRequestParameterException(
        MissingServletRequestParameterException ex) {
        log.error("MissingServletRequestParameterException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, HttpStatus.BAD_REQUEST.name(),
            String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(SQLException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 500
    public ResponseDto handleSQLException(SQLException ex) {
        log.error("SQLException: {}", ErrorMessageUtil.generateErrMessage(ex));
        notificationUtil.sendAlarm(ex, HttpStatus.INTERNAL_SERVER_ERROR.name(),
            String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));

        return generateErrorResponse(ex);
    }

    @ExceptionHandler({CustomException.class, Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseDto handleGeneralException(Exception ex) {
        log.error("General Exception: {}", ErrorMessageUtil.generateErrMessage(ex));
        notificationUtil.sendAlarm(ex, HttpStatus.INTERNAL_SERVER_ERROR.name(),
            String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        log.info("Alarm sent to Almansy");
        return generateErrorResponse(ex);
    }


    private ResponseDto generateErrorResponse(Exception ex) {
        return ResponseHandler.processMethodResponse(ex);
    }

}
