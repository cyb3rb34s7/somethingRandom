package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.exception.CustomException;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetSeriesInfoDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.DeeplinkPayloadDto;
import com.cms.assetmanagement.model.FeedWorkerPriority;
import com.cms.assetmanagement.model.PlatformTagData;
import com.cms.assetmanagement.model.RatingsDeeplinkDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetUpdateDto;
import com.cms.assetmanagement.service.AssetInsertHelper;
import com.cms.assetmanagement.service.VodAssetUpdateService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class VodAssetUpdateServiceImpl implements VodAssetUpdateService {

    private final VodAssetMapper vodAssetMapper;
    private final DateRangeWindowService dateRangeWindowService;
    private final AssetInsertHelper assetInsertHelper;
    private final VodAssetColumnLockMapper vodAssetColumnLockMapper;
    private final Utils utils;

    @Value("${CMS_FEED_WORKERS}")
    public String cmsFeedWorkers;

    @Value("${EXTERNAL_FEED_WORKERS}")
    public String externalFeedWorkers;

    @Value("${REGION}")
    public String region;

    List<FeedWorkerPriority> feedWorkerOrder = new ArrayList<>();
    List<String> feedWorkerList = new ArrayList<>();
    List<String> extFeedWorkersList = new ArrayList<>();
    ObjectMapper objectMapper = new ObjectMapper();

    //    @Autowired
    public VodAssetUpdateServiceImpl(VodAssetMapper vodAssetMapper,
        DateRangeWindowService dateRangeWindowService, AssetInsertHelper assetInsertHelper,
        VodAssetColumnLockMapper vodAssetColumnLockMapper, Utils utils) {
        this.vodAssetMapper = vodAssetMapper;
        this.dateRangeWindowService = dateRangeWindowService;
        this.assetInsertHelper = assetInsertHelper;
        this.vodAssetColumnLockMapper = vodAssetColumnLockMapper;
        this.utils = utils;
    }

    @PostConstruct
    public void init() {
        feedWorkerList = Arrays.asList(cmsFeedWorkers.split(","));
        extFeedWorkersList = Arrays.asList(externalFeedWorkers.split(","));

        var order = 1;
        for (String worker : feedWorkerList) {
            FeedWorkerPriority priority = FeedWorkerPriority.builder().feedWorker(worker)
                .priority(order++).build();
            feedWorkerOrder.add(priority);
        }
    }

    /**
     * ////////////////// Update Methods ///////////////
     */
    @Override
    @Transactional("contentTransactionManager")
    public void updateAsset(VodAssetDto vodAssetDto) throws JsonProcessingException {
        log.info("Updating Asset: {}", vodAssetDto.getContentId());
        vodAssetMapper.updateAsset(vodAssetDto);
        updateContentAssetUtils(vodAssetDto);
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateCPAsset(VodAssetDto vodAssetDto) {
        if (!utils.isTvplusDeltaFeedWorker(vodAssetDto)) {
            log.info("Updating CP Asset: {}", vodAssetDto.getContentId());
            vodAssetMapper.updateCPAsset(vodAssetDto);
            updateCPWindows(vodAssetDto);
        } else {
            log.info("Not updating CP Asset: {} because feedWorker is not CMS or CMS_GRACENOTE",
                vodAssetDto.getContentId());
        }
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateVodAsset(VodAssetUpdateDto vodAssetUpdateDto) throws JsonProcessingException {
        // Updating STD_VC_VOD_CONTENT Table
        log.info("Updating Content table for Asset: {}",
            vodAssetUpdateDto.getVodAsset().getContentId());
        vodAssetMapper.updateAsset(vodAssetUpdateDto.getVodAsset());
        updateContentAssetUtils(vodAssetUpdateDto.getVodAsset());

        // Updating STD_CMS_VOD_CP_CONTENT Table for CP
        if (!utils.isTvplusDeltaFeedWorker(vodAssetUpdateDto.getVodCpAsset())) {
            log.info("Updating CP Table for Asset: {}",
                vodAssetUpdateDto.getVodCpAsset().getContentId());
            vodAssetMapper.updateCPAsset(vodAssetUpdateDto.getVodCpAsset());
            updateCPWindows(vodAssetUpdateDto.getVodCpAsset());
        } else {
            log.info(
                "Not updating CP Table for Asset: {} because feedWorker is not CMS or CMS_GRACENOTE",
                vodAssetUpdateDto.getVodCpAsset().getContentId());
        }
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateAssetStatus(AssetStatusUpdateDto updatedStatus) {
        if (updatedStatus.getAssetList() != null && !updatedStatus.getAssetList().isEmpty()) {
            log.info("Updating Asset Status: {} for {} assets", updatedStatus.getStatus(),
                updatedStatus.getAssetList().size());
            vodAssetMapper.updateAssetStatus(updatedStatus);
            if (Constants.REVOKED.equalsIgnoreCase(updatedStatus.getStatus())) {
                // Find Seasons to Revoke
                List<AssetKeyDto> seasonsToRevoke = findSeasonsToRevoke(
                    updatedStatus.getAssetList());
                seasonsToRevoke = filterUniqueAssets(updatedStatus.getAssetList(), seasonsToRevoke);
                log.info("Updating Parent Seasons with 0 children. Status:{}",
                    updatedStatus.getStatus());
                updatedStatus.getAssetList().addAll(seasonsToRevoke);
                vodAssetMapper.updateAssetStatus(updatedStatus);

                // Find Shows to Revoke
                List<AssetKeyDto> showsToRevoke = findShowsToRevoke(updatedStatus.getAssetList());
                showsToRevoke = filterUniqueAssets(updatedStatus.getAssetList(), showsToRevoke);
                log.info("Updating Parent Shows with 0 children. Status:{} for {} assets",
                    updatedStatus.getStatus(), updatedStatus.getAssetList().size());
                updatedStatus.getAssetList().addAll(showsToRevoke);
                vodAssetMapper.updateAssetStatus(updatedStatus);
            }
            log.info("Updating Asset Last Status");
            assetInsertHelper.deleteAndInsertLastStatusData(updatedStatus.getAssetList());
        }
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateAssetByBulk(@Valid AssetUpdateByBulkDto assetUpdateByBulkDto)
        throws JsonProcessingException {
        log.info("Updating Assets By Bulk: {}", assetUpdateByBulkDto.getContentIds());
        vodAssetMapper.updateAssetByBulk(assetUpdateByBulkDto);

        for (String contentId : assetUpdateByBulkDto.getContentIds()) {
            assetUpdateByBulkDto.getVodAssetDto().setContentId(contentId);
            if (Constants.EPISODE.equalsIgnoreCase(
                assetUpdateByBulkDto.getVodAssetDto().getType())) {
                this.updateParentDeeplinkPayload(assetUpdateByBulkDto.getVodAssetDto());
            }
        }

        List<PlatformTagData> platformTagList = new ArrayList<>();
        assetUpdateByBulkDto.getContentIds().forEach(contentId -> {
            if (assetUpdateByBulkDto.getVodAssetDto().getPlatformTagData() != null
                && !assetUpdateByBulkDto.getVodAssetDto().getPlatformTagData()
                .isEmpty()) {
                log.info("Updating platform Tag Data for contentId: {}", contentId);
                assetUpdateByBulkDto.getVodAssetDto().getPlatformTagData()
                    .forEach(platformTagData -> {
                        platformTagData.setContentId(contentId);
                        platformTagData.setCountryCode(
                            assetUpdateByBulkDto.getVodAssetDto().getCountryCode());
                        platformTagData.setVcCpId(
                            assetUpdateByBulkDto.getVodAssetDto().getVcCpId());
                        platformTagList.add(platformTagData);
                    });
                vodAssetMapper.updatePlatformData(platformTagList);
                vodAssetMapper.deletePlatformDataByKeys(assetUpdateByBulkDto.getVodAssetDto());
            }
        });
    }

    @Override
    @Transactional("contentTransactionManager")
    public void bulkUpdateAssets(List<VodAssetDto> updatedAssets) throws JsonProcessingException {
        log.info("Updating bulkUpdateAssets: {}", updatedAssets.stream().toString());
        for (var asset : updatedAssets) {
            if (asset != null) {
                vodAssetMapper.updateAsset(asset);
                if (!utils.isTvplusDeltaFeedWorker(asset)) {
                    vodAssetMapper.updateCPAsset(asset);
                    updateCPWindows(asset);
                }
                VodAssetDto parentDetails = vodAssetMapper.getAssetParentDetails(asset);
                if (parentDetails != null) {
                    if (Constants.EPISODE.equalsIgnoreCase(parentDetails.getType())) {
                        parentDetails.setRatings(asset.getRatings());
                        this.updateParentDeeplinkPayload(parentDetails);
                    }

                    List<AssetKeyDto> assetKeyList = utils.createAssetList(asset);

                    assetInsertHelper.deleteAndInsertRatingData(assetKeyList,
                        asset.getParentalRatings());

                    assetInsertHelper.deleteAndInsertCastData(assetKeyList, asset.getCast());

                    assetInsertHelper.deleteAndInsertLicenseWindowData(assetKeyList,
                        asset.getLicenseWindowList());
                    dateRangeWindowService.findAndUpdateLicenseActiveSlot(asset.getContentId(),
                        asset.getCountryCode(),
                        asset.getVcCpId(), asset.getLicenseWindowList());

                    assetInsertHelper.deleteAndInsertEventWindowData(assetKeyList,
                        asset.getEventWindowList());
                    dateRangeWindowService.findAndUpdateEventActiveSlot(asset.getContentId(),
                        asset.getCountryCode(),
                        asset.getVcCpId(), asset.getEventWindowList());
                }
            }
        }
    }

    /* //////////////// Insert Methods ///////////////// */

    @Override
    @Transactional("contentTransactionManager")
    public void insertAsset(VodAssetDto vodAssetDto) throws JsonProcessingException {
        log.info("Inserting Asset: {}", vodAssetDto.getContentId());
        vodAssetMapper.insertAsset(vodAssetDto);
        if (Constants.EPISODE.equalsIgnoreCase(vodAssetDto.getType())) {
            this.updateParentDeeplinkPayload(vodAssetDto);
        }
    }

    @Override
    public void insertExternalIdData(List<AssetExternalIdDto> assetExternalIdList) {
        log.info("Inserting {} External Id Data", assetExternalIdList.size());
        vodAssetMapper.insertExternalIdData(assetExternalIdList);
    }

    @Override
    public void insertDRMData(List<AssetDrmDto> assetDrmList) {
        log.info("Inserting {} DRM Data", assetDrmList.size());
        vodAssetMapper.insertDRMData(assetDrmList);
    }

    @Override
    @Transactional("contentTransactionManager")
    public void insertAssetDetails(VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        log.info("Inserting Asset Details");
        deleteInsertAssetDetails(assetDetails);
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateAssetDetails(VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        log.info("Updating Asset Details");
        deleteInsertAssetDetails(assetDetails);
    }

    /**
     * //////////////// Delete Methods /////////////////
     */
    @Override
    @Transactional("contentTransactionManager")
    public void deleteAsset(AssetKeyListDto assetKeyList) {
        try {
            if (assetKeyList.getAssetList() != null && !assetKeyList.getAssetList().isEmpty()) {
                // Update Parent Deeplink Payload (if any)

                List<VodAssetDto> parentDetails = vodAssetMapper.getAssetByKey(
                    assetKeyList.getAssetList());
                deleteAssetByList(assetKeyList);
                updateParentDeeplinkPayloadRevoke(parentDetails);
            }
        } catch (Exception e) {
            log.error("Failed to delete assets/drm/externalIds for asset key list: {}",
                assetKeyList);
            log.error("Exception while deleting assets", e);
            throw new CustomException("Exception while deleting assets: " + e.getMessage());
        }
    }


    @Override
    @Transactional("contentTransactionManager")
    public void softDeleteAsset(String contentId, String vcCpId, String countryCode) {
        vodAssetMapper.softDeleteContentAsset(contentId, vcCpId, countryCode);
        vodAssetMapper.softDeleteFullFeedAsset(contentId, vcCpId, countryCode);
    }


    /* /////////////// Private Methods //////////////// */

    private void updateContentAssetUtils(VodAssetDto vodAssetDto) throws JsonProcessingException {

        VodAssetDto parentDetails = vodAssetMapper.getAssetParentDetails(vodAssetDto);

        if (parentDetails != null) {
            if (Constants.EPISODE.equalsIgnoreCase(parentDetails.getType())) {
                parentDetails.setRatings(vodAssetDto.getRatings());
                this.updateParentDeeplinkPayload(parentDetails);
            }

            List<AssetKeyDto> assetKeyList = utils.createAssetList(vodAssetDto);

            assetInsertHelper.deleteAndInsertGracenoteData(assetKeyList,
                vodAssetDto.getGracenoteAction());

            assetInsertHelper.deleteAndInsertPlatformTagData(assetKeyList,
                vodAssetDto.getPlatformTagData());

            assetInsertHelper.deleteAndInsertExternalIdData(assetKeyList,
                vodAssetDto.getExternalProvider());

            assetInsertHelper.deleteAndInsertRatingData(assetKeyList,
                vodAssetDto.getParentalRatings());

            assetInsertHelper.deleteAndInsertCastData(assetKeyList, vodAssetDto.getCast());

            assetInsertHelper.deleteAndInsertLicenseWindowData(assetKeyList,
                vodAssetDto.getLicenseWindowList());
            dateRangeWindowService.findAndUpdateLicenseActiveSlot(vodAssetDto.getContentId(),
                vodAssetDto.getCountryCode(), vodAssetDto.getVcCpId(),
                vodAssetDto.getLicenseWindowList());

            assetInsertHelper.deleteAndInsertEventWindowData(assetKeyList,
                vodAssetDto.getEventWindowList());
            dateRangeWindowService.findAndUpdateEventActiveSlot(vodAssetDto.getContentId(),
                vodAssetDto.getCountryCode(),
                vodAssetDto.getVcCpId(), vodAssetDto.getEventWindowList());

            assetInsertHelper.deleteAndInsertImageData(assetKeyList,
                vodAssetDto.getAssetImageList());

            assetInsertHelper.deleteAndInsertLockedColumnData(assetKeyList,
                vodAssetDto.getLockedFields());
        }
    }

    private void updateCPWindows(VodAssetDto vodAssetDto) {
        if (vodAssetDto != null) {
            dateRangeWindowService.findAndUpdateCPLicenseActiveSlot(vodAssetDto.getContentId(),
                vodAssetDto.getCountryCode(), vodAssetDto.getVcCpId(),
                vodAssetDto.getLicenseWindowList());

            dateRangeWindowService.findAndUpdateCPEventActiveSlot(vodAssetDto.getContentId(),
                vodAssetDto.getCountryCode(),
                vodAssetDto.getVcCpId(), vodAssetDto.getEventWindowList());

        }
    }

    private void deleteAssetByList(AssetKeyListDto assetKeyList) {
        try {
            log.info("Deleting {} Assets", assetKeyList.getAssetList().size());
            log.info("Deleting Asset");
            List<VodAssetDto> assets = vodAssetMapper.getAssetByKey(assetKeyList.getAssetList());
            vodAssetMapper.deleteAsset(assetKeyList.getAssetList());
            for (VodAssetDto asset : assets) {
                if (utils.isTvplusDeltaFeedWorker(asset)) {
                    log.info("Deleting Full Feed Asset");
                    vodAssetMapper.deleteFullFeedContent(assetKeyList.getAssetList());
                } else {
                    log.info("Deleting Cp Asset");
                    vodAssetMapper.deleteCpAsset(assetKeyList.getAssetList());
                }
            }

            log.info("Deleting DRM Data");
            vodAssetMapper.deleteDRMData(assetKeyList.getAssetList());
            log.info("Deleting External Id Data");
            vodAssetMapper.deleteExternalIdData(assetKeyList.getAssetList());
            log.info("Deleting Ad Breaks");
            vodAssetMapper.deleteAdBreaks(assetKeyList.getAssetList());
            log.info("Deleting Platforms");
            vodAssetMapper.deletePlatforms(assetKeyList.getAssetList());
            log.info("Deleting Ratings");
            vodAssetMapper.deleteRatingData(assetKeyList.getAssetList());
            log.info("Deleting Casts");
            vodAssetMapper.deleteCastData(assetKeyList.getAssetList());
            log.info("Deleting License Windows");
            vodAssetMapper.deleteLicenseWindowData(assetKeyList.getAssetList());
            log.info("Deleting Event Windows");
            vodAssetMapper.deleteEventWindowData(assetKeyList.getAssetList());
            log.info("Deleting Subtitles");
            vodAssetMapper.deleteSubtitles(assetKeyList.getAssetList());
            log.info("Deleting gracenote Map");
            vodAssetMapper.deleteGracenoteMapData(assetKeyList.getAssetList());
            log.info("Inserting batch delete history");
            vodAssetMapper.insertBatchDeleteHistory(assetKeyList.getAssetList());
        } catch (Exception e) {
            log.error("Exception while deleting assets by list", e);
            throw new CustomException(e.getMessage());
        }

    }

    private void deleteInsertAssetDetails(VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        List<AssetKeyDto> assetKeyList = utils.createAssetList(assetDetails.getVodAsset());

        vodAssetMapper.deleteAsset(assetKeyList);

        if (utils.isTvplusDeltaFeedWorker(assetDetails.getVodAsset())) {
            vodAssetMapper.deleteFullFeedContent(assetKeyList);
        } else {
            vodAssetMapper.deleteCpAsset(assetKeyList);
        }

        vodAssetMapper.deleteDRMData(assetKeyList);
        vodAssetMapper.deleteExternalIdData(assetKeyList);
        vodAssetMapper.deleteAdBreaks(assetKeyList);
        vodAssetMapper.deletePlatforms(assetKeyList);
        vodAssetMapper.deleteRatingData(assetKeyList);
        vodAssetMapper.deleteCastData(assetKeyList);
        vodAssetMapper.deleteLicenseWindowData(assetKeyList);
        vodAssetMapper.deleteEventWindowData(assetKeyList);
        vodAssetMapper.deleteSubtitles(assetKeyList);
        vodAssetMapper.deleteGeoRestrictions(assetKeyList);
        vodAssetMapper.deleteGracenoteMapData(assetKeyList);
        vodAssetColumnLockMapper.deleteColumnLockByContentId(assetKeyList);
        insertAssetDetailUtil(assetDetails);
    }

    private void insertAssetDetailUtil(VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        if (assetDetails.getVodAsset() != null) {
            vodAssetMapper.insertAsset(assetDetails.getVodAsset());
            if (Constants.EPISODE.equalsIgnoreCase(assetDetails.getVodAsset().getType())) {
                this.updateParentDeeplinkPayload(assetDetails.getVodAsset());
            } else if (Constants.SEASON.equalsIgnoreCase(assetDetails.getVodAsset().getType())
                || Constants.SHOW.equalsIgnoreCase(assetDetails.getVodAsset().getType())) {
                assetDetails.getVodAsset().setDeeplinkId(null);
            }
            log.info("Asset Inserted Successfully for ID {}",
                assetDetails.getVodAsset().getContentId());
        }

        if (assetDetails.getVodCpAsset() != null) {
            if (utils.isTvplusDeltaFeedWorker(assetDetails.getVodAsset())) {
                vodAssetMapper.insertFullFeedContent(assetDetails.getVodCpAsset());
                log.info("CP Asset Inserted in SMF_FULL_FEED table Successfully for ID {}",
                    assetDetails.getVodCpAsset().getContentId());
            } else {
                vodAssetMapper.insertCpAsset(assetDetails.getVodCpAsset());
                log.info("CP Asset Inserted  in VOD_CP_CONTENT table Successfully for ID {}",
                    assetDetails.getVodCpAsset().getContentId());
            }
        }

        assetInsertHelper.insertDrmData(assetDetails.getDrm());
        assetInsertHelper.insertExternalIdData(assetDetails.getExternalProvider());
        assetInsertHelper.insertAdBreakData(assetDetails.getAdBreak());
        assetInsertHelper.insertPlatformData(assetDetails.getPlatform());
        assetInsertHelper.insertRatingData(assetDetails.getRating());
        assetInsertHelper.insertCastData(assetDetails.getCast());
        assetInsertHelper.insertGracenoteMap(assetDetails.getGracenoteMaintainMap());
        assetInsertHelper.insertSubtitles(assetDetails.getSubtitles());
        assetInsertHelper.insertGeoRestrictions(assetDetails.getGeoRestrictions());
        assetInsertHelper.insertLockedColumnData(assetDetails.getLockedFields());

        // Insert License Window List and Update Main Table
        assetInsertHelper.insertLicenseWindowData(assetDetails.getLicenseWindowList());
        if (assetDetails.getVodAsset() != null) {
            this.dateRangeWindowService.findAndUpdateLicenseActiveSlot(
                assetDetails.getVodAsset().getContentId(),
                assetDetails.getVodAsset().getCountryCode(), assetDetails.getVodAsset().getVcCpId(),
                assetDetails.getLicenseWindowList());
        }

        // Insert Event Window List and Update Main Table
        assetInsertHelper.insertEventWindowData(assetDetails.getEventWindowList());
        if (assetDetails.getVodAsset() != null) {
            this.dateRangeWindowService.findAndUpdateEventActiveSlot(
                assetDetails.getVodAsset().getContentId(),
                assetDetails.getVodAsset().getCountryCode(), assetDetails.getVodAsset().getVcCpId(),
                assetDetails.getEventWindowList());
        }
    }

    private void updateParentDeeplinkPayload(VodAssetDto asset)
        throws JsonProcessingException {
        this.updateDeeplinkPayload(asset, Constants.SEASON);
        this.updateDeeplinkPayload(asset, Constants.SHOW);
    }

    private void updateParentDeeplinkPayloadRevoke(List<VodAssetDto> assetList)
        throws JsonProcessingException {
        if (assetList != null) {
            for (VodAssetDto asset : assetList) {
                if (asset != null && Constants.EPISODE.equalsIgnoreCase(asset.getType())) {
                    this.updateDeeplinkPayloadRevoke(asset, Constants.SEASON);
                    this.updateDeeplinkPayloadRevoke(asset, Constants.SHOW);
                    deleteParentAsset(asset);
                }
                if (asset != null && Constants.SEASON.equalsIgnoreCase(asset.getType())) {
                    deleteParentAsset(asset);
                }
            }
        }
    }

    private void updateDeeplinkPayloadRevoke(VodAssetDto asset, String type)
        throws JsonProcessingException {
        String parentId;
        String countryCode = asset.getCountryCode();
        if (Constants.SHOW.equals(type)) {
            parentId = asset.getShowId();
        } else {
            parentId = asset.getSeasonId();
        }
        RatingsDeeplinkDto ratingsDeeplinkIdDetails = vodAssetMapper.getRatingsDeeplinkIdDetails(
            parentId, asset.getCountryCode());
        boolean updateDeeplink = ratingsDeeplinkIdDetails == null ||
            ratingsDeeplinkIdDetails.getDeeplinkId() == null ||
            ratingsDeeplinkIdDetails.getDeeplinkId().equals(asset.getContentId());
        if (updateDeeplink) {
            String latestEpisodeId;
            if (Constants.SEASON.equals(type)) {
                latestEpisodeId = vodAssetMapper.getLatestEpisodeIdForSeason(parentId, countryCode);
            } else {
                latestEpisodeId = vodAssetMapper.getLatestEpisodeIdForShow(parentId, countryCode);

            }
            String deeplinkPayload = prepareDeeplinkPayload(asset.getShowId(), latestEpisodeId,
                asset.getRatings());
            VodAssetDto parentDeeplinkObj = VodAssetDto.builder().contentId(parentId)
                .deeplinkId(latestEpisodeId)
                .countryCode(asset.getCountryCode())
                .deeplinkPayload(deeplinkPayload)
                .vcCpId(asset.getVcCpId())
                .build();
            vodAssetMapper.updateParentDeeplinkDetails(parentDeeplinkObj);
            // Can update CP deeplink payload as it is non gracenote field and can be updated with every update GN or NON_GN
            vodAssetMapper.updateParentCPDeeplinkDetails(parentDeeplinkObj);
        }

    }

    private void updateDeeplinkPayload(VodAssetDto asset, String type)
        throws JsonProcessingException {
        String parentId = Constants.SHOW.equals(type) ? asset.getShowId() : asset.getSeasonId();

        RatingsDeeplinkDto ratingsDeeplinkIdDetails = vodAssetMapper.getRatingsDeeplinkIdDetails(
            parentId, asset.getCountryCode());
        boolean updateDeeplink = false;
        if (ratingsDeeplinkIdDetails == null || ratingsDeeplinkIdDetails.getDeeplinkId() == null) {
            updateDeeplink = true;
        } else {
            if (asset.getContentId().equals(ratingsDeeplinkIdDetails.getDeeplinkId())) {
                updateDeeplink = true;
            } else {
                AssetSeriesInfoDto previousSeasonEpisodeDetails = vodAssetMapper.getSeasonEpisodeNumberDetails(
                    ratingsDeeplinkIdDetails.getDeeplinkId(), asset.getCountryCode());
                if (previousSeasonEpisodeDetails == null ||
                    ((Constants.SHOW.equals(type) && checkForShowDeeplink(asset,
                        previousSeasonEpisodeDetails)) ||
                        (Constants.SEASON.equals(type) && checkForSeasonDeeplink(asset,
                            previousSeasonEpisodeDetails))
                    )) {
                    updateDeeplink = true;
                }
            }
        }

        if (updateDeeplink) {
            String deeplinkPayload = prepareDeeplinkPayload(asset.getShowId(), asset.getContentId(),
                asset.getRatings());
            VodAssetDto parentDeeplinkObj = VodAssetDto.builder().contentId(parentId)
                .deeplinkId(asset.getContentId())
                .countryCode(asset.getCountryCode())
                .deeplinkPayload(deeplinkPayload)
                .vcCpId(asset.getVcCpId())
                .build();
            vodAssetMapper.updateParentDeeplinkDetails(parentDeeplinkObj);
            // Can update CP deeplink payload as it is non gracenote field and can be updated with every update GN or NON_GN
            vodAssetMapper.updateParentCPDeeplinkDetails(parentDeeplinkObj);
        }

    }

    private boolean checkForSeasonDeeplink(VodAssetDto asset,
        AssetSeriesInfoDto previousSeasonEpisodeDetails) {
        return asset.getEpisodeNo() < previousSeasonEpisodeDetails.getEpisodeNo();
    }

    private boolean checkForShowDeeplink(VodAssetDto asset,
        AssetSeriesInfoDto previousSeasonEpisodeDetails) {
        return asset.getSeasonNo() < previousSeasonEpisodeDetails.getSeasonNo()
            || (asset.getSeasonNo() == previousSeasonEpisodeDetails.getSeasonNo()
            && asset.getEpisodeNo() < previousSeasonEpisodeDetails.getEpisodeNo());
    }

    private String prepareDeeplinkPayload(String parentId, String childId, String ratings)
        throws JsonProcessingException {
        return Constants.DEEPLINK_BODY_START + convertObjecttoString(
            DeeplinkPayloadDto.builder().contentType(Constants.DEEPLINK_CONTENT_TYPE)
                .contentId(childId)
                .seriesId(parentId)
                .ratings(ratings == null ? "" : ratings)
                .build()) + Constants.DEEPLINK_BODY_END;
    }

    private void deleteParentAsset(VodAssetDto asset) {
        try {
            var showId = asset.getShowId();
            var seasonId = asset.getSeasonId();
            if (Constants.EPISODE.equalsIgnoreCase(asset.getType()) && seasonId != null) {
                // If the show or season has no episodes left then delete it
                String latestEpisodeIdInSeason = vodAssetMapper.getLatestEpisodeIdForSeason(
                    seasonId, asset.getCountryCode());

                if (latestEpisodeIdInSeason == null) {
                    deleteAssetByList(AssetKeyListDto.builder().assetList(
                            List.of(AssetKeyDto.builder().countryCode(asset.getCountryCode())
                                .vcCpId(asset.getVcCpId()).contentId(seasonId)
                                .build()))
                        .build());
                }
            }
            if (showId != null) {
                // if show has no child then delete
                int numberOfShowChildren = vodAssetMapper.checkChildrenOfShow(showId,
                    asset.getCountryCode(), asset.getVcCpId());
                if (numberOfShowChildren == 0) {
                    deleteAssetByList(AssetKeyListDto.builder().assetList(
                            List.of(AssetKeyDto.builder().countryCode(asset.getCountryCode())
                                .vcCpId(asset.getVcCpId()).contentId(showId)
                                .build()))
                        .build());
                }
            }
        } catch (Exception e) {
            log.error("Exception while deleting parent assets", e);
            throw new CustomException(e.getMessage());
        }
    }

    private List<AssetKeyDto> findSeasonsToRevoke(List<AssetKeyDto> assetList) {
        Set<AssetKeyDto> seasonsToRevoke = new HashSet<>();
        for (AssetKeyDto asset : assetList) {
            if (asset != null && (Constants.EPISODE.equalsIgnoreCase(asset.getType()))) {
                try {
                    var seasonId = asset.getSeasonId();
                    var countryCode = asset.getCountryCode();
                    var vcCpId = asset.getVcCpId();
                    if (seasonId != null) {
                        int underQCChildrenOfSeason = vodAssetMapper.checkProdChildrenOfSeason(
                            seasonId, countryCode, vcCpId);
                        if (underQCChildrenOfSeason == 0) {
                            seasonsToRevoke.add(AssetKeyDto.builder()
                                .contentId(seasonId)
                                .vcCpId(vcCpId)
                                .countryCode(countryCode)
                                .lastAssetStatus(Constants.RELEASED)
                                .build());
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while finding seasons to revoke", e);
                    throw new CustomException(e.getMessage());
                }
            }
        }
        return new ArrayList<>(seasonsToRevoke);
    }

    private List<AssetKeyDto> findShowsToRevoke(List<AssetKeyDto> assetList) {
        Set<AssetKeyDto> showsToRevoke = new HashSet<>();
        for (AssetKeyDto asset : assetList) {
            if (asset != null && (Constants.EPISODE.equalsIgnoreCase(asset.getType()) ||
                Constants.SEASON.equalsIgnoreCase(asset.getType()))) {
                try {
                    var showId = asset.getShowId();
                    var countryCode = asset.getCountryCode();
                    var vcCpId = asset.getVcCpId();
                    if (showId != null) {
                        int underQCChildrenOfShow = vodAssetMapper.checkProdChildrenOfShow(
                            showId, countryCode, vcCpId);

                        if (underQCChildrenOfShow == 0) {
                            showsToRevoke.add(AssetKeyDto.builder()
                                .contentId(showId)
                                .vcCpId(vcCpId)
                                .countryCode(countryCode)
                                .lastAssetStatus(Constants.RELEASED)
                                .build());
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while finding shows to revoke", e);
                    throw new CustomException(e.getMessage());
                }
            }
        }
        return new ArrayList<>(showsToRevoke);
    }

    private List<AssetKeyDto> filterUniqueAssets(List<AssetKeyDto> existingAssets,
        List<AssetKeyDto> newAssets) {
        Set<String> existingIds = existingAssets.stream()
            .map(AssetKeyDto::getCompositeKey) // getKey() returns a composite unique identifier
            .collect(Collectors.toSet());

        return newAssets.stream()
            .filter(asset -> !existingIds.contains(asset.getCompositeKey())).toList();
    }

    private String convertObjecttoString(Object object) throws JsonProcessingException {
        return objectMapper.writeValueAsString(object);
    }
}
