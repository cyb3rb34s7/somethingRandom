package com.cms.assetmanagement.model.devconsole;

import com.cms.assetmanagement.model.filter.PaginationDto;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class TiRequestDto {

    @NotNull
    private String feedWorker;
    private PaginationDto pagination;
}
