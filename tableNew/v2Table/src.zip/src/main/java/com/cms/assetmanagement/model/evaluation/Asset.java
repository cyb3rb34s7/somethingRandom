package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Asset {
    private String assetId;
    private String lastModified;
    private String type;
    private String width;
    private String height;
    private Boolean primary;
    private String category;
    private String ratio;
    private String tier;
    private String uri;
}
