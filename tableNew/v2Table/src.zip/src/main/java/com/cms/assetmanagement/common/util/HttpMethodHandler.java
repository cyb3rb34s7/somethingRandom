package com.cms.assetmanagement.common.util;

import com.cms.assetmanagement.exception.CustomException;
import com.cms.assetmanagement.model.ResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class HttpMethodHandler {


    public static final String CALLING_THE_API_WITH_ENDPOINT_AND_METHOD = "Calling the API with endpoint: {} and method: {}";
    public static final String BAD_REQUEST_EXCEPTION_OCCURRED_WHILE_CALLING_THE_API = "Bad request Exception occurred while calling the API:{}";
    public static final String EXCEPTION_OCCURRED_AT_SERVER_SIDE_WHILE_CALLING_THE_API = "Exception occurred at server side while calling the API:{}";
    public static final String STATUS_CODE_EXCEPTION_OCCURRED_WHILE_CALLING_THE_API = "Status Code Exception occurred while calling the API:{}";
    public static final String EXCEPTION_OCCURRED_WHILE_CALLING_THE_EXTERNAL_API = "Exception occurred while calling the external API:{}";
    private final RestTemplate restTemplate;

    public HttpMethodHandler(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<ResponseDto> handleHttpExchange(String endPoint,
        String httpMethod,
        HttpEntity<?> httpEntity, Class<?> className) {
        try {
            log.info(CALLING_THE_API_WITH_ENDPOINT_AND_METHOD, endPoint, httpMethod);
            return (ResponseEntity<ResponseDto>) restTemplate.exchange(
                endPoint,
                HttpMethod.valueOf(httpMethod),
                httpEntity,
                className);

        } catch (Exception e) {
            this.handleException(e);
        }
        return null;
    }

    private void handleException(Exception e) {
        if (e instanceof HttpClientErrorException.BadRequest) {
            log.error(BAD_REQUEST_EXCEPTION_OCCURRED_WHILE_CALLING_THE_API, e.getMessage());
            throw new IllegalArgumentException(e);
        } else if (e instanceof HttpServerErrorException.InternalServerError) {
            log.error(EXCEPTION_OCCURRED_AT_SERVER_SIDE_WHILE_CALLING_THE_API, e.getMessage());
            throw new CustomException(e.getMessage());
        } else if (e instanceof HttpStatusCodeException) {
            log.error(STATUS_CODE_EXCEPTION_OCCURRED_WHILE_CALLING_THE_API, e.getMessage());
            throw new CustomException(e.getMessage());
        } else if (e instanceof RestClientException) {
            log.error(EXCEPTION_OCCURRED_WHILE_CALLING_THE_EXTERNAL_API, e.getMessage());
            throw new CustomException(e.getMessage());
        }
    }
}