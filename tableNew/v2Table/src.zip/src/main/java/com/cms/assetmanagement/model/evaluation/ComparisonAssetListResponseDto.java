package com.cms.assetmanagement.model.evaluation;

import lombok.*;

import java.util.List;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString(callSuper = true)
public class ComparisonAssetListResponseDto {
    private long totalCount;
    private long matchedCount;
    private long coveredCount;
    private List<ComparisonDto> data;
}
