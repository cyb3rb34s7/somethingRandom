package com.cms.assetmanagement.model.media;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MediaAssetDto {

    @JsonProperty("stream_url")
    private String streamUrl;

    @JsonProperty("ad_tags")
    private String adTags;

    @JsonProperty("ad_breaks")
    private List<AdBreaksDto> adBreaks;

    @JsonProperty("chapter_time")
    private String chapterTime;

    @JsonProperty("chapter_description")
    private String chapterDescription;

    @JsonProperty("quality")
    private String quality;

    @JsonProperty("audio_languages")
    private List<String> audioLanguages;

    @JsonProperty("subtitle_languages")
    private List<String> subtitleLanguages;

    @JsonProperty("drm")
    private List<DrmDto> drm;

    @JsonProperty("running_time")
    private Integer runningTime;

    @JsonProperty("scenepreview_webvtt")
    private String screenPreview;
}
