package com.cms.assetmanagement.model.filter;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class ParentalRatingsDto {

    private String cntyCd;
    private String type;
    private String organization;
    private String code;
}
