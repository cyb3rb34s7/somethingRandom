package com.cms.assetmanagement.common.util;

public class ErrorConstants {

    public static final String ERROR = "Error";
    public static final String ERROR_ATTRIBUTE_NAME = "error";
    public static final String ERROR_DATETIME = "error_datetime";
    public static final String ERROR_JSON_CONVERSION_TO_ASSET = "Json cannot be converted to SMF Asset Object";
    public static final String ERROR_AD_BREAK_CHECK = "Ad Break check failed for Asset";
    public static final String ERROR_PROVIDER_CHECK = "Content Provider and Country combination is not allowed";
    public static final String ERROR_DESCRIPTION_CHECK = "Description check failed for Asset";
    public static final String ERROR_PARENTAL_RATINGS_CHECK = "Parental Ratings check failed for Asset";
    public static final String ERROR_DUPLICATE_IMAGES_CHECK = "Duplicate Images present in Asset SMF";
    public static final String ERROR_DUPLICATE_ID_FROM_DIFFERENT_CP_CHECK = "Duplicate Id is present from Different CP";
    public static final String ERROR_ARTIST_INFO_CHECK = "Artist Info not present for asset in casts of SMF";
    public static final String ERROR_PLAYBACK_ITEMS_CHECK = "Playback Items check failed because available Start Date and available Ending Date are not in required format";
    public static final String ERROR_ARTIST_INFO_CHECK_CASTE_PRESENT_OR_NOT = "Either casts is null or cast list is empty";
    public static final String ERROR_COUNTRY_NOT_PRESENT_IN_DB = "Country provided doesn't exist in Country Lang Mapping of DB";
    public static final String PROGRAM_ID_NOT_PRESENT_IN_DB = "Program ID provided doesn't exist in DB";
    public static final String ERROR_LANG_NOT_PRESENT_IN_DB = "Language code mismatch with DB -> ";
    public static final String ERROR_COUNTRY_LANGCODE_MISSING = "Lang Code for the provided country is null in DB";
    public static final String ERROR_TYPE_INVALID = "Type provided for program ID is invalid";
    public static final String ERROR_TYPE_NOT_IN_LIST = "Type provided for the asset is invalid";
    public static final String ERROR_INVALID_PROVIDER_CNTY = "Provider or Country code is invalid for the Program Id";
    public static final String ERROR_OVERLAPPING_WINDOWS = "Window list contains overlapping windows";
    public static final String ERROR_INVALID_WINDOWS = "Either invalid date or Window list contains window where available start is greater than available ending";

    public static final String ERROR_TITLE_CHECK = "title_check_failed_for_asset";
    public static final String AUDIO_LANG_ERROR = "audio_lang_error";
    public static final String SUBTITLE_LANG_ERROR = "subtitle_lang_error";
    public static final String PROGRAM_ID_ERROR = "program_id_error";
    public static final String PROVIDER_COUNTRY_COMBO_ERROR = "provider_country_combo_error";
    public static final String TYPE_ERROR = "type_error";
    public static final String PROVIDER_COUNTRY_ERROR = "provider_country_error";
    public static final String STATUS_ERROR = "status_error";
    public static final String PARENT_SHOW_ERROR = "parent_show_error";
    public static final String PARENT_SHOW_TYPE_ERROR = "parent_showId_type_mismatch_error";
    public static final String PARENT_SEASON_ERROR = "parent_season_error";
    public static final String PARENT_SEASON_TYPE_ERROR = "parent_seasonId_type_mismatch_error";
    public static final String HIERARCHY_ERROR = "hierarchy_error";
    public static final String PLAYBACK_ITEMS_ERROR = "playback_items_error";
    public static final String INSUFFICIENT_INFO_ERROR = "insufficient_info_error";
    public static final String LICENSE_WINDOW_ERROR = "license_window_error";
    public static final String EVENT_WINDOW_ERROR = "event_window_error";
    public static final String ERROR_TITLE_NOT_PRESENT = "title_error";
    public static final String EXTERNAL_ID_ERROR = "external_id_error";


    public static final String ERROR_TITLE_LENGTH_EXCEED_TITLE_BYTE_LENGTH = "Title length exceeds ";
    public static final String ERROR_NO_MAIN_TITLE_FOUND = "Title's type was not 'main'";
    public static final String ERROR_LANGCODE_MATCH_FAIL = "LangCode Match Not Found";

    private ErrorConstants() {
        throw new IllegalStateException("Error Constants class, only static access");
    }
}
