package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.FeedWorkerPriority;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface VodAssetExportMapper {

    List<VodAssetDto> getAssetsForExport(
        @Param(Constants.FILTER_BDDY) AssetFilterBodyDto filterBody,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers,
        @Param(Constants.FEED_WORKER_PRIORITY) List<FeedWorkerPriority> feedWorkerOrder);

    long getExportAssetCount(
        @Param(Constants.FILTER_BDDY) AssetFilterBodyDto filterBody,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers,
        @Param(Constants.FEED_WORKER_PRIORITY) List<FeedWorkerPriority> feedWorkerOrder);
}
