package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EpisodeHierarchyDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetViewFilterDto;

public interface VodAssetViewService {

    VodAssetDto getAssetView(String contentId, String cpId, String countryCode);

    VodAssetDto getAssetCPView(String contentId, String cpId, String countryCode);

    VodAssetDto getAssetGracenoteView(String contentId, String cpId, String countryCode);

    VodAssetDto getAssetGracenoteOnView(String contentId, String cpId, String countryCode);

    AssetViewFilterDto getViewFilters(AssetKeyDto assetKeyDto);

    EpisodeHierarchyDto getViewEpisodeHierarchy(AssetKeyDto assetKeyDto);

}