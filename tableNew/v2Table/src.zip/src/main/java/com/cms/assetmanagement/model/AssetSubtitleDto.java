package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssetSubtitleDto {

    private String countryCode;
    private String providerId;
    private String programId;
    private String langCode;
    private String url;
    private String regDate;
    private String updateDate;
    private String regrId;
    private String crctrId;
    private String feedWorker;
}