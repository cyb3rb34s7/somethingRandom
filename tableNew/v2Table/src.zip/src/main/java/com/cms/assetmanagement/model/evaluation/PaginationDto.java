package com.cms.assetmanagement.model.evaluation;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PaginationDto {

    private int limit;
    private int offset;
}
