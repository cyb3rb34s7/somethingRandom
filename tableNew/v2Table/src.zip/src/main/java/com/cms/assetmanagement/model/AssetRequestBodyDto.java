package com.cms.assetmanagement.model;


import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssetRequestBodyDto {

    @Valid
    private VodAssetDto vodAssetDto;
    @Valid
    private AssetChangeHistoryDto assetChangeHistoryDto;
}
