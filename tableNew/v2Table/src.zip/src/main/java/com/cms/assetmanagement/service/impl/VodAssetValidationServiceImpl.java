package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ErrorConstants;
import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.ValidateWindowDto;
import com.cms.assetmanagement.service.VodAssetValidationService;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class VodAssetValidationServiceImpl implements VodAssetValidationService {

    private final VodAssetMapper vodAssetMapper;
    private final DateRangeWindowService dateRangeWindowService;

    //    @Autowired
    public VodAssetValidationServiceImpl(VodAssetMapper vodAssetMapper,
        DateRangeWindowService dateRangeWindowService) {
        this.vodAssetMapper = vodAssetMapper;
        this.dateRangeWindowService = dateRangeWindowService;
    }

    @Override
    public List<String> validateExternalId(List<AssetExternalIdDto> externalIdDtoList) {
        return vodAssetMapper.validateExternalId(externalIdDtoList);
    }
    
    @Override
    public boolean validateDeltaSync(String contentId, String countryCode, String vcCpId,
        String eventType) {
        return vodAssetMapper.validateDeltaSync(contentId, countryCode, vcCpId, eventType);
    }

    @Override
    public boolean validateAssetDetails(EditValidationDto editValidation) {
        if (editValidation != null) {
            String assetType = editValidation.getAssetType();
            if (Constants.EPISODE.equalsIgnoreCase(assetType)) {
                return vodAssetMapper.validateShow(editValidation) &&
                    vodAssetMapper.validateSeasonForEpisode(editValidation) &&
                    vodAssetMapper.validateEpisode(editValidation);
            } else if (Constants.SEASON.equalsIgnoreCase(assetType)) {
                return vodAssetMapper.validateShow(editValidation) &&
                    vodAssetMapper.validateSeasonNo(editValidation);

            }
        }
        return true;
    }


    @Override
    public boolean validateBulkQCPass(List<AssetKeyDto> assetList) {
        Set<AssetKeyDto> parentList = new HashSet<>();

        for (AssetKeyDto assetKeyDto : assetList) {
            String assetType = assetKeyDto.getType();
            if (Constants.EPISODE.equalsIgnoreCase(assetType)) {
                if (assetKeyDto.getShowId() == null || assetKeyDto.getSeasonId() == null) {
                    return false;
                }
                parentList.add(AssetKeyDto.builder().contentId(assetKeyDto.getSeasonId())
                    .vcCpId(assetKeyDto.getVcCpId()).countryCode(assetKeyDto.getCountryCode())
                    .build());                           // Season in parent
                parentList.add(AssetKeyDto.builder().contentId(assetKeyDto.getShowId())
                    .vcCpId(assetKeyDto.getVcCpId()).countryCode(assetKeyDto.getCountryCode())
                    .build());                           // Show in parent
            } else if (Constants.SEASON.equalsIgnoreCase(assetType)) {
                if (assetKeyDto.getShowId() == null) {
                    return false;
                }
                parentList.add(AssetKeyDto.builder().contentId(assetKeyDto.getShowId())
                    .vcCpId(assetKeyDto.getVcCpId()).countryCode(assetKeyDto.getCountryCode())
                    .build());                           // Show in parent
            }
        }

        List<AssetKeyDto> parents = new ArrayList<>(parentList);
        if (!parents.isEmpty()) {
            return parentList.size() == vodAssetMapper.getCountOfValidatedParents(parents);
        }
        return false;
    }

    @Override
    public <T extends DateRangeWindow> ValidateWindowDto validateDateRangeWindow(List<T> newList,
        String programId, String cpId, String countryCode, boolean shouldMerge) {
        if (newList == null || newList.isEmpty()) {
            return ValidateWindowDto.builder().isValid(true).build();
        }

        if (!vodAssetMapper.doesAssetExists(programId, cpId, countryCode)) {
            return ValidateWindowDto.builder()
                .isValid(false)
                .invalidReason("Asset does not exist").build();
        }

        List<String> duplicateLicenseIds = dateRangeWindowService.getDuplicateLicenseIds(newList);
        if (!duplicateLicenseIds.isEmpty()) {
            return ValidateWindowDto.builder().isValid(false)
                .invalidReason("Duplicate License ids are present: " + duplicateLicenseIds).build();
        }

        try {
            dateRangeWindowService.addTzToTimestamps(newList);
        } catch (Exception ex) {
            return ValidateWindowDto.builder()
                .isValid(false)
                .invalidReason("Invalid Date Error: " + ex.getMessage()).build();
        }

        if (!dateRangeWindowService.areWindowsValid(newList)) {
            return ValidateWindowDto.builder()
                .isValid(false)
                .invalidReason(ErrorConstants.ERROR_INVALID_WINDOWS).build();
        }

        List<T> listFromDb = dateRangeWindowService.getWindowListFromDb(programId, cpId,
            countryCode, shouldMerge, newList.get(0).getWindowType());
        List<T> mergedList = dateRangeWindowService.mergeWindows(newList, listFromDb);

        dateRangeWindowService.sortWindows(mergedList);

        if (dateRangeWindowService.areWindowsNonOverlapping(mergedList)) {
            return ValidateWindowDto.builder().isValid(true).build();
        } else {
            dateRangeWindowService.removeTzFromTimestamps(listFromDb);

            return ValidateWindowDto.builder()
                .isValid(false)
                .invalidReason(ErrorConstants.ERROR_OVERLAPPING_WINDOWS)
                .windowsInDb(listFromDb).build();
        }
    }

}
