package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class AssetLockedFieldDto {

    private String contentId;
    private String providerId;
    private String countryCode;
    private String fieldName;
    private String fieldType;
    private String lockedBy;
    private String tableName;
}