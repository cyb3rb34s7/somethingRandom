package com.cms.assetmanagement.model.media;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdBreaksDto {

    private String programId;
    private String countryCode;
    private String providerId;
    @JsonProperty("mark_in")
    private String markIn;
    @JsonProperty("mark_out")
    private String markOut;
    @JsonProperty("duration")
    private String duration;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("insert_ad_markers")
    private String insertAdMarkers;
    @JsonProperty("ad_break_duration_seconds")
    private Double adBreakDurationSeconds;
    private Date regDate;
    private Date updateDate;
}
