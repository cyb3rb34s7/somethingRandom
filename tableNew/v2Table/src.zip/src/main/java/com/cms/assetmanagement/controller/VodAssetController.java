package com.cms.assetmanagement.controller;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.config.LogExecutionTime;
import com.cms.assetmanagement.exception.CustomException;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetDrmReqDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetExternalIdReqDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.EventDeleteDto;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetUpdateDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.service.SchemaValidatorService;
import com.cms.assetmanagement.service.VodAssetService;
import com.cms.assetmanagement.service.VodAssetUpdateService;
import com.cms.assetmanagement.service.VodAssetValidationService;
import com.cms.assetmanagement.service.VodAssetViewService;
import com.cms.assetmanagement.service.VodAssetWindowService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.sql.SQLException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/cms/tvplus/asset")
@RestController
@Slf4j
@Validated
public class VodAssetController {

    private final VodAssetService vodAssetService;
    private final VodAssetUpdateService vodAssetUpdateService;
    private final VodAssetWindowService vodAssetWindowService;
    private final VodAssetViewService vodAssetViewService;
    private final VodAssetValidationService vodAssetValidationService;
    private final DateRangeWindowService dateRangeWindowService;
    private final SchemaValidatorService schemaValidatorService;
    private final ObjectMapper snakeCaseObjectMapper = new ObjectMapper();

    public VodAssetController(VodAssetService vodAssetService,
        VodAssetUpdateService vodAssetUpdateService,
        VodAssetWindowService vodAssetWindowService,
        VodAssetViewService vodAssetViewService,
        VodAssetValidationService vodAssetValidationService,
        DateRangeWindowService dateRangeWindowService,
        SchemaValidatorService schemaValidatorService) {
        this.vodAssetService = vodAssetService;
        this.vodAssetUpdateService = vodAssetUpdateService;
        this.vodAssetWindowService = vodAssetWindowService;
        this.vodAssetViewService = vodAssetViewService;
        this.vodAssetValidationService = vodAssetValidationService;
        this.dateRangeWindowService = dateRangeWindowService;
        this.schemaValidatorService = schemaValidatorService;
        snakeCaseObjectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    @LogExecutionTime
    @GetMapping("/healthcheck")
    public ResponseDto healthcheck() throws SQLException {
        log.info("Request received for heathcheck");
        try {
            vodAssetService.getOracleHealthcheck();
            log.info("healthCheck : Oracle Database Connected Successfully");
            ResponseHandler.processMethodResponse(Constants.SUCCESS,
                Constants.HEATHCHECK_SUCCESS);
        } catch (Exception e) {
            log.error("Exception in Asset-Management Healthcheck: {}", e.getMessage());
            throw new CustomException(e.getMessage());
        }
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.HEATHCHECK_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/list")
    public ResponseDto getFilteredAssetsList(
        @Valid @RequestBody AssetFilterBodyDto assetFilterBodyDto
    ) {
        log.info("Request received for getting filtered assets list. Request body: {}",
            assetFilterBodyDto);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetService.getFilteredAssets(assetFilterBodyDto));
    }

    @LogExecutionTime
    @GetMapping("/view")
    public ResponseDto getAssetView(@RequestParam String contentId, @RequestParam String cpId,
        @RequestParam String countryCode) {
        log.info("Request received for asset view. Content Id: {}, CP Id: {}, Country Code: {}",
            contentId, cpId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetViewService.getAssetView(contentId, cpId, countryCode));
    }

    @LogExecutionTime
    @GetMapping("/view/cp")
    public ResponseDto getAssetCPView(@RequestParam String contentId, @RequestParam String cpId,
        @RequestParam String countryCode) {
        log.info("Request received for asset CP view. Content Id: {}, CP Id: {}, Country Code: {}",
            contentId, cpId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetViewService.getAssetCPView(contentId, cpId, countryCode));
    }

    @LogExecutionTime
    @GetMapping("/view/gracenote")
    public ResponseDto getAssetGracenoteView(@RequestParam String contentId,
        @RequestParam String cpId, @RequestParam String countryCode) {
        log.info(
            "Request received for asset Gracenote view. Content Id: {}, CP Id: {}, Country Code: {}",
            contentId, cpId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetViewService.getAssetGracenoteView(contentId, cpId, countryCode));
    }

    @LogExecutionTime
    @GetMapping("/details")
    public ResponseDto getAssetDetails(@RequestParam String contentId, @RequestParam String cpId,
        @RequestParam String countryCode
    ) {
        log.info("Request received for asset details. Content Id: {}, CP Id: {}, Country Code: {}",
            contentId, cpId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            vodAssetService.getAssetDetails(contentId, cpId, countryCode));
    }

    @LogExecutionTime
    @PostMapping("/count")
    public ResponseDto getFilteredAssetsCount(
        @RequestBody AssetFilterBodyDto assetFilterBodyDto,
        @RequestParam String tab
    ) {
        log.info("Request received for total asset count. Request Body: {},",
            assetFilterBodyDto);
        return ResponseHandler.processMethodResponse(Constants.ASSET_COUNT,
            vodAssetService.getFilteredAssetsCount(assetFilterBodyDto, tab));
    }

    @LogExecutionTime
    @PostMapping("/export")
    public ResponseDto getAssetsForExport(
        @RequestBody AssetFilterBodyDto assetExportRequestDto) {
        log.info("Request received for exporting assets. Request Body: {},",
            assetExportRequestDto);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetService.getAssetsForExport(assetExportRequestDto));
    }

    @LogExecutionTime
    @PostMapping("/export/count")
    public ResponseDto getExportAssetCount(
        @RequestBody AssetFilterBodyDto assetExportRequestDto) {
        log.info("Request received for assets export count. Request Body: {},",
            assetExportRequestDto);
        return ResponseHandler.processMethodResponse(Constants.ASSET_COUNT,
            vodAssetService.getExportAssetCount(assetExportRequestDto));
    }

    @LogExecutionTime
    @PostMapping("/insert")
    public ResponseDto insertAsset(@Valid @RequestBody VodAssetDto asset)
        throws JsonProcessingException {
        log.info("Request received for inserting asset. Asset: {},", asset);
        vodAssetUpdateService.insertAsset(asset);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_INSERT_SUCCESS);

    }

    @LogExecutionTime
    @PostMapping("/sync/insert")
    public ResponseDto insertAssetDetails(@Valid @RequestBody VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        log.info("Request received for inserting asset details. Asset: {},", assetDetails);
        vodAssetUpdateService.insertAssetDetails(assetDetails);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_INSERT_SUCCESS);

    }

    @LogExecutionTime
    @PostMapping("/sync/update")
    public ResponseDto updateAssetDetails(@Valid @RequestBody VodAssetDetailedDto assetDetails)
        throws JsonProcessingException {
        log.info("Request received for updating asset details. Asset: {},", assetDetails);
        vodAssetUpdateService.updateAssetDetails(assetDetails);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_UPDATE_SUCCESS);

    }

    @LogExecutionTime
    @GetMapping("/countrycodes")
    public ResponseDto getCountryCodes() {
        log.info("Request received for countryCodes.");
        return ResponseHandler.processMethodResponse(Constants.COUNTRY,
            vodAssetService.getCountryCodes());
    }

    @LogExecutionTime
    @GetMapping("/filters")
    public ResponseDto getFilters() {
        log.info("Request received for filters.");
        return ResponseHandler.processMethodResponse(Constants.FILTERS,
            vodAssetService.getFilters());
    }

    @LogExecutionTime
    @PostMapping("/status")
    public ResponseDto updateAssetStatus(@Valid @RequestBody AssetStatusUpdateDto updatedStatus) {
        log.info("Request received for updating bulk status. status Body: {}", updatedStatus);
        vodAssetUpdateService.updateAssetStatus(updatedStatus);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.STATUS_UPDATE_SUCCESS);

    }

    @LogExecutionTime
    @PostMapping("/assetListDetailsforUpload")
    public ResponseDto getAssetListDetailsforUpload(
        @Valid @RequestBody AssetKeyListDto assetKeyList) {
        log.info("Request received for assetListForUploads. keyList:{}", assetKeyList);
        return ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            vodAssetService.getAssetListDetailsforUpload(assetKeyList));

    }

    @LogExecutionTime
    @PostMapping("/update")
    public ResponseDto updateAsset(@Valid @RequestBody VodAssetDto vodAssetDto)
        throws JsonProcessingException {
        log.info("Request received for updating asset. {}", vodAssetDto);
        vodAssetUpdateService.updateAsset(vodAssetDto);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_UPDATE_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/update/cp")
    public ResponseDto updateCPAsset(@Valid @RequestBody VodAssetDto vodAssetDto) {
        log.info("Request received for updating CP asset. {}", vodAssetDto);
        vodAssetUpdateService.updateCPAsset(vodAssetDto);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.CP_UPDATE_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/update/vod")
    public ResponseDto updateVodAsset(@Valid @RequestBody VodAssetUpdateDto vodAssetUpdateDto)
        throws JsonProcessingException {
        log.info("Request received for updating vod asset. {}", vodAssetUpdateDto);
        vodAssetUpdateService.updateVodAsset(vodAssetUpdateDto);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_UPDATE_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/delete")
    public ResponseDto deleteAsset(@Valid @RequestBody AssetKeyListDto assetKeyList) {
        log.info("Request received for deleting asset. keyList:{}", assetKeyList);
        vodAssetUpdateService.deleteAsset(assetKeyList);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_DELETE_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/softDelete")
    public ResponseDto softDeleteAsset(@RequestParam String contentId,
        @RequestParam String countryCode, @RequestParam String cpId) {
        log.info("Request received for soft deleting asset. contentId:{}", contentId);
        vodAssetUpdateService.softDeleteAsset(contentId, cpId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_DELETE_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/insert/externalIds")
    public ResponseDto insertExternalIdData(
        @RequestBody AssetExternalIdReqDto assetExternalIdList) {
        log.info("Request received for inserting ExternalId Data. {}", assetExternalIdList);
        vodAssetUpdateService.insertExternalIdData(assetExternalIdList.getAssetExternalIds());
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.EXTERNALID_INSERT_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/insert/drm")
    public ResponseDto insertDRMData(@RequestBody AssetDrmReqDto assetDrmList) {
        log.info("Request received for inserting DRM Data. {}", assetDrmList);
        vodAssetUpdateService.insertDRMData(assetDrmList.getAssetDrmList());
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.DRM_INSERT_SUCCESS);
    }

    @LogExecutionTime
    @PostMapping("/getShowHierarchy")
    public ResponseDto getShowHierarchy(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        log.info("Request received for show Hierarchy. {}", assetKeyDto);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetService.getShowHierarchy(assetKeyDto));
    }

    @LogExecutionTime
    @PostMapping("/updateAssetByBulk")
    public ResponseDto updateAssetByBulk(
        @Valid @RequestBody AssetUpdateByBulkDto assetUpdateByBulkDto)
        throws JsonProcessingException {
        log.info("Request received for bulk asset update. {}", assetUpdateByBulkDto);
        vodAssetUpdateService.updateAssetByBulk(assetUpdateByBulkDto);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSETS_UPDATED_SUCCESSFULLY);
    }

    @LogExecutionTime
    @PostMapping("/bulkUpdateAssets")
    public ResponseDto bulkUpdateAssets(@Valid @RequestBody List<VodAssetDto> updatedAssets)
        throws JsonProcessingException {
        log.info("Request received for bulkUpdateAssets. {}", updatedAssets);
        vodAssetUpdateService.bulkUpdateAssets(updatedAssets);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSETS_UPDATED_SUCCESSFULLY);
    }

    @LogExecutionTime
    @GetMapping("/languages")
    public ResponseDto getLanguages() {
        log.info("Request received for languages.");
        return ResponseHandler.processMethodResponse(Constants.LANGUAGES,
            vodAssetService.getLanguages());
    }

    @LogExecutionTime
    @GetMapping("/ratings")
    public ResponseDto getRatings() {
        log.info("Request received for getting ratings details.");
        return ResponseHandler.processMethodResponse(Constants.RATINGS,
            vodAssetService.getRatings());
    }

    @LogExecutionTime
    @GetMapping("/allRatings")
    public ResponseDto getAllRatings() {
        log.info("Request received for getting all rating details.");
        return ResponseHandler.processMethodResponse(Constants.RATINGS,
            vodAssetService.getAllRatings());
    }

    @LogExecutionTime
    @PostMapping("/validate")
    public ResponseDto validateJson(@RequestBody JsonNode jsonNode,
        @RequestParam("provider_id") String contentProvider,
        @RequestParam("country_code") String countryCode) throws SQLException {
        log.info("Validate Asset request received. {}", contentProvider);
        return ResponseHandler.processSuccess(schemaValidatorService.validateAsset(jsonNode,
            countryCode, contentProvider));
    }

    @LogExecutionTime
    @PostMapping("/validate-media")
    public ResponseDto validateMediaJson(@RequestBody JsonNode jsonNode,
        @RequestParam("provider_id") String contentProvider,
        @RequestParam("country_code") String countryCode,
        @RequestParam("program_id") String programId) throws SQLException {
        log.info("Validate Media request received. {}", contentProvider);
        return ResponseHandler.processSuccess(schemaValidatorService.validateMedia(jsonNode,
            countryCode, contentProvider, programId));
    }

    @LogExecutionTime
    @PostMapping("/view/filters")
    public ResponseDto getViewFilters(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        log.info("Request received for View Filters. {}", assetKeyDto);
        return ResponseHandler.processMethodResponse(Constants.FILTERS,
            vodAssetViewService.getViewFilters(assetKeyDto));
    }


    @LogExecutionTime
    @PostMapping("/view/episode/hierarchy")
    public ResponseDto getViewEpisodeHierarchy(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        log.info("Request received for getViewEpisodeHierarchy. {}", assetKeyDto);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetViewService.getViewEpisodeHierarchy(assetKeyDto));
    }

    @LogExecutionTime
    @PostMapping("/assetDetailsByColumn")
    public ResponseDto assetDetailsByColumn(@RequestBody AssetByColumnsReqDto columnsReqDto) {
        log.info("Request received for assetDetailsByColumn. {}", columnsReqDto);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetService.assetDetailsByColumns(columnsReqDto));
    }

    @LogExecutionTime
    @GetMapping("/validateProviderByCountry")
    public ResponseDto validateProviderByCountry(@RequestParam String countryCode,
        @RequestParam String cpId) throws SQLException {
        log.info("Request received for provider validation. country: {}, provider: {}",
            countryCode, cpId);
        return ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            schemaValidatorService.validateProviderAndCountry(countryCode, cpId));
    }

    @LogExecutionTime
    @GetMapping("/validateDeltaSync")
    public ResponseDto validateDeltaSync(@RequestParam String contentId,
        @RequestParam String countryCode,
        @RequestParam String cpId,
        @RequestParam String eventType) throws SQLException {
        log.info("Request received for Delta Sync validation. contentId: {}, Country: {}",
            contentId, countryCode);
        return ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            vodAssetValidationService.validateDeltaSync(contentId, countryCode, cpId, eventType));
    }


    @LogExecutionTime
    @PostMapping("/validateExternalId")
    public ResponseDto validateExternalId(@RequestBody List<AssetExternalIdDto> externalIdDtoList)
        throws SQLException {
        log.info("Validate ExternalId request received. {}", externalIdDtoList);
        return ResponseHandler.processMethodResponse(Constants.EXTERNAL_ID_STR,
            vodAssetValidationService.validateExternalId(externalIdDtoList));
    }

    @LogExecutionTime
    @PostMapping("/validateExternalIdPerIdType")
    public ResponseDto validateExternalIdPerIdType(
        @RequestBody List<AssetExternalIdDto> externalIdList) {
        log.info("Request to validate External ID Per ID-Type received. {}", externalIdList);
        return ResponseHandler.processMethodResponse(Constants.ID_TYPE_VALIDATION_STATUS,
            schemaValidatorService.validateExternalIdPerIdType(externalIdList));
    }

    @LogExecutionTime
    @PostMapping("/validateAssetDetails")
    public ResponseDto validateAssetDetails(@RequestBody EditValidationDto editValidation)
        throws SQLException {
        log.info("Edit Validation request received. {}", editValidation);
        return ResponseHandler.processMethodResponse(Constants.VALIDATION,
            vodAssetValidationService.validateAssetDetails(editValidation));
    }

    @LogExecutionTime
    @PostMapping("/bulkRevokeHierarchy")
    public ResponseDto bulkRevokeHierarchy(@Valid @RequestBody List<AssetKeyDto> assetsList) {
        log.info("Request received for bulk Revoke Hierarchy. list: {}", assetsList);
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetService.bulkRevokeHierarchy(assetsList));
    }

    @LogExecutionTime
    @PostMapping("/updateLicenseWindow")
    public ResponseDto updateLicenseWindow(
        @Valid @RequestBody List<LicenseWindowDto> licenseWindows,
        @NotNull @RequestParam String countryCode,
        @NotNull @RequestParam String programId,
        @RequestParam(required = false) String vcCpId) {
        log.info("Update license window request received. {}", licenseWindows);
        boolean activeSlotFound = dateRangeWindowService.findAndUpdateLicenseActiveSlot(programId,
            countryCode, vcCpId, licenseWindows);

        if (activeSlotFound) {
            return ResponseHandler.processMethodResponse(Constants.MESSAGE,
                Constants.WIN_UPDATE_SUCCESS);
        } else {
            return ResponseHandler.processMethodResponse(Constants.MESSAGE,
                Constants.WIN_UPDATE_FAIL);
        }
    }

    @LogExecutionTime
    @GetMapping("/getActiveWindow")
    public ResponseDto getActiveWindow(
        @Valid @NotEmpty @RequestBody List<LicenseWindowDto> licenseWindows) {
        log.info("Request get active window received. {}", licenseWindows);

        return ResponseHandler.processMethodResponse(Constants.ACTIVE_WINDOW,
            vodAssetService.getActiveWindow(licenseWindows));
    }

    @LogExecutionTime
    @PostMapping("/validateLicenseWindow")
    public ResponseDto validateLicenseWindow(
        @Valid @NotNull @RequestBody List<LicenseWindowDto> licenseWindows,
        @NotNull @RequestParam("country_code") String countryCode,
        @NotNull @RequestParam("program_id") String programId,
        @NotNull @RequestParam("provider_id") String cpId,
        @RequestParam(name = "should_merge", required = false, defaultValue = "true") boolean shouldMerge)
        throws JsonProcessingException {
        log.info("Request to validate license window received. {}", licenseWindows);

        JsonNode response = snakeCaseObjectMapper.convertValue(
            vodAssetValidationService.validateDateRangeWindow(licenseWindows, programId, cpId,
                countryCode, shouldMerge), JsonNode.class);

        return ResponseHandler.processMethodResponse(Constants.VALIDATION_RESULT, response);
    }

    @LogExecutionTime
    @PostMapping("/validateEventWindow")
    public ResponseDto validateEventWindow(
        @Valid @NotNull @RequestBody List<EventWindowDto> eventWindows,
        @NotNull @RequestParam("country_code") String countryCode,
        @NotNull @RequestParam("program_id") String programId,
        @NotNull @RequestParam("provider_id") String cpId,
        @RequestParam(name = "should_merge", required = false, defaultValue = "true") boolean shouldMerge)
        throws JsonProcessingException {
        log.info("Request to validate event window received. {}", eventWindows);

        JsonNode response = snakeCaseObjectMapper.convertValue(
            vodAssetValidationService.validateDateRangeWindow(eventWindows, programId, cpId,
                countryCode, shouldMerge), JsonNode.class);

        return ResponseHandler.processMethodResponse(Constants.VALIDATION_RESULT, response);
    }

    @LogExecutionTime
    @PostMapping("/importer/event/update")
    public ResponseDto updateEventWindows(
        @Valid @NotNull @RequestBody VodAssetDto vodAssetDto) {
        log.info("Request for updating Event windows from IMPORTER. {}", vodAssetDto);
        vodAssetWindowService.updateEventWindows(vodAssetDto);
        return ResponseHandler.processMethodResponse(Constants.MESSAGE,
            Constants.EVENT_WINDOWS_UPDATED_SUCCESSFUL);
    }

    @LogExecutionTime
    @PostMapping("/importer/license/update")
    public ResponseDto updateLicenseWindows(
        @Valid @NotNull @RequestBody VodAssetDto vodAssetDto) {
        log.info("Request for updating License windows from IMPORTER. {}", vodAssetDto);
        vodAssetWindowService.updateLicenseWindows(vodAssetDto);
        return ResponseHandler.processMethodResponse(Constants.MESSAGE,
            Constants.LICENSE_WINDOWS_UPDATED_SUCCESSFUL);
    }

    @LogExecutionTime
    @PostMapping("/importer/event/remove")
    public ResponseDto removeEventWindows(
        @Valid @NotNull @RequestBody EventDeleteDto eventDeleteDto) {
        log.info("Request for removing Event windows from IMPORTER. {}", eventDeleteDto);
        vodAssetWindowService.removeEventWindows(eventDeleteDto);
        return ResponseHandler.processMethodResponse(Constants.MESSAGE,
            Constants.EVENT_WINDOWS_DELETE_SUCCESSFUL);
    }

    @GetMapping("/view/streamUris")
    public ResponseDto getStreamUris(@RequestParam String contentId, @RequestParam String cpId,
        @RequestParam String countryCode) {
        log.info("Request received for Stream URLs for contentId: {}", contentId);
        return ResponseHandler.processMethodResponse(Constants.STREAM_URIS,
            vodAssetService.getStreamUris(contentId, cpId, countryCode));
    }

    @LogExecutionTime
    @PostMapping("/validateBulkQCPass")
    public ResponseDto validateBulkQCPass(@Valid @RequestBody List<AssetKeyDto> assetList) {
        log.info("Request received for validateBulkQCPass. {}", assetList);
        return ResponseHandler.processMethodResponse(Constants.VALIDATION,
            vodAssetValidationService.validateBulkQCPass(assetList));
    }
}
