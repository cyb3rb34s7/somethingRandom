package com.cms.assetmanagement.common.enums;

public enum AssetImageType {
    LANDSCAPE_BANNER("landscape_banner"),
    LANDSCAPE_ICONIC("landscape_iconic"),
    PORTRAIT_BANNER("portrait_banner"),
    PORTRAIT_BACKDROP("portrait_backdrop"),
    LANDSCAPE_BACKDROP("landscape_backdrop"),
    TITLE_TREATMENT("title_treatment"),
    PORTRAIT_ICONIC("portrait_iconic");


    public final String value;

    AssetImageType(String value) {
        this.value = value;
    }
}