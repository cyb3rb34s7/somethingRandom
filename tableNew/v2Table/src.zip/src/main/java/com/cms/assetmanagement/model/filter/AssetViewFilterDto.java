package com.cms.assetmanagement.model.filter;

import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssetViewFilterDto {

    private List<PlatformTagData> platforms;
    private List<LanguageDto> languages;
    private List<ParentalRatingsDto> parentalRatings;
}
