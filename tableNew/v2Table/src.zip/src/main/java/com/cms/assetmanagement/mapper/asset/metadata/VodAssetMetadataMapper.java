package com.cms.assetmanagement.mapper.asset.metadata;

import com.cms.assetmanagement.model.CountryDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VodAssetMetadataMapper {

    List<CountryDto> getCountryCodes(String region);

    List<String> getCountries(String region);

}
