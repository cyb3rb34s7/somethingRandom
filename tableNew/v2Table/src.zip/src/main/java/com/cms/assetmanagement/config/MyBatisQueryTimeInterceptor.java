package com.cms.assetmanagement.config;

import java.util.Properties;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Component;

/**
 * MyBatis interceptor to log query execution time. This interceptor captures only the database
 * query execution time, excluding data transfer time and result mapping time.
 */
@Slf4j
@Component
@Intercepts({
    @Signature(
        type = Executor.class,
        method = "query",
        args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}
    ),
    @Signature(
        type = Executor.class,
        method = "update",
        args = {MappedStatement.class, Object.class}
    )
})
public class MyBatisQueryTimeInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        // Get the MappedStatement to extract query information
        MappedStatement mappedStatement = (MappedStatement) invocation.getArgs()[0];
        Object parameter = invocation.getArgs()[1];

        // Get the SQL query
        BoundSql boundSql = mappedStatement.getBoundSql(parameter);
        String sql = boundSql.getSql().replaceAll("\\s+", " ").trim();

        // Extract query ID and type
        String queryId = mappedStatement.getId();
        String queryType = mappedStatement.getSqlCommandType().name();

        // Log query start
        if (log.isDebugEnabled()) {
            log.debug("MyBatis Query Start - ID: {}, Type: {}", queryId, queryType);
        }

        // Measure execution time
        long startTime = System.currentTimeMillis();
        Object result;

        try {
            // Execute the query
            result = invocation.proceed();
            return result;
        } finally {
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;

            // Log execution time - this captures only query execution time
            // Data transfer time and result mapping time are excluded
            log.info("MyBatis Query Execution Time - ID: {}, Type: {}, Time: {}ms",
                queryId, queryType, executionTime);

            // Log slow queries (configurable threshold)
            if (executionTime > 2000) { // 2 second threshold
                log.warn("Slow Query Detected - ID: {}, Type: {}, Time: {}ms, SQL: {}",
                    queryId, queryType, executionTime, sql);
            }
        }
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
        // No custom properties needed for now
    }
}
