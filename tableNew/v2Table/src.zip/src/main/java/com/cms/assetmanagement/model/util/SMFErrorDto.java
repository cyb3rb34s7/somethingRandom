package com.cms.assetmanagement.model.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class SMFErrorDto {

    @JsonProperty("program_id_error")
    private String programIdError;

    @JsonProperty("schema_validation_error")
    private String schemaValidationError;

    @JsonProperty("provider_error")
    private String providerError;

    @JsonProperty("ad_break_error")
    private String adBreakError;

    @JsonProperty("title_error")
    private String titleError;

    @JsonProperty("description_error")
    private String descriptionError;

    @JsonProperty("parental_ratings_error")
    private String parentalRatingsError;

    @JsonProperty("playback_items_error")
    private String playbackItemsError;

    @JsonProperty("duplicate_images_error")
    private String duplicateImagesError;

    @JsonProperty("duplicate_id_from_different_cp_error")
    private String duplicateIdFromDifferentCpError;

    @JsonProperty("artist_info_error")
    private String artistInfoError;

    @JsonProperty("json_to_smf_object_conversion_error")
    private String jsonToSMFObjectConversionError;

    @JsonProperty("content_processing_trigger_error")
    private String contentProcessingTriggerError;

    @JsonProperty("country_lang_error")
    private String countryLangError;
}
