package com.cms.assetmanagement.model.util;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorDto {

    private String type;
    private String message;
}
