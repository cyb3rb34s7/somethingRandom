package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ImageProcessingMapper {

    List<ProcessedImageDto> getProcessedImagesByReqId(@Param("requestId") String requestId);

    void deleteImageByKeys(
        @Param("preProcessImageDto") PreProcessImageDto preProcessImageDto);
    
    void insertPreProcessingUrls(
        @Param("preProcessImageDto") PreProcessImageDto preProcessImageDto);

    void deleteImageByReqId(@Param("requestId") String requestId);
}
