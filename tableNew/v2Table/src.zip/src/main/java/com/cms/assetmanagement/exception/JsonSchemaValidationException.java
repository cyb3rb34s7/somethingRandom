package com.cms.assetmanagement.exception;

public class JsonSchemaValidationException extends RuntimeException {

    public JsonSchemaValidationException(String message) {
        super(message);
    }
}
