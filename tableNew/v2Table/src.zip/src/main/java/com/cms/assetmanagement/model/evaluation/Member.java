package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Member {
    private int personId;
    private int ord;
    private String characterName;
    private String role;
    private Name name;
}
