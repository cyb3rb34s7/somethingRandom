package com.cms.assetmanagement.model;

import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VodAssetDetailedDto {

    private VodAssetDto vodAsset;
    private VodAssetDto vodCpAsset;
    private List<AssetExternalIdDto> externalProvider;
    private List<AssetDrmDto> drm;
    private List<PlatformTagData> platform;
    private List<AdBreaksDto> adBreak;
    private List<AssetRatingDto> rating;
    private List<AssetCastDto> cast;
    private List<LicenseWindowDto> licenseWindowList;
    private List<EventWindowDto> eventWindowList;
    private GracenoteMapDto gracenoteMaintainMap;
    private List<AssetLockedFieldDto> lockedFields;
    private List<AssetSubtitleDto> subtitles;
    private List<GeoRestrictionsDto> geoRestrictions;
}
