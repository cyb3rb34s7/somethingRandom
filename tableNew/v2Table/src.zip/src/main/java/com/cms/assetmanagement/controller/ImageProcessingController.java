package com.cms.assetmanagement.controller;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.config.LogExecutionTime;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.service.ImageProcessingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cms/tvplus/imageprocess")
public class ImageProcessingController {

    @Autowired
    ImageProcessingService imageProcessingService;

    @LogExecutionTime
    @PostMapping("/initiate")
    public ResponseDto initiateImageProcess(@RequestBody PreProcessImageDto preProcessImageDto) {
        log.info("Request received for initiateImageProcess for ReqId: {}",
            preProcessImageDto.getServiceBatchId());
        imageProcessingService.initiateImageProcess(preProcessImageDto);
        return ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.IMAGE_PROCESS_SUCCESS);
    }

    @LogExecutionTime
    @GetMapping("/getprocessedimages")
    public ResponseDto getProcessedImages(@RequestParam String requestId) {
        log.info("Request received for getProcessedImages for ReqId: {}", requestId);
        return ResponseHandler.processMethodResponse(Constants.PROCESSED_IMAGES,
            imageProcessingService.getProcessedImagesByReqId(
                requestId));
    }

    @LogExecutionTime
    @PostMapping("/deleteimagebyreqid")
    public ResponseDto deleteImageByReqId(@RequestParam String requestId) {
        log.info("Request received for deleteImageByReqId for ReqId: {}", requestId);
        imageProcessingService.deleteImageByReqId(requestId);
        return ResponseHandler.processMethodResponse(Constants.PROCESSED_IMAGES,
            Constants.IMAGE_DELETE_SUCCESS
        );
    }

}
