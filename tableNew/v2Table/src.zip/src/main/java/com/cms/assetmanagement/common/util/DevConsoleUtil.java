package com.cms.assetmanagement.common.util;

import com.cms.assetmanagement.common.DevConsoleConstants;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import org.springframework.stereotype.Component;

@Component
public class DevConsoleUtil {

    public String parseFeedWorker(String feedWorker) {
        if (feedWorker == null) {
            return "ALL";
        }

        String upperCaseFeedWorker = feedWorker.toUpperCase();
        if (DevConsoleConstants.VALID_FEED_WORKERS.contains(upperCaseFeedWorker)) {
            return upperCaseFeedWorker;
        }

        String errMsg = "Invalid feed worker value provided. Valid values are: "
            + DevConsoleConstants.VALID_FEED_WORKERS + ". Provided value was: " + feedWorker;
        throw new InvalidInputDataException(errMsg);
    }

    public boolean isValidFeedWorker(String feedWorker) {
        return feedWorker.equals(DevConsoleConstants.CMS_FEED_WORKER)
            || feedWorker.equals(DevConsoleConstants.TVPLUS_FEED_WORKER);
    }
}
