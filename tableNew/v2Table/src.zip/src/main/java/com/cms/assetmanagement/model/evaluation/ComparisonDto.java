package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class ComparisonDto {
    private String programId;
    private String cpId;
    private String programType;
    private String programTitle;
    private String feedWorker;
    private String tmsId;
    private String coverageStatus;
    private String comparisonStatus;
}
