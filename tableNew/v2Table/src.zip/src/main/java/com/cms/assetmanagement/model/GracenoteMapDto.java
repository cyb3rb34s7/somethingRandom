package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GracenoteMapDto {

    private String contentId;
    private String vcCpId;
    private String countryCode;
    private String regrId;
    private String crctrId;
    private String regDate;
    private String updateDate;

}
