package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AssetCastDto {

    private String contentId;
    private String vcCpId;
    private String countryCode;
    private String name;
    private String role;
    private String characterName;
    private String regrId;
    private String crctrId;
    private String feedWorker;
}
