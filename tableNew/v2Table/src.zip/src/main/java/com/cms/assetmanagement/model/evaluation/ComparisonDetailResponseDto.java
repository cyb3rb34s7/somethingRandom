package com.cms.assetmanagement.model.evaluation;

import com.cms.assetmanagement.model.VodAssetDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@AllArgsConstructor
@ToString(callSuper = true)
public class ComparisonDetailResponseDto {
    private VodAssetDto content;
    private VodAssetDto umd;
    private VodAssetDto onApi;
    private String coverageStatus;
    private String comparisonStatus;
}
