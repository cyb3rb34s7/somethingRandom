package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.mapper.asset.content.ImageProcessingMapper;
import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import com.cms.assetmanagement.service.ImageProcessingService;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class ImageProcessingServiceImpl implements ImageProcessingService {

    @Autowired
    ImageProcessingMapper imageProcessingMapper;

    @Override
    @Transactional("contentTransactionManager")
    public List<ProcessedImageDto> getProcessedImagesByReqId(String requestId) {
        return imageProcessingMapper.getProcessedImagesByReqId(requestId);
    }

    @Override
    @Transactional("contentTransactionManager")
    public void initiateImageProcess(PreProcessImageDto preProcessImageDto) {
        imageProcessingMapper.deleteImageByKeys(preProcessImageDto);
        imageProcessingMapper.insertPreProcessingUrls(preProcessImageDto);

    }

    @Override
    @Transactional("contentTransactionManager")
    public void insertPreProcessingUrls(PreProcessImageDto preProcessImageDto) {
        imageProcessingMapper.insertPreProcessingUrls(preProcessImageDto);

    }

    @Override
    @Transactional("contentTransactionManager")
    public void deleteImageByReqId(String requestId) {
        imageProcessingMapper.deleteImageByReqId(requestId);
    }

}
