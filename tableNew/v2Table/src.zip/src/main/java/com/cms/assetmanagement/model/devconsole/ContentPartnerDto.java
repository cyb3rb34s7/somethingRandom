package com.cms.assetmanagement.model.devconsole;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class ContentPartnerDto {

    private Integer contentPartnerId;
    private String contentPartner;
    private String isActive;
    private String countryCode;
    private Date regDate;

}
