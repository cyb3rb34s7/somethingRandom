package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class DeeplinkPayloadDto {

    @JsonProperty("content_type")
    private String contentType;
    @JsonProperty("content_id")
    private String contentId;
    @JsonProperty("series_id")
    private String seriesId;
    @JsonProperty("ratings")
    private String ratings;
}
