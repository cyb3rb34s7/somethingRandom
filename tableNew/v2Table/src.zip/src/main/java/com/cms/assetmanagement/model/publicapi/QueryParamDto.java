package com.cms.assetmanagement.model.publicapi;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryParamDto {

    private String countryCode;
    private String providerId;
    private String mediaStatus;
    private String programId;
    private String programType;
    private String sortBy;
    private Integer offset;
    private Integer limit;

}