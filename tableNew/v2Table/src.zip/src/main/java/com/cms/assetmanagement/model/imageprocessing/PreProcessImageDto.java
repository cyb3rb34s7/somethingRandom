package com.cms.assetmanagement.model.imageprocessing;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PreProcessImageDto {

    private String countryCode;
    private String providerId;
    private String assetId;
    private List<String> imageUrls;
    private String serviceBatchId;
}
