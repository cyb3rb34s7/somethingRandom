package com.cms.assetmanagement.model.smf;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AssetDrmDto {

    @JsonProperty("type")
    private String type;

    @JsonProperty("license_url")
    private String licenseUrl;

    @JsonProperty("custom_header_name")
    private String customHeaderName;

    @JsonProperty("custom_header_value")
    private String customHeaderValue;
}

