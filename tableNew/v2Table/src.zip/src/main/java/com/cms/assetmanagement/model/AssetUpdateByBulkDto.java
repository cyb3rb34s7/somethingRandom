package com.cms.assetmanagement.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data

public class AssetUpdateByBulkDto {

    @NotNull
    @Size(min = 1, message = "At least one asset id should be provided")
    private List<String> contentIds;
    @Valid
    private VodAssetDto vodAssetDto;

}
