package com.cms.assetmanagement.model.evaluation;

import com.cms.assetmanagement.common.enums.ComparisonStatusEnum;
import com.cms.assetmanagement.common.enums.CoverageStatusEnum;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@Builder
@Getter
@AllArgsConstructor
@ToString(callSuper = true)
public class ComparisonAssetListRequestDto {
    private String programTitle;
    @NotNull
    private List<String> programTypeList;
    @NotNull
    private CoverageStatusEnum coverageStatus;
    @NotNull
    private ComparisonStatusEnum comparisonStatus;
}
