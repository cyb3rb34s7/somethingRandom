package com.cms.assetmanagement.model.filter;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class CountryLangCodeDto {

    private String cntyCd;
    private String langCode;
}
