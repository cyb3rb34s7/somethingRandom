package com.cms.assetmanagement.model.filter;

import com.cms.assetmanagement.common.Constants;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaginationDto {

    @JsonProperty(defaultValue = Constants.LIMIT_DEFAULT)
    private int limit;
    @JsonProperty(defaultValue = Constants.OFFSET_DEFAULT)
    private int offset;
}
