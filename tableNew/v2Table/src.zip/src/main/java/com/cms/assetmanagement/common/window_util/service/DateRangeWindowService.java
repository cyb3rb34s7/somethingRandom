package com.cms.assetmanagement.common.window_util.service;

import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.common.window_util.model.WindowType;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import jakarta.validation.constraints.NotEmpty;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class DateRangeWindowService {

    @Value("${MERGE_HOUR_GAP:1}")
    private int mergeHourGap;

    private static final DateTimeFormatter inputFormatter = DateTimeFormatter
        .ofPattern("uuuu-MM-dd HH:mm:ss")
        .withZone(ZoneOffset.UTC)
        .withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter outputFormatter = DateTimeFormatter
        .ofPattern("uuuu-MM-dd'T'HH:mm:ss'Z'")
        .withZone(ZoneOffset.UTC)
        .withResolverStyle(ResolverStyle.STRICT);

    private final VodAssetMapper vodAssetMapper;

    public DateRangeWindowService(VodAssetMapper vodAssetMapper) {
        this.vodAssetMapper = vodAssetMapper;
    }

    public <T extends DateRangeWindow> T findUpdateSlot(@NotEmpty List<T> windows) {
        var lo = 0;
        var hi = windows.size() - 1;
        var resInd = -1;
        var now = Instant.now();

        while (lo <= hi) {
            var mid = lo + (hi - lo) / 2;

            var start = Instant.parse(windows.get(mid).getStartingTime());
            var end = windows.get(mid).getEndingTime() != null
                ? Instant.parse(windows.get(mid).getEndingTime())
                : Instant.MAX;

            if (now.isBefore(end)) {
                resInd = mid;
                if (now.isAfter(start)) {
                    return windows.get(resInd);
                }

                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }

        if (resInd == -1) {
            return windows.get(windows.size() - 1);
        }

        WindowType type = windows.get(0).getWindowType();
        if (WindowType.LICENSE_WINDOW.equals(type)) {
            return (T) mergeWindowIfGapLessThan1Hour(resInd, (List<LicenseWindowDto>) windows);
        }
        return windows.get(resInd);
    }

    private LicenseWindowDto mergeWindowIfGapLessThan1Hour(int ind,
        List<LicenseWindowDto> licenseWindows) {
        // No Previous Window
        if (ind == 0) {
            return licenseWindows.get(ind);
        }

        var currWindow = licenseWindows.get(ind);
        var prevWindow = licenseWindows.get(ind - 1);
        var currStartTime = Instant.parse(currWindow.getStartingTime());
        var prevEndTime = Instant.parse(prevWindow.getEndingTime());

        // 1 Hour gap within curr slot and previous slot
        if (isWithinOneHour(currStartTime, prevEndTime)) {
            return LicenseWindowDto.builder()
                .availableStarting(prevWindow.getStartingTime())
                .availableEnding(currWindow.getEndingTime())
                .build();
        }

        return licenseWindows.get(ind);
    }

    private boolean isWithinOneHour(Instant instant1, Instant instant2) {
        Duration duration = Duration.between(instant1, instant2).abs();
        return duration.minus(Duration.ofHours(mergeHourGap)).isNegative();
    }

    public <T extends DateRangeWindow> void sortWindows(List<T> windows) {
        if (windows == null || windows.isEmpty()) {
            return;
        }

        windows.sort(Comparator.comparing(DateRangeWindow::getStartingTime));
    }

    // Warning: Assumes sorted list
    public <T extends DateRangeWindow> boolean areWindowsNonOverlapping(List<T> windows) {
        if (windows == null) {
            return true;
        }

        for (var i = 1; i < windows.size(); ++i) {
            String currStartTime = windows.get(i).getStartingTime();
            String prevEndTime = windows.get(i - 1).getEndingTime();

            if (currStartTime.compareTo(prevEndTime) <= 0) {
                return false;
            }
        }

        return true;
    }

    // Warning: Assumes sorted list
    public <T extends DateRangeWindow> boolean areWindowsValid(List<T> windows) {
        if (windows == null) {
            return true;
        }

        for (DateRangeWindow window : windows) {
            if (window.getEndingTime() != null
                && window.getStartingTime().compareTo(window.getEndingTime()) > 0) {
                return false;
            }
        }

        return true;
    }

    public <T extends DateRangeWindow> List<T> mergeWindows(List<T> newList, List<T> listFromDb) {

        Set<String> seenWindowIds = new HashSet<>();
        List<T> mergedList = new ArrayList<>();

        for (var window : newList) {
            seenWindowIds.add(window.getWindowId());
            mergedList.add(window);
        }

        for (var window : listFromDb) {
            if (!seenWindowIds.contains(window.getWindowId())) {
                mergedList.add(window);
            }
        }

        return mergedList;
    }

    public <T extends DateRangeWindow> void addTzToTimestamps(List<T> windows) {
        if (windows == null) {
            return;
        }

        windows.forEach(win -> {
            win.setStartingTime(convertToIsoFormat(win.getStartingTime()));
            win.setEndingTime(convertToIsoFormat(win.getEndingTime()));
        });
    }

    public <T extends DateRangeWindow> void removeTzFromTimestamps(List<T> windows) {
        if (windows == null) {
            return;
        }

        windows.forEach(win -> {
            win.setStartingTime(convertFromIsoFormat(win.getStartingTime()));
            win.setEndingTime(convertFromIsoFormat(win.getEndingTime()));
        });
    }

    public <T extends DateRangeWindow> List<String> getDuplicateLicenseIds(List<T> windows) {
        if (windows == null) {
            return List.of();
        }

        return windows.stream()
            .map(DateRangeWindow::getWindowId)
            .collect(Collectors.groupingBy(id -> id, Collectors.counting()))
            .entrySet().stream()
            .filter(entry -> entry.getValue() > 1)
            .map(Map.Entry::getKey)
            .toList();
    }

    private String convertToIsoFormat(String inputDate) {
        var localDateTime = LocalDateTime.parse(inputDate, inputFormatter);
        return localDateTime.format(outputFormatter);
    }

    public String convertFromIsoFormat(String inputDate) {
        var localDateTime = LocalDateTime.parse(inputDate, outputFormatter);
        return localDateTime.format(inputFormatter);
    }

    // --- DB Related Helpers ---
    public <T extends DateRangeWindow> List<T> getWindowListFromDb(String programId, String cpId,
        String countryCode, boolean shouldMerge, WindowType windowType) {
        if (!shouldMerge) {
            return new ArrayList<>();
        }

        if (WindowType.LICENSE_WINDOW.equals(windowType)) {
            return (List<T>) vodAssetMapper.getLicenseWindows(programId, cpId, countryCode);
        } else {
            return (List<T>) vodAssetMapper.getEventWindows(programId, cpId, countryCode);
        }
    }


    public boolean findAndUpdateLicenseActiveSlot(String contentId, String countryCode,
        String vcCpId, List<LicenseWindowDto> windows) {
        // null means no update from Admin, And licenseWindows cannot be empty as it's mandatory
        if (windows == null || windows.isEmpty()) {
            return false;
        }

        sortWindows(windows);
        LicenseWindowDto activeSlot = findUpdateSlot(windows);
        updateWindowActiveSlot(contentId, vcCpId, countryCode, activeSlot);

        return true;
    }

    public void findAndUpdateEventActiveSlot(String contentId, String countryCode,
        String vcCpId, List<EventWindowDto> windows) {
        // null means No update from Admin
        if (windows == null) {
            return;
        }
        // empty mean Admin wants to Delete all the event windows (Valid because it's an optional field)
        if (windows.isEmpty()) {
            updateWindowActiveSlot(contentId, vcCpId, countryCode, new EventWindowDto());
            return;
        }

        sortWindows(windows);
        EventWindowDto activeSlot = findUpdateSlot(windows);
        updateWindowActiveSlot(contentId, vcCpId, countryCode, activeSlot);
    }

    public void findAndUpdateCPLicenseActiveSlot(String contentId, String countryCode,
        String vcCpId, List<LicenseWindowDto> windows) {
        // null means no update from Admin, And licenseWindows cannot be empty as it's mandatory
        if (windows == null || windows.isEmpty()) {
            return;
        }

        sortWindows(windows);
        LicenseWindowDto activeSlot = findUpdateSlot(windows);
        updateCPWindowActiveSlot(contentId, vcCpId, countryCode, activeSlot);
    }

    public void findAndUpdateCPEventActiveSlot(String contentId, String countryCode,
        String vcCpId, List<EventWindowDto> windows) {
        // null means No update from Admin
        if (windows == null) {
            return;
        }
        // empty mean Admin wants to Delete all the event windows (Valid because it's an optional field)
        if (windows.isEmpty()) {
            updateCPWindowActiveSlot(contentId, vcCpId, countryCode,
                new EventWindowDto());
            return;
        }

        sortWindows(windows);
        EventWindowDto activeSlot = findUpdateSlot(windows);
        updateCPWindowActiveSlot(contentId, vcCpId, countryCode, activeSlot);
    }

    public <T extends DateRangeWindow> void updateWindowActiveSlot(String programId, String cpId,
        String countryCode, T activeSlot) {

        if (WindowType.LICENSE_WINDOW.equals(activeSlot.getWindowType())) {
            vodAssetMapper.updateLicenseWindow(programId, countryCode, cpId,
                (LicenseWindowDto) activeSlot);
        } else {
            vodAssetMapper.updateEventWindow(programId, countryCode, cpId,
                (EventWindowDto) activeSlot);
        }
    }

    public <T extends DateRangeWindow> void updateCPWindowActiveSlot(String programId, String cpId,
        String countryCode, T activeSlot) {

        if (WindowType.LICENSE_WINDOW.equals(activeSlot.getWindowType())) {
            vodAssetMapper.updateCPLicenseWindow(programId, countryCode, cpId,
                (LicenseWindowDto) activeSlot);
        } else {
            vodAssetMapper.updateCPEventWindow(programId, countryCode, cpId,
                (EventWindowDto) activeSlot);
        }
    }
}