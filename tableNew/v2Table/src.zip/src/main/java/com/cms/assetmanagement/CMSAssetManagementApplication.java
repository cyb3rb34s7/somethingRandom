package com.cms.assetmanagement;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@Slf4j
@PropertySource("classpath:application-${env}.properties")
@PropertySource("classpath:application.properties")
public class CMSAssetManagementApplication {

    public static void main(String[] args) {

        try {
            SpringApplication.run(CMSAssetManagementApplication.class, args);
            log.info("Started AssetManagement Service");
        } catch (Exception ex) {
            log.error("Main method of AssetManagement has stopped. Exception: {}", ex.getMessage());
        }
    }
}
