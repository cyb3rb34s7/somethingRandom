package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.enums.ComparisonStatusEnum;
import com.cms.assetmanagement.common.enums.CoverageStatusEnum;
import com.cms.assetmanagement.mapper.asset.content.EvaluationMapper;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.evaluation.ComparisonAssetListResponseDto;
import com.cms.assetmanagement.model.evaluation.ComparisonDetailResponseDto;
import com.cms.assetmanagement.model.evaluation.ComparisonDto;
import com.cms.assetmanagement.model.evaluation.CountDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import com.cms.assetmanagement.model.evaluation.StatusDto;
import com.cms.assetmanagement.service.EvaluationService;
import com.cms.assetmanagement.service.VodAssetService;
import com.cms.assetmanagement.service.VodAssetViewService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class EvaluationServiceImpl implements EvaluationService {

    private final EvaluationMapper evaluationMapper;
    private final VodAssetService vodAssetService;
    private final VodAssetViewService vodAssetViewService;

    @Override
    public ComparisonAssetListResponseDto getProgramList(FilterRequestDto filterRequestDto) {
        List<ComparisonDto> comparisonDtoList = evaluationMapper.findAllWithUmd(filterRequestDto);

        long matchedCount = comparisonDtoList.stream().filter(content ->
            content.getComparisonStatus().equals(ComparisonStatusEnum.MATCHING.getValue())).count();

        long coveredCount = comparisonDtoList.stream().filter(content ->
            content.getCoverageStatus().equals(CoverageStatusEnum.COVERED.getValue())).count();

        return ComparisonAssetListResponseDto.builder()
            .totalCount(comparisonDtoList.size())
            .matchedCount(matchedCount)
            .coveredCount(coveredCount)
            .data(comparisonDtoList)
            .build();
    }

    @Override
    public ComparisonDetailResponseDto getDetail(String contentId, String cpId) {
        String countryCode = Constants.CNTR_CD_US;
        VodAssetDto cpAssetDto = vodAssetViewService.getAssetCPView(contentId, cpId, countryCode);
        VodAssetDto umdAssetDto = vodAssetViewService.getAssetGracenoteView(contentId, cpId,
            countryCode);
        VodAssetDto onApiAssetDto = vodAssetViewService.getAssetGracenoteOnView(contentId, cpId,
            countryCode);
        StatusDto statusDto = evaluationMapper.findStatus(contentId);

        return ComparisonDetailResponseDto.builder()
            .content(cpAssetDto)
            .umd(umdAssetDto)
            .onApi(onApiAssetDto)
            .coverageStatus(statusDto.getCoverageStatus())
            .comparisonStatus(statusDto.getComparisonStatus())
            .build();
    }

    @Override
    public CountDto getCount(FilterRequestDto filterRequestDto) {
        CountDto countDto = evaluationMapper.findCount(filterRequestDto);
        double coveredRate = 0.0;
        double matchedRate = 0.0;

        if (countDto.getTotalCount() > 0) {
            coveredRate = ((double) countDto.getCoveredCount() / countDto.getTotalCount()) * 100;
        }

        if (countDto.getCoveredCount() > 0) {
            matchedRate = ((double) countDto.getMatchedCount() / countDto.getCoveredCount()) * 100;
        }

        countDto.setCoveredRate(String.format("%.2f", coveredRate));
        countDto.setMatchedRate(String.format("%.2f", matchedRate));

        return countDto;
    }
}
