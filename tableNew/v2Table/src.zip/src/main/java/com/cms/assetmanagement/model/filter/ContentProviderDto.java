package com.cms.assetmanagement.model.filter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ContentProviderDto {

    private String countryCd;
    private String vcCpId;
    private String vcCpNm;
    private String status;
    private String type;
    private String contentId;
    private String showId;
    private Integer seasonNumber;
}
