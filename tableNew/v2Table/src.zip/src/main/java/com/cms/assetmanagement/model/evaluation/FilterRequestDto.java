package com.cms.assetmanagement.model.evaluation;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@Builder
@ToString
public class FilterRequestDto {

    private List<FilterDto> filters;
    private PaginationDto pagination;

}
