package com.cms.assetmanagement.model.export;

import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class VodAssetExportDto {

    private String contentId;
    private String assetId;
    private String type;
    private String countryCode;
    private String mainTitle;
    private String mainTitleLanguage;
    private String shortTitle;
    private String shortTitleLanguage;
    private Integer runningTime;
    private String adTag;
    private String streamUri;
    private String language;
    private String description;
    private String releaseDate;
    private String genres;
    private String ratings;
    private String deeplinkPayload;
    private String chapterTime;
    private String chapterDescription;
    private String audioLang;
    private String subtitleLang;
    private String quality;
    private String cpName;
    private String contentPartner;
    private String contentTier;
    private Date updateDate;
    private String feedWorker;

    private List<AssetCastDto> cast;
    private List<AdBreaksDto> adBreaks;
    private List<AssetDrmDto> drmData;
    private List<PlatformTagData> platformTagData;
    private List<ParentalRatingsDto> parentalRatings;
    private List<ExternalProviderDto> externalProvider;
    private List<LicenseWindowDto> licenseWindowList;
    private List<EventWindowDto> eventWindowList;

    // Extra fields for selected columns
    private String tiName;
    private String showTitle;
    private String seasonTitle;
    private String showId;
    private String seasonId;
    private String seasonNo;
    private String episodeNo;
    private String starring;
    private String vcCpId;
    private String licenseWindow;
    private String availableStarting;
    private String expiryDate;
    private String status;
    private String dbStatus;
    private String externalProgramId;
    private String externalIdProvider;
    private String onDeviceTrans;
    private String qcPassReason;
    private Date regDate;
    private String liveOnDevice;
}

