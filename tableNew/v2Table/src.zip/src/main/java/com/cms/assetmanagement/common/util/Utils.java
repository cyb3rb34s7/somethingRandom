package com.cms.assetmanagement.common.util;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.exception.CustomException;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.SortDto;
import jakarta.annotation.PostConstruct;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class Utils {

    @Value("${TVPLUS_FEED_WORKERS}")
    public String tvplusFeedWorkers;

    private final AssetTableColumnMapping assetTableColumnMapping;

    List<String> tvplusFeedWorkersList = new ArrayList<>();

    public Utils(AssetTableColumnMapping assetTableColumnMapping) {
        this.assetTableColumnMapping = assetTableColumnMapping;
    }

    private Map<String, String> tableColumnMap = new HashMap<>();

    @PostConstruct
    public void init() {
        tableColumnMap = assetTableColumnMapping.initializeTableColumnMapping();
        tvplusFeedWorkersList = Arrays.asList(tvplusFeedWorkers.split(","));
    }

    public static String dateToString(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return formatter.format(date);
    }

    public static <T> void retainOnlyFields(T asset, List<String> fieldsToKeep) {
        if (asset == null || fieldsToKeep == null || fieldsToKeep.isEmpty()) {
            return;
        }
        try {
            for (Field field : asset.getClass().getDeclaredFields()) {
                if (!fieldsToKeep.contains(field.getName())) {
                    String setterName =
                        "set" + field.getName().substring(0, 1).toUpperCase() + field.getName()
                            .substring(1);

                    // Find and invoke the setter method with null parameter
                    asset.getClass().getDeclaredMethod(setterName, field.getType())
                        .invoke(asset, (Object) null);
                }
            }
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            throw new CustomException("Failed to update response with required fields.");
        }
    }

    public AssetFilterBodyDto getColumnMapping(AssetFilterBodyDto filterBody) {

        // Update columns mapping
        List<String> tableColumns = new ArrayList<>();
        List<String> columns = filterBody.getColumns();
        if (columns != null && !columns.isEmpty()) {
            for (String column : columns) {
                checkValidColumn(column, Constants.COLUMN_STR);
                tableColumns.add(tableColumnMap.get(column));
            }
            filterBody.setColumns(tableColumns);
        }

        // Update sort column
        if (filterBody.getSortBy() != null && !filterBody.getSortBy().isEmpty()) {
            List<SortDto> sortFields = filterBody.getSortBy();
            for (SortDto sort : sortFields) {
                String column = sort.getField();
                checkValidColumn(column, Constants.SORT_STR);
                sort.setField(tableColumnMap.get(column));
            }
        }

        //Update Filters
        if (filterBody.getFilters() != null && !filterBody.getFilters().isEmpty()) {
            List<FilterDto> filters = filterBody.getFilters();
            for (FilterDto filter : filters) {
                String column = filter.getKey();
                checkValidColumn(column, Constants.FILTER_STR);
                filter.setKey(tableColumnMap.get(column));
            }
        }

        return filterBody;
    }

    public AssetByColumnsReqDto getHistoryColumnMap(AssetByColumnsReqDto assetReqByColumns) {

        List<String> columns = assetReqByColumns.getColumns();
        List<String> tableColumns = new ArrayList<>();
        if (columns != null && !columns.isEmpty()) {
            columns.forEach(column -> {
                if (!tableColumnMap.containsKey(column)) {
                    log.error("Invalid Bulk Edit Columns : {}", column);
                    throw new InvalidInputDataException("Invalid Bulk Edit Columns : " + column);
                }
                tableColumns.add(tableColumnMap.get(column));
            });
            assetReqByColumns.setColumns(tableColumns);
        }
        return assetReqByColumns;
    }

    public Instant getUTCDateTime(String dateTime, String dateTimeFormat) {
        if (dateTime != null) {
            try {
                return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(dateTimeFormat))
                    .atZone(ZoneId.of("UTC")).toInstant();
            } catch (DateTimeParseException e) {
                log.error("Error while parsing the dates : {}", e.getMessage());
            }
        }
        return null;
    }

    public String getStatus(String licenseWindow, String status) {
        if (Constants.RELEASED.equals(status) && licenseWindow.contains(
            Constants.UPCOMING)) {
            return Constants.READY_FOR_RELEASE;
        } else if (Constants.EXPIRED.equals(licenseWindow)) {
            return status;
        }
        return status;
    }

    public String checkLiveOnDevice(VodAssetDto asset) {
        if (Constants.UNTRACKABLE.equalsIgnoreCase(asset.getStatus())) {
            return Constants.UNTRACKABLE;
        }
        if (Constants.RELEASED.equalsIgnoreCase(asset.getStatus()) &&
            Constants.DB_STATUS_PRD.equalsIgnoreCase(asset.getDbStatus())) {
            if (Constants.SHOW.equalsIgnoreCase(asset.getType()) ||
                Constants.SEASON.equalsIgnoreCase(asset.getType())) {
                return Constants.STRING_YES;
            }
            if (asset.getLicenseWindow() != null &&
                (asset.getLicenseWindow().contains(Constants.ACTIVE) ||
                    asset.getLicenseWindow().contains(Constants.EXPIRING_IN))) {
                return Constants.STRING_YES;
            } else {
                return Constants.STRING_NO;
            }
        }
        return Constants.STRING_NO;
    }

    public String checkExternalAsset(String status, String feedWorker, List<String> feedWorkers) {

        if (feedWorker != null && feedWorkers != null &&
            !feedWorkers.isEmpty() && !feedWorkers.contains(feedWorker)) {
            status = Constants.UNTRACKABLE;
        }

        return status;
    }

    public String checkExternalAssetForDbStatus(String dbStatus, String feedWorker,
        List<String> feedWorkers) {

        if (feedWorker != null && feedWorkers != null &&
            !feedWorkers.isEmpty() && !feedWorkers.contains(feedWorker)) {
            dbStatus = Constants.UNTRACKABLE;
        }

        return dbStatus;
    }

    public void setExternalProviderData(VodAssetDto asset) {
        if (asset.getExternalProvider() != null && !asset.getExternalProvider().isEmpty()) {
            asset.setExternalProgramId(asset.getExternalProvider().stream()
                .map(ExternalProviderDto::getExternalProgramId)
                .filter(Objects::nonNull).distinct().collect(
                    Collectors.joining(",")));
            asset.setExternalIdProvider(asset.getExternalProvider().stream()
                .map(ExternalProviderDto::getProvider)
                .filter(Objects::nonNull).distinct().collect(
                    Collectors.joining(",")));

        }
    }

    public String getLicenseWindow(String startDate, String expDate) {
        var now = Instant.now();
        Instant startDateTime = getUTCDateTime(startDate, Constants.AVAILABLE_START_DATE_FORMAT);
        if (startDateTime == null) {
            return "";
        }

        Instant expDateTime = getUTCDateTime(expDate, Constants.EXPIRY_DATE_FORMAT);
        if (expDateTime == null) {
            expDateTime = Instant.MAX;
        }

        if (startDateTime.isAfter(now)) {
            return calculateUpcoming(now, startDateTime);
        } else if (expDateTime.isBefore(now)) {
            return Constants.EXPIRED;
        } else {
            var difference = Duration.between(now, expDateTime);
            long days = difference.toDays();

            if (days > Constants.EXPIRY_THRESHHOLD) {
                return Constants.ACTIVE;
            } else {
                return Constants.EXPIRING_IN + days + " " +
                    (difference.toDays() == Constants.VALUE_ONE ? Constants.DAY : Constants.DAYS);
            }
        }
    }

    public AssetFilterBodyDto preProcessInput(AssetFilterBodyDto filterBody) {
        if (filterBody.getFilters() != null && !filterBody.getFilters().isEmpty()) {
            List<FilterDto> filters = filterBody.getFilters();
            for (FilterDto filter : filters) {
                List<String> newValues = new ArrayList<>();
                filter.getValues().forEach(value ->
                    newValues.add(
                        value.trim().replace(Constants.SINGLE_QUOTE, Constants.DOUBLE_QUOTES)));
                filter.setValues(newValues);
            }
        }
        return filterBody;
    }

    public List<AssetKeyDto> createAssetList(VodAssetDto assetKeyDto) {
        List<AssetKeyDto> assetKeyList = new ArrayList<>();
        AssetKeyDto assetKey = AssetKeyDto.builder()
            .contentId(assetKeyDto.getContentId()).
            countryCode(assetKeyDto.getCountryCode())
            .vcCpId(assetKeyDto.getVcCpId()).build();
        assetKeyList.add(assetKey);

        return assetKeyList;
    }

    public boolean isTvplusDeltaFeedWorker(VodAssetDto asset) {
        return tvplusFeedWorkersList.stream()
            .anyMatch(el -> el.equalsIgnoreCase(asset.getFeedWorker()));
    }

    private void checkValidColumn(String columnName, String columnType) {
        String errorMsg = switch (columnType) {
            case Constants.SORT_STR -> "Invalid Sort Columns";
            case Constants.FILTER_STR -> "Invalid Filter Columns";
            default -> "Invalid Columns";
        };
        if (!tableColumnMap.containsKey(columnName)) {
            log.error("{} : {}", errorMsg, columnName);
            throw new InvalidInputDataException(errorMsg + " : " + columnName);
        }
    }

    private String calculateUpcoming(Instant now, Instant startDateTime) {
        var difference = Duration.between(now, startDateTime);
        long days = difference.toDays();
        if (days > Constants.UPCOMING_THRESHHOLD) {
            return Constants.UPCOMING_AFTER_300_DAYS;
        } else {
            return Constants.UPCOMING_IN + difference.toDays() + " " +
                (difference.toDays() == Constants.VALUE_ONE ? Constants.DAY : Constants.DAYS);
        }
    }


}
