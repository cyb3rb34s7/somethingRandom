package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetLockedFieldDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VodAssetColumnLockMapper {

    void deleteColumnLockByContentId(List<AssetKeyDto> assetList);

    void insertColumnLockByContentId(List<AssetLockedFieldDto> lockedFieldList);

    List<AssetLockedFieldDto> getAllColumnLockByContentId(AssetKeyDto assetKeyDto);
}