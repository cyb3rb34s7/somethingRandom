package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VodAssetStatusDto {

    private String contentId;
    private String countryCode;
    private String vcCpId;
    private String type;
    private String status;
    private String feedWorker;
    private Integer isCmsProd;
    private Boolean isSyncBlocked;
    private Boolean isReleased;
}
