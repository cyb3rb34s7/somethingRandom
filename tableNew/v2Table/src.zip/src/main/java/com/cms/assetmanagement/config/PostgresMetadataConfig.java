package com.cms.assetmanagement.config;

import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Profile("dev | stg")
@Configuration
@MapperScan(basePackages = "com.cms.assetmanagement.mapper.asset.metadata", sqlSessionFactoryRef = "postgresMetadataSessionFactory")
public class PostgresMetadataConfig {

    @Bean(name = "postgresMetadataDataSource")
    @ConfigurationProperties("spring.datasource.postgres.metadata")
    public DataSource postgresDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "postgresMetadataSessionFactory")
    public SqlSessionFactory postgresSessionFactory(
        @Qualifier("postgresMetadataDataSource") DataSource dataSource) throws Exception {
        var sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        // Add MyBatis query time interceptor
        sessionFactory.setPlugins(new MyBatisQueryTimeInterceptor());
        return sessionFactory.getObject();
    }

    @Bean(name = "postgresMetadataSessionTemplate")
    public SqlSessionTemplate primarySqlSessionTemplate(
        @Qualifier("postgresMetadataSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean(name = "metadataTransactionManager")
    public PlatformTransactionManager primaryTransactionManager(
        @Qualifier("postgresMetadataDataSource") DataSource postgresMetadataDataSource) {
        return new DataSourceTransactionManager(postgresMetadataDataSource);
    }


}
