package com.cms.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class AssetDrmDto {

    private String countryCode;
    private String providerId;
    private String programId;
    @Size(max = 20)
    private String type;
    @Size(max = 2000)
    private String licenseUrl;
    @Size(max = 200)
    private String customHeaderName;
    @Size(max = 4000)
    private String customHeaderValue;
    private String crctrId;
    private String feedWorker;
    private String regrId;
}