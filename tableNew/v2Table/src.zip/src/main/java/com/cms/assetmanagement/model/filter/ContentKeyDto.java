package com.cms.assetmanagement.model.filter;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class ContentKeyDto {

    private String cntyCd;
    private String contentId;
    private String vcCpId;
}
