package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.FeedWorkerPriority;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.SortDto;
import com.cms.assetmanagement.model.publicapi.QueryParamDto;
import com.cms.assetmanagement.service.VodAssetPublicService;
import jakarta.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
public class VodAssetPublicServiceImpl implements VodAssetPublicService {

    private final VodAssetMapper vodAssetMapper;
    private final Utils utils;

    @Value("${CMS_FEED_WORKERS}")
    public String cmsFeedWorkers;

    @Value("${EXTERNAL_FEED_WORKERS}")
    public String externalFeedWorkers;

    @Value("${REGION}")
    public String region;

    List<FeedWorkerPriority> feedWorkerOrder = new ArrayList<>();
    List<String> feedWorkerList = new ArrayList<>();
    List<String> extFeedWorkersList = new ArrayList<>();

    //    @Autowired
    public VodAssetPublicServiceImpl(VodAssetMapper vodAssetMapper, Utils utils) {
        this.vodAssetMapper = vodAssetMapper;
        this.utils = utils;
    }

    @PostConstruct
    public void init() {
        feedWorkerList = Arrays.asList(cmsFeedWorkers.split(","));
        extFeedWorkersList = Arrays.asList(externalFeedWorkers.split(","));

        var order = 1;
        for (String worker : feedWorkerList) {
            FeedWorkerPriority priority = FeedWorkerPriority.builder().feedWorker(worker)
                .priority(order++).build();
            feedWorkerOrder.add(priority);
        }
    }

    @Override
    @Transactional("contentTransactionManager")
    public List<VodAssetDto> getAssets(QueryParamDto queryParamDto) {
        log.info("Getting assets for /asset API");
        // don't need offset in program_id filter case
        int limit = queryParamDto.getLimit();
        int offset = queryParamDto.getOffset();
        if (queryParamDto.getProgramId() != null) {
            offset = Constants.OFFSET_DEFAULT_VALUE;
        }
        RowBounds rowBounds = new RowBounds(offset, limit);
        AssetFilterBodyDto filterBody = createRequestBody(queryParamDto);

        filterBody = utils.getColumnMapping(filterBody);
        List<VodAssetDto> assets = vodAssetMapper.getFilteredAssets(filterBody,
            feedWorkerList, feedWorkerOrder, extFeedWorkersList, rowBounds);

        if (!CollectionUtils.isEmpty(assets)) {
            for (VodAssetDto asset : assets) {
                String licenseWindow = utils.getLicenseWindow(asset.getAvailableStarting(),
                    asset.getExpiryDate());

                String status = utils.getStatus(licenseWindow, asset.getStatus());
                status = utils.checkExternalAsset(status, asset.getFeedWorker(), feedWorkerList);
                String dbStatus = utils.checkExternalAssetForDbStatus(asset.getDbStatus(),
                    asset.getFeedWorker(), feedWorkerList);
                utils.setExternalProviderData(asset);
                asset.setLicenseWindow(licenseWindow);
                asset.setStatus(status);
                asset.setDbStatus(dbStatus);

                asset.setLiveOnDevice(utils.checkLiveOnDevice(asset));
                Utils.retainOnlyFields(asset, Constants.PUBLIC_API_COLUMNS_LIST);
            }
        }
        return assets;
    }

    private AssetFilterBodyDto createRequestBody(QueryParamDto queryParamDto) {
        var providerId = queryParamDto.getProviderId();
        var countryCode = queryParamDto.getCountryCode();
        var programId = queryParamDto.getProgramId();
        var programType = queryParamDto.getProgramType();
        var mediaStatus = queryParamDto.getMediaStatus();
        var sortBy = queryParamDto.getSortBy();

        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .filters(new ArrayList<>()).build();
        filterBody.setColumns(Constants.PUBLIC_API_COLUMNS_LIST);

        if (!Constants.STRING_ALL.equalsIgnoreCase(providerId)) {
            filterBody.getFilters().add(
                FilterDto.builder().key("vcCpId").type(Constants.TYPE_SEARCH)
                    .values(Arrays.stream(providerId.split(",")).map(String::trim).toList())
                    .build());
        }
        if (!Constants.STRING_ALL.equalsIgnoreCase(countryCode)) {
            filterBody.getFilters().add(
                FilterDto.builder().key(Constants.COUNTRY_CODE).type(Constants.TYPE_FILTER)
                    .values(Arrays.stream(countryCode.split(",")).map(String::trim).toList())
                    .build());
        }
        if (programId != null) {
            filterBody.getFilters().add(
                FilterDto.builder().key(Constants.CONTENT_ID).type(Constants.TYPE_SEARCH)
                    .values(Arrays.stream(programId.split(",")).map(String::trim).toList())
                    .build());
        }
        if (programType != null) {
            programType = programType.toUpperCase();
            filterBody.getFilters().add(
                FilterDto.builder().key("type").type(Constants.TYPE_FILTER)
                    .values(Arrays.stream(programType.split(",")).map(String::trim).toList())
                    .build());
        }
        if (mediaStatus != null) {
            filterBody.getFilters().add(
                FilterDto.builder().key("status").type(Constants.TYPE_FILTER)
                    .values(Arrays.stream(mediaStatus.split(",")).map(String::trim).toList())
                    .build());
        }
        if (sortBy == null) {
            filterBody.setSortBy(List.of(SortDto.builder().field(Constants.DEFAULT_FILTER_FIELD)
                .order(Constants.DEFAULT_SORT_ORDER).build()));
        } else {
            List<String> sorts = Arrays.stream(sortBy.split(",")).map(String::trim).toList();
            filterBody.setSortBy(new ArrayList<>());
            for (var sort : sorts) {
                if (sort.contains(Constants.DESC_SORT_DELIMITER)) {
                    filterBody.getSortBy().add(
                        SortDto.builder().field(sort.substring(1))
                            .order(Constants.DEFAULT_SORT_ORDER).build());
                } else {
                    filterBody.getSortBy().add(
                        SortDto.builder().field(sort).order(Constants.ASC_SORT_ORDER).build());
                }
            }
        }

        return filterBody;
    }
}
