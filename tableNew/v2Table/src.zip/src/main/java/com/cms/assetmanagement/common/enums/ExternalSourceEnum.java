package com.cms.assetmanagement.common.enums;

import lombok.Getter;

@Getter
public enum ExternalSourceEnum {
    GVD("GVD"),
    ONAPI("ONAPI");

    private final String value;

    ExternalSourceEnum(String value) {
        this.value = value;
    }
}
