package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssetImageDto {

    private String contentId;
    private String providerId;
    private String countryCode;
    private String imageUrlOriginal;
    private String imageUrlProcessed;
    private String imageType;
    private String isDefault;
    private String feedWorker;
    private String crctrId;
    private String regrId;
    private String imgDimension;


}