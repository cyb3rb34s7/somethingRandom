package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Release {
    private String country;
    private String type;
    private String date;
    private String medium;
    private String programServiceId;
}
