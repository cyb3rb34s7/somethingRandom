package com.cms.assetmanagement.common.util;

import com.cms.assetmanagement.common.Constants;
import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AssetTableColumnMapping {

    @Bean
    public Map<String, String> initializeTableColumnMapping() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("id", "ID");
        tableColumnMap.put("contentId", "CONTENT_ID");
        tableColumnMap.put("countryCode", "CNTY_CD");
        tableColumnMap.put("type", "TYPE");
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("runningTime", "RUNNING_TIME");
        tableColumnMap.put("genres", "GENRES");
        tableColumnMap.put("director", "DIRECTOR");
        tableColumnMap.put("starring", "STARRING");
        tableColumnMap.put("ratings", "RATINGS");
        tableColumnMap.put("description", "DESCR");
        tableColumnMap.put("episodeNo", "EPISODE_NO");
        tableColumnMap.put("seasonNo", "SEASON_NO");
        tableColumnMap.put("seasonId", "SEASON_ID");
        tableColumnMap.put("streamUri", "STREAM_URI");
        tableColumnMap.put("releaseDate", "REL_DATE");
        tableColumnMap.put("expiryDate", "EXP_DATE");
        tableColumnMap.put("showId", "SHOW_ID");
        tableColumnMap.put("regDate", "REG_DT");
        tableColumnMap.put("updateDate", "UPD_DT");
        tableColumnMap.put("regrId", "REGR_ID");
        tableColumnMap.put("crctrId", "CRCTR_ID");
        tableColumnMap.put("vcCpId", "VC_CP_ID");
        tableColumnMap.put("imageCircle", "IMG_CIRCLE");
        tableColumnMap.put("webVttUrl", "WEBVTT_URL");
        tableColumnMap.put("thumbnailUrl", "THUMBNAIL_URL");
        tableColumnMap.put("audioLang", "AUDIO_LANG");
        tableColumnMap.put("subtitleLang", "SUBTITLE_LANG");
        tableColumnMap.put("deeplinkPayload", "DEEPLINK_PAYLOAD");
        tableColumnMap.put("audioCode", "AUDIO_CD");
        tableColumnMap.put("subtitleCode", "SUBTITLE_CD");
        tableColumnMap.put("quality", "QUALITY");
        tableColumnMap.put("vcSvcId", "VC_SVC_ID");
        tableColumnMap.put("deeplinkId", "DEEPLINK_ID");
        tableColumnMap.put("fileName", "FILE_NAME");
        tableColumnMap.put("dataplusYn", "DATAPLUS_YN");
        tableColumnMap.put("nonAdStreamUri", "NON_AD_STREAM_URI");
        tableColumnMap.put("status", "ASSET_CURRENT_STATUS");
        tableColumnMap.put("addedFrom", "ADDED_FROM");
        tableColumnMap.put("artist", "ARTIST");
        tableColumnMap.put("availableStarting", "AVAILABLE_STARTING");
        tableColumnMap.put("identifierId", "IDENTIFIER_ID");
        tableColumnMap.put("contentTier", "CONTENT_TIER");
        tableColumnMap.put("chapterTime", "CHAPTER_TIME");
        tableColumnMap.put("chapterDescription", "CHAPTER_DESC");
        tableColumnMap.put("assetId", "ASSET_ID");
        tableColumnMap.put("qcPassReason", "PASS_REASON");
        tableColumnMap.put("adTag", "AD_TAG");
        tableColumnMap.put("contentPartner", "CONTENT_PARTNER");
        tableColumnMap.put("platformTag", "PLATFORM_TAG");
        tableColumnMap.put("feedWorker", "FEED_WORKER");
        tableColumnMap.put("totalAvailableStarting", "TOTAL_AVAILABLE_STARTING");
        tableColumnMap.put("totalAvailableEnding", "TOTAL_AVAILABLE_ENDING");
        tableColumnMap.put("liveOnDevice", "LIVE_ON_DEVICE");
        tableColumnMap.put("language", Constants.LANGUAGE_STR);

        tableColumnMap.put("cpName", "CONTENT_PARTNER");
        tableColumnMap.put("tiName", "VC_CP_NM");
        tableColumnMap.put("drm", "DRM");
        tableColumnMap.put("externalId", "EXT_ID");
        tableColumnMap.put("licenseRange", "LICENSE_RANGE");
        tableColumnMap.put("licenseStatus", "LICENSE_STATUS");
        tableColumnMap.put("licenseWindow", "LICENSE_WINDOW");
        tableColumnMap.put("licenseWindowList", "LICENSE_WINDOW_LIST");
        tableColumnMap.put("eventWindowList", "EVENT_WINDOW_LIST");
        tableColumnMap.put("externalProgramId", "EXTERNAL_PROGRAM_ID");
        tableColumnMap.put("externalIdProvider", "EXT_PROVIDER");
        tableColumnMap.put("externalProviderList", "EXTERNAL_PROVIDER_LIST");
        tableColumnMap.put("externalProvidersList", "EXTERNAL_PROVIDER_LIST");
        tableColumnMap.put("lockedFields", "LOCKED_FIELDS");

        tableColumnMap.put("seriesDescription", "SERIES_DESCR");
        tableColumnMap.put("isCmsProd", "CMS_IS_PRD");
        tableColumnMap.put("isReleased", "IS_RELEASED");
        tableColumnMap.put("isSyncBlocked", "IS_SYNC_BLOCKED");
        tableColumnMap.put("prodStatus", "PROD_STATUS");
        tableColumnMap.put("cast", "CAST");
        tableColumnMap.put("parentalRatings", "PARENTAL_RATINGS");
        tableColumnMap.put("showTitle", "SHOW_TITLE");
        tableColumnMap.put("seasonTitle", "SEASON_TITLE");
        tableColumnMap.put("dbStatus", "DB_STATUS");

        tableColumnMap.put("onDeviceTrans", "ONDEVICE_TRANS_YN");
        tableColumnMap.put("eventStarting", "EVENT_STARTING");
        tableColumnMap.put("eventEnding", "EVENT_ENDING");
        tableColumnMap.put("eventRange", "EVENT_RANGE");

        tableColumnMap.put("streamType", "STREAM_TYPE");

        tableColumnMap.put("assetIngestionRange", "ASSET_INGESTION_RANGE");
        tableColumnMap.put("assetUpdateRange", "ASSET_UPDATE_RANGE");
        tableColumnMap.put("licenseStatusRange", "LICENSE_STATUS_RANGE");
        tableColumnMap.put("history", "HISTORY");

        tableColumnMap.put("imageLandscapeOriginal", "IMG_LANDSCAPE_ORIGINAL");
        tableColumnMap.put("imagePortraitOriginal", "IMG_PORTRAIT_ORIGINAL");
        tableColumnMap.put("imageLandscape", "IMG_LANDSCAPE");
        tableColumnMap.put("imagePortrait", "IMG_PORTRAIT");

        tableColumnMap.put("imageLandscapeDimension", "IMG_LANDSCAPE_W_H");
        tableColumnMap.put("imagePortraitDimension", "IMG_PORTRAIT_W_H");
        tableColumnMap.put("imageCircleOriginal", "IMG_CIRCLE_ORIGINAL");

        tableColumnMap.put("imagePortraitIconic", "IMG_PORTRAIT_ICONIC");
        tableColumnMap.put("imageLandscapeIconic", "IMG_LANDSCAPE_ICONIC");
        tableColumnMap.put("imagePortraitIconicOriginal", "IMG_PORTRAIT_ICONIC_ORIGINAL");
        tableColumnMap.put("imageLandscapeIconicOriginal", "IMG_LANDSCAPE_ICONIC_ORIGINAL");
        tableColumnMap.put("imageLandscapeIconicDimension", "IMG_LANDSCAPE_ICONIC_W_H");
        tableColumnMap.put("imagePortraitIconicDimension", "IMG_PORTRAIT_ICONIC_W_H");

        tableColumnMap.put("processedImageUrl", "PROCESSED_IMG_URL");

        tableColumnMap.put("imageTitleTreatmentDimension", "IMG_TITLE_TREATMENT_W_H");
        tableColumnMap.put("imageLandscapeBackdropDimension", "IMG_LANDSCAPE_BACKDROP_W_H");
        tableColumnMap.put("imageTitleTreatment", "IMG_TITLE_TREATMENT");
        tableColumnMap.put("imageTitleTreatmentOriginal", "IMG_TITLE_TREATMENT_ORIGINAL");
        tableColumnMap.put("imageLandscapeBackdrop", "IMG_LANDSCAPE_BACKDROP");
        tableColumnMap.put("imageLandscapeBackdropOriginal", "IMG_LANDSCAPE_BACKDROP_ORIGINAL");
        tableColumnMap.put("deltaType", "DELTA_TYPE");

        // Export column mappings
        tableColumnMap.put("externalProvider", "EXTERNAL_PROGRAM_ID");
        tableColumnMap.put("mainTitleLanguage", Constants.LANGUAGE_STR);
        tableColumnMap.put("shortTitleLanguage", Constants.LANGUAGE_STR);

        tableColumnMap.put("ingestionType", "INGESTION_TYPE");
        tableColumnMap.put("subtitles", "SUBTITLES");
        tableColumnMap.put("attributes", "ATTRIBUTES");
        tableColumnMap.put("subType", "SUBTYPE");
        tableColumnMap.put("airType", "AIR_TYPE");
        tableColumnMap.put("matchInformation", "MATCH_INFORMATION");
        tableColumnMap.put("geoRestrictionYn", "GEORESTRICTION_YN");
        tableColumnMap.put("geoRestrictions", "GEO_RESTRICTIONS");
        return tableColumnMap;
    }
}
