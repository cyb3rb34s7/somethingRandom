package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EventDeleteDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.service.AssetInsertHelper;
import com.cms.assetmanagement.service.VodAssetWindowService;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class VodAssetWindowServiceImpl implements VodAssetWindowService {

    private final VodAssetMapper vodAssetMapper;
    private final AssetInsertHelper assetInsertHelper;
    private final Utils utils;

    //    @Autowired
    public VodAssetWindowServiceImpl(VodAssetMapper vodAssetMapper,
        AssetInsertHelper assetInsertHelper, Utils utils) {
        this.vodAssetMapper = vodAssetMapper;
        this.assetInsertHelper = assetInsertHelper;
        this.utils = utils;
    }

    @Override
    @Transactional("contentTransactionManager")
    public void updateEventWindows(VodAssetDto vodAssetDto) {
        log.info("Updating Event Windows in STD_VC_VOD_CONTENT: {}", vodAssetDto);
        vodAssetMapper.updateAsset(vodAssetDto);
        List<AssetKeyDto> assetKeyList = utils.createAssetList(vodAssetDto);
        assetInsertHelper.deleteAndInsertEventWindowData(assetKeyList,
            vodAssetDto.getEventWindowList());

        if (!utils.isTvplusDeltaFeedWorker(vodAssetDto)) {
            log.info("Updating Event Windows in STD_CMS_VOD_CP_CONTENT:{}", vodAssetDto);
            vodAssetMapper.updateCPAsset(vodAssetDto);
        }
    }
    
    @Override
    @Transactional("contentTransactionManager")
    public void updateLicenseWindows(VodAssetDto vodAssetDto) {
        log.info("Updating License Windows in STD_VC_VOD_CONTENT: {}", vodAssetDto);
        vodAssetMapper.updateAsset(vodAssetDto);

        List<AssetKeyDto> assetKeyList = utils.createAssetList(vodAssetDto);
        assetInsertHelper.deleteAndInsertLicenseWindowData(assetKeyList,
            vodAssetDto.getLicenseWindowList());

        if (!utils.isTvplusDeltaFeedWorker(vodAssetDto)) {
            log.info("Updating License Windows in STD_CMS_VOD_CP_CONTENT:{}", vodAssetDto);
            vodAssetMapper.updateCPAsset(vodAssetDto);
        }
    }

    @Override
    @Transactional("contentTransactionManager")
    public void removeEventWindows(EventDeleteDto eventDeleteDto) {
        log.info("Removing Event Windows in STD_VC_VOD_CONTENT: {}", eventDeleteDto);
        switch (eventDeleteDto.getAction().toUpperCase()) {
            case Constants.REMOVE_ALL -> {
                AssetKeyDto assetKeyDto = AssetKeyDto.builder()
                    .contentId(eventDeleteDto.getContentId())
                    .vcCpId(eventDeleteDto.getVcCpId())
                    .countryCode(eventDeleteDto.getCountryCode()).build();

                vodAssetMapper.deleteEventWindowData(List.of(assetKeyDto));
            }
            case Constants.REMOVE -> {
                if (eventDeleteDto.getEventIds() != null && !eventDeleteDto.getEventIds()
                    .isEmpty()) {
                    vodAssetMapper.deleteEventWindowsByEventIds(eventDeleteDto);
                }
            }
            default -> throw new InvalidInputDataException(
                "Event delete action can be only one of " + List.of(
                    Constants.REMOVE, Constants.REMOVE_ALL));
        }

        vodAssetMapper.updateEventInfoAfterDelete(eventDeleteDto);
        vodAssetMapper.updateCPEventInfoAfterDelete(eventDeleteDto);
    }
}