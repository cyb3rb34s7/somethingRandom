package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class CountDto {
    private int coveredCount;
    private String coveredRate;
    private int matchedCount;
    private String matchedRate;
    private int totalCount;
}
