package com.cms.assetmanagement.common.window_util.model;

public enum WindowType {
    LICENSE_WINDOW,
    EVENT_WINDOW;
}
