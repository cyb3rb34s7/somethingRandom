package com.cms.assetmanagement.service;

import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import java.util.List;

public interface ImageProcessingService {

    List<ProcessedImageDto> getProcessedImagesByReqId(String requestId);

    void initiateImageProcess(PreProcessImageDto preProcessImageDto);

    void insertPreProcessingUrls(PreProcessImageDto preProcessImageDto);

    void deleteImageByReqId(String requestId);
}