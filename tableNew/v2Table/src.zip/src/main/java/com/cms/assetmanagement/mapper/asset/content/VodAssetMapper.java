package com.cms.assetmanagement.mapper.asset.content;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.AssetSeriesInfoDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetSubtitleDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.ContentDetailsDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.EventDeleteDto;
import com.cms.assetmanagement.model.FeedWorkerPriority;
import com.cms.assetmanagement.model.GeoRestrictionsDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import com.cms.assetmanagement.model.RatingsDeeplinkDto;
import com.cms.assetmanagement.model.RatingsDto;
import com.cms.assetmanagement.model.ShowHierarchyDto;
import com.cms.assetmanagement.model.StreamURIDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetStatusDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.smf.AssetCountryCpLangDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

@Mapper
public interface VodAssetMapper {

    String getOracleHealthcheck();

    RatingsDeeplinkDto getRatingsDeeplinkIdDetails(String programId, String countryCode);

    AssetSeriesInfoDto getSeasonEpisodeNumberDetails(String episodeId, String countryCode);

    void updateParentDeeplinkDetails(VodAssetDto assetDto);

    void updateParentCPDeeplinkDetails(VodAssetDto assetDto);

    String getLatestEpisodeIdForSeason(String seasonId, String countryCode);

    String getLatestEpisodeIdForShow(String showId, String countryCode);

    int checkChildrenOfShow(String showId, String countryCode, String vcCpId);

    int checkProdChildrenOfSeason(String seasonId, String countryCode, String vcCpId);

    int checkProdChildrenOfShow(String showId, String countryCode, String vcCpId);


    List<VodAssetDto> getAssetByKey(List<AssetKeyDto> assetList);

    VodAssetDto getAssetParentDetails(VodAssetDto asset);

    ///////////////    Filtered Mappers  ///////////////
    Long getFilteredAssetsCount(@Param(Constants.FILTER_BDDY) AssetFilterBodyDto filterBody,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    List<VodAssetDto> getFilteredAssets(
        @Param(Constants.FILTER_BDDY) AssetFilterBodyDto filterBody,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers,
        @Param(Constants.FEED_WORKER_PRIORITY) List<FeedWorkerPriority> feedWorkerOrder,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers,
        RowBounds rowBounds
    );

    VodAssetDto getAssetView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    VodAssetDto getAssetCPView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    VodAssetDto getAssetFullFeedView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    VodAssetDto getAssetGracenoteView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    VodAssetDto getAssetONAPIView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    VodAssetDto getAssetGracenoteOnView(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode,
        @Param(Constants.EXT_FEED_WORKER) List<String> extFeedWorkers);

    List<ShowHierarchyDto> getShowHierarchy(AssetKeyDto assetKeyDto);

    List<VodAssetDto> bulkShowHierarchy(@Param(Constants.ASSET_KEY_DTO) AssetKeyDto assets,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers);

    List<VodAssetDto> bulkSeasonHierarchy(@Param(Constants.ASSET_KEY_DTO) AssetKeyDto assets,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers);

    ContentDetailsDto getEpisodeDetails(String contentId);

    List<VodAssetDto> assetDetailsByColumns(AssetByColumnsReqDto assetReqByColumns,
        List<String> extFeedWorkers);

    List<String> getGenres();

    List<String> getAudioLang();

    List<String> getSubtitleLang();

    List<String> getTechIntegrators();

    List<String> getContentPartners();

    List<PlatformTagData> getPlatforms(@Param(Constants.ASSET_KEY_DTO) AssetKeyDto assetKeyDto,
        @Param(Constants.PLATFORMS) List<String> platforms);

    List<LanguageDto> getLanguages();

    List<RatingsDto> getRatings();

    List<RatingsDto> getAllRatings();

    List<ParentalRatingsDto> getParentalRatings(AssetKeyDto assetKeyDto);

    String getDescriptionLanguage(String countryCode);

    List<AssetCountryCpLangDto> getDescriptionLangCodes();

    Long getCountOfValidatedParents(List<AssetKeyDto> assetKeyDto);

    List<String> getLangCodeByCountryCode(String countryCode);

    String getCpExternalSource(String countryCode, String cpId);


    ///////////////   Asset Details Mappers  //////////////////
    List<VodAssetStatusDto> getAssetListDetailsforUpload(
        @Param(Constants.ASSET_KEY_DTO) List<AssetKeyDto> assetKeyDto,
        @Param(Constants.FEED_WORKERS) List<String> feedWorkers);

    VodAssetDto getAssetDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    VodAssetDto getAssetCpDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    VodAssetDto getAssetFullFeedDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AssetExternalIdDto> getExternalProviderDetails(
        @Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AssetDrmDto> getDRMDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AdBreaksDto> getAdBreakDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<PlatformTagData> getPlatformDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AssetRatingDto> getAssetRatings(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AssetCastDto> getCast(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);


    List<LicenseWindowDto> getLicenseWindow(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<EventWindowDto> getEventWindowDetails(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<AssetSubtitleDto> getSubtitles(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<GeoRestrictionsDto> getGeoRestrictions(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    GracenoteMapDto getAssetGNMap(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);


    List<StreamURIDto> getStreamUris(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    List<StreamURIDto> getRecentStreamUris(@Param(Constants.CONTENT_ID) String contentId,
        @Param(Constants.CP_ID) String cpId,
        @Param(Constants.COUNTRY_CODE) String countryCode);

    ///////////////    Update Mappers ///////////////

    void updateAsset(@Param(Constants.VOD_ASSET_DTO) VodAssetDto vodAssetDto);

    void updateCPAsset(@Param(Constants.VOD_ASSET_DTO) VodAssetDto vodAssetDto);

    void updateAssetByBulk(AssetUpdateByBulkDto assetUpdateByBulkDto);

    void updateDRMData(@Param(Constants.DRM_DETAILS_STRING) List<AssetDrmDto> drmDetailsList);

    void updateExternalIdData(
        @Param(Constants.EXTERNAL_DETAILS_STRING) List<AssetExternalIdDto> externalDetailsList);

    void updateAdBreakData(@Param(Constants.ADBREAK_STRING) List<AdBreaksDto> adBreakList);

    void updatePlatformData(
        @Param(Constants.PLATFORM_TAG_DATA) List<PlatformTagData> platformDataList);

    void updateAssetStatus(@Param(Constants.UPDATED_STATUS) AssetStatusUpdateDto updatedStatus);

    
    ///////////////  Insert Mappers ///////////////
    void insertAsset(VodAssetDto vodAssetDto);

    void insertCpAsset(VodAssetDto vodAssetDto);

    void insertFullFeedContent(VodAssetDto vodAssetDto);

    void insertDRMData(List<AssetDrmDto> assetDrmList);

    void insertExternalIdData(List<AssetExternalIdDto> assetExternalIdList);

    void insertAdBreakData(List<AdBreaksDto> assetAdBreakList);

    void insertPlatformData(List<PlatformTagData> assetPlatformList);

    void insertRatingData(List<AssetRatingDto> assetRatingList);

    void insertCastData(List<AssetCastDto> assetCastList);

    void insertLicenseWindowData(List<LicenseWindowDto> licenseWindowList);

    void insertEventWindowData(List<EventWindowDto> eventWindowList);

    void insertSubtitles(List<AssetSubtitleDto> subtitleList);

    void insertGeoRestrictions(List<GeoRestrictionsDto> geoRestrictionsList);

    void insertBatchDeleteHistory(List<AssetKeyDto> assetList);

    void insertGracenoteMap(GracenoteMapDto gracenote);

    void insertLastStatusData(List<AssetKeyDto> assetList);

    ///////////////  Delete Mappers ///////////////

    void softDeleteFullFeedAsset(String contentId, String vcCpId, String countryCode);

    void softDeleteContentAsset(String contentId, String vcCpId, String countryCode);

    void deleteAsset(List<AssetKeyDto> assetList);

    void deleteCpAsset(List<AssetKeyDto> assetList);

    void deleteFullFeedContent(List<AssetKeyDto> assetList);

    void deleteDRMByKeys(List<AssetDrmDto> assetDrmList);

    void deleteExternalIdByKeys(List<AssetExternalIdDto> assetExternalIdList);

    void deleteAdBreakByKeys(List<AdBreaksDto> assetAdBreakList);

    void deletePlatformByKeys(List<PlatformTagData> platformList);

    void deletePlatformDataByKeys(@Param(Constants.ASSETS) VodAssetDto assets);

    void deleteDRMData(List<AssetKeyDto> assetList);

    void deleteExternalIdData(List<AssetKeyDto> assetList);

    void deleteAdBreaks(List<AssetKeyDto> assetList);

    void deletePlatforms(List<AssetKeyDto> assetList);

    void deleteRatingData(List<AssetKeyDto> assetList);

    void deleteCastData(List<AssetKeyDto> assetList);

    void deleteLicenseWindowData(List<AssetKeyDto> assetList);

    void deleteEventWindowData(List<AssetKeyDto> assetList);

    void deleteGracenoteMapData(List<AssetKeyDto> assetList);

    void deleteSubtitles(List<AssetKeyDto> assetList);

    void deleteGeoRestrictions(List<AssetKeyDto> assetList);

    void deleteGracenoteMap(GracenoteMapDto gracenote);

    void deleteLastStatusData(List<AssetKeyDto> assetList);

    ///////////////  Validation Mappers ///////////////
    List<String> validateExternalId(List<AssetExternalIdDto> externalIdDtoList);

    boolean validateDeltaSync(String contentId, String countryCode, String vcCpId,
        String eventType);

    boolean validateShow(EditValidationDto editValidation);

    boolean validateSeasonForEpisode(EditValidationDto editValidation);

    boolean validateEpisode(EditValidationDto editValidation);

    boolean validateSeasonNo(EditValidationDto editValidation);

    ///////////////  License & Event Window ///////////////
    boolean doesAssetExists(String programId, String cpId, String countryCode);

    List<LicenseWindowDto> getLicenseWindows(String programId, String cpId, String countryCode);

    List<EventWindowDto> getEventWindows(String programId, String cpId, String countryCode);

    void updateLicenseWindow(String contentId, String countryCode, String vcCpId,
        LicenseWindowDto activeSlot);

    void updateEventWindow(String contentId, String countryCode, String vcCpId,
        EventWindowDto activeSlot);

    void updateCPLicenseWindow(String contentId, String countryCode, String vcCpId,
        LicenseWindowDto activeSlot);

    void updateCPEventWindow(String contentId, String countryCode, String vcCpId,
        EventWindowDto activeSlot);

    void deleteEventWindowsByEventIds(EventDeleteDto eventDeleteDto);

    void updateEventInfoAfterDelete(EventDeleteDto eventDeleteDto);

    void updateCPEventInfoAfterDelete(EventDeleteDto eventDeleteDto);
}
