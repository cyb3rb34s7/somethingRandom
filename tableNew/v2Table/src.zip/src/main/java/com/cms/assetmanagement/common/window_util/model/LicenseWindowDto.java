package com.cms.assetmanagement.common.window_util.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class LicenseWindowDto implements DateRangeWindow {

    @JsonAlias({"licenseId", "license_id"})
    private String licenseId;
    private String identifierId;
    private String programId;
    private String providerId;
    private String countryCode;
    @NotNull
    @JsonAlias({"availableStarting", "available_starting"})
    private String availableStarting;
    @JsonAlias({"availableEnding", "available_ending"})
    private String availableEnding;
    private String windowStatus;
    private String regrId;
    private String crctrId;
    private String feedWorker;

    @Override
    public String getWindowId() {
        return licenseId;
    }

    @Override
    public String getStartingTime() {
        return availableStarting;
    }

    @Override
    public String getEndingTime() {
        return availableEnding;
    }

    @Override
    public WindowType getWindowType() {
        return WindowType.LICENSE_WINDOW;
    }

    @Override
    public void setWindowId(String id) {
        licenseId = id;
    }

    @Override
    public void setStartingTime(String startingTime) {
        availableStarting = startingTime;
    }

    @Override
    public void setEndingTime(String endingTime) {
        availableEnding = endingTime;
    }

}


