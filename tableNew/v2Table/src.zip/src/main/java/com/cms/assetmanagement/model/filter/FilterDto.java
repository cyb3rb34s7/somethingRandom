package com.cms.assetmanagement.model.filter;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FilterDto {

    private String type;
    private String key;
    private String displayText;
    private List<String> values;
    private Integer colSpan;

}
