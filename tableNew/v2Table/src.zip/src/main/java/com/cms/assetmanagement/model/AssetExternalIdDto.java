package com.cms.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssetExternalIdDto {

    private String programId;
    private String externalProgramId;
    private String idType;
    private String provider;
    private String idProvider;
    private String countryCode;
    private String regrId;
    private String crctrId;
    private String feedWorker;

}
