package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetExportMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.mapper.asset.metadata.VodAssetMetadataMapper;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetCountDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetLockedFieldDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.AssetSubtitleDto;
import com.cms.assetmanagement.model.BulkRevokeHierarchy;
import com.cms.assetmanagement.model.CountryDto;
import com.cms.assetmanagement.model.FeedWorkerPriority;
import com.cms.assetmanagement.model.GeoRestrictionsDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.PlatformTagData;
import com.cms.assetmanagement.model.RatingsDto;
import com.cms.assetmanagement.model.ShowHierarchyDto;
import com.cms.assetmanagement.model.StreamURIDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetStatusDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.SortDto;
import com.cms.assetmanagement.model.smf.AssetCountryCpLangDto;
import com.cms.assetmanagement.service.VodAssetService;
import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class VodAssetServiceImpl implements VodAssetService {

    private final VodAssetMapper vodAssetMapper;
    private final VodAssetMetadataMapper vodAssetMetadataMapper;
    private final DateRangeWindowService dateRangeWindowService;
    private final VodAssetExportMapper vodAssetExportMapper;
    private final VodAssetColumnLockMapper vodAssetColumnLockMapper;
    private final Utils utils;

    @Value("${CMS_FEED_WORKERS}")
    public String cmsFeedWorkers;

    @Value("${EXTERNAL_FEED_WORKERS}")
    public String externalFeedWorkers;

    @Value("${REGION}")
    public String region;

    List<FeedWorkerPriority> feedWorkerOrder = new ArrayList<>();
    List<String> feedWorkerList = new ArrayList<>();
    List<String> extFeedWorkersList = new ArrayList<>();

    //    @Autowired
    public VodAssetServiceImpl(VodAssetMapper vodAssetMapper,
        @Autowired(required = false) VodAssetMetadataMapper vodAssetMetadataMapper,
        DateRangeWindowService dateRangeWindowService,
        VodAssetExportMapper vodAssetExportMapper,
        VodAssetColumnLockMapper vodAssetColumnLockMapper, Utils utils) {
        this.vodAssetMapper = vodAssetMapper;
        this.vodAssetMetadataMapper = vodAssetMetadataMapper;
        this.dateRangeWindowService = dateRangeWindowService;
        this.vodAssetExportMapper = vodAssetExportMapper;
        this.vodAssetColumnLockMapper = vodAssetColumnLockMapper;
        this.utils = utils;
    }

    @PostConstruct
    public void init() {
        feedWorkerList = Arrays.asList(cmsFeedWorkers.split(","));
        extFeedWorkersList = Arrays.asList(externalFeedWorkers.split(","));

        var order = 1;
        for (String worker : feedWorkerList) {
            FeedWorkerPriority priority = FeedWorkerPriority.builder().feedWorker(worker)
                .priority(order++).build();
            feedWorkerOrder.add(priority);
        }
    }

    @Override
    public String getOracleHealthcheck() {
        return vodAssetMapper.getOracleHealthcheck();
    }

    @Override
    @Transactional("contentTransactionManager")
    public List<VodAssetDto> getFilteredAssets(AssetFilterBodyDto filterBody) {
        log.info("Getting filtered assets");

        RowBounds rowBounds;
        if (filterBody.getPagination() != null) {
            rowBounds = new RowBounds(filterBody.getPagination().getOffset(),
                filterBody.getPagination().getLimit());
        } else {
            rowBounds = new RowBounds(Constants.OFFSET_DEFAULT_VALUE,
                Constants.LIMIT_DEFAULT_VALUE);
        }

        if (filterBody.getSortBy() == null || filterBody.getSortBy().isEmpty()) {
            filterBody.setSortBy(List.of(SortDto.builder().field(Constants.DEFAULT_FILTER_FIELD)
                .order(Constants.DEFAULT_SORT_ORDER).build()));
        }
        filterBody = utils.getColumnMapping(filterBody);
        List<VodAssetDto> assets = vodAssetMapper.getFilteredAssets(filterBody,
            feedWorkerList, feedWorkerOrder, extFeedWorkersList, rowBounds);

        Map<String, String> langCodeMap = new HashMap<>();
        List<AssetCountryCpLangDto> langCodeMapDtoList = vodAssetMapper.getDescriptionLangCodes();
        langCodeMapDtoList.forEach(langConMatch -> langCodeMap.put(langConMatch.getCountry(),
            langConMatch.getLangCode()));

        if (assets != null && !assets.isEmpty()) {
            for (VodAssetDto asset : assets) {
                String licenseWindow = utils.getLicenseWindow(asset.getAvailableStarting(),
                    asset.getExpiryDate());

                String status = utils.getStatus(licenseWindow, asset.getStatus());
                status = utils.checkExternalAsset(status, asset.getFeedWorker(), feedWorkerList);
                String dbStatus = utils.checkExternalAssetForDbStatus(asset.getDbStatus(),
                    asset.getFeedWorker(), feedWorkerList);
                utils.setExternalProviderData(asset);
                asset.setLicenseWindow(licenseWindow);
                asset.setStatus(status);
                asset.setDbStatus(dbStatus);
                asset.setLanguage(langCodeMap.getOrDefault(asset.getCountryCode(), ""));

                asset.setLiveOnDevice(utils.checkLiveOnDevice(asset));
            }
        }
        return assets;
    }

    @Override
    @Transactional("contentTransactionManager")
    public AssetCountDto getFilteredAssetsCount(AssetFilterBodyDto filterBody, String tab) {
        log.info("Getting filtered assets count");
        filterBody = utils.getColumnMapping(filterBody);
        List<String> appliedStatusFilter = new ArrayList<>();
        if (filterBody.getFilters() != null) {
            for (FilterDto filter : filterBody.getFilters()) {
                if (Constants.STATUS_COLUMN.equals(filter.getKey())) {
                    appliedStatusFilter = filter.getValues();
                    break;
                }
            }
        }
        return AssetCountDto.builder().
            allAssets(vodAssetMapper.getFilteredAssetsCount(updateFilters(filterBody,
                    Constants.ALL_TAB.equalsIgnoreCase(tab) ? appliedStatusFilter
                        : Constants.ALL_STATUS, Constants.ALL_TAB),
                feedWorkerList, extFeedWorkersList)).
            assetsInQC(vodAssetMapper.getFilteredAssetsCount(updateFilters(filterBody,
                    Constants.QC_TAB.equalsIgnoreCase(tab) ? appliedStatusFilter
                        : Constants.IN_QC_STATUS, Constants.QC_TAB),
                feedWorkerList, extFeedWorkersList)).
            assetsInProduction(vodAssetMapper.getFilteredAssetsCount(updateFilters(filterBody,
                    Constants.PROD_TAB.equalsIgnoreCase(tab) ? appliedStatusFilter
                        : Constants.IN_PRODUCTION_STATUS, Constants.PROD_TAB),
                feedWorkerList, extFeedWorkersList)).build();
    }


    @Override
    @Transactional("contentTransactionManager")
    public VodAssetDetailedDto getAssetDetails(String contentId, String cpId, String countryCode) {
        log.info("Getting asset details for contentId : {}", contentId);

        VodAssetDto assetDetails = vodAssetMapper.getAssetDetails(contentId, cpId, countryCode);
        VodAssetDto assetCpDetails = null;
        if (assetDetails != null) {
            if (utils.isTvplusDeltaFeedWorker(assetDetails)) {
                assetCpDetails = vodAssetMapper.getAssetFullFeedDetails(contentId, cpId,
                    countryCode);
            } else {
                assetCpDetails = vodAssetMapper.getAssetCpDetails(contentId, cpId, countryCode);
            }
        }
        List<AssetExternalIdDto> externalProviderDetails = vodAssetMapper.getExternalProviderDetails(
            contentId, cpId, countryCode);
        List<AssetDrmDto> drmDetails = vodAssetMapper.getDRMDetails(contentId, cpId, countryCode);
        List<AdBreaksDto> adBreak = vodAssetMapper.getAdBreakDetails(contentId, cpId, countryCode);
        List<PlatformTagData> platform = vodAssetMapper.getPlatformDetails(contentId, cpId,
            countryCode);
        List<AssetRatingDto> ratings = vodAssetMapper.getAssetRatings(contentId, cpId,
            countryCode);
        List<AssetCastDto> cast = vodAssetMapper.getCast(contentId, cpId,
            countryCode);
        List<LicenseWindowDto> licenseWindowList = vodAssetMapper.getLicenseWindow(contentId, cpId,
            countryCode);
        List<EventWindowDto> eventWindowList = vodAssetMapper.getEventWindowDetails(contentId, cpId,
            countryCode);
        List<AssetSubtitleDto> subtitleList = vodAssetMapper.getSubtitles(contentId, cpId,
            countryCode);
        List<GeoRestrictionsDto> geoRestrictionsList = vodAssetMapper.getGeoRestrictions(contentId,
            cpId, countryCode);
        GracenoteMapDto gracenoteMaintainMap = vodAssetMapper.getAssetGNMap(contentId, cpId,
            countryCode);
        List<AssetLockedFieldDto> lockedFields = vodAssetColumnLockMapper.getAllColumnLockByContentId(
            AssetKeyDto.builder().countryCode(countryCode).vcCpId(cpId).contentId(contentId)
                .build());

        if (assetDetails != null) {
            String licenseWindow = utils.getLicenseWindow(assetDetails.getAvailableStarting(),
                assetDetails.getExpiryDate());
            String status = utils.getStatus(licenseWindow, assetDetails.getStatus());
            status = utils.checkExternalAsset(status, assetDetails.getFeedWorker(),
                feedWorkerList);
            String dbStatus = utils.checkExternalAssetForDbStatus(assetDetails.getDbStatus(),
                assetDetails.getFeedWorker(), feedWorkerList);
            utils.setExternalProviderData(assetDetails);

            assetDetails.setLicenseWindow(licenseWindow);
            assetDetails.setStatus(status);

            assetDetails.setDbStatus(dbStatus);
        }

        return VodAssetDetailedDto.builder()
            .vodAsset(assetDetails)
            .vodCpAsset(assetCpDetails)
//            .vodFullFeedAsset(assetFullFeedDetails)
            .externalProvider(externalProviderDetails)
            .drm(drmDetails)
            .adBreak(adBreak)
            .platform(platform)
            .rating(ratings)
            .cast(cast)
            .licenseWindowList(licenseWindowList)
            .eventWindowList(eventWindowList)
            .subtitles(subtitleList)
            .geoRestrictions(geoRestrictionsList)
            .gracenoteMaintainMap(gracenoteMaintainMap).lockedFields(lockedFields).build();
    }


    @Override
    public List<VodAssetStatusDto> getAssetListDetailsforUpload(AssetKeyListDto assetKeyList) {
        List<VodAssetStatusDto> assetDetailsList = new ArrayList<>();
        if (assetKeyList.getAssetList() != null && !assetKeyList.getAssetList().isEmpty()) {
            log.info("Getting Asset Details using Ids");
            assetDetailsList = vodAssetMapper.getAssetListDetailsforUpload(
                assetKeyList.getAssetList(), feedWorkerList);
        }
        return assetDetailsList;
    }

    @Override
    public List<ShowHierarchyDto> getShowHierarchy(@Valid AssetKeyDto assetShowKeyDto) {
        return vodAssetMapper.getShowHierarchy(assetShowKeyDto);
    }

    @Override
    public List<CountryDto> getCountryCodes() {
        log.info("Getting country codes from master table");
        return vodAssetMetadataMapper.getCountryCodes(region);
    }

    @Override
    @Transactional("contentTransactionManager")
    public List<FilterDto> getFilters() {
        log.info("Getting master filters");
        List<FilterDto> filterDtos = new ArrayList<>();
        List<String> langCode = vodAssetMapper.getAudioLang();
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER).key(Constants.AUDIO_LANG)
            .displayText(Constants.AUDIO_LANG_TEXT)
            .values(langCode).colSpan(2).build());
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER).key(Constants.SUBTITLE_LANG)
            .displayText(Constants.SUBTITLE_LANG_TEXT)
            .values(langCode).colSpan(2).build());
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER).key(Constants.COUNTRY_CODE)
            .displayText(Constants.COUNTRY_TEXT)
            .values(vodAssetMetadataMapper.getCountries(region)).colSpan(2).build());
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER).key(Constants.GENRE)
            .displayText(Constants.GENRE_TEXT)
            .values(vodAssetMapper.getGenres()).colSpan(2).build());
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER).key(Constants.TI_NAME)
            .displayText(Constants.TECH_INTEGRATOR_TEXT)
            .values(vodAssetMapper.getTechIntegrators()).colSpan(1).build());
        filterDtos.add(FilterDto.builder().type(Constants.TYPE_FILTER)
            .key(Constants.CONTENT_PARTNER)
            .displayText(Constants.CONTENT_PARTNER_TEXT)
            .values(vodAssetMapper.getContentPartners()).colSpan(1).build());

        return filterDtos;
    }

    /* ////////////////// Export Methods /////////////// */

    @Override
    public List<VodAssetDto> getAssetsForExport(AssetFilterBodyDto filterBody) {
        log.info("Fetching Assets for Export. {}", filterBody);

        if (filterBody.getColumns() == null || filterBody.getColumns().isEmpty()) {
            filterBody.setColumns(Constants.EXPORT_COLUMNS_LIST);
        }

        if (filterBody.getSortBy() == null || filterBody.getSortBy().isEmpty()) {
            filterBody.setSortBy(List.of(SortDto.builder().field(Constants.DEFAULT_FILTER_FIELD)
                .order(Constants.DEFAULT_SORT_ORDER).build()));
        }

        if (filterBody.getPagination() != null) {
            // +1 because RN works inclusive of start and end
            int newLimit =
                filterBody.getPagination().getLimit() + filterBody.getPagination().getOffset();
            int newOffset = filterBody.getPagination().getOffset() + 1;
            filterBody.getPagination().setLimit(newLimit);
            filterBody.getPagination().setOffset(newOffset);
        }

        List<String> fieldsToRetain = filterBody.getColumns();
        filterBody = utils.getColumnMapping(filterBody);
        List<VodAssetDto> assets = vodAssetExportMapper.getAssetsForExport(filterBody,
            feedWorkerList, feedWorkerOrder);

        if (assets != null && !assets.isEmpty()) {
            for (VodAssetDto asset : assets) {
                try {
                    String licenseWindow = utils.getLicenseWindow(asset.getAvailableStarting(),
                        asset.getExpiryDate());

                    String status = utils.getStatus(licenseWindow, asset.getStatus());
                    status = utils.checkExternalAsset(status, asset.getFeedWorker(),
                        feedWorkerList);
                    String dbStatus = utils.checkExternalAssetForDbStatus(asset.getDbStatus(),
                        asset.getFeedWorker(), feedWorkerList);
                    utils.setExternalProviderData(asset);
                    asset.setLicenseWindow(licenseWindow);
                    asset.setStatus(status);
                    asset.setDbStatus(dbStatus);

                    asset.setLiveOnDevice(utils.checkLiveOnDevice(asset));

                    Utils.retainOnlyFields(asset, fieldsToRetain);
                } catch (Exception e) {
                    log.info("Asset failed in export: {}", asset.getContentId());
                }

            }
        }
        return assets;
    }

    @Override
    public long getExportAssetCount(AssetFilterBodyDto filterBody) {
        log.info("Fetching count for Export Assets");
        filterBody = utils.getColumnMapping(filterBody);
        return vodAssetExportMapper.getExportAssetCount(filterBody, feedWorkerList,
            feedWorkerOrder);
    }

    @Override
    public LicenseWindowDto getActiveWindow(List<LicenseWindowDto> licenseWindows) {
        dateRangeWindowService.sortWindows(licenseWindows);
        return dateRangeWindowService.findUpdateSlot(licenseWindows);
    }


    @Override
    @Transactional("contentTransactionManager")
    public BulkRevokeHierarchy bulkRevokeHierarchy(@Valid List<AssetKeyDto> assetsList) {
        BulkRevokeHierarchy bulkRevokeHierarchy = BulkRevokeHierarchy.builder().build();
        if (assetsList != null && !assetsList.isEmpty()) {
            assetsList.forEach(asset -> {
                switch (asset.getType()) {
                    case Constants.SHOW:
                        log.info("Fetching show hierarchy for contentId: {}", asset.getContentId());
                        addAssetListToHierarchy(bulkRevokeHierarchy,
                            vodAssetMapper.bulkShowHierarchy(asset, feedWorkerList));
                        break;
                    case Constants.SEASON:
                        log.info("Fetching season hierarchy for contentId: {}",
                            asset.getContentId());
                        addAssetListToHierarchy(bulkRevokeHierarchy,
                            vodAssetMapper.bulkSeasonHierarchy(asset, feedWorkerList));
                        break;
                    default:
                        List<VodAssetDto> assetList = List.of(
                            VodAssetDto.builder().contentId(asset.getContentId())
                                .vcCpId(asset.getVcCpId())
                                .countryCode(asset.getCountryCode())
                                .seasonId(asset.getSeasonId())
                                .showId(asset.getShowId())
                                .type(asset.getType())
                                .build());
                        addAssetListToHierarchy(bulkRevokeHierarchy, assetList);
                        break;
                }
            });
        }
        return bulkRevokeHierarchy;
    }

    @Override
    public List<LanguageDto> getLanguages() {
        return vodAssetMapper.getLanguages();
    }

    @Override
    public List<VodAssetDto> assetDetailsByColumns(AssetByColumnsReqDto assetReqByColumns) {

        List<VodAssetDto> assets = vodAssetMapper.assetDetailsByColumns(
            utils.getHistoryColumnMap(assetReqByColumns), extFeedWorkersList);

        if (assets != null && !assets.isEmpty()) {
            for (VodAssetDto asset : assets) {
                if (asset.getIsCmsProd() != null) {
                    asset.setIsSyncBlocked(asset.getIsCmsProd() != 1);
                    asset.setIsReleased(asset.getIsCmsProd() != 0);
                }
            }
        }
        return assets;
    }

    @Override
    public List<RatingsDto> getRatings() {
        log.info("Getting country and TYPE wise parental Ratings");
        List<RatingsDto> ratingsResponse = vodAssetMapper.getRatings();

        ratingsResponse.forEach(parentalRatings -> {
            List<String> ratings = new ArrayList<>(
                Arrays.asList(parentalRatings.getRatingsList().split(",")));
            parentalRatings.setParentalRatings(processParentalRatings(ratings));
            parentalRatings.setRatingsList(null);
        });
        return ratingsResponse;
    }

    @Override
    public List<RatingsDto> getAllRatings() {
        log.info("Getting all Parental Ratings data.");
        List<RatingsDto> ratingsResponse = vodAssetMapper.getAllRatings();

        ratingsResponse.forEach(parentalRatings -> {
            List<String> ratings = Arrays.asList(parentalRatings.getRatingsList().split(","));

            parentalRatings.setParentalRatings(ratings);
            parentalRatings.setRatingsList(null);
        });
        return ratingsResponse;
    }

    @Override
    public List<StreamURIDto> getStreamUris(String contentId, String cpId, String countryCode) {
        List<StreamURIDto> streams = vodAssetMapper.getStreamUris(contentId, cpId, countryCode);
        if (streams != null && !streams.isEmpty()) {
            return streams;
        }
        return vodAssetMapper.getRecentStreamUris(contentId, cpId, countryCode);
    }

    private List<String> processParentalRatings(List<String> parentalRatings) {
        Set<String> flattedParentalRatings = new HashSet<>();
        parentalRatings.forEach(ratings -> {
            String[] ratingsArray = ratings.split(",");
            Collections.addAll(flattedParentalRatings, ratingsArray);
        });
        return new ArrayList<>(flattedParentalRatings);
    }

    private AssetFilterBodyDto updateFilters(AssetFilterBodyDto filters,
        List<String> assetStatus, String tab) {
        if (assetStatus.isEmpty()) {
            assetStatus = switch (tab) {
                case Constants.QC_TAB -> Constants.IN_QC_STATUS;
                case Constants.PROD_TAB -> Constants.IN_PRODUCTION_STATUS;
                default -> Constants.ALL_STATUS;
            };
        }
        var isStatusFound = false;
        if (filters.getFilters() != null) {
            for (FilterDto filter : filters.getFilters()) {
                if (Constants.STATUS_COLUMN.equals(filter.getKey())) {
                    isStatusFound = true;
                    filter.setValues(assetStatus);
                    break;
                }
            }
        }
        if (!isStatusFound) {
            FilterDto statusFilter = FilterDto.builder().key(Constants.STATUS_COLUMN)
                .type(Constants.TYPE_FILTER).values(assetStatus).build();
            if (filters.getFilters() == null) {
                filters.setFilters(new ArrayList<>());
            }
            filters.getFilters().add(statusFilter);
        }
        return filters;
    }


    private void addAssetListToHierarchy(BulkRevokeHierarchy bulkRevokeHierarchy,
        List<VodAssetDto> assetList) {
        if (bulkRevokeHierarchy.getAssetHierarchy() == null) {
            bulkRevokeHierarchy.setAssetHierarchy(assetList);
        } else {
            assetList = filterUniqueAssetsForHierarchy(bulkRevokeHierarchy.getAssetHierarchy(),
                assetList);
            bulkRevokeHierarchy.getAssetHierarchy().addAll(assetList);
        }
    }

    private List<VodAssetDto> filterUniqueAssetsForHierarchy(List<VodAssetDto> existingAssets,
        List<VodAssetDto> newAssets) {
        Set<String> existingIds = existingAssets.stream()
            .map(VodAssetDto::getCompositeKey) // getKey() returns a composite unique identifier
            .collect(Collectors.toSet());

        return newAssets.stream()
            .filter(asset -> !existingIds.contains(asset.getCompositeKey())).toList();
    }
}