package com.cms.assetmanagement.model.evaluation;

import lombok.*;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class Title {
    private int size;
    private String type;
    private String subType;
    private String lang;
    private String name;
}
