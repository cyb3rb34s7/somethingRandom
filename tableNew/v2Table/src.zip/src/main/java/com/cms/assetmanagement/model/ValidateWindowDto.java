package com.cms.assetmanagement.model;

import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class ValidateWindowDto {

    Boolean isValid;
    String invalidReason;
    List<? extends DateRangeWindow> windowsInDb;
}
