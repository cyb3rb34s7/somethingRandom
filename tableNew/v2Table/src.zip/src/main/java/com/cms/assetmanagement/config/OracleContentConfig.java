package com.cms.assetmanagement.config;

import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@MapperScan(basePackages = "com.cms.assetmanagement.mapper.asset.content", sqlSessionFactoryRef = "oracleContentSessionFactory")
public class OracleContentConfig {

    @Bean(name = "oracleContentDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.oracle.content")
    public DataSource oracleDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "oracleContentSessionFactory")
    public SqlSessionFactory oracleSessionFactory(
        @Qualifier("oracleContentDataSource") DataSource dataSource) throws Exception {
        var sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        // Add MyBatis query time interceptor
        sessionFactory.setPlugins(new MyBatisQueryTimeInterceptor());
        return sessionFactory.getObject();
    }

    @Bean(name = "oracleContentSessionTemplate")
    public SqlSessionTemplate primarySqlSessionTemplate(
        @Qualifier("oracleContentSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Primary
    @Bean(name = "contentTransactionManager")
    public PlatformTransactionManager primaryTransactionManager(
        @Qualifier("oracleContentDataSource") DataSource oracleContentDataSource) {
        return new DataSourceTransactionManager(oracleContentDataSource);
    }


}
