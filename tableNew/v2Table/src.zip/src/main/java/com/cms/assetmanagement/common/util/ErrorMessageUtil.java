package com.cms.assetmanagement.common.util;

public class ErrorMessageUtil {

    private ErrorMessageUtil() {
    }

    public static String generateErrMessage(Exception e) {
        Throwable current = e;
        while (current != null) {
            if (current instanceof NullPointerException) {
                return "Null pointer exception occurred";
            }
            if (current.getMessage() != null && !current.getMessage().isBlank()) {
                return current.getMessage();
            }
            current = current.getCause();
        }
        return "Unknown error occurred";
    }
}
