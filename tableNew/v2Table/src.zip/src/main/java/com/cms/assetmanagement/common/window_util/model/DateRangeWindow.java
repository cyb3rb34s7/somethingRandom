package com.cms.assetmanagement.common.window_util.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface DateRangeWindow {

    @JsonIgnore
    String getWindowId();

    @JsonIgnore
    String getStartingTime();

    @JsonIgnore
    String getEndingTime();

    @JsonIgnore
    WindowType getWindowType();

    void setWindowId(String id);

    void setStartingTime(String startingTime);

    void setEndingTime(String endingTime);
}
