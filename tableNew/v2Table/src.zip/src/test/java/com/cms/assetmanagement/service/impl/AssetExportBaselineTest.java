package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.AssetTableColumnMapping;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.mapper.asset.content.VodAssetExportMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.mapper.asset.metadata.VodAssetMetadataMapper;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.GeoRestrictionsDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.PaginationDto;
import com.cms.assetmanagement.model.filter.SortDto;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.lang.reflect.Field;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Baseline test suite for the Asset Export endpoint.
 *
 * PURPOSE:
 * 1. Captures the CURRENT behavior of getAssetsForExport() as golden output
 * 2. After optimization (TVPCMS-1777), run the SAME tests to verify identical output
 * 3. Covers ALL business scenarios: asset types, statuses, collections, post-processing
 *
 * STRATEGY:
 * - Uses REAL Utils (not mocked) so actual business logic executes
 * - Mocks only VodAssetExportMapper (no DB available)
 * - Each test builds specific input data and asserts the full output
 *
 * AFTER OPTIMIZATION:
 * - The mapper mock setup will change (1 main query + 6 batch queries instead of 1 big query)
 * - But ALL assertions must still pass — same input data → same output
 */
@ExtendWith(MockitoExtension.class)
class AssetExportBaselineTest {

    @Mock
    private VodAssetMapper vodAssetMapper;
    @Mock
    private VodAssetMetadataMapper vodAssetMetadataMapper;
    @Mock
    private VodAssetExportMapper vodAssetExportMapper;
    @Mock
    private DateRangeWindowService dateRangeWindowService;
    @Mock
    private VodAssetColumnLockMapper vodAssetColumnLockMapper;

    private Utils utils;
    private VodAssetServiceImpl vodAssetService;
    private final ObjectMapper objectMapper = new ObjectMapper()
        .configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);

    // Feed worker config matching typical production setup
    private static final String CMS_FEED_WORKERS = "CMS,CMS_GRACENOTE,TVPLUS_DELTA,TVPLUS_DELTA_GRACENOTE";
    private static final String EXTERNAL_FEED_WORKERS = "EXT_WORKER_1,EXT_WORKER_2";
    private static final List<String> FEED_WORKER_LIST = List.of(
        "CMS", "CMS_GRACENOTE", "TVPLUS_DELTA", "TVPLUS_DELTA_GRACENOTE");

    @BeforeEach
    void setUp() {
        // Build REAL Utils with actual business logic
        AssetTableColumnMapping mapping = new AssetTableColumnMapping();
        utils = new Utils(mapping);
        utils.tvplusFeedWorkers = CMS_FEED_WORKERS;
        utils.init();

        // Build service with real Utils, mocked mappers
        vodAssetService = new VodAssetServiceImpl(
            vodAssetMapper, vodAssetMetadataMapper, dateRangeWindowService,
            vodAssetExportMapper, vodAssetColumnLockMapper, utils);

        vodAssetService.cmsFeedWorkers = CMS_FEED_WORKERS;
        vodAssetService.externalFeedWorkers = EXTERNAL_FEED_WORKERS;
        vodAssetService.region = "US";
        vodAssetService.init();
    }

    // ==================== TEST DATA BUILDERS ====================

    private static AssetFilterBodyDto buildDefaultFilterBody() {
        return AssetFilterBodyDto.builder()
            .columns(new ArrayList<>(Constants.EXPORT_COLUMNS_LIST))
            .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
            .pagination(PaginationDto.builder().offset(0).limit(5000).build())
            .build();
    }

    private static AssetFilterBodyDto buildFilterBodyWithColumns(List<String> columns) {
        return AssetFilterBodyDto.builder()
            .columns(new ArrayList<>(columns))
            .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
            .pagination(PaginationDto.builder().offset(0).limit(5000).build())
            .build();
    }

    private static AssetFilterBodyDto buildFilterBodyWithFilters(List<FilterDto> filters) {
        return AssetFilterBodyDto.builder()
            .columns(new ArrayList<>(Constants.EXPORT_COLUMNS_LIST))
            .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
            .pagination(PaginationDto.builder().offset(0).limit(5000).build())
            .filters(filters)
            .build();
    }

    /**
     * Filter body that includes computed business-logic fields (status, liveOnDevice, etc.)
     * so they survive retainOnlyFields. Use this for tests that assert on post-processing output.
     */
    private static AssetFilterBodyDto buildBusinessLogicFilterBody() {
        List<String> allColumns = new ArrayList<>(Constants.EXPORT_COLUMNS_LIST);
        allColumns.addAll(List.of("status", "liveOnDevice", "licenseWindow", "dbStatus",
            "externalProgramId", "externalIdProvider", "feedWorker", "availableStarting",
            "expiryDate"));
        return AssetFilterBodyDto.builder()
            .columns(allColumns)
            .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
            .pagination(PaginationDto.builder().offset(0).limit(5000).build())
            .build();
    }

    /** EPISODE with full collections — the most complex case */
    private static VodAssetDto buildEpisodeWithAllCollections() {
        Instant now = Instant.now();
        String activeStart = now.minus(30, ChronoUnit.DAYS).toString().replace("Z", "Z");
        String activeEnd = now.plus(60, ChronoUnit.DAYS).toString().replace("Z", "Z");
        // Format: yyyy-MM-dd'T'HH:mm:ss'Z' (without millis for consistency)
        String startFormatted = activeStart.substring(0, 19) + "Z";
        String endFormatted = activeEnd.substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("EP_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("EPISODE")
            .mainTitle("Game of Thrones")
            .shortTitle("GoT")
            .runningTime(4524)
            .genres("Action,Comedy")
            .description("A great show")
            .episodeNo(5)
            .seasonNo(1)
            .seasonId("SEASON_01")
            .showId("SHOW_01")
            .streamUri("https://stream.example.com/ep001")
            .releaseDate("1983-09-13")
            .availableStarting(startFormatted)
            .expiryDate(endFormatted)
            .webVttUrl("https://vtt.example.com/ep001")
            .audioLang("English")
            .subtitleLang("English")
            .quality("HD")
            .contentPartner("ABCD")
            .chapterTime("00:00:00:Frames")
            .chapterDescription("Introduction")
            .assetId("ASSET_EP_001")
            .adTag("test_ad_tag")
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .showTitle("Game of Thrones Show")
            .seasonTitle("Season 1")
            .language("English")
            .deeplinkPayload("{\"deeplink_data\":{\"content_type\":\"episodic\"}}")
            .attributes("multiview,live_ott")
            .subType("sports event")
            .airType("Premiere")
            .cast(List.of(
                AssetCastDto.builder().name("Kit Harington").role("actor").characterName("Jon Snow").build(),
                AssetCastDto.builder().name("Emilia Clarke").role("actor").characterName("Daenerys").build(),
                AssetCastDto.builder().name("Peter Dinklage").role("actor").characterName("Tyrion").build()
            ))
            .parentalRatings(List.of(
                ParentalRatingsDto.builder().body("AA Parental Rating").ratings("TV-Y").build(),
                ParentalRatingsDto.builder().body("US Parental Rating").ratings("TV-14").build()
            ))
            .licenseWindowList(List.of(
                LicenseWindowDto.builder().licenseId("LW_01")
                    .availableStarting(startFormatted).availableEnding(endFormatted).build(),
                LicenseWindowDto.builder().licenseId("LW_02")
                    .availableStarting(now.plus(90, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .availableEnding(now.plus(180, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build()
            ))
            .eventWindowList(List.of(
                EventWindowDto.builder().eventId("EVT_01")
                    .eventStarting(startFormatted).eventEnding(endFormatted).build(),
                EventWindowDto.builder().eventId("EVT_02")
                    .eventStarting(now.plus(10, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .eventEnding(now.plus(12, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build()
            ))
            .geoRestrictions(List.of(
                GeoRestrictionsDto.builder().accessType("allow").restrictionType("team_region")
                    .teamRegion("Cleveland Cavaliers").build(),
                GeoRestrictionsDto.builder().accessType("allow").restrictionType("team_region")
                    .teamRegion("Detroit Pistons").build()
            ))
            .externalProvider(List.of(
                ExternalProviderDto.builder().externalProgramId("EXT_123")
                    .idType("tmsId").idProvider("AAPBE3701VT").provider("tms").build()
            ))
            .drm("Yes")
            .build();
    }

    /** MOVIE — no show/season hierarchy, with external providers */
    private static VodAssetDto buildMovieAsset() {
        Instant now = Instant.now();
        String startFormatted = now.minus(10, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String endFormatted = now.plus(90, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("MOV_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MOVIE")
            .mainTitle("Game of Thrones III")
            .shortTitle("GoT III")
            .runningTime(4524)
            .genres("Action,Comedy")
            .description("A movie")
            .episodeNo(0)
            .seasonNo(0)
            .streamUri("https://stream.example.com/mov001")
            .releaseDate("1983-09-13")
            .availableStarting(startFormatted)
            .expiryDate(endFormatted)
            .quality("HD")
            .contentPartner("ABCD")
            .contentTier("Premium")
            .assetId("ASSET_MOV_001")
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("Yes")
            .cast(List.of(
                AssetCastDto.builder().name("Actor1").role("actor").characterName("Char1").build()
            ))
            .parentalRatings(List.of(
                ParentalRatingsDto.builder().body("AA Parental Rating").ratings("TV-Y").build()
            ))
            .licenseWindowList(List.of(
                LicenseWindowDto.builder().licenseId("US_02")
                    .availableStarting(startFormatted).availableEnding(endFormatted).build()
            ))
            .externalProvider(List.of(
                ExternalProviderDto.builder().externalProgramId("External-ID")
                    .idType("tmsId").idProvider("AAPBE3701VT").provider("tms").build()
            ))
            .build();
    }

    /** SHOW — no streamUri, no episode/season numbers, minimal collections */
    private static VodAssetDto buildShowAsset() {
        return VodAssetDto.builder()
            .contentId("SHOW_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("SHOW")
            .mainTitle("Jack Hanna Wild Countdown")
            .runningTime(0)
            .genres("Documentary,Reality")
            .description("Jack Hanna entertains viewers")
            .episodeNo(0)
            .seasonNo(0)
            .contentPartner("Hearst Media")
            .assetId("SHOW_ASSET_001")
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("No")
            .showTitle("Jack Hanna Wild Countdown")
            .build();
    }

    /** MUSIC asset — with events and geo restrictions */
    private static VodAssetDto buildMusicAsset() {
        Instant now = Instant.now();
        String startFormatted = now.minus(5, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String endFormatted = now.plus(45, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("MUSIC_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MUSIC")
            .mainTitle("Jean Poolee")
            .runningTime(3604)
            .genres("Religious")
            .description("A music piece")
            .episodeNo(0)
            .seasonNo(0)
            .streamUri("https://stream.example.com/music001")
            .releaseDate("2017-01-05")
            .availableStarting(startFormatted)
            .expiryDate(endFormatted)
            .audioLang("Italian")
            .subtitleLang("English")
            .quality("FHD")
            .contentPartner("WildBrain")
            .assetId("MUSIC_ASSET_001")
            .adTag("gravitas_ventures_rev_vod")
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(2)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("No")
            .attributes("multiview,live_ott")
            .subType("sports event")
            .airType("Finale")
            .cast(List.of(
                AssetCastDto.builder().name("Giuseppina Schmitt").role("artist").build(),
                AssetCastDto.builder().name("Garret Schmeler II").role("artist").build()
            ))
            .parentalRatings(List.of(
                ParentalRatingsDto.builder().body("AA Parental Rating").ratings("TV-Y").build()
            ))
            .licenseWindowList(List.of(
                LicenseWindowDto.builder().licenseId("LW_01")
                    .availableStarting(startFormatted).availableEnding(endFormatted).build(),
                LicenseWindowDto.builder().licenseId("LW_02")
                    .availableStarting(now.plus(60, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .availableEnding(now.plus(120, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build(),
                LicenseWindowDto.builder().licenseId("LW_03")
                    .availableStarting(now.plus(150, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .availableEnding(now.plus(200, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build()
            ))
            .eventWindowList(List.of(
                EventWindowDto.builder().eventId("ED_01")
                    .eventStarting(now.plus(1, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .eventEnding(now.plus(3, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build(),
                EventWindowDto.builder().eventId("ED_02")
                    .eventStarting(now.plus(5, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
                    .eventEnding(now.plus(7, ChronoUnit.DAYS).toString().substring(0, 19) + "Z").build()
            ))
            .geoRestrictions(List.of(
                GeoRestrictionsDto.builder().accessType("allow").restrictionType("team_region")
                    .teamRegion("Cleveland Cavaliers").build(),
                GeoRestrictionsDto.builder().accessType("allow").restrictionType("team_region")
                    .teamRegion("Detroit Pistons").build()
            ))
            .externalProvider(List.of(
                ExternalProviderDto.builder().externalProgramId("BarbDwyer")
                    .idType("tmsId").idProvider("AAPBE3701VT").provider("tms").build()
            ))
            .build();
    }

    /** Asset with EXTERNAL feed worker → should become Untrackable */
    private static VodAssetDto buildUntrackableAsset() {
        return VodAssetDto.builder()
            .contentId("UNT_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MOVIE")
            .mainTitle("Unknown Movie")
            .runningTime(3600)
            .availableStarting(Instant.now().minus(5, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
            .expiryDate(Instant.now().plus(30, ChronoUnit.DAYS).toString().substring(0, 19) + "Z")
            .status("Released")
            .feedWorker("SOME_EXTERNAL_WORKER")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("No")
            .assetId("UNT_ASSET_001")
            .contentPartner("External CP")
            .build();
    }

    /** Asset with Released status but FUTURE available_starting → Ready for Release */
    private static VodAssetDto buildReadyForReleaseAsset() {
        String futureStart = Instant.now().plus(30, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String futureEnd = Instant.now().plus(120, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("RFR_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MOVIE")
            .mainTitle("Future Movie")
            .runningTime(5400)
            .availableStarting(futureStart)
            .expiryDate(futureEnd)
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("No")
            .assetId("RFR_ASSET_001")
            .contentPartner("FutureCP")
            .build();
    }

    /** Asset with EXPIRED license */
    private static VodAssetDto buildExpiredAsset() {
        String pastStart = Instant.now().minus(90, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String pastEnd = Instant.now().minus(10, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("EXP_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MOVIE")
            .mainTitle("Old Movie")
            .runningTime(3600)
            .availableStarting(pastStart)
            .expiryDate(pastEnd)
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(1)
            .dbStatus("PRD & STG")
            .language("English")
            .drm("No")
            .assetId("EXP_ASSET_001")
            .contentPartner("OldCP")
            .build();
    }

    /** Asset with NO collections at all */
    private static VodAssetDto buildAssetWithNoCollections() {
        String start = Instant.now().minus(5, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String end = Instant.now().plus(60, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("BARE_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("MOVIE")
            .mainTitle("Bare Movie")
            .runningTime(3600)
            .availableStarting(start)
            .expiryDate(end)
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(0)
            .language("English")
            .drm("No")
            .assetId("BARE_ASSET_001")
            .contentPartner("BareCP")
            .build();
    }

    /** STG-only asset (isCmsProd = 0) */
    private static VodAssetDto buildStagingOnlyAsset() {
        String start = Instant.now().minus(5, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";
        String end = Instant.now().plus(60, ChronoUnit.DAYS).toString().substring(0, 19) + "Z";

        return VodAssetDto.builder()
            .contentId("STG_001")
            .vcCpId("AAPBE3701VT")
            .countryCode("AA")
            .type("EPISODE")
            .mainTitle("Staging Episode")
            .episodeNo(1)
            .seasonNo(1)
            .seasonId("STG_SEASON_01")
            .showId("STG_SHOW_01")
            .availableStarting(start)
            .expiryDate(end)
            .status("Released")
            .feedWorker("CMS")
            .isCmsProd(0)
            .language("English")
            .drm("No")
            .assetId("STG_ASSET_001")
            .contentPartner("StagingCP")
            .showTitle("Staging Show")
            .seasonTitle("Staging Season 1")
            .build();
    }

    private void mockMapperReturning(List<VodAssetDto> assets) {
        when(vodAssetExportMapper.getAssetsForExport(
            any(AssetFilterBodyDto.class), anyList(), anyList()))
            .thenReturn(new ArrayList<>(assets));
    }

    // ==================== TESTS: ASSET TYPE SCENARIOS ====================

    @Nested
    @DisplayName("Asset Type Scenarios")
    class AssetTypeTests {

        @Test
        @DisplayName("EPISODE with full collections — all fields populated correctly")
        void episodeWithAllCollections() {
            VodAssetDto episode = buildEpisodeWithAllCollections();
            mockMapperReturning(List.of(episode));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertEquals(1, result.size());
            VodAssetDto out = result.get(0);
            assertEquals("EP_001", out.getContentId());
            assertEquals("EPISODE", out.getType());

            // Collections preserved
            assertNotNull(out.getCast());
            assertEquals(3, out.getCast().size());
            assertEquals("Kit Harington", out.getCast().get(0).getName());

            assertNotNull(out.getParentalRatings());
            assertEquals(2, out.getParentalRatings().size());

            assertNotNull(out.getLicenseWindowList());
            assertEquals(2, out.getLicenseWindowList().size());

            assertNotNull(out.getEventWindowList());
            assertEquals(2, out.getEventWindowList().size());

            assertNotNull(out.getGeoRestrictions());
            assertEquals(2, out.getGeoRestrictions().size());

            assertNotNull(out.getExternalProvider());
            assertEquals(1, out.getExternalProvider().size());

            // Show/Season hierarchy
            assertEquals("Game of Thrones Show", out.getShowTitle());
            assertEquals("Season 1", out.getSeasonTitle());
        }

        @Test
        @DisplayName("MOVIE — no hierarchy, external providers populated")
        void movieAsset() {
            VodAssetDto movie = buildMovieAsset();
            mockMapperReturning(List.of(movie));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertEquals(1, result.size());
            VodAssetDto out = result.get(0);
            assertEquals("MOV_001", out.getContentId());
            assertEquals("MOVIE", out.getType());
            assertEquals(0, out.getEpisodeNo());
            assertEquals(0, out.getSeasonNo());
        }

        @Test
        @DisplayName("SHOW — minimal collections, no stream URI")
        void showAsset() {
            VodAssetDto show = buildShowAsset();
            mockMapperReturning(List.of(show));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertEquals(1, result.size());
            VodAssetDto out = result.get(0);
            assertEquals("SHOW_001", out.getContentId());
            assertEquals("SHOW", out.getType());
            assertEquals("Jack Hanna Wild Countdown", out.getShowTitle());
        }

        @Test
        @DisplayName("MUSIC — events, geo restrictions, multiple license windows")
        void musicAsset() {
            VodAssetDto music = buildMusicAsset();
            mockMapperReturning(List.of(music));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertEquals(1, result.size());
            VodAssetDto out = result.get(0);
            assertEquals("MUSIC_001", out.getContentId());
            assertEquals("MUSIC", out.getType());
            assertNotNull(out.getLicenseWindowList());
            assertEquals(3, out.getLicenseWindowList().size());
            assertNotNull(out.getEventWindowList());
            assertEquals(2, out.getEventWindowList().size());
            assertNotNull(out.getGeoRestrictions());
            assertEquals(2, out.getGeoRestrictions().size());
        }
    }

    // ==================== TESTS: STATUS/BUSINESS LOGIC ====================

    @Nested
    @DisplayName("Status & Business Logic Scenarios")
    class StatusTests {

        @Test
        @DisplayName("Released + Active license → status stays Released, liveOnDevice=Yes")
        void releasedActiveAsset() {
            VodAssetDto episode = buildEpisodeWithAllCollections();
            mockMapperReturning(List.of(episode));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertEquals("Released", out.getStatus());
            assertNotNull(out.getLicenseWindow());
            // Active license (availableStarting is past, expiryDate is future)
            assertTrue(out.getLicenseWindow().contains("Active")
                || out.getLicenseWindow().contains("Expiring in"));
            assertEquals("Yes", out.getLiveOnDevice());
        }

        @Test
        @DisplayName("Released + Future license → status becomes Ready for Release")
        void readyForReleaseAsset() {
            VodAssetDto asset = buildReadyForReleaseAsset();
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertEquals("Ready for Release", out.getStatus());
            assertTrue(out.getLicenseWindow().contains("Upcoming"));
        }

        @Test
        @DisplayName("Expired license asset")
        void expiredAsset() {
            VodAssetDto asset = buildExpiredAsset();
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertEquals("Expired", out.getLicenseWindow());
            assertEquals("Released", out.getStatus()); // Expired doesn't change status
        }

        @Test
        @DisplayName("External feed worker → Untrackable status")
        void untrackableAsset() {
            VodAssetDto asset = buildUntrackableAsset();
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertEquals("Untrackable", out.getStatus());
            assertEquals("Untrackable", out.getDbStatus());
            assertEquals("Untrackable", out.getLiveOnDevice());
        }

        @Test
        @DisplayName("STG-only asset (isCmsProd=0) → liveOnDevice=No")
        void stagingOnlyAsset() {
            VodAssetDto asset = buildStagingOnlyAsset();
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertEquals("No", out.getLiveOnDevice());
        }

        @Test
        @DisplayName("Asset with no collections → empty lists, no NPE")
        void assetWithNoCollections() {
            VodAssetDto asset = buildAssetWithNoCollections();
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertEquals(1, result.size());
            VodAssetDto out = result.get(0);
            assertEquals("BARE_001", out.getContentId());
        }
    }

    // ==================== TESTS: EXTERNAL PROVIDER POST-PROCESSING ====================

    @Nested
    @DisplayName("External Provider Data Processing")
    class ExternalProviderTests {

        @Test
        @DisplayName("setExternalProviderData populates externalProgramId and externalIdProvider")
        void externalProviderFieldsPopulated() {
            VodAssetDto movie = buildMovieAsset();
            mockMapperReturning(List.of(movie));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            // setExternalProviderData extracts from externalProvider collection
            assertEquals("External-ID", out.getExternalProgramId());
            assertEquals("tms", out.getExternalIdProvider());
        }

        @Test
        @DisplayName("Multiple external providers → comma-separated values")
        void multipleExternalProviders() {
            VodAssetDto asset = buildMovieAsset();
            asset.setExternalProvider(List.of(
                ExternalProviderDto.builder().externalProgramId("ID_1").provider("tms").build(),
                ExternalProviderDto.builder().externalProgramId("ID_2").provider("gracenote").build()
            ));
            mockMapperReturning(List.of(asset));

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            VodAssetDto out = result.get(0);
            assertTrue(out.getExternalProgramId().contains("ID_1"));
            assertTrue(out.getExternalProgramId().contains("ID_2"));
            assertTrue(out.getExternalIdProvider().contains("tms"));
            assertTrue(out.getExternalIdProvider().contains("gracenote"));
        }
    }

    // ==================== TESTS: PAGINATION ====================

    @Nested
    @DisplayName("Pagination Handling")
    class PaginationTests {

        @Test
        @DisplayName("Pagination offset/limit transformation for ROW_NUMBER")
        void paginationTransformation() {
            mockMapperReturning(new ArrayList<>());

            AssetFilterBodyDto filterBody = buildDefaultFilterBody();
            filterBody.getPagination().setOffset(5000);
            filterBody.getPagination().setLimit(5000);

            vodAssetService.getAssetsForExport(filterBody);

            // After transformation: newLimit = 5000+5000 = 10000, newOffset = 5000+1 = 5001
            assertEquals(10000, filterBody.getPagination().getLimit());
            assertEquals(5001, filterBody.getPagination().getOffset());
        }

        @Test
        @DisplayName("No pagination → no transformation")
        void noPagination() {
            mockMapperReturning(new ArrayList<>());

            AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
                .columns(new ArrayList<>(Constants.EXPORT_COLUMNS_LIST))
                .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
                .build();

            vodAssetService.getAssetsForExport(filterBody);
            assertNull(filterBody.getPagination());
        }
    }

    // ==================== TESTS: MIXED ASSET BATCH (REALISTIC SCENARIO) ====================

    @Nested
    @DisplayName("Mixed Asset Batch — Realistic Scenarios")
    class MixedBatchTests {

        @Test
        @DisplayName("Batch of all asset types — each processed correctly")
        void mixedAssetBatch() {
            List<VodAssetDto> allAssets = List.of(
                buildEpisodeWithAllCollections(),
                buildMovieAsset(),
                buildShowAsset(),
                buildMusicAsset(),
                buildUntrackableAsset(),
                buildReadyForReleaseAsset(),
                buildExpiredAsset(),
                buildAssetWithNoCollections(),
                buildStagingOnlyAsset()
            );
            mockMapperReturning(allAssets);

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            assertEquals(9, result.size());

            // Verify each asset type is handled correctly
            VodAssetDto episode = result.stream().filter(a -> "EP_001".equals(a.getContentId())).findFirst().get();
            assertEquals("EPISODE", episode.getType());
            assertEquals(3, episode.getCast().size());

            VodAssetDto movie = result.stream().filter(a -> "MOV_001".equals(a.getContentId())).findFirst().get();
            assertEquals("MOVIE", movie.getType());

            VodAssetDto show = result.stream().filter(a -> "SHOW_001".equals(a.getContentId())).findFirst().get();
            assertEquals("SHOW", show.getType());
            assertEquals("Yes", show.getLiveOnDevice()); // SHOW type + Released + PRD

            VodAssetDto untrackable = result.stream().filter(a -> "UNT_001".equals(a.getContentId())).findFirst().get();
            assertEquals("Untrackable", untrackable.getStatus());

            VodAssetDto readyForRelease = result.stream().filter(a -> "RFR_001".equals(a.getContentId())).findFirst().get();
            assertEquals("Ready for Release", readyForRelease.getStatus());

            VodAssetDto expired = result.stream().filter(a -> "EXP_001".equals(a.getContentId())).findFirst().get();
            assertEquals("Expired", expired.getLicenseWindow());

            VodAssetDto staging = result.stream().filter(a -> "STG_001".equals(a.getContentId())).findFirst().get();
            assertEquals("No", staging.getLiveOnDevice());
        }

        @Test
        @DisplayName("Empty result from mapper → returns empty list")
        void emptyResult() {
            mockMapperReturning(new ArrayList<>());

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }

        @Test
        @DisplayName("Null result from mapper → returns null")
        void nullResult() {
            when(vodAssetExportMapper.getAssetsForExport(
                any(AssetFilterBodyDto.class), anyList(), anyList()))
                .thenReturn(null);

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildDefaultFilterBody());

            assertNull(result);
        }
    }

    // ==================== TESTS: COLUMN FILTERING (retainOnlyFields) ====================

    @Nested
    @DisplayName("Column Filtering via retainOnlyFields")
    class ColumnFilteringTests {

        @Test
        @DisplayName("Only scalar columns requested → collections nulled out")
        void onlyScalarColumns() {
            VodAssetDto episode = buildEpisodeWithAllCollections();
            mockMapperReturning(List.of(episode));

            List<String> scalarOnly = List.of("contentId", "mainTitle", "type", "countryCode");
            AssetFilterBodyDto filterBody = buildFilterBodyWithColumns(scalarOnly);

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(filterBody);

            VodAssetDto out = result.get(0);
            assertEquals("EP_001", out.getContentId());
            assertEquals("EPISODE", out.getType());
            // Collections should be nulled out by retainOnlyFields
            assertNull(out.getCast());
            assertNull(out.getParentalRatings());
            assertNull(out.getLicenseWindowList());
            assertNull(out.getEventWindowList());
            assertNull(out.getGeoRestrictions());
        }

        @Test
        @DisplayName("Only collection columns requested → scalar fields nulled")
        void onlyCollectionColumns() {
            VodAssetDto episode = buildEpisodeWithAllCollections();
            mockMapperReturning(List.of(episode));

            List<String> collectionsOnly = List.of("cast", "parentalRatings", "licenseWindowList");
            AssetFilterBodyDto filterBody = buildFilterBodyWithColumns(collectionsOnly);

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(filterBody);

            VodAssetDto out = result.get(0);
            // Scalar fields should be null
            assertNull(out.getMainTitle());
            assertNull(out.getGenres());
            // Collections should be present
            assertNotNull(out.getCast());
            assertEquals(3, out.getCast().size());
            assertNotNull(out.getParentalRatings());
            assertEquals(2, out.getParentalRatings().size());
        }

        @Test
        @DisplayName("Default columns (null input) → uses EXPORT_COLUMNS_LIST")
        void defaultColumns() {
            VodAssetDto episode = buildEpisodeWithAllCollections();
            mockMapperReturning(List.of(episode));

            AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
                .sortBy(List.of(SortDto.builder().field("updateDate").order("DESC").build()))
                .pagination(PaginationDto.builder().offset(0).limit(5000).build())
                .build();
            // columns = null → should default to EXPORT_COLUMNS_LIST

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(filterBody);

            assertEquals(1, result.size());
            // contentId is in EXPORT_COLUMNS_LIST
            assertEquals("EP_001", result.get(0).getContentId());
        }
    }

    // ==================== TESTS: DEFAULT SORT ====================

    @Nested
    @DisplayName("Default Sort Handling")
    class SortTests {

        @Test
        @DisplayName("No sortBy → defaults to updateDate DESC")
        void defaultSort() {
            mockMapperReturning(new ArrayList<>());

            AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
                .columns(new ArrayList<>(Constants.EXPORT_COLUMNS_LIST))
                .pagination(PaginationDto.builder().offset(0).limit(5000).build())
                .build();

            vodAssetService.getAssetsForExport(filterBody);

            assertNotNull(filterBody.getSortBy());
            assertEquals(1, filterBody.getSortBy().size());
            // getColumnMapping transforms "updateDate" → "UPD_DT"
            assertEquals("UPD_DT", filterBody.getSortBy().get(0).getField());
            assertEquals("DESC", filterBody.getSortBy().get(0).getOrder());
        }
    }

    // ==================== GOLDEN OUTPUT SNAPSHOT ====================

    @Nested
    @DisplayName("Golden Output Snapshot — for before/after comparison")
    class GoldenOutputTests {

        /**
         * This test produces a JSON snapshot of the full output.
         * Run this BEFORE optimization to capture baseline.
         * Run AFTER optimization — output must match exactly.
         *
         * To compare:
         * 1. Run before optimization, save the printed JSON
         * 2. Run after optimization, compare with saved JSON
         * 3. Any difference = regression
         */
        @Test
        @DisplayName("Full golden output — all asset types with all collections")
        void goldenOutputSnapshot() throws JsonProcessingException {
            List<VodAssetDto> allAssets = List.of(
                buildEpisodeWithAllCollections(),
                buildMovieAsset(),
                buildShowAsset(),
                buildMusicAsset(),
                buildUntrackableAsset(),
                buildReadyForReleaseAsset(),
                buildExpiredAsset(),
                buildAssetWithNoCollections(),
                buildStagingOnlyAsset()
            );
            mockMapperReturning(allAssets);

            List<VodAssetDto> result = vodAssetService.getAssetsForExport(buildBusinessLogicFilterBody());

            // Verify count
            assertEquals(9, result.size());

            // Verify every asset's key computed fields
            for (VodAssetDto asset : result) {
                assertNotNull(asset.getContentId(), "contentId should not be null");
                assertNotNull(asset.getStatus(), "status should not be null for " + asset.getContentId());
                assertNotNull(asset.getLiveOnDevice(), "liveOnDevice should not be null for " + asset.getContentId());
            }

            // Print snapshot for manual comparison (optional)
            String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);
            System.out.println("=== GOLDEN OUTPUT SNAPSHOT ===");
            System.out.println("Asset count: " + result.size());
            for (VodAssetDto asset : result) {
                System.out.printf("  [%s] type=%s status=%s licenseWindow=%s liveOnDevice=%s dbStatus=%s extProgramId=%s%n",
                    asset.getContentId(), asset.getType(), asset.getStatus(),
                    asset.getLicenseWindow(), asset.getLiveOnDevice(), asset.getDbStatus(),
                    asset.getExternalProgramId());
            }
            System.out.println("=== END SNAPSHOT ===");
        }
    }
}
