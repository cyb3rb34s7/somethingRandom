package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.service.AssetInsertHelper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VodAssetUpdateServiceImplTest {

    @Mock
    private VodAssetMapper vodAssetMapper;
    @Mock
    private VodAssetColumnLockMapper vodAssetColumnLockMapper;
    @Mock
    private AssetInsertHelper assetInsertHelper;
    @Mock
    private DateRangeWindowService dateRangeWindowService;
    @Mock
    private Utils utils;

    @InjectMocks
    private VodAssetServiceImpl vodAssetService;
    @InjectMocks
    private VodAssetUpdateServiceImpl vodAssetUpdateService;

    @BeforeEach
    void setUp() {
        // Set default values for @Value fields
        vodAssetService.cmsFeedWorkers = "worker1,worker2";
        vodAssetService.externalFeedWorkers = "extWorker1,extWorker2";
        vodAssetService.region = "US";
    }

    @ParameterizedTest
    @ValueSource(strings = {Constants.EPISODE, Constants.SEASON, Constants.SHOW})
    void insertAssetDetails_success(String type) {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .type(type).build();
        List<AssetDrmDto> drm = List.of(AssetDrmDto.builder().build(),
            AssetDrmDto.builder().build());
        List<AssetExternalIdDto> externalProvider = List.of(AssetExternalIdDto.builder().build(),
            AssetExternalIdDto.builder().build());
        List<AdBreaksDto> adBreaks = List.of(AdBreaksDto.builder().build());
        List<PlatformTagData> platforms = List.of(PlatformTagData.builder().build());
        List<AssetRatingDto> ratings = List.of(AssetRatingDto.builder().build(),
            AssetRatingDto.builder().build());
        List<AssetCastDto> cast = List.of(AssetCastDto.builder().build(),
            AssetCastDto.builder().build());
        List<com.cms.assetmanagement.common.window_util.model.LicenseWindowDto> licenseWindowList =
            List.of(
                com.cms.assetmanagement.common.window_util.model.LicenseWindowDto.builder().build(),
                com.cms.assetmanagement.common.window_util.model.LicenseWindowDto.builder()
                    .build());
        GracenoteMapDto gracenoteMap = GracenoteMapDto.builder().build();

        VodAssetDetailedDto assetDetails = VodAssetDetailedDto.builder().vodAsset(vodAssetDto)
            .drm(drm).externalProvider(externalProvider).adBreak(adBreaks).platform(platforms)
            .rating(ratings).cast(cast).licenseWindowList(licenseWindowList)
            .gracenoteMaintainMap(gracenoteMap).vodCpAsset(vodAssetDto).build();

        doNothing().when(vodAssetMapper).insertAsset(vodAssetDto);
        assertDoesNotThrow(() -> {
            vodAssetUpdateService.insertAssetDetails(assetDetails);
        });
    }

    @Test
    void updateAsset_success() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").vcCpId("vcCpId")
            .countryCode("US").gracenoteAction("add").
            type("EPISODE").ratings("A").
            platformTagData(List.of(PlatformTagData.builder().build())).
            externalProvider(List.of(ExternalProviderDto.builder().build())).
            adBreaks(List.of(AdBreaksDto.builder().build())).
            drmData(List.of(AssetDrmDto.builder().build())).
            parentalRatings(List.of(ParentalRatingsDto.builder().build())).
            cast(List.of(AssetCastDto.builder().build())).
            licenseWindowList(List.of(
                com.cms.assetmanagement.common.window_util.model.LicenseWindowDto.builder()
                    .build())).
            eventWindowList(List.of(
                com.cms.assetmanagement.common.window_util.model.EventWindowDto.builder().build())).
            assetImageList(List.of(com.cms.assetmanagement.model.AssetImageDto.builder().build()))
            .build();

        VodAssetDto parentDetails = VodAssetDto.builder().contentId("contentId").
            vcCpId("vcCpId").
            type("EPISODE").
            showId("showId").
            seasonId("seasonId").
            countryCode("US").
            seasonNo(2).
            episodeNo(2).
            build();

        doNothing().when(vodAssetMapper).updateAsset(vodAssetDto);
        when(vodAssetMapper.getAssetParentDetails(vodAssetDto)).thenReturn(parentDetails);
        assertDoesNotThrow(() -> {
            vodAssetUpdateService.updateAsset(vodAssetDto);
        });
    }

    @Test
    void updateCPAsset_success() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").vcCpId("vcCpId")
            .countryCode("US").build();

        doNothing().when(vodAssetMapper).updateCPAsset(vodAssetDto);

        assertDoesNotThrow(() -> {
            vodAssetUpdateService.updateCPAsset(vodAssetDto);
        });
        Mockito.verify(vodAssetMapper, Mockito.times(1)).updateCPAsset(vodAssetDto);
    }

    @Test
    void updateAssetByBulk_success() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").vcCpId("vcCpId")
            .countryCode("US").
            platformTagData(List.of(PlatformTagData.builder().build(),
                PlatformTagData.builder().build()))
            .build();

        AssetUpdateByBulkDto bulkUpdate = AssetUpdateByBulkDto.builder().vodAssetDto(vodAssetDto)
            .contentIds(List.of("contentId1", "contentId2")).build();

        doNothing().when(vodAssetMapper).updateAssetByBulk(bulkUpdate);
        doNothing().when(vodAssetMapper).updatePlatformData(Mockito.any());
        doNothing().when(vodAssetMapper).deletePlatformDataByKeys(Mockito.any());

        assertDoesNotThrow(() -> {
            vodAssetUpdateService.updateAssetByBulk(bulkUpdate);
        });
        Mockito.verify(vodAssetMapper, Mockito.times(1)).updateAssetByBulk(bulkUpdate);
    }

    @Test
    void deleteAsset_success() {
        AssetKeyListDto assetKeyList = AssetKeyListDto.builder().assetList(
            List.of(AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build(),
                AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build())
        ).build();

        List<VodAssetDto> parentDetails = List.of(VodAssetDto.builder().build(),
            VodAssetDto.builder().type(Constants.EPISODE).build(),
            VodAssetDto.builder().type(Constants.SHOW).build(),
            VodAssetDto.builder().contentId("contentId").
                vcCpId("vcCpId").type("EPISODE").
                showId("showId").seasonId("seasonId").
                countryCode("US").ratings("ratings").seasonNo(2).
                episodeNo(2).build());

        when(vodAssetMapper.getAssetByKey(Mockito.any())).thenReturn(parentDetails);

        assertDoesNotThrow(() -> {
            vodAssetUpdateService.deleteAsset(assetKeyList);
        });
    }

    @Test
    void updateAssetDetails_success() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").vcCpId("vcCpId")
            .countryCode("AA").type(Constants.SHOW).feedWorker("TVPLUS_DELTA").build();
        List<AssetDrmDto> drm = List.of(AssetDrmDto.builder().build(),
            AssetDrmDto.builder().build());
        List<AssetExternalIdDto> externalProvider = List.of(AssetExternalIdDto.builder().build(),
            AssetExternalIdDto.builder().build());
        List<AdBreaksDto> adBreak = List.of(AdBreaksDto.builder().build(),
            AdBreaksDto.builder().build());
        List<PlatformTagData> platform = List.of(PlatformTagData.builder().build(),
            PlatformTagData.builder().build());
        List<AssetRatingDto> ratings = List.of(AssetRatingDto.builder().build(),
            AssetRatingDto.builder().build());
        List<AssetCastDto> casts = List.of(AssetCastDto.builder().build(),
            AssetCastDto.builder().build());
        List<com.cms.assetmanagement.common.window_util.model.LicenseWindowDto> licenseWindows =
            List.of(
                com.cms.assetmanagement.common.window_util.model.LicenseWindowDto.builder().build(),
                com.cms.assetmanagement.common.window_util.model.LicenseWindowDto.builder()
                    .build());
        List<com.cms.assetmanagement.common.window_util.model.EventWindowDto> eventWindows =
            List.of(
                com.cms.assetmanagement.common.window_util.model.EventWindowDto.builder().build(),
                com.cms.assetmanagement.common.window_util.model.EventWindowDto.builder().build());
        GracenoteMapDto gracenoteMaps = GracenoteMapDto.builder().build();
        List<com.cms.assetmanagement.model.AssetLockedFieldDto> lockedFields =
            List.of(com.cms.assetmanagement.model.AssetLockedFieldDto.builder().build(),
                com.cms.assetmanagement.model.AssetLockedFieldDto.builder().build());

        VodAssetDetailedDto assetDetails = VodAssetDetailedDto.builder()
            .vodAsset(vodAssetDto)
            .drm(drm)
            .externalProvider(externalProvider)
            .adBreak(adBreak)
            .platform(platform)
            .rating(ratings)
            .cast(casts)
            .licenseWindowList(licenseWindows)
            .eventWindowList(eventWindows)
            .gracenoteMaintainMap(gracenoteMaps)
            .lockedFields(lockedFields)
            .vodCpAsset(vodAssetDto).build();

        doNothing().when(vodAssetMapper).deleteAsset(Mockito.any());
        doNothing().when(vodAssetMapper).deleteDRMData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteExternalIdData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteAdBreaks(Mockito.any());
        doNothing().when(vodAssetMapper).deletePlatforms(Mockito.any());
        doNothing().when(vodAssetMapper).deleteRatingData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteCastData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteLicenseWindowData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteEventWindowData(Mockito.any());
        doNothing().when(vodAssetMapper).deleteGracenoteMapData(Mockito.any());
        doNothing().when(vodAssetColumnLockMapper).deleteColumnLockByContentId(Mockito.any());

        assertDoesNotThrow(() -> {
            vodAssetUpdateService.updateAssetDetails(assetDetails);
        });
    }

    @Test
    void updateAssetStatus_success() {
        AssetKeyDto assetKey1 = AssetKeyDto.builder().contentId("contentId1").countryCode("US")
            .vcCpId("cp1").build();
        AssetKeyDto assetKey2 = AssetKeyDto.builder().contentId("contentId2").countryCode("US")
            .vcCpId("cp2").build();

        AssetStatusUpdateDto status = AssetStatusUpdateDto.builder()
            .assetList(List.of(assetKey1, assetKey2))
            .status("NewStatus").build();

        doNothing().when(vodAssetMapper).updateAssetStatus(status);
        assertDoesNotThrow(() -> {
            vodAssetUpdateService.updateAssetStatus(status);
        });
        Mockito.verify(vodAssetMapper, Mockito.times(1)).updateAssetStatus(status);
    }

    @Test
    void insert_success() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().build();
        doNothing().when(vodAssetMapper).insertAsset(vodAssetDto);
        assertDoesNotThrow(() -> {
            vodAssetUpdateService.insertAsset(vodAssetDto);
        });
        Mockito.verify(vodAssetMapper, Mockito.times(1)).insertAsset(vodAssetDto);
    }

}
