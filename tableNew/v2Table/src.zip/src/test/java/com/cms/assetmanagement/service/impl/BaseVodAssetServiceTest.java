package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetExportMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetImageMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.mapper.asset.metadata.VodAssetMetadataMapper;
import com.cms.assetmanagement.service.AssetInsertHelper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Base test class for VodAssetService tests. This class contains common setup code and mock objects
 * used by all test classes.
 */
class BaseVodAssetServiceTest {

    @Mock
    protected VodAssetMapper vodAssetMapper;
    @Mock
    protected VodAssetMetadataMapper vodAssetMetadataMapper;
    @Mock
    protected VodAssetColumnLockMapper vodAssetColumnLockMapper;
    @Mock
    protected DateRangeWindowService dateRangeWindowService;
    @Mock
    protected AssetInsertHelper assetInsertHelper;
    @Mock
    protected VodAssetImageMapper vodAssetImageMapper;
    @Mock
    protected VodAssetExportMapper vodAssetExportMapper;
    @Mock
    protected Utils utils;

    protected VodAssetServiceImpl vodAssetService;
    protected VodAssetViewServiceImpl vodAssetViewService;
    protected VodAssetWindowServiceImpl vodAssetWindowService;
    protected VodAssetValidationServiceImpl vodAssetValidationService;

    @BeforeEach
    void baseSetUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);

        // Initialize the service implementation
        vodAssetService = new VodAssetServiceImpl(
            vodAssetMapper,
            vodAssetMetadataMapper,
            dateRangeWindowService,
            vodAssetExportMapper,
            vodAssetColumnLockMapper,
            utils
        );

        vodAssetWindowService = new VodAssetWindowServiceImpl(
            vodAssetMapper,
            assetInsertHelper,
            utils
        );

        vodAssetValidationService = new VodAssetValidationServiceImpl(
            vodAssetMapper,
            dateRangeWindowService
        );

        vodAssetViewService = new VodAssetViewServiceImpl(
            vodAssetMapper,
            vodAssetImageMapper,
            vodAssetColumnLockMapper,
            utils
        );
    }

    @Test
    void testBaseSetUpInitializesServices() {
        // Test that all services are properly initialized
        assertNotNull(vodAssetService, "VodAssetService should be initialized");
        assertNotNull(vodAssetWindowService, "VodAssetWindowService should be initialized");
        assertNotNull(vodAssetValidationService, "VodAssetValidationService should be initialized");
        assertNotNull(vodAssetViewService, "VodAssetViewService should be initialized");
    }

    @Test
    void testMockObjectsAreInitialized() {
        // Test that mock objects are properly initialized and can be used
        assertNotNull(vodAssetMapper, "VodAssetMapper mock should be initialized");
        assertNotNull(vodAssetMetadataMapper, "VodAssetMetadataMapper mock should be initialized");
        assertNotNull(vodAssetColumnLockMapper, "VodAssetColumnLockMapper mock should be initialized");
        assertNotNull(dateRangeWindowService, "DateRangeWindowService mock should be initialized");
        assertNotNull(assetInsertHelper, "AssetInsertHelper mock should be initialized");
        assertNotNull(vodAssetImageMapper, "VodAssetImageMapper mock should be initialized");
        assertNotNull(vodAssetExportMapper, "VodAssetExportMapper mock should be initialized");
        assertNotNull(utils, "Utils mock should be initialized");
    }
}
