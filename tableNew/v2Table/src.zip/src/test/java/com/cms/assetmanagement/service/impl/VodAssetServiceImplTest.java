package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.mapper.asset.content.VodAssetExportMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.mapper.asset.metadata.VodAssetMetadataMapper;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetCountDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.CountryDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.RatingsDto;
import com.cms.assetmanagement.model.ShowHierarchyDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetStatusDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.PaginationDto;
import com.cms.assetmanagement.model.filter.SortDto;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VodAssetServiceImplTest {

    @Mock
    private VodAssetMapper vodAssetMapper;

    @Mock
    private VodAssetExportMapper vodAssetExportMapper;

    @Mock
    private VodAssetMetadataMapper vodAssetMetadataMapper;

    //    @Mock
//    private VodAssetColumnLockMapper vodAssetColumnLockMapper;
//
//    @Mock
//    private AssetInsertHelper assetInsertHelper;
//    @Mock
//    private DateRangeWindowService dateRangeWindowService;
//
//    @Mock
//    private VodAssetPublicService vodAssetPublicService;

    @Mock
    private Utils utils;

    @InjectMocks
    private VodAssetServiceImpl vodAssetService;

    @BeforeEach
    void setUp() {
        // Set default values for @Value fields
        vodAssetService.cmsFeedWorkers = "worker1,worker2";
        vodAssetService.externalFeedWorkers = "extWorker1,extWorker2";
        vodAssetService.region = "US";
    }

    @Test
    void getFilteredAssets_success() {
        List<FilterDto> filters = List.of(FilterDto.builder().key("").build(),
            FilterDto.builder().key("").build());
        List<String> columns = List.of("contentId", "cpName", "mainTitle", "type", "countryCode",
            "updateDate", "licenseWindow", "status");
        List<SortDto> sortBy = List.of(SortDto.builder().field("updateDate").order("DESC").build());
        PaginationDto pagination = PaginationDto.builder().limit(10).offset(0).build();

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().filters(filters)
            .columns(columns).sortBy(sortBy).pagination(pagination).build();

        List<VodAssetDto> expectedAssets = List.of(
            VodAssetDto.builder().contentId("contentId").countryCode("US").vcCpId("cpId")
                .status("status").licenseWindow("Active").availableStarting("starting")
                .expiryDate("expiry").build());

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(assetFilterBodyDto);
        when(utils.getLicenseWindow(anyString(), anyString())).thenReturn("Active");
        when(utils.getStatus(anyString(), anyString())).thenReturn("NewStatus");
        doNothing().when(utils).setExternalProviderData(any(VodAssetDto.class));
        when(utils.checkLiveOnDevice(any(VodAssetDto.class))).thenReturn("No");
        when(vodAssetMapper.getDescriptionLangCodes()).thenReturn(new ArrayList<>());

        List<VodAssetDto> actualResponse = vodAssetService.getFilteredAssets(assetFilterBodyDto);

        assertEquals(expectedAssets, actualResponse);
    }

    @Test
    void getFilteredAssets_else_success() {
        List<FilterDto> filters = List.of(FilterDto.builder().key("").build(),
            FilterDto.builder().key("").build());
        List<String> columns = List.of("contentId", "cpName", "mainTitle", "type", "countryCode",
            "updateDate", "licenseWindow", "status");

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().filters(filters)
            .columns(columns).build();

        List<VodAssetDto> expectedAssets = new ArrayList<>();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(assetFilterBodyDto);
        when(vodAssetMapper.getDescriptionLangCodes()).thenReturn(new ArrayList<>());

        List<VodAssetDto> actualResponse = vodAssetService.getFilteredAssets(assetFilterBodyDto);

        assertEquals(expectedAssets, actualResponse);
    }

    @Test
    void getFilteredAssetsCount_success() {
        List<FilterDto> filters = List.of(
            FilterDto.builder().key("ASSET_CURRENT_STATUS").type("filter")
                .values(List.of("Released")).build(),
            FilterDto.builder().key("ASSET_CURRENT_STATUS").type("filter").build());
        List<String> columns = List.of("contentId", "cpName", "mainTitle", "type", "countryCode",
            "updateDate", "licenseWindow", "status");
        List<SortDto> sortBy = List.of(SortDto.builder().field("updateDate").order("DESC").build());
        PaginationDto pagination = PaginationDto.builder().limit(10).offset(0).build();

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().filters(filters)
            .columns(columns).sortBy(sortBy).pagination(pagination).build();

        AssetCountDto expectedAssetsCount = AssetCountDto.builder().allAssets(10L).assetsInQC(10L)
            .assetsInProduction(10L).build();

        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(assetFilterBodyDto);
        when(vodAssetMapper.getFilteredAssetsCount(any(AssetFilterBodyDto.class), anyList(),
            anyList()))
            .thenReturn(10L);

        assertEquals(expectedAssetsCount,
            vodAssetService.getFilteredAssetsCount(assetFilterBodyDto, "all"));
        assertEquals(expectedAssetsCount,
            vodAssetService.getFilteredAssetsCount(assetFilterBodyDto, "qc"));
        assertEquals(expectedAssetsCount,
            vodAssetService.getFilteredAssetsCount(assetFilterBodyDto, "prod"));
    }

    @Test
    void getAssetsForExport_success() {
        List<FilterDto> filters = List.of(FilterDto.builder().key("").build(),
            FilterDto.builder().key("").build());
        List<String> columns = List.of("contentId", "cpName", "mainTitle", "type", "countryCode",
            "updateDate", "licenseWindow", "status");
        List<SortDto> sortBy = List.of(SortDto.builder().field("updateDate").order("DESC").build());
        PaginationDto pagination = PaginationDto.builder().limit(10).offset(0).build();

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().filters(filters)
            .columns(columns).sortBy(sortBy).pagination(pagination).build();

        List<VodAssetDto> expectedAssets = List.of(
            VodAssetDto.builder().contentId("contentId").countryCode("US").vcCpId("cpId")
                .status("status").licenseWindow("Active").availableStarting("starting")
                .expiryDate("expiry").build());

        when(vodAssetExportMapper.getAssetsForExport(any(AssetFilterBodyDto.class), anyList(),
            anyList()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(assetFilterBodyDto);
        when(utils.getLicenseWindow(anyString(), anyString())).thenReturn("Active");
        when(utils.getStatus(anyString(), anyString())).thenReturn("NewStatus");
        when(utils.checkExternalAsset(anyString(), anyString(), anyList())).thenReturn("NewStatus");
        when(utils.checkExternalAssetForDbStatus(anyString(), anyString(), anyList())).thenReturn(
            "NewStatus");
        doNothing().when(utils).setExternalProviderData(any(VodAssetDto.class));
        when(utils.checkLiveOnDevice(any(VodAssetDto.class))).thenReturn("No");

        List<VodAssetDto> actualResponse = vodAssetService.getAssetsForExport(assetFilterBodyDto);

        assertEquals(expectedAssets, actualResponse);
    }

    @Test
    void getExportAssetCount_success() {
        List<FilterDto> filters = List.of(
            FilterDto.builder().key("ASSET_CURRENT_STATUS").type("filter")
                .values(List.of("Released")).build(),
            FilterDto.builder().key("ASSET_CURRENT_STATUS").type("filter").build());
        List<String> columns = List.of("contentId", "cpName", "mainTitle", "type", "countryCode",
            "updateDate", "licenseWindow", "status");
        List<SortDto> sortBy = List.of(SortDto.builder().field("updateDate").order("DESC").build());
        PaginationDto pagination = PaginationDto.builder().limit(10).offset(0).build();

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().filters(filters)
            .columns(columns).sortBy(sortBy).pagination(pagination).build();

        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(assetFilterBodyDto);
        when(vodAssetExportMapper.getExportAssetCount(any(AssetFilterBodyDto.class), anyList(),
            anyList()))
            .thenReturn(0L);

        assertEquals(0L, vodAssetService.getExportAssetCount(assetFilterBodyDto));
    }

    @Test
    void getFilter_success() {
        List<String> expectedCountries = new ArrayList<>();
        List<String> expectedGenres = new ArrayList<>();
        List<String> expectedLang = new ArrayList<>();
        List<String> expectedTechIntegrators = new ArrayList<>();
        List<String> expectedContentPartners = new ArrayList<>();

        List<FilterDto> expectedResult = new ArrayList<>();
        expectedResult.add(
            new FilterDto("filter", "audioLang", Constants.AUDIO_LANG_TEXT, expectedLang, 2));
        expectedResult.add(
            new FilterDto("filter", "subtitleLang", Constants.SUBTITLE_LANG_TEXT, expectedLang, 2));
        expectedResult.add(
            new FilterDto("filter", "countryCode", Constants.COUNTRY_TEXT, expectedCountries, 2));
        expectedResult.add(
            new FilterDto("filter", "genres", Constants.GENRE_TEXT, expectedGenres, 2));
        expectedResult.add(new FilterDto("filter", "tiName", Constants.TECH_INTEGRATOR_TEXT,
            expectedTechIntegrators, 1));
        expectedResult.add(new FilterDto("filter", "contentPartner", Constants.CONTENT_PARTNER_TEXT,
            expectedContentPartners, 1));

        when(vodAssetMetadataMapper.getCountries(anyString())).thenReturn(expectedCountries);
        when(vodAssetMapper.getGenres()).thenReturn(expectedGenres);
        when(vodAssetMapper.getAudioLang()).thenReturn(expectedLang);
        when(vodAssetMapper.getTechIntegrators()).thenReturn(expectedTechIntegrators);
        when(vodAssetMapper.getContentPartners()).thenReturn(expectedContentPartners);

        List<FilterDto> result = vodAssetService.getFilters();

        assertEquals(expectedResult, result);
    }

    @Test
    void getCountryCodes_success() {
        List<CountryDto> countryCodeList = List.of(
            CountryDto.builder().countryCode("IN").countryName("India").build(),
            CountryDto.builder().countryCode("US").countryName("United States of America").build());

        when(vodAssetMetadataMapper.getCountryCodes(anyString())).thenReturn(countryCodeList);

        assertEquals(countryCodeList, vodAssetService.getCountryCodes());
    }

    @Test
    void getShowHierarchy_success() {
        AssetKeyDto assetKey = AssetKeyDto.builder().build();
        List<ShowHierarchyDto> expectedResponse = List.of(ShowHierarchyDto.builder().build());
        when(vodAssetMapper.getShowHierarchy(any(AssetKeyDto.class))).thenReturn(expectedResponse);
        assertEquals(expectedResponse, vodAssetService.getShowHierarchy(assetKey));
    }

    @Test
    void getLanguages_success() {
        List<LanguageDto> expectedResponse = List.of(LanguageDto.builder().build());
        when(vodAssetMapper.getLanguages()).thenReturn(expectedResponse);
        assertEquals(expectedResponse, vodAssetService.getLanguages());
    }

    @Test
    void assetDetailsByColumns_success() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder().build();
        List<VodAssetDto> expectedResponse = List.of(
            VodAssetDto.builder().isCmsProd(0).isSyncBlocked(true).isReleased(false).build());
        when(utils.getHistoryColumnMap(any(AssetByColumnsReqDto.class))).thenReturn(reqDto);
        when(vodAssetMapper.assetDetailsByColumns(any(AssetByColumnsReqDto.class), anyList()))
            .thenReturn(expectedResponse);
        assertEquals(expectedResponse, vodAssetService.assetDetailsByColumns(reqDto));
    }

    @Test
    void assetDetailsByColumns_else_success() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder().build();
        when(utils.getHistoryColumnMap(any(AssetByColumnsReqDto.class))).thenReturn(reqDto);
        when(vodAssetMapper.assetDetailsByColumns(any(AssetByColumnsReqDto.class), anyList()))
            .thenReturn(null);
        assertNull(vodAssetService.assetDetailsByColumns(reqDto));
    }

    @Test
    void getRatings_success() {
        List<RatingsDto> expectedResponse = List.of(
            RatingsDto.builder().ratingsList("PG-13, R, PG, G, PG-13, R, G").build(),
            RatingsDto.builder().ratingsList("PG-13, R, PG, G, PG-13, R, G").build());
        when(vodAssetMapper.getRatings()).thenReturn(expectedResponse);
        assertEquals(expectedResponse, vodAssetService.getRatings());
    }

    @Test
    void getAssetListDetailsforUpload_success() {
        AssetKeyListDto assetKeyList = AssetKeyListDto.builder().assetList(
            List.of(AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build(),
                AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId2")
                    .build())
        ).build();

        List<VodAssetStatusDto> expectedResult = new ArrayList<>();
        when(vodAssetMapper.getAssetListDetailsforUpload(anyList(), anyList())).thenReturn(
            expectedResult);

        assertEquals(expectedResult, vodAssetService.getAssetListDetailsforUpload(assetKeyList));
    }

    @Test
    void getAssetListDetailsforUpload_Exception() {
        AssetKeyListDto assetKeyList = AssetKeyListDto.builder().assetList(
            List.of(AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                .build())
        ).build();

        when(vodAssetMapper.getAssetListDetailsforUpload(anyList(), anyList()))
            .thenThrow(new com.cms.assetmanagement.exception.DataNotFoundException("TEST"));

        assertThrows(com.cms.assetmanagement.exception.DataNotFoundException.class,
            () -> vodAssetService.getAssetListDetailsforUpload(assetKeyList));
    }

    @Test
    void init_success() throws NoSuchFieldException, IllegalAccessException {
        // Set up the field values
        Field cmsFeedWorkersField = VodAssetServiceImpl.class.getDeclaredField("cmsFeedWorkers");
        cmsFeedWorkersField.setAccessible(true);
        cmsFeedWorkersField.set(vodAssetService, "worker1,worker2");

        Field externalFeedWorkersField = VodAssetServiceImpl.class.getDeclaredField(
            "externalFeedWorkers");
        externalFeedWorkersField.setAccessible(true);
        externalFeedWorkersField.set(vodAssetService, "extWorker1,extWorker2");

        // Call init method
        vodAssetService.init();

        // Verify that the lists are initialized correctly
        Field feedWorkerListField = VodAssetServiceImpl.class.getDeclaredField("feedWorkerList");
        feedWorkerListField.setAccessible(true);
        List<String> feedWorkerList = (List<String>) feedWorkerListField.get(vodAssetService);
        assertEquals(2, feedWorkerList.size());
        assertEquals("worker1", feedWorkerList.get(0));
        assertEquals("worker2", feedWorkerList.get(1));

        Field extFeedWorkersListField = VodAssetServiceImpl.class.getDeclaredField(
            "extFeedWorkersList");
        extFeedWorkersListField.setAccessible(true);
        List<String> extFeedWorkersList = (List<String>) extFeedWorkersListField.get(
            vodAssetService);
        assertEquals(2, extFeedWorkersList.size());
        assertEquals("extWorker1", extFeedWorkersList.get(0));
        assertEquals("extWorker2", extFeedWorkersList.get(1));
    }
}
