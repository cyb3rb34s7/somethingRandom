package com.cms.assetmanagement.common.enums;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ComparisonStatusEnumTest {

    @Test
    void enumValues_ShouldHaveCorrectValues() {
        // Then
        assertEquals("MATCHING", ComparisonStatusEnum.MATCHING.getValue());
        assertEquals("MISMATCHING", ComparisonStatusEnum.MISMATCHING.getValue());
        assertEquals("NONE", ComparisonStatusEnum.NONE.getValue());
    }

    @Test
    void enumValues_ShouldHaveCorrectNumberOfValues() {
        // When
        ComparisonStatusEnum[] values = ComparisonStatusEnum.values();

        // Then
        assertEquals(3, values.length);
    }

    @Test
    void enumValueOf_ShouldReturnCorrectEnum() {
        // When & Then
        assertEquals(ComparisonStatusEnum.MATCHING, ComparisonStatusEnum.valueOf("MATCHING"));
        assertEquals(ComparisonStatusEnum.MISMATCHING, ComparisonStatusEnum.valueOf("MISMATCHING"));
        assertEquals(ComparisonStatusEnum.NONE, ComparisonStatusEnum.valueOf("NONE"));
    }

}
