package com.cms.assetmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import com.cms.assetmanagement.service.ImageProcessingService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ImageProcessingControllerTest {

    @InjectMocks
    private ImageProcessingController imageProcessingController;

    @Mock
    private ImageProcessingService imageProcessingService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getProcessedImages_success() {
        String requestId = "testRequestId";
        List<ProcessedImageDto> processedImageDtos = new ArrayList<>();
        processedImageDtos.add(new ProcessedImageDto());
        when(imageProcessingService.getProcessedImagesByReqId(requestId)).thenReturn(
            processedImageDtos);

        ResponseDto response = imageProcessingController.getProcessedImages(
            requestId);

        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
    }


    @Test
    void initiateImageProcess_success() {
        PreProcessImageDto preProcessImageDto = PreProcessImageDto.builder().
            countryCode("AA").
            providerId("AAPBE3701VT").
            assetId("assetId").
            imageUrls(List.of("url1", "url2")).
            serviceBatchId("batchId").build();
        doNothing().when(imageProcessingService).initiateImageProcess(preProcessImageDto);

        imageProcessingController.initiateImageProcess(preProcessImageDto);

        verify(imageProcessingService, times(1)).initiateImageProcess(preProcessImageDto);
    }

    @Test
    void deleteImageByReqId_success() {
        String requestId = "req123";
        doNothing().when(imageProcessingService).deleteImageByReqId(requestId);

        imageProcessingController.deleteImageByReqId(requestId);

        verify(imageProcessingService, times(1)).deleteImageByReqId(requestId);
    }

}