package com.cms.assetmanagement.common.window_util.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.assetmanagement.common.window_util.model.DateRangeWindow;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.common.window_util.model.WindowType;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import java.lang.reflect.Field;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest(classes = DateRangeWindowServiceTest.class)
class DateRangeWindowServiceTest {

    @Mock
    private VodAssetMapper vodAssetMapper;

    Instant currTime = Instant.now();
    Instant ins10HrsBefore = currTime.minus(10, ChronoUnit.HOURS);
    Instant ins10HrsAfter = currTime.plus(10, ChronoUnit.HOURS);
    Instant ins20HrsBefore = currTime.minus(20, ChronoUnit.HOURS);
    Instant ins20HrsAfter = currTime.plus(20, ChronoUnit.HOURS);
    Instant ins30HrsBefore = currTime.minus(30, ChronoUnit.HOURS);
    Instant ins30HrsAfter = currTime.plus(30, ChronoUnit.HOURS);
    Instant ins40HrsBefore = currTime.minus(40, ChronoUnit.HOURS);
    Instant ins40HrsAfter = currTime.plus(40, ChronoUnit.HOURS);
    Instant ins50HrsBefore = currTime.minus(50, ChronoUnit.HOURS);

    Instant ins10MinBefore = currTime.minus(10, ChronoUnit.MINUTES);
    Instant ins20MinBefore = currTime.minus(20, ChronoUnit.MINUTES);
    Instant ins10MinAfter = currTime.plus(10, ChronoUnit.MINUTES);
    Instant ins20MinAfter = currTime.plus(20, ChronoUnit.MINUTES);

    String time10HrsBefore = DateTimeFormatter.ISO_INSTANT.format(ins10HrsBefore);
    String time10HrsAfter = DateTimeFormatter.ISO_INSTANT.format(ins10HrsAfter);
    String time20HrsBefore = DateTimeFormatter.ISO_INSTANT.format(ins20HrsBefore);
    String time20HrsAfter = DateTimeFormatter.ISO_INSTANT.format(ins20HrsAfter);
    String time30HrsBefore = DateTimeFormatter.ISO_INSTANT.format(ins30HrsBefore);
    String time30HrsAfter = DateTimeFormatter.ISO_INSTANT.format(ins30HrsAfter);
    String time40HrsBefore = DateTimeFormatter.ISO_INSTANT.format(ins40HrsBefore);
    String time40HrsAfter = DateTimeFormatter.ISO_INSTANT.format(ins40HrsAfter);
    String time50HrsBefore = DateTimeFormatter.ISO_INSTANT.format(ins50HrsBefore);

    String time10MinBefore = DateTimeFormatter.ISO_INSTANT.format(ins10MinBefore);
    String time20MinBefore = DateTimeFormatter.ISO_INSTANT.format(ins20MinBefore);
    String time10MinAfter = DateTimeFormatter.ISO_INSTANT.format(ins10MinAfter);
    String time20MinAfter = DateTimeFormatter.ISO_INSTANT.format(ins20MinAfter);

    LicenseWindowDto activeWindow = LicenseWindowDto.builder().licenseId("1")
        .availableStarting(time10HrsBefore)
        .availableEnding(time10HrsAfter).build();
    LicenseWindowDto expiredWindow = LicenseWindowDto.builder().licenseId("2")
        .availableStarting(time30HrsBefore)
        .availableEnding(time20HrsBefore).build();
    LicenseWindowDto expiredWindowOld = LicenseWindowDto.builder().licenseId("3")
        .availableStarting(time50HrsBefore)
        .availableEnding(time40HrsBefore).build();
    LicenseWindowDto nextActiveWindow = LicenseWindowDto.builder().licenseId("4")
        .availableStarting(time20HrsAfter)
        .availableEnding(time30HrsAfter).build();
    LicenseWindowDto nextActiveWindowNewer = LicenseWindowDto.builder().licenseId("5")
        .availableStarting(time40HrsAfter)
        .availableEnding(null).build();
    LicenseWindowDto expiredCloserWindow = LicenseWindowDto.builder().licenseId("6")
        .availableStarting(time20MinBefore)
        .availableEnding(time10MinBefore).build();
    LicenseWindowDto nextCloserWindow = LicenseWindowDto.builder().licenseId("7")
        .availableStarting(time10MinAfter)
        .availableEnding(time20MinAfter).build();

    @InjectMocks
    private DateRangeWindowService dateRangeWindowService;

    @BeforeEach
    void init() throws NoSuchFieldException, IllegalAccessException {
        Field mergeHourGapField = DateRangeWindowService.class.getDeclaredField("mergeHourGap");
        mergeHourGapField.setAccessible(true);
        mergeHourGapField.set(dateRangeWindowService, 1);
    }

    static List<Arguments> findAndUpdateEventActiveSlotParams() {
        EventWindowDto eventWindow = EventWindowDto.builder()
            .eventId("test-event")
            .eventStarting("2024-01-01T10:00:00Z")
            .eventEnding("2024-01-01T12:00:00Z")
            .build();
        return List.of(
            Arguments.of(new ArrayList<>(List.of(eventWindow)))
        );
    }
    
    @Test
    void findUpdateSlotTest_ActiveSlotFound() {
        List<LicenseWindowDto> windows = List.of(expiredWindowOld, expiredWindow, activeWindow,
            nextActiveWindow, nextActiveWindowNewer);
        assertEquals(activeWindow, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void findUpdateSlotTest_NextActiveSlotFound() {
        List<LicenseWindowDto> windows = List.of(expiredWindowOld, expiredWindow, nextActiveWindow,
            nextActiveWindowNewer);
        assertEquals(nextActiveWindow, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void findUpdateSlotTest_NextActiveSlotFound_EventWindow() {
        EventWindowDto oldWindow = EventWindowDto.builder().eventId("1")
            .eventStarting(time30HrsBefore).eventEnding(time20HrsBefore).build();
        EventWindowDto nextWindow = EventWindowDto.builder().eventId("2")
            .eventStarting(time30HrsAfter).eventEnding(time20HrsAfter).build();
        List<EventWindowDto> windows = List.of(oldWindow, nextWindow);
        assertEquals(nextWindow, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void findUpdateSlotTest_NextActiveSlotFound_NoPreviousWindows() {
        List<LicenseWindowDto> windows = List.of(nextActiveWindow, nextActiveWindowNewer);
        assertEquals(nextActiveWindow, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void findUpdateSlotTest_NextActiveSlotFound_ActiveSlotCloserThan1Hour() {
        List<LicenseWindowDto> windows = List.of(expiredWindowOld, expiredWindow,
            expiredCloserWindow, nextCloserWindow, nextActiveWindow, nextActiveWindowNewer);
        LicenseWindowDto mergedActiveWindow = LicenseWindowDto.builder()
            .availableStarting(time20MinBefore)
            .availableEnding(time20MinAfter).build();
        var res = dateRangeWindowService.findUpdateSlot(windows);
        assertEquals(mergedActiveWindow.getAvailableStarting(), res.getAvailableStarting());
        assertEquals(mergedActiveWindow.getAvailableEnding(), res.getAvailableEnding());
    }

    @Test
    void findUpdateSlotTest_NextActiveSlotFound_NullEndTime() {
        List<LicenseWindowDto> windows = List.of(expiredWindowOld, expiredWindow,
            nextActiveWindowNewer);
        assertEquals(nextActiveWindowNewer, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void findUpdateSlotTest_LastActiveSlotFound() {
        List<LicenseWindowDto> windows = List.of(expiredWindowOld, expiredWindow);
        assertEquals(expiredWindow, dateRangeWindowService.findUpdateSlot(windows));
    }

    @Test
    void sortWindowsTest_EmptyList() {
        List<LicenseWindowDto> windows = new ArrayList<>();
        assertDoesNotThrow(() -> dateRangeWindowService.sortWindows(windows));
    }

    @Test
    void sortWindowsTest_NullList() {
        assertDoesNotThrow(() -> dateRangeWindowService.sortWindows(null));
    }

    @Test
    void sortWindowsTest_AlreadySorted() {

        List<LicenseWindowDto> windows = new ArrayList<>(
            Arrays.asList(expiredWindow, activeWindow, nextActiveWindow));
        List<LicenseWindowDto> sortedWindows = new ArrayList<>(
            Arrays.asList(expiredWindow, activeWindow, nextActiveWindow));

        assertDoesNotThrow(() -> dateRangeWindowService.sortWindows(windows));
        assertEquals(windows, sortedWindows);
    }

    @Test
    void sortWindowsTest() {
        List<LicenseWindowDto> windows = new ArrayList<>(
            Arrays.asList(nextActiveWindow, expiredWindow, activeWindow, expiredWindowOld));
        List<LicenseWindowDto> sortedWindows = new ArrayList<>(
            Arrays.asList(expiredWindowOld, expiredWindow, activeWindow, nextActiveWindow));

        assertDoesNotThrow(() -> dateRangeWindowService.sortWindows(windows));
        assertEquals(windows, sortedWindows);
    }

    @Test
    void areWindowsNonOverlappingTest_EmptyList() {
        List<LicenseWindowDto> windows = List.of();

        assertTrue(dateRangeWindowService.areWindowsNonOverlapping(windows));
    }

    @Test
    void areWindowsNonOverlappingTest_NullList() {
        assertTrue(dateRangeWindowService.areWindowsNonOverlapping(null));
    }

    @Test
    void areWindowsNonOverlappingTest_SizeOneList() {
        List<LicenseWindowDto> windows = List.of(activeWindow);

        assertTrue(dateRangeWindowService.areWindowsNonOverlapping(windows));
    }

    @Test
    void areWindowsNonOverlappingTest_NonOverlapping() {
        List<LicenseWindowDto> windows = List.of(expiredWindow, activeWindow, nextActiveWindow);

        assertTrue(dateRangeWindowService.areWindowsNonOverlapping(windows));
    }

    @Test
    void areWindowsNonOverlappingTest_Overlapping() {
        LicenseWindowDto win1 = LicenseWindowDto.builder().availableStarting(time30HrsBefore)
            .availableEnding(time10HrsAfter).build();
        LicenseWindowDto win2 = LicenseWindowDto.builder().availableStarting(time20HrsBefore)
            .availableEnding(time40HrsAfter).build();

        List<LicenseWindowDto> windows = List.of(win1, win2);

        assertFalse(dateRangeWindowService.areWindowsNonOverlapping(windows));
    }

    @Test
    void mergeWindowsTest() {
        List<LicenseWindowDto> list1 = List.of(expiredWindowOld, expiredWindow, activeWindow);
        List<LicenseWindowDto> list2 = List.of(activeWindow, nextActiveWindow,
            nextActiveWindowNewer);
        List<LicenseWindowDto> resList = List.of(expiredWindowOld, expiredWindow, activeWindow,
            nextActiveWindow, nextActiveWindowNewer);

        assertEquals(resList, dateRangeWindowService.mergeWindows(list1, list2));
    }

    @Test
    void addTzToTimestampsTest_Null() {
        assertDoesNotThrow(() -> dateRangeWindowService.addTzToTimestamps(null));
    }

    @Test
    void addTzToTimestampsTest_Empty() {
        assertDoesNotThrow(() -> dateRangeWindowService.addTzToTimestamps(List.of()));
    }

    @Test
    void addTzToTimestampsTest() {
        LicenseWindowDto input = LicenseWindowDto.builder().availableStarting("2024-12-12 03:00:00")
            .availableEnding("2024-12-13 04:00:00").build();
        LicenseWindowDto expected = LicenseWindowDto.builder()
            .availableStarting("2024-12-12T03:00:00Z").availableEnding("2024-12-13T04:00:00Z")
            .build();

        dateRangeWindowService.addTzToTimestamps(List.of(input));
        assertEquals(expected, input);
    }

    @Test
    void removeTzFromTimestampsTest_Empty() {
        assertDoesNotThrow(() -> dateRangeWindowService.removeTzFromTimestamps(List.of()));
    }

    @Test
    void removeTzFromTimestampsTest_Null() {
        assertDoesNotThrow(() -> dateRangeWindowService.removeTzFromTimestamps(null));
    }

    @Test
    void removeTzFromTimestampsTest() {
        LicenseWindowDto expected = LicenseWindowDto.builder()
            .availableStarting("2024-12-12 03:00:00")
            .availableEnding("2024-12-13 04:00:00").build();
        LicenseWindowDto input = LicenseWindowDto.builder()
            .availableStarting("2024-12-12T03:00:00Z").availableEnding("2024-12-13T04:00:00Z")
            .build();

        dateRangeWindowService.removeTzFromTimestamps(List.of(input));
        assertEquals(expected, input);
    }

    @Test
    void areWindowsValidTest_Null() {
        assertTrue(dateRangeWindowService.areWindowsValid(null));
    }

    @Test
    void areWindowsValidTest_Valid() {
        assertTrue(dateRangeWindowService.areWindowsValid(
            List.of(activeWindow, expiredWindow, nextActiveWindowNewer)));
    }

    @Test
    void areWindowsValidTest_Invalid() {
        LicenseWindowDto invalidWindow = LicenseWindowDto.builder()
            .availableStarting(time20MinAfter).availableEnding(time10MinAfter).build();
        assertFalse(dateRangeWindowService.areWindowsValid(List.of(invalidWindow)));
    }

    @Test
    void getDuplicateLicenseIdsTest_nullList() {
        assertEquals(List.of(), dateRangeWindowService.getDuplicateLicenseIds(null));
    }

    @Test
    void getDuplicateLicenseIdsTest() {
        List<LicenseWindowDto> inputWindows = List.of(
            LicenseWindowDto.builder().licenseId("1").build(),
            LicenseWindowDto.builder().licenseId("1").build(),
            LicenseWindowDto.builder().licenseId("1").build(),
            LicenseWindowDto.builder().licenseId("2").build(),
            LicenseWindowDto.builder().licenseId("2").build()
        );

        List<String> outputWindows = List.of("1", "2");

        assertEquals(outputWindows, dateRangeWindowService.getDuplicateLicenseIds(inputWindows));
    }

    @Test
    void getDuplicateLicenseIdsTest_NoDuplicates() {
        List<LicenseWindowDto> inputWindows = List.of(
            LicenseWindowDto.builder().licenseId("1").build(),
            LicenseWindowDto.builder().licenseId("2").build(),
            LicenseWindowDto.builder().licenseId("3").build(),
            LicenseWindowDto.builder().licenseId("4").build(),
            LicenseWindowDto.builder().licenseId("5").build()
        );

        List<String> outputWindows = List.of();

        assertEquals(outputWindows, dateRangeWindowService.getDuplicateLicenseIds(inputWindows));
    }

    List<Arguments> getWindowListParams() {
        return List.of(
            Arguments.of(WindowType.LICENSE_WINDOW, true),
            Arguments.of(WindowType.LICENSE_WINDOW, false),
            Arguments.of(WindowType.EVENT_WINDOW, true),
            Arguments.of(WindowType.EVENT_WINDOW, false)
        );
    }

    @ParameterizedTest
    @MethodSource("getWindowListParams")
    void getWindowListFromDbTest(WindowType windowType,
        boolean shouldMerge) {
        Mockito.when(vodAssetMapper.getLicenseWindow(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(List.of());
        Mockito.when(vodAssetMapper.getEventWindows(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(List.of());

        assertDoesNotThrow(
            () -> dateRangeWindowService.getWindowListFromDb("TEST", "TEST", "TEST", shouldMerge,
                windowType));
    }

    List<Arguments> updateWindowActiveSlotParams() {
        return List.of(
            Arguments.of(new LicenseWindowDto()),
            Arguments.of(new EventWindowDto())
        );
    }

    @ParameterizedTest
    @MethodSource("updateWindowActiveSlotParams")
    <T extends DateRangeWindow> void updateWindowActiveSlotTest(T activeSlot) {
        assertDoesNotThrow(
            () -> dateRangeWindowService.updateWindowActiveSlot("TEST", "TEST", "AA", activeSlot)
        );
    }


    @Test
    void findAndUpdateLicenseActiveSlotTest_EmptyInputList() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        assertFalse(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID",
                List.of()));
    }

    @Test
    void findAndUpdateLicenseActiveSlotTest_NullInputList() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        assertFalse(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID", null));
    }

    @Test
    void findAndUpdateLicenseActiveSlotTest_NoActiveSlot() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        Instant now = Instant.now();
        Instant winStart = now.minus(10, ChronoUnit.MINUTES);
        Instant winEnd = now.minus(5, ChronoUnit.MINUTES);

        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder()
            .availableStarting(DateTimeFormatter.ISO_INSTANT.format(winStart))
            .availableEnding(DateTimeFormatter.ISO_INSTANT.format(winEnd)).build();
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(licenseWindowDto);

        assertTrue(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID",
                licenseWindowDtos));
    }

    @Test
    void findAndUpdateLicenseActiveSlotTest_NoActiveSlot2() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        Instant now = Instant.now();
        Instant winStart = now.plus(6, ChronoUnit.MINUTES);
        Instant winEnd = now.plus(10, ChronoUnit.MINUTES);

        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder()
            .availableStarting(DateTimeFormatter.ISO_INSTANT.format(winStart))
            .availableEnding(DateTimeFormatter.ISO_INSTANT.format(winEnd)).build();
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(licenseWindowDto);

        assertTrue(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID",
                licenseWindowDtos));
    }

    @Test
    void findAndUpdateLicenseActiveSlotTest_Success() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        Instant now = Instant.now();
        Instant winStart = now.minus(10, ChronoUnit.MINUTES);
        Instant winEnd = now.plus(10, ChronoUnit.MINUTES);

        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder()
            .availableStarting(DateTimeFormatter.ISO_INSTANT.format(winStart))
            .availableEnding(DateTimeFormatter.ISO_INSTANT.format(winEnd)).build();
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(licenseWindowDto);

        assertTrue(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID",
                licenseWindowDtos));
    }

    @ParameterizedTest
    @NullAndEmptySource
    @MethodSource("findAndUpdateEventActiveSlotParams")
    void findAndUpdateEventActiveSlotTest(List<EventWindowDto> windows) {
        assertDoesNotThrow(
            () -> dateRangeWindowService.findAndUpdateEventActiveSlot("TEST", "TEST", "TEST",
                windows));
    }

    @Test
    void updateDateRangeWindowTest_Success_NullExpDate() {
        Mockito.doNothing().when(vodAssetMapper)
            .updateLicenseWindow(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
                Mockito.any());

        Instant now = Instant.now();
        Instant winStart = now.minus(10, ChronoUnit.MINUTES);

        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder()
            .availableStarting(DateTimeFormatter.ISO_INSTANT.format(winStart))
            .availableEnding(null).build();
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(licenseWindowDto);

        assertTrue(
            () -> dateRangeWindowService.findAndUpdateLicenseActiveSlot("ID", "AA", "VP_ID",
                licenseWindowDtos));
    }

}
