package com.cms.assetmanagement.config;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

class PostgresMetadataConfigTest {

    @Test
    void postgresSessionFactory_ShouldReturnSqlSessionFactory() throws Exception {
        // Given
        PostgresMetadataConfig config = new PostgresMetadataConfig();
        DataSource dataSource = mock(DataSource.class);

        // When & Then
        assertDoesNotThrow(() -> {
            SqlSessionFactory sessionFactory = config.postgresSessionFactory(dataSource);
            assertNotNull(sessionFactory);
        });
    }

    @Test
    void primaryTransactionManager_ShouldReturnDataSourceTransactionManager() {
        // Given
        PostgresMetadataConfig config = new PostgresMetadataConfig();
        DataSource dataSource = mock(DataSource.class);

        // When
        DataSourceTransactionManager transactionManager =
            (DataSourceTransactionManager) config.primaryTransactionManager(
                dataSource);

        // Then
        assertNotNull(transactionManager);
    }
}
