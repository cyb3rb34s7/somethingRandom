package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import org.junit.jupiter.api.Test;

class ErrorMessageUtilTest {

    @Test
    void testPrivateConstructor() throws Exception {
        // Test that the constructor is private
        Constructor<ErrorMessageUtil> constructor = ErrorMessageUtil.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);

        // Verify that constructor can be called (doesn't throw exception)
        assertDoesNotThrow(() -> {
            constructor.newInstance();
        });
    }

    @Test
    void testGenerateErrMessage_NullPointerException() {
        // Test with NullPointerException
        NullPointerException npe = new NullPointerException();
        String result = ErrorMessageUtil.generateErrMessage(npe);
        assertEquals("Null pointer exception occurred", result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithMessage() {
        // Test with exception that has a message
        Exception exception = new Exception("Test error message");
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertEquals("Test error message", result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithBlankMessage() {
        // Test with exception that has a blank message
        Exception exception = new Exception("") {
            @Override
            public String getMessage() {
                return "";
            }
        };
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertEquals("Unknown error occurred", result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithNullMessage() {
        // Test with exception that has a null message
        Exception exception = new Exception() {
            @Override
            public String getMessage() {
                return null;
            }
        };
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertEquals("Unknown error occurred", result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithCause() {
        // Test with exception that has a cause with message
        Exception cause = new Exception("Cause message");
        Exception exception = new Exception(cause);
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertNotNull(result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithMultipleCauses() {
        // Test with exception that has multiple causes
        Exception rootCause = new Exception("Root cause message");
        Exception middleCause = new Exception(rootCause);
        Exception exception = new Exception(middleCause);
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertNotNull(result);
    }

    @Test
    void testGenerateErrMessage_ExceptionWithCausesButNoMessages() {
        // Test with exception that has causes but no messages
        Exception rootCause = new Exception() {
            @Override
            public String getMessage() {
                return null;
            }
        };
        Exception middleCause = new Exception(rootCause) {
            @Override
            public String getMessage() {
                return null;
            }
        };
        Exception exception = new Exception(middleCause) {
            @Override
            public String getMessage() {
                return null;
            }
        };
        String result = ErrorMessageUtil.generateErrMessage(exception);
        assertEquals("Unknown error occurred", result);
    }
}
