package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.SortDto;
import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class UtilsTest {

    @InjectMocks
    Utils utils;
    HashMap<String, String> tableColumnMap = new HashMap<>();
    @Mock
    private AssetTableColumnMapping assetTableColumnMapping;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @PostConstruct
    public void init() {
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("contentId", "CONTENT_ID");
        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);
    }

    @Test
    void testGetColumnMapping_InvalidColumn() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("contentId", "CONTENT_ID");
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder().
            columns(List.of("invalidColumn", "shortTitle", "contentId"))
            .build();
        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);

        assertThrows(InvalidInputDataException.class,
            () -> utils.getColumnMapping(filterBody));
    }

    @Test
    void testGetColumnMapping_InvalidFilter() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("contentId", "CONTENT_ID");
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder().
            filters(List.of(
                FilterDto.builder().type("filter").key("invalidColumn")
                    .values(List.of("game of thrones")).build(),
                FilterDto.builder().type("filter").key("shortTitle").values(List.of("got"))
                    .build()))
            .build();
        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);
        assertThrows(InvalidInputDataException.class,
            () -> utils.getColumnMapping(filterBody));
    }

    @Test
    void testGetColumnMapping_InvalidSortColumn() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("contentId", "CONTENT_ID");
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder().
            sortBy(List.of(SortDto.builder().order("DESC").field("invalidColumn").build()))
            .build();
        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);
        assertThrows(InvalidInputDataException.class,
            () -> utils.getColumnMapping(filterBody));
    }


    @Test
    void testGetUTCDateTime() {
        // Arrange
        String date = "2023-10-01T00:00:00Z";
        String dateFormat = Constants.EXPIRY_DATE_FORMAT;
        Instant expectedInstant = Instant.parse("2023-10-01T00:00:00Z");

        // Act
        Instant actualInstant = utils.getUTCDateTime(date, dateFormat);

        // Assert
        assertEquals(expectedInstant, actualInstant);
    }

    @Test
    void testGetUTCDateTimeDateNull() {
        String dateFormat = Constants.EXPIRY_DATE_FORMAT;

        Instant actualInstant = utils.getUTCDateTime(null, dateFormat);

        assertNull(actualInstant);
    }

    @Test
    void testGetStatusReadyForRelease() {
        String licenseWindow = "Upcoming";
        String status = "Released";

        String newStatus = utils.getStatus(licenseWindow, status);

        assertEquals(Constants.READY_FOR_RELEASE, newStatus);
    }

    @Test
    void testGetStatusWithWindowExpired() {
        String licenseWindow = "Expired";
        String status = "Released";

        String newStatus = utils.getStatus(licenseWindow, status);

        assertEquals(status, newStatus);
    }

    @Test
    void testGetStatusAllOthers() {
        String licenseWindow = "Active";
        String status = "Ready For QC";

        String newStatus = utils.getStatus(licenseWindow, status);

        assertEquals(status, newStatus);
    }


    @Test
    void testGetLicenseWindow_Active() {

        Instant currTime = Instant.now();
        Instant ins40DaysBefore = currTime.minus(40, ChronoUnit.DAYS);
        Instant ins40DaysAfter = currTime.plus(40, ChronoUnit.DAYS);

        String startDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(ins40DaysBefore);
        String expDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(ins40DaysAfter);

        String licenseWindow = utils.getLicenseWindow(startDate, expDate);

        assertEquals("Active", licenseWindow);
    }

    @Test
    void testGetLicenseWindow_Upcoming_after300days() {

        Instant currTime = Instant.now();
        Instant ins400DaysAfter = currTime.plus(400, ChronoUnit.DAYS);
        Instant ins401DaysAfter = currTime.plus(401, ChronoUnit.DAYS);

        String startDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(ins400DaysAfter);
        String expDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(ins401DaysAfter);

        String licenseWindow = utils.getLicenseWindow(startDate, expDate);

        assertEquals("Upcoming after 300 days", licenseWindow);
    }

    @Test
    void testGetLicenseWindow_ExpiringIn() {
        Instant nowUtc = Instant.now().minusSeconds(3600);
        String startDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(nowUtc);

        Instant upcomingUtc = Instant.now().plusSeconds(3600);
        String expDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(ZoneOffset.UTC).format(upcomingUtc);

        String licenseWindow = utils.getLicenseWindow(startDate, expDate);

        assertEquals("Expiring in 0 days", licenseWindow);
    }

    @Test
    void testGetLicenseWindowWithExpDateNull() {
        String startDate = "2024-05-16T00:00:00Z";

        String licenseWindow = utils.getLicenseWindow(startDate, null);

        assertEquals("Active", licenseWindow);
    }

    @Test
    void testGetLicenseWindowActive() {
        String startDate = "2024-05-16T00:00:00Z";
        String expDate = "2029-09-30T04:00:00Z";

        String licenseWindow = utils.getLicenseWindow(startDate, expDate);

        assertEquals("Active", licenseWindow);

    }

    @Test
    void testGetLicenseWindowWithStartDateNull() {
        String expDate = "2024-09-30T04:00:00Z";

        String licenseWindow = utils.getLicenseWindow(null, expDate);

        assertEquals("", licenseWindow);
    }

    @ParameterizedTest
    @CsvSource({
        "'Released', 'worker1', 'worker1,worker2,worker3'",
        "'Released', 'worker4', 'worker1,worker2,worker3'",
        "'Released', '', 'worker1,worker2,worker3'",
        "'Released', 'worker1', ''"
    })
    void testCheckExternalAsset(String status, String feedWorker, String feedWorkersString) {
        String[] feedWorkersArray = feedWorkersString.split(",");
        List<String> feedWorkers = Arrays.asList(feedWorkersArray);

        String expected =
            (feedWorker == null || feedWorkers.contains(feedWorker)) ? "Released" : "Untrackable";
        String result = utils.checkExternalAsset(status, feedWorker, feedWorkers);

        assertEquals(expected, result);
    }

    @Test
    void testCheckExternalAsset_WithEmptyFeedWorkers() {
        String status = "Released";
        String feedWorker = "worker1";
        List<String> feedWorkers = List.of();

        String result = utils.checkExternalAsset(status, feedWorker, feedWorkers);

        assertEquals("Released", result);
    }

    @Test
    void testCheckExternalAssetForDbStatus_WithValidFeedWorker() {
        String dbStatus = "Released";
        String feedWorker = "worker1";
        List<String> feedWorkers = List.of("worker1", "worker2", "worker3");

        String result = utils.checkExternalAssetForDbStatus(dbStatus, feedWorker, feedWorkers);

        assertEquals("Released", result);
    }

    @Test
    void testCheckExternalAssetForDbStatus_WithInvalidFeedWorker() {
        String dbStatus = "Released";
        String feedWorker = "worker4";
        List<String> feedWorkers = List.of("worker1", "worker2", "worker3");

        String result = utils.checkExternalAssetForDbStatus(dbStatus, feedWorker, feedWorkers);

        assertEquals("Untrackable", result);
    }

    @Test
    void testPreProcessInput_WithFilters() {
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .filters(List.of(
                FilterDto.builder().type("filter").key("mainTitle")
                    .values(List.of("game of thrones'")).build(),
                FilterDto.builder().type("filter").key("shortTitle").values(List.of("got'"))
                    .build()))
            .build();

        AssetFilterBodyDto result = utils.preProcessInput(filterBody);

        assertEquals("game of thrones\"", result.getFilters().get(0).getValues().get(0));
        assertEquals("got\"", result.getFilters().get(1).getValues().get(0));
    }

    @Test
    void testPreProcessInput_WithNullFilters() {
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .filters(null)
            .build();

        AssetFilterBodyDto result = utils.preProcessInput(filterBody);

        assertNull(result.getFilters());
    }

    @Test
    void testPreProcessInput_WithEmptyFilters() {
        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .filters(List.of())
            .build();

        AssetFilterBodyDto result = utils.preProcessInput(filterBody);

        assertEquals(0, result.getFilters().size());
    }

    @Test
    void testGetColumnMapping_WithNullColumns() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("mainTitle", "MAIN_TITLE");

        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .columns(null)
            .build();

        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);

        AssetFilterBodyDto result = utils.getColumnMapping(filterBody);

        assertNull(result.getColumns());
    }

    @Test
    void testGetColumnMapping_WithEmptyColumns() {
        HashMap<String, String> tableColumnMap = new HashMap<>();
        tableColumnMap.put("mainTitle", "MAIN_TITLE");

        AssetFilterBodyDto filterBody = AssetFilterBodyDto.builder()
            .columns(List.of())
            .build();

        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);

        AssetFilterBodyDto result = utils.getColumnMapping(filterBody);

        assertEquals(0, result.getColumns().size());
    }
}
