package com.cms.assetmanagement.interceptor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

class InterceptorConfigTest {

    private InterceptorConfig interceptorConfig;

    @Mock
    private ApiInterceptor apiInterceptor;

    @Mock
    private InterceptorRegistry interceptorRegistry;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        interceptorConfig = new InterceptorConfig(apiInterceptor);
    }

    @Test
    void constructor_ShouldInitializeWithApiInterceptor() {
        // Then
        assertNotNull(interceptorConfig);
        // We can't directly access the private field, but we can verify it was set through behavior
    }

    @Test
    void addInterceptors_ShouldRegisterApiInterceptorWithCorrectPaths() {
        // Given
        InterceptorRegistry registry = mock(InterceptorRegistry.class);
        InterceptorRegistration interceptorRegistration = mock(InterceptorRegistration.class);
        
        // Mock the chaining methods to return the same registration object
        when(registry.addInterceptor(any())).thenReturn(interceptorRegistration);
        when(interceptorRegistration.addPathPatterns(any(String[].class))).thenReturn(interceptorRegistration);

        // When & Then
        assertDoesNotThrow(() -> interceptorConfig.addInterceptors(registry));
        
        // Verify that the interceptor is added with the correct paths
        verify(registry).addInterceptor(apiInterceptor);
        verify(interceptorRegistration).addPathPatterns(
            "/cms/tvplus/asset/sync/insert", 
            "/cms/tvplus/asset/sync/update",
            "/cms/tvplus/asset/status", 
            "/cms/tvplus/asset/delete"
        );
    }
}
