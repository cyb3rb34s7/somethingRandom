package com.cms.assetmanagement.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ErrorConstants;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.exception.DatabaseException;
import com.cms.assetmanagement.exception.JsonSchemaValidationException;
import com.cms.assetmanagement.mapper.asset.content.JsonValidatorMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.filter.ContentKeyDto;
import com.cms.assetmanagement.model.filter.ContentProviderDto;
import com.cms.assetmanagement.model.filter.ParentalRatingsDto;
import com.cms.assetmanagement.model.media.MediaAssetDto;
import com.cms.assetmanagement.model.smf.AssetDto;
import com.cms.assetmanagement.model.smf.AssetParentalRatingDto;
import com.cms.assetmanagement.model.smf.AssetPlaybackDto;
import com.cms.assetmanagement.model.smf.AssetSeriesInfo;
import com.cms.assetmanagement.model.smf.AssetTitleDto;
import com.cms.assetmanagement.model.util.ErrorDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = SchemaValidatorServiceTest.class)
class SchemaValidatorServiceTest {

    @Mock
    private JsonValidatorMapper jsonValidatorMapper;

    @Mock
    private DateRangeWindowService dateRangeWindowService;

    @Mock
    private VodAssetMapper vodAssetMapper;

    @InjectMocks
    @Spy
    private SchemaValidatorService schemaValidatorService;

    @Test
    void parentSeasonValidationTest_NullSeasonId() {
        assertNull(schemaValidatorService.parentSeasonValidation(null, null, new ArrayList<>()));
    }

    @Test
    void parentSeasonValidationTest_ParentIsNull() {
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(null);

        assertNull(
            schemaValidatorService.parentSeasonValidation("TEST_ID", null, new ArrayList<>()));
    }

    @Test
    void parentSeasonValidationTest_TypeMismatch() {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder().type(Constants.EPISODE)
            .seasonNumber(0).build();
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(contentProviderDto);

        assertNull(
            schemaValidatorService.parentSeasonValidation("TEST_ID", "TEST", new ArrayList<>()));
    }

    @Test
    void parentSeasonValidationTest_Ok() {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder().type(Constants.SEASON)
            .seasonNumber(3).build();
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(contentProviderDto);

        assertEquals(contentProviderDto,
            schemaValidatorService.parentSeasonValidation("TEST_ID", "TEST", new ArrayList<>()));
    }

    @Test
    void parentSeasonValidationTest_Exception() {
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenThrow(new DatabaseException("TEST"));

        List<ErrorDto> errorList = new ArrayList<>();

        assertThrows(DatabaseException.class,
            () -> schemaValidatorService.parentSeasonValidation("TEST_ID", "TEST", errorList));
    }

    @Test
    void parentShowValidationTest_NullSeasonId() {
        assertNull(schemaValidatorService.parentShowValidation(null, null, new ArrayList<>()));
    }

    @Test
    void parentShowValidationTest_ParentIsNull() {
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(null);

        assertNull(
            schemaValidatorService.parentShowValidation("TEST_ID", null, new ArrayList<>()));
    }

    @Test
    void parentShowValidationTest_TypeMismatch() {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder().type(Constants.EPISODE)
            .seasonNumber(0).build();
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(contentProviderDto);

        assertNull(
            schemaValidatorService.parentShowValidation("TEST_ID", "TEST", new ArrayList<>()));
    }

    @Test
    void parentShowValidationTest_Ok() {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder().type(Constants.SHOW)
            .seasonNumber(5).build();
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenReturn(contentProviderDto);

        assertEquals(contentProviderDto,
            schemaValidatorService.parentShowValidation("TEST_ID", "TEST", new ArrayList<>()));
    }

    @Test
    void parentShowValidationTest_Exception() {
        Mockito.when(jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(),
            Mockito.anyString())).thenThrow(new DatabaseException("TEST"));

        List<ErrorDto> errorList = new ArrayList<>();

        assertThrows(DatabaseException.class,
            () -> schemaValidatorService.parentShowValidation("TEST_ID", "TEST", errorList));
    }

    @Test
    void parentAssetValidationTest_ShowType() {
        AssetDto asset = AssetDto.builder().type(Constants.SHOW).build();

        assertTrue(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_SeasonType_NoSeriesInfo() {
        AssetDto asset = AssetDto.builder().type(Constants.SEASON).build();

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_SeasonType() {

        AssetDto asset = AssetDto.builder().type(Constants.SEASON).seriesInfo(
            AssetSeriesInfo.builder().showId("TEST").build()).build();

        Mockito.when(
            schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(new ContentProviderDto());

        assertTrue(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_SeasonType_ReturnNull() {
        AssetDto asset = AssetDto.builder().type(Constants.SEASON).seriesInfo(
            AssetSeriesInfo.builder().showId("TEST").build()).build();

        Mockito.when(
            schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(null);

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType_NoSeriesInfo() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).build();

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).seriesInfo(
                AssetSeriesInfo.builder().showId("TEST").seasonId("TEST").seasonNumber(5).build())
            .build();

        Mockito.when(
                schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().contentId("SHOW_ID").build());
        Mockito.when(
                schemaValidatorService.parentSeasonValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().showId("SHOW_ID").seasonNumber(5).build());

        assertTrue(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType_Mismatch() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).seriesInfo(
                AssetSeriesInfo.builder().showId("TEST").seasonId("TEST").seasonNumber(5).build())
            .build();

        Mockito.when(
                schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().contentId("SHOW_ID1").build());
        Mockito.when(
                schemaValidatorService.parentSeasonValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().showId("SHOW_ID2").seasonNumber(5).build());

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType_MismatchSeasonNumber() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).seriesInfo(
                AssetSeriesInfo.builder().showId("TEST").seasonId("TEST").seasonNumber(5).build())
            .build();

        Mockito.when(
                schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().contentId("SHOW_ID1").build());
        Mockito.when(
                schemaValidatorService.parentSeasonValidation(Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyList()))
            .thenReturn(ContentProviderDto.builder().showId("SHOW_ID1").seasonNumber(2).build());

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType_ReturnNull() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).seriesInfo(
            AssetSeriesInfo.builder().showId("TEST").seasonId("TEST").build()).build();

        Mockito.when(
            schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(new ContentProviderDto());
        Mockito.when(
            schemaValidatorService.parentSeasonValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(null);

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void parentAssetValidationTest_EpisodeType_ReturnNull2() {
        AssetDto asset = AssetDto.builder().type(Constants.EPISODE).seriesInfo(
            AssetSeriesInfo.builder().showId("TEST").seasonId("TEST").build()).build();

        Mockito.when(
            schemaValidatorService.parentShowValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(null);
        Mockito.when(
            schemaValidatorService.parentSeasonValidation(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList())).thenReturn(new ContentProviderDto());

        assertFalse(schemaValidatorService.parentAssetValidation(asset, "TEST", new ArrayList<>()));
    }

    @Test
    void assetStatusValidationTest_NullContentProvider() {
        assertTrue(schemaValidatorService.assetStatusValidation(null, new ArrayList<>(), true));
    }

    @Test
    void assetStatusValidationTest_NullStatus() {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder().status(null).build();
        assertTrue(
            schemaValidatorService.assetStatusValidation(contentProviderDto, new ArrayList<>(),
                true));
    }

    @ParameterizedTest
    @ValueSource(strings = {Constants.QC_PASS, Constants.TEMP_QC_PASS, Constants.REVOKED})
    void assetStatusValidationTest_InvalidStatus_MediaType(String status) {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder()
            .status(status).build();
        assertFalse(
            schemaValidatorService.assetStatusValidation(contentProviderDto, new ArrayList<>(),
                true));
    }

    @ParameterizedTest
    @ValueSource(strings = {Constants.QC_PASS, Constants.TEMP_QC_PASS})
    void assetStatusValidationTest_InvalidStatus_AssetType(String status) {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder()
            .status(status).build();
        assertFalse(
            schemaValidatorService.assetStatusValidation(contentProviderDto, new ArrayList<>(),
                false));
    }

    @ParameterizedTest
    @ValueSource(strings = {Constants.RELEASED, Constants.READY_FOR_RELEASE})
    void assetStatusValidationTest_Ok_MediaType(String status) {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder()
            .status(status).build();
        assertTrue(
            schemaValidatorService.assetStatusValidation(contentProviderDto, new ArrayList<>(),
                true));
    }

    @ParameterizedTest
    @ValueSource(strings = {Constants.QC_IN_PROGRESS, Constants.QC_FAIL})
    void assetStatusValidationTest_Ok_AssetType(String status) {
        ContentProviderDto contentProviderDto = ContentProviderDto.builder()
            .status(status).build();
        assertTrue(
            schemaValidatorService.assetStatusValidation(contentProviderDto, new ArrayList<>(),
                false));
    }

    @Test
    void validateProgramId_NullCount() {
        Integer assetCount = null;
        Mockito.when(jsonValidatorMapper.countAssetByContentId(Mockito.anyString()))
            .thenReturn(assetCount);

        assertFalse(schemaValidatorService.validateProgramId("TEST"));
    }

    @Test
    void validateProgramId_ZeroCount() {
        Integer assetCount = 0;
        Mockito.when(jsonValidatorMapper.countAssetByContentId(Mockito.anyString()))
            .thenReturn(assetCount);

        assertFalse(schemaValidatorService.validateProgramId("TEST"));
    }

    @Test
    void validateProgramId_PositiveCount() {
        Integer assetCount = 5;
        Mockito.when(jsonValidatorMapper.countAssetByContentId(Mockito.anyString()))
            .thenReturn(assetCount);

        assertTrue(schemaValidatorService.validateProgramId("TEST"));
    }

    @Test
    void processProgramIdCheckTest_validTest() {
        Mockito.when(schemaValidatorService.validateProgramId(Mockito.anyString()))
            .thenReturn(true);

        assertTrue(schemaValidatorService.processProgramIdCheck("Test", new ArrayList<>()));
    }

    @Test
    void processProgramIdCheckTest_invalidTest() {
        Mockito.when(schemaValidatorService.validateProgramId(Mockito.anyString()))
            .thenReturn(false);

        assertFalse(schemaValidatorService.processProgramIdCheck("Test", new ArrayList<>()));
    }

    @Test
    void validateDuplicateIdFromDifferentCpTest_Ok() {
        List<ContentKeyDto> contentKeyDtoList = List.of(
            ContentKeyDto.builder().vcCpId("cpId").build());

        Mockito.when(
                jsonValidatorMapper.getContentIdDetail(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(contentKeyDtoList);

        assertFalse(
            schemaValidatorService.validateDuplicateIdFromDifferentCp("TEST", "TEST", "cpId2"));
    }

    @Test
    void validateDuplicateIdFromDifferentCpTest_Null() {
        Mockito.when(
                jsonValidatorMapper.getContentIdDetail(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(null);

        assertTrue(
            schemaValidatorService.validateDuplicateIdFromDifferentCp("TEST", "TEST", "cpId2"));
    }

    @Test
    void validateDuplicateIdFromDifferentCpTest_Empty() {
        Mockito.when(
                jsonValidatorMapper.getContentIdDetail(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(List.of());

        assertTrue(
            schemaValidatorService.validateDuplicateIdFromDifferentCp("TEST", "TEST", "cpId2"));
    }

    @Test
    void validateDuplicateIdFromDifferentCpTest_Duplicate() {
        List<ContentKeyDto> contentKeyDtoList = List.of(
            ContentKeyDto.builder().vcCpId("cpId").build());

        Mockito.when(
                jsonValidatorMapper.getContentIdDetail(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(contentKeyDtoList);

        assertTrue(
            schemaValidatorService.validateDuplicateIdFromDifferentCp("TEST", "TEST", "cpId"));
    }

    @Test
    void processDuplicateIdFromDifferentCpTest_Valid() {
        Mockito.when(schemaValidatorService.validateDuplicateIdFromDifferentCp(Mockito.anyString(),
            Mockito.anyString(), Mockito.anyString())).thenReturn(true).thenReturn(true);

        assertDoesNotThrow(() -> schemaValidatorService.processDuplicateIdFromDifferentCp(
            AssetDto.builder().programId("TEST").build(), "Test", "Test", new ArrayList<>()));
        assertTrue(schemaValidatorService.processDuplicateIdFromDifferentCp(
            AssetDto.builder().programId("TEST").build(), "Test", "Test", new ArrayList<>()));
    }

    @Test
    void processDuplicateIdFromDifferentCpTest_Invalid() {
        Mockito.when(schemaValidatorService.validateDuplicateIdFromDifferentCp(Mockito.anyString(),
            Mockito.anyString(), Mockito.anyString())).thenReturn(false);

        assertFalse(schemaValidatorService.processDuplicateIdFromDifferentCp(
            AssetDto.builder().programId("TEST").build(), "Test", "Test", new ArrayList<>()));
    }

    @Test
    void validateParentalRatingsTest_Null() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(null);

        assertFalse(schemaValidatorService.validateParentalRatings(List.of(), "TYPE"));
    }

    @Test
    void validateParentalRatingsTest_Empty() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of());

        assertFalse(schemaValidatorService.validateParentalRatings(List.of(), "TYPE"));
    }

    @Test
    void validateParentalRatingsTest_CountryCodeMismatch() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1").build()));

        assertFalse(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("BB").body("Org1").build()), "type1"));
    }

    @Test
    void validateParentalRatingsTest_TypeMismatch() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1").build()));

        assertFalse(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("AA").body("Org1").build()), "type2"));
    }

    @Test
    void validateParentalRatingsTest_OrgMismatch() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1").build()));

        assertFalse(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("AA").body("Org2").build()), "type1"));
    }

    @Test
    void validateParentalRatingsTest_Match_NullCode() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1").code(null)
                .build()));

        assertFalse(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("AA").body("Org1").build()), "type1"));
    }

    @Test
    void validateParentalRatingsTest_Match_InvalidCodeList() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1")
                .code("Code1,Code2,Code3").build()));

        assertFalse(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("AA").body("Org1").code("Code4").build()), "type1"));
    }

    @Test
    void validateParentalRatingsTest_Match_validCodeList() throws SQLException {
        Mockito.when(jsonValidatorMapper.getParentalRatingsList()).thenReturn(List.of(
            ParentalRatingsDto.builder().cntyCd("AA").type("type1").organization("Org1")
                .code("Code1,Code2,Code3").build()));

        assertTrue(
            schemaValidatorService.validateParentalRatings(List.of(AssetParentalRatingDto.builder()
                .countryCode("AA").body("Org1").code("Code1").build()), "type1"));
    }

    @Test
    void processParentalRatingsTest_FlagIsN()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "parentalRatingsCheckFlag");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "N");

        assertTrue(schemaValidatorService.processParentalRatings(AssetDto.builder().build(),
            new ArrayList<>()));
    }

    @Test
    void processParentalRatingsTest_NullParentalRatings()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "parentalRatingsCheckFlag");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "Y");

        assertTrue(schemaValidatorService.processParentalRatings(
            AssetDto.builder().parentalRatings(null).build(), new ArrayList<>()));
    }

    @Test
    void processParentalRatingsTest_EmptyParentalRatings()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "parentalRatingsCheckFlag");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "Y");

        assertTrue(schemaValidatorService.processParentalRatings(
            AssetDto.builder().parentalRatings(List.of()).build(), new ArrayList<>()));
    }

    @Test
    void processParentalRatingsTest_TrueRes()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "parentalRatingsCheckFlag");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "Y");

        Mockito.when(
                schemaValidatorService.validateParentalRatings(Mockito.anyList(), Mockito.anyString()))
            .thenReturn(true);

        assertTrue(schemaValidatorService.processParentalRatings(AssetDto.builder().type("Type")
                .parentalRatings(List.of(AssetParentalRatingDto.builder().build())).build(),
            new ArrayList<>()));
    }

    @Test
    void processParentalRatingsTest_FalseRes()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "parentalRatingsCheckFlag");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "Y");

        Mockito.when(
                schemaValidatorService.validateParentalRatings(Mockito.anyList(), Mockito.anyString()))
            .thenReturn(false);

        assertFalse(schemaValidatorService.processParentalRatings(AssetDto.builder().type("Type")
                .parentalRatings(List.of(AssetParentalRatingDto.builder().build())).build(),
            new ArrayList<>()));
    }

    @Test
    void getContentProviderListTest() throws IllegalAccessException, NoSuchFieldException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        assertDoesNotThrow(() -> schemaValidatorService.getContentProviderList());
    }

    @Test
    void getContentProviderListTest_Exception()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(jsonValidatorMapper.getContentProviderList(Mockito.any()))
            .thenThrow(new SQLException("TEST"));

        assertThrows(SQLException.class, () -> schemaValidatorService.getContentProviderList());
    }

    @Test
    void processProviderTest_True()
        throws SQLException, IllegalAccessException, NoSuchFieldException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                schemaValidatorService.validateProviderAndCountry(Mockito.anyString(),
                    Mockito.anyString()))
            .thenReturn(true);

        assertTrue(
            schemaValidatorService.processProvider("TEST", "TEST", "TEST", new ArrayList<>()));
    }

    @Test
    void processProviderTest_False()
        throws SQLException, IllegalAccessException, NoSuchFieldException {
        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                schemaValidatorService.validateProviderAndCountry(Mockito.anyString(),
                    Mockito.anyString()))
            .thenReturn(false);

        assertFalse(
            schemaValidatorService.processProvider("TEST", "TEST", "TEST", new ArrayList<>()));
    }

    @Test
    void duplicateProviderIdAndCountryCheck_NullDto_Asset() {
        assertTrue(schemaValidatorService.duplicateProviderIdAndCountryCheck("TEST", "TEST",
            new ArrayList<>(), true, null));
    }

    @Test
    void duplicateProviderIdAndCountryCheck_NullDto_Media() {
        assertFalse(schemaValidatorService.duplicateProviderIdAndCountryCheck("TEST", "TEST",
            new ArrayList<>(), false, null));
    }

    @Test
    void duplicateProviderIdAndCountryCheck_DuplicateVcCpId() {
        assertFalse(schemaValidatorService.duplicateProviderIdAndCountryCheck("ID1", "TEST",
            new ArrayList<>(), true, ContentProviderDto.builder().vcCpId("ID2").build()));
    }

    @Test
    void duplicateProviderIdAndCountryCheck_DuplicateCountryCode() {
        assertFalse(schemaValidatorService.duplicateProviderIdAndCountryCheck("ID1", "CD1",
            new ArrayList<>(), true,
            ContentProviderDto.builder().vcCpId("ID1").countryCd("CD2").build()));
    }

    @Test
    void duplicateProviderIdAndCountryCheck_ValidCase() {
        assertTrue(schemaValidatorService.duplicateProviderIdAndCountryCheck("ID1", "CD1",
            new ArrayList<>(), true,
            ContentProviderDto.builder().vcCpId("ID1").countryCd("CD1").build()));
    }

    @Test
    void processValidationsTest_DuplicateProviderFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(false).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        assertFalse(
            schemaValidatorService.processValidations(AssetDto.builder().build(), "CD1", "PRO1",
                new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ProviderCountryFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(false).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertFalse(
            schemaValidatorService.processValidations(AssetDto.builder().programId("CONT1").build(),
                "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_PlaybackItemsCheckFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(false).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        assertFalse(
            schemaValidatorService.processValidations(
                AssetDto.builder().type("TEST").assetId("TEST").programId("TEST")
                    .parentalRatings(List.of()).programId("CONT1").playbackItems(
                        List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
                "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ParentAssetValidationFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(false).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        assertFalse(
            schemaValidatorService.processValidations(
                AssetDto.builder().type("TEST").assetId("TEST").programId("TEST")
                    .parentalRatings(List.of()).programId("CONT1").playbackItems(
                        List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
                "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_AssetStatusValidationFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(false).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        assertFalse(
            schemaValidatorService.processValidations(
                AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                    List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
                "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ProcessParentalRatingsFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(false).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        assertFalse(
            schemaValidatorService.processValidations(
                AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                    List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
                "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ProcessDuplicateIdFromDifferentCpFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(false).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        assertFalse(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ValidTest()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processTitlesCheck(Mockito.any(), Mockito.anyString(), Mockito.anyList());

        assertTrue(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ValidTest_TitleCheckFail()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        Mockito.doReturn(false).when(schemaValidatorService)
            .processTitlesCheck(Mockito.any(), Mockito.anyString(), Mockito.anyList());

        assertFalse(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                List.of(AssetPlaybackDto.builder().licenseWindows(List.of()).build())).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ValidTest_NullPlayback()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processTitlesCheck(Mockito.any(), Mockito.anyString(), Mockito.anyList());

        assertTrue(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(null).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ValidTest_EmptyPlayback()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processTitlesCheck(Mockito.any(), Mockito.anyString(), Mockito.anyList());

        assertTrue(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(List.of()).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void processValidationsTest_ValidTest_LicenseWindowNull()
        throws NoSuchFieldException, IllegalAccessException, SQLException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .parentAssetValidation(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .playbackItemsCheck(Mockito.any(), Mockito.anyString(),
                Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processParentalRatings(Mockito.any(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processDuplicateIdFromDifferentCp(Mockito.any(), Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processValidWindowTest(Mockito.anyList(), Mockito.anyList(), Mockito.anyString());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processTitlesCheck(Mockito.any(), Mockito.anyString(), Mockito.anyList());

        assertTrue(schemaValidatorService.processValidations(
            AssetDto.builder().type("TEST").programId("CONT1").playbackItems(
                List.of(AssetPlaybackDto.builder().licenseWindows(null).build())).build(),
            "CD1", "PRO1", new ArrayList<>()));
    }

    @Test
    void validateProviderAndCountryTest_Valid()
        throws SQLException, NoSuchFieldException, IllegalAccessException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(schemaValidatorService.getContentProviderList())
            .thenReturn(
                List.of(ContentProviderDto.builder().vcCpId("ID1").countryCd("CD1").build()));

        assertTrue(schemaValidatorService.validateProviderAndCountry("CD1", "ID1"));
    }

    @Test
    void validateProviderAndCountryTest_Invalid()
        throws SQLException, IllegalAccessException, NoSuchFieldException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(schemaValidatorService.getContentProviderList())
            .thenReturn(
                List.of(ContentProviderDto.builder().vcCpId("ID2").countryCd("CD2").build()));

        assertFalse(schemaValidatorService.validateProviderAndCountry("CD1", "ID1"));
    }

    @Test
    void validateProviderAndCountryTest_InvalidProvider()
        throws SQLException, IllegalAccessException, NoSuchFieldException {

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.when(schemaValidatorService.getContentProviderList())
            .thenReturn(
                List.of(ContentProviderDto.builder().vcCpId("ID1").countryCd("CD2").build()));

        assertFalse(schemaValidatorService.validateProviderAndCountry("CD1", "ID1"));
    }

    @Test
    void validateAssetTest_InvalidJson()
        throws IllegalAccessException, NoSuchFieldException, JsonProcessingException {
        String jsonString = """
                "code": "hi",
                "id": "invalid"
            """;
        JsonNode jsonNode = new ObjectMapper().readTree(jsonString);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        assertThrows(JsonSchemaValidationException.class,
            () -> schemaValidatorService.validateAsset(jsonNode, "US", "ID1"));
    }

    @Test
    void validateAssetTest_ValidJson_Pass()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        AssetDto assetDto = AssetDto.builder().type("TP1").assetId("AID1").casts(new ArrayList<>())
            .programId("PID1").adBreaks(new ArrayList<>()).build();
        JsonNode jsonNode = new ObjectMapper().valueToTree(assetDto);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.doReturn(true).when(schemaValidatorService)
            .processValidations(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertDoesNotThrow(() -> schemaValidatorService.validateAsset(jsonNode, "US", "ID1"));
    }

    @Test
    void validateAssetTest_ValidJson_Fail()
        throws IllegalAccessException, NoSuchFieldException {
        AssetDto assetDto = AssetDto.builder().type("TP1").assetId("AID1").casts(new ArrayList<>())
            .programId("PID1").adBreaks(new ArrayList<>()).build();
        JsonNode jsonNode = new ObjectMapper().valueToTree(assetDto);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        assertDoesNotThrow(() -> schemaValidatorService.validateAsset(jsonNode, "US", "ID1"));
    }

    @Test
    void validateMediaTest_InvalidJson()
        throws IllegalAccessException, NoSuchFieldException, JsonProcessingException {
        String jsonString = """
                "code": "hi",
                "id": "invalid"
            """;
        JsonNode jsonNode = new ObjectMapper().readTree(jsonString);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        assertThrows(JsonSchemaValidationException.class,
            () -> schemaValidatorService.validateMedia(jsonNode, "US", "ID1", "PRO1"));
    }

    @Test
    void validateMediaTest_ValidJson_Pass()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        MediaAssetDto mediaAssetDto = MediaAssetDto.builder().adBreaks(List.of()).adTags("test")
            .build();
        JsonNode jsonNode = new ObjectMapper().valueToTree(mediaAssetDto);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.doReturn(true).when(schemaValidatorService)
            .processMediaValidations(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertDoesNotThrow(
            () -> schemaValidatorService.validateMedia(jsonNode, "US", "ID1", "PRO1"));
    }

    @Test
    void validateMediaTest_ValidJson_Fail()
        throws IllegalAccessException, NoSuchFieldException, SQLException {
        MediaAssetDto mediaAssetDto = MediaAssetDto.builder().adBreaks(List.of()).adTags("test")
            .build();
        JsonNode jsonNode = new ObjectMapper().valueToTree(mediaAssetDto);

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.doReturn(false).when(schemaValidatorService)
            .processMediaValidations(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertDoesNotThrow(
            () -> schemaValidatorService.validateMedia(jsonNode, "US", "ID1", "PRO1"));
    }

    @Test
    void processMediaValidationsTest_DuplicateProviderCountryCheckFail() throws SQLException {
        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(false).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        assertFalse(schemaValidatorService.processMediaValidations("PRO1", "CD1", "ID1",
            new ArrayList<>()));
    }

    @Test
    void processMediaValidationsTest_AssetStatusValidationFail()
        throws SQLException, IllegalAccessException, NoSuchFieldException {
        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "feedWorkers");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, "worker1,worker2");

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(false).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertFalse(schemaValidatorService.processMediaValidations("PRO1", "CD1", "ID1",
            new ArrayList<>()));
    }

    @Test
    void processMediaValidationsTest_ProcessProviderFail() throws SQLException {
        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(false).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertFalse(schemaValidatorService.processMediaValidations("PRO1", "CD1", "ID1",
            new ArrayList<>()));
    }

    @Test
    void processMediaValidationsTest_Pass() throws SQLException {
        Mockito.when(
                jsonValidatorMapper.getAssetDetailByContentId(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(ContentProviderDto.builder().build());

        Mockito.doReturn(true).when(schemaValidatorService)
            .duplicateProviderIdAndCountryCheck(Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList(), Mockito.anyBoolean(), Mockito.any());

        Mockito.doReturn(true).when(schemaValidatorService)
            .assetStatusValidation(Mockito.any(), Mockito.anyList(), Mockito.anyBoolean());

        Mockito.doReturn(true).when(schemaValidatorService)
            .processProvider(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                Mockito.anyList());

        assertTrue(schemaValidatorService.processMediaValidations("PRO1", "CD1", "ID1",
            new ArrayList<>()));
    }

    @Test
    void processValidWindowTest_Success() {
        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);
        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.anyList()))
            .thenReturn(true);

        assertTrue(schemaValidatorService.processValidWindowTest(List.of(), List.of(),
            ErrorConstants.LICENSE_WINDOW_ERROR));
    }

    @Test
    void processValidWindowTest_InvalidWindows() {
        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(false);

        assertFalse(schemaValidatorService.processValidWindowTest(new ArrayList<>(),
            new ArrayList<>(), ErrorConstants.LICENSE_WINDOW_ERROR));
    }

    @Test
    void processValidWindowTest_OverlappingWindows() {
        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);
        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.anyList()))
            .thenReturn(false);

        assertFalse(schemaValidatorService.processValidWindowTest(new ArrayList<>(),
            new ArrayList<>(), ErrorConstants.LICENSE_WINDOW_ERROR));
    }

    @Test
    void processValidWindowTest_InvalidDate() {
        Mockito.doThrow(new RuntimeException("TEST")).when(dateRangeWindowService)
            .addTzToTimestamps(Mockito.any());
        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);
        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.anyList()))
            .thenReturn(false);

        assertFalse(schemaValidatorService.processValidWindowTest(new ArrayList<>(),
            new ArrayList<>(), ErrorConstants.LICENSE_WINDOW_ERROR));
    }

    @Test
    void playbackItemsCheckTest_Season() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SEASON).build();

        assertTrue(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_NullShow() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SHOW).playbackItems(null).build();

        assertTrue(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_NullNonShow() {
        AssetDto assetDto = AssetDto.builder().type(Constants.EPISODE).playbackItems(null).build();

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_ShowNotNull_Valid() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SHOW)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("AA").build())).build();

        Mockito.doReturn(true).when(schemaValidatorService)
            .processValidWindowTest(Mockito.any(), Mockito.anyList(), Mockito.anyString());

        assertTrue(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_ShowNotNull_InvalidLicenseWindow() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SHOW)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("AA").build())).build();

        Mockito.doReturn(false).when(schemaValidatorService)
            .processValidWindowTest(Mockito.any(), Mockito.anyList(), Mockito.anyString());

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_NotShowNotNull_Valid() {
        AssetDto assetDto = AssetDto.builder().type(Constants.EPISODE)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("AA").build())).build();

        Mockito.doReturn(true).when(schemaValidatorService)
            .processValidWindowTest(Mockito.any(), Mockito.anyList(), Mockito.anyString());

        assertTrue(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_NotShowNotNull_InvalidLicenseWindow() {
        AssetDto assetDto = AssetDto.builder().type(Constants.EPISODE)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("AA").build())).build();

        Mockito.doReturn(false).when(schemaValidatorService)
            .processValidWindowTest(Mockito.any(), Mockito.anyList(), Mockito.anyString());

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_ShowNotNull_Invalid() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SHOW)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("BB").build())).build();

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_ShowNotNull_Invalid2() {
        AssetDto assetDto = AssetDto.builder().type(Constants.SHOW)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode(null).build())).build();

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void playbackItemsCheckTest_NotShowNotNull_Invalid() {
        AssetDto assetDto = AssetDto.builder().type(Constants.EPISODE)
            .playbackItems(List.of(AssetPlaybackDto.builder().countryCode("BB").build())).build();

        assertFalse(schemaValidatorService.playbackItemsCheck(assetDto, "AA", new ArrayList<>()));
    }

    @Test
    void processTitlesCheckTest_Valid()
        throws SQLException, NoSuchFieldException, IllegalAccessException {
        AssetDto assetDto = AssetDto.builder().titles(List.of(
            AssetTitleDto.builder().title("TITLE").type(Constants.TITLE_TYPE_MAIN).language("LANG")
                .build())).programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        langCodes.add("LANG");
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();

        Field parentalRatingsCheckFlag = SchemaValidatorService.class.getDeclaredField(
            "titleByteLength");
        parentalRatingsCheckFlag.setAccessible(true);
        parentalRatingsCheckFlag.set(schemaValidatorService, 10);

        assertTrue(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }

    @Test
    void processTitlesCheckTest_Invalid_TitleLengthExceed() throws SQLException {
        AssetDto assetDto = AssetDto.builder().titles(List.of(
            AssetTitleDto.builder().title("LONG_TITLE").type(Constants.TITLE_TYPE_MAIN)
                .language("LANG").build())).programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        langCodes.add("LANG");
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();

        setByteLength("titleByteLength", 6);

        assertFalse(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }

    @Test
    void processTitlesCheckTest_Invalid_LangCodeEmptyList() throws SQLException {
        AssetDto assetDto = AssetDto.builder().titles(List.of(
            AssetTitleDto.builder().title("TITLE").type(Constants.TITLE_TYPE_MAIN).language("LANG")
                .build())).programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();

        setByteLength("titleByteLength", 6);

        assertFalse(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }

    @Test
    void processTitlesCheckTest_Invalid_NoMainTitle() throws SQLException {
        AssetDto assetDto = AssetDto.builder().titles(
                List.of(AssetTitleDto.builder().title("TITLE").type("Random").language("LANG").build()))
            .programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();

        setByteLength("titleByteLength", 6);
        assertFalse(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }

    @Test
    void processTitlesCheckTest_Invalid_NoTitle() throws SQLException {
        AssetDto assetDto = AssetDto.builder().programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();
        setByteLength("titleByteLength", 6);
        assertFalse(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }

    @Test
    void processTitlesCheckTest_Invalid_TitleLanguageNotMatchingToLangCode() throws SQLException {
        AssetDto assetDto = AssetDto.builder().titles(List.of(
            AssetTitleDto.builder().title("TITLE").type(Constants.TITLE_TYPE_MAIN).language("LANG")
                .build())).programId("PID").build();
        String countryCode = "CON";
        List<String> langCodes = new ArrayList<>();
        langCodes.add("OTHER_LANG");
        Mockito.when(vodAssetMapper.getLangCodeByCountryCode(countryCode)).thenReturn(langCodes);
        List<ErrorDto> errorList = new ArrayList<>();

        setByteLength("titleByteLength", 6);

        assertFalse(schemaValidatorService.processTitlesCheck(assetDto, countryCode, errorList));
    }


    private void setByteLength(String fieldName, int value) {
        try {
            Field field = SchemaValidatorService.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(schemaValidatorService, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static List<Arguments> validateExternalIdPerIdTypeParams() {
        return List.of(
            Arguments.of(null, List.of(), Constants.VALID),
            Arguments.of(List.of(), List.of(), Constants.VALID),
            Arguments.of(List.of(AssetExternalIdDto.builder().build()), List.of(), Constants.VALID),
            Arguments.of(List.of(AssetExternalIdDto.builder().build()),
                List.of(AssetExternalIdDto.builder().build()), Constants.INVALID)
        );
    }

    @ParameterizedTest
    @MethodSource("validateExternalIdPerIdTypeParams")
    void validateExternalIdPerIdTypeTest(List<AssetExternalIdDto> input,
        List<AssetExternalIdDto> output, String res) {
        Mockito.doReturn(output)
            .when(jsonValidatorMapper)
            .getExternalIdDataByProviderAndTypeAndCountry(Mockito.any());

        assertEquals(res, schemaValidatorService.validateExternalIdPerIdType(input));
    }

}
