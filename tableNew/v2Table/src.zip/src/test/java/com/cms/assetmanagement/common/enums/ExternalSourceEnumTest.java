package com.cms.assetmanagement.common.enums;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ExternalSourceEnumTest {

    @Test
    void enumValues_ShouldHaveCorrectValues() {
        // Then
        assertEquals("GVD", ExternalSourceEnum.GVD.getValue());
        assertEquals("ONAPI", ExternalSourceEnum.ONAPI.getValue());
    }

    @Test
    void enumValues_ShouldHaveCorrectNumberOfValues() {
        // When
        ExternalSourceEnum[] values = ExternalSourceEnum.values();

        // Then
        assertEquals(2, values.length);
    }

    @Test
    void enumValueOf_ShouldReturnCorrectEnum() {
        // When & Then
        assertEquals(ExternalSourceEnum.GVD, ExternalSourceEnum.valueOf("GVD"));
        assertEquals(ExternalSourceEnum.ONAPI, ExternalSourceEnum.valueOf("ONAPI"));
    }

    @Test
    void getValue_ShouldReturnCorrectValue() {
        // When & Then
        assertEquals("GVD", ExternalSourceEnum.GVD.getValue());
        assertEquals("ONAPI", ExternalSourceEnum.ONAPI.getValue());
    }
}
