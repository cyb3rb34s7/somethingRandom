package com.cms.assetmanagement.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.mapper.asset.content.VodAssetImageMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
//comment for sonar trigger 
@SpringBootTest(classes = AssetInsertHelperTest.class)
class AssetInsertHelperTest {

    @Mock
    private VodAssetMapper vodAssetMapper;

    @Mock
    private VodAssetImageMapper vodAssetImageMapper;

    @InjectMocks
    private AssetInsertHelper assetInsertHelper;

    @Test
    void testInsertDrmData_NormalValue() {
        // Arrange
        List<AssetDrmDto> assetDrmDtoList = List.of(
            new AssetDrmDto(),
            new AssetDrmDto()
        );

        // Act
        assetInsertHelper.insertDrmData(assetDrmDtoList);

        // Assert
        verify(vodAssetMapper, times(1)).insertDRMData(assetDrmDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testInsertDrmData_NullOrEmptyList(List<AssetDrmDto> assetDrmDtoList) {
        // Arrange, Act, Assert
        assetInsertHelper.insertDrmData(assetDrmDtoList);
        verify(vodAssetMapper, times(0)).insertDRMData(assetDrmDtoList);
    }

    @Test
    void testInsertExternalIdData_NormalValue() {
        // Arrange
        List<AssetExternalIdDto> assetExternalIdDtoList = List.of(
            new AssetExternalIdDto(),
            new AssetExternalIdDto()
        );

        // Act
        assetInsertHelper.insertExternalIdData(assetExternalIdDtoList);

        // Assert
        verify(vodAssetMapper, times(1)).insertExternalIdData(assetExternalIdDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testInsertExternalIdData_NullOrEmptyList(
        List<AssetExternalIdDto> assetExternalIdDtoList) {
        // Arrange, Act, Assert
        assetInsertHelper.insertExternalIdData(assetExternalIdDtoList);
        verify(vodAssetMapper, times(0)).insertExternalIdData(assetExternalIdDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void insertAdBreakData_ShouldNotCallMapper_WhenListIsNullOrEmpty(
        List<AdBreaksDto> adBreaksDtoList) {
        // Act
        assetInsertHelper.insertAdBreakData(adBreaksDtoList);

        // Assert
        verifyNoInteractions(vodAssetMapper);
    }

    @Test
    void insertAdBreakData_NormalValue() {
        // Arrange
        List<AdBreaksDto> adBreaksDtoList = List.of(new AdBreaksDto(), new AdBreaksDto());

        // Act
        assetInsertHelper.insertAdBreakData(adBreaksDtoList);

        // Assert
        verify(vodAssetMapper).insertAdBreakData(adBreaksDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testInsertPlatformData_WithNullOrEmptyList(List<PlatformTagData> platformTagDataList) {
        // Act
        assetInsertHelper.insertPlatformData(platformTagDataList);

        // Assert
        verify(vodAssetMapper, Mockito.never()).insertPlatformData(Mockito.anyList());
    }

    @Test
    void testInsertPlatformData_WithNormalValue() {
        List<PlatformTagData> platformTagDataList = List.of(new PlatformTagData(),
            new PlatformTagData());

        // Act
        assetInsertHelper.insertPlatformData(platformTagDataList);

        // Assert
        verify(vodAssetMapper).insertPlatformData(platformTagDataList);
    }

    @Test
    void testInsertRatingData_NormalValue() {
        // Arrange
        var assetRatingDtoList = List.of(new AssetRatingDto(), new AssetRatingDto());

        // Act
        assetInsertHelper.insertRatingData(assetRatingDtoList);

        // Assert
        Mockito.verify(vodAssetMapper).insertRatingData(assetRatingDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void testInsertRatingData_WithNullOrEmptyList(List<AssetRatingDto> assetRatingDtoList) {
        // Act
        assetInsertHelper.insertRatingData(assetRatingDtoList);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.never()).insertRatingData(assetRatingDtoList);
    }

    @Test
    void testInsertCastData_NormalValue() {
        // Arrange
        var assetRatingDtoList = List.of(new AssetCastDto(), new AssetCastDto());

        // Act
        assetInsertHelper.insertCastData(assetRatingDtoList);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.times(1)).insertCastData(assetRatingDtoList);
    }

    @ParameterizedTest
    @NullAndEmptySource
    void insertCastDataTest_WithNullOrEmptyList(List<AssetCastDto> assetCastDtoList) {
        // Act
        assetInsertHelper.insertCastData(assetCastDtoList);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.never()).insertCastData(assetCastDtoList);
    }

    @Test
    void insertGracenoteMapTest_NormalValue() {
        // Act
        assetInsertHelper.insertGracenoteMap(new GracenoteMapDto());

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.times(1)).insertGracenoteMap(Mockito.any());
    }

    @ParameterizedTest
    @NullSource
    void insertGracenoteMapTest_WithNullOrEmptyList(GracenoteMapDto gracenoteMapDto) {
        // Act
        assetInsertHelper.insertGracenoteMap(gracenoteMapDto);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.never()).insertGracenoteMap(gracenoteMapDto);
    }

    @Test
    void insertLicenseWindowDataTest_NormalValue() {
        // Act
        assetInsertHelper.insertLicenseWindowData(
            List.of(new LicenseWindowDto(), new LicenseWindowDto()));

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.times(1)).insertLicenseWindowData(Mockito.any());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void insertLicenseWindowDataTest_WithNullOrEmptyList(
        List<LicenseWindowDto> licenseWindowDtoList) {
        // Act
        assetInsertHelper.insertLicenseWindowData(licenseWindowDtoList);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.never())
            .insertLicenseWindowData(licenseWindowDtoList);
    }

    @Test
    void insertEventWindowDataTest_NormalValue() {
        // Act
        assetInsertHelper.insertEventWindowData(
            List.of(new EventWindowDto(), new EventWindowDto()));

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.times(1)).insertEventWindowData(Mockito.any());
    }

    @ParameterizedTest
    @NullAndEmptySource
    void insertEventWindowDataTest_WithNullOrEmptyList(List<EventWindowDto> eventWindowDtos) {
        // Act
        assetInsertHelper.insertEventWindowData(eventWindowDtos);

        // Assert
        Mockito.verify(vodAssetMapper, Mockito.never())
            .insertEventWindowData(eventWindowDtos);
    }

    static List<Arguments> deleteAndInsertRatingDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new ParentalRatingsDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new ParentalRatingsDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertRatingDataParams")
    void deleteAndInsertRatingDataTest(List<AssetKeyDto> assetKeyList,
        List<ParentalRatingsDto> parentalRatingsDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertRatingData(assetKeyList,
            parentalRatingsDtoList));
    }

    static List<Arguments> deleteAndInsertGracenoteDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, Constants.ADD),
            Arguments.of(List.of(), Constants.ADD),
            Arguments.of(List.of(new AssetKeyDto()), Constants.ADD),
            Arguments.of(List.of(new AssetKeyDto()), Constants.DELETE),
            Arguments.of(List.of(new AssetKeyDto()), "DUMMY")
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertGracenoteDataParams")
    void deleteAndInsertGracenoteDataTest(List<AssetKeyDto> assetKeyList, String gracenoteAction) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertGracenoteData(assetKeyList,
            gracenoteAction));
    }

    static List<Arguments> deleteAndInsertPlatformTagDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new PlatformTagData())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new PlatformTagData()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertPlatformTagDataParams")
    void deleteAndInsertPlatformTagDataTest(List<AssetKeyDto> assetKeyList,
        List<PlatformTagData> platformTagDataList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertPlatformTagData(assetKeyList,
            platformTagDataList));
    }

    static List<Arguments> deleteAndInsertExternalIdDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new ExternalProviderDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new ExternalProviderDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertExternalIdDataParams")
    void deleteAndInsertExternalIdDataTest(List<AssetKeyDto> assetKeyList,
        List<ExternalProviderDto> externalProviderDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertExternalIdData(assetKeyList,
            externalProviderDtoList));
    }

    static List<Arguments> deleteAndInsertCastDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(
                List.of(new AssetKeyDto()),
                List.of(AssetCastDto.builder().crctrId("TEST").regrId("TEST").feedWorker("TEST")
                    .build())
            ),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new AssetCastDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new AssetCastDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertCastDataParams")
    void deleteAndInsertCastDataTest(List<AssetKeyDto> assetKeyList,
        List<AssetCastDto> assetCastDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertCastData(assetKeyList,
            assetCastDtoList));
    }

    static List<Arguments> deleteAndInsertLicenseWindowDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(
                List.of(new AssetKeyDto()),
                List.of(LicenseWindowDto.builder().crctrId("TEST").regrId("TEST").feedWorker("TEST")
                    .build())
            ),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new LicenseWindowDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new LicenseWindowDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertLicenseWindowDataParams")
    void deleteAndInsertLicenseWindowDataTest(List<AssetKeyDto> assetKeyList,
        List<LicenseWindowDto> licenseWindowDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertLicenseWindowData(assetKeyList,
            licenseWindowDtoList));
    }

    static List<Arguments> deleteAndInsertEventWindowDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(
                List.of(new AssetKeyDto()),
                List.of(EventWindowDto.builder().crctrId("TEST").regrId("TEST").feedWorker("TEST")
                    .build())
            ),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new EventWindowDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new EventWindowDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertEventWindowDataParams")
    void deleteAndInsertEventWindowDataTest(List<AssetKeyDto> assetKeyList,
        List<EventWindowDto> eventWindowDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertEventWindowData(assetKeyList,
            eventWindowDtoList));
    }

    static List<Arguments> deleteAndInsertImageDataParams() {
        return List.of(
            Arguments.of(null, null),
            Arguments.of(List.of(), null),
            Arguments.of(null, List.of()),
            Arguments.of(List.of(), List.of()),
            Arguments.of(List.of(new AssetKeyDto()), List.of(new AssetImageDto())),
            Arguments.of(List.of(new AssetKeyDto()), List.of()),
            Arguments.of(List.of(), List.of(new AssetImageDto()))
        );
    }

    @ParameterizedTest
    @MethodSource("deleteAndInsertImageDataParams")
    void deleteAndInsertImageDataTest(List<AssetKeyDto> assetKeyList,
        List<AssetImageDto> assetImageDtoList) {
        assertDoesNotThrow(() -> assetInsertHelper.deleteAndInsertImageData(assetKeyList,
            assetImageDtoList));
    }
}
