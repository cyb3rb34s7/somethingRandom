package com.cms.assetmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.evaluation.ComparisonDetailResponseDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import com.cms.assetmanagement.service.EvaluationService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = EvaluationControllerTest.class)
class EvaluationControllerTest {

    @Mock
    EvaluationService evaluationService;
    @InjectMocks
    EvaluationController evaluationController;

    @Test
    void testGetProgramList() {
        FilterRequestDto filterRequestDto = FilterRequestDto.builder().build();
        assertDoesNotThrow(
            () -> evaluationController.getProgramList(filterRequestDto));
    }

    @Test
    void testGetDetail() {
        String contentId = "1234567890";
        String cpId = "123";

        ComparisonDetailResponseDto comparisonDetailResponseDto = ComparisonDetailResponseDto.builder()
            .content(null).umd(null).onApi(null).build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.EVALUATION,
            comparisonDetailResponseDto);

        when(evaluationService.getDetail(contentId, cpId)).thenReturn(comparisonDetailResponseDto);

        // Act
        ResponseDto actualResponse = evaluationController.getDetail(contentId, cpId);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(evaluationService, times(1)).getDetail(contentId, cpId);
    }

    @Test
    void testGetCount() {
        FilterRequestDto filterRequestDto = FilterRequestDto.builder().build();
        assertDoesNotThrow(
            () -> evaluationController.getCount(filterRequestDto));
    }
}
