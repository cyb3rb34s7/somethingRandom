package com.cms.assetmanagement.config;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

class RestTemplateConfigurationTest {

    private RestTemplateConfiguration restTemplateConfiguration;

    @BeforeEach
    void setUp() {
        restTemplateConfiguration = new RestTemplateConfiguration();
    }

    @Test
    void getRestTemplate_ShouldReturnRestTemplateWithCorrectTimeouts() {
        // When
        RestTemplate restTemplate = restTemplateConfiguration.getRestTemplate();

        // Then
        assertNotNull(restTemplate);
        // We can't easily verify the timeout settings without reflection, but we can at least
        // verify that the method returns a valid RestTemplate instance
    }
}
