package com.cms.assetmanagement.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.publicapi.QueryParamDto;
import com.cms.assetmanagement.service.impl.VodAssetPublicServiceImpl;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AssetPublicControllerTest {

    @InjectMocks
    private AssetPublicController assetPublicController;

    @Mock
    private VodAssetPublicServiceImpl vodAssetPublicService;

    @Test
    void assets_success() {
        //Required Params
        String countryCode = "US";
        String providerId = "AAPBF3601C6";
        String mediaStatus = "Released";
        String programId = "programId";
        String programType = "EPISODE";
        String sortBy = "-updateDate";
        int offset = 0;
        int limit = 10;
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            List.of(VodAssetDto.builder().build()));

        when(vodAssetPublicService.getAssets(Mockito.any(QueryParamDto.class))).thenReturn(
            List.of(VodAssetDto.builder().build()));

        // Act
        ResponseDto actualResponse = assetPublicController.assets(countryCode, providerId,
            mediaStatus, programId, programType, sortBy, offset, limit);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }
}
