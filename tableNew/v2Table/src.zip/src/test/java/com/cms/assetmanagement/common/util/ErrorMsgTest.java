package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ErrorMsgTest {

    @Test
    void testErrorMsg() {
        assertEquals("Missing Required Header", ErrorMsg.MISSING_REQUIRED_HEADER);
        assertEquals("Unsupported Header", ErrorMsg.UNSUPPORTED_HEADER);
        assertEquals("Invalid Header Value", ErrorMsg.INVALID_HEADER_VALUE);
        assertEquals("Missing Required Query Parameter", ErrorMsg.MISSING_REQUIRED_QUERY_PARAM);
        assertEquals("Unsupported Query Parameter", ErrorMsg.UNSUPPORTED_QUERY_PARAM);
        assertEquals("Invalid Query Parameter Value", ErrorMsg.INVALID_QUERY_PARAM_VALUE);
        assertEquals("Invalid Path Variable", ErrorMsg.INVALID_PATH_VARIABLE);
        assertEquals("Malformed Body Content", ErrorMsg.MALFORMED_BODY_CONTENT);
        assertEquals("Country Not Assigned To The User", ErrorMsg.COUNTRY_NOT_ASSIGNED);
        assertEquals("Invalid userId", ErrorMsg.INVALID_APPKEY);
        assertEquals("Invalid Token", ErrorMsg.INVALID_TOKEN);
        assertEquals("Invalid UserToken", ErrorMsg.INVALID_USERTOKEN);
        assertEquals("UserToken Expired", ErrorMsg.USERTOKEN_EXPIRED);
        assertEquals("Permission Denied", ErrorMsg.PERMISSION_DENIED);
        assertEquals("Access Denied", ErrorMsg.ACCESS_DENIED);
        assertEquals("HTTPS Only", ErrorMsg.HTTPS_ONLY);
        assertEquals("DUID or IP Denied", ErrorMsg.DUID_OR_IP_DENIED);
        assertEquals("Requested URI Not Exists", ErrorMsg.REQUIRED_URI_NOT_EXISTS);
    }

    @Test
    void testOtherErrorMsg() {
        assertEquals("Data Not Found", ErrorMsg.DATA_NOT_FOUND);
        assertEquals("Data Not Editable", ErrorMsg.DATA_NOT_EDITABLE);
        assertEquals("Text is not unique", ErrorMsg.DATA_NOT_UNIQUE);
        assertEquals("GOG has cycle in it", ErrorMsg.DATA_IS_CYCLIC);
        assertEquals("Data Integrity Violation Occurred (Database constraint violated)",
            ErrorMsg.DATA_INTEGRITY_VIOLATION);
        assertEquals("Cannot be deleted. Key is utilized as FK in other table",
            ErrorMsg.INTEGRITY_VIOLATION);
        assertEquals("Unsupported HTTP Method", ErrorMsg.UNSUPPORTED_HTTP_METHOD);
        assertEquals("Modifying Role of Self", ErrorMsg.MODIFYING_ROLE_OF_SELF);
        assertEquals("Not Acceptable", ErrorMsg.NOT_ACCEPTABLE);
        assertEquals("Request Timeout", ErrorMsg.REQUEST_TIMEOUT);
        assertEquals("Data Already Exists", ErrorMsg.DATA_ALREADY_EXISTS);
        assertEquals("No Content Length", ErrorMsg.NO_CONTENT_LENGTH);
        assertEquals("Request Too Large", ErrorMsg.REQUEST_TOO_LARGE);
        assertEquals("Invalid Character Set", ErrorMsg.INVALID_CHARACTER_SET);
        assertEquals("Internal Server Error", ErrorMsg.INTERNAL_SERVER_ERROR);
        assertEquals("Internal Server Error in IMS System", ErrorMsg.IMS_ERROR);
        assertEquals("Not Implemented", ErrorMsg.NOT_IMPLEMENTED);
        assertEquals("Service Unavailable", ErrorMsg.SERVICE_UNAVAILABLE);
        assertEquals("Timeout Exception", ErrorMsg.TIMEOUT_EXCEPTION);
        assertEquals("Unsupported Action", ErrorMsg.UNSUPPORTED_ACTION);
    }
}