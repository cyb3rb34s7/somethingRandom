package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetLockedFieldDto;
import com.cms.assetmanagement.model.ContentDetailsDto;
import com.cms.assetmanagement.model.EpisodeHierarchyDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetViewFilterDto;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class VodAssetViewServiceImplTest extends BaseVodAssetServiceTest {

    @Test
    void getAssetView_success() {
        String contentId = "contentId";
        String vcCpId = "vcCpId";
        String countryCode = "US";

        VodAssetDto expectedAsset = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .vcCpId("vcCpId").status("status").licenseWindow("Active").availableStarting("starting")
            .expiryDate("expiry").imageLandscape("landscape").imagePortrait("portrait")
            .imagePortraitIconic("portraitIconic").imageLandscapeIconic("landscapeIconic")
            .imageTitleTreatment("titleTreatment").imageLandscapeBackdrop("landscapeBackdrop")
            .build();

        List<AssetImageDto> expectedAssetImageDto = new ArrayList<>(List.of(AssetImageDto.builder()
            .contentId("contentId").countryCode("US").providerId("vcCpId").imageType("Image Type")
            .build()));

        List<AssetLockedFieldDto> lockedFields = List.of(AssetLockedFieldDto.builder().build());

        when(vodAssetMapper.getAssetView(Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(List.class))).thenReturn(expectedAsset);
        when(vodAssetImageMapper.getAllImageByContentId(Mockito.any(AssetKeyDto.class))).thenReturn(
            expectedAssetImageDto);
        when(vodAssetColumnLockMapper.getAllColumnLockByContentId(
            Mockito.any(AssetKeyDto.class))).thenReturn(lockedFields);

        when(utils.getUTCDateTime("2021-03-12", "yyyy-mm-dd")).thenReturn(Instant.now());
        when(utils.getLicenseWindow("starting", "expiry")).thenReturn("Active");
        when(utils.getStatus("Active", "status")).thenReturn("NewStatus");
        VodAssetDto actualResponse = vodAssetViewService.getAssetView(contentId, vcCpId,
            countryCode);

        assertEquals(expectedAsset, actualResponse);
    }

    @Test
    void getAssetCPView_success() {
        String contentId = "contentId";
        String vcCpId = "vcCpId";
        String countryCode = "US";

        VodAssetDto expectedAsset = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .vcCpId("vcCpId").status("status").licenseWindow("Active").availableStarting("starting")
            .expiryDate("expiry").build();

        when(vodAssetMapper.getAssetDetails(Mockito.anyString(), Mockito.any(),
            Mockito.any())).thenReturn(VodAssetDto.builder().build());
        when(vodAssetMapper.getAssetCPView(Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(List.class))).thenReturn(expectedAsset);
        when(utils.getUTCDateTime("2021-03-12", "yyyy-mm-dd")).thenReturn(Instant.now());
        when(utils.getLicenseWindow("starting", "expiry")).thenReturn("Active");
        when(utils.getStatus("Active", "status")).thenReturn("NewStatus");

        VodAssetDto actualResponse = vodAssetViewService.getAssetCPView(contentId, vcCpId,
            countryCode);

        assertEquals(expectedAsset, actualResponse);
    }

    @Test
    void getAssetGracenoteGVDView_success() {
        String contentId = "contentId";
        String vcCpId = "vcCpId";
        String countryCode = "US";

        VodAssetDto expectedAsset = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .vcCpId("vcCpId").status("status").licenseWindow("Active").availableStarting("starting")
            .expiryDate("expiry").build();

        when(vodAssetMapper.getCpExternalSource(Mockito.any(String.class),
            Mockito.any(String.class))).thenReturn("GVD");
        when(vodAssetMapper.getAssetGracenoteView(Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any(List.class))).thenReturn(expectedAsset);
        VodAssetDto actualResponse = vodAssetViewService.getAssetGracenoteView(contentId, vcCpId,
            countryCode);

        assertEquals(expectedAsset, actualResponse);
    }

    @Test
    void getAssetGracenoteONAPIView_success() {
        String contentId = "contentId";
        String vcCpId = "vcCpId";
        String countryCode = "US";

        VodAssetDto expectedAsset = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .vcCpId("vcCpId").status("status").licenseWindow("Active").availableStarting("starting")
            .expiryDate("expiry").build();

        when(vodAssetMapper.getCpExternalSource(Mockito.any(String.class),
            Mockito.any(String.class))).thenReturn("ONAPI");
        when(vodAssetMapper.getAssetONAPIView(Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class),
            Mockito.any(List.class))).thenReturn(expectedAsset);

        VodAssetDto actualResponse = vodAssetViewService.getAssetGracenoteView(contentId, vcCpId,
            countryCode);

        assertEquals(expectedAsset, actualResponse);
    }

    @Test
    void getAssetGracenoteOnView_success() {
        String contentId = "contentId";
        String vcCpId = "vcCpId";
        String countryCode = "US";

        VodAssetDto expectedAsset = VodAssetDto.builder().contentId("contentId").countryCode("US")
            .vcCpId("vcCpId").status("status").licenseWindow("Active").availableStarting("starting")
            .expiryDate("expiry").build();

        when(vodAssetMapper.getAssetGracenoteOnView(Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class), Mockito.any(List.class)))
            .thenReturn(expectedAsset);
        when(utils.getUTCDateTime("2021-03-12", "yyyy-mm-dd")).thenReturn(Instant.now());
        when(utils.getLicenseWindow("starting", "expiry")).thenReturn("Active");
        when(utils.getStatus("Active", "status")).thenReturn("NewStatus");

        VodAssetDto actualResponse = vodAssetViewService.getAssetGracenoteOnView(contentId, vcCpId,
            countryCode);

        assertEquals(expectedAsset, actualResponse);
    }

    @Test
    void getAssetDetails_success() {
        String contentId = "testContentId";
        String cpId = "testCpId";
        String countryCode = "testCountryCode";
        String availableStartingDate = "2023-10-01";
        String expiryDate = "2023-12-31";

        String externalProgramId = "ext123";
        String type = "Type1";

        VodAssetDto assetDetails = VodAssetDto.builder().
            contentId(contentId).
            vcCpId(cpId).
            countryCode(countryCode).
            availableStarting(availableStartingDate).
            expiryDate(expiryDate).build();

        List<AssetExternalIdDto> externalProviderDetails = new ArrayList<>();
        AssetExternalIdDto externalProvider = AssetExternalIdDto.builder().
            externalProgramId(externalProgramId).build();
        externalProviderDetails.add(externalProvider);

        List<AssetDrmDto> drmDetails = new ArrayList<>();
        AssetDrmDto drm = AssetDrmDto.builder().type(type).build();
        drmDetails.add(drm);
        List<AssetLockedFieldDto> lockedFields = List.of(AssetLockedFieldDto.builder().build());

        when(vodAssetMapper.getAssetDetails(contentId, cpId, countryCode)).thenReturn(assetDetails);
        when(vodAssetMapper.getExternalProviderDetails(contentId, cpId, countryCode))
            .thenReturn(externalProviderDetails);
        when(vodAssetMapper.getDRMDetails(contentId, cpId, countryCode)).thenReturn(drmDetails);
        when(vodAssetColumnLockMapper.getAllColumnLockByContentId(
            Mockito.any(AssetKeyDto.class))).thenReturn(lockedFields);

        VodAssetDetailedDto result = vodAssetService.getAssetDetails(contentId, cpId, countryCode);

        // Assertions
        assertEquals(contentId, result.getVodAsset().getContentId());
        assertEquals(cpId, result.getVodAsset().getVcCpId());
        assertEquals(countryCode, result.getVodAsset().getCountryCode());
        assertEquals(1, result.getExternalProvider().size());
        assertEquals(externalProgramId, result.getExternalProvider().get(0).getExternalProgramId());
        assertEquals(1, result.getDrm().size());
        assertEquals(type, result.getDrm().get(0).getType());
        assertEquals(lockedFields, result.getLockedFields());
    }

    @Test
    void assetDetailsByColumns_success() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder().build();
        List<VodAssetDto> expectedResponse = List.of(
            VodAssetDto.builder().isCmsProd(0).isSyncBlocked(true).isReleased(false).build());
        when(utils.getHistoryColumnMap(reqDto)).thenReturn(reqDto);
        when(vodAssetMapper.assetDetailsByColumns(Mockito.any(), Mockito.any())).thenReturn(
            expectedResponse);
        assertEquals(expectedResponse, vodAssetService.assetDetailsByColumns(reqDto));
        verify(vodAssetMapper, times(1)).assetDetailsByColumns(Mockito.any(), Mockito.any());
    }

    @Test
    void assetDetailsByColumns_else_success() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder().build();
        when(utils.getHistoryColumnMap(reqDto)).thenReturn(reqDto);
        when(vodAssetMapper.assetDetailsByColumns(Mockito.any(), Mockito.any())).thenReturn(null);
        assertNull(vodAssetService.assetDetailsByColumns(reqDto));
        verify(vodAssetMapper, times(1)).assetDetailsByColumns(Mockito.any(), Mockito.any());
    }


    @Test
    void getViewFilters_success() {
        AssetKeyDto reqDto = AssetKeyDto.builder().build();

        List<com.cms.assetmanagement.model.PlatformTagData> expectedPlatforms = List.of(
            com.cms.assetmanagement.model.PlatformTagData.builder().build());
        List<com.cms.assetmanagement.model.ParentalRatingsDto> expectedParentalRatings = List.of(
            com.cms.assetmanagement.model.ParentalRatingsDto.builder().build());
        List<LanguageDto> expectedLanguages = List.of(LanguageDto.builder().build());
        AssetViewFilterDto expectedViewFilters = AssetViewFilterDto.builder()
            .languages(expectedLanguages)
            .parentalRatings(expectedParentalRatings).platforms(expectedPlatforms).build();

        when(vodAssetMapper.getLanguages()).thenReturn(expectedLanguages);
        when(vodAssetMapper.getPlatforms(reqDto, Constants.PLATFORM_DEVICE)).thenReturn(
            expectedPlatforms);
        when(vodAssetMapper.getParentalRatings(reqDto)).thenReturn(expectedParentalRatings);
        assertEquals(expectedViewFilters, vodAssetViewService.getViewFilters(reqDto));
    }

    @Test
    void getViewEpisodeHierarchy_success() {
        AssetKeyDto reqDto = AssetKeyDto.builder().seasonId("seasonId").showId("showId").build();

        ContentDetailsDto expectedDetails = ContentDetailsDto.builder().build();

        EpisodeHierarchyDto expectedResponse = EpisodeHierarchyDto.builder().season(expectedDetails)
            .show(expectedDetails).build();

        when(vodAssetMapper.getEpisodeDetails(Mockito.any(String.class))).thenReturn(
            expectedDetails);
        assertEquals(expectedResponse, vodAssetViewService.getViewEpisodeHierarchy(reqDto));
    }

}
