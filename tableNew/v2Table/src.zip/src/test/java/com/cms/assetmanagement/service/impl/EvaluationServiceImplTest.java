package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.cms.assetmanagement.mapper.asset.content.EvaluationMapper;
import com.cms.assetmanagement.model.evaluation.CountDto;
import com.cms.assetmanagement.model.evaluation.FilterDto;
import com.cms.assetmanagement.model.evaluation.FilterRequestDto;
import com.cms.assetmanagement.model.evaluation.PaginationDto;
import com.cms.assetmanagement.service.VodAssetService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EvaluationServiceImplTest {

    @Mock
    EvaluationMapper evaluationMapper;

    @Mock
    VodAssetService vodAssetService;

    @InjectMocks
    EvaluationServiceImpl evaluationService;

    @Test
    void getProgramListTest() {
        FilterRequestDto filterRequestDto = FilterRequestDto.builder()
            .filters(List.of(new FilterDto()))
            .pagination(new PaginationDto())
            .build();

        assertDoesNotThrow(() -> {
            evaluationService.getProgramList(filterRequestDto);
        });
        verify(evaluationMapper, times(1)).findAllWithUmd(filterRequestDto);
    }

    @Test
    void getCountTest() {
        FilterRequestDto filterRequestDto = FilterRequestDto.builder()
            .filters(List.of(new FilterDto()))
            .pagination(new PaginationDto())
            .build();

        CountDto countDto = CountDto.builder().coveredCount(1).matchedCount(1).totalCount(2)
            .matchedRate("").coveredRate("").build();
        CountDto totalCount0 = CountDto.builder().coveredCount(1).matchedCount(1).totalCount(0)
            .matchedRate("").coveredRate("").build();

        Mockito.when(evaluationMapper.findCount(Mockito.any())).thenReturn(countDto)
            .thenReturn(totalCount0);

        assertDoesNotThrow(() -> {
            // Total Count > 0 case
            evaluationService.getCount(filterRequestDto);

            // Total Count == 0 case
            evaluationService.getCount(filterRequestDto);
        });
        
        verify(evaluationMapper, times(2)).findCount(filterRequestDto);
    }
}
