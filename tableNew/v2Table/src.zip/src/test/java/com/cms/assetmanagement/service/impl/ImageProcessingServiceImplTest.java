package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.mapper.asset.content.ImageProcessingMapper;
import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ImageProcessingServiceImplTest {

    @InjectMocks
    private ImageProcessingServiceImpl imageProcessingServiceImpl;

    @Mock
    private ImageProcessingMapper imageProcessingMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getProcessedImagesByReqId_success() {
        String requestId = "12345";
        List<ProcessedImageDto> expectedResult = new ArrayList<>();
        expectedResult.add(new ProcessedImageDto("image1", "url1"));
        expectedResult.add(new ProcessedImageDto("image2", "url2"));

        when(imageProcessingMapper.getProcessedImagesByReqId(requestId)).thenReturn(expectedResult);

        List<ProcessedImageDto> actualResult = imageProcessingServiceImpl.getProcessedImagesByReqId(
            requestId);

        assertEquals(expectedResult, actualResult);
    }

    @Test
    void insertPreProcessingUrls_success() {

        PreProcessImageDto imageDto = new PreProcessImageDto();
        doNothing().when(imageProcessingMapper)
            .insertPreProcessingUrls(imageDto);
        assertDoesNotThrow(() -> {
            imageProcessingServiceImpl.insertPreProcessingUrls(imageDto);
        });
        verify(imageProcessingMapper, times(1)).insertPreProcessingUrls(
            imageDto);
    }

    @Test
    void initiateImageProcess_success() {

        PreProcessImageDto imageDto = new PreProcessImageDto();
        doNothing().when(imageProcessingMapper).deleteImageByKeys(imageDto);
        doNothing().when(imageProcessingMapper).insertPreProcessingUrls(imageDto);

        assertDoesNotThrow(() -> {
            imageProcessingServiceImpl.initiateImageProcess(imageDto);
        });
        verify(imageProcessingMapper, times(1)).deleteImageByKeys(
            imageDto);
        verify(imageProcessingMapper, times(1)).insertPreProcessingUrls(
            imageDto);
    }

    @Test
    void deleteImageByReqId_success() {
        String requestId = "req123";
        doNothing().when(imageProcessingMapper).deleteImageByReqId(requestId);
        assertDoesNotThrow(() -> {
            imageProcessingServiceImpl.deleteImageByReqId(requestId);
        });
        verify(imageProcessingMapper, times(1)).deleteImageByReqId(
            requestId);
    }
}