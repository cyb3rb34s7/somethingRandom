package com.cms.assetmanagement.common.enums;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CoverageStatusEnumTest {

    @Test
    void enumValues_ShouldHaveCorrectValues() {
        // Then
        assertEquals("COVERED", CoverageStatusEnum.COVERED.getValue());
        assertEquals("NONCOVERED", CoverageStatusEnum.NON_COVERED.getValue());
    }

    @Test
    void enumValues_ShouldHaveCorrectNumberOfValues() {
        // When
        CoverageStatusEnum[] values = CoverageStatusEnum.values();

        // Then
        assertEquals(2, values.length);
    }

    @Test
    void enumValueOf_ShouldReturnCorrectEnum() {
        // When & Then
        assertEquals(CoverageStatusEnum.COVERED, CoverageStatusEnum.valueOf("COVERED"));
        assertEquals(CoverageStatusEnum.NON_COVERED, CoverageStatusEnum.valueOf("NON_COVERED"));
    }

    @Test
    void getValue_ShouldReturnCorrectValue() {
        // When & Then
        assertEquals("COVERED", CoverageStatusEnum.COVERED.getValue());
        assertEquals("NONCOVERED", CoverageStatusEnum.NON_COVERED.getValue());
    }
}
