package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.model.EventDeleteDto;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class VodAssetWindowServiceImplTest extends BaseVodAssetServiceTest {

    static List<Arguments> removeEventWindowsParams() {
        return List.of(
            Arguments.of(EventDeleteDto.builder().action(Constants.REMOVE_ALL).build(), false),
            Arguments.of(
                EventDeleteDto.builder().action(Constants.REMOVE).eventIds(List.of()).build(),
                false),
            Arguments.of(
                EventDeleteDto.builder().action(Constants.REMOVE).eventIds(null).build(), false),
            Arguments.of(
                EventDeleteDto.builder().action(Constants.REMOVE).eventIds(List.of("TEST"))
                    .build(), false),
            Arguments.of(
                EventDeleteDto.builder().action("INVALID").eventIds(List.of()).build(), true)
        );
    }


    @Test
    void getActiveWindowTest() {
        Instant now = Instant.now();
        Instant winStart = now.minus(10, ChronoUnit.MINUTES);
        Instant winEnd = now.plus(10, ChronoUnit.MINUTES);

        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder()
            .availableStarting(DateTimeFormatter.ISO_INSTANT.format(winStart))
            .availableEnding(DateTimeFormatter.ISO_INSTANT.format(winEnd)).build();

        assertDoesNotThrow(() -> vodAssetService.getActiveWindow(List.of(licenseWindowDto)));
    }


    @ParameterizedTest
    @MethodSource("removeEventWindowsParams")
    void removeEventWindowsTest(EventDeleteDto eventDeleteDto, boolean hasError) {
        if (hasError) {
            assertThrows(InvalidInputDataException.class,
                () -> vodAssetWindowService.removeEventWindows(eventDeleteDto));
        } else {
            assertDoesNotThrow(() -> vodAssetWindowService.removeEventWindows(eventDeleteDto));
        }
    }
}
