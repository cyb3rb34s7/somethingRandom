package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ErrorCodeTest {

    @Test
    void testErrorCodeValues() {
        assertEquals("2414001", ErrorCode.MISSING_REQUIRED_HEADER);
        assertEquals("2414002", ErrorCode.UNSUPPORTED_HEADER);
        assertEquals("2414003", ErrorCode.INVALID_HEADER_VALUE);
        assertEquals("2414004", ErrorCode.MISSING_REQUIRED_QUERY_PARAM);
        assertEquals("2414005", ErrorCode.UNSUPPORTED_QUERY_PARAM);
        assertEquals("2414006", ErrorCode.INVALID_QUERY_PARAM_VALUE);
        assertEquals("2414007", ErrorCode.INVALID_PATH_VARIABLE);
        assertEquals("2414008", ErrorCode.MALFORMED_BODY_CONTENT);
        assertEquals("2414009", ErrorCode.COUNTRY_NOT_ASSIGNED);
        assertEquals("2414010", ErrorCode.INVALID_INPUT_DATA);
        assertEquals("2414101", ErrorCode.INVALID_APPKEY);
        assertEquals("2414102", ErrorCode.INVALID_TOKEN);
        assertEquals("2414105", ErrorCode.INVALID_USERTOKEN);
        assertEquals("2414106", ErrorCode.USERTOKEN_EXPIRED);
        assertEquals("2414151", ErrorCode.PERMISSION_DENIED);
        assertEquals("2414152", ErrorCode.ACCESS_DENIED);
        assertEquals("2414153", ErrorCode.HTTPS_ONLY);
    }

    @Test
    void testOtherErrorCodeValues() {
        assertEquals("2414154", ErrorCode.DUID_OR_IP_DENIED);
        assertEquals("2414163", ErrorCode.REQUIRED_URI_NOT_EXISTS);
        assertEquals("2414202", ErrorCode.DATA_NOT_FOUND);
        assertEquals("2414203", ErrorCode.DATA_NOT_EDITABLE);
        assertEquals("2414204", ErrorCode.DATA_NOT_UNIQUE);
        assertEquals("2414205", ErrorCode.DATA_IS_CYCLIC);
        assertEquals("2414206", ErrorCode.DATA_INTEGRITY_VIOLATION);
        assertEquals("2414221", ErrorCode.UNSUPPORTED_HTTP_METHOD);
        assertEquals("2414222", ErrorCode.UNSUPPORTED_ACTION);
        assertEquals("2414223", ErrorCode.MODIFYING_ROLE_OF_SELF);
        assertEquals("2414241", ErrorCode.NOT_ACCEPTABLE);
        assertEquals("2414261", ErrorCode.REQUEST_TIMEOUT);
        assertEquals("2414281", ErrorCode.DATA_ALREADY_EXISTS);
        assertEquals("2414301", ErrorCode.NO_CONTENT_LENGTH);
        assertEquals("2414321", ErrorCode.REQUEST_TOO_LARGE);
        assertEquals("2414342", ErrorCode.INVALID_CHARACTER_SET);
        assertEquals("2415001", ErrorCode.INTERNAL_SERVER_ERROR);
        assertEquals("2415002", ErrorCode.IMS_ERROR);
        assertEquals("2415101", ErrorCode.NOT_IMPLEMENTED);
        assertEquals("2415163", ErrorCode.SERVICE_UNAVAILABLE);
        assertEquals("2415301", ErrorCode.TIMEOUT_EXCEPTION);
    }
}