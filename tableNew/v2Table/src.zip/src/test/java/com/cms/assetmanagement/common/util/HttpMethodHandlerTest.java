package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.exception.CustomException;
import com.cms.assetmanagement.model.ResponseDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

class HttpMethodHandlerTest {

    private HttpMethodHandler httpMethodHandler;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        httpMethodHandler = new HttpMethodHandler(restTemplate);
    }

    @Test
    void testHandleHttpExchange_Success() {
        // Arrange
        String endPoint = "http://test.com/api";
        String httpMethod = "GET";

        HttpEntity<?> httpEntity = new HttpEntity<>(new LinkedMultiValueMap<>());
        Class<ResponseDto> className = ResponseDto.class;

        ResponseDto responseDto = new ResponseDto();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        when(restTemplate.exchange((endPoint), (HttpMethod.GET), (httpEntity), (className)))
            .thenReturn(responseEntity);

        // Act
        ResponseEntity<?> result = httpMethodHandler.handleHttpExchange(endPoint, httpMethod,
            httpEntity, className);

        // Assert
        assertNotNull(result);
        assertEquals(responseEntity, result);
        verify(restTemplate).exchange((endPoint), (HttpMethod.GET), (httpEntity),
            (className));
    }

    @Test
    void testHandleHttpExchange_RestClientException() {
        // Arrange
        String endPoint = "http://test.com/api";
        String httpMethod = "GET";
        HttpEntity<?> httpEntity = new HttpEntity<>(new LinkedMultiValueMap<>());
        Class<ResponseDto> className = ResponseDto.class;

        RestClientException restClientException = new RestClientException("Rest Client Error");

        when(restTemplate.exchange((endPoint), (HttpMethod.GET), (httpEntity), (className)))
            .thenThrow(restClientException);

        // Act & Assert
        CustomException exception = assertThrows(CustomException.class, () -> {
            httpMethodHandler.handleHttpExchange(endPoint, httpMethod, httpEntity, className);
        });

        assertEquals(restClientException.getMessage(), exception.getMessage());
        verify(restTemplate).exchange((endPoint), (HttpMethod.GET), (httpEntity),
            (className));
    }

}
