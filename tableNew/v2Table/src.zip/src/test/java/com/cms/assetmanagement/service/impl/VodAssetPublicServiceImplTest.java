package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.publicapi.QueryParamDto;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VodAssetPublicServiceImplTest {

    @Mock
    private VodAssetMapper vodAssetMapper;

    @Mock
    private Utils utils;

    @InjectMocks
    private VodAssetPublicServiceImpl vodAssetPublicService;

    @BeforeEach
    void setUp() {
        // Set default values for @Value fields
        vodAssetPublicService.cmsFeedWorkers = "worker1,worker2";
        vodAssetPublicService.externalFeedWorkers = "extWorker1,extWorker2";
        vodAssetPublicService.region = "US";

        // Call init method to initialize lists
        vodAssetPublicService.init();
    }

    @Test
    void getAssets_Success_WithAllParameters() {
        // Arrange
        QueryParamDto queryParamDto = QueryParamDto.builder()
            .providerId("provider1")
            .countryCode("US")
            .programId("program1")
            .programType("MOVIE")
            .mediaStatus("ACTIVE")
            .sortBy("title")
            .limit(10)
            .offset(0)
            .build();

        List<VodAssetDto> expectedAssets = createSampleAssetList();
        AssetFilterBodyDto expectedFilterBody = createSampleFilterBody();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(expectedFilterBody);

        // Act
        List<VodAssetDto> result = vodAssetPublicService.getAssets(queryParamDto);

        // Assert
        assertNotNull(result);
        assertEquals(expectedAssets.size(), result.size());
    }

    @Test
    void getAssets_Success_WithDefaultAllValues() {
        // Arrange
        QueryParamDto queryParamDto = QueryParamDto.builder()
            .providerId("ALL")
            .countryCode("ALL")
            .programId(null)
            .programType(null)
            .mediaStatus(null)
            .sortBy(null)
            .limit(20)
            .offset(0)
            .build();

        List<VodAssetDto> expectedAssets = new ArrayList<>();
        AssetFilterBodyDto expectedFilterBody = AssetFilterBodyDto.builder().build();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(expectedFilterBody);

        // Act
        List<VodAssetDto> result = vodAssetPublicService.getAssets(queryParamDto);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getAssets_Success_WithMultipleValues() {
        // Arrange
        QueryParamDto queryParamDto = QueryParamDto.builder()
            .providerId("provider1,provider2")
            .countryCode("US,CA")
            .programId("program1,program2")
            .programType("MOVIE,SHOW")
            .mediaStatus("ACTIVE,INACTIVE")
            .sortBy("-title,+date")
            .limit(5)
            .offset(10)
            .build();

        List<VodAssetDto> expectedAssets = createSampleAssetList();
        AssetFilterBodyDto expectedFilterBody = createSampleFilterBody();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(expectedFilterBody);
        // Act
        List<VodAssetDto> result = vodAssetPublicService.getAssets(queryParamDto);

        // Assert
        assertNotNull(result);
        assertEquals(expectedAssets.size(), result.size());
    }

    @Test
    void getAssets_Success_EmptyResults() {
        // Arrange
        QueryParamDto queryParamDto = QueryParamDto.builder()
            .providerId("provider1")
            .countryCode("US")
            .limit(10)
            .offset(0)
            .build();

        List<VodAssetDto> expectedAssets = new ArrayList<>();
        AssetFilterBodyDto expectedFilterBody = createSampleFilterBody();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(expectedFilterBody);

        // Act
        List<VodAssetDto> result = vodAssetPublicService.getAssets(queryParamDto);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getAssets_Success_WithProgramIdFilter() {
        // Arrange
        QueryParamDto queryParamDto = QueryParamDto.builder()
            .providerId("provider1")
            .countryCode("US")
            .programId("program123")
            .limit(10)
            .offset(0) // Should be set to 0 when programId is present
            .build();

        List<VodAssetDto> expectedAssets = createSampleAssetList();
        AssetFilterBodyDto expectedFilterBody = createSampleFilterBody();

        when(vodAssetMapper.getFilteredAssets(any(AssetFilterBodyDto.class), anyList(), anyList(),
            anyList(), any()))
            .thenReturn(expectedAssets);
        when(utils.getColumnMapping(any(AssetFilterBodyDto.class))).thenReturn(expectedFilterBody);

        // Act
        List<VodAssetDto> result = vodAssetPublicService.getAssets(queryParamDto);

        // Assert
        assertNotNull(result);
        assertEquals(expectedAssets.size(), result.size());
    }

    private List<VodAssetDto> createSampleAssetList() {
        List<VodAssetDto> assets = new ArrayList<>();
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content123")
            .vcCpId("provider1")
            .countryCode("US")
            .status("New")
            .licenseWindow("Pending")
            .build();
        assets.add(asset);
        return assets;
    }

    private AssetFilterBodyDto createSampleFilterBody() {
        return AssetFilterBodyDto.builder().build();
    }
}
