package com.cms.assetmanagement.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.util.DevConsoleUtil;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.mapper.asset.content.DevConsoleMapper;
import com.cms.assetmanagement.model.devconsole.TiFeedworkerUpdateDto;
import com.cms.assetmanagement.model.devconsole.TiRequestDto;
import com.cms.assetmanagement.model.filter.PaginationDto;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = DevConsoleServiceTest.class)
class DevConsoleServiceTest {

    @Mock
    private DevConsoleMapper devConsoleMapper;

    @Mock
    private DevConsoleUtil devConsoleUtil;

    @InjectMocks
    private DevConsoleService devConsoleService;

    @BeforeEach
    void setUp() {
        // Reset mocks before each test
        reset(devConsoleMapper, devConsoleUtil);
    }

    @Test
    void getTiDataTest_NullPagination() {
        Mockito.when(devConsoleMapper.getTiData(Mockito.anyString(), Mockito.any())).thenReturn(
            List.of());

        TiRequestDto tiRequestDto = TiRequestDto.builder().pagination(null).feedWorker("CMS")
            .build();

        assertDoesNotThrow(() -> devConsoleService.getTiData(tiRequestDto));
    }

    @Test
    void getTiDataTest_WithPagination() {
        Mockito.when(devConsoleMapper.getTiData(Mockito.anyString(), Mockito.any())).thenReturn(
            List.of());

        TiRequestDto tiRequestDto = TiRequestDto.builder()
            .pagination(PaginationDto.builder().offset(0).limit(1000).build()).feedWorker("CMS")
            .build();

        assertDoesNotThrow(() -> devConsoleService.getTiData(tiRequestDto));
    }

    @Test
    void testUpdateTiFeedworker_ValidInput() {
        // Arrange
        TiFeedworkerUpdateDto tiFeedworkerUpdateDto = TiFeedworkerUpdateDto.builder()
            .vcCpId("cp123")
            .countryCode("US")
            .feedworker("cms")
            .build();

        when(devConsoleUtil.isValidFeedWorker(Mockito.anyString())).thenReturn(true);

        // Act and Assert
        assertDoesNotThrow(() -> devConsoleService.updateTiFeedworker(tiFeedworkerUpdateDto));
        verify(devConsoleMapper, times(1)).updateTiFeedworker(tiFeedworkerUpdateDto);
    }

    @Test
    void testUpdateTiFeedworker_InvalidInput() {
        // Arrange
        TiFeedworkerUpdateDto tiFeedworkerUpdateDto = TiFeedworkerUpdateDto.builder()
            .vcCpId("cp123")
            .countryCode("US")
            .feedworker("INVALID")
            .build();

        when(devConsoleUtil.isValidFeedWorker(tiFeedworkerUpdateDto.getFeedworker())).thenReturn(
            false);

        // Act and Assert
        assertThrows(InvalidInputDataException.class,
            () -> devConsoleService.updateTiFeedworker(tiFeedworkerUpdateDto));
        verify(devConsoleMapper, never()).updateTiFeedworker(any(TiFeedworkerUpdateDto.class));
    }

}
