package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import org.junit.jupiter.api.Test;

class ErrorConstantsTest {

    @Test
    void testErrorConstantsForGeneralErrors() {
        // Test general error constants
        assertEquals("Error", ErrorConstants.ERROR);
        assertEquals("error", ErrorConstants.ERROR_ATTRIBUTE_NAME);
        assertEquals("error_datetime", ErrorConstants.ERROR_DATETIME);
        assertEquals("Json cannot be converted to SMF Asset Object", ErrorConstants.ERROR_JSON_CONVERSION_TO_ASSET);
        assertEquals("Ad Break check failed for Asset", ErrorConstants.ERROR_AD_BREAK_CHECK);
        assertEquals("Content Provider and Country combination is not allowed", ErrorConstants.ERROR_PROVIDER_CHECK);
        assertEquals("Description check failed for Asset", ErrorConstants.ERROR_DESCRIPTION_CHECK);
        assertEquals("Parental Ratings check failed for Asset", ErrorConstants.ERROR_PARENTAL_RATINGS_CHECK);
        assertEquals("Duplicate Images present in Asset SMF", ErrorConstants.ERROR_DUPLICATE_IMAGES_CHECK);
        assertEquals("Duplicate Id is present from Different CP", ErrorConstants.ERROR_DUPLICATE_ID_FROM_DIFFERENT_CP_CHECK);
    }

    @Test
    void testErrorConstantsForArtistAndPlayback() {
        // Test artist and playback related constants
        assertEquals("Artist Info not present for asset in casts of SMF", ErrorConstants.ERROR_ARTIST_INFO_CHECK);
        assertEquals("Playback Items check failed because available Start Date and available Ending Date are not in required format", ErrorConstants.ERROR_PLAYBACK_ITEMS_CHECK);
        assertEquals("Either casts is null or cast list is empty", ErrorConstants.ERROR_ARTIST_INFO_CHECK_CASTE_PRESENT_OR_NOT);
        assertEquals("Country provided doesn't exist in Country Lang Mapping of DB", ErrorConstants.ERROR_COUNTRY_NOT_PRESENT_IN_DB);
        assertEquals("Program ID provided doesn't exist in DB", ErrorConstants.PROGRAM_ID_NOT_PRESENT_IN_DB);
        assertEquals("Language code mismatch with DB -> ", ErrorConstants.ERROR_LANG_NOT_PRESENT_IN_DB);
        assertEquals("Lang Code for the provided country is null in DB", ErrorConstants.ERROR_COUNTRY_LANGCODE_MISSING);
        assertEquals("Type provided for program ID is invalid", ErrorConstants.ERROR_TYPE_INVALID);
        assertEquals("Type provided for the asset is invalid", ErrorConstants.ERROR_TYPE_NOT_IN_LIST);
        assertEquals("Provider or Country code is invalid for the Program Id", ErrorConstants.ERROR_INVALID_PROVIDER_CNTY);
    }

    @Test
    void testErrorConstantsForWindowValidation() {
        // Test window validation constants
        assertEquals("Window list contains overlapping windows", ErrorConstants.ERROR_OVERLAPPING_WINDOWS);
        assertEquals("Either invalid date or Window list contains window where available start is greater than available ending", ErrorConstants.ERROR_INVALID_WINDOWS);
        assertEquals("title_check_failed_for_asset", ErrorConstants.ERROR_TITLE_CHECK);
        assertEquals("audio_lang_error", ErrorConstants.AUDIO_LANG_ERROR);
        assertEquals("subtitle_lang_error", ErrorConstants.SUBTITLE_LANG_ERROR);
        assertEquals("program_id_error", ErrorConstants.PROGRAM_ID_ERROR);
        assertEquals("provider_country_combo_error", ErrorConstants.PROVIDER_COUNTRY_COMBO_ERROR);
        assertEquals("type_error", ErrorConstants.TYPE_ERROR);
        assertEquals("provider_country_error", ErrorConstants.PROVIDER_COUNTRY_ERROR);
        assertEquals("status_error", ErrorConstants.STATUS_ERROR);
    }

    @Test
    void testErrorConstantsForHierarchyAndPlayback() {
        // Test hierarchy and playback constants
        assertEquals("parent_show_error", ErrorConstants.PARENT_SHOW_ERROR);
        assertEquals("parent_showId_type_mismatch_error", ErrorConstants.PARENT_SHOW_TYPE_ERROR);
        assertEquals("parent_season_error", ErrorConstants.PARENT_SEASON_ERROR);
        assertEquals("parent_seasonId_type_mismatch_error", ErrorConstants.PARENT_SEASON_TYPE_ERROR);
        assertEquals("hierarchy_error", ErrorConstants.HIERARCHY_ERROR);
        assertEquals("playback_items_error", ErrorConstants.PLAYBACK_ITEMS_ERROR);
        assertEquals("insufficient_info_error", ErrorConstants.INSUFFICIENT_INFO_ERROR);
        assertEquals("license_window_error", ErrorConstants.LICENSE_WINDOW_ERROR);
        assertEquals("event_window_error", ErrorConstants.EVENT_WINDOW_ERROR);
        assertEquals("title_error", ErrorConstants.ERROR_TITLE_NOT_PRESENT);
        assertEquals("external_id_error", ErrorConstants.EXTERNAL_ID_ERROR);
    }

    @Test
    void testErrorConstantsForTitleAndLanguage() {
        // Test title and language related constants
        assertEquals("Title length exceeds ", ErrorConstants.ERROR_TITLE_LENGTH_EXCEED_TITLE_BYTE_LENGTH);
        assertEquals("Title's type was not 'main'", ErrorConstants.ERROR_NO_MAIN_TITLE_FOUND);
        assertEquals("LangCode Match Not Found", ErrorConstants.ERROR_LANGCODE_MATCH_FAIL);
    }

    @Test
    void testPrivateConstructor() throws Exception {
        // Test that the constructor is private and throws an exception
        Constructor<ErrorConstants> constructor = ErrorConstants.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        
        // Verify that constructor throws IllegalStateException
        InvocationTargetException exception = assertThrows(InvocationTargetException.class, () -> {
            constructor.newInstance();
        });
        
        assertTrue(exception.getCause() instanceof IllegalStateException);
        assertEquals("Error Constants class, only static access", exception.getCause().getMessage());
    }
}
