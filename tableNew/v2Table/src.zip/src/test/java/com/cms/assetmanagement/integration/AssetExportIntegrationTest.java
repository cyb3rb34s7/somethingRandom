package com.cms.assetmanagement.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.PaginationDto;
import com.cms.assetmanagement.model.filter.SortDto;
import com.cms.assetmanagement.service.impl.VodAssetServiceImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * TVPCMS-1777 Integration Test — runs against REAL Oracle DB.
 *
 * <h2>PURPOSE</h2>
 * <ol>
 *   <li><b>BEFORE optimization</b>: Run once to capture golden output (baseline)</li>
 *   <li><b>AFTER optimization</b>: Run again — same filters must return same results</li>
 *   <li>Captures real performance timings for before/after comparison</li>
 * </ol>
 *
 * <h2>HOW IT WORKS</h2>
 * <ul>
 *   <li>First run: no golden files exist → results are SAVED as golden output</li>
 *   <li>Second run: golden files exist → results are COMPARED against golden output</li>
 *   <li>To re-capture: delete <code>build/golden-output/</code> and run again</li>
 * </ul>
 *
 * <h2>HOW TO RUN</h2>
 * <pre>
 * # 1. Fill in application-integration.properties with your Oracle DB details
 * # 2. Run:
 * ./gradlew test --tests "*AssetExportIntegrationTest" -Dspring.profiles.active=integration
 *
 * # To re-capture golden output after optimization:
 * rm -rf build/golden-output/
 * ./gradlew test --tests "*AssetExportIntegrationTest" -Dspring.profiles.active=integration
 * </pre>
 *
 * <h2>WHAT IT COVERS</h2>
 * <ul>
 *   <li>All filter types: main-table, joined-table (DRM, EXT, HISTORY), search, dateRange</li>
 *   <li>Filter combinations</li>
 *   <li>Sorting, pagination, page consistency</li>
 *   <li>Performance baseline (5000-asset page)</li>
 * </ul>
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("integration")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Tag("integration")
class AssetExportIntegrationTest {

    @Autowired
    private VodAssetServiceImpl vodAssetService;

    private static final Path GOLDEN_DIR = Path.of("build/golden-output");
    private static final int SMALL_PAGE = 200;
    private static final int PERF_PAGE = 5000;

    private final ObjectMapper objectMapper = new ObjectMapper()
        .enable(SerializationFeature.INDENT_OUTPUT);

    // Performance log: scenario name → [capturedMs, verifyMs]
    private final Map<String, long[]> perfLog = new LinkedHashMap<>();

    // ==================== DISCOVERED TEST DATA ====================
    // Populated from a real DB query in @BeforeAll — no hardcoded values
    private String discoveredType;
    private String discoveredCountry;
    private String discoveredContentId;
    private String discoveredContentPartner;
    private String discoveredGenre;
    private String discoveredTitle;
    private String discoveredFeedWorker;
    private String discoveredStartDate;   // yyyy-MM-dd HH:mm:ss format for dateRange
    private String discoveredEndDate;
    private String discoveredExternalProgramId;
    private String discoveredShowTitle;
    private String discoveredQuality;
    private String discoveredAudioLang;
    private boolean hasDataInDb = false;

    // ==================== SETUP ====================

    @BeforeAll
    void setUp() throws IOException {
        Files.createDirectories(GOLDEN_DIR);

        // Discovery: query the DB with no filters to learn what data exists
        System.out.println("\n====================================================");
        System.out.println("  TVPCMS-1777 INTEGRATION TEST — DISCOVERING DATA");
        System.out.println("====================================================");

        try {
            AssetFilterBodyDto body = buildBody(null, 0, SMALL_PAGE, null);
            List<VodAssetDto> sample = vodAssetService.getAssetsForExport(body);

            if (sample == null || sample.isEmpty()) {
                System.out.println("WARNING: No data found in DB. All tests will be skipped.");
                return;
            }

            hasDataInDb = true;
            System.out.println("Found " + sample.size() + " assets in sample query.");

            // Extract real values for filter scenarios
            discoveredType = sample.stream().map(VodAssetDto::getType)
                .filter(Objects::nonNull).findFirst().orElse(null);
            discoveredCountry = sample.stream().map(VodAssetDto::getCountryCode)
                .filter(Objects::nonNull).findFirst().orElse(null);
            discoveredContentId = sample.stream().map(VodAssetDto::getContentId)
                .filter(Objects::nonNull).findFirst().orElse(null);
            discoveredContentPartner = sample.stream().map(VodAssetDto::getContentPartner)
                .filter(Objects::nonNull).filter(s -> !s.isEmpty()).findFirst().orElse(null);
            discoveredFeedWorker = sample.stream().map(VodAssetDto::getFeedWorker)
                .filter(Objects::nonNull).findFirst().orElse(null);
            discoveredQuality = sample.stream().map(VodAssetDto::getQuality)
                .filter(Objects::nonNull).filter(s -> !s.isEmpty()).findFirst().orElse(null);
            discoveredAudioLang = sample.stream().map(VodAssetDto::getAudioLang)
                .filter(Objects::nonNull).filter(s -> !s.isEmpty()).findFirst().orElse(null);

            // For title search, pick a word from a mainTitle
            String anyTitle = sample.stream().map(VodAssetDto::getMainTitle)
                .filter(Objects::nonNull).filter(t -> t.length() > 3).findFirst().orElse(null);
            if (anyTitle != null) {
                String[] words = anyTitle.split("\\s+");
                discoveredTitle = words.length > 1 ? words[0] : anyTitle.substring(0, 3);
            }

            // Genre: extract first genre token
            String anyGenre = sample.stream().map(VodAssetDto::getGenres)
                .filter(Objects::nonNull).filter(g -> !g.isEmpty()).findFirst().orElse(null);
            if (anyGenre != null) {
                discoveredGenre = anyGenre.split(",")[0].trim();
            }

            // Show title: look for episodes/seasons that have a showTitle
            discoveredShowTitle = sample.stream()
                .filter(a -> "EPISODE".equals(a.getType()) || "SEASON".equals(a.getType()))
                .map(VodAssetDto::getShowTitle)
                .filter(Objects::nonNull).filter(s -> s.length() > 2)
                .findFirst().orElse(null);

            // External program ID: from externalProvider collection
            discoveredExternalProgramId = sample.stream()
                .filter(a -> a.getExternalProvider() != null && !a.getExternalProvider().isEmpty())
                .flatMap(a -> a.getExternalProvider().stream())
                .map(ExternalProviderDto::getExternalProgramId)
                .filter(Objects::nonNull)
                .findFirst().orElse(null);

            // Date range: use availableStarting/expiryDate from a real asset
            for (VodAssetDto asset : sample) {
                if (asset.getAvailableStarting() != null && asset.getExpiryDate() != null) {
                    discoveredStartDate = convertToDateRangeFormat(asset.getAvailableStarting());
                    discoveredEndDate = convertToDateRangeFormat(asset.getExpiryDate());
                    break;
                }
            }
            // Fallback: use broad date range
            if (discoveredStartDate == null) {
                discoveredStartDate = LocalDate.now().minusYears(2)
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00";
                discoveredEndDate = LocalDate.now().plusYears(1)
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59";
            }

            System.out.println("Discovered values:");
            System.out.println("  type            = " + discoveredType);
            System.out.println("  country         = " + discoveredCountry);
            System.out.println("  contentId       = " + discoveredContentId);
            System.out.println("  contentPartner  = " + discoveredContentPartner);
            System.out.println("  genre           = " + discoveredGenre);
            System.out.println("  title (search)  = " + discoveredTitle);
            System.out.println("  showTitle       = " + discoveredShowTitle);
            System.out.println("  feedWorker      = " + discoveredFeedWorker);
            System.out.println("  quality         = " + discoveredQuality);
            System.out.println("  audioLang       = " + discoveredAudioLang);
            System.out.println("  externalPgmId   = " + discoveredExternalProgramId);
            System.out.println("  startDate       = " + discoveredStartDate);
            System.out.println("  endDate         = " + discoveredEndDate);
            System.out.println("====================================================\n");

        } catch (Exception e) {
            System.err.println("DISCOVERY FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ==================== MAIN TABLE FILTERS ====================

    @Test @Order(1)
    void T01_noFilters_baseline() {
        assumeDataExists();
        runScenario("T01_noFilters_baseline",
            buildBody(null, 0, SMALL_PAGE, null));
    }

    @Test @Order(2)
    void T02_filterByType() {
        assumeDataExists();
        assumeTrue(discoveredType != null, "No type discovered");
        runScenario("T02_filterByType_" + discoveredType,
            buildBody(List.of(filter("type", discoveredType)), 0, SMALL_PAGE, null));
    }

    @Test @Order(3)
    void T03_filterByCountry() {
        assumeDataExists();
        assumeTrue(discoveredCountry != null, "No country discovered");
        runScenario("T03_filterByCountry_" + discoveredCountry,
            buildBody(List.of(filter("countryCode", discoveredCountry)), 0, SMALL_PAGE, null));
    }

    @Test @Order(4)
    void T04_filterByStatus_Released() {
        assumeDataExists();
        runScenario("T04_filterByStatus_Released",
            buildBody(List.of(filter("status", "Released")), 0, SMALL_PAGE, null));
    }

    @Test @Order(5)
    void T05_filterByStatus_ReadyForRelease() {
        assumeDataExists();
        runScenario("T05_filterByStatus_ReadyForRelease",
            buildBody(List.of(filter("status", "Ready for Release")), 0, SMALL_PAGE, null));
    }

    @Test @Order(6)
    void T06_filterByStatus_Untrackable() {
        assumeDataExists();
        runScenario("T06_filterByStatus_Untrackable",
            buildBody(List.of(filter("status", "Untrackable")), 0, SMALL_PAGE, null));
    }

    @Test @Order(7)
    void T07_filterByContentPartner() {
        assumeDataExists();
        assumeTrue(discoveredContentPartner != null, "No contentPartner discovered");
        runScenario("T07_filterByContentPartner",
            buildBody(List.of(filter("contentPartner", discoveredContentPartner)), 0, SMALL_PAGE, null));
    }

    @Test @Order(8)
    void T08_filterByGenres() {
        assumeDataExists();
        assumeTrue(discoveredGenre != null, "No genre discovered");
        runScenario("T08_filterByGenres",
            buildBody(List.of(filter("genres", discoveredGenre)), 0, SMALL_PAGE, null));
    }

    @Test @Order(9)
    void T09_filterByQuality() {
        assumeDataExists();
        assumeTrue(discoveredQuality != null, "No quality discovered");
        runScenario("T09_filterByQuality",
            buildBody(List.of(filter("quality", discoveredQuality)), 0, SMALL_PAGE, null));
    }

    @Test @Order(10)
    void T10_filterByAudioLang() {
        assumeDataExists();
        assumeTrue(discoveredAudioLang != null, "No audioLang discovered");
        runScenario("T10_filterByAudioLang",
            buildBody(List.of(filter("audioLang", discoveredAudioLang)), 0, SMALL_PAGE, null));
    }

    @Test @Order(11)
    void T11_filterByFeedWorker() {
        assumeDataExists();
        assumeTrue(discoveredFeedWorker != null, "No feedWorker discovered");
        runScenario("T11_filterByFeedWorker",
            buildBody(List.of(filter("feedWorker", discoveredFeedWorker)), 0, SMALL_PAGE, null));
    }

    @Test @Order(12)
    void T12_filterByIngestionType_CMS() {
        assumeDataExists();
        runScenario("T12_filterByIngestionType_CMS",
            buildBody(List.of(filter("ingestionType", "CMS")), 0, SMALL_PAGE, null));
    }

    @Test @Order(13)
    void T13_filterByLicenseStatus_Active() {
        assumeDataExists();
        runScenario("T13_filterByLicenseStatus_Active",
            buildBody(List.of(filter("licenseStatus", "ACTIVE")), 0, SMALL_PAGE, null));
    }

    @Test @Order(14)
    void T14_filterByLicenseStatus_Expired() {
        assumeDataExists();
        runScenario("T14_filterByLicenseStatus_Expired",
            buildBody(List.of(filter("licenseStatus", "EXPIRED")), 0, SMALL_PAGE, null));
    }

    @Test @Order(15)
    void T15_filterByDbStatus_PrdStg() {
        assumeDataExists();
        runScenario("T15_filterByDbStatus_PrdStg",
            buildBody(List.of(filter("dbStatus", "PRD & STG")), 0, SMALL_PAGE, null));
    }

    @Test @Order(16)
    void T16_filterByLiveOnDevice_Yes() {
        assumeDataExists();
        runScenario("T16_filterByLiveOnDevice_Yes",
            buildBody(List.of(filter("liveOnDevice", "Yes")), 0, SMALL_PAGE, null));
    }

    @Test @Order(17)
    void T17_filterByAttributes() {
        assumeDataExists();
        runScenario("T17_filterByAttributes",
            buildBody(List.of(filter("attributes", "live_ott")), 0, SMALL_PAGE, null));
    }

    // ==================== JOINED TABLE FILTERS (HIGH RISK) ====================

    @Test @Order(20)
    void T20_filterByDrm_Yes() {
        assumeDataExists();
        runScenario("T20_filterByDrm_Yes",
            buildBody(List.of(filter("drm", "Y")), 0, SMALL_PAGE, null));
    }

    @Test @Order(21)
    void T21_filterByDrm_No() {
        assumeDataExists();
        runScenario("T21_filterByDrm_No",
            buildBody(List.of(filter("drm", "N")), 0, SMALL_PAGE, null));
    }

    @Test @Order(22)
    void T22_searchByExternalId() {
        assumeDataExists();
        assumeTrue(discoveredExternalProgramId != null, "No external ID in sample data");
        runScenario("T22_searchByExternalId",
            buildBody(List.of(search("externalId", discoveredExternalProgramId)), 0, SMALL_PAGE, null));
    }

    @Test @Order(23)
    void T23_searchByExternalProgramId() {
        assumeDataExists();
        assumeTrue(discoveredExternalProgramId != null, "No external ID in sample data");
        runScenario("T23_searchByExternalProgramId",
            buildBody(List.of(search("externalProgramId", discoveredExternalProgramId)), 0, SMALL_PAGE, null));
    }

    @Test @Order(24)
    void T24_searchByExternalProvider() {
        assumeDataExists();
        assumeTrue(discoveredExternalProgramId != null, "No external provider in sample data");
        runScenario("T24_searchByExternalProvider",
            buildBody(List.of(search("externalIdProvider", "tms")), 0, SMALL_PAGE, null));
    }

    @Test @Order(25)
    void T25_filterByHistory() {
        assumeDataExists();
        runScenario("T25_filterByHistory",
            buildBody(List.of(filter("history", "true")), 0, SMALL_PAGE, null));
    }

    // ==================== SEARCH FILTERS ====================

    @Test @Order(30)
    void T30_searchByMainTitle() {
        assumeDataExists();
        assumeTrue(discoveredTitle != null, "No title discovered");
        runScenario("T30_searchByMainTitle",
            buildBody(List.of(search("mainTitle", discoveredTitle)), 0, SMALL_PAGE, null));
    }

    @Test @Order(31)
    void T31_searchByShowTitle() {
        assumeDataExists();
        assumeTrue(discoveredShowTitle != null, "No show title discovered");
        String searchTerm = discoveredShowTitle.length() > 4
            ? discoveredShowTitle.substring(0, 4) : discoveredShowTitle;
        runScenario("T31_searchByShowTitle",
            buildBody(List.of(search("showTitle", searchTerm)), 0, SMALL_PAGE, null));
    }

    @Test @Order(32)
    void T32_searchByContentId() {
        assumeDataExists();
        assumeTrue(discoveredContentId != null, "No contentId discovered");
        runScenario("T32_searchByContentId",
            buildBody(List.of(search("contentId", discoveredContentId)), 0, SMALL_PAGE, null));
    }

    // ==================== DATE RANGE FILTERS ====================

    @Test @Order(40)
    void T40_dateRange_LicenseStatusRange() {
        assumeDataExists();
        runScenario("T40_dateRange_LicenseStatusRange",
            buildBody(List.of(dateRange("licenseStatusRange",
                discoveredStartDate, discoveredEndDate)), 0, SMALL_PAGE, null));
    }

    @Test @Order(41)
    void T41_dateRange_LicenseRange() {
        assumeDataExists();
        runScenario("T41_dateRange_LicenseRange",
            buildBody(List.of(dateRange("licenseRange",
                discoveredStartDate, discoveredEndDate)), 0, SMALL_PAGE, null));
    }

    @Test @Order(42)
    void T42_dateRange_IngestionRange() {
        assumeDataExists();
        // Broad ingestion range: last 2 years to now
        String twoYearsAgo = LocalDate.now().minusYears(2)
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00";
        String today = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59";
        runScenario("T42_dateRange_IngestionRange",
            buildBody(List.of(dateRange("assetIngestionRange", twoYearsAgo, today)),
                0, SMALL_PAGE, null));
    }

    @Test @Order(43)
    void T43_dateRange_UpdateRange() {
        assumeDataExists();
        // Last 30 days
        String thirtyDaysAgo = LocalDate.now().minusDays(30)
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00";
        String today = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59";
        runScenario("T43_dateRange_UpdateRange",
            buildBody(List.of(dateRange("assetUpdateRange", thirtyDaysAgo, today)),
                0, SMALL_PAGE, null));
    }

    // ==================== FILTER COMBINATIONS ====================

    @Test @Order(50)
    void T50_combo_TypeAndCountry() {
        assumeDataExists();
        assumeTrue(discoveredType != null && discoveredCountry != null, "Need type + country");
        runScenario("T50_combo_TypeAndCountry",
            buildBody(List.of(
                filter("type", discoveredType),
                filter("countryCode", discoveredCountry)
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(51)
    void T51_combo_TypeAndDrm() {
        assumeDataExists();
        assumeTrue(discoveredType != null, "Need type");
        runScenario("T51_combo_TypeAndDrm",
            buildBody(List.of(
                filter("type", discoveredType),
                filter("drm", "Y")
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(52)
    void T52_combo_StatusAndDrmAndCountry() {
        assumeDataExists();
        assumeTrue(discoveredCountry != null, "Need country");
        runScenario("T52_combo_StatusDrmCountry",
            buildBody(List.of(
                filter("status", "Released"),
                filter("drm", "Y"),
                filter("countryCode", discoveredCountry)
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(53)
    void T53_combo_TypeAndExternalId() {
        assumeDataExists();
        assumeTrue(discoveredType != null && discoveredExternalProgramId != null,
            "Need type + externalId");
        runScenario("T53_combo_TypeAndExternalId",
            buildBody(List.of(
                filter("type", discoveredType),
                search("externalId", discoveredExternalProgramId)
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(54)
    void T54_combo_SearchAndFilter() {
        assumeDataExists();
        assumeTrue(discoveredTitle != null && discoveredCountry != null,
            "Need title + country");
        runScenario("T54_combo_SearchAndFilter",
            buildBody(List.of(
                search("mainTitle", discoveredTitle),
                filter("countryCode", discoveredCountry)
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(55)
    void T55_combo_DateRangeAndFilter() {
        assumeDataExists();
        assumeTrue(discoveredType != null, "Need type");
        String thirtyDaysAgo = LocalDate.now().minusDays(30)
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00";
        String today = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59";
        runScenario("T55_combo_DateRangeAndFilter",
            buildBody(List.of(
                filter("type", discoveredType),
                dateRange("assetUpdateRange", thirtyDaysAgo, today)
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(56)
    void T56_combo_DrmAndHistoryAndType() {
        assumeDataExists();
        assumeTrue(discoveredType != null, "Need type");
        runScenario("T56_combo_DrmHistoryType",
            buildBody(List.of(
                filter("type", discoveredType),
                filter("drm", "Y"),
                filter("history", "true")
            ), 0, SMALL_PAGE, null));
    }

    @Test @Order(57)
    void T57_combo_AllJoinedTableFilters() {
        assumeDataExists();
        List<FilterDto> filters = new ArrayList<>();
        filters.add(filter("drm", "Y"));
        filters.add(filter("history", "true"));
        if (discoveredExternalProgramId != null) {
            filters.add(search("externalId", discoveredExternalProgramId));
        }
        runScenario("T57_combo_AllJoinedTableFilters",
            buildBody(filters, 0, SMALL_PAGE, null));
    }

    // ==================== SORTING ====================

    @Test @Order(60)
    void T60_sortByUpdateDate_DESC() {
        assumeDataExists();
        runScenario("T60_sortByUpdateDate_DESC",
            buildBody(null, 0, SMALL_PAGE,
                List.of(SortDto.builder().field("updateDate").order("DESC").build())));
    }

    @Test @Order(61)
    void T61_sortByUpdateDate_ASC() {
        assumeDataExists();
        runScenario("T61_sortByUpdateDate_ASC",
            buildBody(null, 0, SMALL_PAGE,
                List.of(SortDto.builder().field("updateDate").order("ASC").build())));
    }

    @Test @Order(62)
    void T62_sortByMainTitle_ASC() {
        assumeDataExists();
        runScenario("T62_sortByMainTitle_ASC",
            buildBody(null, 0, SMALL_PAGE,
                List.of(SortDto.builder().field("mainTitle").order("ASC").build())));
    }

    @Test @Order(63)
    void T63_sortByRegDate_DESC() {
        assumeDataExists();
        runScenario("T63_sortByRegDate_DESC",
            buildBody(null, 0, SMALL_PAGE,
                List.of(SortDto.builder().field("regDate").order("DESC").build())));
    }

    // ==================== PAGINATION ====================

    @Test @Order(70)
    void T70_pagination_page1() {
        assumeDataExists();
        runScenario("T70_pagination_page1",
            buildBody(null, 0, 100, null));
    }

    @Test @Order(71)
    void T71_pagination_page2() {
        assumeDataExists();
        runScenario("T71_pagination_page2",
            buildBody(null, 100, 100, null));
    }

    @Test @Order(72)
    void T72_pagination_noOverlap() {
        assumeDataExists();

        // Page 1: offset=0, limit=50
        AssetFilterBodyDto body1 = buildBody(null, 0, 50, null);
        long start1 = System.currentTimeMillis();
        List<VodAssetDto> page1 = vodAssetService.getAssetsForExport(body1);
        long dur1 = System.currentTimeMillis() - start1;

        // Page 2: offset=50, limit=50
        AssetFilterBodyDto body2 = buildBody(null, 50, 50, null);
        long start2 = System.currentTimeMillis();
        List<VodAssetDto> page2 = vodAssetService.getAssetsForExport(body2);
        long dur2 = System.currentTimeMillis() - start2;

        System.out.println("T72 Page 1: " + page1.size() + " assets (" + dur1 + "ms)");
        System.out.println("T72 Page 2: " + page2.size() + " assets (" + dur2 + "ms)");

        // Check no content ID overlap between pages
        List<String> ids1 = page1.stream().map(VodAssetDto::getContentId).toList();
        List<String> ids2 = page2.stream().map(VodAssetDto::getContentId).toList();
        boolean overlap = ids1.stream().anyMatch(ids2::contains);
        assertFalse(overlap, "Page 1 and Page 2 should NOT have overlapping content IDs");
    }

    // ==================== PERFORMANCE BASELINE ====================

    @Test @Order(80)
    void T80_performance_5000assets() {
        assumeDataExists();
        System.out.println("\n--- PERFORMANCE TEST: 5000 assets ---");
        runScenario("T80_performance_5000",
            buildBody(null, 0, PERF_PAGE, null));
    }

    @Test @Order(81)
    void T81_performance_5000_withDrmFilter() {
        assumeDataExists();
        System.out.println("\n--- PERFORMANCE TEST: 5000 assets + DRM filter ---");
        runScenario("T81_perf_5000_drm",
            buildBody(List.of(filter("drm", "Y")), 0, PERF_PAGE, null));
    }

    @Test @Order(82)
    void T82_performance_5000_withTypeFilter() {
        assumeDataExists();
        assumeTrue(discoveredType != null, "Need type");
        System.out.println("\n--- PERFORMANCE TEST: 5000 assets + type filter ---");
        runScenario("T82_perf_5000_type",
            buildBody(List.of(filter("type", discoveredType)), 0, PERF_PAGE, null));
    }

    // ==================== CORE LOGIC ====================

    private void runScenario(String scenarioName, AssetFilterBodyDto body) {
        // Execute with timing
        long startMs = System.currentTimeMillis();
        List<VodAssetDto> result = vodAssetService.getAssetsForExport(body);
        long durationMs = System.currentTimeMillis() - startMs;

        if (result == null) {
            result = Collections.emptyList();
        }

        List<Map<String, Object>> snapshot = toSnapshot(result);
        Path goldenFile = GOLDEN_DIR.resolve(scenarioName + ".json");

        if (Files.exists(goldenFile)) {
            // ---- VERIFY MODE ----
            verifyAgainstGolden(scenarioName, snapshot, goldenFile, durationMs);
        } else {
            // ---- CAPTURE MODE ----
            saveGolden(scenarioName, snapshot, goldenFile, durationMs);
        }
    }

    private void saveGolden(String name, List<Map<String, Object>> snapshot,
                            Path goldenFile, long durationMs) {
        try {
            Map<String, Object> goldenData = new LinkedHashMap<>();
            goldenData.put("scenario", name);
            goldenData.put("capturedAt", Instant.now().toString());
            goldenData.put("durationMs", durationMs);
            goldenData.put("assetCount", snapshot.size());
            goldenData.put("assets", snapshot);

            objectMapper.writeValue(goldenFile.toFile(), goldenData);
            perfLog.put(name, new long[]{durationMs, -1});

            System.out.printf("  CAPTURED %-45s | %4d assets | %6d ms%n",
                name, snapshot.size(), durationMs);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save golden output: " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private void verifyAgainstGolden(String name, List<Map<String, Object>> currentSnapshot,
                                     Path goldenFile, long currentDurationMs) {
        try {
            Map<String, Object> goldenData = objectMapper.readValue(
                goldenFile.toFile(), new TypeReference<>() {});
            long goldenDurationMs = ((Number) goldenData.get("durationMs")).longValue();
            int goldenCount = ((Number) goldenData.get("assetCount")).intValue();
            List<Map<String, Object>> goldenAssets =
                (List<Map<String, Object>>) goldenData.get("assets");

            perfLog.put(name, new long[]{goldenDurationMs, currentDurationMs});

            // 1. Compare asset count
            assertEquals(goldenCount, currentSnapshot.size(),
                name + ": asset count mismatch");

            // 2. Compare content IDs in order
            List<String> goldenIds = goldenAssets.stream()
                .map(a -> (String) a.get("contentId")).toList();
            List<String> currentIds = currentSnapshot.stream()
                .map(a -> (String) a.get("contentId")).toList();
            assertEquals(goldenIds, currentIds,
                name + ": content ID list mismatch (order or set)");

            // 3. Compare each asset's key fields
            int mismatches = 0;
            for (int i = 0; i < goldenAssets.size(); i++) {
                Map<String, Object> golden = goldenAssets.get(i);
                Map<String, Object> current = currentSnapshot.get(i);
                String cid = (String) golden.get("contentId");

                for (String key : golden.keySet()) {
                    Object goldenVal = golden.get(key);
                    Object currentVal = current.get(key);
                    if (!Objects.equals(goldenVal, currentVal)) {
                        mismatches++;
                        System.err.printf("  MISMATCH [%s] field=%s golden=%s current=%s%n",
                            cid, key, goldenVal, currentVal);
                    }
                }
            }

            assertEquals(0, mismatches, name + ": " + mismatches + " field mismatches found");

            String speedChange = currentDurationMs < goldenDurationMs
                ? String.format("FASTER by %dms (%.0f%%)",
                    goldenDurationMs - currentDurationMs,
                    (1.0 - (double) currentDurationMs / goldenDurationMs) * 100)
                : String.format("SLOWER by %dms",
                    currentDurationMs - goldenDurationMs);

            System.out.printf("  VERIFIED %-45s | %4d assets | %6d ms → %6d ms | %s%n",
                name, currentSnapshot.size(), goldenDurationMs, currentDurationMs, speedChange);

        } catch (IOException e) {
            throw new RuntimeException("Failed to read golden output: " + name, e);
        }
    }

    // ==================== SNAPSHOT BUILDER ====================

    private List<Map<String, Object>> toSnapshot(List<VodAssetDto> assets) {
        return assets.stream().map(a -> {
            Map<String, Object> snap = new LinkedHashMap<>();
            snap.put("contentId", a.getContentId());
            snap.put("compositeKey", safeCompositeKey(a));
            snap.put("type", a.getType());
            snap.put("status", a.getStatus());
            snap.put("liveOnDevice", a.getLiveOnDevice());
            snap.put("licenseWindowCategory", normalizeLicenseWindow(a.getLicenseWindow()));
            snap.put("dbStatus", a.getDbStatus());
            snap.put("mainTitle", a.getMainTitle());
            snap.put("externalProgramId", a.getExternalProgramId());
            snap.put("externalIdProvider", a.getExternalIdProvider());
            snap.put("drm", a.getDrm());
            snap.put("feedWorker", a.getFeedWorker());
            snap.put("countryCode", a.getCountryCode());
            // Collection sizes — catches batch query mismatches
            snap.put("castSize", a.getCast() != null ? a.getCast().size() : 0);
            snap.put("parentalRatingsSize",
                a.getParentalRatings() != null ? a.getParentalRatings().size() : 0);
            snap.put("licenseWindowListSize",
                a.getLicenseWindowList() != null ? a.getLicenseWindowList().size() : 0);
            snap.put("eventWindowListSize",
                a.getEventWindowList() != null ? a.getEventWindowList().size() : 0);
            snap.put("geoRestrictionsSize",
                a.getGeoRestrictions() != null ? a.getGeoRestrictions().size() : 0);
            snap.put("externalProviderSize",
                a.getExternalProvider() != null ? a.getExternalProvider().size() : 0);
            return snap;
        }).collect(Collectors.toList());
    }

    /**
     * Normalize licenseWindow to a stable category.
     * "Expiring in 45 days" → "Expiring" (the day count changes daily)
     * "Upcoming in 12 days" → "Upcoming"
     * "Active" → "Active"
     * "Expired" → "Expired"
     */
    private String normalizeLicenseWindow(String lw) {
        if (lw == null) return null;
        if (lw.startsWith("Expiring in")) return "Expiring";
        if (lw.startsWith("Upcoming in")) return "Upcoming";
        if (lw.startsWith("Upcoming after")) return "Upcoming_300+";
        return lw; // "Active", "Expired", ""
    }

    // ==================== HELPERS ====================

    private AssetFilterBodyDto buildBody(List<FilterDto> filters, int offset, int limit,
                                         List<SortDto> sortBy) {
        List<String> columns = allExportColumns();
        if (sortBy == null) {
            sortBy = List.of(SortDto.builder().field("updateDate").order("DESC").build());
        }
        return AssetFilterBodyDto.builder()
            .columns(columns)
            .filters(filters)
            .sortBy(sortBy)
            .pagination(PaginationDto.builder().offset(offset).limit(limit).build())
            .build();
    }

    private static List<String> allExportColumns() {
        List<String> cols = new ArrayList<>(Constants.EXPORT_COLUMNS_LIST);
        cols.addAll(List.of("status", "liveOnDevice", "licenseWindow", "dbStatus",
            "externalProgramId", "externalIdProvider", "feedWorker",
            "availableStarting", "expiryDate"));
        return cols;
    }

    private static FilterDto filter(String key, String... values) {
        return FilterDto.builder()
            .type("filter")
            .key(key)
            .values(List.of(values))
            .build();
    }

    private static FilterDto search(String key, String... values) {
        return FilterDto.builder()
            .type("search")
            .key(key)
            .values(List.of(values))
            .build();
    }

    private static FilterDto dateRange(String key, String start, String end) {
        return FilterDto.builder()
            .type("dateRange")
            .key(key)
            .values(List.of(start, end))
            .build();
    }

    private void assumeDataExists() {
        assumeTrue(hasDataInDb, "No data in DB — skipping");
    }

    private String safeCompositeKey(VodAssetDto a) {
        return a.getContentId() + "|" + a.getVcCpId() + "|" + a.getCountryCode();
    }

    /**
     * Convert "2024-01-15T10:30:00Z" → "2024-01-15 10:30:00"
     * for dateRange filter format expected by the SQL.
     */
    private String convertToDateRangeFormat(String isoDate) {
        if (isoDate == null) return null;
        return isoDate.replace("T", " ").replace("Z", "");
    }

    // ==================== SUMMARY REPORT ====================

    @AfterAll
    void printSummary() {
        System.out.println("\n====================================================================");
        System.out.println("  TVPCMS-1777 INTEGRATION TEST SUMMARY");
        System.out.println("====================================================================");
        System.out.printf("  %-50s | %10s | %10s | %s%n",
            "SCENARIO", "BEFORE(ms)", "AFTER(ms)", "CHANGE");
        System.out.println("  " + "-".repeat(95));

        long totalBefore = 0, totalAfter = 0;
        for (Map.Entry<String, long[]> entry : perfLog.entrySet()) {
            String name = entry.getKey();
            long before = entry.getValue()[0];
            long after = entry.getValue()[1];

            if (after == -1) {
                // Capture mode
                System.out.printf("  %-50s | %10d | %10s | %s%n",
                    name, before, "—", "CAPTURED");
                totalBefore += before;
            } else {
                // Verify mode
                totalBefore += before;
                totalAfter += after;
                String change;
                if (before > 0) {
                    double pct = (1.0 - (double) after / before) * 100;
                    change = pct > 0
                        ? String.format("%.1f%% FASTER", pct)
                        : String.format("%.1f%% SLOWER", -pct);
                } else {
                    change = "N/A";
                }
                System.out.printf("  %-50s | %10d | %10d | %s%n",
                    name, before, after, change);
            }
        }

        System.out.println("  " + "-".repeat(95));
        if (totalAfter > 0) {
            double totalPct = (1.0 - (double) totalAfter / totalBefore) * 100;
            System.out.printf("  %-50s | %10d | %10d | %.1f%%%n",
                "TOTAL", totalBefore, totalAfter, totalPct);
        } else {
            System.out.printf("  %-50s | %10d | %10s |%n", "TOTAL", totalBefore, "—");
        }
        System.out.println("====================================================================");
        System.out.println("  Golden output dir: " + GOLDEN_DIR.toAbsolutePath());
        System.out.println("====================================================================\n");
    }
}
