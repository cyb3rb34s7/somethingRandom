package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.util.Utils;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.mapper.asset.content.VodAssetColumnLockMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetImageMapper;
import com.cms.assetmanagement.mapper.asset.content.VodAssetMapper;
import com.cms.assetmanagement.mapper.asset.metadata.VodAssetMetadataMapper;
import com.cms.assetmanagement.service.AssetInsertHelper;
import org.mockito.Mockito;

/**
 * Utility class to provide common mock objects for testing.
 * This helps to reduce code duplication in test classes.
 */
public class MockObjectFactory {

    public static VodAssetMapper createVodAssetMapper() {
        return Mockito.mock(VodAssetMapper.class);
    }

    public static VodAssetMetadataMapper createVodAssetMetadataMapper() {
        return Mockito.mock(VodAssetMetadataMapper.class);
    }

    public static VodAssetColumnLockMapper createVodAssetColumnLockMapper() {
        return Mockito.mock(VodAssetColumnLockMapper.class);
    }

    public static DateRangeWindowService createDateRangeWindowService() {
        return Mockito.mock(DateRangeWindowService.class);
    }

    public static AssetInsertHelper createAssetInsertHelper() {
        return Mockito.mock(AssetInsertHelper.class);
    }

    public static VodAssetImageMapper createVodAssetImageMapper() {
        return Mockito.mock(VodAssetImageMapper.class);
    }

    public static Utils createUtils() {
        return Mockito.mock(Utils.class);
    }
}
