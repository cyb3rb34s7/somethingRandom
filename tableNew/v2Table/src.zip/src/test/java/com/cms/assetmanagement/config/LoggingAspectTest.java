package com.cms.assetmanagement.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class LoggingAspectTest {

    private LoggingAspect loggingAspect;

    @Mock
    private ProceedingJoinPoint joinPoint;

    @Mock
    private Signature signature;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        loggingAspect = new LoggingAspect();
    }

    @Test
    void loggingAspect_ShouldBeCreated() {
        // Then
        assertNotNull(loggingAspect);
    }

    @Test
    void logExecutionTime_ShouldLogExecutionTimeAndReturnResult() throws Throwable {
        // Given
        Object expectedResult = new Object();
        when(joinPoint.proceed()).thenReturn(expectedResult);
        when(joinPoint.getSignature()).thenReturn(signature);
        when(signature.toString()).thenReturn("testMethod()");

        // When
        Object result = loggingAspect.logExecutionTime(joinPoint);

        // Then
        assertEquals(expectedResult, result);
        verify(joinPoint).proceed();
        verify(joinPoint).getSignature();
    }

    @Test
    void logExecutionTime_ShouldHandleException() throws Throwable {
        // Given
        Throwable testException = new RuntimeException("Test exception");
        when(joinPoint.proceed()).thenThrow(testException);
        when(joinPoint.getSignature()).thenReturn(signature);
        when(signature.toString()).thenReturn("testMethod()");

        // When & Then
        assertThrows(RuntimeException.class, () -> loggingAspect.logExecutionTime(joinPoint));
        verify(joinPoint).proceed();
    }
}
