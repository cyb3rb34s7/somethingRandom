package com.cms.assetmanagement.service.impl;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.window_util.model.EventWindowDto;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.model.AdBreaksDto;
import com.cms.assetmanagement.model.AssetCastDto;
import com.cms.assetmanagement.model.AssetDrmDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetImageDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetLockedFieldDto;
import com.cms.assetmanagement.model.AssetRatingDto;
import com.cms.assetmanagement.model.ExternalProviderDto;
import com.cms.assetmanagement.model.GracenoteMapDto;
import com.cms.assetmanagement.model.ParentalRatingsDto;
import com.cms.assetmanagement.model.PlatformTagData;
import com.cms.assetmanagement.model.VodAssetDto;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Utility class to provide common test data objects. This helps to reduce code duplication in test
 * classes.
 */
public class TestDataProvider {

    public static VodAssetDto createBasicVodAssetDto() {
        return VodAssetDto.builder()
            .contentId("testContentId")
            .vcCpId("testVcCpId")
            .countryCode("US")
            .build();
    }

    public static VodAssetDto createFullVodAssetDto() {
        return VodAssetDto.builder()
            .contentId("testContentId")
            .vcCpId("testVcCpId")
            .countryCode("US")
            .type(Constants.EPISODE)
            .status("Active")
            .availableStarting("2023-01-01")
            .expiryDate("2024-01-01")
            .build();
    }

    public static List<AssetKeyDto> createAssetKeyList() {
        return List.of(
            AssetKeyDto.builder()
                .contentId("contentId1")
                .vcCpId("vcCpId1")
                .countryCode("US")
                .build(),
            AssetKeyDto.builder()
                .contentId("contentId2")
                .vcCpId("vcCpId2")
                .countryCode("US")
                .build()
        );
    }

    public static List<AssetDrmDto> createDrmDtoList() {
        return List.of(
            AssetDrmDto.builder().type("Widevine").build(),
            AssetDrmDto.builder().type("PlayReady").build()
        );
    }

    public static List<AssetExternalIdDto> createExternalIdDtoList() {
        return List.of(
            AssetExternalIdDto.builder().externalProgramId("extId1").build(),
            AssetExternalIdDto.builder().externalProgramId("extId2").build()
        );
    }

    public static List<AdBreaksDto> createAdBreaksDtoList() {
        return List.of(
            AdBreaksDto.builder().adBreakDurationSeconds(0.5).build(),
            AdBreaksDto.builder().adBreakDurationSeconds(0.2).build()
        );
    }

    public static List<PlatformTagData> createPlatformTagDataList() {
        return List.of(
            PlatformTagData.builder().platform("Platform1").build(),
            PlatformTagData.builder().platform("Platform2").build()
        );
    }

    public static List<AssetRatingDto> createAssetRatingDtoList() {
        return List.of(
            AssetRatingDto.builder().code("PG").build(),
            AssetRatingDto.builder().code("R").build()
        );
    }

    public static List<AssetCastDto> createAssetCastDtoList() {
        return List.of(
            AssetCastDto.builder().name("Actor1").role("Role1").build(),
            AssetCastDto.builder().name("Actor2").role("Role2").build()
        );
    }

    public static List<LicenseWindowDto> createLicenseWindowDtoList() {
        Instant now = Instant.now();
        return List.of(
            LicenseWindowDto.builder()
                .availableStarting(
                    DateTimeFormatter.ISO_INSTANT.format(now.minus(10, ChronoUnit.MINUTES)))
                .availableEnding(
                    DateTimeFormatter.ISO_INSTANT.format(now.plus(10, ChronoUnit.MINUTES)))
                .build(),
            LicenseWindowDto.builder()
                .availableStarting(
                    DateTimeFormatter.ISO_INSTANT.format(now.plus(5, ChronoUnit.MINUTES)))
                .availableEnding(
                    DateTimeFormatter.ISO_INSTANT.format(now.plus(15, ChronoUnit.MINUTES)))
                .build()
        );
    }

    public static List<EventWindowDto> createEventWindowDtoList() {
        Instant now = Instant.now();
        return List.of(
            EventWindowDto.builder()
                .eventStarting(
                    DateTimeFormatter.ISO_INSTANT.format(now.minus(5, ChronoUnit.MINUTES)))
                .eventEnding(DateTimeFormatter.ISO_INSTANT.format(now.plus(5, ChronoUnit.MINUTES)))
                .build(),
            EventWindowDto.builder()
                .eventStarting(
                    DateTimeFormatter.ISO_INSTANT.format(now.plus(10, ChronoUnit.MINUTES)))
                .eventEnding(DateTimeFormatter.ISO_INSTANT.format(now.plus(20, ChronoUnit.MINUTES)))
                .build()
        );
    }

    public static List<AssetImageDto> createAssetImageDtoList() {
        return List.of(
            AssetImageDto.builder().imageType("landscape").build(),
            AssetImageDto.builder().imageType("portrait").build()
        );
    }

    public static List<AssetLockedFieldDto> createAssetLockedFieldDtoList() {
        return List.of(
            AssetLockedFieldDto.builder().fieldName("title").build(),
            AssetLockedFieldDto.builder().fieldName("description").build()
        );
    }

    public static GracenoteMapDto createGracenoteMapDto() {
        return GracenoteMapDto.builder()
            .contentId("contentId")
            .vcCpId("vcCpId")
            .countryCode("US")
            .build();
    }

    public static List<ExternalProviderDto> createExternalProviderDtoList() {
        return List.of(
            ExternalProviderDto.builder().provider("Provider1").build(),
            ExternalProviderDto.builder().provider("Provider2").build()
        );
    }

    public static List<ParentalRatingsDto> createParentalRatingsDtoList() {
        return List.of(
            ParentalRatingsDto.builder().ratings("PG").build(),
            ParentalRatingsDto.builder().ratings("R").build()
        );
    }
}
