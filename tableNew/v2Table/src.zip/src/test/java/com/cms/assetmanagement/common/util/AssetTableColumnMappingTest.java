package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetTableColumnMappingTest {

    @Test
    void testInitializeTableBasicColumnMapping() {
        AssetTableColumnMapping assetTableColumnMapping = new AssetTableColumnMapping();
        Map<String, String> tableColumnMap = assetTableColumnMapping.initializeTableColumnMapping();

        assertEquals("ID", tableColumnMap.get("id"));
        assertEquals("CONTENT_ID", tableColumnMap.get("contentId"));
        assertEquals("CNTY_CD", tableColumnMap.get("countryCode"));
        assertEquals("VC_CP_ID", tableColumnMap.get("vcCpId"));
        assertEquals("TYPE", tableColumnMap.get("type"));
        assertEquals("MAIN_TITLE", tableColumnMap.get("mainTitle"));
        assertEquals("SHORT_TITLE", tableColumnMap.get("shortTitle"));
        assertEquals("RUNNING_TIME", tableColumnMap.get("runningTime"));
        assertEquals("GENRES", tableColumnMap.get("genres"));
        assertEquals("DIRECTOR", tableColumnMap.get("director"));
        assertEquals("STARRING", tableColumnMap.get("starring"));
        assertEquals("RATINGS", tableColumnMap.get("ratings"));
        assertEquals("DESCR", tableColumnMap.get("description"));
        assertEquals("EPISODE_NO", tableColumnMap.get("episodeNo"));
        assertEquals("SEASON_NO", tableColumnMap.get("seasonNo"));
        assertEquals("SEASON_ID", tableColumnMap.get("seasonId"));
        assertEquals("SHOW_ID", tableColumnMap.get("showId"));
        assertEquals("QUALITY", tableColumnMap.get("quality"));
        assertEquals("VC_SVC_ID", tableColumnMap.get("vcSvcId"));
        assertEquals("FILE_NAME", tableColumnMap.get("fileName"));
        assertEquals("DATAPLUS_YN", tableColumnMap.get("dataplusYn"));
        assertEquals("CONTENT_PARTNER", tableColumnMap.get("cpName"));
        assertEquals("ASSET_CURRENT_STATUS", tableColumnMap.get("status"));
        assertEquals("ADDED_FROM", tableColumnMap.get("addedFrom"));
        assertEquals("ARTIST", tableColumnMap.get("artist"));
    }

    @Test
    void testInitializeTableOtherColumnMapping() {
        AssetTableColumnMapping assetTableColumnMapping = new AssetTableColumnMapping();
        Map<String, String> tableColumnMap = assetTableColumnMapping.initializeTableColumnMapping();

        assertEquals("AUDIO_LANG", tableColumnMap.get("audioLang"));
        assertEquals("SUBTITLE_LANG", tableColumnMap.get("subtitleLang"));
        assertEquals("AUDIO_CD", tableColumnMap.get("audioCode"));
        assertEquals("SUBTITLE_CD", tableColumnMap.get("subtitleCode"));
        assertEquals("DEEPLINK_PAYLOAD", tableColumnMap.get("deeplinkPayload"));
        assertEquals("WEBVTT_URL", tableColumnMap.get("webVttUrl"));
        assertEquals("THUMBNAIL_URL", tableColumnMap.get("thumbnailUrl"));
        assertEquals("REL_DATE", tableColumnMap.get("releaseDate"));
        assertEquals("EXP_DATE", tableColumnMap.get("expiryDate"));
        assertEquals("REG_DT", tableColumnMap.get("regDate"));
        assertEquals("UPD_DT", tableColumnMap.get("updateDate"));
        assertEquals("REGR_ID", tableColumnMap.get("regrId"));
        assertEquals("CRCTR_ID", tableColumnMap.get("crctrId"));
        assertEquals("STREAM_URI", tableColumnMap.get("streamUri"));
        assertEquals("IMG_LANDSCAPE", tableColumnMap.get("imageLandscape"));
        assertEquals("IMG_PORTRAIT", tableColumnMap.get("imagePortrait"));
        assertEquals("IMG_CIRCLE", tableColumnMap.get("imageCircle"));
        assertEquals("IMG_LANDSCAPE_ORIGINAL", tableColumnMap.get("imageLandscapeOriginal"));
        assertEquals("IMG_PORTRAIT_ORIGINAL", tableColumnMap.get("imagePortraitOriginal"));
        assertEquals("IMG_CIRCLE_ORIGINAL", tableColumnMap.get("imageCircleOriginal"));
        assertEquals("PROCESSED_IMG_URL", tableColumnMap.get("processedImageUrl"));
        assertEquals("NON_AD_STREAM_URI", tableColumnMap.get("nonAdStreamUri"));
    }
}