package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.VodAssetDto;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class UtilsAdditionalTest {

    @InjectMocks
    Utils utils;

    HashMap<String, String> tableColumnMap = new HashMap<>();

    @Mock
    private AssetTableColumnMapping assetTableColumnMapping;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        tableColumnMap.put("mainTitle", "MAIN_TITLE");
        tableColumnMap.put("shortTitle", "SHORT_TITLE");
        tableColumnMap.put("contentId", "CONTENT_ID");
        when(assetTableColumnMapping.initializeTableColumnMapping()).thenReturn(tableColumnMap);
    }

    @Test
    void testGetHistoryColumnMap_InvalidColumn() {
        List<String> columns = List.of("invalidColumn");
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder()
            .columns(columns)
            .build();

        assertThrows(InvalidInputDataException.class, () -> utils.getHistoryColumnMap(reqDto));
    }

    @Test
    void testGetHistoryColumnMap_NullColumns() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder()
            .columns(null)
            .build();

        AssetByColumnsReqDto result = utils.getHistoryColumnMap(reqDto);

        assertNull(result.getColumns());
    }

    @Test
    void testGetHistoryColumnMap_EmptyColumns() {
        AssetByColumnsReqDto reqDto = AssetByColumnsReqDto.builder()
            .columns(new ArrayList<>())
            .build();

        AssetByColumnsReqDto result = utils.getHistoryColumnMap(reqDto);

        assertNotNull(result.getColumns());
        assertTrue(result.getColumns().isEmpty());
    }

    @Test
    void testCheckLiveOnDevice_UntrackableStatus() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Untrackable")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("Untrackable", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_ShowType() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD & STG")
            .type("SHOW")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("Yes", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_SeasonType() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD & STG")
            .type("SEASON")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("Yes", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_ActiveLicenseWindow() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD & STG")
            .type("MOVIE")
            .licenseWindow("Active")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("Yes", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_ExpiringLicenseWindow() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD & STG")
            .type("MOVIE")
            .licenseWindow("Expiring in 5 days")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("Yes", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_ExpiredLicenseWindow() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD")
            .type("MOVIE")
            .licenseWindow("Expired")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("No", result);
    }

    @Test
    void testCheckLiveOnDevice_ReleasedStatus_NullLicenseWindow() {
        VodAssetDto asset = VodAssetDto.builder()
            .status("Released")
            .dbStatus("PRD")
            .type("MOVIE")
            .build();

        String result = utils.checkLiveOnDevice(asset);

        assertEquals("No", result);
    }

    @Test
    void testIsTvplusDeltaFeedWorker_Match() {
        VodAssetDto asset = VodAssetDto.builder()
            .feedWorker("worker1")
            .build();

        utils.tvplusFeedWorkersList = List.of("worker1", "worker2");

        boolean result = utils.isTvplusDeltaFeedWorker(asset);

        assertTrue(result);
    }

    @Test
    void testIsTvplusDeltaFeedWorker_NoMatch() {
        VodAssetDto asset = VodAssetDto.builder()
            .feedWorker("worker3")
            .build();

        utils.tvplusFeedWorkersList = List.of("worker1", "worker2");

        boolean result = utils.isTvplusDeltaFeedWorker(asset);

        assertTrue(!result);
    }

    @Test
    void testCreateAssetList() {
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content123")
            .countryCode("US")
            .vcCpId("cp123")
            .build();

        List result = utils.createAssetList(asset);

        assertNotNull(result);
        assertEquals(1, result.size());
    }
}
