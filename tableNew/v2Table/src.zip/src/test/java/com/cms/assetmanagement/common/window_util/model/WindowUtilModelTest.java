package com.cms.assetmanagement.common.window_util.model;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = WindowUtilModelTest.class)
class WindowUtilModelTest {

    private static final String TEST_DATE = "2024-12-12 00:00:00";
    private static final String TEST_ID = "TEST_ID";

    @Test
    void eventWindowTest() {
        EventWindowDto eventWindowDto = EventWindowDto.builder().build();

        eventWindowDto.setWindowId(TEST_ID);
        eventWindowDto.setStartingTime(TEST_DATE);
        eventWindowDto.setEndingTime(TEST_DATE);

        assertEquals(TEST_DATE, eventWindowDto.getStartingTime());
        assertEquals(TEST_DATE, eventWindowDto.getEndingTime());
        assertEquals(TEST_ID, eventWindowDto.getWindowId());
    }

    @Test
    void licenseWindowTest() {
        LicenseWindowDto licenseWindowDto = LicenseWindowDto.builder().build();

        licenseWindowDto.setWindowId(TEST_ID);
        licenseWindowDto.setStartingTime(TEST_DATE);
        licenseWindowDto.setEndingTime(TEST_DATE);

        assertEquals(TEST_DATE, licenseWindowDto.getStartingTime());
        assertEquals(TEST_DATE, licenseWindowDto.getEndingTime());
        assertEquals(TEST_ID, licenseWindowDto.getWindowId());
    }
}
