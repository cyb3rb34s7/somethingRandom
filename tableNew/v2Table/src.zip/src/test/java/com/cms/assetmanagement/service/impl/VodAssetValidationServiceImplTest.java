package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.ValidateWindowDto;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class VodAssetValidationServiceImplTest extends BaseVodAssetServiceTest {

    @Test
    void validateAssetDetails_Episode_success() {
        EditValidationDto editValidation = EditValidationDto.builder().assetType("EPISODE").build();

        when(vodAssetMapper.validateShow(editValidation)).thenReturn(true);
        when(vodAssetMapper.validateSeasonForEpisode(editValidation)).thenReturn(true);
        when(vodAssetMapper.validateEpisode(editValidation)).thenReturn(true);

        assertTrue(vodAssetValidationService.validateAssetDetails(editValidation));
    }

    @Test
    void validateAssetDetails_Season_success() {
        EditValidationDto editValidation = EditValidationDto.builder().assetType("SEASON").build();

        when(vodAssetMapper.validateShow(editValidation)).thenReturn(true);
        when(vodAssetMapper.validateSeasonNo(editValidation)).thenReturn(true);

        assertTrue(vodAssetValidationService.validateAssetDetails(editValidation));
    }


    @Test
    void validateAssetDetails_NullInput() {
        assertTrue(vodAssetValidationService.validateAssetDetails(null));
    }

    @Test
    void validateBulkQCPass_True_success() {
        List<AssetKeyDto> assetList = List.of(
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId1")
                .type("EPISODE").showId("showId1").seasonId("seasonId1").build(),
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId2")
                .type("SEASON").showId("showId1").build()
        );
        when(vodAssetMapper.getCountOfValidatedParents(Mockito.anyList())).thenReturn(2L);

        assertTrue(vodAssetValidationService.validateBulkQCPass(assetList));
    }

    @Test
    void validateBulkQCPass_False_EpisodeMissingParentIds() {
        List<AssetKeyDto> assetList = List.of(
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId1")
                .type("EPISODE").build()  // Missing showId and seasonId
        );

        assertFalse(vodAssetValidationService.validateBulkQCPass(assetList));
    }

    @Test
    void validateBulkQCPass_False_SeasonMissingParentIds() {
        List<AssetKeyDto> assetList = List.of(
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId1")
                .type("SEASON").build()  // Missing showId
        );

        assertFalse(vodAssetValidationService.validateBulkQCPass(assetList));
    }

    @Test
    void validateBulkQCPass_False_ParentCountMismatch() {
        List<AssetKeyDto> assetList = List.of(
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId1")
                .type("EPISODE").showId("showId1").seasonId("seasonId1").build(),
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId2")
                .type("SEASON").showId("showId1").build()
        );
        when(vodAssetMapper.getCountOfValidatedParents(Mockito.anyList())).thenReturn(
            1L); // Less than expected

        assertFalse(vodAssetValidationService.validateBulkQCPass(assetList));
    }

    @Test
    void validateExternalId_success() {
        List<AssetExternalIdDto> externalIdDtoList = List.of(AssetExternalIdDto.builder().build());

        List<String> expectedDetails = List.of("invalidId1", "invalidId2");

        when(vodAssetMapper.validateExternalId(externalIdDtoList)).thenReturn(expectedDetails);
        assertEquals(expectedDetails,
            vodAssetValidationService.validateExternalId(externalIdDtoList));
    }

    @Test
    void validateLicenseWindowTest_DoesNotExist() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(false);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertFalse(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_NullCase() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(false);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(null,
            "PRO_ID", "CP_ID", "AA", true);

        assertTrue(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_DuplicateLicenseIdsWithMerge() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of("1", "2"));

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertFalse(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_WindowWithMergeInvalid() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of());

        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(false);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertFalse(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_InvalidDateException() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of());

        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);

        Mockito.doThrow(new RuntimeException("Test")).when(dateRangeWindowService)
            .addTzToTimestamps(Mockito.any());

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertFalse(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_ValidationFail() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of());

        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);

        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.any()))
            .thenReturn(false);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertFalse(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_ValidationSuccess() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of());

        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);

        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.any()))
            .thenReturn(true);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(LicenseWindowDto.builder().build()),
            "PRO_ID", "CP_ID", "AA", true);

        assertTrue(actualResponse.getIsValid());
    }

    @Test
    void validateLicenseWindowTest_ValidationSuccess_ShouldNotMerge() {
        Mockito.when(vodAssetMapper.doesAssetExists(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(true);

        Mockito.when(dateRangeWindowService.getDuplicateLicenseIds(Mockito.any()))
            .thenReturn(List.of());

        Mockito.when(dateRangeWindowService.areWindowsValid(Mockito.any())).thenReturn(true);

        Mockito.when(dateRangeWindowService.areWindowsNonOverlapping(Mockito.any()))
            .thenReturn(true);

        ValidateWindowDto actualResponse = vodAssetValidationService.validateDateRangeWindow(
            List.of(),
            "PRO_ID", "CP_ID", "AA", false);

        assertTrue(actualResponse.getIsValid());
    }
}
