package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.assetmanagement.common.DevConsoleConstants;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = DevConsoleUtilTest.class)
class DevConsoleUtilTest {

    @InjectMocks
    private DevConsoleUtil devConsoleUtil;

    @Test
    void testParseFeedWorkerWithNullInput() {
        String result = devConsoleUtil.parseFeedWorker(null);
        assertEquals("ALL", result);
    }

    @Test
    void testParseFeedWorkerWithValidInput() {
        String validFeedWorker = "cms";
        String result = devConsoleUtil.parseFeedWorker(validFeedWorker);
        assertEquals(validFeedWorker.toUpperCase(), result);
    }

    @Test
    void testParseFeedWorkerWithInvalidInput() {
        String invalidFeedWorker = "invalid_worker";
        assertThrows(InvalidInputDataException.class,
            () -> devConsoleUtil.parseFeedWorker(invalidFeedWorker));
    }

    @Test
    void testParseFeedWorkerWithValidUpperCaseInput() {
        String validUpperCaseFeedWorker = "TVPLUS";
        String result = devConsoleUtil.parseFeedWorker(validUpperCaseFeedWorker);
        assertEquals(validUpperCaseFeedWorker, result);
    }

    @Test
    void testParseFeedWorkerWithValidLowerCaseInput() {
        String validLowerCaseFeedWorker = "tvplus";
        String result = devConsoleUtil.parseFeedWorker(validLowerCaseFeedWorker);
        assertEquals(validLowerCaseFeedWorker.toUpperCase(), result);
    }

    @Test
    void testIsValidFeedWorkerWithValidFeedWorker() {
        assertTrue(devConsoleUtil.isValidFeedWorker(DevConsoleConstants.CMS_FEED_WORKER));
        assertTrue(devConsoleUtil.isValidFeedWorker(DevConsoleConstants.TVPLUS_FEED_WORKER));
    }

    @Test
    void testIsValidFeedWorkerWithInvalidFeedWorker() {
        assertFalse(devConsoleUtil.isValidFeedWorker("invalid_feed_worker"));
        assertFalse(devConsoleUtil.isValidFeedWorker("BOMBAY"));
    }
}
