package com.cms.assetmanagement.common.enums;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AssetImageTypeTest {

    @Test
    void enumValues_ShouldHaveCorrectValues() {
        // Then
        assertEquals("landscape_banner", AssetImageType.LANDSCAPE_BANNER.value);
        assertEquals("portrait_banner", AssetImageType.PORTRAIT_BANNER.value);
        assertEquals("landscape_iconic", AssetImageType.LANDSCAPE_ICONIC.value);
        assertEquals("portrait_iconic", AssetImageType.PORTRAIT_ICONIC.value);
        assertEquals("title_treatment", AssetImageType.TITLE_TREATMENT.value);
        assertEquals("landscape_backdrop", AssetImageType.LANDSCAPE_BACKDROP.value);
    }

    @Test
    void enumValues_ShouldHaveCorrectNumberOfValues() {
        // When
        AssetImageType[] values = AssetImageType.values();

        // Then
        assertEquals(7, values.length);
    }

    @Test
    void enumValueOf_ShouldReturnCorrectEnum() {
        // When & Then
        assertEquals(AssetImageType.LANDSCAPE_BANNER, AssetImageType.valueOf("LANDSCAPE_BANNER"));
        assertEquals(AssetImageType.PORTRAIT_BANNER, AssetImageType.valueOf("PORTRAIT_BANNER"));
        assertEquals(AssetImageType.LANDSCAPE_ICONIC, AssetImageType.valueOf("LANDSCAPE_ICONIC"));
        assertEquals(AssetImageType.PORTRAIT_ICONIC, AssetImageType.valueOf("PORTRAIT_ICONIC"));
        assertEquals(AssetImageType.TITLE_TREATMENT, AssetImageType.valueOf("TITLE_TREATMENT"));
        assertEquals(AssetImageType.LANDSCAPE_BACKDROP,
            AssetImageType.valueOf("LANDSCAPE_BACKDROP"));
    }
}
