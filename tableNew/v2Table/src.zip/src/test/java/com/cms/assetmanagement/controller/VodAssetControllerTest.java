package com.cms.assetmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.ResponseHandler;
import com.cms.assetmanagement.common.window_util.model.LicenseWindowDto;
import com.cms.assetmanagement.common.window_util.service.DateRangeWindowService;
import com.cms.assetmanagement.exception.DatabaseException;
import com.cms.assetmanagement.model.AssetByColumnsReqDto;
import com.cms.assetmanagement.model.AssetCountDto;
import com.cms.assetmanagement.model.AssetDrmReqDto;
import com.cms.assetmanagement.model.AssetExternalIdDto;
import com.cms.assetmanagement.model.AssetExternalIdReqDto;
import com.cms.assetmanagement.model.AssetKeyDto;
import com.cms.assetmanagement.model.AssetKeyListDto;
import com.cms.assetmanagement.model.AssetStatusUpdateDto;
import com.cms.assetmanagement.model.AssetUpdateByBulkDto;
import com.cms.assetmanagement.model.BulkRevokeHierarchy;
import com.cms.assetmanagement.model.CountryDto;
import com.cms.assetmanagement.model.EditValidationDto;
import com.cms.assetmanagement.model.EpisodeHierarchyDto;
import com.cms.assetmanagement.model.EventDeleteDto;
import com.cms.assetmanagement.model.LanguageDto;
import com.cms.assetmanagement.model.RatingsDto;
import com.cms.assetmanagement.model.ResponseDto;
import com.cms.assetmanagement.model.ShowHierarchyDto;
import com.cms.assetmanagement.model.ValidateWindowDto;
import com.cms.assetmanagement.model.VodAssetDetailedDto;
import com.cms.assetmanagement.model.VodAssetDto;
import com.cms.assetmanagement.model.VodAssetStatusDto;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.AssetViewFilterDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.service.SchemaValidatorService;
import com.cms.assetmanagement.service.VodAssetService;
import com.cms.assetmanagement.service.VodAssetUpdateService;
import com.cms.assetmanagement.service.VodAssetValidationService;
import com.cms.assetmanagement.service.VodAssetViewService;
import com.cms.assetmanagement.service.VodAssetWindowService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VodAssetControllerTest {

    @InjectMocks
    private VodAssetController vodAssetController;
    @Mock
    private VodAssetService vodAssetService;
    @Mock
    private VodAssetUpdateService vodAssetUpdateService;
    @Mock
    private VodAssetViewService vodAssetViewService;
    @Mock
    private VodAssetValidationService vodAssetValidationService;
    @Mock
    private DateRangeWindowService dateRangeWindowService;
    @Mock
    private SchemaValidatorService schemaValidatorService;
    @Mock
    private VodAssetWindowService vodAssetWindowService;

    @Test
    void getAssetList_success() {
        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto();
        List<VodAssetDto> expectedAssets = List.of(new VodAssetDto());
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        when(vodAssetService.getFilteredAssets(assetFilterBodyDto)).thenReturn(expectedAssets);

        // Act
        ResponseDto actualResponse = vodAssetController.getFilteredAssetsList(assetFilterBodyDto);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getFilteredAssets(assetFilterBodyDto);
    }

    @Test
    void getAssetCount_success() {
        String tab = "all";
        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto();
        AssetCountDto expectedAssetCount = AssetCountDto.builder().build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSET_COUNT,
            expectedAssetCount);

        when(vodAssetService.getFilteredAssetsCount(assetFilterBodyDto, tab)).thenReturn(
            expectedAssetCount);

        // Act
        ResponseDto actualResponse = vodAssetController.getFilteredAssetsCount(assetFilterBodyDto,
            tab);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getFilteredAssetsCount(assetFilterBodyDto, tab);
    }

    @Test
    void getAssetsForExport_success() {
        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto();
        List<VodAssetDto> expectedAssets = List.of(new VodAssetDto());
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        when(vodAssetService.getAssetsForExport(assetFilterBodyDto)).thenReturn(expectedAssets);

        // Act
        ResponseDto actualResponse = vodAssetController.getAssetsForExport(assetFilterBodyDto);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getAssetsForExport(assetFilterBodyDto);
    }

    @Test
    void getExportAssetCount_success() {
        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSET_COUNT,
            0L);

        when(vodAssetService.getExportAssetCount(assetFilterBodyDto)).thenReturn(
            0L);

        // Act
        ResponseDto actualResponse = vodAssetController.getExportAssetCount(assetFilterBodyDto);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getExportAssetCount(assetFilterBodyDto);
    }

    @Test
    void getView_success() {
        // Given
        String contentId = "1234567890";
        String cpId = "";
        String countryCode = "US";

        VodAssetDto expectedAssets = new VodAssetDto();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        when(vodAssetViewService.getAssetView(contentId, cpId, countryCode)).thenReturn(
            expectedAssets);

        // Act
        ResponseDto actualResponse = vodAssetController.getAssetView(contentId, cpId, countryCode);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetViewService, times(1)).getAssetView(contentId, cpId, countryCode);
    }

    @Test
    void getAssetCPView_success() {
        // Given
        String contentId = "1234567890";
        String cpId = "";
        String countryCode = "US";

        VodAssetDto expectedAssets = new VodAssetDto();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        when(vodAssetViewService.getAssetCPView(contentId, cpId, countryCode)).thenReturn(
            expectedAssets);

        // Act
        ResponseDto actualResponse = vodAssetController.getAssetCPView(contentId, cpId,
            countryCode);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetViewService, times(1)).getAssetCPView(contentId, cpId, countryCode);
    }

    @Test
    void getAssetGracenoteView_success() {
        // Given
        String contentId = "1234567890";
        String cpId = "";
        String countryCode = "US";

        VodAssetDto expectedAssets = new VodAssetDto();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        when(vodAssetViewService.getAssetGracenoteView(contentId, cpId, countryCode)).thenReturn(
            expectedAssets);

        // Act
        ResponseDto actualResponse = vodAssetController.getAssetGracenoteView(contentId, cpId,
            countryCode);

        // Assert
        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetViewService, times(1)).getAssetGracenoteView(contentId, cpId, countryCode);
    }

    @Test
    void getInsert_success() throws JsonProcessingException {

        VodAssetDto asset = VodAssetDto.builder().contentId("contentId").vcCpId("vcCpId")
            .countryCode("AA").build();

        Mockito.doNothing().when(vodAssetUpdateService).insertAsset(any(VodAssetDto.class));

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_INSERT_SUCCESS);

        ResponseDto actualResponse = vodAssetController.insertAsset(asset);

        assertEquals(expectedResponse, actualResponse);
        // Verify that the service method was called with the correct parameters
        verify(vodAssetUpdateService).insertAsset(asset);
    }

    @Test
    void getFilter_success() {
        List<FilterDto> filterDtos = new ArrayList<>();
        FilterDto filterDto1 = new FilterDto();
        filterDtos.add(filterDto1);

        FilterDto filterDto2 = new FilterDto();
        filterDtos.add(filterDto2);

        when(vodAssetService.getFilters()).thenReturn(filterDtos);

        ResponseDto responseDto = vodAssetController.getFilters();
        assertEquals(Constants.STATUS_OK, responseDto.getRsp().getStat());
    }

    @Test
    void update_status_success() {
        AssetStatusUpdateDto status = new AssetStatusUpdateDto();

        Mockito.doNothing().when(vodAssetUpdateService).updateAssetStatus(status);
        ResponseDto response = vodAssetController.updateAssetStatus(status);

        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
    }

    @Test
    void updateAsset_success() throws JsonProcessingException {

        VodAssetDto asset = VodAssetDto.builder().build();

        Mockito.doNothing().when(vodAssetUpdateService).updateAsset(asset);

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_UPDATE_SUCCESS);

        ResponseDto actualResponse = vodAssetController.updateAsset(asset);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetUpdateService, times(1)).updateAsset(asset);
    }

    @Test
    void getAssetDetails_success() {
        String contentId = "contentId123";
        String cpId = "cp1";
        String countryCode = "US";

        VodAssetDetailedDto expectedAssets = VodAssetDetailedDto.builder().build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(
            Constants.ASSET_DETAILS,
            expectedAssets);

        when(vodAssetService.getAssetDetails(contentId, cpId, countryCode)).thenReturn(
            expectedAssets);

        ResponseDto actualResponse = vodAssetController.getAssetDetails(contentId, cpId,
            countryCode);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getAssetDetails(contentId, cpId, countryCode);
    }

    @Test
    void insertAssetDetails_success() throws JsonProcessingException {
        VodAssetDetailedDto assetDetails = VodAssetDetailedDto.builder().vodAsset(
            VodAssetDto.builder().contentId("TEST").countryCode("AA").vcCpId("TEST")
                .feedWorker("CMS").type("MOVIE").build()).build();

        Mockito.doNothing().when(vodAssetUpdateService).insertAssetDetails(assetDetails);

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_INSERT_SUCCESS);

        ResponseDto actualResponse = vodAssetController.insertAssetDetails(assetDetails);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetUpdateService, times(1)).insertAssetDetails(assetDetails);

    }

    @Test
    void updateAssetDetails_success() throws JsonProcessingException {
        VodAssetDetailedDto asset = VodAssetDetailedDto.builder().vodAsset(
            VodAssetDto.builder().contentId("TEST").countryCode("AA").vcCpId("TEST")
                .feedWorker("CMS").type("MOVIE").build()).build();

        Mockito.doNothing().when(vodAssetUpdateService).updateAssetDetails(asset);

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_UPDATE_SUCCESS);

        ResponseDto actualResponse = vodAssetController.updateAssetDetails(asset);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetUpdateService, times(1)).updateAssetDetails(asset);
    }

    @Test
    void getCountryCodes_success() {
        List<CountryDto> countryCodeList = List.of(
            CountryDto.builder().countryCode("IN").countryName("India").build(),
            CountryDto.builder().countryCode("US").countryName("United States of America").build());

        when(vodAssetService.getCountryCodes()).thenReturn(countryCodeList);

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.COUNTRY,
            countryCodeList);

        ResponseDto actualResponse = vodAssetController.getCountryCodes();

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetService, times(1)).getCountryCodes();
    }

    @Test
    void getAssetListDetailsForUpload_success() {
        AssetKeyListDto assetKeyList = AssetKeyListDto.builder().assetList(
            List.of(AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build(),
                AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build())
        ).build();

        List<VodAssetStatusDto> vodAssetStatusDtosList = new ArrayList<>();
        when(vodAssetService.getAssetListDetailsforUpload(assetKeyList)).thenReturn(
            vodAssetStatusDtosList);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            vodAssetStatusDtosList);

        ResponseDto actualResponse = vodAssetController.getAssetListDetailsforUpload(assetKeyList);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetService, times(1)).getAssetListDetailsforUpload(assetKeyList);
    }

    @Test
    void insertExternalIdData_success() {
        AssetExternalIdReqDto externalIdReq = AssetExternalIdReqDto.builder()
            .assetExternalIds(List.of()).build();
        Mockito.doNothing().when(vodAssetUpdateService)
            .insertExternalIdData(externalIdReq.getAssetExternalIds());

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.EXTERNALID_INSERT_SUCCESS);

        ResponseDto actualResponse = vodAssetController.insertExternalIdData(externalIdReq);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetUpdateService, times(1)).insertExternalIdData(
            externalIdReq.getAssetExternalIds());

    }

    @Test
    void insertDRMData_success() {
        AssetDrmReqDto drm = AssetDrmReqDto.builder().assetDrmList(List.of()).build();
        Mockito.doNothing().when(vodAssetUpdateService).insertDRMData(drm.getAssetDrmList());

        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.DRM_INSERT_SUCCESS);

        ResponseDto actualResponse = vodAssetController.insertDRMData(drm);

        assertEquals(expectedResponse, actualResponse);
        verify(vodAssetUpdateService, times(1)).insertDRMData(drm.getAssetDrmList());
    }

    @Test
    void deleteAsset_success() {
        AssetKeyListDto assetKeyList = AssetKeyListDto.builder().assetList(
            List.of(AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build(),
                AssetKeyDto.builder().countryCode("US").vcCpId("CP1").contentId("contentId1")
                    .build())
        ).build();
        doNothing().when(vodAssetUpdateService).deleteAsset(assetKeyList);

        vodAssetController.deleteAsset(assetKeyList);

        verify(vodAssetUpdateService, times(1)).deleteAsset(assetKeyList);
    }

    @Test
    void softDeleteAsset_success() {
        String contentId = "contentId";
        String countryCode = "countryCode";
        String cpId = "vcCpId";
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSET_DELETE_SUCCESS);

        doNothing().when(vodAssetUpdateService)
            .softDeleteAsset(Mockito.any(String.class), Mockito.any(String.class),
                Mockito.any(String.class));

        // Act
        ResponseDto actualResponse = vodAssetController.softDeleteAsset(contentId, countryCode,
            cpId);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void getShowHierarchy_success() {
        AssetKeyDto assetKey = AssetKeyDto.builder().countryCode("AA").vcCpId("BB").showId("showId")
            .contentId("contentId").seasonId("seasonId").type("type").build();

        List<ShowHierarchyDto> expectedShowHierarchy = new ArrayList<>();

        when(vodAssetService.getShowHierarchy(assetKey)).thenReturn(
            expectedShowHierarchy);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedShowHierarchy);

        ResponseDto actualResponse = vodAssetController.getShowHierarchy(assetKey);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetService, times(1)).getShowHierarchy(assetKey);
    }

    @Test
    void updateAssetByBulk_success() throws JsonProcessingException {
        AssetUpdateByBulkDto assetBulk = AssetUpdateByBulkDto.builder().
            contentIds(new ArrayList<>()).vodAssetDto(new VodAssetDto())
            .build();
        doNothing().when(vodAssetUpdateService).updateAssetByBulk(assetBulk);

        vodAssetController.updateAssetByBulk(assetBulk);

        verify(vodAssetUpdateService, times(1)).updateAssetByBulk(assetBulk);
    }

    @Test
    void bulkUpdateAssets_success() throws JsonProcessingException {
        List<VodAssetDto> updatedAssets = new ArrayList<>();
        doNothing().when(vodAssetUpdateService).bulkUpdateAssets(updatedAssets);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.SUCCESS,
            Constants.ASSETS_UPDATED_SUCCESSFULLY);

        ResponseDto actualResponse = vodAssetController.bulkUpdateAssets(updatedAssets);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetUpdateService, times(1)).bulkUpdateAssets(updatedAssets);
    }

    @Test
    void getLanguages_success() {
        List<LanguageDto> languagesData = new ArrayList<>();
        when(vodAssetService.getLanguages()).thenReturn(
            languagesData);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.LANGUAGES,
            languagesData);

        ResponseDto actualResponse = vodAssetController.getLanguages();

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetService, times(1)).getLanguages();
    }

    @Test
    void getRatings_success() {
        List<RatingsDto> ratingsData = new ArrayList<>();
        when(vodAssetService.getRatings()).thenReturn(
            ratingsData);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.RATINGS,
            ratingsData);

        ResponseDto actualResponse = vodAssetController.getRatings();

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetService, times(1)).getRatings();
    }

    @Test
    void getViewFilters_success() {
        AssetKeyDto assetKey = AssetKeyDto.builder().countryCode("AA").vcCpId("BB").showId("showId")
            .contentId("contentId").seasonId("seasonId").type("type").build();

        AssetViewFilterDto expectedFilters = AssetViewFilterDto.builder().build();

        when(vodAssetViewService.getViewFilters(assetKey)).thenReturn(
            expectedFilters);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.FILTERS,
            expectedFilters);

        ResponseDto actualResponse = vodAssetController.getViewFilters(assetKey);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetViewService, times(1)).getViewFilters(assetKey);
    }

    @Test
    void getViewEpisodeHierarchy_success() {
        AssetKeyDto assetKey = AssetKeyDto.builder().countryCode("AA").vcCpId("BB").showId("showId")
            .contentId("contentId").seasonId("seasonId").type("type").build();

        EpisodeHierarchyDto expectedHierarchy = EpisodeHierarchyDto.builder().build();

        when(vodAssetViewService.getViewEpisodeHierarchy(assetKey)).thenReturn(
            expectedHierarchy);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedHierarchy);

        ResponseDto actualResponse = vodAssetController.getViewEpisodeHierarchy(assetKey);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetViewService, times(1)).getViewEpisodeHierarchy(assetKey);
    }

    @Test
    void assetDetailsByColumn_success() {
        AssetByColumnsReqDto assetKey = AssetByColumnsReqDto.builder().columns(new ArrayList<>())
            .assetList(new ArrayList<>()).build();

        List<VodAssetDto> expectedAssets = new ArrayList<>();

        when(vodAssetService.assetDetailsByColumns(assetKey)).thenReturn(
            expectedAssets);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.ASSETS,
            expectedAssets);

        ResponseDto actualResponse = vodAssetController.assetDetailsByColumn(assetKey);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetService, times(1)).assetDetailsByColumns(assetKey);
    }

    @Test
    void validateProviderByCountry_success() throws SQLException {
        String countryCode = "US";
        String cp = "cp";

        when(schemaValidatorService.validateProviderAndCountry(countryCode, cp)).thenReturn(
            true);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(
            Constants.ASSET_DETAILS, true);

        ResponseDto actualResponse = vodAssetController.validateProviderByCountry(countryCode, cp);

        assertEquals(expectedResult, actualResponse);

        verify(schemaValidatorService, times(1)).validateProviderAndCountry(countryCode, cp);
    }

    @Test
    void validateDeltaSync_success() throws SQLException {
        String contentId = "contentId";
        String countryCode = "countryCode";
        String cpId = "vcCpId";
        String eventType = "TVPLUS_DELTA";
        when(vodAssetValidationService.validateDeltaSync(Mockito.any(String.class),
            Mockito.any(String.class),
            Mockito.any(String.class), Mockito.any(String.class))).thenReturn(true);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(Constants.ASSET_DETAILS,
            true);

        ResponseDto actualResponse = vodAssetController.validateDeltaSync(contentId, countryCode,
            cpId, eventType);

        assertEquals(expectedResult, actualResponse);
    }

    @Test
    void validateExternalId_success() throws SQLException {
        List<AssetExternalIdDto> externalIds = new ArrayList<>();

        List<String> expectedIds = new ArrayList<>();

        when(vodAssetValidationService.validateExternalId(externalIds)).thenReturn(
            expectedIds);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(
            Constants.EXTERNAL_ID_STR,
            expectedIds);

        ResponseDto actualResponse = vodAssetController.validateExternalId(externalIds);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetValidationService, times(1)).validateExternalId(externalIds);
    }

    @Test
    void validateAssetDetails_success() throws SQLException {
        EditValidationDto editValidationDto = EditValidationDto.builder().build();

        boolean expectedValidation = true;

        when(vodAssetValidationService.validateAssetDetails(editValidationDto)).thenReturn(
            expectedValidation);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(
            Constants.VALIDATION,
            expectedValidation);

        ResponseDto actualResponse = vodAssetController.validateAssetDetails(editValidationDto);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetValidationService, times(1)).validateAssetDetails(editValidationDto);
    }

    @Test
    void validateBulkQCPass_success() {
        List<AssetKeyDto> assetList = List.of(
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP1").contentId("contentId1")
                .type("EPISODE").build(),
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP2").contentId("contentId2")
                .type("SEASON").build(),
            AssetKeyDto.builder().countryCode("AA").vcCpId("CP3").contentId("contentId3")
                .type("MOVIE").build()
        );

        boolean expectedValidation = true;

        when(vodAssetValidationService.validateBulkQCPass(assetList)).thenReturn(
            expectedValidation);

        ResponseDto expectedResult = ResponseHandler.processMethodResponse(
            Constants.VALIDATION,
            expectedValidation);

        ResponseDto actualResponse = vodAssetController.validateBulkQCPass(assetList);

        assertEquals(expectedResult, actualResponse);

        verify(vodAssetValidationService, times(1)).validateBulkQCPass(assetList);
    }

    @Test
    void getAllRatingsTest() {
        Mockito.when(vodAssetService.getAllRatings()).thenReturn(List.of());

        assertDoesNotThrow(() -> vodAssetController.getAllRatings());
    }

    @Test
    void getAllRatingsTest_Exception() {
        Mockito.when(vodAssetService.getAllRatings()).thenThrow(new DatabaseException("TEST"));

        assertThrows(DatabaseException.class, () -> vodAssetController.getAllRatings());
    }

    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    void updateLicenseWindowTest(boolean wasActiveSlotFound) {
        Mockito.when(
            dateRangeWindowService.findAndUpdateLicenseActiveSlot(Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyString(), Mockito.anyList())).thenReturn(wasActiveSlotFound);

        List<LicenseWindowDto> windows = List.of(
            LicenseWindowDto.builder().availableStarting("START").availableEnding("end").build());

        assertDoesNotThrow(
            () -> vodAssetController.updateLicenseWindow(windows, "AA", "ID", "CP_ID"));
    }

    @Test
    void getActiveWindowTest() {
        assertDoesNotThrow(() -> vodAssetController.getActiveWindow(List.of()));
    }

    @Test
    void validateLicenseWindow() {
        assertDoesNotThrow(
            () -> vodAssetController.validateLicenseWindow(List.of(), "AA", "TEST_ID", "CP_ID",
                true));
    }

    @Test
    void validateLicenseWindow_ShouldNotMerge() {
        assertDoesNotThrow(
            () -> vodAssetController.validateLicenseWindow(List.of(), "AA", "TEST_ID", "CP_ID",
                false));
    }

    @Test
    void removeEventWindowsTest() {
        assertDoesNotThrow(() -> vodAssetController.removeEventWindows(EventDeleteDto.builder()
            .build()));
    }

    @Test
    void getStreamUrisTest() {
        Mockito.when(vodAssetService.getStreamUris(Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(List.of());

        assertDoesNotThrow(() -> vodAssetController.getStreamUris("TEST", "TEST", "TEST"));
    }

    @Test
    void validateEventWindowTest() {
        ValidateWindowDto validateWindowDto = ValidateWindowDto.builder().build();
        Mockito.when(vodAssetValidationService.validateDateRangeWindow(Mockito.anyList(),
                Mockito.anyString(),
                Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean()))
            .thenReturn(validateWindowDto);

        assertDoesNotThrow(
            () -> vodAssetController.validateEventWindow(List.of(), "TEST", "TEST", "TEST", true));
    }

    @Test
    void updateCPAssetTest() {
        assertDoesNotThrow(() -> vodAssetController.updateCPAsset(VodAssetDto.builder().build()));
    }

    @Test
    void validateJsonTest() throws JsonProcessingException, SQLException {
        JsonNode jsonNode = new ObjectMapper().readTree("\"TEST\"");
        Mockito.when(schemaValidatorService.validateAsset(Mockito.any(), Mockito.anyString(),
            Mockito.anyString())).thenReturn(new HashMap<>());

        assertDoesNotThrow(() -> vodAssetController.validateJson(jsonNode, "TEST", "TEST"));
    }

    @Test
    void validateMediaJsonTest() throws JsonProcessingException, SQLException {
        JsonNode jsonNode = new ObjectMapper().readTree("\"TEST\"");
        Mockito.when(schemaValidatorService.validateMedia(Mockito.any(), Mockito.anyString(),
            Mockito.anyString(), Mockito.anyString())).thenReturn(new HashMap<>());

        assertDoesNotThrow(
            () -> vodAssetController.validateMediaJson(jsonNode, "TEST", "TEST", "TEST"));
    }

    @Test
    void bulkRevokeHierarchyTest() {
        Mockito.when(vodAssetService.bulkRevokeHierarchy(Mockito.anyList())).thenReturn(
            BulkRevokeHierarchy.builder().build());

        assertDoesNotThrow(() -> vodAssetController.bulkRevokeHierarchy(List.of()));
    }

    @Test
    void validateExternalIdPerIdTypeTest() {
        Mockito.when(schemaValidatorService.validateExternalIdPerIdType(Mockito.anyList()))
            .thenReturn(Constants.VALID);

        assertDoesNotThrow(() -> vodAssetController.validateExternalIdPerIdType(List.of()));

        Mockito.when(schemaValidatorService.validateExternalIdPerIdType(Mockito.anyList()))
            .thenReturn(Constants.INVALID);

        assertDoesNotThrow(() -> vodAssetController.validateExternalIdPerIdType(List.of()));
    }
}
