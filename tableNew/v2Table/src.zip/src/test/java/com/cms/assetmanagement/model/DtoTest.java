package com.cms.assetmanagement.model;

import com.cms.assetmanagement.common.util.ModelDtoTestUtility;
import com.cms.assetmanagement.model.filter.AssetFilterBodyDto;
import com.cms.assetmanagement.model.filter.AssetViewFilterDto;
import com.cms.assetmanagement.model.filter.ContentKeyDto;
import com.cms.assetmanagement.model.filter.ContentProviderDto;
import com.cms.assetmanagement.model.filter.CountryLangCodeDto;
import com.cms.assetmanagement.model.filter.FilterDto;
import com.cms.assetmanagement.model.filter.PaginationDto;
import com.cms.assetmanagement.model.filter.ParentalRatingsDto;
import com.cms.assetmanagement.model.filter.SortDto;
import com.cms.assetmanagement.model.imageprocessing.PreProcessImageDto;
import com.cms.assetmanagement.model.imageprocessing.ProcessedImageDto;
import com.cms.assetmanagement.model.media.MediaAssetDto;
import com.cms.assetmanagement.model.smf.AssetAdBreakDto;
import com.cms.assetmanagement.model.smf.AssetCastDto;
import com.cms.assetmanagement.model.smf.AssetCountryCpLangDto;
import com.cms.assetmanagement.model.smf.AssetDescriptionDto;
import com.cms.assetmanagement.model.smf.AssetDto;
import com.cms.assetmanagement.model.smf.AssetImageDto;
import com.cms.assetmanagement.model.smf.AssetParentalRatingDto;
import com.cms.assetmanagement.model.smf.AssetPlaybackDto;
import com.cms.assetmanagement.model.smf.AssetSeriesInfo;
import com.cms.assetmanagement.model.smf.AssetTitleDto;
import com.cms.assetmanagement.model.smf.SmfExternalIdDto;
import com.cms.assetmanagement.model.util.ErrorDto;
import com.cms.assetmanagement.model.util.SMFErrorDto;
import org.junit.jupiter.api.Test;

class DtoTest {

    @Test
    void testResponseDto() {
        ModelDtoTestUtility.testModelOrDto(ResponseDto.class);
    }

    @Test
    void testErrorResponseDto() {
        ModelDtoTestUtility.testModelOrDto(ErrorResponseDto.class);
    }

    @Test
    void testBaseResponseDto() {

        ModelDtoTestUtility.testModelOrDto(BaseResponseDto.class);
    }

    @Test
    void testAssetFilterBodyDto() {
        ModelDtoTestUtility.testModelOrDto(AssetFilterBodyDto.class);
    }

    @Test
    void testAssetViewFilterDto() {
        ModelDtoTestUtility.testModelOrDto(AssetViewFilterDto.class);
    }


    @Test
    void testContentKeyDto() {
        ModelDtoTestUtility.testModelOrDto(ContentKeyDto.class);
    }

    @Test
    void testContentProviderDto() {
        ModelDtoTestUtility.testModelOrDto(ContentProviderDto.class);
    }

    @Test
    void testCountryLangCodeDto() {
        ModelDtoTestUtility.testModelOrDto(CountryLangCodeDto.class);
    }

    @Test
    void testFilterDto() {
        ModelDtoTestUtility.testModelOrDto(FilterDto.class);
    }

    @Test
    void testPaginationDto() {
        ModelDtoTestUtility.testModelOrDto(PaginationDto.class);
    }

    @Test
    void testParentalRatingsDto() {
        ModelDtoTestUtility.testModelOrDto(ParentalRatingsDto.class);
    }

    @Test
    void testSortDto() {
        ModelDtoTestUtility.testModelOrDto(SortDto.class);
    }

    @Test
    void testPreProcessImageDto() {
        ModelDtoTestUtility.testModelOrDto(PreProcessImageDto.class);
    }

    @Test
    void testProcessedImageDto() {
        ModelDtoTestUtility.testModelOrDto(ProcessedImageDto.class);
    }

    @Test
    void testAdBreaksDto() {
        ModelDtoTestUtility.testModelOrDto(AdBreaksDto.class);
    }

    @Test
    void testDRMDto() {
        ModelDtoTestUtility.testModelOrDto(DRMDto.class);
    }

    @Test
    void testMediaAssetDto() {
        ModelDtoTestUtility.testModelOrDto(MediaAssetDto.class);
    }


    @Test
    void testAssetByColumnsReqDto() {
        ModelDtoTestUtility.testModelOrDto(AssetByColumnsReqDto.class);
    }

    @Test
    void testAssetChangeHistoryDto() {
        ModelDtoTestUtility.testModelOrDto(AssetChangeHistoryDto.class);
    }

    @Test
    void testAssetDrmDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDrmDto.class);
    }

    @Test
    void testAssetDrmReqDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDrmReqDto.class);
    }

    @Test
    void testAssetExternalIdDto() {
        ModelDtoTestUtility.testModelOrDto(AssetExternalIdDto.class);
    }

    @Test
    void testAssetExternalIdReqDto() {
        ModelDtoTestUtility.testModelOrDto(AssetExternalIdReqDto.class);
    }

    @Test
    void testAssetKeyDto() {
        ModelDtoTestUtility.testModelOrDto(AssetKeyDto.class);
    }

    @Test
    void testAssetKeyListDto() {
        ModelDtoTestUtility.testModelOrDto(AssetKeyListDto.class);
    }

    @Test
    void testAssetRequestBodyDto() {
        ModelDtoTestUtility.testModelOrDto(AssetRequestBodyDto.class);
    }

    @Test
    void testAssetStatusUpdateDto() {
        ModelDtoTestUtility.testModelOrDto(AssetStatusUpdateDto.class);
    }

    @Test
    void testAssetUpdateByBulkDto() {
        ModelDtoTestUtility.testModelOrDto(AssetUpdateByBulkDto.class);
    }

    @Test
    void testContentDetailsDto() {
        ModelDtoTestUtility.testModelOrDto(ContentDetailsDto.class);
    }

    @Test
    void testCountryDto() {
        ModelDtoTestUtility.testModelOrDto(CountryDto.class);
    }

    @Test
    void testEditValidationDto() {
        ModelDtoTestUtility.testModelOrDto(EditValidationDto.class);
    }

    @Test
    void testEpisodeHierarchyDto() {
        ModelDtoTestUtility.testModelOrDto(EpisodeHierarchyDto.class);
    }

    @Test
    void testExternalProviderDto() {
        ModelDtoTestUtility.testModelOrDto(ExternalProviderDto.class);
    }

    @Test
    void testFeedWorkerPriority() {
        ModelDtoTestUtility.testModelOrDto(FeedWorkerPriority.class);
    }

    @Test
    void testLanguageDto() {
        ModelDtoTestUtility.testModelOrDto(LanguageDto.class);
    }

    @Test
    void testPlatformTagData() {
        ModelDtoTestUtility.testModelOrDto(PlatformTagData.class);
    }

    @Test
    void testRatingsDto() {
        ModelDtoTestUtility.testModelOrDto(RatingsDto.class);
    }

    @Test
    void testShowHierarchyDto() {
        ModelDtoTestUtility.testModelOrDto(ShowHierarchyDto.class);
    }

    @Test
    void testVodAssetDetailedDto() {
        ModelDtoTestUtility.testModelOrDto(VodAssetDetailedDto.class);
    }

    @Test
    void testVodAssetStatusDto() {
        ModelDtoTestUtility.testModelOrDto(VodAssetStatusDto.class);
    }

    @Test
    void testErrorDto() {
        ModelDtoTestUtility.testModelOrDto(ErrorDto.class);
    }

    @Test
    void testSMFErrorDto() {
        ModelDtoTestUtility.testModelOrDto(SMFErrorDto.class);
    }

    @Test
    void testAssetAdBreakDto() {
        ModelDtoTestUtility.testModelOrDto(AssetAdBreakDto.class);
    }

    @Test
    void testLoggingDto() {
        ModelDtoTestUtility.testModelOrDto(LoggingDto.class);
    }

    @Test
    void testAssetCastDto() {
        ModelDtoTestUtility.testModelOrDto(AssetCastDto.class);
    }

    @Test
    void testAssetCountryCpLangDto() {
        ModelDtoTestUtility.testModelOrDto(AssetCountryCpLangDto.class);
    }

    @Test
    void testAssetDescriptionDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDescriptionDto.class);
    }

    @Test
    void testSMFAssetDrmDto() {
        ModelDtoTestUtility.testModelOrDto(com.cms.assetmanagement.model.smf.AssetDrmDto.class);
    }

    @Test
    void testAssetDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDto.class);
    }

    @Test
    void testSMFAssetExternalIdDto() {
        ModelDtoTestUtility.testModelOrDto(
            SmfExternalIdDto.class);
    }

    @Test
    void testAssetImageDto() {
        ModelDtoTestUtility.testModelOrDto(AssetImageDto.class);
    }

    @Test
    void testAssetParentalRatingDto() {
        ModelDtoTestUtility.testModelOrDto(AssetParentalRatingDto.class);
    }

    @Test
    void testAssetPlaybackDto() {
        ModelDtoTestUtility.testModelOrDto(AssetPlaybackDto.class);
    }

    @Test
    void testAssetSeriesInfo() {
        ModelDtoTestUtility.testModelOrDto(AssetSeriesInfo.class);
    }

    @Test
    void testAssetTitleDto() {
        ModelDtoTestUtility.testModelOrDto(AssetTitleDto.class);
    }

}
