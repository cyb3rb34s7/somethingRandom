package com.cms.assetmanagement.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.common.util.NotificationUtil;
import com.cms.assetmanagement.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.MethodParameter;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@SpringBootTest(classes = GlobalExceptionHandlerTest.class)
class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private NotificationUtil notificationUtil;

    @Test
    void testHandleMethodArgumentNotValidException() {
        // Mocking BindingResult
        BindingResult bindingResult = mock(BindingResult.class);

        // Creating a list of errors
        FieldError fieldError1 = new FieldError("testObject", "field1", "Invalid value");

        // Setting up the mock to return the list of errors
        when(bindingResult.getAllErrors()).thenReturn(
            Collections.singletonList(fieldError1));

        // Creating a mock MethodParameter
        MethodParameter methodParameter = mock(MethodParameter.class);

        // Creating MethodArgumentNotValidException with mocked BindingResult
        MethodArgumentNotValidException exception = new MethodArgumentNotValidException(
            methodParameter,
            bindingResult);

        // Invoking the method under test
        ResponseDto responseDto = globalExceptionHandler.handleMethodArgumentNotValidException(
            exception);

        // Assertions
        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void handleSQLException() {
        SQLException sqlException = Mockito.mock(SQLException.class);
        Mockito.when(sqlException.getMessage()).thenReturn("Database connection failed");

        ResponseDto responseDto = globalExceptionHandler.handleSQLException(sqlException);

        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void handleConstraintViolationException() {
        // Mocking exceptions
        ConstraintViolationException constraintViolationException = mock(
            ConstraintViolationException.class);
        when(constraintViolationException.getMessage()).thenReturn("Constraint Violation");

        MethodArgumentTypeMismatchException methodArgumentTypeMismatchException = mock(
            MethodArgumentTypeMismatchException.class);
        when(methodArgumentTypeMismatchException.getMessage()).thenReturn("Argument Type Mismatch");

        InvalidInputDataException invalidInputDataException = mock(InvalidInputDataException.class);
        when(invalidInputDataException.getMessage()).thenReturn("Invalid Input Data");

        DataIntegrityViolationException dataIntegrityViolationException = mock(
            DataIntegrityViolationException.class);
        when(dataIntegrityViolationException.getMessage()).thenReturn("Data Integrity Violation");

        // Testing with different types of exceptions
        ResponseDto response1 = globalExceptionHandler.handleConstraintViolationException(
            constraintViolationException);
        assertEquals(Constants.STATUS_FAIL, response1.getRsp().getStat());

        ResponseDto response2 = globalExceptionHandler.handleConstraintViolationException(
            methodArgumentTypeMismatchException);
        assertEquals(Constants.STATUS_FAIL, response2.getRsp().getStat());

        ResponseDto response3 = globalExceptionHandler.handleConstraintViolationException(
            invalidInputDataException);
        assertEquals(Constants.STATUS_FAIL, response3.getRsp().getStat());

        ResponseDto response4 = globalExceptionHandler.handleConstraintViolationException(
            dataIntegrityViolationException);
        assertEquals(Constants.STATUS_FAIL, response4.getRsp().getStat());
    }

    @Test
    void testHandleDataNotFoundException() {
        // Arrange
        DataNotFoundException dataNotFoundException = new DataNotFoundException(
            "Data not found exception message");
        when(dataNotFoundException.getMessage()).thenReturn("Data Not Found");

        // Act
        ResponseDto responseDto = globalExceptionHandler.handleDataNotFoundException(
            dataNotFoundException);

        // Assert
        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void handleHttpRequestMethodNotSupportedException() {
        // Mocking HttpRequestMethodNotSupportedException
        HttpRequestMethodNotSupportedException exception = mock(
            HttpRequestMethodNotSupportedException.class);
        when(exception.getMessage()).thenReturn("Method Not Allowed");

        // Invoking the method under test
        ResponseDto responseDto = globalExceptionHandler.handleHttpRequestMethodNotSupportedException(
            exception);

        // Assertions
        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void testHandleMissingServletRequestParameterException() {
        // Arrange
        MissingServletRequestParameterException exception = Mockito.mock(
            MissingServletRequestParameterException.class);
        Mockito.when(exception.getMessage()).thenReturn("Required parameter is missing");

        // Act
        ResponseDto responseDto = globalExceptionHandler.handleMissingServletRequestParameterException(
            exception);

        // Assert
        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void testHandleJsonSchemaValidationException() {
        Exception ex = new JsonSchemaValidationException(
            "This is a handleJsonSchemaValidationException");

        ResponseDto responseDto = globalExceptionHandler.handleJsonSchemaValidationException(ex);

        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }

    @Test
    void testHandleGeneralException() {
        Exception ex = new Exception("This is a general exception");

        ResponseDto responseDto = globalExceptionHandler.handleGeneralException(ex);

        assertEquals(Constants.STATUS_FAIL, responseDto.getRsp().getStat());
    }


}
