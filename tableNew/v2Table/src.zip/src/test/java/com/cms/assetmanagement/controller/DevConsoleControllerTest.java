package com.cms.assetmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import com.cms.assetmanagement.model.devconsole.TiFeedworkerUpdateDto;
import com.cms.assetmanagement.model.devconsole.TiRequestDto;
import com.cms.assetmanagement.service.DevConsoleService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = DevConsoleControllerTest.class)
class DevConsoleControllerTest {

    @Mock
    private DevConsoleService devConsoleService;

    @InjectMocks
    private DevConsoleController devConsoleController;

    @Test
    void getTiDataTest() {
        TiRequestDto tiRequestDto = TiRequestDto.builder().build();

        assertDoesNotThrow(() -> devConsoleController.getTiData(tiRequestDto));
    }

    @Test
    void updateTiFeedworkerTest() {
        TiFeedworkerUpdateDto tiFeedworkerUpdateDto = TiFeedworkerUpdateDto.builder().build();

        assertDoesNotThrow(() -> devConsoleController.updateTiFeedworker(tiFeedworkerUpdateDto));
    }

}
