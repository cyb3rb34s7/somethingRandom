package com.cms.assetmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.assetmanagement.model.VodAssetDto;
import java.util.List;

/**
 * Utility class to provide common assertion methods for testing.
 * This helps to reduce code duplication in test classes.
 */
public class TestAssertionHelper {

    public static void assertVodAssetDtoIsValid(VodAssetDto assetDto) {
        assertNotNull(assetDto);
        assertNotNull(assetDto.getContentId());
        assertNotNull(assetDto.getVcCpId());
        assertNotNull(assetDto.getCountryCode());
    }

    public static void assertVodAssetDtoHasBasicFields(VodAssetDto assetDto) {
        assertNotNull(assetDto);
        assertNotNull(assetDto.getContentId());
        assertNotNull(assetDto.getVcCpId());
        assertNotNull(assetDto.getCountryCode());
    }

    public static void assertVodAssetDtoHasStatusFields(VodAssetDto assetDto) {
        assertVodAssetDtoHasBasicFields(assetDto);
        assertNotNull(assetDto.getStatus());
        assertNotNull(assetDto.getLicenseWindow());
    }

    public static void assertListIsNotEmpty(List<?> list) {
        assertNotNull(list);
        assertFalse(list.isEmpty());
    }

    public static void assertListIsEmpty(List<?> list) {
        assertTrue(list == null || list.isEmpty());
    }

    public static void assertStringsAreEqual(String expected, String actual, String message) {
        assertEquals(expected, actual, message);
    }

    public static void assertStringIsNotNullOrEmpty(String value, String fieldName) {
        assertNotNull(value, fieldName + " should not be null");
        assertFalse(value.isEmpty(), fieldName + " should not be empty");
    }

    public static void assertIntegerIsPositive(Integer value, String fieldName) {
        assertNotNull(value, fieldName + " should not be null");
        assertTrue(value > 0, fieldName + " should be positive");
    }

    public static void assertBooleanValue(boolean actual, boolean expected, String message) {
        assertEquals(expected, actual, message);
    }
}
