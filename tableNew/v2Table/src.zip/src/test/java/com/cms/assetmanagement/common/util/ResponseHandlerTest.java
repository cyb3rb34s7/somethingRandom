package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.assetmanagement.exception.DataNotFoundException;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.exception.JsonSchemaValidationException;
import com.cms.assetmanagement.model.ErrorResponseDto;
import com.cms.assetmanagement.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

class ResponseHandlerTest {

    @Test
    void testPrivateConstructor() throws Exception {
        // Test that the constructor is private
        Constructor<ResponseHandler> constructor = ResponseHandler.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);

        // Verify that constructor can be called (doesn't throw exception)
        assertDoesNotThrow(() -> {
            constructor.newInstance();
        });
    }

    @Test
    void testProcessMethodResponse_Success_WithPayload() {
        // Test success case with payload
        String payloadKey = "data";
        String payloadObj = "test data";

        ResponseDto result = ResponseHandler.processMethodResponse(payloadKey, payloadObj);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertNotNull(result.getRsp().getPayload());
        assertEquals("test data", result.getRsp().getPayload().get("data"));
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testProcessMethodResponse_Success_WithoutPayload() {
        // Test success case without payload
        ResponseDto result = ResponseHandler.processMethodResponse(null, null);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertNull(result.getRsp().getPayload());
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testProcessMethodResponse_Success_BooleanOverload_True() {
        // Test success case with boolean overload
        String payloadKey = "data";
        String payloadObj = "test data";
        Exception err = null;
        boolean isSuccess = true;

        ResponseDto result = ResponseHandler.processMethodResponse(isSuccess, payloadObj,
            payloadKey, err);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertNotNull(result.getRsp().getPayload());
        assertEquals("test data", result.getRsp().getPayload().get("data"));
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testProcessMethodResponse_Success_BooleanOverload_True_WithoutPayload() {
        // Test success case with boolean overload without payload
        String payloadKey = null;
        String payloadObj = null;
        Exception err = null;
        boolean isSuccess = true;

        ResponseDto result = ResponseHandler.processMethodResponse(isSuccess, payloadObj,
            payloadKey, err);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertNull(result.getRsp().getPayload());
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testProcessMethodResponse_Error_BooleanOverload() {
        // Test error case with boolean overload
        String payloadKey = null;
        String payloadObj = null;
        Exception err = new Exception("Test error");
        boolean isSuccess = false;

        ResponseDto result = ResponseHandler.processMethodResponse(isSuccess, payloadObj,
            payloadKey, err);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("fail", result.getRsp().getStat());
        assertNull(result.getRsp().getPayload());
        assertNotNull(result.getRsp().getErr());
        assertEquals("2415001", result.getRsp().getErr().getCode());
    }

    @Test
    void testProcessMethodResponse_Error() {
        // Test error case
        Exception err = new Exception("Test error");

        ResponseDto result = ResponseHandler.processMethodResponse(err);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("fail", result.getRsp().getStat());
        assertNull(result.getRsp().getPayload());
        assertNotNull(result.getRsp().getErr());
        assertEquals("2415001", result.getRsp().getErr().getCode());
    }

    @Test
    void testProcessSuccess() {
        // Test processSuccess method directly
        Map<String, Object> payload = new HashMap<>();
        payload.put("key", "value");

        ResponseDto result = ResponseHandler.processSuccess(payload);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertEquals(payload, result.getRsp().getPayload());
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testProcessSuccess_WithNullPayload() {
        // Test processSuccess method with null payload
        ResponseDto result = ResponseHandler.processSuccess(null);

        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertEquals("ok", result.getRsp().getStat());
        assertNull(result.getRsp().getPayload());
        assertNull(result.getRsp().getErr());
    }

    @Test
    void testSetResponseDetails_NullException() {
        // Test setResponseDetails with null exception
        // We need to use reflection to test private method
        ErrorResponseDto result = invokeSetResponseDetails(null);
        assertNotNull(result);
        assertEquals("2415001", result.getCode());
        assertEquals("Internal Server Error", result.getMsg());
    }

    @Test
    void testSetResponseDetails_ConstraintViolationException() {
        // Test with ConstraintViolationException
        Exception err = new ConstraintViolationException(null);
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414010", result.getCode());
    }

    @Test
    void testSetResponseDetails_InvalidInputDataException() {
        // Test with InvalidInputDataException
        Exception err = new InvalidInputDataException("Invalid input");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414010", result.getCode());
    }

    @Test
    void testSetResponseDetails_NoResourceFoundException() {
        // Test with NoResourceFoundException
        Exception err = new NoResourceFoundException(org.springframework.http.HttpMethod.GET,
            "/test");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414163", result.getCode());
    }

    @Test
    void testSetResponseDetails_DataIntegrityViolationException() {
        // Test with DataIntegrityViolationException
        Exception err = new DataIntegrityViolationException("Data integrity violation");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414206", result.getCode());
    }

    @Test
    void testSetResponseDetails_JsonSchemaValidationException() {
        // Test with JsonSchemaValidationException
        Exception err = new JsonSchemaValidationException("JSON validation error");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414008", result.getCode());
    }

    @Test
    void testSetResponseDetails_MissingServletRequestParameterException() {
        // Test with MissingServletRequestParameterException
        Exception err = new MissingServletRequestParameterException("param", "String");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414004", result.getCode());
    }

    @Test
    void testSetResponseDetails_HttpRequestMethodNotSupportedException() {
        // Test with HttpRequestMethodNotSupportedException
        Exception err = new HttpRequestMethodNotSupportedException("POST");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414221", result.getCode());
    }

    @Test
    void testSetResponseDetails_DataNotFoundException() {
        // Test with DataNotFoundException
        Exception err = new DataNotFoundException("Data not found");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2414202", result.getCode());
    }

    @Test
    void testSetResponseDetails_GenericException() {
        // Test with generic Exception
        Exception err = new Exception("Generic error");
        ErrorResponseDto result = invokeSetResponseDetails(err);
        assertNotNull(result);
        assertEquals("2415001", result.getCode());
    }

    // Helper method to test private setResponseDetails method using reflection
    private ErrorResponseDto invokeSetResponseDetails(Exception e) {
        try {
            java.lang.reflect.Method method = ResponseHandler.class.getDeclaredMethod(
                "setResponseDetails", Exception.class);
            method.setAccessible(true);
            return (ErrorResponseDto) method.invoke(null, e);
        } catch (Exception ex) {
            throw new RuntimeException("Failed to invoke setResponseDetails method", ex);
        }
    }
}
