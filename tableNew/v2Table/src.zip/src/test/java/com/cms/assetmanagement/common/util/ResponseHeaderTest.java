package com.cms.assetmanagement.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.assetmanagement.common.Constants;
import com.cms.assetmanagement.exception.DataNotFoundException;
import com.cms.assetmanagement.exception.InvalidInputDataException;
import com.cms.assetmanagement.model.ResponseDto;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpMethod;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

class ResponseHeaderTest {

    @Test
    void testProcessMethodResponseSuccessWithPayload() {
        String payloadKey = "key";
        Object payloadObj = "value";

        ResponseDto response = ResponseHandler.processMethodResponse(true, payloadObj, payloadKey,
            null);

        assertEquals("value", ((Map<String, Object>) response.getRsp().getPayload()).get("key"));
        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseFailWithPayload() {
        String payloadKey = "key";
        Object payloadObj = "value";

        ResponseDto response = ResponseHandler.processMethodResponse(false, payloadObj, payloadKey,
            null);

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseSuccessWithNullPayload() {
        String payloadKey = null;
        Object payloadObj = "value";

        ResponseDto response = ResponseHandler.processMethodResponse(true, payloadObj, payloadKey,
            null);

        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseWithNullKey() {
        Object payloadObj = "value";

        ResponseDto response = ResponseHandler.processMethodResponse(null, payloadObj);

        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseException() {

        ResponseDto response = ResponseHandler.processMethodResponse(new Exception("Exception"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseInvalidInputDataException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new InvalidInputDataException("InvalidInputDataException"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseNoResourceFoundException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new NoResourceFoundException(HttpMethod.DELETE, "NoResourceFoundException"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseDataIntegrityViolationException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new DataIntegrityViolationException("DataIntegrityViolationException"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseMissingServletRequestParameterException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new MissingServletRequestParameterException("contentId", "String"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseHttpRequestMethodNotSupportedException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new HttpRequestMethodNotSupportedException("DELETE"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

    @Test
    void testProcessMethodResponseHttpDataNotFoundException() {

        ResponseDto response = ResponseHandler.processMethodResponse(
            new DataNotFoundException("DELETE"));

        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
    }

}
