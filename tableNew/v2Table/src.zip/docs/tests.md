The integrationTest task is registered under Verification tasks with the description "Runs integration tests against real DB". Everything is in place. Here's the complete setup:                                                                                                                                    
                                                                                                                                                                                                                                                                                                                         ---                                                                                                                                                                                                                                                                                                                    What was created:                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                         1. AssetExportIntegrationTest.java — 41 test scenarios                                                                                                                                                                                                                                                               

  Runs against real Oracle DB. Self-discovering (no hardcoded filter values).

  Filter Coverage:

  ┌──────────────────────────────────┬─────────┬────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
  │              Group               │  Tests  │                                                                                     What it covers                                                                                     │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Main table filters               │ T01–T17 │ type, country, status (Released/ReadyForRelease/Untrackable), contentPartner, genres, quality, audioLang, feedWorker, ingestionType, licenseStatus, dbStatus, liveOnDevice, attributes │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Joined table filters (HIGH RISK) │ T20–T25 │ DRM (Y/N), externalId search, externalProgramId search, externalProvider search, history                                                                                               │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Search filters                   │ T30–T32 │ mainTitle, showTitle, contentId                                                                                                                                                        │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Date range filters               │ T40–T43 │ licenseStatusRange, licenseRange, ingestionRange, updateRange                                                                                                                          │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Combinations                     │ T50–T57 │ type+country, type+DRM, status+DRM+country, type+externalId, search+filter, dateRange+filter, DRM+history+type, all joined filters together                                            │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Sorting                          │ T60–T63 │ updateDate DESC/ASC, mainTitle ASC, regDate DESC                                                                                                                                       │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Pagination                       │ T70–T72 │ page1, page2, no-overlap check                                                                                                                                                         │
  ├──────────────────────────────────┼─────────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
  │ Performance                      │ T80–T82 │ 5000 assets baseline, 5000+DRM, 5000+type                                                                                                                                              │
  └──────────────────────────────────┴─────────┴────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

  2. How to use at your org:

  # Step 1: Fill in application-integration.properties with your Oracle connection

  # Step 2: BEFORE optimization — capture golden output
  ./gradlew integrationTest -Dspring.profiles.active=integration

  # Step 3: Implement the optimization changes

  # Step 4: AFTER optimization — verify same results + see performance diff
  ./gradlew integrationTest -Dspring.profiles.active=integration

  # To re-capture: delete golden output and run again
  rm -rf build/golden-output/
  ./gradlew integrationTest -Dspring.profiles.active=integration

  3. What you'll see in the output:

  First run (capture):
    CAPTURED T01_noFilters_baseline                         |  200 assets |   3200 ms
    CAPTURED T20_filterByDrm_Yes                            |  150 assets |   2800 ms
    ...

  Second run (verify):
    VERIFIED T01_noFilters_baseline     | 200 assets | 3200 ms →  800 ms | FASTER by 75%
    VERIFIED T20_filterByDrm_Yes        | 150 assets | 2800 ms →  400 ms | FASTER by 86%
    ...
    TOTAL                               | 45000 ms → 12000 ms | 73.3% FASTER

  4. Build config

  - @Tag("integration") + Gradle excludeTags means ./gradlew test never runs the integration test
  - Only ./gradlew integrationTest runs it
