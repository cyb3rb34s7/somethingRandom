# Logging Enhancement Implementation Plan

## Overview

This document provides a complete implementation guide for adding structured logging with TraceId support to the cms-history module.

**Goals:**
1. TraceId propagation for request correlation
2. Caller service identification
3. Request/response body logging
4. External API call logging
5. Clean, readable log format for debugging

---

## Table of Contents

1. [Files to Create](#files-to-create)
2. [Files to Modify](#files-to-modify)
3. [StructuredLogger Usage Guide](#structuredlogger-usage-guide)
4. [Service Logging Templates](#service-logging-templates)
5. [Implementation Order](#implementation-order)
6. [Validation Checklist](#validation-checklist)

---

## Files to Create

### 1. TraceIdGenerator.java

**Path:** `src/main/java/com/cms/history/common/util/TraceIdGenerator.java`

**Source:** Copy from `cms-monitoring-system/src/main/java/com/cms_monitoring_system/common/util/TraceIdGenerator.java`

```java
package com.cms.history.common.util;

import java.security.SecureRandom;

public class TraceIdGenerator {

    private static final String CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    private TraceIdGenerator() {}

    public static String generate() {
        // 5 chars for timestamp + 5 chars random = 10 total
        String timestampPart = encodeTimestamp(System.currentTimeMillis() / 1000, 5);
        String randomPart = generateRandomString(5);
        return timestampPart + randomPart;
    }

    private static String encodeTimestamp(long timestamp, int length) {
        StringBuilder result = new StringBuilder();
        long value = timestamp;

        for (int i = 0; i < length; i++) {
            result.insert(0, CHARSET.charAt((int) (value % CHARSET.length())));
            value /= CHARSET.length();
        }

        return result.toString();
    }

    private static String generateRandomString(int length) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < length; i++) {
            result.append(CHARSET.charAt(RANDOM.nextInt(CHARSET.length())));
        }
        return result.toString();
    }

    public static boolean isValidTraceId(String traceId) {
        if (traceId == null || traceId.length() != 10) {
            return false;
        }

        for (char c : traceId.toCharArray()) {
            if (CHARSET.indexOf(c) == -1) {
                return false;
            }
        }

        return true;
    }
}
```

---

### 2. StructuredLogger.java

**Path:** `src/main/java/com/cms/history/common/util/StructuredLogger.java`

**Source:** Copy from `cms-monitoring-system/src/main/java/com/cms_monitoring_system/common/util/StructuredLogger.java`

```java
package com.cms.history.common.util;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

@Slf4j
public class StructuredLogger {

    private static final String TRACE_ID = "traceId";
    private static final String OPERATION = "operation";
    private static final String SOURCE_SERVICE = "sourceService";
    private static final String ENVIRONMENT = "environment";
    private static final String REGION = "region";
    private static final String ERROR_TYPE = "errorType";
    private static final String ERROR_MESSAGE = "errorMessage";
    private static final String SUCCESS = "success";
    private static final String DURATION = "duration";
    private static final String RETRY_ATTEMPT = "retryAttempt";
    private static final String MUTE_REASON = "muteReason";

    private StructuredLogger() {}

    public static void setTraceId(String traceId) {
        MDC.put(TRACE_ID, traceId);
    }

    public static String getTraceId() {
        return MDC.get(TRACE_ID);
    }

    public static void setSourceService(String sourceService) {
        MDC.put(SOURCE_SERVICE, sourceService);
    }

    public static void setRequestContext(String operation, String sourceService,
                                       String environment, String region, String errorType, String errorMessage) {
        MDC.put(OPERATION, operation);
        MDC.put(SOURCE_SERVICE, sourceService);
        MDC.put(ENVIRONMENT, environment);
        MDC.put(REGION, region);
        MDC.put(ERROR_TYPE, errorType);
        MDC.put(ERROR_MESSAGE, errorMessage);
    }

    public static void setSuccess(boolean success) {
        MDC.put(SUCCESS, String.valueOf(success));
    }

    public static void setDuration(long duration) {
        MDC.put(DURATION, String.valueOf(duration));
    }

    public static void setRetryAttempt(int attempt) {
        MDC.put(RETRY_ATTEMPT, String.valueOf(attempt));
    }

    public static void clearRetryAttempt() {
        MDC.remove(RETRY_ATTEMPT);
    }

    public static void clearContext() {
        MDC.clear();
    }

    public static void logRequestReceived(String message) {
        log.info("REQUEST_RECEIVED: {}", message);
    }

    public static void logOperationStart(String message) {
        log.info("OPERATION_START: {}", message);
    }

    public static void logOperationSuccess(String message) {
        setSuccess(true);
        log.info("OPERATION_SUCCESS: {}", message);
    }

    public static void logOperationFailure(String message, Exception ex) {
        setSuccess(false);
        log.error("OPERATION_FAILURE: {}", message, ex);
    }

    public static void logRetryAttempt(String message, int attempt) {
        setRetryAttempt(attempt);
        log.warn("RETRY_ATTEMPT: {} (attempt: {})", message, attempt);
    }

    public static void logMutedRequest(String reason) {
        MDC.put(MUTE_REASON, reason);
        log.info("REQUEST_MUTED: Error request muted due to {}", reason);
        MDC.remove(MUTE_REASON);
    }
}
```

---

### 3. TraceIdFilter.java

**Path:** `src/main/java/com/cms/history/common/filter/TraceIdFilter.java`

```java
package com.cms.history.common.filter;

import com.cms.history.common.util.StructuredLogger;
import com.cms.history.common.util.TraceIdGenerator;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TraceIdFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(TraceIdFilter.class);

    private static final String HEADER_TRACE_ID = "X-Trace-Id";
    private static final String HEADER_SOURCE_SERVICE = "X-Source-Service";
    private static final String HEADER_USER_AGENT = "User-Agent";
    private static final String MDC_SOURCE_SERVICE = "sourceService";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        if (!(request instanceof HttpServletRequest httpRequest) ||
            !(response instanceof HttpServletResponse httpResponse)) {
            chain.doFilter(request, response);
            return;
        }

        long startTime = System.currentTimeMillis();

        try {
            // Extract or generate traceId
            String traceId = httpRequest.getHeader(HEADER_TRACE_ID);
            if (traceId == null || !TraceIdGenerator.isValidTraceId(traceId)) {
                traceId = TraceIdGenerator.generate();
            }

            // Set traceId in MDC
            StructuredLogger.setTraceId(traceId);

            // Add traceId to response header for caller correlation
            httpResponse.setHeader(HEADER_TRACE_ID, traceId);

            // Extract source service
            String sourceService = httpRequest.getHeader(HEADER_SOURCE_SERVICE);
            if (sourceService == null || sourceService.isEmpty()) {
                sourceService = httpRequest.getHeader(HEADER_USER_AGENT);
            }
            if (sourceService == null || sourceService.isEmpty()) {
                sourceService = "unknown";
            }
            MDC.put(MDC_SOURCE_SERVICE, sourceService);

            // Log request entry
            log.info(">>> {} {}", httpRequest.getMethod(), httpRequest.getRequestURI());

            // Execute filter chain
            chain.doFilter(request, response);

        } finally {
            long duration = System.currentTimeMillis() - startTime;

            // Log request completion
            log.info("<<< {} ({}ms)", httpResponse.getStatus(), duration);

            // Clear MDC to prevent memory leaks
            StructuredLogger.clearContext();
        }
    }
}
```

---

## Files to Modify

### 4. log4j2.xml

**Path:** `src/main/resources/log4j2.xml`

**Change:** Update PatternLayout to include traceId and sourceService

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Configuration>
  <Appenders>
    <Console name="Console" target="SYSTEM_OUT">
      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%X{traceId:-NO_TRACE}] [%X{sourceService:-unknown}] %-5level %c{1} - %msg%n%throwable"/>
    </Console>
  </Appenders>

  <Loggers>
    <Root level="info">
      <AppenderRef ref="Console"/>
    </Root>
    <Logger name="com.cms.history" level="debug" additivity="false">
      <AppenderRef ref="Console"/>
    </Logger>
  </Loggers>
</Configuration>
```

---

### 5. HttpMethodHandler.java

**Path:** `src/main/java/com/cms/history/common/util/HttpMethodHandler.java`

**Changes:**
1. Log outgoing request body
2. Log response status and timing
3. Pass X-Trace-Id header to external API

```java
package com.cms.history.common.util;

import com.cms.history.common.exception.AssetApiFailureException;
import com.cms.history.common.model.ResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class HttpMethodHandler {

    private final RestTemplate restTemplate;

    private static final String HEADER_TRACE_ID = "X-Trace-Id";

    public HttpMethodHandler(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<ResponseDto> handleHttpExchange(String endPoint,
        String httpMethod,
        HttpEntity<?> httpEntity, Class<?> className) {

        long startTime = System.currentTimeMillis();

        try {
            // Add traceId header to outgoing request
            HttpHeaders headers = new HttpHeaders();
            if (httpEntity.getHeaders() != null) {
                headers.addAll(httpEntity.getHeaders());
            }
            String traceId = StructuredLogger.getTraceId();
            if (traceId != null) {
                headers.add(HEADER_TRACE_ID, traceId);
            }
            HttpEntity<?> entityWithTrace = new HttpEntity<>(httpEntity.getBody(), headers);

            // Log outgoing request
            log.info(">>> External API: {} {} request: {}", httpMethod, endPoint, httpEntity.getBody());

            ResponseEntity<ResponseDto> response = (ResponseEntity<ResponseDto>) restTemplate.exchange(
                endPoint,
                HttpMethod.valueOf(httpMethod),
                entityWithTrace,
                className);

            long duration = System.currentTimeMillis() - startTime;
            log.info("<<< External API: {} {} ({}ms)", response.getStatusCode(), endPoint, duration);

            return response;

        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            log.error("<<< External API FAILED: {} {} ({}ms) error: {}", httpMethod, endPoint, duration, e.getMessage());
            this.handleException(e);
        }
        return null;
    }

    private void handleException(Exception e) {
        if (e instanceof HttpClientErrorException.BadRequest) {
            log.error("Bad request Exception occurred while calling the API: {}", e.getMessage());
            throw new IllegalArgumentException(e);
        } else if (e instanceof HttpServerErrorException.InternalServerError) {
            log.error("Exception occurred at server side while calling the API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        } else if (e instanceof HttpStatusCodeException) {
            log.error("Status Code Exception occurred while calling the API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        } else if (e instanceof RestClientException) {
            log.error("Exception occurred while calling the external API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        }
    }
}
```

---

### 6. Controllers - Add Entry Logs

**Pattern for all controllers:**

Add `@Slf4j` annotation and log entry for each endpoint with full request body.

#### LicenseHistoryController.java

**Path:** `src/main/java/com/cms/history/licensehistory/controller/LicenseHistoryController.java`

```java
@Slf4j  // ADD THIS
@RestController
@RequestMapping("/cms/tvplus/license/history")
public class LicenseHistoryController {

    @PostMapping("/get")
    public ResponseDto getLicenseHistory(@RequestBody FilterRequestBodyDto filterRequestBody) {
        log.info("getLicenseHistory request: {}", filterRequestBody);  // ADD THIS
        List<LicenseHistoryResponseDto> assets = licenseHistoryService.getLicenseHistory(filterRequestBody);
        Map<String,Object> response = new HashMap<>();
        response.put(Constants.RESPONSE_KEY, assets);
        response.put(Constants.COUNT, licenseHistoryService.getLicenseHistoryCount(filterRequestBody));
        log.info("getLicenseHistory returning {} records", assets.size());  // ADD THIS
        return ResponseHandler.processSuccess(response);
    }

    @GetMapping("/get/asset/{assetId}")
    public ResponseDto getLicenseHistoryByAssetId(@PathVariable String assetId) {
        log.info("getLicenseHistoryByAssetId assetId: {}", assetId);  // ADD THIS
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            licenseHistoryService.getLicenseHistoryByAssetId(assetId));
    }

    @PostMapping("/add")
    public ResponseDto insertLicenseHistory(@RequestBody LicenseHistoryRequestDto historyRequest) {
        log.info("insertLicenseHistory request: {}", historyRequest);  // ADD THIS
        licenseHistoryService.insertLicenseHistory(historyRequest);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getAssetId());
    }

    @GetMapping("/get/filters")
    public ResponseDto getFilters() {
        log.info("getFilters called");  // ADD THIS
        Map<String, List<String>> filters = licenseHistoryService.getFilters();
        return ResponseHandler.processMethodResponse(Constants.FILTER_KEY, filters);
    }
}
```

#### MetadataHistoryController.java

**Path:** `src/main/java/com/cms/history/metadatahistory/controller/MetadataHistoryController.java`

```java
// Already has @Slf4j, just add log statements

@PostMapping(value = "/add")
public ResponseDto addHistory(@RequestBody MetadataHistoryRequestDto assetReq) {
    log.info("addHistory request: {}", assetReq);  // ADD THIS
    metadataHistoryService.addMetadataHistory(assetReq);
    return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
        Constants.SUCCESS_MESSAGE_HISTORY + assetReq.getAssetId());
}

@PostMapping(value = "/get")
public ResponseDto getAllMetadata(@RequestBody FilterRequestBodyDto filteredReqBody) {
    log.info("getAllMetadata request: {}", filteredReqBody);  // ADD THIS
    List<MetadataHistoryModel> assets = metadataHistoryService.getAllMetadata(filteredReqBody);
    // ... rest of method
    log.info("getAllMetadata returning {} records", assets.size());  // ADD THIS
    return ResponseHandler.processSuccess(response);
}

@PostMapping(value = "/get/asset/{assetId}")
public ResponseDto getHistoryByAssetId(@PathVariable String assetId,
    @RequestBody FilterRequestBodyDto filteredReqBody) {
    log.info("getHistoryByAssetId assetId: {} request: {}", assetId, filteredReqBody);  // ADD THIS
    // ... rest of method
}

@GetMapping("/get/filters")
public ResponseDto getFilters() {
    log.info("getFilters called");  // ADD THIS
    // ... rest of method
}
```

#### EventHistoryController.java

**Path:** `src/main/java/com/cms/history/eventhistory/controller/EventHistoryController.java`

Add `@Slf4j` and log statements following the same pattern.

#### StatusHistoryController.java

**Path:** `src/main/java/com/cms/history/statushistory/controller/StatusHistoryController.java`

Add `@Slf4j` and log statements following the same pattern.

#### LockHistoryController.java

**Path:** `src/main/java/com/cms/history/lockHistory/controller/LockHistoryController.java`

Add `@Slf4j` and log statements following the same pattern.

---

### 7. LockHistoryService.java

**Path:** `src/main/java/com/cms/history/lockHistory/service/LockHistoryService.java`

```java
public void addLockChangeHistory(LockHistoryRequestDto lockHistoryRequest) {
    log.info("addLockChangeHistory request: {}", lockHistoryRequest);  // ADD THIS
    lockHistoryRequest.populateChangesJsonString();
    lockHistoryMapper.addLockChangeHistory(lockHistoryRequest);
    log.info("Lock change history added for asset: {}", lockHistoryRequest.getContentId());
}
```

---

## StructuredLogger Usage Guide

### When to Use Each Method

| Method | When to Use | Example |
|--------|-------------|---------|
| `logRequestReceived()` | At the start of processing a request | `StructuredLogger.logRequestReceived("Processing metadata history for asset: " + assetId)` |
| `logOperationStart()` | Before starting a significant operation | `StructuredLogger.logOperationStart("Fetching asset details from API")` |
| `logOperationSuccess()` | When operation completes successfully | `StructuredLogger.logOperationSuccess("Metadata history inserted successfully")` |
| `logOperationFailure()` | When operation fails with exception | `StructuredLogger.logOperationFailure("Failed to insert history", ex)` |
| `logRetryAttempt()` | During retry operations | `StructuredLogger.logRetryAttempt("Retrying database insert", attemptNumber)` |

### Basic Usage Pattern

```java
@Slf4j
@Service
public class ExampleService {

    public void processData(RequestDto request) {
        // Log operation start
        log.info("processData request: {}", request);

        try {
            // Do work
            someRepository.save(data);

            // Log success
            log.info("processData completed for id: {}", request.getId());

        } catch (Exception e) {
            log.error("processData failed for id: {} error: {}", request.getId(), e.getMessage());
            throw e;
        }
    }
}
```

### Using StructuredLogger Methods

```java
public void processWithStructuredLogging(RequestDto request) {
    StructuredLogger.logOperationStart("Processing request: " + request.getId());

    try {
        // Do work
        StructuredLogger.logOperationSuccess("Request processed successfully");

    } catch (Exception e) {
        StructuredLogger.logOperationFailure("Request processing failed", e);
        throw e;
    }
}
```

---

## Service Logging Templates

### Template: Insert/Add Operations

```java
public void insertHistory(HistoryRequestDto request) {
    // 1. Log entry with full request
    log.info("insertHistory request: {}", request);

    // 2. Validate
    if (request.getId() == null) {
        log.error("Validation failed: ID is null");
        throw new IllegalArgumentException("ID cannot be null");
    }

    // 3. Log significant operations
    log.info("Updating main table for id: {}", request.getId());

    // 4. Perform operation (within retry if applicable)
    RetryUtil.retry(() -> {
        mapper.insert(request);
        return null;
    });

    // 5. Log success
    log.info("History inserted successfully for id: {}", request.getId());
}
```

### Template: Get/Fetch Operations

```java
public List<HistoryDto> getHistory(FilterRequestBodyDto filter) {
    // 1. Log entry with request
    log.info("getHistory request: {}", filter);

    // 2. Fetch data
    List<HistoryDto> results = mapper.getHistory(filter);

    // 3. Log result count
    log.info("getHistory returning {} records", results.size());

    return results;
}
```

### Template: External API Calls

```java
public ExternalData callExternalApi(ApiRequestDto request) {
    String url = baseUrl + "/endpoint";

    // 1. Log request being sent
    log.info("Calling external API: {} with request: {}", url, request);

    // 2. Make call (HttpMethodHandler will log details)
    ResponseEntity<ResponseDto> response = httpHandler.handleHttpExchange(
        url, "POST", new HttpEntity<>(request), ResponseDto.class);

    // 3. Log response received
    log.info("External API response received, size: {}",
        response.getBody().getRsp().getPayload().size());

    return parseResponse(response);
}
```

---

## Implementation Order

Execute these steps in order:

### Step 1: Create Utility Classes

1. Create package `com.cms.history.common.filter` if not exists
2. Create `TraceIdGenerator.java` in `common/util/`
3. Create `StructuredLogger.java` in `common/util/`
4. Create `TraceIdFilter.java` in `common/filter/`

### Step 2: Update Configuration

5. Update `log4j2.xml` with new pattern

### Step 3: Update HTTP Handler

6. Modify `HttpMethodHandler.java` with logging and X-Trace-Id header

### Step 4: Update Controllers

7. Add `@Slf4j` and entry logs to `LicenseHistoryController.java`
8. Add entry logs to `MetadataHistoryController.java`
9. Add `@Slf4j` and entry logs to `EventHistoryController.java`
10. Add `@Slf4j` and entry logs to `StatusHistoryController.java`
11. Add `@Slf4j` and entry logs to `LockHistoryController.java`

### Step 5: Update Services

12. Add entry log to `LockHistoryService.java`

---

## Validation Checklist

After implementation, verify:

### TraceId Propagation
- [ ] Requests without X-Trace-Id get a generated one
- [ ] Requests with X-Trace-Id use the provided one
- [ ] X-Trace-Id appears in all log lines for a request
- [ ] X-Trace-Id is returned in response header

### Log Output
- [ ] Filter logs `>>> METHOD /path` on entry
- [ ] Filter logs `<<< STATUS (Xms)` on exit
- [ ] Controllers log full request body
- [ ] Services log operation progress
- [ ] External API calls log request and response
- [ ] MyBatis SQL logs appear with traceId

### Sample Test

Make a request and verify log output:

```bash
curl -X POST http://localhost:8080/cms/tvplus/metadata/history/add \
  -H "Content-Type: application/json" \
  -H "X-Source-Service: test-client" \
  -d '{"assetId":"12345","countryCode":"US"}'
```

Expected log output:
```
10:15:30.100 [Abc12Xyz34] [test-client] INFO  TraceIdFilter - >>> POST /cms/tvplus/metadata/history/add
10:15:30.102 [Abc12Xyz34] [test-client] INFO  MetadataHistoryController - addHistory request: MetadataHistoryRequestDto{assetId=12345, countryCode=US}
10:15:30.105 [Abc12Xyz34] [test-client] INFO  MetadataHistoryService - Inserting Asset History: 12345
10:15:30.110 [Abc12Xyz34] [test-client] INFO  HttpMethodHandler - >>> External API: POST http://asset-api/getView request: {...}
10:15:30.180 [Abc12Xyz34] [test-client] INFO  HttpMethodHandler - <<< External API: 200 OK http://asset-api/getView (70ms)
10:15:30.200 [Abc12Xyz34] [test-client] DEBUG MetadataHistoryMapper - ==> Preparing: INSERT INTO cms_metadata_h...
10:15:30.210 [Abc12Xyz34] [test-client] INFO  MetadataHistoryService - Metadata History Added Successfully!
10:15:30.215 [Abc12Xyz34] [test-client] INFO  TraceIdFilter - <<< 200 (115ms)
```

---

## Debugging with TraceId

Once implemented, you can debug any request by:

1. **Get the traceId** from response header or logs
2. **Search all logs** for that traceId: `grep "Abc12Xyz34" application.log`
3. **See complete flow**: request -> controller -> service -> API calls -> DB -> response
