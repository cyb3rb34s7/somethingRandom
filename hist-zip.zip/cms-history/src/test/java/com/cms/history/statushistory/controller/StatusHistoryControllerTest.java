package com.cms.history.statushistory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.constant.TestConstants;
import com.cms.history.statushistory.dto.StatusHistoryRequestDto;
import com.cms.history.statushistory.dto.StatusHistoryResponseDto;
import com.cms.history.statushistory.model.StatusHistoryModel;
import com.cms.history.statushistory.service.StatusHistoryService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


class StatusHistoryControllerTest {

    @InjectMocks
    private StatusHistoryController statusHistoryController;

    @Mock
    private StatusHistoryService statusHistoryService;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void exportStatusHistoryTest() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResponse = List.of(new StatusHistoryResponseDto());
        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            expectedResponse);
        Mockito.when(statusHistoryService.getStatusHistoryForExport(filterRequestBody))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = statusHistoryController.exportStatusHistory(filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());

    }

    @Test
    void exportStatusHistory_Exception() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Mockito.when(statusHistoryService.getStatusHistoryForExport(filterRequestBody))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> statusHistoryController.exportStatusHistory(filterRequestBody));
    }

    @Test
    void getStatusHistoryTest() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResponse = List.of(new StatusHistoryResponseDto());
        Map<String, Object> map = new HashMap<>();
        map.put("data", expectedResponse);
        map.put("count",0) ;
        ResponseDto expected = ResponseHandler.processSuccess(map);
        Mockito.when(statusHistoryService.getAllAssetStatus(filterRequestBody))
            .thenReturn(expectedResponse);
        Mockito.when(statusHistoryService.getStatusHistoryCount(filterRequestBody)).thenReturn(0) ;

        ResponseDto actualResponse = statusHistoryController.getAllAssetsStatus(filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());

    }

    @Test
    void getStatusHistoryTest_Exception() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Mockito.when(statusHistoryService.getAllAssetStatus(filterRequestBody))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> statusHistoryController.getAllAssetsStatus(filterRequestBody));
    }

    @Test
    void getStatusHistoryByAssetId() {

        List<StatusHistoryModel> expectedResponse = List.of(new StatusHistoryModel());
        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            expectedResponse);
        Mockito.when(statusHistoryService.getStatusHistoryByAssetId(TestConstants.TEST_ID))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = statusHistoryController.getStatusHistoryByAssetId(
            TestConstants.TEST_ID);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());

    }

    @Test
    void getStatusHistoryByIdTest_Exception() {

        Mockito.when(statusHistoryService.getStatusHistoryByAssetId(TestConstants.TEST_ID))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> statusHistoryController.getStatusHistoryByAssetId(TestConstants.TEST_ID));
    }

    @Test
    void testStatusHistoryException() {
        StatusHistoryRequestDto historyRequest = new StatusHistoryRequestDto();
        historyRequest.setUpdatedBy(TestConstants.TEST_UPD_BY);
        historyRequest.setChanges(new ArrayList<>());
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.ASSET_STATUS_HISTORY_MESSAGE + historyRequest.getChanges().size());

        Mockito.when(statusHistoryService.addStatusHistory(Mockito.any()))
            .thenReturn(historyRequest.getChanges().size());
        ResponseDto response = statusHistoryController.addHistory(historyRequest);
        assertEquals(expectedResponse.getRsp().getPayload(), response.getRsp().getPayload());

    }

    @Test
    void testStatusHistoryException_exception() {
        StatusHistoryRequestDto historyRequest = new StatusHistoryRequestDto();
        Mockito.doThrow(new RuntimeException()).when(statusHistoryService)
            .addStatusHistory(historyRequest);
        assertThrows(RuntimeException.class,
            () -> statusHistoryController.addHistory(historyRequest));

    }

    @Test
    void testGetFilters_success() {
        List<String> tiList = new ArrayList<>();
        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.TI_NAME, tiList);

        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.FILTER_KEY,
            expectedFilters);
        Mockito.when(statusHistoryService.getFilters()).thenReturn(expectedFilters);

        ResponseDto actual = statusHistoryController.getFilters();

        assertEquals(expected.getRsp().getPayload(), actual.getRsp().getPayload());
        Mockito.verify(statusHistoryService, Mockito.times(1)).getFilters();

    }

    @Test
    void testGetFilters_exception() {

        Mockito.when(statusHistoryService.getFilters()).thenThrow(new RuntimeException());
        assertThrows(RuntimeException.class, () -> statusHistoryController.getFilters());

    }


}