package com.cms.history.statushistory.util;

import static org.mockito.Mockito.mock;

import com.cms.history.statushistory.dto.StatusHistoryRequestDto;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Collections;
import java.util.List;

public class DummyStatusDtoGenerator {

    public static StatusHistoryRequestDto generateAssetDummy() {

        JsonNode dummy = mock(JsonNode.class);

        StatusHistoryRequestDto.AssetsChanges changes = new StatusHistoryRequestDto.AssetsChanges(
            "US0101",
            "QC In Progress", "QC Pass", "Post", "ID001", "US", "KR0078JU_TEST");

        List<StatusHistoryRequestDto.AssetsChanges> lstChanges = Collections.singletonList(changes);
        StatusHistoryRequestDto dto = new StatusHistoryRequestDto("user1",
            (List<StatusHistoryRequestDto.AssetsChanges>) lstChanges);

        return dto;
    }

}
