package com.cms.history.licensehistory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.constant.TestConstants;
import com.cms.history.licensehistory.dto.LicenseHistoryChangesDto;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import com.cms.history.licensehistory.service.LicenseHistoryService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class LicenseHistoryControllerTest {


    @Mock
    private LicenseHistoryService licenseHistoryService;

    @InjectMocks
    private LicenseHistoryController licenseHistoryController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFilteredLicenseList_success() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<LicenseHistoryResponseDto> expectedResponse = List.of(
            LicenseHistoryResponseDto.builder()
                .build());
        Map<String, Object> map = new HashMap<>();
        map.put("data", expectedResponse);
        map.put("count",0) ;
        ResponseDto expected = ResponseHandler.processSuccess(map);
        Mockito.when(licenseHistoryService.getLicenseHistory(filterRequestBody))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = licenseHistoryController.getLicenseHistory(filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());


    }

    @Test
    void testGetFilteredLicenseByIdList_success() {

        List<LicenseHistoryChangesDto> expectedResponse = List.of(
            LicenseHistoryChangesDto.builder()
                .build());
        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            expectedResponse);
        Mockito.when(licenseHistoryService.getLicenseHistoryByAssetId(TestConstants.TEST_ID))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = licenseHistoryController.getLicenseHistoryByAssetId(
            TestConstants.TEST_ID);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());


    }

    @Test
    void testGetFilteredLicenseList_serviceThrowsException() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Mockito.when(licenseHistoryService.getLicenseHistory(filterRequestBody))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> licenseHistoryController.getLicenseHistory(filterRequestBody));
    }

    @Test
    void testGetFilteredLicenseListById_serviceThrowsException() {

        Mockito.when(licenseHistoryService.getLicenseHistoryByAssetId(TestConstants.TEST_ID))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> licenseHistoryController.getLicenseHistoryByAssetId(TestConstants.TEST_ID));
    }

    @Test
    void testInsertLicenseHistory_success() {
        LicenseHistoryRequestDto historyRequest = LicenseHistoryRequestDto.builder().build();
        historyRequest.setAssetId(TestConstants.TEST_ID);
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getAssetId());

        Mockito.doNothing().when(licenseHistoryService).insertLicenseHistory(historyRequest);

        ResponseDto response = licenseHistoryController.insertLicenseHistory(historyRequest);
        assertEquals(expectedResponse.getRsp().getPayload(), response.getRsp().getPayload());

    }

    @Test
    void testInsertLicenseHistory_exception() {
        LicenseHistoryRequestDto historyRequest = LicenseHistoryRequestDto.builder().build();

        Mockito.doThrow(new RuntimeException()).when(licenseHistoryService)
            .insertLicenseHistory(historyRequest);

        assertThrows(RuntimeException.class,
            () -> licenseHistoryController.insertLicenseHistory(historyRequest));


    }

    @Test
    void testGetFilters_success() {

        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.ASSET_STATUS, Constants.ASSET_STATUS_FILTERS);

        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.FILTER_KEY,
            expectedFilters);
        Mockito.when(licenseHistoryService.getFilters()).thenReturn(expectedFilters);

        ResponseDto actual = licenseHistoryController.getFilters();

        assertEquals(expected.getRsp().getPayload(), actual.getRsp().getPayload());
        Mockito.verify(licenseHistoryService, Mockito.times(1)).getFilters();

    }

    @Test
    void testGetFilters_exception() {

        Mockito.when(licenseHistoryService.getFilters()).thenThrow(new RuntimeException());
        assertThrows(RuntimeException.class, () -> licenseHistoryController.getFilters());

    }


}