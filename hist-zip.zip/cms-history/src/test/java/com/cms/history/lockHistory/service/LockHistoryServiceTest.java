package com.cms.history.lockHistory.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.cms.history.lockHistory.mapper.LockHistoryMapper;
import com.cms.history.lockHistory.model.LockHistoryRequestDto;
import com.cms.history.lockHistory.model.LockHistoryRequestDto.LockChange;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class LockHistoryServiceTest {

    private static final String TEST_CONTENT_ID = "TEST_CONTENT_123";

    @Mock
    private LockHistoryMapper lockHistoryMapper;

    @InjectMocks
    private LockHistoryService lockHistoryService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddLockChangeHistory_success() {
        LockHistoryRequestDto request = LockHistoryRequestDto.builder()
            .contentId(TEST_CONTENT_ID)
            .changes(List.of(new LockChange()))
            .build();

        lockHistoryService.addLockChangeHistory(request);

        verify(lockHistoryMapper, times(1)).addLockChangeHistory(request);
    }

    @Test
    void testAddLockChangeHistory_mapperException() {
        LockHistoryRequestDto request = LockHistoryRequestDto.builder()
            .contentId(TEST_CONTENT_ID)
            .changes(List.of(new LockChange()))
            .build();

        doThrow(new RuntimeException()).when(lockHistoryMapper).addLockChangeHistory(request);

        assertThrows(RuntimeException.class,
            () -> lockHistoryService.addLockChangeHistory(request));
    }
}
