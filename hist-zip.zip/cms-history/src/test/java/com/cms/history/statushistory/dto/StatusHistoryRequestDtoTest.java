package com.cms.history.statushistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.constant.TestConstants;
import com.cms.history.statushistory.dto.StatusHistoryRequestDto.AssetsChanges;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class StatusHistoryRequestDtoTest {

    @Test
    void testAllArgsConstructor() {
        List<AssetsChanges> changes = new ArrayList<>();
        StatusHistoryRequestDto dto = new StatusHistoryRequestDto(TestConstants.TEST_UPD_BY,
            changes);
        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(changes, dto.getChanges());
        AssetsChanges changeData = new AssetsChanges(TestConstants.TEST_ID,
            TestConstants.TEST_OLD_STATUS, TestConstants.TEST_NEW_STATUS,
            TestConstants.TEST_MASTER_STATUS, TestConstants.TEST_UPD_BY,
            TestConstants.TEST_CNTRY_CD, TestConstants.TEST_CP_ID);
        assertEquals(TestConstants.TEST_ID, changeData.getAssetId());
        assertEquals(TestConstants.TEST_OLD_STATUS, changeData.getOldStatus());
        assertEquals(TestConstants.TEST_NEW_STATUS, changeData.getNewStatus());
        assertEquals(TestConstants.TEST_MASTER_STATUS, changeData.getMasterStatus());
        assertEquals(TestConstants.TEST_UPD_BY, changeData.getIdentifierId());
        assertEquals(TestConstants.TEST_CNTRY_CD, changeData.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, changeData.getVcCpId());

    }

    @Test
    void testGettersAndSetters() {
        StatusHistoryRequestDto dto = new StatusHistoryRequestDto();
        AssetsChanges chg = new AssetsChanges();
        List<AssetsChanges> changes = new ArrayList<>();

        dto.setUpdatedBy(TestConstants.TEST_UPD_BY);
        dto.setChanges(changes);

        chg.setAssetId(TestConstants.TEST_ID);
        chg.setOldStatus(TestConstants.TEST_OLD_STATUS);
        chg.setNewStatus(TestConstants.TEST_NEW_STATUS);
        chg.setMasterStatus(TestConstants.TEST_MASTER_STATUS);
        chg.setIdentifierId(TestConstants.TEST_UPD_BY);
        chg.setCountryCode(TestConstants.TEST_CNTRY_CD);
        chg.setVcCpId(TestConstants.TEST_CP_ID);

        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(changes, dto.getChanges());

        assertEquals(TestConstants.TEST_ID, chg.getAssetId());
        assertEquals(TestConstants.TEST_OLD_STATUS, chg.getOldStatus());
        assertEquals(TestConstants.TEST_NEW_STATUS, chg.getNewStatus());

        assertEquals(TestConstants.TEST_MASTER_STATUS, chg.getMasterStatus());
        assertEquals(TestConstants.TEST_UPD_BY, chg.getIdentifierId());
        assertEquals(TestConstants.TEST_CNTRY_CD, chg.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, chg.getVcCpId());
    }
}