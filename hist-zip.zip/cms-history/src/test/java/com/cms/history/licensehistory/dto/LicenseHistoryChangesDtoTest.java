package com.cms.history.licensehistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.common.model.BaseResponseDto;
import com.cms.history.common.util.ModelDtoTestUtility;
import com.cms.history.constant.TestConstants;
import org.junit.jupiter.api.Test;

class LicenseHistoryChangesDtoTest {

   @Test
    void testLicenseChangesDto(){

       ModelDtoTestUtility.testModelOrDto(LicenseHistoryChangesDto.class);
   }


}