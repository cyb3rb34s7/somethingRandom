package com.cms.history.metadatahistory.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.constant.TestConstants;
import com.cms.history.metadatahistory.dto.MetadataHistoryRequestDto;
import com.cms.history.metadatahistory.mapper.MetadataHistoryMapper;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


class MetadataHistoryModelServiceTest {


    @Mock
    private AssetDetailsService assetDetailsService;

    @InjectMocks
    private MetadataHistoryService metadataHistoryService;

    @Mock
    private MetadataHistoryMapper metadataHistoryMapper;


    MetadataHistoryRequestDto validAssetReq;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        validAssetReq = MetadataHistoryRequestDto.builder()
            .updatedBy(TestConstants.TEST_UPD_BY)
            .assetId(TestConstants.TEST_ID)
            .changes(TestConstants.TEST_JSON_CHANGES)
            .txnOccDate(Instant.now())
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();
        validAssetReq.setAssetId(TestConstants.TEST_ID);

    }

    @Test
    void getAssetHistory_test_success() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResult = new ArrayList<>();
        expectedResult.add(MetadataHistoryModel.builder().build());
        Mockito.when(metadataHistoryMapper.getAllAsset(filterRequestBody))
            .thenReturn(expectedResult);

        List<MetadataHistoryModel> actualResult = metadataHistoryService.getAllMetadata(
            filterRequestBody);
        assertEquals(expectedResult, actualResult);
        Mockito.verify(metadataHistoryMapper).getAllAsset(filterRequestBody);
    }

    @Test
    void getAssetHistory_test_exception() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResult = new ArrayList<>();
        expectedResult.add(MetadataHistoryModel.builder().build());
        Mockito.when(metadataHistoryService.getAllMetadata(filterRequestBody))
            .thenReturn(expectedResult);
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE))
            .when(metadataHistoryMapper)
            .getAllAsset(filterRequestBody);
        assertThrows(RuntimeException.class,
            () -> metadataHistoryService.getAllMetadata(filterRequestBody));
    }

    @Test
    void getAssetHistoryById_test_success() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResult = new ArrayList<>();
        expectedResult.add(MetadataHistoryModel.builder().build());
        Mockito.when(
                metadataHistoryMapper.getAllAssetByAssetId(TestConstants.TEST_ID, filterRequestBody))
            .thenReturn(expectedResult);

        List<MetadataHistoryModel> actualResult = metadataHistoryService.getMetadataDetailsByAssetId(
            TestConstants.TEST_ID,
            filterRequestBody);
        assertEquals(expectedResult, actualResult);
        Mockito.verify(metadataHistoryMapper)
            .getAllAssetByAssetId(TestConstants.TEST_ID, filterRequestBody);
    }

    @Test
    void getAssetHistoryById_test_exception() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResult = new ArrayList<>();
        expectedResult.add(MetadataHistoryModel.builder().build());
        Mockito.when(metadataHistoryService.getMetadataDetailsByAssetId(TestConstants.TEST_ID,
                filterRequestBody))
            .thenReturn(expectedResult);
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE))
            .when(metadataHistoryMapper)
            .getAllAssetByAssetId(TestConstants.TEST_ID, filterRequestBody);
        assertThrows(RuntimeException.class,
            () -> metadataHistoryService.getMetadataDetailsByAssetId(TestConstants.TEST_ID,
                filterRequestBody));
    }

    @Test
    void testAddMetadataHistoryWithValidRequest() {
        List<AssetKeyDto> assets = new ArrayList<>();
        doNothing().when(assetDetailsService).updateAssetTable(assets);
        metadataHistoryService.addMetadataHistory(validAssetReq);

        verify(metadataHistoryMapper, times(1)).addAssetHistory(validAssetReq);
    }

    @Test
    void testAddMetadataHistoryWithNullAssetIdThrowsException() {
        MetadataHistoryRequestDto request = MetadataHistoryRequestDto.builder()
            .updatedBy(TestConstants.TEST_UPD_BY)
            .assetId(null)
            .changes(TestConstants.TEST_JSON_CHANGES)
            .txnOccDate(Instant.now())
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();
        List<AssetKeyDto> assets = new ArrayList<>();
        doNothing().when(assetDetailsService).updateAssetTable(assets);
        assertThrows(IllegalArgumentException.class,
            () -> metadataHistoryService.addMetadataHistory(request));
    }

    @Test
    void testGetFilters() {
        List<String> tiList = new ArrayList<>();
        when(metadataHistoryMapper.getTechIntegrators()).thenReturn(tiList);

        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.TI_NAME, tiList);
        expectedFilters.put(Constants.CP_KEY, new ArrayList<>());
        Map<String, List<String>> actualFilters = metadataHistoryService.getFilters();
        assertEquals(expectedFilters, actualFilters);
    }


}