package com.cms.history.licensehistory.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.constant.TestConstants;
import com.cms.history.licensehistory.dto.LicenseHistoryChangesDto;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import com.cms.history.licensehistory.mapper.LicenseHistoryMapper;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class LicenseHistoryServiceImplTest {


    @InjectMocks
    private LicenseHistoryServiceImpl licenseHistoryService;

    @Mock
    private LicenseHistoryMapper licenseHistoryMapper;
    @Mock
    private AssetDetailsService assetDetailsService;

    private LicenseHistoryRequestDto validHistoryRequest;
    private LicenseHistoryRequestDto historyRequestMissingAssetId;
    private LicenseHistoryRequestDto nullAssetIdHistoryRequest;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        validHistoryRequest = LicenseHistoryRequestDto.builder()
            .assetId(TestConstants.TEST_ID)
            .changeDateTime(Instant.now())
            .releaseDate(TestConstants.TEST_RELEASE_DATE)
            .expiryDate(TestConstants.TEST_EXP_DATE)
            .oldStatus(TestConstants.TEST_STATUS)
            .updatedBy(TestConstants.TEST_UPD_BY)
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();
        historyRequestMissingAssetId = LicenseHistoryRequestDto.builder()
            .changeDateTime(Instant.now())
            .releaseDate(TestConstants.TEST_RELEASE_DATE)
            .expiryDate(TestConstants.TEST_EXP_DATE)
            .oldStatus(TestConstants.TEST_STATUS)
            .updatedBy(TestConstants.TEST_UPD_BY)
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();

        nullAssetIdHistoryRequest = new LicenseHistoryRequestDto();
        nullAssetIdHistoryRequest.setChangeDateTime(Instant.now());
    }

    @Test
    void getLicenseHistory_test_success() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<LicenseHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(LicenseHistoryResponseDto.builder().build());
        when(licenseHistoryMapper.getLicenseHistory(filterRequestBody))
            .thenReturn(expectedResult);

        List<LicenseHistoryResponseDto> actualResult = licenseHistoryService.getLicenseHistory(
            filterRequestBody);

        assertEquals(expectedResult, actualResult);
        verify(licenseHistoryMapper).getLicenseHistory(filterRequestBody);
    }

    @Test
    void getLicenseHistory_test_exception() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<LicenseHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(LicenseHistoryResponseDto.builder().build());
        when(licenseHistoryMapper.getLicenseHistory(filterRequestBody))
            .thenReturn(expectedResult);
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE))
            .when(licenseHistoryMapper)
            .getLicenseHistory(filterRequestBody);
        assertThrows(RuntimeException.class,
            () -> licenseHistoryService.getLicenseHistory(filterRequestBody));
    }


    @Test
    void testInsertLicenseHistoryWithMissingAssetId() {
        assertThrows(IllegalArgumentException.class,
            () -> licenseHistoryService.insertLicenseHistory(historyRequestMissingAssetId));
    }

    @Test
    void insertLicenseHistory_nullAssetId_exceptionThrown() {
        assertThrows(IllegalArgumentException.class,
            () -> licenseHistoryService.insertLicenseHistory(nullAssetIdHistoryRequest));
    }

    @Test
    void testInsertLicenseHistoryWithValidInput() {

        licenseHistoryService.insertLicenseHistory(validHistoryRequest);

        verify(assetDetailsService).updateAssetTable(any(List.class));
        verify(licenseHistoryMapper).insertLicenseHistory(any(LicenseHistoryRequestDto.class));
    }

    @Test
    void testGetFilters() {
        List<String> tiList = new ArrayList<>();
        when(licenseHistoryMapper.getTechIntegrators()).thenReturn(tiList);

        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.ASSET_STATUS, Constants.ASSET_STATUS_FILTERS);
        expectedFilters.put(Constants.TI_NAME, tiList);
        expectedFilters.put(Constants.CP_KEY, new ArrayList<>());

        Map<String, List<String>> actualFilters = licenseHistoryService.getFilters();
        assertEquals(expectedFilters, actualFilters);
    }

    @Test
    void getLicenseHistory_emptyResult() {
        FilterRequestBodyDto invalidHistoryRequest = FilterRequestBodyDto.builder().build();
        ArrayList<LicenseHistoryResponseDto> emptyArray = new ArrayList<>();
        when(licenseHistoryMapper.getLicenseHistory(invalidHistoryRequest)).thenReturn(
            emptyArray);

        assertEquals(emptyArray, licenseHistoryService.getLicenseHistory(invalidHistoryRequest));


    }

    @Test
    void getLicenseHistory_nullResult() {
        FilterRequestBodyDto invalidHistoryRequest = FilterRequestBodyDto.builder().build();
        when(licenseHistoryMapper.getLicenseHistory(invalidHistoryRequest)).thenReturn(
            null);

        assertNull(licenseHistoryService.getLicenseHistory(invalidHistoryRequest));


    }

    @Test
    void getLicenseHistoryById_test_success() {
        List<LicenseHistoryChangesDto> expectedResult = new ArrayList<>();
        expectedResult.add(LicenseHistoryChangesDto.builder().build());
        when(licenseHistoryMapper.getLicenseHistoryByAssetId(TestConstants.TEST_ID))
            .thenReturn(expectedResult);

        List<LicenseHistoryChangesDto> actualResult = licenseHistoryService.getLicenseHistoryByAssetId(
            TestConstants.TEST_ID);

        assertEquals(expectedResult, actualResult);
        verify(licenseHistoryMapper).getLicenseHistoryByAssetId(TestConstants.TEST_ID);
    }

    @Test
    void testGetLicenseHistoryByAssetId_emptyList() {

        List<LicenseHistoryChangesDto> expectedHistories = List.of();

        when(licenseHistoryMapper.getLicenseHistoryByAssetId(TestConstants.TEST_ID))
            .thenReturn(expectedHistories);

        List<LicenseHistoryChangesDto> actualHistories = licenseHistoryService.getLicenseHistoryByAssetId(
            TestConstants.TEST_ID);

        assertNotNull(actualHistories);
        assertEquals(0, actualHistories.size());
    }

    @Test
    void getLicenseHistoryById_emptyResult() {
        ArrayList<LicenseHistoryChangesDto> emptyArray = new ArrayList<>();
        when(licenseHistoryMapper.getLicenseHistoryByAssetId(TestConstants.TEST_ID)).thenReturn(
            emptyArray);
        assertEquals(emptyArray,
            licenseHistoryService.getLicenseHistoryByAssetId(TestConstants.TEST_ID));
    }

    @Test
    void getLicenseHistoryById_nullResult() {
        when(licenseHistoryMapper.getLicenseHistoryByAssetId(TestConstants.TEST_ID)).thenReturn(
            null);

        assertNull(
            licenseHistoryService.getLicenseHistoryByAssetId(TestConstants.TEST_ID));

    }


}