package com.cms.history.statushistory.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cms.history.constant.TestConstants;
import java.time.Instant;
import org.junit.jupiter.api.Test;


class StatusHistoryModelTest {

    @Test
    void testAllArgs() {
        StatusHistoryModel statusHistoryModel = new StatusHistoryModel(TestConstants.TEST_ID,
            Instant.now(),
            TestConstants.TEST_OLD_STATUS,
            TestConstants.TEST_NEW_STATUS,
            TestConstants.TEST_UPD_BY,
            TestConstants.TEST_UPD_BY,
            TestConstants.TEST_MASTER_STATUS
        );
        assertEquals(TestConstants.TEST_ID, statusHistoryModel.getAssetId());
        assertEquals(TestConstants.TEST_OLD_STATUS, statusHistoryModel.getOldStatus());
        assertEquals(TestConstants.TEST_NEW_STATUS, statusHistoryModel.getNewStatus());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getUpdatedBy());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getIdentifierId());
        assertEquals(TestConstants.TEST_MASTER_STATUS, statusHistoryModel.getMasterStatus());
        assertNotNull(statusHistoryModel.getChangeDateTime());


    }

    @Test
    void testBuilder() {
        StatusHistoryModel statusHistoryModel = StatusHistoryModel.builder()
            .assetId(TestConstants.TEST_ID)
            .changeDateTime(Instant.now())
            .oldStatus(TestConstants.TEST_OLD_STATUS)
            .newStatus(TestConstants.TEST_NEW_STATUS)
            .updatedBy(TestConstants.TEST_UPD_BY)
            .identifierId(TestConstants.TEST_UPD_BY)
            .masterStatus(TestConstants.TEST_MASTER_STATUS)
            .build();

        assertEquals(TestConstants.TEST_ID, statusHistoryModel.getAssetId());
        assertEquals(TestConstants.TEST_OLD_STATUS, statusHistoryModel.getOldStatus());
        assertEquals(TestConstants.TEST_NEW_STATUS, statusHistoryModel.getNewStatus());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getUpdatedBy());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getIdentifierId());
        assertEquals(TestConstants.TEST_MASTER_STATUS, statusHistoryModel.getMasterStatus());
        assertNotNull(statusHistoryModel.getChangeDateTime());

    }

    @Test
    void testGetterSetter() {
        StatusHistoryModel statusHistoryModel = new StatusHistoryModel();
        statusHistoryModel.setAssetId(TestConstants.TEST_ID);
        statusHistoryModel.setChangeDateTime(Instant.now());
        statusHistoryModel.setOldStatus(TestConstants.TEST_OLD_STATUS);
        statusHistoryModel.setNewStatus(TestConstants.TEST_NEW_STATUS);
        statusHistoryModel.setUpdatedBy(TestConstants.TEST_UPD_BY);
        statusHistoryModel.setIdentifierId(TestConstants.TEST_UPD_BY);
        statusHistoryModel.setMasterStatus(TestConstants.TEST_MASTER_STATUS);

        assertEquals(TestConstants.TEST_ID, statusHistoryModel.getAssetId());
        assertEquals(TestConstants.TEST_OLD_STATUS, statusHistoryModel.getOldStatus());
        assertEquals(TestConstants.TEST_NEW_STATUS, statusHistoryModel.getNewStatus());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getUpdatedBy());
        assertEquals(TestConstants.TEST_UPD_BY, statusHistoryModel.getIdentifierId());
        assertEquals(TestConstants.TEST_MASTER_STATUS, statusHistoryModel.getMasterStatus());
        assertNotNull(statusHistoryModel.getChangeDateTime());


    }
}