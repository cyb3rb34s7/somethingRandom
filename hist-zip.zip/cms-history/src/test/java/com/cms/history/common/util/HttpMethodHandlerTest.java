package com.cms.history.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.cms.history.common.exception.AssetApiFailureException;
import com.cms.history.common.exception.CustomException;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.constant.TestConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

class HttpMethodHandlerTest {

    @InjectMocks
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleHttpExchangeSuccess() {

        HttpEntity<?> httpEntity = new HttpEntity<>(null);

        ResponseEntity<ResponseDto> expectedResponse = ResponseEntity.ok(new ResponseDto());

        when(restTemplate.exchange(eq(TestConstants.ENDPOINT), eq(HttpMethod.GET),
            any(HttpEntity.class),
            eq(ResponseDto.class)))
            .thenReturn(expectedResponse);

        ResponseEntity<ResponseDto> response = httpMethodHandler.handleHttpExchange(
            TestConstants.ENDPOINT,
            TestConstants.HTTP_METHOD, httpEntity, ResponseDto.class);
        assertEquals(expectedResponse, response);
    }

    @Test
    void testHandleHttpExchangeFailure() {

        HttpEntity<?> httpEntity = new HttpEntity<>(null);
        doThrow(new RestClientException("Error")).when(restTemplate)
            .exchange(eq(TestConstants.ENDPOINT), eq(HttpMethod.GET), any(HttpEntity.class),
                eq(ResponseDto.class));
        assertThrows(AssetApiFailureException.class, () ->
            httpMethodHandler.handleHttpExchange(TestConstants.ENDPOINT, TestConstants.HTTP_METHOD,
                httpEntity,
                ResponseDto.class)
        );
    }
}