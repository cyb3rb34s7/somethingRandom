package com.cms.history.licensehistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cms.history.constant.TestConstants;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class LicenseHistoryResponseDtoTest {

    @Test
    void testGettersAndSetters() {
        LicenseHistoryResponseDto dto = new LicenseHistoryResponseDto();

        dto.setAssetId(TestConstants.TEST_ID);
        dto.setMediaTitle(TestConstants.TEST_TITLE);
        dto.setType(TestConstants.TEST_TYPE);
        dto.setTiName(TestConstants.TEST_TI_NAME);
        dto.setContentPartner(TestConstants.TEST_CP_NAME);
        dto.setCurrentReleaseDate(TestConstants.TEST_RELEASE_DATE);
        dto.setCurrentExpiryDate(TestConstants.TEST_EXP_DATE);
        dto.setCurrentStatus(TestConstants.TEST_STATUS);
        dto.setLatestChangeDateTime(TestConstants.CHANGE_DATE);
        dto.setLatestUpdatedBy(TestConstants.TEST_UPD_BY);

        List<LicenseHistoryRequestDto> historyChanges = new ArrayList<>();
        historyChanges.add(new LicenseHistoryRequestDto());
        dto.setHistoryChanges(historyChanges);

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, dto.getMediaTitle());
        assertEquals(TestConstants.TEST_TYPE, dto.getType());
        assertEquals(TestConstants.TEST_TI_NAME, dto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, dto.getContentPartner());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getCurrentReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getCurrentExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getCurrentStatus());
        assertNotNull(dto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getLatestUpdatedBy());
        assertEquals(1, dto.getHistoryChanges().size());
    }

    @Test
    void testBuilder() {
        List<LicenseHistoryRequestDto> historyChanges = new ArrayList<>();
        historyChanges.add(new LicenseHistoryRequestDto());
        LicenseHistoryResponseDto dto = LicenseHistoryResponseDto.builder()
            .assetId(TestConstants.TEST_ID)
            .mediaTitle(TestConstants.TEST_TITLE)
            .type(TestConstants.TEST_TYPE)
            .tiName(TestConstants.TEST_TI_NAME)
            .contentPartner(TestConstants.TEST_CP_NAME)
            .currentReleaseDate(TestConstants.TEST_RELEASE_DATE)
            .currentExpiryDate(TestConstants.TEST_EXP_DATE)
            .currentStatus(TestConstants.TEST_STATUS)
            .latestChangeDateTime(TestConstants.CHANGE_DATE)
            .latestUpdatedBy(TestConstants.TEST_UPD_BY)
            .historyChanges(historyChanges)
            .build();

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, dto.getMediaTitle());
        assertEquals(TestConstants.TEST_TYPE, dto.getType());
        assertEquals(TestConstants.TEST_TI_NAME, dto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, dto.getContentPartner());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getCurrentReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getCurrentExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getCurrentStatus());
        assertNotNull(dto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getLatestUpdatedBy());
        assertEquals(1, dto.getHistoryChanges().size());
    }

    @Test
    void testAllArgsConstructor() {
        LicenseHistoryResponseDto dto = new LicenseHistoryResponseDto(
            TestConstants.TEST_ID,
            TestConstants.TEST_TITLE,
            TestConstants.TEST_TYPE,
            TestConstants.TEST_TI_NAME,
            TestConstants.TEST_CP_NAME,
            TestConstants.TEST_RELEASE_DATE,
            TestConstants.TEST_EXP_DATE,
            TestConstants.TEST_STATUS,
            TestConstants.CHANGE_DATE,
            TestConstants.TEST_UPD_BY,
            new ArrayList<>());

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, dto.getMediaTitle());
        assertEquals(TestConstants.TEST_TYPE, dto.getType());
        assertEquals(TestConstants.TEST_TI_NAME, dto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, dto.getContentPartner());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getCurrentReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getCurrentExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getCurrentStatus());
        assertNotNull(dto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getLatestUpdatedBy());
        assertEquals(0, dto.getHistoryChanges().size());
    }

}