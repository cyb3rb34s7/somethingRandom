package com.cms.history.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ErrorMessageUtilTest.class)
class ErrorMessageUtilTest {

    private Exception mockException;
    private Exception mockCauseException;

    @BeforeEach
    void setUp() {
        mockException = mock(Exception.class);
        mockCauseException = mock(Exception.class);
    }

    @Test
    void testGenerateErrMessage_WithValidMessage() {
        // Arrange
        String expectedMessage = "Mock Exception Message";
        when(mockException.getMessage()).thenReturn(expectedMessage);

        // Act
        String actualMessage = ErrorMessageUtil.generateErrMessage(mockException);

        // Assert
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void testGenerateErrMessage_WithNullMessageAndValidCauseMessage() {
        // Arrange
        String expectedCauseMessage = "Mock Cause Exception Message";
        when(mockException.getMessage()).thenReturn(null);
        when(mockException.getCause()).thenReturn(mockCauseException);
        when(mockCauseException.getMessage()).thenReturn(expectedCauseMessage);

        // Act
        String actualMessage = ErrorMessageUtil.generateErrMessage(mockException);

        // Assert
        assertEquals(expectedCauseMessage, actualMessage);
    }

    @Test
    void testGenerateErrMessage_WithNullMessageAndNotNullCause() {
        // Arrange
        when(mockException.getMessage()).thenReturn(null);
        when(mockException.getCause()).thenReturn(mockCauseException);
        when(mockCauseException.getMessage()).thenReturn(null);

        // Act
        String actualMessage = ErrorMessageUtil.generateErrMessage(mockException);

        // Assert
        assertEquals("Unknown error occurred", actualMessage);
    }

    @Test
    void testGenerateErrMessage_WithNullMessageAndNullCause() {
        // Arrange
        when(mockException.getMessage()).thenReturn(null);
        when(mockException.getCause()).thenReturn(null);

        // Act
        String actualMessage = ErrorMessageUtil.generateErrMessage(mockException);

        // Assert
        assertEquals("Unknown error occurred", actualMessage);
    }

    @Test
    void testGenerateErrMessage_NULL_POINTER_EXCEPTION() {
        Exception testException = new NullPointerException();
        assertEquals("Null pointer exception occurred", ErrorMessageUtil.generateErrMessage(testException));
    }

    @Test
    void testGenerateErrMessage_BLANK_MESSAGE() {
        Exception testException = new Exception("   ", new Throwable("test-throwable"));
        assertEquals("test-throwable", ErrorMessageUtil.generateErrMessage(testException));
    }
}