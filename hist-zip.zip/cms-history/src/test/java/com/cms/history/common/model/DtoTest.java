package com.cms.history.common.model;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetDetailsDto;
import com.cms.history.common.dto.AssetDetailsRequestDto;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.dto.PaginationDto;
import com.cms.history.common.dto.SortDto;
import com.cms.history.common.util.ModelDtoTestUtility;
import com.cms.history.eventhistory.dto.EventHistoryRequestDto;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.junit.jupiter.api.Test;

class DtoTest {

    @Test
    void testResponseDto()
        throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {

        Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        constructor.newInstance();

        ModelDtoTestUtility.testModelOrDto(ResponseDto.class);
    }

    @Test
    void testErrorResponseDto() {
        ModelDtoTestUtility.testModelOrDto(ErrorResponseDto.class);
    }

    @Test
    void testBaseResponseDto() {

        ModelDtoTestUtility.testModelOrDto(BaseResponseDto.class);
    }

    @Test
    void testMethodResDto() {
        ModelDtoTestUtility.testModelOrDto(MethodRes.class);
    }

    @Test
    void testAssetDetailsDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDetailsDto.class);
    }

    @Test
    void testAssetDetailsReqDto() {
        ModelDtoTestUtility.testModelOrDto(AssetDetailsRequestDto.class);
    }

    @Test
    void testAssetKeyDto() {
        ModelDtoTestUtility.testModelOrDto(AssetKeyDto.class);
    }

    @Test
    void testFilterDto() {
        ModelDtoTestUtility.testModelOrDto(FilterDto.class);
    }

    @Test
    void testFilterReqDto() {
        ModelDtoTestUtility.testModelOrDto(FilterRequestBodyDto.class);
    }

    @Test
    void testPaginationDto() {
        ModelDtoTestUtility.testModelOrDto(PaginationDto.class);
    }

    @Test
    void testSortDto() {
        ModelDtoTestUtility.testModelOrDto(SortDto.class);
    }

    @Test
    void testEventDto(){
        ModelDtoTestUtility.testModelOrDto(EventHistoryRequestDto.class);
    }
}