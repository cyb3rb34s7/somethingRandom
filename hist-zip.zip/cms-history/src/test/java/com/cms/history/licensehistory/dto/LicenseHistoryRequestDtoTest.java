package com.cms.history.licensehistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.constant.TestConstants;
import org.junit.jupiter.api.Test;

class LicenseHistoryRequestDtoTest {

    @Test
    void testAllArgsConstructor() {
        LicenseHistoryRequestDto dto = new LicenseHistoryRequestDto(
            TestConstants.TEST_ID,
            TestConstants.CHANGE_DATE,
            TestConstants.TEST_RELEASE_DATE,
            TestConstants.TEST_EXP_DATE,
            TestConstants.TEST_STATUS,
            TestConstants.TEST_UPD_BY,
            TestConstants.TEST_CNTRY_CD,
            TestConstants.TEST_CP_ID);

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.CHANGE_DATE, dto.getChangeDateTime());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getOldStatus());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }

    @Test
    void testBuilder() {
        LicenseHistoryRequestDto dto = LicenseHistoryRequestDto.builder()
            .assetId(TestConstants.TEST_ID)
            .changeDateTime(TestConstants.CHANGE_DATE)
            .releaseDate(TestConstants.TEST_RELEASE_DATE)
            .expiryDate(TestConstants.TEST_EXP_DATE)
            .oldStatus(TestConstants.TEST_STATUS)
            .updatedBy(TestConstants.TEST_UPD_BY)
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.CHANGE_DATE, dto.getChangeDateTime());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getOldStatus());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }

    @Test
    void testGettersAndSetters() {
        LicenseHistoryRequestDto dto = new LicenseHistoryRequestDto();

        dto.setAssetId(TestConstants.TEST_ID);
        dto.setChangeDateTime(TestConstants.CHANGE_DATE);
        dto.setReleaseDate(TestConstants.TEST_RELEASE_DATE);
        dto.setExpiryDate(TestConstants.TEST_EXP_DATE);
        dto.setOldStatus(TestConstants.TEST_STATUS);
        dto.setUpdatedBy(TestConstants.TEST_UPD_BY);
        dto.setCountryCode(TestConstants.TEST_CNTRY_CD);
        dto.setVcCpId(TestConstants.TEST_CP_ID);

        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals(TestConstants.CHANGE_DATE, dto.getChangeDateTime());
        assertEquals(TestConstants.TEST_RELEASE_DATE, dto.getReleaseDate());
        assertEquals(TestConstants.TEST_EXP_DATE, dto.getExpiryDate());
        assertEquals(TestConstants.TEST_STATUS, dto.getOldStatus());
        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }
}