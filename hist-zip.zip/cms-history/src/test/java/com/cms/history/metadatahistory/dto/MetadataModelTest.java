package com.cms.history.metadatahistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.constant.TestConstants;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import org.junit.jupiter.api.Test;

class MetadataModelTest {

    public static final String TEST_JSON_CHANGES = "Test";

    @Test
    void testAllArgsConstructor() {
        MetadataHistoryModel model = new MetadataHistoryModel(TestConstants.TEST_ID,
            TestConstants.TEST_TITLE
            , TestConstants.TEST_CP_NAME, TestConstants.TEST_TI_NAME, TestConstants.CHANGE_DATE,
            TEST_JSON_CHANGES
            , TestConstants.TEST_UPD_BY
        );

        assertEquals(TestConstants.TEST_ID, model.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, model.getMediaTitle());
        assertEquals(TestConstants.TEST_CP_NAME, model.getContentPartner());
        assertEquals(TestConstants.TEST_TI_NAME, model.getTiName());
        assertEquals(TestConstants.CHANGE_DATE, model.getChangeDateTime());
        assertEquals(TEST_JSON_CHANGES, model.getChanges());
        assertEquals(TestConstants.TEST_UPD_BY, model.getUpdatedBy());
    }

    @Test
    void testBuilder() {
        MetadataHistoryModel model = MetadataHistoryModel.builder()
            .assetId(TestConstants.TEST_ID)
            .mediaTitle(TestConstants.TEST_TITLE)
            .contentPartner(TestConstants.TEST_CP_NAME)
            .tiName(TestConstants.TEST_TI_NAME)
            .changeDateTime(TestConstants.CHANGE_DATE)
            .changes(TEST_JSON_CHANGES)
            .updatedBy(TestConstants.TEST_UPD_BY)
            .build();

        assertEquals(TestConstants.TEST_ID, model.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, model.getMediaTitle());
        assertEquals(TestConstants.TEST_CP_NAME, model.getContentPartner());
        assertEquals(TestConstants.TEST_TI_NAME, model.getTiName());
        assertEquals(TestConstants.CHANGE_DATE, model.getChangeDateTime());
        assertEquals(TEST_JSON_CHANGES, model.getChanges());
        assertEquals(TestConstants.TEST_UPD_BY, model.getUpdatedBy());
    }

    @Test
    void testGettersAndSetters() {
        MetadataHistoryModel model = new MetadataHistoryModel();

        model.setAssetId(TestConstants.TEST_ID);
        model.setMediaTitle(TestConstants.TEST_TITLE);
        model.setContentPartner(TestConstants.TEST_CP_NAME);
        model.setTiName(TestConstants.TEST_TI_NAME);
        model.setChangeDateTime(TestConstants.CHANGE_DATE);
        model.setChanges(TEST_JSON_CHANGES);
        model.setUpdatedBy(TestConstants.TEST_UPD_BY);

        assertEquals(TestConstants.TEST_ID, model.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, model.getMediaTitle());
        assertEquals(TestConstants.TEST_CP_NAME, model.getContentPartner());
        assertEquals(TestConstants.TEST_TI_NAME, model.getTiName());
        assertEquals(TestConstants.CHANGE_DATE, model.getChangeDateTime());
        assertEquals(TEST_JSON_CHANGES, model.getChanges());
        assertEquals(TestConstants.TEST_UPD_BY, model.getUpdatedBy());
    }
}
