package com.cms.history.statushistory.util;

import com.cms.history.statushistory.model.StatusHistoryModel;
import java.time.Instant;

public class DummyAssetModelGenerator {


    public static StatusHistoryModel generateAssetStatusHistoryDummy(String assetId) {

        StatusHistoryModel model = new StatusHistoryModel(
            "UA8088",
            Instant.now(),
            "QC Fail",
            "QC Pass",
            "deepak.jain@samsung.com",
            "Id001",
            "Post");
        return model;

    }


}
