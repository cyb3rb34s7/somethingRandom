package com.cms.history.common.util;

import static com.cms.history.common.util.Utils.getLicenseWindow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.common.constants.Constants;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.Test;


class UtilsTest {

    @Test
    void testGetLicenseWindow_StartInFuture_Upcoming()
        throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Constructor<Utils> constructor = Utils.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        constructor.newInstance();
        Instant futureDate = Instant.now().plus(30, ChronoUnit.DAYS);
        String startDate = formatDate(futureDate);
        String expDate = formatDate(futureDate.plus(365, ChronoUnit.DAYS));
        assertEquals(Constants.UPCOMING_IN + "29 days", getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_StartInFuture_Upcoming_1Day() {
        Instant futureDate = Instant.now().plus(2, ChronoUnit.DAYS);
        String startDate = formatDate(futureDate);
        assertEquals(Constants.UPCOMING_IN + "1 day", getLicenseWindow(startDate, null));
    }

    @Test
    void testGetLicenseWindow_StartInFuture_UpcomingAfterThreshold() {
        Instant futureDate = Instant.now().plus(400, ChronoUnit.DAYS);
        String startDate = formatDate(futureDate);
        String expDate = formatDate(futureDate.plus(365, ChronoUnit.DAYS));
        assertEquals(Constants.UPCOMING_AFTER_300_DAYS, getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_StartInPast_Active() {
        Instant pastDate = Instant.now().minus(365, ChronoUnit.DAYS);
        String startDate = formatDate(pastDate);
        String expDate = formatDate(Instant.now().plus(365, ChronoUnit.DAYS));
        assertEquals(Constants.ACTIVE, getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_StartInPast_ExpiringSoon() {
        Instant pastDate = Instant.now().minus(365, ChronoUnit.DAYS);
        String startDate = formatDate(pastDate);
        String expDate = formatDate(Instant.now().plus(30, ChronoUnit.DAYS));
        assertEquals(Constants.EXPIRING_IN + "29 days", getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_StartInPast_Expiring1Day() {
        Instant pastDate = Instant.now().minus(365, ChronoUnit.DAYS);
        String startDate = formatDate(pastDate);
        String expDate = formatDate(Instant.now().plus(2, ChronoUnit.DAYS));
        assertEquals(Constants.EXPIRING_IN + "1 day", getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_StartInPast_ExpiringFar() {
        Instant pastDate = Instant.now().minus(365, ChronoUnit.DAYS);
        String startDate = formatDate(pastDate);
        String expDate = formatDate(pastDate.plus(730, ChronoUnit.DAYS));
        assertEquals(Constants.ACTIVE, getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_Expired() {
        Instant pastDate = Instant.now().minus(1, ChronoUnit.DAYS);
        String startDate = formatDate(pastDate);
        String expDate = formatDate(pastDate.minus(1, ChronoUnit.DAYS));
        assertEquals(Constants.EXPIRED, getLicenseWindow(startDate, expDate));
    }

    @Test
    void testGetLicenseWindow_NullStartDate() {
        String expDate = formatDate(Instant.now().plus(365, ChronoUnit.DAYS));
        assertEquals("", getLicenseWindow(null, expDate));
    }

    @Test
    void testGetLicenseWindow_NullEndDate() {
        Instant date = Instant.now().minus(365, ChronoUnit.DAYS);
        String startDate = formatDate(date);
        assertEquals(Constants.ACTIVE, getLicenseWindow(startDate, null));
    }


    private static String formatDate(Instant instant) {
        return LocalDateTime.ofInstant(instant, ZoneId.of("UTC"))
            .format(DateTimeFormatter.ofPattern(Constants.EXPIRY_DATE_FORMAT));
    }


}