package com.cms.history.metadatahistory.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.metadatahistory.dto.MetadataHistoryRequestDto;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import com.cms.history.metadatahistory.service.MetadataHistoryService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


class MetadataHistoryControllerTest {

    private static final String TEST_ASSET_ID = "TEST";

    @Mock
    private MetadataHistoryService metadataHistoryService;

    @InjectMocks
    private MetadataHistoryController metadataHistoryController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFilteredMetadataList_success() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResponse = new ArrayList<>();
        MetadataHistoryModel metadataHistoryModel = MetadataHistoryModel.builder().build();
        metadataHistoryModel.setAssetId(TEST_ASSET_ID);
        expectedResponse.add(metadataHistoryModel);
        Map<String, Object> map = new HashMap<>();
        map.put("data", expectedResponse);
        map.put("count",0) ;
        ResponseDto expected = ResponseHandler.processSuccess(map);
        Mockito.when(metadataHistoryService.getAllMetadata(filterRequestBody))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = metadataHistoryController.getAllMetadata(
            filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());


    }

    @Test
    void testGetFilteredMetadataListNullResponse() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Map<String, Object> map = new HashMap<>();
        map.put("data", null);
        map.put("count",0) ;
        ResponseDto expected = ResponseHandler.processSuccess(map);
        Mockito.when(metadataHistoryService.getAllMetadata(filterRequestBody))
            .thenReturn(null);

        ResponseDto actualResponse = metadataHistoryController.getAllMetadata(
            filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());


    }

    @Test
    void testGetFilteredMetadataList_ExceptionalCase() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Mockito.when(metadataHistoryService.getAllMetadata(filterRequestBody))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> metadataHistoryController.getAllMetadata(filterRequestBody));
    }

    @Test
    void testGetFilteredMetadataById_success() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<MetadataHistoryModel> expectedResponse = new ArrayList<>();
        MetadataHistoryModel metadataHistoryModel = MetadataHistoryModel.builder().build();
        metadataHistoryModel.setAssetId(TEST_ASSET_ID);
        expectedResponse.add(metadataHistoryModel);
        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            expectedResponse);
        Mockito.when(
                metadataHistoryService.getMetadataDetailsByAssetId(TEST_ASSET_ID, filterRequestBody))
            .thenReturn(expectedResponse);

        ResponseDto actualResponse = metadataHistoryController.getHistoryByAssetId(TEST_ASSET_ID,
            filterRequestBody);

        assertEquals(expected.getRsp().getPayload(), actualResponse.getRsp().getPayload());


    }

    @Test
    void testGetFilteredMetadataById_ExceptionalCase() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        Mockito.when(
                metadataHistoryService.getMetadataDetailsByAssetId(TEST_ASSET_ID, filterRequestBody))
            .thenThrow(new RuntimeException(ErrorMsg.BAD_REQUEST));

        assertThrows(RuntimeException.class,
            () -> metadataHistoryController.getHistoryByAssetId(TEST_ASSET_ID, filterRequestBody));
    }

    @Test
    void testMetadataInsertion() {
        MetadataHistoryRequestDto historyRequest = MetadataHistoryRequestDto.builder().build();
        historyRequest.setAssetId(TEST_ASSET_ID);
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getAssetId());

        Mockito.doNothing().when(metadataHistoryService).addMetadataHistory(historyRequest);

        ResponseDto response = metadataHistoryController.addHistory(historyRequest);
        assertEquals(expectedResponse.getRsp().getPayload(), response.getRsp().getPayload());

    }

    @Test
    void testInsert_exception() {
        MetadataHistoryRequestDto historyRequest = MetadataHistoryRequestDto.builder().build();

        Mockito.doThrow(new RuntimeException()).when(metadataHistoryService)
            .addMetadataHistory(historyRequest);

        assertThrows(RuntimeException.class,
            () -> metadataHistoryController.addHistory(historyRequest));


    }

    @Test
    void testGetFilters_success() {
        List<String> tiList = new ArrayList<>();
        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.TI_NAME, tiList);

        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.FILTER_KEY,
            expectedFilters);
        Mockito.when(metadataHistoryService.getFilters()).thenReturn(expectedFilters);

        ResponseDto actual = metadataHistoryController.getFilters();

        assertEquals(expected.getRsp().getPayload(), actual.getRsp().getPayload());
        Mockito.verify(metadataHistoryService, Mockito.times(1)).getFilters();

    }

    @Test
    void testGetFilters_exception() {
        ResponseDto err = ResponseHandler.processMethodResponse(new RuntimeException());
        Mockito.when(metadataHistoryService.getFilters()).thenThrow(new RuntimeException());
        assertThrows(RuntimeException.class, () -> metadataHistoryController.getFilters());
        assertNotNull(err.getRsp().getErr());
    }


    @Test
    void testHealthCheck() {
        assertDoesNotThrow(()-> metadataHistoryController.healthCheck());
    }



}

