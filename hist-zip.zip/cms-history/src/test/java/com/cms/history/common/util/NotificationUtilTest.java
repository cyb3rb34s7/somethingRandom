package com.cms.history.common.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class NotificationUtilTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private NotificationUtil notificationUtil;


    private static final String NOTIFICATION_SERVER_URL = "http://localhost:8080";
    private static final String REGION = "us-east-1";

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(notificationUtil, "notificationServerUrl",
            NOTIFICATION_SERVER_URL);
        ReflectionTestUtils.setField(notificationUtil, "region", REGION);
    }

    @Test
    void sendErrorMail_shouldCallNotificationEndpoint() {
        Mockito.when(restTemplate.exchange(
            Mockito.anyString(),
            Mockito.any(HttpMethod.class),
            Mockito.any(HttpEntity.class),
            Mockito.any(Class.class)
        )).thenReturn(ResponseEntity.ok(""));
        Assertions.assertDoesNotThrow(
            () -> notificationUtil.sendErrorMail(new Exception("test"), "type", "code"));
    }

    @Test
    void sendErrorMail_FailRequest() {
        Mockito.when(restTemplate.exchange(
            Mockito.anyString(),
            Mockito.any(HttpMethod.class),
            Mockito.any(HttpEntity.class),
            Mockito.any(Class.class)
        )).thenThrow(new RuntimeException());
        Assertions.assertDoesNotThrow(
            () -> notificationUtil.sendErrorMail(new Exception("test"), "type", "code"));
    }

    @Test
    void sendAlarm_shouldCallAlarmEndpoint() {
        Mockito.when(restTemplate.exchange(
            Mockito.anyString(),
            Mockito.any(HttpMethod.class),
            Mockito.any(HttpEntity.class),
            Mockito.any(Class.class)
        )).thenReturn(ResponseEntity.ok(""));
        Assertions.assertDoesNotThrow(
            () -> notificationUtil.sendAlarm(new Exception("test"), "type", "code"));
    }

    @Test
    void sendAlarm_Fails() {
        Mockito.when(restTemplate.exchange(
            Mockito.anyString(),
            Mockito.any(HttpMethod.class),
            Mockito.any(HttpEntity.class),
            Mockito.any(Class.class)
        )).thenThrow(new RuntimeException());
        Assertions.assertDoesNotThrow(
            () -> notificationUtil.sendAlarm(new Exception("test"), "type", "code"));
    }
}