package com.cms.history.metadatahistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.history.constant.TestConstants;
import org.junit.jupiter.api.Test;

class MetadataHistoryRequestDtoTest {

    @Test
    void testAllArgsConstructor() {
        MetadataHistoryRequestDto dto = new MetadataHistoryRequestDto(TestConstants.TEST_UPD_BY,
            TestConstants.TEST_ID,
            "changes made",
            TestConstants.CHANGE_DATE,
            TestConstants.TEST_CNTRY_CD,
            TestConstants.TEST_CP_ID
        );

        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals("changes made", dto.getChanges());
        assertEquals(TestConstants.CHANGE_DATE, dto.getTxnOccDate());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }

    @Test
    void testBuilder() {
        MetadataHistoryRequestDto dto = MetadataHistoryRequestDto.builder()
            .updatedBy(TestConstants.TEST_UPD_BY)
            .assetId(TestConstants.TEST_ID)
            .changes("changes made")
            .txnOccDate(TestConstants.CHANGE_DATE)
            .countryCode(TestConstants.TEST_CNTRY_CD)
            .vcCpId(TestConstants.TEST_CP_ID)
            .build();

        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals("changes made", dto.getChanges());
        assertEquals(TestConstants.CHANGE_DATE, dto.getTxnOccDate());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }

    @Test
    void testGettersAndSetters() {
        MetadataHistoryRequestDto dto = new MetadataHistoryRequestDto();

        // Set values
        dto.setUpdatedBy(TestConstants.TEST_UPD_BY);
        dto.setAssetId(TestConstants.TEST_ID);
        dto.setChanges("new changes");
        dto.setTxnOccDate(TestConstants.CHANGE_DATE);
        dto.setCountryCode(TestConstants.TEST_CNTRY_CD);
        dto.setVcCpId(TestConstants.TEST_CP_ID);

        // Get values and assert
        assertEquals(TestConstants.TEST_UPD_BY, dto.getUpdatedBy());
        assertEquals(TestConstants.TEST_ID, dto.getAssetId());
        assertEquals("new changes", dto.getChanges());
        assertEquals(TestConstants.CHANGE_DATE, dto.getTxnOccDate());
        assertEquals(TestConstants.TEST_CNTRY_CD, dto.getCountryCode());
        assertEquals(TestConstants.TEST_CP_ID, dto.getVcCpId());
    }
}