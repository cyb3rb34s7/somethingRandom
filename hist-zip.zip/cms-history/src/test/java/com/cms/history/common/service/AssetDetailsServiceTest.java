package com.cms.history.common.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetDetailsDto;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.exception.AssetApiFailureException;
import com.cms.history.common.mapper.AssetDetailsMapper;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.HttpMethodHandler;
import com.cms.history.common.util.ResponseHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

class AssetDetailsServiceTest {

    @Mock
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private AssetDetailsMapper assetDetailsMapper;

    @InjectMocks
    private AssetDetailsService assetDetailsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

    }

    @Test
    void testUpdateAssetTable_success() {

        List<AssetKeyDto> assets = Arrays.asList(new AssetKeyDto(), new AssetKeyDto());
        List<AssetDetailsDto> assetDetails = new ArrayList<>();
        AssetDetailsDto assetDetail = new AssetDetailsDto();
        assetDetails.add(assetDetail);

        ResponseDto responseDto = ResponseHandler.processMethodResponse(Constants.ASSETS_KEY,
            assetDetails);
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, null,
            200);
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            any(Class.class))).thenReturn(responseEntity);
        doNothing().when(assetDetailsMapper).updateAssetTable(assetDetails);

        assetDetailsService.updateAssetTable(assets);

        assertDoesNotThrow(() -> assetDetailsService.updateAssetTable(assets));

    }

    @Test
    void testUpdateAssetTable_emptyResponse_success() {

        List<AssetKeyDto> assets = Arrays.asList(new AssetKeyDto(), new AssetKeyDto());
        List<AssetDetailsDto> assetDetails = new ArrayList<>();

        ResponseDto responseDto = ResponseHandler.processMethodResponse(Constants.ASSETS_KEY,
            assetDetails);
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, null,
            200);
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            any(Class.class))).thenReturn(responseEntity);
        doNothing().when(assetDetailsMapper).updateAssetTable(assetDetails);

        assetDetailsService.updateAssetTable(assets);

        assertDoesNotThrow(() -> assetDetailsService.updateAssetTable(assets));

    }

    @Test
    void testUpdateAssetTable_exception() {

        List<AssetKeyDto> assets = Arrays.asList(new AssetKeyDto(), new AssetKeyDto());
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(null, null, 500);
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            any(Class.class))).thenReturn(responseEntity);
        assertThrows(AssetApiFailureException.class,
            () -> assetDetailsService.updateAssetTable(assets));
    }
}