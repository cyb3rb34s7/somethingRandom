package com.cms.history.lockHistory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.lockHistory.model.LockHistoryRequestDto;
import com.cms.history.lockHistory.model.LockHistoryRequestDto.LockChange;
import com.cms.history.lockHistory.service.LockHistoryService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class LockHistoryControllerTest {

    private static final String TEST_CONTENT_ID = "TEST_CONTENT_123";

    @Mock
    private LockHistoryService lockHistoryService;

    @InjectMocks
    private LockHistoryController lockHistoryController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddLockChangeHistory_success() {
        LockHistoryRequestDto request = LockHistoryRequestDto.builder()
            .contentId(TEST_CONTENT_ID)
            .changes(List.of(new LockChange()))
            .build();

        ResponseDto expected = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY.toLowerCase() + TEST_CONTENT_ID);

        doNothing().when(lockHistoryService).addLockChangeHistory(request);

        ResponseDto actual = lockHistoryController.addLockChangeHistory(request);
        assertEquals(expected.getRsp().getPayload(), actual.getRsp().getPayload());
    }

    @Test
    void testAddLockChangeHistory_exception() {
        LockHistoryRequestDto request = LockHistoryRequestDto.builder()
            .contentId(TEST_CONTENT_ID)
            .build();

        doThrow(new RuntimeException()).when(lockHistoryService).addLockChangeHistory(request);

        assertThrows(RuntimeException.class,
            () -> lockHistoryController.addLockChangeHistory(request));
    }
}
