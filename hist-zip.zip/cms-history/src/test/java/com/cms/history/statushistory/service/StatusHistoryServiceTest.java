package com.cms.history.statushistory.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.constant.TestConstants;
import com.cms.history.statushistory.dto.StatusHistoryRequestDto;
import com.cms.history.statushistory.dto.StatusHistoryResponseDto;
import com.cms.history.statushistory.mapper.StatusHistoryMapper;
import com.cms.history.statushistory.model.StatusHistoryModel;
import com.cms.history.statushistory.util.DummyStatusDtoGenerator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


class StatusHistoryServiceTest {

    @InjectMocks
    private StatusHistoryService assetHistoryService;

    @Mock
    private StatusHistoryMapper assetMapper;

    @Mock
    private AssetDetailsService assetDetailsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFilteredAssetTest() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(new StatusHistoryResponseDto());
        Mockito.when(assetMapper.getAllAssetStatus(filterRequestBody)).thenReturn(expectedResult);
        List<StatusHistoryResponseDto> actualResult = assetHistoryService.getAllAssetStatus(
            filterRequestBody);

        assertEquals(expectedResult, actualResult);
        Mockito.verify(assetMapper).getAllAssetStatus(filterRequestBody);
    }


    @Test
    void testGetAllFilteredStatusHistory_Exception() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(new StatusHistoryResponseDto());
        Mockito.when(assetHistoryService.getAllAssetStatus(filterRequestBody))
            .thenReturn(expectedResult);
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE)).when(assetMapper)
            .getAllAssetStatus(filterRequestBody);

        assertThrows(RuntimeException.class,
            () -> assetHistoryService.getAllAssetStatus(filterRequestBody));
    }

    @Test
    void testGetAllFilteredAssetHistory_WithEmptyFilterRequestBody() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        Mockito.when(assetMapper.getAllAssetStatus(filterRequestBody)).thenReturn(expectedResult);

        List<StatusHistoryResponseDto> actualResult = assetHistoryService.getAllAssetStatus(
            filterRequestBody);

        assertEquals(expectedResult, actualResult);
        Mockito.verify(assetMapper).getAllAssetStatus(filterRequestBody);
    }


    @Test
    void testCreateAssetStatusHistory() throws Exception {
        StatusHistoryRequestDto dto = DummyStatusDtoGenerator.generateAssetDummy();
        Mockito.doNothing().when(assetMapper).addStatusHistory(anyList());
        Mockito.doNothing().when(assetDetailsService).updateAssetTable(any(List.class));
        int actualResult = assetHistoryService.addStatusHistory(dto);
        assertEquals(1, actualResult);
    }

    @Test
    void testAddStatusHistoryWithNoChanges() {
        String updatedBy = TestConstants.TEST_UPD_BY;

        StatusHistoryRequestDto request = new StatusHistoryRequestDto(updatedBy, null);

        Exception exception = assertThrows(IllegalArgumentException.class,
            () -> assetHistoryService.addStatusHistory(request));
        assertEquals("No changes found", exception.getMessage());
    }


    @Test
    void testCreateAssetStatusHistory_Exception() {
        StatusHistoryRequestDto dto = DummyStatusDtoGenerator.generateAssetDummy();
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE)).when(assetMapper)
            .addStatusHistory(anyList());
        assertThrows(RuntimeException.class, () -> assetHistoryService.addStatusHistory(dto));
    }

    @Test
    void testGetFilters() {
        List<String> tiList = new ArrayList<>();
        when(assetMapper.getTechIntegrators()).thenReturn(tiList);

        Map<String, List<String>> expectedFilters = new HashMap<>();
        expectedFilters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        expectedFilters.put(Constants.TI_NAME, tiList);
        expectedFilters.put(Constants.CP_KEY, new ArrayList<>());
        Map<String, List<String>> actualFilters = assetHistoryService.getFilters();
        assertEquals(expectedFilters, actualFilters);
    }

    @Test
    void testGetAllFilteredAssetByIdTest() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryModel> expectedResult = new ArrayList<>();
        expectedResult.add(new StatusHistoryModel());
        Mockito.when(
                assetMapper.getStatusHistoryByAssetId(TestConstants.TEST_ID))
            .thenReturn(expectedResult);
        List<StatusHistoryModel> actualResult = assetHistoryService.getStatusHistoryByAssetId(
            TestConstants.TEST_ID);

        assertEquals(expectedResult, actualResult);
        Mockito.verify(assetMapper)
            .getStatusHistoryByAssetId(TestConstants.TEST_ID);
    }

    @Test
    void exportAssetStatusHistoryTest() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(new StatusHistoryResponseDto());
        Mockito.when(assetMapper.getStatusHistoryForExport(filterRequestBody)).thenReturn(expectedResult);
        List<StatusHistoryResponseDto> actualResult = assetHistoryService.getStatusHistoryForExport(
            filterRequestBody);

        assertEquals(expectedResult, actualResult);
        Mockito.verify(assetMapper).getStatusHistoryForExport(filterRequestBody);
    }


    @Test
    void exportAssetStatusHistoryTest_Exception() {
        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        expectedResult.add(new StatusHistoryResponseDto());
        Mockito.when(assetHistoryService.getStatusHistoryForExport(filterRequestBody))
            .thenReturn(expectedResult);
        Mockito.doThrow(new RuntimeException(TestConstants.TEST_ERROR_MESSAGE)).when(assetMapper)
            .getStatusHistoryForExport(filterRequestBody);

        assertThrows(RuntimeException.class,
            () -> assetHistoryService.getStatusHistoryForExport(filterRequestBody));
    }

    @Test
    void exportAssetStatusHistoryTest_WithEmptyFilterRequestBody() {

        FilterRequestBodyDto filterRequestBody = FilterRequestBodyDto.builder().build();
        List<StatusHistoryResponseDto> expectedResult = new ArrayList<>();
        Mockito.when(assetMapper.getStatusHistoryForExport(filterRequestBody)).thenReturn(expectedResult);

        List<StatusHistoryResponseDto> actualResult = assetHistoryService.getStatusHistoryForExport(
            filterRequestBody);

        assertEquals(expectedResult, actualResult);
        Mockito.verify(assetMapper).getStatusHistoryForExport(filterRequestBody);
    }




}