package com.cms.history.statushistory.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.history.constant.TestConstants;
import java.time.Instant;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;

class StatusHistoryResponseDtoTest {

    @Test
    void testAllArgsConstructor() {

        StatusHistoryResponseDto builtDto = new StatusHistoryResponseDto(TestConstants.TEST_ID,
            TestConstants.TEST_TITLE, TestConstants.TEST_TI_NAME, TestConstants.TEST_CP_NAME,
            TestConstants.TEST_TYPE,
            Instant.now(), TestConstants.TEST_UPD_BY, TestConstants.TEST_MASTER_STATUS,
            new ArrayList<>());
        assertEquals(TestConstants.TEST_ID, builtDto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, builtDto.getMediaTitle());
        assertEquals(TestConstants.TEST_TI_NAME, builtDto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, builtDto.getContentPartner());
        assertEquals(TestConstants.TEST_TYPE, builtDto.getType());
        assertNotNull(builtDto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, builtDto.getLatestUpdatedBy());
        assertEquals(TestConstants.TEST_MASTER_STATUS, builtDto.getMasterStatus());
        assertNotNull(builtDto.getStatusHistoryChanges());
        assertTrue(builtDto.getStatusHistoryChanges().isEmpty());

    }

    @Test
    void testGettersAndSetters() {
        StatusHistoryResponseDto builtDto = new StatusHistoryResponseDto();

        builtDto.setAssetId(TestConstants.TEST_ID);
        builtDto.setMediaTitle(TestConstants.TEST_TITLE);
        builtDto.setTiName(TestConstants.TEST_TI_NAME);
        builtDto.setContentPartner(TestConstants.TEST_CP_NAME);
        builtDto.setType(TestConstants.TEST_TYPE);
        builtDto.setLatestChangeDateTime(Instant.now());
        builtDto.setLatestUpdatedBy(TestConstants.TEST_UPD_BY);
        builtDto.setMasterStatus(TestConstants.TEST_MASTER_STATUS);
        builtDto.setStatusHistoryChanges(new ArrayList<>());

        assertEquals(TestConstants.TEST_ID, builtDto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, builtDto.getMediaTitle());
        assertEquals(TestConstants.TEST_TI_NAME, builtDto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, builtDto.getContentPartner());
        assertEquals(TestConstants.TEST_TYPE, builtDto.getType());
        assertNotNull(builtDto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, builtDto.getLatestUpdatedBy());
        assertEquals(TestConstants.TEST_MASTER_STATUS, builtDto.getMasterStatus());
        assertNotNull(builtDto.getStatusHistoryChanges());
        assertTrue(builtDto.getStatusHistoryChanges().isEmpty());

    }

    @Test
    void testBuilder() {
        StatusHistoryResponseDto builtDto = StatusHistoryResponseDto.builder()
            .assetId(TestConstants.TEST_ID)
            .mediaTitle(TestConstants.TEST_TITLE)
            .tiName(TestConstants.TEST_TI_NAME)
            .contentPartner(TestConstants.TEST_CP_NAME)
            .type(TestConstants.TEST_TYPE)
            .latestChangeDateTime(Instant.now())
            .latestUpdatedBy(TestConstants.TEST_UPD_BY)
            .masterStatus(TestConstants.TEST_MASTER_STATUS)
            .statusHistoryChanges(new ArrayList<>())
            .build();

        assertEquals(TestConstants.TEST_ID, builtDto.getAssetId());
        assertEquals(TestConstants.TEST_TITLE, builtDto.getMediaTitle());
        assertEquals(TestConstants.TEST_TI_NAME, builtDto.getTiName());
        assertEquals(TestConstants.TEST_CP_NAME, builtDto.getContentPartner());
        assertEquals(TestConstants.TEST_TYPE, builtDto.getType());
        assertNotNull(builtDto.getLatestChangeDateTime());
        assertEquals(TestConstants.TEST_UPD_BY, builtDto.getLatestUpdatedBy());
        assertEquals(TestConstants.TEST_MASTER_STATUS, builtDto.getMasterStatus());
        assertNotNull(builtDto.getStatusHistoryChanges());
        assertTrue(builtDto.getStatusHistoryChanges().isEmpty());
    }

}