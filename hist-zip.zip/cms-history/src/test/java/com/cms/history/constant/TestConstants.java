package com.cms.history.constant;

import java.time.Instant;

public class TestConstants {

    public static final Instant CHANGE_DATE = Instant.now();
    public static final String TEST_TYPE = "VOD";
    public static final String TEST_CP_NAME = "TEST_CP";
    public static final String TEST_TI_NAME = "TEST_TI";
    public static final String TEST_TITLE = "TITLE";
    public static final String TEST_ERROR_MESSAGE = "TEST";
    public static final String TEST_RELEASE_DATE = "2023-10-01";
    public static final String TEST_EXP_DATE = "2024-10-01";
    public static final String TEST_STATUS = "ACTIVE";
    public static final String TEST_UPD_BY = "TEST USER";
    public static final String TEST_CNTRY_CD = "US";
    public static final String TEST_CP_ID = "CMS-01";
    public static final String TEST_ID = "TEST1";
    public static final String TEST_JSON_CHANGES = "testJson";
    public static final String TEST_OLD_STATUS = "QC in Progress";
    public static final String TEST_NEW_STATUS = "Released";
    public static final String TEST_MASTER_STATUS = "VOD Importer";
    public static final String ENDPOINT = "http://example.com/api";
    public static final String HTTP_METHOD = "GET";

}
