package com.cms.history.eventhistory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.constant.TestConstants;
import com.cms.history.eventhistory.dto.EventHistoryRequestDto;
import com.cms.history.eventhistory.service.EventHistoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class EventHistoryControllerTest {

    @Mock
    private EventHistoryService eventHistoryService;

    @InjectMocks
    private EventHistoryController eventHistoryController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void testInsertEventHistory_success() {
        EventHistoryRequestDto historyRequest = EventHistoryRequestDto.builder().build();
        historyRequest.setContentId(TestConstants.TEST_ID);
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getContentId());

        Mockito.doNothing().when(eventHistoryService).insertEventHistory(historyRequest);

        ResponseDto response = eventHistoryController.insertEventHistory(historyRequest);
        assertEquals(expectedResponse.getRsp().getPayload(), response.getRsp().getPayload());

    }

    @Test
    void testInsertLicenseHistory_exception() {
        EventHistoryRequestDto historyRequest = EventHistoryRequestDto.builder().build();

        Mockito.doThrow(new RuntimeException()).when(eventHistoryService)
            .insertEventHistory(historyRequest);

        assertThrows(RuntimeException.class,
            () -> eventHistoryController.insertEventHistory(historyRequest));


    }

}