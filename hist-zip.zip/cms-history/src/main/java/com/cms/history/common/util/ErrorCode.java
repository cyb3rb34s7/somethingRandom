package com.cms.history.common.util;

//! ErrorCode Class
public class ErrorCode {

    private ErrorCode() {
    }

    public static final String CMS_SERVICE_CODE = "241";

    /* 400 Error */
    public static final String BAD_REQUEST = CMS_SERVICE_CODE + "4010";
    public static final String INVALID_INPUT_DATA = CMS_SERVICE_CODE + "4010";

    /* 404 ERROR */
    public static final String DATA_NOT_FOUND = CMS_SERVICE_CODE + "4202";
    public static final String DATA_INTEGRITY_VIOLATION = CMS_SERVICE_CODE + "4206";

    /* 500 ERROR */
    public static final String INTERNAL_SERVER_ERROR = CMS_SERVICE_CODE + "5001";
}
