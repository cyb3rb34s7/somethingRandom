package com.cms.history.common.util;

public class ErrorMsg {

    private ErrorMsg() {
    }


    public static final String INVALID_QUERY_PARAM_VALUE = "Invalid Query Parameter Value";
    public static final String BAD_REQUEST = "Bad Request";
    public static final String INVALID_INPUT_DATA = "Invalid or Unsupported input data provided";
    public static final String ASSET_ID_EMPTY_ERROR = "Asset Id cannot be empty ";

    /* 404 ERROR */

    public static final String DATA_NOT_FOUND = "Data Not Found";
    public static final String DATA_INTEGRITY_VIOLATION = "Data Integrity Violation Occurred (Database constraint violated)";

    /* 500 ERROR */
    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
}
