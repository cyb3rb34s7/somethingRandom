package com.cms.history.licensehistory.service.impl;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.RetryUtil;
import com.cms.history.common.util.Utils;
import com.cms.history.licensehistory.dto.LicenseHistoryChangesDto;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import com.cms.history.licensehistory.mapper.LicenseHistoryMapper;
import com.cms.history.licensehistory.service.LicenseHistoryService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class LicenseHistoryServiceImpl implements LicenseHistoryService {


    private final LicenseHistoryMapper licenseHistoryMapper;
    private final AssetDetailsService assetDetailsService;

    public LicenseHistoryServiceImpl(LicenseHistoryMapper licenseHistoryMapper,
        AssetDetailsService assetDetailsService) {
        this.licenseHistoryMapper = licenseHistoryMapper;
        this.assetDetailsService = assetDetailsService;
    }

    @Override
    public List<LicenseHistoryResponseDto> getLicenseHistory(
        FilterRequestBodyDto filterRequestBody) {
        log.info("Fetching License History From DB with Request Body {}",
            filterRequestBody.toString());
        List<LicenseHistoryResponseDto> histories = licenseHistoryMapper.getLicenseHistory(
            filterRequestBody);
        log.info("Data Fetched, Adding License Window");
        if (histories != null && !histories.isEmpty()) {

            for (LicenseHistoryResponseDto history : histories) {

                String licenceWindow = Utils.getLicenseWindow(history.getCurrentReleaseDate(),
                    history.getCurrentExpiryDate());
                history.setCurrentStatus(licenceWindow);

            }
        }

        log.info("Returning License History Data with Size {}",
            histories == null ? "null" : histories.size());
        return histories;
    }

    @Override
    public void insertLicenseHistory(LicenseHistoryRequestDto historyRequest) {
        if (historyRequest.getAssetId() == null) {
            log.error("Asset ID is null,Throwing Exception");
            throw new IllegalArgumentException(ErrorMsg.ASSET_ID_EMPTY_ERROR);
        }
        log.info("Inserting license History {} :", historyRequest.getAssetId());
        var changeTime = Instant.now();
        List<AssetKeyDto> data = new ArrayList<>();
        AssetKeyDto assetKey = AssetKeyDto.builder().contentId(historyRequest.getAssetId())
            .countryCode(historyRequest.getCountryCode()).vcCpId(historyRequest.getVcCpId())
            .build();
        data.add(assetKey);

        RetryUtil.retry(() -> {
            log.info("Updating postgres main table from license History");
            assetDetailsService.updateAssetTable(data);
            historyRequest.setChangeDateTime(changeTime);
            log.info("Inserting License History {} :", historyRequest.getAssetId());
            licenseHistoryMapper.insertLicenseHistory(historyRequest);
            log.info("License History Added Successfully!");
            return null;
        });

    }

    @Override
    public Map<String, List<String>> getFilters() {

        log.info("Fetching Filters from DB for License History...");
        Map<String, List<String>> filters = new HashMap<>();
        filters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        filters.put(Constants.ASSET_STATUS, Constants.ASSET_STATUS_FILTERS);
        filters.put(Constants.TI_NAME, licenseHistoryMapper.getTechIntegrators());
        filters.put(Constants.CP_KEY, new ArrayList<>());
        log.info("Filters Fetched Returning Data");
        return filters;

    }


    public List<LicenseHistoryChangesDto> getLicenseHistoryByAssetId(String assetId) {

        log.info("Fetching License History By Asset Id {} ", assetId);

        List<LicenseHistoryChangesDto> histories = licenseHistoryMapper.getLicenseHistoryByAssetId(
            assetId);

        log.info("Returning Data with Size {}",
            histories == null ? "null" : histories.size());
        return histories;
    }

    @Override
    public int getLicenseHistoryCount(FilterRequestBodyDto filteredReqBody) {
        log.info("Fetching Count of License History");
        return licenseHistoryMapper.getLicenseHistoryCount(filteredReqBody);
    }

}
