package com.cms.history.statushistory.controller;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.statushistory.dto.StatusHistoryRequestDto;
import com.cms.history.statushistory.dto.StatusHistoryResponseDto;
import com.cms.history.statushistory.model.StatusHistoryModel;
import com.cms.history.statushistory.service.StatusHistoryService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cms/tvplus/asset/status/history")
public class StatusHistoryController {

    private final StatusHistoryService statusHistoryService;

    public StatusHistoryController(StatusHistoryService assetService) {
        this.statusHistoryService = assetService;
    }

    @PostMapping(value = "/add")
    public ResponseDto addHistory(@RequestBody StatusHistoryRequestDto assetReq) {
        log.info("addHistory request: {}", assetReq);
        int count = statusHistoryService.addStatusHistory(assetReq);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.ASSET_STATUS_HISTORY_MESSAGE + count);
    }

    @PostMapping(value = "/get")
    public ResponseDto getAllAssetsStatus(@RequestBody FilterRequestBodyDto filteredReqBody) {
        log.info("getAllAssetsStatus request: {}", filteredReqBody);
        List<StatusHistoryResponseDto> assets = statusHistoryService.getAllAssetStatus(filteredReqBody);
        Map<String, Object> response = new HashMap<>();
        response.put(Constants.RESPONSE_KEY, assets);
        response.put(Constants.COUNT, statusHistoryService.getStatusHistoryCount(filteredReqBody));
        log.info("getAllAssetsStatus returning {} records", assets.size());
        return ResponseHandler.processSuccess(response);
    }

    @PostMapping(value = "/export")
    public ResponseDto exportStatusHistory(@RequestBody FilterRequestBodyDto filteredReqBody) {
        log.info("exportStatusHistory request: {}", filteredReqBody);
        List<StatusHistoryResponseDto> assets = statusHistoryService.getStatusHistoryForExport(filteredReqBody);
        log.info("exportStatusHistory returning {} records", assets.size());
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY, assets);
    }

    @GetMapping(value = "/get/{assetId}")
    public ResponseDto getStatusHistoryByAssetId(@PathVariable String assetId) {
        log.info("getStatusHistoryByAssetId assetId: {}", assetId);
        List<StatusHistoryModel> assets = statusHistoryService.getStatusHistoryByAssetId(assetId);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY, assets);
    }

    @GetMapping("/get/filters")
    public ResponseDto getFilters() {
        log.info("getFilters called");
        Map<String, List<String>> filters = statusHistoryService.getFilters();
        return ResponseHandler.processMethodResponse(Constants.FILTER_KEY, filters);
    }
}
