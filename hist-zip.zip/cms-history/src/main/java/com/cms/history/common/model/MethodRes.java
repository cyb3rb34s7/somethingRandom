package com.cms.history.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MethodRes {

    private boolean success = true;
    private Exception exception;
    private Object returnObj;
}
