package com.cms.history.common.exception_handler;


import com.cms.history.common.exception.DataNotFoundException;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ErrorMessageUtil;
import com.cms.history.common.util.NotificationUtil;
import com.cms.history.common.util.ResponseHandler;
import java.sql.SQLException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    private final NotificationUtil notificationUtil;

        public GlobalExceptionHandler(NotificationUtil notificationUtil) {
        this.notificationUtil = notificationUtil;
    }

    @ExceptionHandler(SQLException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseDto handleSQLException(SQLException ex) {
        String errorMessage = "SQLException : " + ErrorMessageUtil.generateErrMessage(ex);
        log.error(errorMessage);
        notificationUtil.sendAlarm(new SQLException(errorMessage), HttpStatus.INTERNAL_SERVER_ERROR.name(),
            String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleMethodArgumentNotValidException(
        MethodArgumentNotValidException ex) {

        var sb = new StringBuilder();

        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            sb.append(fieldName).append(": ").append(errorMessage).append(", ");
        });

        var errorMessage = sb.toString();
        log.error("MethodArgumentNotValidException: {}", errorMessage);
        return generateErrorResponse(new Exception(errorMessage));
    }

    @ExceptionHandler(DataNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND) // 404
    public ResponseDto handleDataNotFoundException(DataNotFoundException ex) {
        log.error("DataNotFoundException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleDataIntegrityViolationException(DataIntegrityViolationException ex) {
        log.error("DataIntegrityViolationException: {}", ResponseHandler.generateBaseMessage(ex));

        return generateErrorResponse(ex);
    }
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseDto handleInvalidDataException(Exception ex) {
        log.error("Exception occurred: {}", ex.getMessage());
        notificationUtil.sendAlarm(ex, HttpStatus.INTERNAL_SERVER_ERROR.name(),
            String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        return generateErrorResponse(ex);
    }

    private ResponseDto generateErrorResponse(Exception ex) {
        return ResponseHandler.processMethodResponse(ex);
    }
}
