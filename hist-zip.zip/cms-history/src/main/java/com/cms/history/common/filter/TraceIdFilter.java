package com.cms.history.common.filter;

import com.cms.history.common.util.StructuredLogger;
import com.cms.history.common.util.TraceIdGenerator;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TraceIdFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(TraceIdFilter.class);

    private static final String HEADER_TRACE_ID = "X-Trace-Id";
    private static final String HEADER_SOURCE_SERVICE = "X-Source-Service";
    private static final String HEADER_USER_AGENT = "User-Agent";
    private static final String MDC_SOURCE_SERVICE = "sourceService";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        if (!(request instanceof HttpServletRequest httpRequest) ||
            !(response instanceof HttpServletResponse httpResponse)) {
            chain.doFilter(request, response);
            return;
        }

        long startTime = System.currentTimeMillis();

        try {
            // Extract or generate traceId
            String traceId = httpRequest.getHeader(HEADER_TRACE_ID);
            if (traceId == null || !TraceIdGenerator.isValidTraceId(traceId)) {
                traceId = TraceIdGenerator.generate();
            }

            // Set traceId in MDC
            StructuredLogger.setTraceId(traceId);

            // Add traceId to response header for caller correlation
            httpResponse.setHeader(HEADER_TRACE_ID, traceId);

            // Extract source service
            String sourceService = httpRequest.getHeader(HEADER_SOURCE_SERVICE);
            if (sourceService == null || sourceService.isEmpty()) {
                sourceService = httpRequest.getHeader(HEADER_USER_AGENT);
            }
            if (sourceService == null || sourceService.isEmpty()) {
                sourceService = "unknown";
            }
            MDC.put(MDC_SOURCE_SERVICE, sourceService);

            // Log request entry
            log.info(">>> {} {}", httpRequest.getMethod(), httpRequest.getRequestURI());

            // Execute filter chain
            chain.doFilter(request, response);

        } finally {
            long duration = System.currentTimeMillis() - startTime;

            // Log request completion
            log.info("<<< {} ({}ms)", httpResponse.getStatus(), duration);

            // Clear MDC to prevent memory leaks
            StructuredLogger.clearContext();
        }
    }
}
