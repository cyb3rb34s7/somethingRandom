package com.cms.history.common.dto;

import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class FilterRequestBodyDto {

    private List<FilterDto> filters;
    private SortDto sortBy;
    private PaginationDto pagination;

}
