package com.cms.history.licensehistory.service;


import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.licensehistory.dto.LicenseHistoryChangesDto;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import java.util.List;
import java.util.Map;


public interface LicenseHistoryService {

    void insertLicenseHistory(LicenseHistoryRequestDto historyRequest);

    List<LicenseHistoryResponseDto> getLicenseHistory(FilterRequestBodyDto filterRequestBody);

    List<LicenseHistoryChangesDto> getLicenseHistoryByAssetId(String assetId);

    Map<String, List<String>> getFilters();
    int getLicenseHistoryCount(FilterRequestBodyDto filteredReqBody);

}
