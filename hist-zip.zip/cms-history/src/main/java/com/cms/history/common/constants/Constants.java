package com.cms.history.common.constants;

import java.util.List;

public class Constants {

    private Constants() {
    }

    public static final String STATUS_OK = "ok";
    public static final String STATUS_FAIL = "fail";
    public static final String EXPIRY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String MESSAGE = "message";

    //API-const
    public static final String GET_ASSET_VIEW = "/cms/tvplus/asset/assetDetailsByColumn";

    //HTTP-METHODS
    public static final String METHOD_POST = "POST";

    public static final String RESPONSE_KEY = "data";
    public static final String FILTER_BODY_PARAM = "filterBody";
    public static final String HIST_COLL_PARAM = "histColl";


    public static final String SUCCESS_MESSAGE_HISTORY = "Successfully Added History with id ";


    public static final int EXPIRY_THRESHOLD = 30;
    public static final int UPCOMING_THRESHOLD = 300;
    public static final int VALUE_ONE = 1;

    public static final String ACTIVE = "Active";
    public static final String UPCOMING_IN = "Upcoming in ";
    public static final String EXPIRING_IN = "Expiring in ";
    public static final String UPCOMING_AFTER_300_DAYS = "Upcoming after 300 days";
    public static final String EXPIRED = "Expired";
    public static final String DAY = "day";
    public static final String DAYS = "days";
    public static final String TYPE = "type";
    public static final String ASSETS_KEY = "assets";
    public static final String CP_KEY = "contentPartner";

    public static final List<String> ASSET_TYPE_FILTERS = List.of("SHOW", "SEASON", "EPISODE",
        "MOVIE",
        "MUSIC", "SINGLEVOD");
    public static final List<String> ASSET_STATUS_FILTERS = List.of("UPCOMING", "ACTIVE",
        "EXPIRED");

    public static final String ASSET_STATUS = "licenseStatus";
    public static final String TI_NAME = "tiName";


    public static final String LICENSE_HISTORY_KEY = "LicenseHistory";
    public static final String FILTER_KEY = "filters";
    public static final String COUNT = "count" ;


    public static final String ASSET_STATUS_HISTORY_MESSAGE = "Successfully added # status histories:";


    public static final String ARGUS_DETECTION_SYSTEM = "CMS History";
    public static final String ARGUS_FAIL_ALERT = "FailAlert";

}
