package com.cms.history.statushistory.dto;

import com.cms.history.statushistory.model.StatusHistoryModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusHistoryResponseDto {

    private String assetId;
    private String mediaTitle;
    private String tiName;
    private String contentPartner;
    private String type;
    private Instant latestChangeDateTime;
    private String latestUpdatedBy;

    @JsonIgnore
    private String masterStatus;


    private List<StatusHistoryModel> statusHistoryChanges;

}
