package com.cms.history.lockHistory.service;

import com.cms.history.lockHistory.mapper.LockHistoryMapper;
import com.cms.history.lockHistory.model.LockHistoryRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class LockHistoryService {

    private final LockHistoryMapper lockHistoryMapper;

    public LockHistoryService(LockHistoryMapper lockHistoryMapper) {
        this.lockHistoryMapper = lockHistoryMapper;
    }

    public void addLockChangeHistory(LockHistoryRequestDto lockHistoryRequest) {
        log.info("addLockChangeHistory request: {}", lockHistoryRequest);
        lockHistoryRequest.populateChangesJsonString();
        lockHistoryMapper.addLockChangeHistory(lockHistoryRequest);
        log.info("Successfully added lock change history for asset: {}",
            lockHistoryRequest.getContentId());
    }
}
