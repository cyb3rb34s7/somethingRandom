package com.cms.history.eventhistory.controller;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.eventhistory.dto.EventHistoryRequestDto;
import com.cms.history.eventhistory.service.EventHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cms/tvplus/event/history")
public class EventHistoryController {

    private final EventHistoryService eventHistoryService;

    public EventHistoryController(EventHistoryService eventHistoryService) {
        this.eventHistoryService = eventHistoryService;
    }

    @PostMapping("/add")
    public ResponseDto insertEventHistory(@RequestBody EventHistoryRequestDto historyRequest) {
        log.info("insertEventHistory request: {}", historyRequest);
        eventHistoryService.insertEventHistory(historyRequest);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getContentId());
    }
}
