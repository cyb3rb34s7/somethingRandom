package com.cms.history.lockHistory.mapper;

import com.cms.history.lockHistory.model.LockHistoryRequestDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LockHistoryMapper {

    void addLockChangeHistory(LockHistoryRequestDto lockHistoryRequest);
}
