package com.cms.history.common.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssetDetailsDto {

    @NotNull
    @Size(max = 125)
    private String contentId;

    @Size(max = 2)
    private String countryCode;

    @Size(max = 20)
    private String type;

    @Size(max = 200)
    private String mainTitle;

    @Size(max = 30)
    private String expiryDate;

    @NotNull
    @Size(max = 50)
    private String vcCpId;

    @Size(max = 30)
    private String availableStarting;

    @Size(max = 200)
    private String contentPartner;

    private String tiName;

    private Instant changeDateTime;
    private String cpName;

}
