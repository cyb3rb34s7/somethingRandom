package com.cms.history.metadatahistory.controller;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.metadatahistory.dto.MetadataHistoryRequestDto;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import com.cms.history.metadatahistory.service.MetadataHistoryService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/cms/tvplus/metadata/history")
public class MetadataHistoryController {

    private final MetadataHistoryService metadataHistoryService;

    public MetadataHistoryController(MetadataHistoryService metadataHistoryService) {
        this.metadataHistoryService = metadataHistoryService;
    }

    @GetMapping(value = "/healthcheck")
    public ResponseDto healthCheck() {
        return ResponseHandler.processMethodResponse(Constants.MESSAGE, Constants.STATUS_OK);
    }

    @PostMapping(value = "/add")
    public ResponseDto addHistory(@RequestBody MetadataHistoryRequestDto assetReq) {
        log.info("addHistory request: {}", assetReq);
        metadataHistoryService.addMetadataHistory(assetReq);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + assetReq.getAssetId());
    }

    @PostMapping(value = "/get")
    public ResponseDto getAllMetadata(@RequestBody FilterRequestBodyDto filteredReqBody) {
        log.info("getAllMetadata request: {}", filteredReqBody);
        List<MetadataHistoryModel> assets = metadataHistoryService.getAllMetadata(filteredReqBody);
        Map<String, Object> response = new HashMap<>();
        response.put(Constants.RESPONSE_KEY, assets);
        response.put(Constants.COUNT, metadataHistoryService.getMetadataHistoryCount(filteredReqBody));
        log.info("getAllMetadata returning {} records", assets.size());
        return ResponseHandler.processSuccess(response);
    }

    @PostMapping(value = "/get/asset/{assetId}")
    public ResponseDto getHistoryByAssetId(@PathVariable String assetId,
        @RequestBody FilterRequestBodyDto filteredReqBody) {
        log.info("getHistoryByAssetId assetId: {} request: {}", assetId, filteredReqBody);
        List<MetadataHistoryModel> assets = metadataHistoryService.getMetadataDetailsByAssetId(
            assetId,
            filteredReqBody);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY, assets);
    }

    @GetMapping("/get/filters")
    public ResponseDto getFilters() {
        log.info("getFilters called");
        Map<String, List<String>> filters = metadataHistoryService.getFilters();
        return ResponseHandler.processMethodResponse(Constants.FILTER_KEY, filters);
    }
}
