package com.cms.history.metadatahistory.service;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.RetryUtil;
import com.cms.history.metadatahistory.dto.MetadataHistoryRequestDto;
import com.cms.history.metadatahistory.mapper.MetadataHistoryMapper;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class MetadataHistoryService {

    private final MetadataHistoryMapper metadataHistoryMapper;
    private final AssetDetailsService assetDetailsService;

    public MetadataHistoryService(MetadataHistoryMapper metadataHistoryMapper,
        AssetDetailsService assetDetailsService) {
        this.metadataHistoryMapper = metadataHistoryMapper;
        this.assetDetailsService = assetDetailsService;
    }

    public void addMetadataHistory(MetadataHistoryRequestDto req) {
        log.info("addMetadataHistory request: {}", req);
        if (req.getAssetId() == null) {
            log.error("addMetadataHistory failed: assetId is null");
            throw new IllegalArgumentException(ErrorMsg.ASSET_ID_EMPTY_ERROR);
        }
        log.info("Inserting Asset History {} :", req.getAssetId());

        List<AssetKeyDto> data = new ArrayList<>();
        AssetKeyDto assetKey = AssetKeyDto.builder().contentId(req.getAssetId())
            .countryCode(req.getCountryCode()).vcCpId(req.getVcCpId()).build();
        data.add(assetKey);

        RetryUtil.retry(() -> {
            log.info("Updating postgres main table");
            assetDetailsService.updateAssetTable(data);
            req.setTxnOccDate(Instant.now());
            log.info("Adding Metadata history..");
            metadataHistoryMapper.addAssetHistory(req);
            log.info("Metadata History Added Successfully!");
            return null;
        });
    }

    public List<MetadataHistoryModel> getAllMetadata(FilterRequestBodyDto filteredReqBody) {
        log.info("Fetching Metadata History With Request Body: {}", filteredReqBody);
        List<MetadataHistoryModel> histories = metadataHistoryMapper.getAllAsset(filteredReqBody);
        log.info("Returning MetadataHistory with Size: {}", histories.size());
        return histories;
    }

    public List<MetadataHistoryModel> getMetadataDetailsByAssetId(String contentId,
        FilterRequestBodyDto filteredReqBody) {
        log.info("Fetching Metadata History For Content Id: {}", contentId);
        return metadataHistoryMapper.getAllAssetByAssetId(contentId, filteredReqBody);
    }


    public Map<String, List<String>> getFilters() {
        log.info("Fetching Filters from DB for Metadata History...");
        Map<String, List<String>> filters = new HashMap<>();
        filters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        filters.put(Constants.TI_NAME, metadataHistoryMapper.getTechIntegrators());
        filters.put(Constants.CP_KEY, new ArrayList<>());
        log.info("Filters Fetched,Returning Data");
        return filters;

    }
    public int getMetadataHistoryCount(FilterRequestBodyDto filteredReqBody){
        log.info("Fetching Count of Metadata History");
        return metadataHistoryMapper.getMetadataHistoryCount(filteredReqBody);
    }


}


