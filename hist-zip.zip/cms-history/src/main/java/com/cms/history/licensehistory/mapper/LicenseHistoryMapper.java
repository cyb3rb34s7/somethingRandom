package com.cms.history.licensehistory.mapper;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.licensehistory.dto.LicenseHistoryChangesDto;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface LicenseHistoryMapper {

    void insertLicenseHistory(LicenseHistoryRequestDto historyRequest);

    List<LicenseHistoryResponseDto> getLicenseHistory(
        @Param("filterBody") FilterRequestBodyDto filterRequestBody);

    List<LicenseHistoryChangesDto> getLicenseHistoryByAssetId(@Param("assetId") String assetId);

    int getLicenseHistoryCount( @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<String> getTechIntegrators();


}
