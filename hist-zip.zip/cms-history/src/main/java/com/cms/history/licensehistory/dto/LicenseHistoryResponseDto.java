package com.cms.history.licensehistory.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LicenseHistoryResponseDto {

    private String assetId;
    private String mediaTitle;
    private String type;
    private String tiName;
    private String contentPartner;
    private String currentReleaseDate;
    private String currentExpiryDate;
    private String currentStatus;
    private Instant latestChangeDateTime;
    private String latestUpdatedBy;

    private List<LicenseHistoryRequestDto> historyChanges;
}
