package com.cms.history.metadatahistory.mapper;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.metadatahistory.dto.MetadataHistoryRequestDto;
import com.cms.history.metadatahistory.model.MetadataHistoryModel;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface MetadataHistoryMapper {

    void addAssetHistory(MetadataHistoryRequestDto assetHistory);

    List<MetadataHistoryModel> getAllAsset(
        @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<MetadataHistoryModel> getAllAssetByAssetId(@Param("assetId") String assetId,
        @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    int getMetadataHistoryCount( @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<String> getTechIntegrators();

}

