package com.cms.history.lockHistory.controller;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.lockHistory.model.LockHistoryRequestDto;
import com.cms.history.lockHistory.service.LockHistoryService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Validated
@RequestMapping("/cms/tvplus/lock/history")
public class LockHistoryController {

    private final LockHistoryService lockHistoryService;

    public LockHistoryController(LockHistoryService lockHistoryService) {
        this.lockHistoryService = lockHistoryService;
    }

    @PostMapping("/add")
    public ResponseDto addLockChangeHistory(
        @RequestBody @Valid LockHistoryRequestDto lockHistoryRequest) {
        log.info("adding field locking history for asset: {} , changes: {}",
            lockHistoryRequest.getContentId(), lockHistoryRequest.getChanges());
        lockHistoryService.addLockChangeHistory(lockHistoryRequest);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY.toLowerCase() + lockHistoryRequest.getContentId());
    }
}
