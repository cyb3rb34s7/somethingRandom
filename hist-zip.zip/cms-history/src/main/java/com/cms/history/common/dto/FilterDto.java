package com.cms.history.common.dto;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FilterDto {

    private String type;
    private String key;
    private List<String> values;
}
