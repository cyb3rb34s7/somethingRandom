package com.cms.history.common.util;

import com.cms.history.common.exception.CustomException;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RetryUtil {

    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 1000;

    private RetryUtil() {
    }

    public static <T> T retry(Supplier<T> supplier) {
        int retries = 0;
        while (retries < MAX_RETRIES) {
            try {
                return supplier.get();
            } catch (Exception e) {
                log.error("Error Occurred. Retrying...:{}", retries, e);
                retries++;
                try {
                    TimeUnit.MILLISECONDS.sleep(RETRY_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    log.error("Retry interrupted.", ie);
                }
            }
        }

        log.error("Failed after {} retries.", MAX_RETRIES);
        throw new CustomException("Failed after " + MAX_RETRIES + " retries.");
    }

}