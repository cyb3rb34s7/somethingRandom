package com.cms.history.common.mapper;

import com.cms.history.common.dto.AssetDetailsDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface AssetDetailsMapper {

    void updateAssetTable(@Param("assetDetails") List<AssetDetailsDto> assetDetails);
}
