package com.cms.history.statushistory.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatusHistoryModel {

    @JsonIgnore
    private String assetId;
    private Instant changeDateTime;
    private String oldStatus;
    private String newStatus;
    private String updatedBy;

    @JsonIgnore
    private String identifierId;

    @JsonIgnore
    private String masterStatus;


}
