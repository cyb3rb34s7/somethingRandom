package com.cms.history.common.util;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.exception.DataNotFoundException;
import com.cms.history.common.exception.MethodArgumentException;
import com.cms.history.common.model.BaseResponseDto;
import com.cms.history.common.model.ErrorResponseDto;
import com.cms.history.common.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;


public class ResponseHandler {

    private ResponseHandler() {
    }

    public static ResponseDto processSuccess(Map<String, Object> daoResponse) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_OK).payload(daoResponse).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }

    public static ResponseDto processError(ErrorResponseDto errorDto) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_FAIL).err(errorDto).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }


    public static ResponseDto processMethodResponse(String payloadKey, Object payloadObj) {
        if (payloadKey == null) {
            return processSuccess(null);
        } else {
            Map<String, Object> payload = new HashMap<>();
            payload.put(payloadKey, payloadObj);
            return processSuccess(payload);
        }
    }

    public static ResponseDto processMethodResponse(Exception err) {
        return processError(
            setResponseDetails(err)
        );
    }

    private static ErrorResponseDto setResponseDetails(Exception e) {
        if (e == null) {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR);
        }

        String baseMessage = generateBaseMessage(e);

        if (e instanceof MethodArgumentTypeMismatchException
            || e instanceof MethodArgumentNotValidException
            || e instanceof ConstraintViolationException
        ) {
            return new ErrorResponseDto(ErrorCode.INVALID_INPUT_DATA,
                ErrorMsg.INVALID_INPUT_DATA + baseMessage);
        } else if (e instanceof DataIntegrityViolationException) {
            return new ErrorResponseDto(ErrorCode.DATA_INTEGRITY_VIOLATION,
                ErrorMsg.DATA_INTEGRITY_VIOLATION);
        } else if (e instanceof DataNotFoundException) {
            return new ErrorResponseDto(ErrorCode.DATA_NOT_FOUND,
                ErrorMsg.DATA_NOT_FOUND + baseMessage);
        } else if (e instanceof MethodArgumentException) {
            return new ErrorResponseDto(ErrorCode.BAD_REQUEST, ErrorMsg.BAD_REQUEST + baseMessage);

        } else if (e instanceof SQLException) {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INVALID_QUERY_PARAM_VALUE + baseMessage);

        } else {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR + baseMessage);
        }
    }

    public static String generateBaseMessage(Exception e) {
        var baseMessage = ": ";
        if (e.getMessage() != null) {
            baseMessage += e.getMessage();
        } else if (e.getCause() != null && e.getCause().getMessage() != null) {
            baseMessage += e.getCause().getMessage();
        } else {
            baseMessage += "An Error has occurred";
        }
        return baseMessage;
    }


}