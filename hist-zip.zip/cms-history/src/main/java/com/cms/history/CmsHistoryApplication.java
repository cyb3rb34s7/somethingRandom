package com.cms.history;

import lombok.Generated;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@PropertySource("classpath:application-${env}.properties")
@PropertySource("classpath:application.properties")
@SpringBootApplication
@Generated
public class CmsHistoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(CmsHistoryApplication.class, args);

    }
}
