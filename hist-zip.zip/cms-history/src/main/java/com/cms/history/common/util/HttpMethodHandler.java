package com.cms.history.common.util;

import com.cms.history.common.exception.AssetApiFailureException;
import com.cms.history.common.model.ResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class HttpMethodHandler {

    private final RestTemplate restTemplate;

    private static final String HEADER_TRACE_ID = "X-Trace-Id";

    public HttpMethodHandler(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<ResponseDto> handleHttpExchange(String endPoint,
        String httpMethod,
        HttpEntity<?> httpEntity, Class<?> className) {

        long startTime = System.currentTimeMillis();

        try {
            // Add traceId header to outgoing request
            HttpHeaders headers = new HttpHeaders();
            if (httpEntity.getHeaders() != null) {
                headers.addAll(httpEntity.getHeaders());
            }
            String traceId = StructuredLogger.getTraceId();
            if (traceId != null) {
                headers.add(HEADER_TRACE_ID, traceId);
            }
            HttpEntity<?> entityWithTrace = new HttpEntity<>(httpEntity.getBody(), headers);

            // Log outgoing request
            log.info(">>> External API: {} {} request: {}", httpMethod, endPoint, httpEntity.getBody());

            ResponseEntity<ResponseDto> response = (ResponseEntity<ResponseDto>) restTemplate.exchange(
                endPoint,
                HttpMethod.valueOf(httpMethod),
                entityWithTrace,
                className);

            long duration = System.currentTimeMillis() - startTime;
            log.info("<<< External API: {} {} ({}ms)", response.getStatusCode(), endPoint, duration);

            return response;

        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            log.error("<<< External API FAILED: {} {} ({}ms) error: {}", httpMethod, endPoint, duration, e.getMessage());
            this.handleException(e);
        }
        return null;
    }

    private void handleException(Exception e) {
        if (e instanceof HttpClientErrorException.BadRequest) {
            log.error("Bad request Exception occurred while calling the API: {}", e.getMessage());
            throw new IllegalArgumentException(e);
        } else if (e instanceof HttpServerErrorException.InternalServerError) {
            log.error("Exception occurred at server side while calling the API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        } else if (e instanceof HttpStatusCodeException) {
            log.error("Status Code Exception occurred while calling the API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        } else if (e instanceof RestClientException) {
            log.error("Exception occurred while calling the external API: {}", e.getMessage());
            throw new AssetApiFailureException(e.getMessage());
        }
    }
}
