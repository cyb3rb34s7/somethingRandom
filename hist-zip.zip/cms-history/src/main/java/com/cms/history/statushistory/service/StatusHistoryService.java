package com.cms.history.statushistory.service;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.common.util.RetryUtil;
import com.cms.history.statushistory.dto.StatusHistoryRequestDto;
import com.cms.history.statushistory.dto.StatusHistoryResponseDto;
import com.cms.history.statushistory.mapper.StatusHistoryMapper;
import com.cms.history.statushistory.model.StatusHistoryModel;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class StatusHistoryService {

    private final StatusHistoryMapper statusHistoryMapper;
    private final AssetDetailsService assetDetailsService;

    public StatusHistoryService(StatusHistoryMapper assetMapper,
        AssetDetailsService assetDetailsService) {
        this.statusHistoryMapper = assetMapper;
        this.assetDetailsService = assetDetailsService;
    }

    public int addStatusHistory(StatusHistoryRequestDto req) {
        log.info("addStatusHistory request: {}", req);
        List<StatusHistoryRequestDto.AssetsChanges> assetChanges = req.getChanges();
        if (assetChanges == null) {
            log.error("addStatusHistory failed: changes is null");
            throw new IllegalArgumentException("No changes found");
        }
        List<AssetKeyDto> data = new ArrayList<>();
        log.info("Creating Objects to Be inserted in DB..");
        List<StatusHistoryModel> histColl = assetChanges.stream()
            .map(change ->
            {
                AssetKeyDto reqData = AssetKeyDto.builder().contentId(change.getAssetId())
                    .countryCode(
                        change.getCountryCode()).vcCpId(change.getVcCpId()).build();
                data.add(reqData);
                return StatusHistoryModel.builder()
                    .assetId(change.getAssetId())
                    .changeDateTime(Instant.now())
                    .oldStatus(change.getOldStatus())
                    .newStatus(change.getNewStatus())
                    .updatedBy(req.getUpdatedBy())
                    .masterStatus(change.getMasterStatus())
                    .identifierId(change.getIdentifierId())
                    .build();
            })
            .toList();
        return RetryUtil.retry(() -> {
            log.info("DB Objects Created, Updating Main History content Table. ");
            assetDetailsService.updateAssetTable(data);

            log.info("Adding Status history...");
            statusHistoryMapper.addStatusHistory(histColl);
            log.info("History added Successfully With size: {}", histColl.size());
            return histColl.size();
        });

    }

    public List<StatusHistoryResponseDto> getAllAssetStatus(FilterRequestBodyDto filteredReqBody) {
        log.info("Fetching Status History with RequestBody: {}", filteredReqBody);
        List<StatusHistoryResponseDto> histories = statusHistoryMapper.getAllAssetStatus(
            filteredReqBody);
        log.info("Returning Status History with Size: {}", histories.size());
        return histories;
    }

    public List<StatusHistoryResponseDto> getStatusHistoryForExport(FilterRequestBodyDto filteredReqBody) {
        log.info("Fetching Status History For export with RequestBody: {}", filteredReqBody);
        List<StatusHistoryResponseDto> histories = statusHistoryMapper.getStatusHistoryForExport(
            filteredReqBody);
        log.info("Returning Status History  with Size: {}", histories.size());
        return histories;
    }

    public List<StatusHistoryModel> getStatusHistoryByAssetId(String assetId) {
        log.info("Fetching Status history for content id: {}", assetId);
        return statusHistoryMapper.getStatusHistoryByAssetId(
            assetId);
    }


    public Map<String, List<String>> getFilters() {
        log.info("Fetching Filters from DB for Status History...");
        Map<String, List<String>> filters = new HashMap<>();
        filters.put(Constants.TYPE, Constants.ASSET_TYPE_FILTERS);
        filters.put(Constants.TI_NAME, statusHistoryMapper.getTechIntegrators());
        filters.put(Constants.CP_KEY, new ArrayList<>());
        log.info("Filters Fetched,Returning Data");
        return filters;

    }
    public int getStatusHistoryCount(FilterRequestBodyDto filteredReqBody){
        log.info("Fetching Count of status History");
        return statusHistoryMapper.getStatusHistoryCount(filteredReqBody);
    }




}
