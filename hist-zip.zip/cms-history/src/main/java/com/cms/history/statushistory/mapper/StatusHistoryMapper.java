package com.cms.history.statushistory.mapper;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.statushistory.dto.StatusHistoryResponseDto;
import com.cms.history.statushistory.model.StatusHistoryModel;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface StatusHistoryMapper {

    void addStatusHistory(
        @Param(Constants.HIST_COLL_PARAM) List<StatusHistoryModel> assetStatHistories);

    List<StatusHistoryResponseDto> getAllAssetStatus(
        @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<StatusHistoryResponseDto> getStatusHistoryForExport(
        @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<StatusHistoryModel> getStatusHistoryByAssetId(@Param("assetId") String assetId) ;

    int getStatusHistoryCount( @Param(Constants.FILTER_BODY_PARAM) FilterRequestBodyDto filterReqBodyDto);

    List<String> getTechIntegrators();
}
