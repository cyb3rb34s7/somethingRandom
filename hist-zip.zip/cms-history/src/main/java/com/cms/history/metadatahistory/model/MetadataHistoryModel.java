package com.cms.history.metadatahistory.model;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MetadataHistoryModel {

    private String assetId;
    private String mediaTitle;
    private String contentPartner;
    private String tiName;
    private Instant changeDateTime;
    private String changes;
    private String updatedBy;
}


