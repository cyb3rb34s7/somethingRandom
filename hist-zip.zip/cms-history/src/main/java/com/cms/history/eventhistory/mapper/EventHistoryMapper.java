package com.cms.history.eventhistory.mapper;

import com.cms.history.eventhistory.dto.EventHistoryRequestDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EventHistoryMapper {

    void insertEventHistory(EventHistoryRequestDto historyRequest);
}