package com.cms.history.lockHistory.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class LockHistoryRequestDto {

    @NotNull
    private String contentId;
    private String updatedBy;
    private Instant changeDateTime;
    private String changesJsonString;

    @NotEmpty(message = "No changes found in lockHistory request")
    private List<LockChange> changes;

    public void populateChangesJsonString() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            this.setChangesJsonString(objectMapper.writeValueAsString(this.changes));
        } catch (Exception e) {
            this.setChangesJsonString("");
        }
    }

    @Data
    public static class LockChange {

        private String fieldName;
        @JsonProperty("isLocked")
        private boolean isLocked;
    }

}

