package com.cms.history.common.util;

public class ErrorMessageUtil {

    private ErrorMessageUtil() {
    }

    public static String generateErrMessage(Exception e) {
        Throwable current = e;
        while (current != null) {
            if (e instanceof NullPointerException) {
                return "Null pointer exception occurred";
            }
            if (current.getMessage() != null && !current.getMessage().isBlank()) {
                return current.getMessage();
            }
            current = current.getCause();
        }
        return "Unknown error occurred";
    }
}