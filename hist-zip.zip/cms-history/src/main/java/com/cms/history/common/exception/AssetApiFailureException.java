package com.cms.history.common.exception;

public class AssetApiFailureException extends RuntimeException {

    public AssetApiFailureException(String message) {
        super(message);
    }
}
