package com.cms.history.common.exception;

public class MethodArgumentException extends RuntimeException {

    public MethodArgumentException(String message) {
        super(message);
    }

}
