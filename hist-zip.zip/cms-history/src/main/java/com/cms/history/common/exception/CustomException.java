package com.cms.history.common.exception;

public class CustomException extends RuntimeException {

    public CustomException(String message) {
        super(message);
    }
}
