package com.cms.history.common.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssetDetailsRequestDto {

    private List<String> columns;
    private List<AssetKeyDto> assetList;

}
