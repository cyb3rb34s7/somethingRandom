package com.cms.history.eventhistory.service;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.service.AssetDetailsService;
import com.cms.history.common.util.ErrorMsg;
import com.cms.history.common.util.RetryUtil;
import com.cms.history.common.util.Utils;
import com.cms.history.eventhistory.dto.EventHistoryRequestDto;
import com.cms.history.eventhistory.mapper.EventHistoryMapper;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EventHistoryService {

    private final EventHistoryMapper eventHistoryMapper;
    private final AssetDetailsService assetDetailsService;

    public EventHistoryService(EventHistoryMapper eventHistoryMapper,
        AssetDetailsService assetDetailsService) {
        this.eventHistoryMapper = eventHistoryMapper;
        this.assetDetailsService = assetDetailsService;
    }


    public void insertEventHistory(EventHistoryRequestDto historyRequest) {
        log.info("insertEventHistory request: {}", historyRequest);
        if (historyRequest.getContentId() == null || historyRequest.getContentId().isEmpty()) {
            log.error("insertEventHistory failed: contentId is null or empty");
            throw new IllegalArgumentException(ErrorMsg.ASSET_ID_EMPTY_ERROR);
        }
        log.info("Inserting event History: {}", historyRequest.getContentId());
        var changeTime = Instant.now();
        List<AssetKeyDto> data = new ArrayList<>();
        AssetKeyDto assetKey = AssetKeyDto.builder().contentId(historyRequest.getContentId())
            .countryCode(historyRequest.getCountryCode()).vcCpId(historyRequest.getVcCpId())
            .build();
        data.add(assetKey);
        RetryUtil.retry(() -> {
            log.info("Updating postgres main table from event History");
            assetDetailsService.updateAssetTable(data);
            historyRequest.setChangeDateTime(changeTime);
            log.info("Inserting event History: {}", historyRequest.getContentId());
            eventHistoryMapper.insertEventHistory(historyRequest);
            log.info("Event History Added Successfully!");
            return null;
        });
    }
}