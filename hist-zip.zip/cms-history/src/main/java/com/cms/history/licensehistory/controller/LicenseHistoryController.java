package com.cms.history.licensehistory.controller;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.FilterRequestBodyDto;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.ResponseHandler;
import com.cms.history.licensehistory.dto.LicenseHistoryRequestDto;
import com.cms.history.licensehistory.dto.LicenseHistoryResponseDto;
import com.cms.history.licensehistory.service.LicenseHistoryService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cms/tvplus/license/history")
public class LicenseHistoryController {

    private final LicenseHistoryService licenseHistoryService;

    public LicenseHistoryController(LicenseHistoryService licenseHistoryService) {
        this.licenseHistoryService = licenseHistoryService;
    }

    @PostMapping("/get")
    public ResponseDto getLicenseHistory(@RequestBody FilterRequestBodyDto filterRequestBody) {
        log.info("getLicenseHistory request: {}", filterRequestBody);
        List<LicenseHistoryResponseDto> assets = licenseHistoryService.getLicenseHistory(filterRequestBody);
        Map<String, Object> response = new HashMap<>();
        response.put(Constants.RESPONSE_KEY, assets);
        response.put(Constants.COUNT, licenseHistoryService.getLicenseHistoryCount(filterRequestBody));
        log.info("getLicenseHistory returning {} records", assets.size());
        return ResponseHandler.processSuccess(response);
    }

    @GetMapping("/get/asset/{assetId}")
    public ResponseDto getLicenseHistoryByAssetId(@PathVariable String assetId) {
        log.info("getLicenseHistoryByAssetId assetId: {}", assetId);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            licenseHistoryService.getLicenseHistoryByAssetId(assetId));
    }

    @PostMapping("/add")
    public ResponseDto insertLicenseHistory(@RequestBody LicenseHistoryRequestDto historyRequest) {
        log.info("insertLicenseHistory request: {}", historyRequest);
        licenseHistoryService.insertLicenseHistory(historyRequest);
        return ResponseHandler.processMethodResponse(Constants.RESPONSE_KEY,
            Constants.SUCCESS_MESSAGE_HISTORY + historyRequest.getAssetId());
    }

    @GetMapping("/get/filters")
    public ResponseDto getFilters() {
        log.info("getFilters called");
        Map<String, List<String>> filters = licenseHistoryService.getFilters();
        return ResponseHandler.processMethodResponse(Constants.FILTER_KEY, filters);
    }
}
