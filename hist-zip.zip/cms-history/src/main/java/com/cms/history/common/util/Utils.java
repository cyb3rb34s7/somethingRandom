package com.cms.history.common.util;

import com.cms.history.common.constants.Constants;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.springframework.stereotype.Component;

@Component
public class Utils {


    private Utils() {
    }

    public static Instant getUTCDateTime(String dateTime, String dateTimeFormat) {
        if (dateTime != null) {
            return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(dateTimeFormat))
                .atZone(ZoneId.of("UTC")).toInstant();
        }
        return null;
    }

    public static String getLicenseWindow(String startDate, String expDate) {
        var now = Instant.now();
        Instant startDateTime = getUTCDateTime(startDate, Constants.EXPIRY_DATE_FORMAT);
        Instant expDateTime = getUTCDateTime(expDate, Constants.EXPIRY_DATE_FORMAT);
        var licenseWindow = "";
        if (startDateTime == null) {
            licenseWindow += "";
        } else if (startDateTime.isAfter(now)) {
            licenseWindow += calculateUpcoming(startDateTime, now);

        } else if (startDateTime.isBefore(now) && expDateTime == null) {
            licenseWindow += Constants.ACTIVE;
        } else if (startDateTime.isBefore(now) && expDateTime != null && expDateTime.isAfter(now)) {
            var difference = Duration.between(now, expDateTime);
            long days = difference.toDays();
            if (days > Constants.EXPIRY_THRESHOLD) {
                licenseWindow += Constants.ACTIVE;
            } else {
                licenseWindow += Constants.EXPIRING_IN + days;
                if (difference.toDays() == Constants.VALUE_ONE) {
                    licenseWindow += " " + Constants.DAY;
                } else {
                    licenseWindow += " " + Constants.DAYS;
                }
            }
        } else if (expDateTime != null && expDateTime.isBefore(now)) {
            licenseWindow += Constants.EXPIRED;
        }
        return licenseWindow;
    }

    private static String calculateUpcoming(Instant startDateTime, Instant now) {
        var difference = Duration.between(now, startDateTime);
        long days = difference.toDays();
        var licenseWindow = "";
        if (days > Constants.UPCOMING_THRESHOLD) {
            licenseWindow += Constants.UPCOMING_AFTER_300_DAYS;

        } else {
            licenseWindow += Constants.UPCOMING_IN + difference.toDays();
            if (difference.toDays() == Constants.VALUE_ONE) {
                licenseWindow += " " + Constants.DAY;
            } else {
                licenseWindow += " " + Constants.DAYS;
            }
        }
        return licenseWindow;
    }


}
