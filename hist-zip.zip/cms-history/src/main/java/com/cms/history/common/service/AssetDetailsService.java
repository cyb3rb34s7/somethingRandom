package com.cms.history.common.service;

import com.cms.history.common.constants.Constants;
import com.cms.history.common.dto.AssetDetailsDto;
import com.cms.history.common.dto.AssetDetailsRequestDto;
import com.cms.history.common.dto.AssetKeyDto;
import com.cms.history.common.exception.AssetApiFailureException;
import com.cms.history.common.mapper.AssetDetailsMapper;
import com.cms.history.common.model.ResponseDto;
import com.cms.history.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AssetDetailsService {

    private final String assetManagementOpenApiUrl;
    private final HttpMethodHandler httpMethodHandler;
    private final AssetDetailsMapper assetDetailsMapper;


    public AssetDetailsService(@Value("${ASSET_OPENAPI_URL}") String assetManagementOpenApiUrl,
        HttpMethodHandler httpMethodHandler, AssetDetailsMapper assetDetailsMapper) {
        this.assetManagementOpenApiUrl = assetManagementOpenApiUrl;
        this.httpMethodHandler = httpMethodHandler;
        this.assetDetailsMapper = assetDetailsMapper;
    }

    public List<AssetDetailsDto> getAssetDetails(List<AssetKeyDto> assetKeys,
        List<String> columns) {
        try {
            String finalUrl = assetManagementOpenApiUrl + Constants.GET_ASSET_VIEW;
            log.info("Fetching Latest Asset Details from Open API with URL: {}", finalUrl);
            AssetDetailsRequestDto request = AssetDetailsRequestDto.builder().assetList(assetKeys)
                .columns(columns).build();
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, new HttpEntity<>(request),
                ResponseDto.class);
            log.info("Latest Asset details received from API with Size: {}",
                Objects.requireNonNull(responseEntity.getBody()).getRsp().getPayload().size());
            var mapper = new ObjectMapper();
            return mapper.convertValue(
                Objects.requireNonNull(responseEntity.getBody()).getRsp().getPayload()
                    .get(Constants.ASSETS_KEY),
                new TypeReference<>() {
                });
        } catch (Exception ex) {
            log.error("Error while getting view: {}", ex.getMessage(), ex);
            throw new AssetApiFailureException("Error while getting view");
        }

    }

    public void updateAssetTable(List<AssetKeyDto> assets) {
        log.info("Request to update main history table received");
        List<String> columns = Arrays.asList("contentId", "countryCode", "type", "mainTitle",
            "expiryDate", "vcCpId", "availableStarting", "contentPartner", "tiName");

        List<AssetDetailsDto> assetDetails = getAssetDetails(assets, columns);

        log.info("Updating Main History Table with latest details");
        var currentTime = Instant.now();
        if (!assetDetails.isEmpty()) {
            assetDetails.forEach(asset ->
                asset.setChangeDateTime(currentTime)
            );
            assetDetailsMapper.updateAssetTable(assetDetails);

        }
        
        log.info(!assetDetails.isEmpty() ? "Main History Table updated successfully"
            : "No Data to update in Main History Table");

    }


}
