package com.cms.history.metadatahistory.dto;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MetadataHistoryRequestDto {

    private String updatedBy;
    private String assetId;
    private String changes;
    private Instant txnOccDate;
    private String countryCode;
    private String vcCpId;
}