package com.cms.history.statushistory.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StatusHistoryRequestDto {

    private String updatedBy;
    private List<AssetsChanges> changes;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AssetsChanges {

        private String assetId;
        private String oldStatus;
        private String newStatus;
        private String masterStatus;
        private String identifierId;
        private String countryCode;
        private String vcCpId;

    }
}