"""
stitching_pipeline/stitch.py

Main orchestrator for the stitching pipeline.
Reads a manifest.json and produces a final explanation video.

Usage:
    python stitch.py --manifest output_manifests/manifest_2025-03-20_10-30-00.json

Output:
    output/{timestamp}/{umdId1_umdId2}/explanation.mp4
"""

import json
import logging
import shutil
import sys
from datetime import datetime
from pathlib import Path

import config
from ffmpeg_runner import check_ffmpeg, FFmpegError
from steps.extractor  import run_all as extract_all
from steps.overlayer  import run_all as overlay_all
from steps.cards      import generate_title_card, generate_end_card
from steps.compositor import compose
from steps.audio      import run_audio

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Logger setup
# ---------------------------------------------------------------------------

def _setup_logging(run_id: str) -> None:
    log_dir = config.LOG_DIR / run_id
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "stitch.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(),
        ],
    )


# ---------------------------------------------------------------------------
# Output path builder
# ---------------------------------------------------------------------------

def _build_output_path(manifest: dict, run_id: str) -> Path:
    """
    Build output path:
      output/{run_id}/{umdId1_umdId2}/explanation.mp4   — A_TO_B
      output/{run_id}/{umdId}/explanation.mp4            — other types
    """
    clips    = manifest.get("clips", [])
    umd_ids  = list(dict.fromkeys(c["umdId"] for c in clips))  # ordered, deduped
    folder   = "_".join(umd_ids) if len(umd_ids) > 1 else umd_ids[0]
    out_dir  = config.OUTPUT_DIR / run_id / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir / "explanation.mp4"


# ---------------------------------------------------------------------------
# Temp directory management
# ---------------------------------------------------------------------------

def _make_temp_dir(run_id: str) -> Path:
    temp = config.TEMP_DIR / run_id
    temp.mkdir(parents=True, exist_ok=True)
    return temp


def _cleanup_temp(temp_dir: Path) -> None:
    try:
        shutil.rmtree(temp_dir)
        logger.info(f"Temp files cleaned up: {temp_dir}")
    except Exception as e:
        logger.warning(f"Could not clean temp dir {temp_dir}: {e}")


# ---------------------------------------------------------------------------
# Font check
# ---------------------------------------------------------------------------

def _check_fonts() -> None:
    for font_path in [config.FONT_IMPACT, config.FONT_BODY]:
        if not Path(font_path).exists():
            raise FileNotFoundError(
                f"Font not found: {font_path}. "
                f"Run: python tools/collect_assets.py"
            )


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def stitch(manifest_path: str) -> Path:
    """
    Run the full stitching pipeline for a given manifest.

    Args:
        manifest_path: Path to manifest JSON produced by the manifest pipeline

    Returns:
        Path to the final output video
    """
    run_id   = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    _setup_logging(run_id)

    logger.info("=" * 60)
    logger.info("  Stitching Pipeline Started")
    logger.info(f"  Manifest: {manifest_path}")
    logger.info(f"  Run ID:   {run_id}")
    logger.info("=" * 60)

    # ── Pre-flight checks ──────────────────────────────────────────
    check_ffmpeg()
    _check_fonts()

    with open(manifest_path) as f:
        manifest = json.load(f)

    output_path = _build_output_path(manifest, run_id)
    temp_dir    = _make_temp_dir(run_id)

    # Save manifest copy alongside output for reference
    manifest_copy = output_path.parent / "manifest_used.json"

    logger.info(f"Output → {output_path}")
    logger.info(f"Temp   → {temp_dir}")

    try:
        # ── Step 1: Extract + grade + letterbox all clips ──────────
        logger.info("── Step 1: Extracting clips")
        extracted_clips = extract_all(manifest, temp_dir)

        # ── Step 2: Apply text overlays ────────────────────────────
        logger.info("── Step 2: Applying overlays")
        overlaid_clips = overlay_all(extracted_clips, manifest, temp_dir)

        # ── Step 3: Generate title card ────────────────────────────
        logger.info("── Step 3: Generating title card")
        title_card_data = manifest.get("metadata", {}).get("titleCard", {
            "text": "RECOMMENDED FOR YOU",
            "durationSeconds": 2.0,
        })
        title_card = generate_title_card(title_card_data, temp_dir)

        # ── Step 4: Generate end card ──────────────────────────────
        logger.info("── Step 4: Generating end card")
        end_card = generate_end_card(manifest["endCard"], temp_dir)

        # ── Step 5: Composite all segments ────────────────────────
        logger.info("── Step 5: Compositing")
        composed_video = compose(
            title_card=title_card,
            overlaid_clips=overlaid_clips,
            end_card=end_card,
            manifest=manifest,
            temp_dir=temp_dir,
        )

        # ── Step 6: Mix audio ──────────────────────────────────────
        logger.info("── Step 6: Mixing audio")
        run_audio(
            composed_video=composed_video,
            manifest=manifest,
            output_path=output_path,
            temp_dir=temp_dir,
        )

        # ── Save manifest copy ─────────────────────────────────────
        shutil.copy2(manifest_path, str(manifest_copy))

        # ── Cleanup temp ───────────────────────────────────────────
        _cleanup_temp(temp_dir)

        logger.info("=" * 60)
        logger.info(f"  Done! → {output_path}")
        logger.info(f"  Tag:     {manifest.get('tag', '')}")
        logger.info(f"  Est dur: {manifest.get('metadata', {}).get('estimatedDurationSeconds', '?')}s")
        logger.info("=" * 60)

        return output_path

    except Exception as e:
        logger.error(f"Stitching failed: {e}", exc_info=True)
        logger.info(f"Temp files preserved for debugging: {temp_dir}")
        raise


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Explainable Recommendation — Stitching Pipeline")
    parser.add_argument("--manifest", required=True, help="Path to manifest JSON")
    args = parser.parse_args()

    try:
        output = stitch(args.manifest)
        print(f"\nVideo ready: {output}\n")
    except (FFmpegError, FileNotFoundError) as e:
        print(f"\nERROR: {e}\n", file=sys.stderr)
        sys.exit(1)
