"""
stitching_pipeline/config.py

All paths and constants for the stitching pipeline.
Override via environment variables.
"""

import os
from pathlib import Path

def _env(key, default):
    return os.environ.get(key, default)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

INPUT_DIR        = Path(_env("STITCH_INPUT_DIR",   "input"))       # input/{umdId}/video.mp4 or stream.m3u8
OUTPUT_DIR       = Path(_env("STITCH_OUTPUT_DIR",  "output"))      # output/{timestamp}/{umdId1_umdId2}/
TEMP_DIR         = Path(_env("STITCH_TEMP_DIR",    "temp"))        # intermediate files, cleaned after run
MUSIC_DIR        = Path(_env("STITCH_MUSIC_DIR",   "music"))       # music/{mood}/*.mp3
FONTS_DIR        = Path(_env("STITCH_FONTS_DIR",   "fonts"))       # fonts/*.ttf
LOG_DIR          = Path(_env("STITCH_LOG_DIR",     "logs"))

# ---------------------------------------------------------------------------
# Output video spec
# ---------------------------------------------------------------------------

OUTPUT_WIDTH     = int(_env("STITCH_WIDTH",        "1920"))
OUTPUT_HEIGHT    = int(_env("STITCH_HEIGHT",       "1080"))
OUTPUT_FPS       = int(_env("STITCH_FPS",          "24"))
OUTPUT_CRF       = int(_env("STITCH_CRF",          "18"))          # quality — lower = better, 18 is visually lossless
OUTPUT_PRESET    = _env("STITCH_PRESET",            "medium")      # ffmpeg encode speed/size tradeoff
OUTPUT_CODEC     = _env("STITCH_CODEC",             "libx264")

# ---------------------------------------------------------------------------
# Letterbox
# ---------------------------------------------------------------------------

# 2.39:1 cinematic ratio — black bars top and bottom
LETTERBOX_HEIGHT = int(OUTPUT_WIDTH / 2.39)    # ~803px of actual content
LETTERBOX_PAD_Y  = (OUTPUT_HEIGHT - LETTERBOX_HEIGHT) // 2   # ~138px bars top and bottom

# ---------------------------------------------------------------------------
# Fonts
# ---------------------------------------------------------------------------

FONT_IMPACT   = str(FONTS_DIR / "BebasNeue-Regular.ttf")     # large cinematic text
FONT_BODY     = str(FONTS_DIR / "Montserrat-Bold.ttf")        # supporting text

# ---------------------------------------------------------------------------
# Color grade filter strings
# ---------------------------------------------------------------------------

COLOR_GRADES = {
    "CINEMATIC": (
        "curves=r='0/0 0.5/0.55 1/1':g='0/0 0.5/0.5 1/1':b='0/0 0.5/0.45 1/0.95',"
        "eq=contrast=1.1:saturation=0.85"
    ),
    "COOL": (
        "curves=r='0/0 0.5/0.48 1/0.95':g='0/0 0.5/0.5 1/1':b='0/0 0.5/0.55 1/1.05',"
        "eq=contrast=1.15:saturation=0.8"
    ),
    "WARM": (
        "curves=r='0/0 0.5/0.55 1/1.05':g='0/0 0.5/0.5 1/1':b='0/0 0.5/0.45 1/0.9',"
        "eq=contrast=1.05:saturation=0.9"
    ),
    "NONE": "",
}

# ---------------------------------------------------------------------------
# Transition durations (seconds)
# ---------------------------------------------------------------------------

TRANSITION_DURATION = 1.2

# ---------------------------------------------------------------------------
# Audio
# ---------------------------------------------------------------------------

MUSIC_INDEX_FILE = MUSIC_DIR / "music_index.json"
