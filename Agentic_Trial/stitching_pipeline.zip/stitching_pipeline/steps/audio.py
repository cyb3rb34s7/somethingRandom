"""
stitching_pipeline/steps/audio.py  — Step 6

Handles music selection and audio mixing:
  1. Pick a random track from the correct mood folder
  2. Loop/trim the track to match video duration
  3. Mix music (30%) with original clip audio (70%) using amix
  4. Apply fade out on music in last 3 seconds
  5. Merge final audio into composed video → final output
"""

import json
import logging
import random
from pathlib import Path

import config
from ffmpeg_runner import run, get_duration, FFmpegError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Music selection
# ---------------------------------------------------------------------------

def _load_music_index() -> dict:
    if not config.MUSIC_INDEX_FILE.exists():
        raise FFmpegError(
            f"Music index not found at {config.MUSIC_INDEX_FILE}. "
            f"Run: python tools/collect_music.py"
        )
    with open(config.MUSIC_INDEX_FILE) as f:
        return json.load(f)


def select_track(music_mood: str) -> Path:
    """
    Pick a random track from the given mood folder.
    Falls back to cinematic_neutral if mood not found.

    Args:
        music_mood: e.g. "dark_thriller", "epic_prestige"

    Returns:
        Path to the selected MP3 file
    """
    index = _load_music_index()
    moods = index.get("moods", {})

    tracks = moods.get(music_mood) or moods.get("cinematic_neutral", [])
    if not tracks:
        raise FFmpegError(
            f"No tracks found for mood '{music_mood}' and no fallback available. "
            f"Run: python tools/collect_music.py"
        )

    # Filter to tracks that actually exist on disk
    available = [t for t in tracks if Path(t["path"]).exists()]
    if not available:
        raise FFmpegError(
            f"Music tracks for mood '{music_mood}' are listed in index "
            f"but files not found on disk. Re-run: python tools/collect_music.py"
        )

    selected = random.choice(available)
    logger.info(f"Selected music: {selected['title']} [{music_mood}]")
    return Path(selected["path"])


# ---------------------------------------------------------------------------
# Audio mixer
# ---------------------------------------------------------------------------

def mix_audio(
    composed_video: Path,
    music_track: Path,
    video_duration: float,
    music_volume: float,
    clip_volume:  float,
    output_path: Path,
    temp_dir: Path,
) -> None:
    """
    Mix music + clip audio and merge into the composed video.

    Steps:
    1. Loop music to cover full video duration
    2. Trim to exact duration
    3. Apply fade out on music last 3s
    4. amix music + clip audio at specified volumes
    5. Merge audio track back into video

    Args:
        composed_video:  Path to composed video (video + original audio)
        music_track:     Path to selected MP3
        video_duration:  Total duration of composed video in seconds
        music_volume:    Music track volume (0.0–1.0)
        clip_volume:     Original clip audio volume (0.0–1.0)
        output_path:     Final output MP4
        temp_dir:        Temp directory
    """
    fade_out_start = max(0, video_duration - 3.0)
    mixed_audio    = temp_dir / "mixed_audio.aac"

    logger.info(
        f"Mixing audio — music: {music_volume:.0%}, clip: {clip_volume:.0%}, "
        f"duration: {video_duration:.1f}s"
    )

    # Build audio filter:
    # [0:a] = clip audio, volume adjusted
    # [1:a] = music, looped + trimmed + faded, volume adjusted
    # amix combines both
    audio_filter = (
        # Clip audio at specified volume
        f"[0:a]volume={clip_volume}[clip_audio];"

        # Music: loop → trim → fade out → volume
        f"[1:a]"
        f"aloop=loop=-1:size=2e+09,"           # loop indefinitely
        f"atrim=duration={video_duration:.3f}," # trim to video length
        f"afade=t=out:st={fade_out_start:.3f}:d=3,"  # fade out last 3s
        f"volume={music_volume}[music_audio];"

        # Mix both streams
        f"[clip_audio][music_audio]amix=inputs=2:normalize=0[final_audio]"
    )

    # Step 1 — produce mixed audio track
    run([
        "-i", str(composed_video),
        "-i", str(music_track),
        "-filter_complex", audio_filter,
        "-map", "[final_audio]",
        "-c:a", "aac",
        "-b:a", "192k",
        "-ar", "44100",
        "-ac", "2",
        "-t", str(video_duration),
        str(mixed_audio),
    ], label="mix audio")

    # Step 2 — merge mixed audio back into video
    run([
        "-i", str(composed_video),
        "-i", str(mixed_audio),
        "-map", "0:v",
        "-map", "1:a",
        "-c:v", "copy",
        "-c:a", "copy",
        "-shortest",
        str(output_path),
    ], label="merge audio into video")

    logger.info(f"Audio merged → {output_path}")


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run_audio(
    composed_video: Path,
    manifest: dict,
    output_path: Path,
    temp_dir: Path,
) -> None:
    """
    Full audio step: select track, get duration, mix, merge.

    Args:
        composed_video: Output of compositor step
        manifest:       Full manifest dict
        output_path:    Final output path
        temp_dir:       Temp directory
    """
    video_style   = manifest.get("metadata", {}).get("videoStyle", {})
    music_mood    = video_style.get("musicMood", "cinematic_neutral")
    music_volume  = float(video_style.get("musicVolume", 0.3))
    clip_volume   = float(video_style.get("clipVolume", 0.7))

    music_track    = select_track(music_mood)
    video_duration = get_duration(str(composed_video))

    mix_audio(
        composed_video=composed_video,
        music_track=music_track,
        video_duration=video_duration,
        music_volume=music_volume,
        clip_volume=clip_volume,
        output_path=output_path,
        temp_dir=temp_dir,
    )
