"""
stitching_pipeline/steps/extractor.py  — Step 1

For each clip in the manifest:
  - Locate the source video (MP4 or HLS) from input/{umdId}/
  - Extract the clip window (clipStart → clipEnd)
  - Apply color grade
  - Apply letterbox (2.39:1 cinematic bars)
  - Normalize to 1920x1080
  - Output to temp/{clip_index}_graded.mp4
"""

import logging
from pathlib import Path
from dataclasses import dataclass

import config
from ffmpeg_runner import run, detect_input_type, FFmpegError

logger = logging.getLogger(__name__)

# Supported source file names — checked in order
SOURCE_CANDIDATES = ["video.mp4", "stream.m3u8", "video.m3u8", "movie.mp4", "source.mp4"]


@dataclass
class ExtractedClip:
    clip_index:   int
    umd_id:       str
    path:         Path
    duration:     float   # seconds


def _find_source(umd_id: str) -> Path:
    """
    Find the source video file for a given umdId.
    Looks in input/{umdId}/ for known filenames.
    """
    content_dir = config.INPUT_DIR / umd_id
    if not content_dir.exists():
        raise FFmpegError(
            f"No input directory found for umdId '{umd_id}'. "
            f"Expected: {content_dir.resolve()}"
        )

    for candidate in SOURCE_CANDIDATES:
        path = content_dir / candidate
        if path.exists():
            logger.info(f"Found source for {umd_id}: {path} [{detect_input_type(str(path))}]")
            return path

    # Also accept any .mp4 or .m3u8 in the directory
    for ext in ["*.mp4", "*.m3u8"]:
        matches = list(content_dir.glob(ext))
        if matches:
            logger.info(f"Found source for {umd_id}: {matches[0]}")
            return matches[0]

    raise FFmpegError(
        f"No video file found in {content_dir}. "
        f"Expected one of: {SOURCE_CANDIDATES}"
    )


def _build_video_filter(color_grade: str) -> str:
    """
    Build ffmpeg video filter chain:
    1. Scale to fill 1920x803 (letterbox content area)
    2. Pad to 1920x1080 with black bars top/bottom
    3. Apply color grade
    4. Set FPS
    """
    W = config.OUTPUT_WIDTH
    H = config.OUTPUT_HEIGHT
    LH = config.LETTERBOX_HEIGHT
    PAD_Y = config.LETTERBOX_PAD_Y
    FPS = config.OUTPUT_FPS

    # Scale to fill content area (crop if needed to maintain aspect)
    scale = f"scale={W}:{LH}:force_original_aspect_ratio=increase,crop={W}:{LH}"

    # Pad to full 1080p with black bars
    pad = f"pad={W}:{H}:0:{PAD_Y}:black"

    # FPS normalization
    fps = f"fps={FPS}"

    filters = [scale, pad, fps]

    grade = config.COLOR_GRADES.get(color_grade, "")
    if grade:
        filters.append(grade)

    return ",".join(filters)


def extract_clip(
    clip_index: int,
    umd_id: str,
    clip_start: int,
    clip_end: int,
    color_grade: str,
    temp_dir: Path,
) -> ExtractedClip:
    """
    Extract, grade and letterbox a single clip.

    Args:
        clip_index:  Position in the video (1-based)
        umd_id:      Content identifier
        clip_start:  Start time in seconds (from manifest)
        clip_end:    End time in seconds (from manifest)
        color_grade: "CINEMATIC" | "COOL" | "WARM" | "NONE"
        temp_dir:    Where to write the temp file

    Returns:
        ExtractedClip with path to processed temp file
    """
    source = _find_source(umd_id)
    duration = clip_end - clip_start
    output_path = temp_dir / f"{clip_index:02d}_clip_{umd_id}.mp4"

    logger.info(
        f"Extracting clip {clip_index} [{umd_id}] "
        f"{clip_start}s→{clip_end}s ({duration}s) grade={color_grade}"
    )

    vf = _build_video_filter(color_grade)

    run([
        "-ss", str(clip_start),
        "-to", str(clip_end),
        "-i", str(source),
        "-vf", vf,
        "-c:v", config.OUTPUT_CODEC,
        "-crf", str(config.OUTPUT_CRF),
        "-preset", config.OUTPUT_PRESET,
        "-c:a", "aac",
        "-b:a", "192k",
        "-ar", "44100",
        "-ac", "2",
        "-avoid_negative_ts", "make_zero",
        str(output_path),
    ], label=f"extract clip {clip_index}")

    return ExtractedClip(
        clip_index=clip_index,
        umd_id=umd_id,
        path=output_path,
        duration=duration,
    )


def run_all(manifest: dict, temp_dir: Path) -> list[ExtractedClip]:
    """Extract all clips defined in the manifest."""
    color_grade = manifest.get("metadata", {}).get("videoStyle", {}).get("colorGrade", "CINEMATIC")
    clips = []
    for clip in manifest["clips"]:
        extracted = extract_clip(
            clip_index=clip["clipIndex"],
            umd_id=clip["umdId"],
            clip_start=clip["clipStart"],
            clip_end=clip["clipEnd"],
            color_grade=color_grade,
            temp_dir=temp_dir,
        )
        clips.append(extracted)
    return clips
