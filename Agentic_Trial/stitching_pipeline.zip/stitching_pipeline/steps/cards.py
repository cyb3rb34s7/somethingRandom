"""
stitching_pipeline/steps/cards.py  — Steps 3 + 4

Generates:
  - Title card: black video + centered text (e.g. "BECAUSE YOU WATCHED")
  - End card:   black video + content title + "Watch Now"

Both are short MP4 segments that get concatenated with the main clips.
"""

import logging
from pathlib import Path
from dataclasses import dataclass

import config
from ffmpeg_runner import run

logger = logging.getLogger(__name__)

W    = config.OUTPUT_WIDTH
H    = config.OUTPUT_HEIGHT
LH   = config.LETTERBOX_HEIGHT
PY   = config.LETTERBOX_PAD_Y
FPS  = config.OUTPUT_FPS


def _escape(text: str) -> str:
    return (
        text
        .replace("\\", "\\\\")
        .replace("'",  "\u2019")
        .replace(":",  "\\:")
        .replace(",",  "\\,")
    )


def _card_base_filter() -> str:
    """Black background at target resolution with letterbox."""
    return (
        f"color=c=black:size={W}x{H}:rate={FPS},"
        f"drawbox=x=0:y=0:w={W}:h={PY}:color=black:t=fill,"
        f"drawbox=x=0:y={PY + LH}:w={W}:h={PY}:color=black:t=fill"
    )


# ---------------------------------------------------------------------------
# Title card
# ---------------------------------------------------------------------------

@dataclass
class CardSegment:
    path:     Path
    duration: float


def generate_title_card(title_card: dict, temp_dir: Path) -> CardSegment:
    """
    Generate the opening title card.
    e.g. "BECAUSE YOU WATCHED" in large Bebas Neue, centered, white on black.

    Args:
        title_card: dict from manifest.metadata.titleCard
        temp_dir:   Temp directory

    Returns:
        CardSegment with path to MP4
    """
    text     = _escape(title_card.get("text", "RECOMMENDED FOR YOU"))
    duration = float(title_card.get("durationSeconds", 2.0))
    output   = temp_dir / "00_title_card.mp4"

    center_y = PY + LH // 2
    fade_d   = 0.25

    # Alpha: fade in over 0.25s, hold, fade out over 0.25s
    alpha = (
        f"if(lt(t,{fade_d}),t/{fade_d},"
        f"if(lt(t,{duration - fade_d}),1,"
        f"({duration}-t)/{fade_d}))"
    )

    vf = (
        f"{_card_base_filter()},"
        f"drawtext="
        f"text='{text}':"
        f"font='{config.FONT_IMPACT}':"
        f"fontsize=96:"
        f"fontcolor=white:"
        f"shadowcolor=black@0.5:"
        f"shadowx=3:shadowy=3:"
        f"borderw=2:bordercolor=black@0.4:"
        f"x=(w-text_w)/2:"
        f"y={center_y}-(text_h/2):"
        f"alpha='{alpha}':"
        f"fix_bounds=true"
    )

    logger.info(f"Generating title card: '{text}' ({duration}s)")

    run([
        "-f", "lavfi",
        "-i", f"color=c=black:size={W}x{H}:rate={FPS}:duration={duration}",
        "-f", "lavfi",
        "-i", f"aevalsrc=0:c=stereo:r=44100:d={duration}",
        "-vf", vf,
        "-c:v", config.OUTPUT_CODEC,
        "-crf", str(config.OUTPUT_CRF),
        "-preset", config.OUTPUT_PRESET,
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", str(duration),
        str(output),
    ], label="title card")

    return CardSegment(path=output, duration=duration)


# ---------------------------------------------------------------------------
# End card
# ---------------------------------------------------------------------------

def generate_end_card(end_card: dict, temp_dir: Path) -> CardSegment:
    """
    Generate the closing end card.
    Two lines: content title (large) + "Watch Now" (smaller, below).

    Args:
        end_card: dict from manifest.endCard
        temp_dir: Temp directory

    Returns:
        CardSegment with path to MP4
    """
    title    = _escape(end_card.get("text", "Watch Now"))
    duration = float(end_card.get("durationSeconds", 2.0))
    output   = temp_dir / "99_end_card.mp4"

    center_y   = PY + LH // 2
    title_y    = center_y - 60
    subtitle_y = center_y + 40

    fade_d = 0.25
    alpha = (
        f"if(lt(t,{fade_d}),t/{fade_d},"
        f"if(lt(t,{duration - fade_d}),1,"
        f"({duration}-t)/{fade_d}))"
    )

    # Title line — large Bebas Neue
    title_dt = (
        f"drawtext="
        f"text='{title}':"
        f"font='{config.FONT_IMPACT}':"
        f"fontsize=88:"
        f"fontcolor=white:"
        f"shadowcolor=black@0.4:shadowx=2:shadowy=2:"
        f"x=(w-text_w)/2:y={title_y}:"
        f"alpha='{alpha}':"
        f"fix_bounds=true"
    )

    # "Watch Now" — smaller Montserrat
    sub_dt = (
        f"drawtext="
        f"text='WATCH NOW':"
        f"font='{config.FONT_BODY}':"
        f"fontsize=42:"
        f"fontcolor=white@0.85:"
        f"x=(w-text_w)/2:y={subtitle_y}:"
        f"alpha='{alpha}':"
        f"fix_bounds=true"
    )

    vf = f"{_card_base_filter()},{title_dt},{sub_dt}"

    logger.info(f"Generating end card: '{title}' ({duration}s)")

    run([
        "-f", "lavfi",
        "-i", f"color=c=black:size={W}x{H}:rate={FPS}:duration={duration}",
        "-f", "lavfi",
        "-i", f"aevalsrc=0:c=stereo:r=44100:d={duration}",
        "-vf", vf,
        "-c:v", config.OUTPUT_CODEC,
        "-crf", str(config.OUTPUT_CRF),
        "-preset", config.OUTPUT_PRESET,
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", str(duration),
        str(output),
    ], label="end card")

    return CardSegment(path=output, duration=duration)
