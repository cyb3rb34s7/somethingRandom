"""
stitching_pipeline/steps/compositor.py  — Step 5

Concatenates all video segments in order:
  title_card → clip1 → [transition_overlay] → clip2 → ... → end_card

Applies xfade transitions between segments.
Transition overlay text is rendered onto the transition itself.

Output: temp/composed_video.mp4  (video only — audio added in step 6)
"""

import logging
from pathlib import Path
from dataclasses import dataclass

import config
from ffmpeg_runner import run
from steps.extractor import ExtractedClip
from steps.overlayer import OverlaidClip
from steps.cards import CardSegment

logger = logging.getLogger(__name__)

W   = config.OUTPUT_WIDTH
H   = config.OUTPUT_HEIGHT
FPS = config.OUTPUT_FPS
TD  = config.TRANSITION_DURATION   # transition duration in seconds

# ---------------------------------------------------------------------------
# Transition type → xfade transition name
# ---------------------------------------------------------------------------

XFADE_MAP = {
    "FADE_BLACK":  "fade",
    "FADE_WHITE":  "fadewhite",
    "FLASH_CUT":   "fadewhite",   # fast fadewhite simulates flash cut
    "CROSSFADE":   "dissolve",
    "HARD_CUT":    "fade",        # 0 duration effectively = hard cut
}

XFADE_DURATION = {
    "FADE_BLACK":  TD,
    "FADE_WHITE":  TD,
    "FLASH_CUT":   0.15,   # very fast — flash feel
    "CROSSFADE":   TD,
    "HARD_CUT":    0.0,
}


# ---------------------------------------------------------------------------
# Segment — unified type for all video pieces going into the compositor
# ---------------------------------------------------------------------------

@dataclass
class Segment:
    path:           Path
    duration:       float
    transition_type: str = "FADE_BLACK"  # transition OUT of this segment


# ---------------------------------------------------------------------------
# Two-clip xfade
# ---------------------------------------------------------------------------

def _xfade_two(
    seg_a: Path,
    dur_a: float,
    seg_b: Path,
    transition_type: str,
    output: Path,
) -> float:
    """
    Crossfade seg_a into seg_b using xfade filter.
    Returns duration of the combined output.
    """
    xfade_name = XFADE_MAP.get(transition_type, "fade")
    xfade_dur  = XFADE_DURATION.get(transition_type, TD)

    if xfade_dur == 0.0:
        # Hard cut — just concatenate directly
        concat_list = output.parent / f"_concat_{output.stem}.txt"
        with open(concat_list, "w") as f:
            f.write(f"file '{seg_a.resolve()}'\n")
            f.write(f"file '{seg_b.resolve()}'\n")
        run([
            "-f", "concat", "-safe", "0",
            "-i", str(concat_list),
            "-c", "copy",
            str(output),
        ], label=f"hard cut → {output.name}")
        concat_list.unlink()
        return dur_a + dur_a  # approximate
    else:
        # xfade offset = start of seg_a's end overlap with seg_b
        offset = max(0.01, dur_a - xfade_dur)

        run([
            "-i", str(seg_a),
            "-i", str(seg_b),
            "-filter_complex",
            f"[0:v][1:v]xfade=transition={xfade_name}:duration={xfade_dur}:offset={offset:.3f}[v];"
            f"[0:a][1:a]acrossfade=d={xfade_dur}[a]",
            "-map", "[v]",
            "-map", "[a]",
            "-c:v", config.OUTPUT_CODEC,
            "-crf", str(config.OUTPUT_CRF),
            "-preset", config.OUTPUT_PRESET,
            "-c:a", "aac",
            "-b:a", "192k",
            str(output),
        ], label=f"xfade {xfade_name} → {output.name}")

        return dur_a + dur_a - xfade_dur  # approximate combined duration


# ---------------------------------------------------------------------------
# Add transition overlay text on top of a transition segment
# ---------------------------------------------------------------------------

def _add_transition_overlay(
    video_path: Path,
    overlay_text: str,
    total_duration: float,
    output: Path,
) -> None:
    """Burn the transition overlay text (e.g. 'THINK AGAIN.') onto the transition segment."""
    from steps.overlayer import _escape, STYLE_PARAMS, _position_xy

    text   = _escape(overlay_text)
    params = STYLE_PARAMS["CINEMATIC_BOLD"]
    x, y   = _position_xy("CENTER", params["fontsize"])
    half   = total_duration / 2
    fade   = 0.2

    alpha = (
        f"if(lt(t,{fade}),t/{fade},"
        f"if(lt(t,{half}),1,"
        f"if(lt(t,{total_duration - fade}),({total_duration - fade}-t)/{total_duration - 2*fade},"
        f"0)))"
    )

    vf = (
        f"drawtext="
        f"text='{text}':"
        f"font='{config.FONT_IMPACT}':"
        f"fontsize={params['fontsize']}:"
        f"fontcolor={params['fontcolor']}:"
        f"shadowcolor={params['shadowcolor']}:"
        f"shadowx={params['shadowx']}:shadowy={params['shadowy']}:"
        f"borderw={params['borderw']}:bordercolor={params['bordercolor']}:"
        f"x={x}:y={y}:"
        f"alpha='{alpha}':"
        f"fix_bounds=true"
    )

    run([
        "-i", str(video_path),
        "-vf", vf,
        "-c:v", config.OUTPUT_CODEC,
        "-crf", str(config.OUTPUT_CRF),
        "-preset", config.OUTPUT_PRESET,
        "-c:a", "copy",
        str(output),
    ], label="transition overlay text")


# ---------------------------------------------------------------------------
# Main compositor
# ---------------------------------------------------------------------------

def compose(
    title_card: CardSegment,
    overlaid_clips: list[OverlaidClip],
    end_card: CardSegment,
    manifest: dict,
    temp_dir: Path,
) -> Path:
    """
    Compose all segments into a single video with transitions.

    Order: title_card → clip1 → transition_overlay → clip2 → ... → end_card

    Returns:
        Path to final composed video (no music — audio added in step 6)
    """
    logger.info("Compositing video segments...")

    # Build transition overlay lookup: afterClipIndex → text
    trans_overlay_map = {
        t["afterClipIndex"]: t
        for t in manifest.get("transitionOverlays", [])
    }

    # Build transition type lookup: clipIndex → transitionIn
    trans_type_map = {
        c["clipIndex"]: c.get("transitionIn", "FADE_BLACK")
        for c in manifest["clips"]
    }

    # ── Start with title card ──────────────────────────────────────
    current_path = title_card.path
    current_dur  = title_card.duration
    step         = 0

    for i, clip in enumerate(overlaid_clips):
        step += 1
        trans_type  = trans_type_map.get(clip.clip_index, "FADE_BLACK")
        merged_path = temp_dir / f"compose_{step:02d}.mp4"

        current_dur = _xfade_two(
            seg_a=current_path,
            dur_a=current_dur,
            seg_b=clip.path,
            transition_type=trans_type,
            output=merged_path,
        )
        current_path = merged_path

        # ── Add transition overlay text if defined after this clip ──
        if clip.clip_index in trans_overlay_map:
            t_ov    = trans_overlay_map[clip.clip_index]
            ov_text = t_ov.get("text", "")
            ov_dur  = t_ov.get("durationMs", 1200) / 1000

            if ov_text:
                step += 1
                ov_path = temp_dir / f"compose_{step:02d}_transov.mp4"
                _add_transition_overlay(current_path, ov_text, ov_dur, ov_path)
                current_path = ov_path

    # ── Append end card ───────────────────────────────────────────
    step += 1
    final_path = temp_dir / "composed_video.mp4"
    _xfade_two(
        seg_a=current_path,
        dur_a=current_dur,
        seg_b=end_card.path,
        transition_type="FADE_BLACK",
        output=final_path,
    )

    logger.info(f"Composition complete → {final_path}")
    return final_path
