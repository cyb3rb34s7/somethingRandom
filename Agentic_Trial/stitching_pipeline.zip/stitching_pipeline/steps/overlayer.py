"""
stitching_pipeline/steps/overlayer.py  — Step 2

Renders text overlays onto extracted clips using ffmpeg drawtext filter.
Supports fade in/out, all position types, and both font styles.
Input:  temp/{n}_clip_{umdId}.mp4
Output: temp/{n}_overlaid_{umdId}.mp4
"""

import logging
from pathlib import Path
from dataclasses import dataclass

import config
from ffmpeg_runner import run
from steps.extractor import ExtractedClip

logger = logging.getLogger(__name__)

W  = config.OUTPUT_WIDTH
H  = config.OUTPUT_HEIGHT
LH = config.LETTERBOX_HEIGHT
PY = config.LETTERBOX_PAD_Y   # top letterbox bar height

# ---------------------------------------------------------------------------
# Font + style definitions
# ---------------------------------------------------------------------------

STYLE_PARAMS = {
    "CINEMATIC_BOLD": {
        "font":       config.FONT_IMPACT,
        "fontsize":   92,
        "fontcolor":  "white",
        "shadowcolor": "black@0.8",
        "shadowx":    3,
        "shadowy":    3,
        "borderw":    2,
        "bordercolor": "black@0.6",
    },
    "SUBTLE": {
        "font":       config.FONT_BODY,
        "fontsize":   48,
        "fontcolor":  "white@0.92",
        "shadowcolor": "black@0.7",
        "shadowx":    2,
        "shadowy":    2,
        "borderw":    1,
        "bordercolor": "black@0.5",
    },
    "BRAND": {
        "font":       config.FONT_BODY,
        "fontsize":   56,
        "fontcolor":  "white",
        "shadowcolor": "black@0.0",
        "shadowx":    0,
        "shadowy":    0,
        "borderw":    0,
        "bordercolor": "black@0.0",
    },
}

# ---------------------------------------------------------------------------
# Position → (x expression, y expression)
# All positions are within the letterbox content area
# ---------------------------------------------------------------------------

def _position_xy(position: str, fontsize: int) -> tuple[str, str]:
    content_top    = PY                       # top of letterbox content area
    content_bottom = PY + LH                  # bottom of letterbox content area
    center_y       = content_top + LH // 2    # vertical center of content
    margin         = 60

    positions = {
        "CENTER":       ("(w-text_w)/2",     f"{center_y}-(text_h/2)"),
        "TOP_CENTER":   ("(w-text_w)/2",     f"{content_top + margin}"),
        "BOTTOM_CENTER":("(w-text_w)/2",     f"{content_bottom - fontsize - margin}"),
        "LOWER_THIRD":  (f"{margin}",        f"{content_bottom - fontsize - margin}"),
    }
    return positions.get(position, positions["CENTER"])


# ---------------------------------------------------------------------------
# Drawtext filter builder
# ---------------------------------------------------------------------------

FADE_DURATION = 0.3   # seconds for text fade in / fade out


def _drawtext_filter(
    text: str,
    position: str,
    appear_at: float,
    hold_seconds: float,
    style: str,
) -> str:
    """
    Build a single drawtext filter expression with alpha fade in/out.

    fade_in:  appear_at → appear_at + FADE_DURATION
    hold:     appear_at + FADE_DURATION → appear_at + hold_seconds - FADE_DURATION
    fade_out: appear_at + hold_seconds - FADE_DURATION → appear_at + hold_seconds
    """
    params = STYLE_PARAMS.get(style, STYLE_PARAMS["SUBTLE"])
    x, y = _position_xy(position, params["fontsize"])

    fade_in_start  = appear_at
    fade_in_end    = appear_at + FADE_DURATION
    fade_out_start = appear_at + hold_seconds - FADE_DURATION
    fade_out_end   = appear_at + hold_seconds

    # Alpha expression — 0 outside window, linear fade in/out, 1 during hold
    alpha = (
        f"if(lt(t,{fade_in_start:.3f}),0,"
        f"if(lt(t,{fade_in_end:.3f}),(t-{fade_in_start:.3f})/{FADE_DURATION},"
        f"if(lt(t,{fade_out_start:.3f}),1,"
        f"if(lt(t,{fade_out_end:.3f}),({fade_out_end:.3f}-t)/{FADE_DURATION},"
        f"0))))"
    )

    # Escape special chars in text for ffmpeg drawtext
    safe_text = (
        text
        .replace("\\", "\\\\")
        .replace("'",  "\u2019")   # smart apostrophe — avoids ffmpeg quote issues
        .replace(":",  "\\:")
        .replace(",",  "\\,")
    )

    parts = [
        f"text='{safe_text}'",
        f"font='{params['font']}'",
        f"fontsize={params['fontsize']}",
        f"fontcolor={params['fontcolor']}",
        f"shadowcolor={params['shadowcolor']}",
        f"shadowx={params['shadowx']}",
        f"shadowy={params['shadowy']}",
        f"borderw={params['borderw']}",
        f"bordercolor={params['bordercolor']}",
        f"x={x}",
        f"y={y}",
        f"alpha='{alpha}'",
        "fix_bounds=true",
    ]

    return f"drawtext={':'.join(parts)}"


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

@dataclass
class OverlaidClip:
    clip_index: int
    umd_id:     str
    path:       Path
    duration:   float


def apply_overlays(
    extracted: ExtractedClip,
    overlays: list[dict],
    temp_dir: Path,
) -> OverlaidClip:
    """
    Apply text overlays to an extracted clip.
    If no overlays, just copies the file reference (no ffmpeg call needed).

    Args:
        extracted: ExtractedClip from step 1
        overlays:  List of overlay dicts from manifest clip
        temp_dir:  Temp directory for output

    Returns:
        OverlaidClip pointing to the processed file
    """
    output_path = temp_dir / f"{extracted.clip_index:02d}_overlaid_{extracted.umd_id}.mp4"

    if not overlays:
        logger.info(f"Clip {extracted.clip_index} [{extracted.umd_id}] — no overlays, skipping drawtext")
        # Symlink or copy to keep consistent naming
        import shutil
        shutil.copy2(str(extracted.path), str(output_path))
        return OverlaidClip(
            clip_index=extracted.clip_index,
            umd_id=extracted.umd_id,
            path=output_path,
            duration=extracted.duration,
        )

    drawtext_filters = [
        _drawtext_filter(
            text=ov["text"],
            position=ov["position"],
            appear_at=float(ov["appearAtSecond"]),
            hold_seconds=float(ov["holdSeconds"]),
            style=ov["style"],
        )
        for ov in overlays
    ]

    # Chain all drawtext filters
    vf = ",".join(drawtext_filters)

    logger.info(
        f"Clip {extracted.clip_index} [{extracted.umd_id}] — "
        f"applying {len(overlays)} overlay(s)"
    )

    run([
        "-i", str(extracted.path),
        "-vf", vf,
        "-c:v", config.OUTPUT_CODEC,
        "-crf", str(config.OUTPUT_CRF),
        "-preset", config.OUTPUT_PRESET,
        "-c:a", "copy",
        str(output_path),
    ], label=f"overlay clip {extracted.clip_index}")

    return OverlaidClip(
        clip_index=extracted.clip_index,
        umd_id=extracted.umd_id,
        path=output_path,
        duration=extracted.duration,
    )


def run_all(
    extracted_clips: list[ExtractedClip],
    manifest: dict,
    temp_dir: Path,
) -> list[OverlaidClip]:
    """Apply overlays to all clips."""
    # Build lookup: clipIndex → overlays list
    overlay_map = {
        clip["clipIndex"]: clip.get("overlays", [])
        for clip in manifest["clips"]
    }

    overlaid = []
    for clip in extracted_clips:
        overlays = overlay_map.get(clip.clip_index, [])
        overlaid.append(apply_overlays(clip, overlays, temp_dir))
    return overlaid
