"""
stitching_pipeline/ffmpeg_runner.py

Thin wrapper around ffmpeg subprocess calls.
Every ffmpeg invocation in the pipeline goes through here.
"""

import logging
import subprocess
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


class FFmpegError(Exception):
    pass


def check_ffmpeg():
    if not shutil.which("ffmpeg"):
        raise FFmpegError("ffmpeg not found in PATH. Please install ffmpeg.")
    if not shutil.which("ffprobe"):
        raise FFmpegError("ffprobe not found in PATH. Please install ffmpeg.")


def run(args: list[str], label: str = "") -> subprocess.CompletedProcess:
    """
    Run an ffmpeg command.

    Args:
        args:  Full argument list — do NOT include 'ffmpeg' as first element
        label: Human readable label for logging

    Returns:
        CompletedProcess

    Raises:
        FFmpegError on non-zero exit
    """
    cmd = ["ffmpeg", "-y"] + args   # -y = overwrite output without asking
    label_str = f"[{label}] " if label else ""

    logger.debug(f"{label_str}Running: {' '.join(cmd)}")

    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    if result.returncode != 0:
        logger.error(f"{label_str}ffmpeg failed:\n{result.stderr[-3000:]}")
        raise FFmpegError(
            f"ffmpeg failed (exit {result.returncode}) during: {label}\n"
            f"{result.stderr[-1000:]}"
        )

    logger.debug(f"{label_str}OK")
    return result


def probe(path: str) -> dict:
    """
    Run ffprobe on a file or URL and return stream info.
    Works with both local MP4 files and HLS .m3u8 URLs.
    """
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        str(path),
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        raise FFmpegError(f"ffprobe failed on {path}:\n{result.stderr}")

    import json
    return json.loads(result.stdout)


def get_duration(path: str) -> float:
    """Return duration in seconds for a video file or HLS stream."""
    info = probe(path)
    return float(info["format"]["duration"])


def detect_input_type(path_or_url: str) -> str:
    """
    Returns 'hls' if the input is an HLS manifest, 'mp4' otherwise.
    ffmpeg handles both — this is only used for logging.
    """
    s = str(path_or_url).lower()
    if s.endswith(".m3u8") or s.startswith("http"):
        return "hls"
    return "mp4"
