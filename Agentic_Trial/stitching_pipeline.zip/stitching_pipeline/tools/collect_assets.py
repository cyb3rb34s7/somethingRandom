"""
stitching_pipeline/tools/collect_assets.py

Downloads required font files for the stitching pipeline.
Run once before using stitch.py:
    python tools/collect_assets.py

Fonts used:
  - Bebas Neue (impact text, overlays, title cards)
  - Montserrat Bold (supporting text, end cards)

Both are free under SIL Open Font License from Google Fonts.
"""

import urllib.request
import urllib.error
import zipfile
import io
import sys
from pathlib import Path

FONTS_DIR = Path("fonts")

FONTS = [
    {
        "name": "BebasNeue-Regular.ttf",
        "url": "https://fonts.gstatic.com/s/bebasneue/v14/JTUSjIg69CK48gW7PXoo9Wlhyw.woff2",
        "fallback_url": "https://github.com/google/fonts/raw/main/ofl/bebasneue/BebasNeue-Regular.ttf",
    },
    {
        "name": "Montserrat-Bold.ttf",
        "url": "https://fonts.gstatic.com/s/montserrat/v26/JTUHjIg1_i6t8kCHKm4532VJOt5-QNFgpCtr6Xw0aXpsog.woff2",
        "fallback_url": "https://github.com/google/fonts/raw/main/ofl/montserrat/static/Montserrat-Bold.ttf",
    },
]


def _download_font(font: dict) -> bool:
    dest = FONTS_DIR / font["name"]
    if dest.exists():
        print(f"  ✓ Already exists — {font['name']}")
        return True

    headers = {"User-Agent": "Mozilla/5.0 (compatible; asset-collector/1.0)"}

    for url in [font["fallback_url"], font["url"]]:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
            if len(data) < 1000:
                continue
            dest.write_bytes(data)
            print(f"  ✓ Downloaded {font['name']} ({len(data)//1024}KB)")
            return True
        except Exception as e:
            print(f"  ✗ Failed from {url}: {e}")
            continue

    return False


def main():
    print(f"\n{'='*50}")
    print(f"  Asset Collector — Stitching Pipeline")
    print(f"{'='*50}\n")

    FONTS_DIR.mkdir(exist_ok=True)

    print("Downloading fonts...")
    ok = all(_download_font(f) for f in FONTS)

    if not ok:
        print(
            "\nSome fonts failed to download automatically.\n"
            "Please download manually:\n"
            "  Bebas Neue:  https://fonts.google.com/specimen/Bebas+Neue\n"
            "  Montserrat:  https://fonts.google.com/specimen/Montserrat\n"
            f"Place the .ttf files in: {FONTS_DIR.resolve()}\n"
        )
        sys.exit(1)

    print(f"\n✓ All assets ready in {FONTS_DIR.resolve()}")
    print("You can now run the stitching pipeline.\n")


if __name__ == "__main__":
    main()
