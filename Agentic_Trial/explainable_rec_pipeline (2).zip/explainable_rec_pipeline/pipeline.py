"""
pipeline.py

Orchestrates the full pipeline: T1 → T2 → T3 → T5 → T6A → [human pause] → T7+T8

Two-phase flow:
  Phase 1: run_phase1(event, client) → saves scene_selection.json, pauses
  Phase 2: run_phase2(scene_selection_path, client) → produces manifest.json

Human review happens between phases:
  Open scene_selection.json, set clipStart + clipEnd on each scene, save.
"""

import json
import sys
from pathlib import Path
from datetime import datetime

from shared.ai_client import BaseAIClient
from shared.logger import PipelineLogger, _serialize
from shared.schemas import SceneSelectionOutput, PipelineStatus

from modules.input_aggregator import module as input_aggregator
from modules.classifier import module as classifier
from modules.pretag_loader import module as pretag_loader
from modules.correlation_engine import module as correlation_engine
from modules.scene_selector import module as scene_selector
from modules.manifest_builder import module as manifest_builder

STATE_DIR = Path("pipeline_state")


def run_phase1(raw_event: dict, client: BaseAIClient) -> tuple[PipelineStatus, Path]:
    """
    Run T1 → T2 → T3 → T5 → T6A.
    Saves intermediate state for human review.
    Returns (AWAITING_TIMESTAMPS, path_to_scene_selection_json)
    """
    log = PipelineLogger()
    log.info("=== PHASE 1 STARTED ===")

    try:
        # T1 — Input Aggregator
        context = input_aggregator.run(raw_event)
        log.log_step("input_aggregator", raw_event, _serialize(context))

        # T2 — Classifier
        classification = classifier.run(context, client)
        log.log_step("classifier", _serialize(context), _serialize(classification))

        # T3 — Pretag Loader
        pretag = pretag_loader.run(classification)
        log.log_step("pretag_loader", _serialize(classification), _serialize(pretag))

        # T5 — Correlation / Highlight Engine
        engine_output = correlation_engine.run(pretag, context, classification, client)
        log.log_step("correlation_engine", _serialize(pretag), _serialize(engine_output))

        # T6A — Scene Selector
        scenes = scene_selector.run(engine_output, pretag, client)
        log.log_step("scene_selector", _serialize(engine_output), _serialize(scenes))

        # Save state for phase 2
        STATE_DIR.mkdir(exist_ok=True)
        run_id = log.run_id
        state = {
            "run_id": run_id,
            "log_dir": str(log.run_dir),
            "classification": _serialize(classification),
            "engine_output": _serialize(engine_output),
            "scene_selection": _serialize(scenes),
            "instructions": (
                "Edit 'scene_selection.selectedScenes' — "
                "set 'clipStart' and 'clipEnd' (in seconds) for each scene, then run phase 2."
            ),
        }
        state_path = STATE_DIR / f"state_{run_id}.json"
        with open(state_path, "w") as f:
            json.dump(state, f, indent=2, default=str)

        log.info(f"=== PHASE 1 COMPLETE ===")
        log.info(f"State saved → {state_path}")
        log.info("Next: Set clipStart + clipEnd in the state file, then run phase 2.")

        return PipelineStatus.AWAITING_TIMESTAMPS, state_path

    except Exception as e:
        log.error(f"Phase 1 failed: {e}")
        raise


def run_phase2(state_path: Path, client: BaseAIClient) -> tuple[PipelineStatus, dict]:
    """
    Resume from saved state after human timestamp injection.
    Runs T7 + T8 → produces final manifest.
    Returns (COMPLETE, manifest_dict)
    """
    log = PipelineLogger()
    log.info(f"=== PHASE 2 STARTED — state: {state_path} ===")

    try:
        with open(state_path) as f:
            state = json.load(f)

        from shared.schemas import (
            ClassificationResult, CorrelationOutput, HighlightOutput,
            SceneSelectionOutput, OutputMode,
        )

        classification = ClassificationResult.model_validate(state["classification"])

        # Reconstruct engine output from saved state
        engine_raw = state["engine_output"]
        if engine_raw.get("mode") == "CORRELATION":
            engine_output = CorrelationOutput.model_validate(engine_raw)
        else:
            engine_output = HighlightOutput.model_validate(engine_raw)

        scenes = SceneSelectionOutput.model_validate(state["scene_selection"])

        if not scenes.is_timestamps_complete():
            missing = [
                s.contentId for s in scenes.selectedScenes
                if s.clipStart is None or s.clipEnd is None
            ]
            raise ValueError(
                f"clipStart/clipEnd not set for: {missing}. "
                f"Edit {state_path} and try again."
            )

        # T7 + T8 — Manifest Builder
        manifest = manifest_builder.run(scenes, engine_output, classification, client)
        log.log_step("manifest_builder", _serialize(scenes), _serialize(manifest))

        log.info("=== PHASE 2 COMPLETE ===")
        log.info(f"Tag: {manifest.tag}")
        log.info(f"One-liner: {manifest.oneLiner}")

        return PipelineStatus.COMPLETE, manifest.model_dump()

    except Exception as e:
        log.error(f"Phase 2 failed: {e}")
        raise
