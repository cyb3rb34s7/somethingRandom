"""
shared/config.py

Environment-based configuration for the pipeline.
All tuneable names, paths, and flags live here.
Set via environment variables or .env file.
"""

import os
from pathlib import Path


def _env(key: str, default: str) -> str:
    return os.environ.get(key, default)


# ---------------------------------------------------------------------------
# Pretag file naming — override via environment variables
# ---------------------------------------------------------------------------

PRETAG_BASE_DIR         = Path(_env("PRETAG_BASE_DIR",          "pretag_data"))
PRETAG_SCENES_FILE      = _env("PRETAG_SCENES_FILE",            "scenes.json")
PRETAG_THEME_FILE       = _env("PRETAG_THEME_FILE",             "theme.json")
PRETAG_TOP_SCENES_FILE  = _env("PRETAG_TOP_SCENES_FILE_NAMING", "top-scenes.json")

# ---------------------------------------------------------------------------
# Pipeline paths
# ---------------------------------------------------------------------------

STATE_DIR               = Path(_env("PIPELINE_STATE_DIR",       "pipeline_state"))
OUTPUT_MANIFEST_DIR     = Path(_env("PIPELINE_OUTPUT_DIR",      "output_manifests"))
LOG_BASE_DIR            = _env("PIPELINE_LOG_DIR",              "logs")
VIDEO_STORE_DIR         = Path(_env("VIDEO_STORE_DIR",          "video_store"))

# ---------------------------------------------------------------------------
# UMD
# ---------------------------------------------------------------------------

UMD_DATA_DIR            = Path(_env("UMD_DATA_DIR",             "umd_data"))
UMD_DATA_FILE           = _env("UMD_DATA_FILE",                 "umd_metadata.json")
