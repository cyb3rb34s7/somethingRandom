"""
shared/logger.py

Structured pipeline logger.
Creates a dated folder per run, one log file per step capturing input + output.
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path


class PipelineLogger:
    """
    Creates: logs/YYYY-MM-DD_HH-MM-SS/
      ├── pipeline.log     — human readable full run log
      ├── 01_input_aggregator.json
      ├── 02_classifier.json
      ├── 03_pretag_loader.json
      ├── 05_correlation_engine.json
      ├── 06_scene_selector.json
      └── 08_manifest_builder.json
    """

    STEP_FILES = {
        "input_aggregator":   "01_input_aggregator.json",
        "classifier":         "02_classifier.json",
        "pretag_loader":      "03_pretag_loader.json",
        "correlation_engine": "05_correlation_engine.json",
        "scene_selector":     "06_scene_selector.json",
        "manifest_builder":   "08_manifest_builder.json",
    }

    def __init__(self, base_log_dir: str = "logs"):
        self.run_id = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.run_dir = Path(base_log_dir) / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=True)

        # Human-readable pipeline log
        log_file = self.run_dir / "pipeline.log"
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(),  # also print to terminal
            ],
        )
        self.logger = logging.getLogger("pipeline")
        self.logger.info(f"Run started — ID: {self.run_id}")
        self.logger.info(f"Logs at: {self.run_dir}")

    def log_step(self, step: str, input_data: dict, output_data: dict, error: str = None):
        """Write input + output for a pipeline step to its own JSON file."""
        filename = self.STEP_FILES.get(step, f"{step}.json")
        filepath = self.run_dir / filename

        payload = {
            "step": step,
            "timestamp": datetime.now().isoformat(),
            "status": "error" if error else "success",
            "input": input_data,
            "output": output_data if not error else None,
            "error": error,
        }

        with open(filepath, "w") as f:
            json.dump(payload, f, indent=2, default=str)

        if error:
            self.logger.error(f"[{step}] FAILED — {error}")
        else:
            self.logger.info(f"[{step}] OK")

    def info(self, msg: str):
        self.logger.info(msg)

    def error(self, msg: str):
        self.logger.error(msg)


def _serialize(obj) -> dict:
    """Convert Pydantic model or plain dict to JSON-serializable dict."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    return obj if isinstance(obj, dict) else {"value": str(obj)}
