"""
shared/ai_client.py

Provider-agnostic AI client. One implementation, used by every module.
"""

import os
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class AIResponse:
    content: str
    provider: str
    model: str


class BaseAIClient(ABC):
    @abstractmethod
    def complete(self, system_prompt: str, user_prompt: str,
                 temperature: float = 0.3, max_tokens: int = 2048) -> AIResponse:
        pass


class OpenAIClient(BaseAIClient):
    def __init__(self, model: str = "gpt-4o", api_key: Optional[str] = None):
        from openai import OpenAI
        self.model = model
        self.client = OpenAI(api_key=api_key or os.environ["OPENAI_API_KEY"])

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model, temperature=temperature, max_tokens=max_tokens,
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": user_prompt}],
        )
        return AIResponse(response.choices[0].message.content, "openai", self.model)


class GroqClient(BaseAIClient):
    def __init__(self, model: str = "llama-3.3-70b-versatile", api_key: Optional[str] = None):
        from groq import Groq
        self.model = model
        self.client = Groq(api_key=api_key or os.environ["GROQ_API_KEY"])

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model, temperature=temperature, max_tokens=max_tokens,
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": user_prompt}],
        )
        return AIResponse(response.choices[0].message.content, "groq", self.model)


class BedrockClient(BaseAIClient):
    def __init__(self, model: str = "anthropic.claude-3-5-sonnet-20241022-v2:0", region: str = "us-east-1"):
        import boto3
        self.model = model
        self.client = boto3.client("bedrock-runtime", region_name=region)

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens, "temperature": temperature,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        })
        response = self.client.invoke_model(
            modelId=self.model, contentType="application/json",
            accept="application/json", body=body,
        )
        result = json.loads(response["body"].read())
        return AIResponse(result["content"][0]["text"], "bedrock", self.model)


class GeminiClient(BaseAIClient):
    def __init__(self, model: str = "gemini-2.5-flash-preview-04-17", api_key: Optional[str] = None):
        from google import genai
        from google.genai import types
        self.model = model
        self.types = types
        self.client = genai.Client(api_key=api_key or os.environ["GEMINI_API_KEY"])

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.models.generate_content(
            model=self.model,
            contents=user_prompt,
            config=self.types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=temperature,
                max_output_tokens=max_tokens,
            ),
        )
        return AIResponse(response.text, "gemini", self.model)


class CustomClient(BaseAIClient):
    def __init__(self, base_url: str, model: str, api_key: str = "none"):
        from openai import OpenAI
        self.model = model
        self.client = OpenAI(base_url=base_url, api_key=api_key)

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model, temperature=temperature, max_tokens=max_tokens,
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": user_prompt}],
        )
        return AIResponse(response.choices[0].message.content, "custom", self.model)


def get_ai_client(provider: str, **kwargs) -> BaseAIClient:
    providers = {
        "openai": OpenAIClient,
        "groq": GroqClient,
        "bedrock": BedrockClient,
        "gemini": GeminiClient,
        "custom": CustomClient,
    }
    if provider not in providers:
        raise ValueError(f"Unknown provider '{provider}'. Choose from: {list(providers.keys())}")
    return providers[provider](**kwargs)
