"""
shared/llm_caller.py

Single retry + validation wrapper for all LLM calls across the pipeline.
"""

import json
import logging
from typing import Type, TypeVar
from pydantic import BaseModel, ValidationError
from shared.ai_client import BaseAIClient

logger = logging.getLogger(__name__)
T = TypeVar("T", bound=BaseModel)
MAX_RETRIES = 2


class LLMCallError(Exception):
    pass


def call_llm(
    client: BaseAIClient,
    system_prompt: str,
    user_prompt: str,
    output_schema: Type[T],
    temperature: float = 0.3,
    max_tokens: int = 2048,
) -> T:
    """
    Call LLM, parse JSON, validate against Pydantic schema.
    Retries with corrective prompt on parse/validation failure.
    """
    last_error = None
    current_user_prompt = user_prompt

    for attempt in range(1, MAX_RETRIES + 2):
        try:
            logger.debug(f"LLM attempt {attempt}/{MAX_RETRIES + 1}")
            response = client.complete(system_prompt, current_user_prompt, temperature, max_tokens)
            raw = response.content

            # Strip markdown fences if present
            cleaned = raw.strip()
            if cleaned.startswith("```"):
                lines = cleaned.splitlines()
                cleaned = "\n".join(lines[1:-1]).strip()

            parsed = json.loads(cleaned)
            return output_schema.model_validate(parsed)

        except (json.JSONDecodeError, ValidationError) as e:
            last_error = str(e)
            logger.warning(f"Attempt {attempt} failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error on attempt {attempt}: {e}")
            raise

        if attempt <= MAX_RETRIES:
            current_user_prompt = f"""Your previous response had errors:

{last_error}

Original request:
{user_prompt}

Fix only the errors. Output ONLY valid JSON. No preamble, no markdown fences."""

    raise LLMCallError(f"LLM call failed after {MAX_RETRIES + 1} attempts. Last error: {last_error}")
