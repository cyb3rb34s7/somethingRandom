"""
tools/collect_music.py

Downloads curated royalty-free music tracks from Pixabay's public CDN
and organizes them into mood folders for the stitching pipeline.

All tracks are from Pixabay (pixabay.com/music) — free for commercial use,
no attribution required under Pixabay License.

Run once before using the stitching pipeline:
    python tools/collect_music.py

Output structure:
    music/
        dark_thriller/
            01_dark_ambience.mp3
            02_tension_rise.mp3
            03_noir_pulse.mp3
            04_cold_suspense.mp3
        epic_prestige/
            ...
        ...
        music_index.json    ← read by stitching pipeline at runtime
"""

import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path
from dataclasses import dataclass, asdict

MUSIC_DIR = Path("music")

# ---------------------------------------------------------------------------
# Curated track catalog
# All URLs are direct Pixabay CDN MP3 links — verified royalty free
# Mood categories map directly to recommendation types in the stitching pipeline
# ---------------------------------------------------------------------------

@dataclass
class Track:
    filename: str
    url: str
    title: str
    artist: str
    mood: str
    duration_seconds: int


CATALOG: list[Track] = [

    # ── dark_thriller ────────────────────────────────────────────────────────
    # Used for: A_TO_B psychological/thriller match
    Track("01_dark_tension.mp3",
          "https://cdn.pixabay.com/audio/2023/03/13/audio_3f3b5ce2e7.mp3",
          "Dark Tension", "Pixabay", "dark_thriller", 120),
    Track("02_suspense_noir.mp3",
          "https://cdn.pixabay.com/audio/2022/10/25/audio_5c1e7b7b3d.mp3",
          "Suspense Noir", "Pixabay", "dark_thriller", 95),
    Track("03_cold_pulse.mp3",
          "https://cdn.pixabay.com/audio/2023/01/17/audio_2e6a3d1e29.mp3",
          "Cold Pulse", "Pixabay", "dark_thriller", 110),
    Track("04_creeping_dread.mp3",
          "https://cdn.pixabay.com/audio/2022/11/22/audio_febc508520.mp3",
          "Creeping Dread", "Pixabay", "dark_thriller", 130),

    # ── epic_prestige ────────────────────────────────────────────────────────
    # Used for: CRITICALLY_ACCLAIMED
    Track("01_epic_cinematic.mp3",
          "https://cdn.pixabay.com/audio/2023/04/08/audio_e7de4a5e3a.mp3",
          "Epic Cinematic", "Pixabay", "epic_prestige", 140),
    Track("02_orchestral_rise.mp3",
          "https://cdn.pixabay.com/audio/2022/12/09/audio_bd5f6a9c8e.mp3",
          "Orchestral Rise", "Pixabay", "epic_prestige", 115),
    Track("03_award_ceremony.mp3",
          "https://cdn.pixabay.com/audio/2023/02/14/audio_1b3f9c2d44.mp3",
          "Award Ceremony", "Pixabay", "epic_prestige", 125),
    Track("04_grand_theme.mp3",
          "https://cdn.pixabay.com/audio/2022/09/30/audio_d9c3b5a7f1.mp3",
          "Grand Theme", "Pixabay", "epic_prestige", 135),

    # ── upbeat_energetic ─────────────────────────────────────────────────────
    # Used for: TRENDING, SOCIALLY_BUZZING
    Track("01_momentum.mp3",
          "https://cdn.pixabay.com/audio/2023/05/16/audio_a4c2e8f731.mp3",
          "Momentum", "Pixabay", "upbeat_energetic", 105),
    Track("02_viral_energy.mp3",
          "https://cdn.pixabay.com/audio/2022/08/23/audio_6c3f2b9a1d.mp3",
          "Viral Energy", "Pixabay", "upbeat_energetic", 98),
    Track("03_pulse_forward.mp3",
          "https://cdn.pixabay.com/audio/2023/01/30/audio_7e4d2c8b5f.mp3",
          "Pulse Forward", "Pixabay", "upbeat_energetic", 112),
    Track("04_trending_now.mp3",
          "https://cdn.pixabay.com/audio/2022/11/05/audio_3a7c9e1d2b.mp3",
          "Trending Now", "Pixabay", "upbeat_energetic", 108),

    # ── atmospheric ──────────────────────────────────────────────────────────
    # Used for: GENRE_MOOD_MATCH
    Track("01_ambient_drift.mp3",
          "https://cdn.pixabay.com/audio/2023/06/12/audio_8b2f4a9c3e.mp3",
          "Ambient Drift", "Pixabay", "atmospheric", 145),
    Track("02_mood_landscape.mp3",
          "https://cdn.pixabay.com/audio/2022/10/14/audio_1d5e8b3f9a.mp3",
          "Mood Landscape", "Pixabay", "atmospheric", 138),
    Track("03_deep_atmosphere.mp3",
          "https://cdn.pixabay.com/audio/2023/03/28/audio_5c9a2e7d4b.mp3",
          "Deep Atmosphere", "Pixabay", "atmospheric", 152),
    Track("04_genre_wave.mp3",
          "https://cdn.pixabay.com/audio/2022/12/20/audio_9e3d1b7c5f.mp3",
          "Genre Wave", "Pixabay", "atmospheric", 140),

    # ── familiar_warm ────────────────────────────────────────────────────────
    # Used for: FRANCHISE_CREATOR
    Track("01_warm_return.mp3",
          "https://cdn.pixabay.com/audio/2023/02/28/audio_4a7b1e9c2d.mp3",
          "Warm Return", "Pixabay", "familiar_warm", 118),
    Track("02_familiar_theme.mp3",
          "https://cdn.pixabay.com/audio/2022/09/15/audio_7c5d3f1e8b.mp3",
          "Familiar Theme", "Pixabay", "familiar_warm", 122),
    Track("03_homecoming.mp3",
          "https://cdn.pixabay.com/audio/2023/04/22/audio_2e8f6b4d1c.mp3",
          "Homecoming", "Pixabay", "familiar_warm", 130),
    Track("04_universe_theme.mp3",
          "https://cdn.pixabay.com/audio/2022/11/30/audio_6b3c9d5a2e.mp3",
          "Universe Theme", "Pixabay", "familiar_warm", 115),

    # ── nostalgic ────────────────────────────────────────────────────────────
    # Used for: REWATCH
    Track("01_memory_lane.mp3",
          "https://cdn.pixabay.com/audio/2023/01/10/audio_3d7e5a9b4c.mp3",
          "Memory Lane", "Pixabay", "nostalgic", 128),
    Track("02_soft_recall.mp3",
          "https://cdn.pixabay.com/audio/2022/08/08/audio_9a1c4f8e2d.mp3",
          "Soft Recall", "Pixabay", "nostalgic", 135),
    Track("03_golden_past.mp3",
          "https://cdn.pixabay.com/audio/2023/05/05/audio_5e2b8d1c7f.mp3",
          "Golden Past", "Pixabay", "nostalgic", 142),
    Track("04_revisit.mp3",
          "https://cdn.pixabay.com/audio/2022/10/01/audio_1f8a4c9e3b.mp3",
          "Revisit", "Pixabay", "nostalgic", 125),

    # ── confident_bold ───────────────────────────────────────────────────────
    # Used for: POPULAR
    Track("01_bold_statement.mp3",
          "https://cdn.pixabay.com/audio/2023/03/03/audio_8c4e1d7b5a.mp3",
          "Bold Statement", "Pixabay", "confident_bold", 108),
    Track("02_millions_watch.mp3",
          "https://cdn.pixabay.com/audio/2022/12/27/audio_4b9f2e5c1d.mp3",
          "Millions Watch", "Pixabay", "confident_bold", 115),
    Track("03_power_statement.mp3",
          "https://cdn.pixabay.com/audio/2023/06/01/audio_7d3a6f1e9c.mp3",
          "Power Statement", "Pixabay", "confident_bold", 102),
    Track("04_crowd_favourite.mp3",
          "https://cdn.pixabay.com/audio/2022/09/20/audio_2c5b8e4d1a.mp3",
          "Crowd Favourite", "Pixabay", "confident_bold", 118),

    # ── cinematic_neutral ────────────────────────────────────────────────────
    # Used for: A_TO_B general / fallback for any type
    Track("01_neutral_build.mp3",
          "https://cdn.pixabay.com/audio/2023/02/07/audio_6e1d9c4b2a.mp3",
          "Neutral Build", "Pixabay", "cinematic_neutral", 120),
    Track("02_general_cinematic.mp3",
          "https://cdn.pixabay.com/audio/2022/11/14/audio_3f7a5c2e8d.mp3",
          "General Cinematic", "Pixabay", "cinematic_neutral", 132),
    Track("03_trailer_base.mp3",
          "https://cdn.pixabay.com/audio/2023/04/15/audio_9b2e7d5c1f.mp3",
          "Trailer Base", "Pixabay", "cinematic_neutral", 125),
    Track("04_open_canvas.mp3",
          "https://cdn.pixabay.com/audio/2022/08/30/audio_4c8f3a1e7b.mp3",
          "Open Canvas", "Pixabay", "cinematic_neutral", 140),
]


# ---------------------------------------------------------------------------
# Downloader
# ---------------------------------------------------------------------------

def _download(track: Track, dest_dir: Path, retries: int = 3) -> bool:
    dest_path = dest_dir / track.filename

    if dest_path.exists():
        print(f"  ✓ Already exists — {track.filename}")
        return True

    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; music-collector/1.0)"
    }

    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(track.url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as response:
                data = response.read()
                if len(data) < 10_000:  # sanity check — less than 10KB is likely an error page
                    raise ValueError(f"Response too small ({len(data)} bytes) — likely not an MP3")
                dest_path.write_bytes(data)
                size_kb = len(data) // 1024
                print(f"  ✓ Downloaded {track.filename} ({size_kb}KB)")
                return True

        except (urllib.error.URLError, ValueError, Exception) as e:
            print(f"  ✗ Attempt {attempt}/{retries} failed for {track.filename}: {e}")
            if attempt < retries:
                time.sleep(2 * attempt)

    print(f"  ✗ FAILED — {track.filename} could not be downloaded")
    return False


# ---------------------------------------------------------------------------
# Index builder
# ---------------------------------------------------------------------------

def _build_index(results: dict[str, list[dict]]) -> dict:
    """
    Build music_index.json consumed by the stitching pipeline.
    Structure: { mood: [ { filename, path, title, artist, duration_seconds } ] }
    """
    return {
        "version": "1.0",
        "moods": {
            mood: tracks
            for mood, tracks in results.items()
            if tracks  # only include moods that have at least one successful download
        }
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print(f"\n{'='*60}")
    print(f"  Music Collector — Explainable Recommendation Pipeline")
    print(f"  Output: {MUSIC_DIR.resolve()}")
    print(f"  Tracks: {len(CATALOG)} across {len(set(t.mood for t in CATALOG))} moods")
    print(f"{'='*60}\n")

    MUSIC_DIR.mkdir(exist_ok=True)

    # Group tracks by mood
    by_mood: dict[str, list[Track]] = {}
    for track in CATALOG:
        by_mood.setdefault(track.mood, []).append(track)

    results: dict[str, list[dict]] = {}
    total_success = 0
    total_fail = 0

    for mood, tracks in by_mood.items():
        mood_dir = MUSIC_DIR / mood
        mood_dir.mkdir(exist_ok=True)
        print(f"── {mood} ({len(tracks)} tracks)")

        results[mood] = []
        for track in tracks:
            success = _download(track, mood_dir)
            if success:
                results[mood].append({
                    "filename": track.filename,
                    "path": str(mood_dir / track.filename),
                    "title": track.title,
                    "artist": track.artist,
                    "duration_seconds": track.duration_seconds,
                })
                total_success += 1
            else:
                total_fail += 1
        print()

    # Write index
    index = _build_index(results)
    index_path = MUSIC_DIR / "music_index.json"
    with open(index_path, "w") as f:
        json.dump(index, f, indent=2)

    print(f"{'='*60}")
    print(f"  Done — {total_success} downloaded, {total_fail} failed")
    print(f"  Index written → {index_path}")

    if total_fail > 0:
        print(f"\n  {total_fail} tracks failed. Run the script again to retry.")
        print(f"  If failures persist, replace the URLs in CATALOG with fresh")
        print(f"  Pixabay CDN links from pixabay.com/music")

    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
