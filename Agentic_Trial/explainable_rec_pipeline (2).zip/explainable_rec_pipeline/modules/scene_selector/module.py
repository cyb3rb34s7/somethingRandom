"""
modules/scene_selector/module.py  — T6A

Selects best scenes from scenes.json (short clips, stitching candidates).
Uses score/rank from theme groupings to guide selection.
Enriches selected scenes with top-scene context descriptions where available.
clipStart/clipEnd are null — set manually after human review.
"""

import logging
from pydantic import BaseModel
from typing import Optional
from shared.schemas import (
    PretagContext, EngineOutput, SceneSelectionOutput, SelectedScene,
    CorrelationOutput, HighlightOutput,
    SpoilerRisk, OutputMode, Scene, ContentPretag,
)
from shared.ai_client import BaseAIClient
from shared.llm_caller import call_llm

logger = logging.getLogger(__name__)
TEMPERATURE = 0.1


class _RawSelectedScene(BaseModel):
    umdId:            str
    sceneNumber:      int
    title:            str
    startTime:        int
    endTime:          int
    durationSeconds:  int
    spoilerRisk:      SpoilerRisk
    spoilerReason:    Optional[str] = None
    narrativePurpose: str

class _RawSceneSelection(BaseModel):
    selectedScenes: list[_RawSelectedScene]


SYSTEM = """You are a film editor selecting short scenes for a recommendation explanation video.

You will receive scenes from scenes.json — these are short (20-50s) and are the actual stitching candidates.
Each scene may have a score and rank indicating its relevance to its theme — prefer higher scored scenes.

Rules:
- Select scenes that establish atmosphere, character, or premise — NOT scenes that resolve the story
- Flag spoilerRisk HIGH if description implies: a twist, death, final confrontation, or revelation
- If spoilerRisk is HIGH on your top pick, choose the next best scene
- For A_TO_B: select exactly one scene from EACH content (two total)
- For other types: select 1-2 scenes from the recommended content only
- Prefer scenes with higher score values when available
- durationSeconds = endTime - startTime
- narrativePurpose: what this clip makes the viewer FEEL, not what happens in it
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "selectedScenes": [
    {
      "umdId": "<umdId>",
      "sceneNumber": <number>,
      "title": "<title>",
      "startTime": <seconds>,
      "endTime": <seconds>,
      "durationSeconds": <number>,
      "spoilerRisk": "LOW|MEDIUM|HIGH",
      "spoilerReason": "<reason or null>",
      "narrativePurpose": "<what viewer feels>"
    }
  ]
}"""


def _fmt_scenes(umd_id: str, scenes: list[Scene]) -> str:
    lines = [f"\nScenes from {umd_id}:"]
    for s in scenes:
        score_info = f" [score={s.score}, rank={s.rank}]" if s.score is not None else ""
        tags_info  = f" tags={s.tags}" if s.tags else ""
        lines.append(
            f"  [{s.number}] {s.title} ({s.startTime}s-{s.endTime}s, {s.duration}s){score_info}{tags_info}\n"
            f"      {s.description}"
        )
    return "\n".join(lines)


def _build_user_prompt(engine_output: EngineOutput, pretag: PretagContext) -> str:
    if engine_output.mode == OutputMode.CORRELATION:
        top = engine_output.correlations[0]
        reason = f"Correlation: {top.reason} (theme match: {top.themeA} ↔ {top.themeB})"
        scenes_block = (
            _fmt_scenes(pretag.sourceContent.umdId, pretag.sourceContent.scenes)
            + _fmt_scenes(pretag.recommendedContent.umdId, pretag.recommendedContent.scenes)
        )
    else:
        reason = f"Highlight angle: {engine_output.primaryAngle}"
        scenes_block = _fmt_scenes(
            pretag.recommendedContent.umdId,
            pretag.recommendedContent.scenes,
        )

    return f"""Select scenes for this explanation video.

Recommendation type: {engine_output.recommendationType.value}
Recommendation reason: {reason}
{scenes_block}"""


def run(
    engine_output: EngineOutput,
    pretag: PretagContext,
    client: BaseAIClient,
) -> SceneSelectionOutput:
    logger.info("Selecting scenes from scenes.json...")

    raw = call_llm(
        client=client,
        system_prompt=SYSTEM,
        user_prompt=_build_user_prompt(engine_output, pretag),
        output_schema=_RawSceneSelection,
        temperature=TEMPERATURE,
    )

    # Build lookup for top-scene context enrichment
    content_map: dict[str, ContentPretag] = {
        pretag.recommendedContent.umdId: pretag.recommendedContent
    }
    if pretag.sourceContent:
        content_map[pretag.sourceContent.umdId] = pretag.sourceContent

    scenes = []
    for s in raw.selectedScenes:
        # Find matching scene to get thumbnail
        content_pretag = content_map.get(s.umdId)
        thumbnail = None
        top_context = None

        if content_pretag:
            matched = next((sc for sc in content_pretag.scenes if sc.number == s.sceneNumber), None)
            if matched:
                thumbnail = matched.thumbnail
                top_context = content_pretag.enrich_scene_with_top_context(matched)

        scenes.append(SelectedScene(
            **s.model_dump(),
            thumbnail=thumbnail,
            topSceneContext=top_context,
            clipStart=None,
            clipEnd=None,
        ))

    result = SceneSelectionOutput(selectedScenes=scenes)

    logger.info(f"Selected {len(scenes)} scene(s):")
    for s in scenes:
        ctx_note = " [+top-scene context]" if s.topSceneContext else ""
        logger.info(
            f"  [{s.umdId}] {s.title} ({s.startTime}s-{s.endTime}s) "
            f"spoiler={s.spoilerRisk.value}{ctx_note}"
        )

    if not result.is_timestamps_complete():
        logger.info(
            "clipStart/clipEnd are null — edit the state file to set timestamps before running phase 2."
        )

    return result
