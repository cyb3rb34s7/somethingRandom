"""
modules/input_aggregator/module.py  — T1

Reads UMD metadata JSON and recommendation event, 
normalizes into UnifiedContext.

Raw event shape:
{
    "recommendationType": "A_TO_B",
    "recommendedUmdId": "228704",
    "sourceUmdId": "228705",          <- only for A_TO_B
    "availableSignals": ["BECAUSE_YOU_WATCHED"],
    "umdDataFile": "umd_data/umd_metadata.json"   <- optional override
}
"""

import json
import logging
from pathlib import Path
from shared.schemas import (
    UnifiedContext, ContentMetadata, UMDProgram, UMDProgram,
    RecommendationType,
)
from shared import config

logger = logging.getLogger(__name__)


class InputAggregatorError(Exception):
    pass


def _load_umd_registry(umd_data_file: str) -> dict[str, UMDProgram]:
    """Load UMD metadata file and return a dict keyed by string program_id."""
    path = Path(umd_data_file)
    if not path.exists():
        raise InputAggregatorError(f"UMD data file not found: {path.resolve()}")

    with open(path) as f:
        raw = json.load(f)

    programs_raw = raw.get("programs_data", {})
    registry: dict[str, UMDProgram] = {}

    for pid, data in programs_raw.items():
        try:
            program = UMDProgram.model_validate(data)
            registry[str(pid)] = program
        except Exception as e:
            logger.warning(f"Skipping malformed UMD entry {pid}: {e}")

    return registry


def _get_content_metadata(umd_id: str, registry: dict[str, UMDProgram]) -> ContentMetadata:
    program = registry.get(str(umd_id))
    if not program:
        raise InputAggregatorError(
            f"umdId '{umd_id}' not found in UMD registry. "
            f"Available IDs: {list(registry.keys())[:10]}"
        )
    return ContentMetadata.from_umd(program)


def run(raw_event: dict) -> UnifiedContext:
    """
    Normalize raw recommendation event + UMD metadata into UnifiedContext.

    Args:
        raw_event: dict with recommendationType, recommendedUmdId, 
                   optional sourceUmdId, optional umdDataFile path

    Returns:
        UnifiedContext — validated, ready for downstream modules
    """
    try:
        rec_type = RecommendationType(raw_event["recommendationType"])
    except (KeyError, ValueError) as e:
        raise InputAggregatorError(f"Invalid recommendationType: {e}")

    umd_data_file = raw_event.get(
        "umdDataFile",
        str(config.UMD_DATA_DIR / config.UMD_DATA_FILE)
    )

    registry = _load_umd_registry(umd_data_file)

    recommended_id = str(raw_event.get("recommendedUmdId", ""))
    source_id      = str(raw_event.get("sourceUmdId", "")) if raw_event.get("sourceUmdId") else None

    if not recommended_id:
        raise InputAggregatorError("recommendedUmdId is required in the event")

    recommended = _get_content_metadata(recommended_id, registry)
    source      = _get_content_metadata(source_id, registry) if source_id else None

    context = UnifiedContext(
        recommendationType=rec_type,
        recommendedContent=recommended,
        sourceContent=source,
        availableSignals=raw_event.get("availableSignals", []),
    )

    logger.info(
        f"Input aggregated — type: {rec_type.value} | "
        f"recommended: {recommended.title} ({recommended.umdId})"
        + (f" | source: {source.title} ({source.umdId})" if source else "")
    )

    return context
