"""
modules/correlation_engine/module.py  — T5

Routes to correlation (A_TO_B) or highlight extraction (all other types).
Uses UMD long descriptions for richer LLM context.
"""

import logging
from pydantic import BaseModel
from typing import Optional
from shared.schemas import (
    PretagContext, UnifiedContext, ClassificationResult,
    CorrelationOutput, CorrelationEntry, EngineOutput,
    HighlightOutput, HighlightSignals,
    RecommendationType, Confidence, NarrativeAngle, ToneDirection, OutputMode,
)
from shared.ai_client import BaseAIClient
from shared.llm_caller import call_llm

logger = logging.getLogger(__name__)

TONE_GUIDE = {
    RecommendationType.TRENDING:            ("URGENT",       "Urgent, FOMO — the moment everyone is watching"),
    RecommendationType.POPULAR:             ("SOCIAL_PROOF", "Confident — millions of viewers can't be wrong"),
    RecommendationType.CRITICALLY_ACCLAIMED:("PRESTIGE",     "Prestige, cinematic — recognized as genuinely great art"),
    RecommendationType.SOCIALLY_BUZZING:    ("ENERGETIC",    "Energetic — fans and communities can't stop discussing this"),
    RecommendationType.GENRE_MOOD_MATCH:    ("ATMOSPHERIC",  "Atmospheric, mood-first — matches your current mood"),
    RecommendationType.FRANCHISE_CREATOR:   ("FAMILIAR",     "Warm and familiar — more of what you already love"),
    RecommendationType.REWATCH:             ("NOSTALGIC",    "Nostalgic, warm — some stories are worth revisiting"),
}

def _fmt_themes(themes) -> str:
    return "\n".join(f"  {t.rank}. {t.name}" for t in themes)

def _fmt_list(items) -> str:
    return ", ".join(items) if items else "N/A"


# ---------------------------------------------------------------------------
# Correlation (A_TO_B)
# ---------------------------------------------------------------------------

class _RawCorrelation(BaseModel):
    correlations: list[CorrelationEntry]

CORRELATION_SYSTEM = """You are a film analyst for a video streaming platform.

Find the most compelling correlations between two contents — explaining why a viewer \
who enjoyed content A would also enjoy content B.

Rules:
- Find up to 3 correlation reasons, ranked by strength
- Use BOTH theme overlap AND metadata signals (genre, tone, awards, descriptions)
- narrativeAngle = DOMINANT_MATCH when correlation is on rank-1 themes of both contents
- narrativeAngle = HIDDEN_CONNECTION when on secondary themes (rank 2+)
- Do NOT reference plot points that could be spoilers
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "correlations": [
    {
      "rank": 1,
      "themeA": "<theme from content A>",
      "themeB": "<theme from content B>",
      "reason": "<one sentence — emotional connection viewer would feel>",
      "metadataSignals": "<genre, awards or tonal notes>",
      "confidence": "HIGH|MEDIUM|LOW",
      "narrativeAngle": "DOMINANT_MATCH|HIDDEN_CONNECTION"
    }
  ]
}"""


def _run_correlation(client, pretag, context) -> CorrelationOutput:
    src_pretag = pretag.sourceContent
    rec_pretag = pretag.recommendedContent
    src_meta   = context.sourceContent
    rec_meta   = context.recommendedContent

    user_prompt = f"""Find correlations between these two contents.

Content A — {src_meta.title} (UMD: {src_meta.umdId})
Description: {src_meta.longDescription}
Genre: {_fmt_list(src_meta.genres)}
Awards: {_fmt_list(src_meta.awards)}
Themes (ranked):
{_fmt_themes(src_pretag.themes)}

Content B — {rec_meta.title} (UMD: {rec_meta.umdId})
Description: {rec_meta.longDescription}
Genre: {_fmt_list(rec_meta.genres)}
Awards: {_fmt_list(rec_meta.awards)}
Themes (ranked):
{_fmt_themes(rec_pretag.themes)}"""

    raw = call_llm(client, CORRELATION_SYSTEM, user_prompt, _RawCorrelation, temperature=0.3)

    return CorrelationOutput(
        recommendationType=RecommendationType.A_TO_B,
        sourceContentId=src_pretag.umdId,
        recommendedContentId=rec_pretag.umdId,
        correlations=raw.correlations,
    )


# ---------------------------------------------------------------------------
# Highlight extraction (non A_TO_B)
# ---------------------------------------------------------------------------

class _RawHighlight(BaseModel):
    primaryAngle:     str
    dominantTheme:    str
    toneDirection:    ToneDirection
    highlightSignals: HighlightSignals

HIGHLIGHT_SYSTEM = """You are a film marketing analyst for a video streaming platform.

Identify the most compelling narrative angle for a recommendation explanation video.

Rules:
- primaryAngle: single sentence — the core message
- dominantTheme: rank-1 theme name from pretag data
- toneDirection: must match the recommendation type given
- Only include highlightSignals fields that have real values — do not invent data
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "primaryAngle": "<one compelling sentence>",
  "dominantTheme": "<rank-1 theme name>",
  "toneDirection": "<tone value>",
  "highlightSignals": {
    "awards": "<key award or null>",
    "popularityNote": "<short note or null>"
  }
}"""


def _run_highlight(client, pretag, context, rec_type) -> HighlightOutput:
    rec_pretag = pretag.recommendedContent
    rec_meta   = context.recommendedContent
    tone_val, tone_desc = TONE_GUIDE.get(rec_type, ("PRESTIGE", "Prestige and quality"))

    user_prompt = f"""Extract the highlight angle for this recommendation.

Recommendation type: {rec_type.value}
Tone direction to use: {tone_val} — {tone_desc}

Content: {rec_meta.title} (UMD: {rec_meta.umdId})
Description: {rec_meta.longDescription}
Genre: {_fmt_list(rec_meta.genres)}
Awards: {_fmt_list(rec_meta.awards)}
Themes (ranked):
{_fmt_themes(rec_pretag.themes)}"""

    raw = call_llm(client, HIGHLIGHT_SYSTEM, user_prompt, _RawHighlight, temperature=0.4)

    return HighlightOutput(
        recommendationType=rec_type,
        recommendedContentId=rec_pretag.umdId,
        **raw.model_dump(),
    )


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(pretag, context, classification, client) -> EngineOutput:
    rec_type = classification.primaryType
    logger.info(f"Correlation engine — mode: {rec_type.value}")

    if rec_type == RecommendationType.A_TO_B:
        return _run_correlation(client, pretag, context)
    else:
        return _run_highlight(client, pretag, context, rec_type)
