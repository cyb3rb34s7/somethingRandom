"""
modules/manifest_builder/module.py  — T7 + T8

Two steps in one module:
  T7 — Narrative Generator: tag, one-liner, overlays, video arc (LLM call)
  T8 — Manifest Assembler: combines everything into final manifest.json

Input requires clipStart/clipEnd to be set on all scenes (post human review).
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
from shared.schemas import (
    SceneSelectionOutput, EngineOutput, ClassificationResult,
    Manifest, ManifestClip, TransitionOverlay, EndCard, Overlay,
    CorrelationOutput, HighlightOutput,
    OverlayPosition, OverlayStyle, OutputMode,
)
from shared.ai_client import BaseAIClient
from shared.llm_caller import call_llm

logger = logging.getLogger(__name__)
TEMPERATURE = 0.7  # creative — varied output desired
MANIFEST_OUTPUT_DIR = Path("output_manifests")

TONE_GUIDE = {
    "A_TO_B":               "Intimate and comparative — draw a direct emotional line between the two contents",
    "TRENDING":             "Urgent — create FOMO, make viewer feel they are missing a cultural moment",
    "POPULAR":              "Confident — social proof, bold statements about quality",
    "CRITICALLY_ACCLAIMED": "Cinematic and prestige — reverent, authoritative",
    "SOCIALLY_BUZZING":     "Energetic — community, conversation, excitement",
    "GENRE_MOOD_MATCH":     "Atmospheric — sensory, mood-driven language",
    "FRANCHISE_CREATOR":    "Warm and familiar — fan-service, continuity",
    "REWATCH":              "Nostalgic — emotional recall, warmth",
}


# ---------------------------------------------------------------------------
# T7 — Raw narrative schema
# ---------------------------------------------------------------------------

class _RawOverlay(BaseModel):
    text:           str
    position:       OverlayPosition
    appearAtSecond: float
    holdSeconds:    float
    style:          OverlayStyle


class _RawClipNarrative(BaseModel):
    clipIndex:       int
    umdId:       str
    emotionalIntent: str
    overlays:        list[_RawOverlay]


class _RawTransitionOverlay(BaseModel):
    text:     str
    position: OverlayPosition
    style:    OverlayStyle


class _RawEndCard(BaseModel):
    text:            str
    durationSeconds: int


class _RawNarrative(BaseModel):
    tag:                str
    oneLiner:           str
    videoArc:           str
    clipNarratives:     list[_RawClipNarrative]
    transitionOverlay:  _RawTransitionOverlay
    endCard:            _RawEndCard


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

NARRATIVE_SYSTEM = """You are a creative director writing the script for a short recommendation explanation video.

Generate a tag, one-liner, and text overlay plan.

Overlay style guide:
- CINEMATIC_BOLD: Large, high-impact text. Use for opening hooks and transitions.
- SUBTLE: Smaller, lower-third text. Use for supporting context mid-clip.
- BRAND: Clean, minimal. End cards only.

Overlay positions: TOP_CENTER, BOTTOM_CENTER, CENTER

Rules:
- tag: 2-5 words maximum
- oneLiner: single punchy sentence, max 15 words
- Each clip: 1-2 overlays maximum
- appearAtSecond >= 1 (never at exact clip start)
- appearAtSecond + holdSeconds <= clip duration
- transitionOverlay: 1-3 bold words shown during crossfade between clips
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "tag": "<2-5 words>",
  "oneLiner": "<single sentence>",
  "videoArc": "<one sentence — emotional journey of the full video>",
  "clipNarratives": [
    {
      "clipIndex": <number>,
      "umdId": "<umdId>",
      "emotionalIntent": "<what viewer feels>",
      "overlays": [
        {
          "text": "<overlay text>",
          "position": "TOP_CENTER|BOTTOM_CENTER|CENTER",
          "appearAtSecond": <number>,
          "holdSeconds": <number>,
          "style": "CINEMATIC_BOLD|SUBTLE|BRAND"
        }
      ]
    }
  ],
  "transitionOverlay": {
    "text": "<1-3 words>",
    "position": "CENTER",
    "style": "CINEMATIC_BOLD"
  },
  "endCard": {
    "text": "<Content Title — Watch Now>",
    "durationSeconds": 2
  }
}"""


def _build_narrative_prompt(
    scenes: SceneSelectionOutput,
    engine_output: EngineOutput,
    classification: ClassificationResult,
) -> str:
    rec_type = classification.primaryType.value
    tone = TONE_GUIDE.get(rec_type, "Prestige and quality")

    if engine_output.mode == OutputMode.CORRELATION:
        context_block = (
            f"Correlation reason: {engine_output.correlations[0].reason}\n"
            f"Narrative angle: {engine_output.correlations[0].narrativeAngle.value}"
        )
    else:
        context_block = (
            f"Highlight angle: {engine_output.primaryAngle}\n"
            f"Tone direction: {engine_output.toneDirection.value}"
        )

    clips_block = "\n".join(
        f"Clip {i+1} — {s.umdId}\n"
        f"  Duration: {(s.clipEnd - s.clipStart)}s "
        f"({s.clipStart}s–{s.clipEnd}s)\n"
        f"  Narrative purpose: {s.narrativePurpose}"
        for i, s in enumerate(scenes.selectedScenes)
    )

    return f"""Write the explanation video script for this recommendation.

Recommendation type: {rec_type}
Tone: {tone}

{context_block}

Clips:
{clips_block}"""


# ---------------------------------------------------------------------------
# T7 — Narrative generation
# ---------------------------------------------------------------------------

def _generate_narrative(
    scenes: SceneSelectionOutput,
    engine_output: EngineOutput,
    classification: ClassificationResult,
    client: BaseAIClient,
) -> _RawNarrative:
    logger.info("Generating narrative script...")
    return call_llm(
        client=client,
        system_prompt=NARRATIVE_SYSTEM,
        user_prompt=_build_narrative_prompt(scenes, engine_output, classification),
        output_schema=_RawNarrative,
        temperature=TEMPERATURE,
    )


# ---------------------------------------------------------------------------
# T8 — Manifest assembly
# ---------------------------------------------------------------------------

TRANSITIONS = ["FADE_FROM_BLACK", "CROSSFADE", "FADE_TO_BLACK"]


def _assemble_manifest(
    narrative: _RawNarrative,
    scenes: SceneSelectionOutput,
    engine_output: EngineOutput,
    classification: ClassificationResult,
) -> Manifest:
    logger.info("Assembling manifest...")

    scene_map = {s.umdId: s for s in scenes.selectedScenes}

    clips = []
    for i, cn in enumerate(narrative.clipNarratives):
        scene = scene_map[cn.umdId]
        clip_duration = scene.clipEnd - scene.clipStart

        # Validate overlay timings
        validated_overlays = []
        for ov in cn.overlays:
            if ov.appearAtSecond + ov.holdSeconds > clip_duration:
                logger.warning(
                    f"Overlay timing exceeds clip duration for {cn.umdId} — clamping holdSeconds"
                )
                ov = _RawOverlay(
                    text=ov.text,
                    position=ov.position,
                    appearAtSecond=ov.appearAtSecond,
                    holdSeconds=max(1.0, clip_duration - ov.appearAtSecond),
                    style=ov.style,
                )
            validated_overlays.append(Overlay(**ov.model_dump()))

        is_first = i == 0
        is_last = i == len(narrative.clipNarratives) - 1

        clips.append(ManifestClip(
            clipIndex=i + 1,
            umdId=cn.umdId,
            clipStart=scene.clipStart,
            clipEnd=scene.clipEnd,
            transitionIn="FADE_FROM_BLACK" if is_first else "CROSSFADE",
            transitionOut="FADE_TO_BLACK" if is_last else "CROSSFADE",
            transitionDurationMs=1200,
            overlays=validated_overlays,
        ))

    transition_overlays = [
        TransitionOverlay(
            afterClipIndex=i + 1,
            text=narrative.transitionOverlay.text,
            position=narrative.transitionOverlay.position,
            style=narrative.transitionOverlay.style,
            durationMs=1200,
        )
        for i in range(len(clips) - 1)
    ]

    total_duration = sum(
        s.clipEnd - s.clipStart for s in scenes.selectedScenes
    )

    correlation_reason = (
        engine_output.correlations[0].reason
        if engine_output.mode == OutputMode.CORRELATION
        else engine_output.primaryAngle
    )

    return Manifest(
        recommendationType=classification.primaryType,
        tag=narrative.tag,
        oneLiner=narrative.oneLiner,
        clips=clips,
        transitionOverlays=transition_overlays,
        endCard=EndCard(
            text=narrative.endCard.text,
            durationSeconds=narrative.endCard.durationSeconds,
        ),
        metadata={
            "videoArc": narrative.videoArc,
            "correlationReason": correlation_reason,
            "estimatedDurationSeconds": total_duration,
            "spoilerRiskFlags": [s.spoilerRisk.value for s in scenes.selectedScenes],
            "generatedAt": datetime.now().isoformat(),
        },
    )


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(
    scenes: SceneSelectionOutput,
    engine_output: EngineOutput,
    classification: ClassificationResult,
    client: BaseAIClient,
    output_dir: Path = MANIFEST_OUTPUT_DIR,
) -> Manifest:
    if not scenes.is_timestamps_complete():
        raise ValueError(
            "All scenes must have clipStart and clipEnd set before manifest generation. "
            "Edit the scene_selection.json file to add timestamps, then resume."
        )

    narrative = _generate_narrative(scenes, engine_output, classification, client)
    manifest = _assemble_manifest(narrative, scenes, engine_output, classification)

    # Save to disk
    output_dir.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    out_path = output_dir / f"manifest_{run_id}.json"
    with open(out_path, "w") as f:
        json.dump(manifest.model_dump(), f, indent=2, default=str)

    logger.info(f"Manifest saved → {out_path}")
    return manifest
