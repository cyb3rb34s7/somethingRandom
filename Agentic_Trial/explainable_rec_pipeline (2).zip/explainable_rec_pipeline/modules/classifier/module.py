"""
modules/classifier/module.py  — T2

LLM call that classifies the recommendation type from unified context.
"""

import logging
from pydantic import BaseModel
from typing import Optional
from shared.schemas import (
    UnifiedContext, ClassificationResult,
    RecommendationType, Confidence,
)
from shared.ai_client import BaseAIClient
from shared.llm_caller import call_llm

logger = logging.getLogger(__name__)
TEMPERATURE = 0.1


class _RawClassification(BaseModel):
    primaryType:       RecommendationType
    confidence:        Confidence
    evidence:          str
    secondaryType:     Optional[RecommendationType] = None
    secondaryEvidence: Optional[str]                = None
    sourceContentId:   Optional[str]                = None


SYSTEM = """You are a recommendation classification engine for a video streaming platform.

Classify the recommendation event into exactly ONE primary type:
- A_TO_B: User watched content A, recommended B based on watch history/similarity
- TRENDING: Content is currently spiking in views or engagement
- POPULAR: High all-time viewership or vote count
- CRITICALLY_ACCLAIMED: High critic scores, awards wins or nominations
- SOCIALLY_BUZZING: High community discussion or social mentions
- GENRE_MOOD_MATCH: Based on user's genre or mood watching patterns
- FRANCHISE_CREATOR: Same director, actor, franchise or shared creative universe
- REWATCH: User previously watched this, high affinity

Rules:
- Pick the SINGLE most compelling type with strongest evidence
- A_TO_B takes priority when because_you_watched signal is present AND clear content similarity exists
- sourceContentId must be set for A_TO_B and FRANCHISE_CREATOR, null otherwise
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "primaryType": "<TYPE>",
  "confidence": "HIGH|MEDIUM|LOW",
  "evidence": "<one sentence>",
  "secondaryType": "<TYPE or null>",
  "secondaryEvidence": "<one sentence or null>",
  "sourceContentId": "<umdId or null>"
}"""


def _build_user_prompt(ctx: UnifiedContext) -> str:
    src = ctx.sourceContent
    rec = ctx.recommendedContent

    shared_genre = list(set(rec.genres) & set(src.genres)) if src else []

    source_block = ""
    if src:
        source_block = f"""
Source content (watched by user):
- UMD ID: {src.umdId}
- Title: {src.title}
- Genre: {", ".join(src.genres)}
- Description: {src.shortDescription}
- Awards: {", ".join(src.awards) or "none"}
- Shared genres with recommended: {", ".join(shared_genre) or "none"}
"""

    return f"""Classify this recommendation event.

Available signals: {", ".join(ctx.availableSignals) or "none"}

Recommended content:
- UMD ID: {rec.umdId}
- Title: {rec.title}
- Genre: {", ".join(rec.genres)}
- Description: {rec.shortDescription}
- Awards: {", ".join(rec.awards) or "none"}
{source_block}"""


def run(context: UnifiedContext, client: BaseAIClient) -> ClassificationResult:
    logger.info(f"Classifying recommendation for: {context.recommendedContent.title} ({context.recommendedContent.umdId})")

    raw = call_llm(
        client=client,
        system_prompt=SYSTEM,
        user_prompt=_build_user_prompt(context),
        output_schema=_RawClassification,
        temperature=TEMPERATURE,
    )

    result = ClassificationResult(
        **raw.model_dump(),
        recommendedContentId=context.recommendedContent.umdId,
    )

    logger.info(
        f"Classified as {result.primaryType.value} "
        f"[{result.confidence.value}] — {result.evidence}"
    )
    return result
