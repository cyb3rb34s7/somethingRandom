"""
modules/pretag_loader/module.py  — T3

Loads scenes.json, theme.json, top-scenes.json for a given umdId.
Handles PascalCase normalization via Scene.from_raw().
File names are configurable via environment variables (see shared/config.py).

Directory structure expected:
  pretag_data/{umdId}/scenes.json
  pretag_data/{umdId}/theme.json
  pretag_data/{umdId}/top-scenes.json  (name configurable)
"""

import json
import logging
from pathlib import Path
from shared.schemas import (
    ClassificationResult, PretagContext, ContentPretag,
    Theme, Scene, RecommendationType,
)
from shared import config

logger = logging.getLogger(__name__)


class PretagLoaderError(Exception):
    pass


# ---------------------------------------------------------------------------
# Internal file loaders
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> dict:
    if not path.exists():
        raise PretagLoaderError(f"Pretag file not found: {path}")
    with open(path) as f:
        return json.load(f)


def _load_scenes(content_dir: Path) -> list[Scene]:
    """Load scenes.json — primary short scenes, stitching candidates."""
    data = _load_json(content_dir / config.PRETAG_SCENES_FILE)
    raw_scenes = data.get("content", [])
    return [Scene.from_raw(s) for s in raw_scenes]


def _load_top_scenes(content_dir: Path) -> list[Scene]:
    """Load top-scenes.json — longer curated scenes, used for context only."""
    path = content_dir / config.PRETAG_TOP_SCENES_FILE
    if not path.exists():
        logger.warning(f"Top-scenes file not found at {path} — skipping context enrichment")
        return []
    data = _load_json(path)
    raw_scenes = data.get("content", [])
    return [Scene.from_raw(s) for s in raw_scenes]


def _load_themes(content_dir: Path) -> tuple[list[Theme], dict[str, list[Scene]]]:
    """
    Load theme.json.
    Returns:
        - theme_list: ranked list of Theme objects
        - theme_scenes: dict mapping theme name -> list of scenes under that theme
    """
    data = _load_json(content_dir / config.PRETAG_THEME_FILE)

    # Theme data lives under content key
    content_block = data.get("content", data)

    raw_theme_list = content_block.get("ThemeList", content_block.get("themeList", []))
    theme_list = sorted(
        [Theme(name=t.get("name", t.get("Name", "")), rank=t.get("rank", t.get("Rank", 0)))
         for t in raw_theme_list],
        key=lambda t: t.rank,
    )

    # Build theme -> scenes map
    # Theme scene lists are keyed by exact theme name under content block
    theme_scenes: dict[str, list[Scene]] = {}
    for theme in theme_list:
        raw = content_block.get(theme.name, [])
        theme_scenes[theme.name] = [Scene.from_raw(s) for s in raw]

    return theme_list, theme_scenes


def _load_content(umd_id: str) -> ContentPretag:
    content_dir = config.PRETAG_BASE_DIR / umd_id
    if not content_dir.exists():
        raise PretagLoaderError(
            f"No pretag directory found for umdId: {umd_id} "
            f"(looked in: {content_dir.resolve()})"
        )

    scenes    = _load_scenes(content_dir)
    top_scenes = _load_top_scenes(content_dir)
    themes, theme_scenes = _load_themes(content_dir)

    # Enrich scenes.json scenes with score/rank from theme groupings
    # Build a lookup: scene number -> (score, rank) from theme data
    scene_enrichment: dict[int, tuple[float, int]] = {}
    for theme_scene_list in theme_scenes.values():
        for ts in theme_scene_list:
            if ts.number not in scene_enrichment:
                scene_enrichment[ts.number] = (ts.score or 0.0, ts.rank or 99)

    enriched_scenes = []
    for scene in scenes:
        if scene.number in scene_enrichment:
            score, rank = scene_enrichment[scene.number]
            enriched_scenes.append(scene.model_copy(update={"score": score, "rank": rank}))
        else:
            enriched_scenes.append(scene)

    logger.info(
        f"Loaded pretag for umdId '{umd_id}' — "
        f"{len(themes)} themes | {len(enriched_scenes)} scenes | {len(top_scenes)} top-scenes"
    )

    return ContentPretag(
        umdId=umd_id,
        themes=themes,
        scenes=enriched_scenes,
        topScenes=top_scenes,
    )


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(classification: ClassificationResult) -> PretagContext:
    recommended = _load_content(classification.recommendedContentId)

    source = None
    if classification.primaryType == RecommendationType.A_TO_B and classification.sourceContentId:
        source = _load_content(classification.sourceContentId)

    return PretagContext(recommendedContent=recommended, sourceContent=source)
