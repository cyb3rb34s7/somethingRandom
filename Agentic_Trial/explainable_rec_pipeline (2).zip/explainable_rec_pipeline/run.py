"""
run.py  — CLI entry point

Usage:
  # Phase 1 — run to scene selection, then pause for human timestamp review
  python run.py phase1 --input samples/sample_a_to_b.json --provider gemini --model gemini-2.5-flash-preview-04-17

  # Phase 2 — resume after editing timestamps in state file
  python run.py phase2 --state pipeline_state/state_2025-03-20_10-30-00.json --provider gemini --model gemini-2.5-flash-preview-04-17
"""

import argparse
import json
import sys
from pathlib import Path

from pipeline import run_phase1, run_phase2
from shared.ai_client import get_ai_client


def main():
    parser = argparse.ArgumentParser(description="Explainable Recommendation Pipeline")
    sub = parser.add_subparsers(dest="phase", required=True)

    # Phase 1
    p1 = sub.add_parser("phase1", help="Run T1→T6A, output scene selection for review")
    p1.add_argument("--input",    required=True, help="Path to recommendation event JSON")
    p1.add_argument("--provider", required=True, choices=["openai", "groq", "bedrock", "gemini", "custom"])
    p1.add_argument("--model",    required=True)
    p1.add_argument("--base_url", default=None, help="For custom provider only")

    # Phase 2
    p2 = sub.add_parser("phase2", help="Resume from state file after timestamp injection")
    p2.add_argument("--state",    required=True, help="Path to pipeline state JSON from phase 1")
    p2.add_argument("--provider", required=True, choices=["openai", "groq", "bedrock", "gemini", "custom"])
    p2.add_argument("--model",    required=True)
    p2.add_argument("--base_url", default=None, help="For custom provider only")

    args = parser.parse_args()

    # Build AI client
    kwargs = {"model": args.model}
    if args.provider == "custom":
        if not args.base_url:
            print("ERROR: --base_url required for custom provider")
            sys.exit(1)
        kwargs["base_url"] = args.base_url

    client = get_ai_client(args.provider, **kwargs)

    if args.phase == "phase1":
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"ERROR: Input file not found: {input_path}")
            sys.exit(1)

        with open(input_path) as f:
            raw_event = json.load(f)

        status, state_path = run_phase1(raw_event, client)

        print(f"\n{'='*60}")
        print(f"  Phase 1 complete — status: {status.value}")
        print(f"  State file: {state_path}")
        print(f"\n  NEXT STEPS:")
        print(f"  1. Open {state_path}")
        print(f"  2. Find 'scene_selection.selectedScenes'")
        print(f"  3. Set 'clipStart' and 'clipEnd' (seconds) for each scene")
        print(f"  4. Run: python run.py phase2 --state {state_path} --provider {args.provider} --model {args.model}")
        print(f"{'='*60}\n")

    elif args.phase == "phase2":
        state_path = Path(args.state)
        if not state_path.exists():
            print(f"ERROR: State file not found: {state_path}")
            sys.exit(1)

        status, manifest = run_phase2(state_path, client)

        print(f"\n{'='*60}")
        print(f"  Phase 2 complete — status: {status.value}")
        print(f"  Tag: {manifest['tag']}")
        print(f"  One-liner: {manifest['oneLiner']}")
        print(f"  Clips: {len(manifest['clips'])}")
        print(f"  Est. duration: {manifest['metadata']['estimatedDurationSeconds']}s")
        print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
