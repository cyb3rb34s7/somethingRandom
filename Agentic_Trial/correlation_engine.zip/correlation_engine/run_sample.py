"""
run_sample.py

Plug in your provider + API key and run against the sample JSONs.

Usage:
    python run_sample.py --sample a_to_b --provider openai --model gpt-4o
    python run_sample.py --sample critically_acclaimed --provider groq --model llama-3.3-70b-versatile
    python run_sample.py --sample a_to_b --provider bedrock --model anthropic.claude-3-5-sonnet-20241022-v2:0
    python run_sample.py --sample a_to_b --provider custom --base_url http://localhost:8000 --model my-model

Set your API key as an env variable before running:
    export OPENAI_API_KEY=sk-...
    export GROQ_API_KEY=gsk_...
    (Bedrock uses your AWS credentials automatically via boto3)
"""

import json
import argparse
import logging
from engine import run_from_dict

logging.basicConfig(level=logging.INFO, format="%(levelname)s — %(message)s")

SAMPLES = {
    "a_to_b": "sample_a_to_b.json",
    "critically_acclaimed": "sample_critically_acclaimed.json",
}


def main():
    parser = argparse.ArgumentParser(description="Run the correlation/highlight engine on a sample input.")
    parser.add_argument("--sample", choices=list(SAMPLES.keys()), required=True, help="Which sample to run")
    parser.add_argument("--provider", choices=["openai", "groq", "bedrock", "custom", "gemini"], required=True)
    parser.add_argument("--model", required=True, help="Model name for the provider")
    parser.add_argument("--base_url", default=None, help="Base URL for custom provider")
    args = parser.parse_args()

    # Load sample input
    sample_file = SAMPLES[args.sample]
    with open(sample_file) as f:
        input_dict = json.load(f)

    print(f"\n{'='*60}")
    print(f"  Sample : {args.sample}")
    print(f"  Provider: {args.provider} / {args.model}")
    print(f"{'='*60}\n")

    # Build provider kwargs
    provider_kwargs = {"model": args.model}
    if args.provider == "custom":
        if not args.base_url:
            raise ValueError("--base_url is required for custom provider")
        provider_kwargs["base_url"] = args.base_url

    # Run engine
    result = run_from_dict(
        input_dict=input_dict,
        provider=args.provider,
        **provider_kwargs,
    )

    # Pretty print output
    print("OUTPUT:")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
