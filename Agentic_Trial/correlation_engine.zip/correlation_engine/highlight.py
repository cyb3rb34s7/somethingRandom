"""
highlight.py

Handles all non A_TO_B recommendation types.
Extracts the primary narrative angle for a single content
based on its recommendation type signal and available metadata.
"""

import logging
from ai_client import BaseAIClient
from llm_caller import call_with_retry
from prompts import HighlightPrompt
from schemas import (
    ContentInput,
    ExternalSignals,
    HighlightOutput,
    HighlightSignals,
    RecommendationType,
    ToneDirection,
)

logger = logging.getLogger(__name__)

# Temperature — slightly higher than correlation, allows more expressive angle writing
TEMPERATURE = 0.4


def _build_llm_output_schema():
    """
    Intermediate schema for raw LLM output.
    LLM produces the inner fields — we wrap with mode/type/contentId after.
    """
    from pydantic import BaseModel
    from typing import Optional

    class RawHighlightOutput(BaseModel):
        primaryAngle: str
        dominantTheme: str
        toneDirection: ToneDirection
        highlightSignals: HighlightSignals

    return RawHighlightOutput


def run_highlight(
    client: BaseAIClient,
    recommended: ContentInput,
    recommendation_type: RecommendationType,
    external_signals: ExternalSignals | None = None,
) -> HighlightOutput:
    """
    Extract the primary highlight angle for a non A_TO_B recommendation.

    Args:
        client:              Agnostic AI client
        recommended:         The content being recommended
        recommendation_type: One of TRENDING, POPULAR, CRITICALLY_ACCLAIMED, etc.
        external_signals:    Optional TMDb/IMDb/RT signals

    Returns:
        HighlightOutput with narrative angle and tone direction
    """
    logger.info(
        f"Running highlight extraction: {recommended.contentId} "
        f"[{recommendation_type.value}]"
    )

    prompt = HighlightPrompt(
        recommended=recommended,
        recommendation_type=recommendation_type,
        external_signals=external_signals,
    )
    RawSchema = _build_llm_output_schema()

    raw_output = call_with_retry(
        client=client,
        system_prompt=prompt.SYSTEM,
        user_prompt=prompt.render_user(),
        output_schema=RawSchema,
        temperature=TEMPERATURE,
    )

    result = HighlightOutput(
        recommendationType=recommendation_type,
        recommendedContentId=recommended.contentId,
        primaryAngle=raw_output.primaryAngle,
        dominantTheme=raw_output.dominantTheme,
        toneDirection=raw_output.toneDirection,
        highlightSignals=raw_output.highlightSignals,
    )

    logger.info(
        f"Highlight complete — angle: '{result.primaryAngle}' "
        f"tone: {result.toneDirection.value}"
    )

    return result
