"""
llm_caller.py

Handles the raw LLM call + JSON parsing + retry logic.
Every LLM call in this engine goes through here.
"""

import json
import logging
from typing import Type, TypeVar
from pydantic import BaseModel, ValidationError
from ai_client import BaseAIClient

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

MAX_RETRIES = 2


class LLMCallError(Exception):
    """Raised when LLM output fails validation after all retries."""
    pass


def _parse_json(raw: str) -> dict:
    """
    Strip markdown fences if present, then parse JSON.
    LLMs sometimes wrap output in ```json ... ``` despite being told not to.
    """
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        # Drop first line (```json or ```) and last line (```)
        cleaned = "\n".join(lines[1:-1]).strip()
    return json.loads(cleaned)


def call_with_retry(
    client: BaseAIClient,
    system_prompt: str,
    user_prompt: str,
    output_schema: Type[T],
    temperature: float = 0.3,
    max_tokens: int = 2048,
) -> T:
    """
    Call the LLM, parse JSON, validate against schema.
    Retries up to MAX_RETRIES times with a corrective prompt on failure.

    Args:
        client:         Any BaseAIClient implementation
        system_prompt:  System instructions
        user_prompt:    User turn content
        output_schema:  Pydantic model to validate against
        temperature:    LLM temperature
        max_tokens:     Max tokens for response

    Returns:
        Validated Pydantic model instance

    Raises:
        LLMCallError: If all retries fail
    """
    last_error = None
    current_user_prompt = user_prompt

    for attempt in range(1, MAX_RETRIES + 2):  # attempts: 1, 2, 3
        try:
            logger.debug(f"LLM call attempt {attempt}/{MAX_RETRIES + 1}")

            response = client.complete(
                system_prompt=system_prompt,
                user_prompt=current_user_prompt,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            raw = response.content
            logger.debug(f"Raw LLM response:\n{raw}")

            parsed = _parse_json(raw)
            validated = output_schema.model_validate(parsed)

            if attempt > 1:
                logger.info(f"LLM call succeeded on attempt {attempt}")

            return validated

        except json.JSONDecodeError as e:
            last_error = f"JSON parse error: {e}\n\nRaw output was:\n{raw}"
            logger.warning(f"Attempt {attempt} — JSON parse failed: {e}")

        except ValidationError as e:
            last_error = f"Schema validation error:\n{e}"
            logger.warning(f"Attempt {attempt} — validation failed:\n{e}")

        except Exception as e:
            last_error = f"Unexpected error: {e}"
            logger.error(f"Attempt {attempt} — unexpected error: {e}")
            raise  # Don't retry on unexpected errors — likely a provider issue

        # Build corrective prompt for next attempt
        if attempt <= MAX_RETRIES:
            current_user_prompt = f"""Your previous response had errors that must be fixed:

{last_error}

Original request:
{user_prompt}

Fix only the errors listed above.
Output ONLY valid JSON matching the required schema. No preamble, no markdown fences."""

    raise LLMCallError(
        f"LLM call failed after {MAX_RETRIES + 1} attempts.\nLast error: {last_error}"
    )
