"""
test_engine.py

Tests for the correlation/highlight engine.
Uses a MockAIClient — no real API calls needed.
Run with: python -m pytest test_engine.py -v
"""

import json
import pytest
from unittest.mock import MagicMock

from ai_client import BaseAIClient, AIResponse
from engine import run
from schemas import (
    EngineInput,
    CorrelationOutput,
    HighlightOutput,
    OutputMode,
    RecommendationType,
    NarrativeAngle,
    ToneDirection,
    Confidence,
)


# ---------------------------------------------------------------------------
# Mock AI client — returns hardcoded JSON, no API calls
# ---------------------------------------------------------------------------

class MockAIClient(BaseAIClient):
    def __init__(self, response_json: dict):
        self._response = response_json

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        return AIResponse(
            content=json.dumps(self._response),
            provider="mock",
            model="mock-model",
        )


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

INCEPTION_CONTENT = {
    "contentId": "inception",
    "description": "A thief who steals corporate secrets through dream-sharing technology.",
    "genre": ["sci-fi", "thriller", "action"],
    "cast": ["Leonardo DiCaprio", "Joseph Gordon-Levitt"],
    "awards": ["Oscar – Best Cinematography"],
    "rating": 8.8,
    "themes": [
        {"name": "Mind-Bending Reality", "rank": 1},
        {"name": "Heist and Deception", "rank": 2},
        {"name": "Guilt and Grief", "rank": 3},
    ],
}

SHUTTER_ISLAND_CONTENT = {
    "contentId": "shutter_island",
    "description": "A U.S. Marshal investigates a psychiatric facility on a remote island.",
    "genre": ["thriller", "mystery", "drama"],
    "cast": ["Leonardo DiCaprio", "Mark Ruffalo"],
    "awards": ["BAFTA Nomination – Best Production Design"],
    "rating": 8.1,
    "themes": [
        {"name": "Fractured Perception", "rank": 1},
        {"name": "Institutional Conspiracy", "rank": 2},
        {"name": "Loss and Guilt", "rank": 3},
    ],
}

MOCK_CORRELATION_RESPONSE = {
    "correlations": [
        {
            "rank": 1,
            "themeA": "Mind-Bending Reality",
            "themeB": "Fractured Perception",
            "reason": "Both protagonists experience reality as unstable and untrustworthy.",
            "metadataSignals": "Shared lead actor, overlapping psychological thriller genre.",
            "confidence": "HIGH",
            "narrativeAngle": "DOMINANT_MATCH",
        },
        {
            "rank": 2,
            "themeA": "Guilt and Grief",
            "themeB": "Loss and Guilt",
            "reason": "Both protagonists are driven by unresolved guilt over a lost loved one.",
            "metadataSignals": "Tonal similarity — grief as the engine of unreliability.",
            "confidence": "HIGH",
            "narrativeAngle": "HIDDEN_CONNECTION",
        },
    ]
}

MOCK_HIGHLIGHT_RESPONSE = {
    "primaryAngle": "Award-nominated psychological thriller with near-universal critical praise.",
    "dominantTheme": "Fractured Perception",
    "toneDirection": "PRESTIGE",
    "highlightSignals": {
        "rating": 8.1,
        "awards": "BAFTA Nomination – Best Production Design",
        "popularityNote": "1.2M IMDb votes, 88% RT critic score",
    },
}


# ---------------------------------------------------------------------------
# A_TO_B Correlation tests
# ---------------------------------------------------------------------------

class TestCorrelation:

    def _make_input(self):
        return EngineInput.model_validate({
            "recommendationType": "A_TO_B",
            "recommendedContent": SHUTTER_ISLAND_CONTENT,
            "sourceContent": INCEPTION_CONTENT,
        })

    def test_returns_correlation_output(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        assert isinstance(result, CorrelationOutput)

    def test_mode_is_correlation(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        assert result.mode == OutputMode.CORRELATION

    def test_content_ids_are_set(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        assert result.sourceContentId == "inception"
        assert result.recommendedContentId == "shutter_island"

    def test_correlations_are_sorted_by_rank(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        ranks = [c.rank for c in result.correlations]
        assert ranks == sorted(ranks)

    def test_top_correlation_is_dominant_match(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        assert result.correlations[0].narrativeAngle == NarrativeAngle.DOMINANT_MATCH

    def test_second_correlation_is_hidden_connection(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        assert result.correlations[1].narrativeAngle == NarrativeAngle.HIDDEN_CONNECTION

    def test_confidence_values_are_valid(self):
        client = MockAIClient(MOCK_CORRELATION_RESPONSE)
        result = run(self._make_input(), client)
        for c in result.correlations:
            assert c.confidence in list(Confidence)

    def test_a_to_b_requires_source_content(self):
        with pytest.raises(Exception):
            EngineInput.model_validate({
                "recommendationType": "A_TO_B",
                "recommendedContent": SHUTTER_ISLAND_CONTENT,
                "sourceContent": None,
            })


# ---------------------------------------------------------------------------
# Non A_TO_B Highlight tests
# ---------------------------------------------------------------------------

class TestHighlight:

    def _make_input(self, rec_type: str = "CRITICALLY_ACCLAIMED"):
        return EngineInput.model_validate({
            "recommendationType": rec_type,
            "recommendedContent": SHUTTER_ISLAND_CONTENT,
            "sourceContent": None,
            "externalSignals": {
                "rtCriticScore": 88,
                "imdbVoteCount": 1200000,
                "trendingRank": None,
                "popularityScore": 74.3,
            },
        })

    def test_returns_highlight_output(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert isinstance(result, HighlightOutput)

    def test_mode_is_highlight(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert result.mode == OutputMode.HIGHLIGHT

    def test_content_id_is_set(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert result.recommendedContentId == "shutter_island"

    def test_recommendation_type_is_set(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert result.recommendationType == RecommendationType.CRITICALLY_ACCLAIMED

    def test_tone_direction_is_prestige(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert result.toneDirection == ToneDirection.PRESTIGE

    def test_dominant_theme_is_set(self):
        client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
        result = run(self._make_input(), client)
        assert result.dominantTheme == "Fractured Perception"

    def test_all_non_a_to_b_types_route_to_highlight(self):
        highlight_types = [
            "TRENDING", "POPULAR", "CRITICALLY_ACCLAIMED",
            "SOCIALLY_BUZZING", "GENRE_MOOD_MATCH", "FRANCHISE_CREATOR", "REWATCH"
        ]
        for rec_type in highlight_types:
            client = MockAIClient(MOCK_HIGHLIGHT_RESPONSE)
            result = run(self._make_input(rec_type), client)
            assert isinstance(result, HighlightOutput), f"Failed for type: {rec_type}"


# ---------------------------------------------------------------------------
# Retry logic tests
# ---------------------------------------------------------------------------

class TestRetryLogic:

    def test_retries_on_invalid_json(self):
        """Client returns garbage first, valid JSON on second attempt."""
        call_count = 0

        class FlakyClient(BaseAIClient):
            def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048):
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    return AIResponse(content="not valid json {{{", provider="mock", model="mock")
                return AIResponse(
                    content=json.dumps(MOCK_CORRELATION_RESPONSE),
                    provider="mock",
                    model="mock",
                )

        engine_input = EngineInput.model_validate({
            "recommendationType": "A_TO_B",
            "recommendedContent": SHUTTER_ISLAND_CONTENT,
            "sourceContent": INCEPTION_CONTENT,
        })

        result = run(engine_input, FlakyClient())
        assert isinstance(result, CorrelationOutput)
        assert call_count == 2

    def test_raises_after_max_retries(self):
        """Client always returns invalid JSON — should raise after retries."""
        from llm_caller import LLMCallError

        class AlwaysBrokenClient(BaseAIClient):
            def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048):
                return AIResponse(content="{{broken json", provider="mock", model="mock")

        engine_input = EngineInput.model_validate({
            "recommendationType": "A_TO_B",
            "recommendedContent": SHUTTER_ISLAND_CONTENT,
            "sourceContent": INCEPTION_CONTENT,
        })

        with pytest.raises(LLMCallError):
            run(engine_input, AlwaysBrokenClient())
