"""
engine.py

Entry point for the Correlation & Highlight Engine (T5).

Single public function: run(input, client) → EngineOutput
Routes internally to correlation.py or highlight.py based on recommendation type.
Caller never needs to know which path was taken — check output.mode if needed.
"""

import logging
from ai_client import BaseAIClient, get_ai_client
from correlation import run_correlation
from highlight import run_highlight
from schemas import EngineInput, EngineOutput, RecommendationType

logger = logging.getLogger(__name__)

# Types that go through correlation (need source content)
_CORRELATION_TYPES = {RecommendationType.A_TO_B}

# All other types go through highlight extraction
_HIGHLIGHT_TYPES = {
    RecommendationType.TRENDING,
    RecommendationType.POPULAR,
    RecommendationType.CRITICALLY_ACCLAIMED,
    RecommendationType.SOCIALLY_BUZZING,
    RecommendationType.GENRE_MOOD_MATCH,
    RecommendationType.FRANCHISE_CREATOR,
    RecommendationType.REWATCH,
}


def run(engine_input: EngineInput, client: BaseAIClient) -> EngineOutput:
    """
    Main entry point for the correlation/highlight engine.

    Args:
        engine_input: Validated EngineInput object
        client:       Any BaseAIClient implementation (OpenAI, Groq, Bedrock, custom)

    Returns:
        CorrelationOutput (for A_TO_B) or HighlightOutput (for all other types)

    Raises:
        ValueError:    If recommendation type is unknown
        LLMCallError:  If LLM fails after all retries
    """
    rec_type = engine_input.recommendationType
    logger.info(f"Engine starting — type: {rec_type.value}")

    if rec_type in _CORRELATION_TYPES:
        return run_correlation(
            client=client,
            source=engine_input.sourceContent,
            recommended=engine_input.recommendedContent,
        )

    elif rec_type in _HIGHLIGHT_TYPES:
        return run_highlight(
            client=client,
            recommended=engine_input.recommendedContent,
            recommendation_type=rec_type,
            external_signals=engine_input.externalSignals,
        )

    else:
        raise ValueError(f"Unknown recommendation type: {rec_type}")


# ---------------------------------------------------------------------------
# Convenience wrapper — accepts raw dict, handles client creation
# ---------------------------------------------------------------------------

def run_from_dict(
    input_dict: dict,
    provider: str,
    **provider_kwargs,
) -> dict:
    """
    Convenience wrapper for callers who want to pass raw dicts
    and get raw dicts back (e.g. from an API layer or tests).

    Args:
        input_dict:       Raw dict matching EngineInput schema
        provider:         "openai" | "groq" | "bedrock" | "custom"
        **provider_kwargs: Passed to get_ai_client (model, api_key, etc.)

    Returns:
        Output as dict (serialized from Pydantic model)

    Example:
        result = run_from_dict(
            input_dict={"recommendationType": "A_TO_B", ...},
            provider="groq",
            model="llama-3.3-70b-versatile"
        )
    """
    engine_input = EngineInput.model_validate(input_dict)
    client = get_ai_client(provider, **provider_kwargs)
    output = run(engine_input, client)
    return output.model_dump()
