"""
ai_client.py

Provider-agnostic AI client layer.
Swap providers via config — zero changes to engine logic.

Supported providers: openai, groq, bedrock, custom
"""

import os
import json
from abc import ABC, abstractmethod
from typing import Optional
from dataclasses import dataclass


@dataclass
class AIResponse:
    content: str
    provider: str
    model: str


class BaseAIClient(ABC):
    """
    All providers implement this interface.
    Engine only calls .complete() — never talks to provider SDKs directly.
    """

    @abstractmethod
    def complete(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ) -> AIResponse:
        pass


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------

class OpenAIClient(BaseAIClient):

    def __init__(self, model: str = "gpt-4o", api_key: Optional[str] = None):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("pip install openai")

        self.model = model
        self.client = OpenAI(api_key=api_key or os.environ["OPENAI_API_KEY"])

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return AIResponse(
            content=response.choices[0].message.content,
            provider="openai",
            model=self.model,
        )


# ---------------------------------------------------------------------------
# Groq
# ---------------------------------------------------------------------------

class GroqClient(BaseAIClient):

    def __init__(self, model: str = "llama-3.3-70b-versatile", api_key: Optional[str] = None):
        try:
            from groq import Groq
        except ImportError:
            raise ImportError("pip install groq")

        self.model = model
        self.client = Groq(api_key=api_key or os.environ["GROQ_API_KEY"])

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return AIResponse(
            content=response.choices[0].message.content,
            provider="groq",
            model=self.model,
        )


# ---------------------------------------------------------------------------
# AWS Bedrock
# ---------------------------------------------------------------------------

class BedrockClient(BaseAIClient):

    def __init__(
        self,
        model: str = "anthropic.claude-3-5-sonnet-20241022-v2:0",
        region: str = "us-east-1",
    ):
        try:
            import boto3
        except ImportError:
            raise ImportError("pip install boto3")

        self.model = model
        self.client = boto3.client("bedrock-runtime", region_name=region)

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        import boto3
        from botocore.exceptions import ClientError

        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        })

        response = self.client.invoke_model(
            modelId=self.model,
            contentType="application/json",
            accept="application/json",
            body=body,
        )

        result = json.loads(response["body"].read())
        return AIResponse(
            content=result["content"][0]["text"],
            provider="bedrock",
            model=self.model,
        )


# ---------------------------------------------------------------------------
# Custom / Self-hosted (OpenAI-compatible endpoint)
# ---------------------------------------------------------------------------

class CustomClient(BaseAIClient):
    """
    For self-hosted models exposing an OpenAI-compatible API.
    e.g. vLLM, LM Studio, Ollama with OpenAI adapter
    """

    def __init__(self, base_url: str, model: str, api_key: str = "none"):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("pip install openai")

        self.model = model
        self.client = OpenAI(base_url=base_url, api_key=api_key)

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return AIResponse(
            content=response.choices[0].message.content,
            provider="custom",
            model=self.model,
        )


# ---------------------------------------------------------------------------
# Google Gemini
# ---------------------------------------------------------------------------

class GeminiClient(BaseAIClient):

    def __init__(self, model: str = "gemini-2.5-flash-preview-04-17", api_key: Optional[str] = None):
        try:
            from google import genai
            from google.genai import types
        except ImportError:
            raise ImportError("pip install google-genai")

        import os
        from google import genai as genai_module
        from google.genai import types as types_module

        self.model = model
        self.types = types_module
        self.client = genai_module.Client(
            api_key=api_key or os.environ["GEMINI_API_KEY"]
        )

    def complete(self, system_prompt, user_prompt, temperature=0.3, max_tokens=2048) -> AIResponse:
        response = self.client.models.generate_content(
            model=self.model,
            contents=user_prompt,
            config=self.types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=temperature,
                max_output_tokens=max_tokens,
            ),
        )
        return AIResponse(
            content=response.text,
            provider="gemini",
            model=self.model,
        )


# ---------------------------------------------------------------------------
# Factory — single entry point, driven by config
# ---------------------------------------------------------------------------

def get_ai_client(provider: str, **kwargs) -> BaseAIClient:
    """
    Usage:
        client = get_ai_client("openai", model="gpt-4o")
        client = get_ai_client("groq", model="llama-3.3-70b-versatile")
        client = get_ai_client("bedrock", model="anthropic.claude-3-5-sonnet-20241022-v2:0")
        client = get_ai_client("custom", base_url="http://localhost:8000", model="my-model")
    """
    providers = {
        "openai": OpenAIClient,
        "groq": GroqClient,
        "bedrock": BedrockClient,
        "custom": CustomClient,
        "gemini": GeminiClient,
    }

    if provider not in providers:
        raise ValueError(f"Unknown provider '{provider}'. Choose from: {list(providers.keys())}")

    return providers[provider](**kwargs)
