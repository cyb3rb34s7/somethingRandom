"""
correlation.py

Handles A_TO_B correlation — finds thematic and metadata-level reasons
why a viewer who watched content A would enjoy content B.
"""

import logging
from ai_client import BaseAIClient
from llm_caller import call_with_retry
from prompts import CorrelationPrompt
from schemas import (
    ContentInput,
    CorrelationOutput,
    RecommendationType,
)

logger = logging.getLogger(__name__)

# Temperature for this call — low, we want deterministic reasoning not creativity
TEMPERATURE = 0.3


def _build_llm_output_schema():
    """
    Intermediate schema for raw LLM output.
    The LLM doesn't know about mode/recommendationType/contentIds —
    we inject those after validation.
    """
    from pydantic import BaseModel
    from schemas import CorrelationEntry

    class RawCorrelationOutput(BaseModel):
        correlations: list[CorrelationEntry]

    return RawCorrelationOutput


def run_correlation(
    client: BaseAIClient,
    source: ContentInput,
    recommended: ContentInput,
) -> CorrelationOutput:
    """
    Find correlations between two contents for A_TO_B recommendation type.

    Args:
        client:      Agnostic AI client
        source:      Content the user watched (content A)
        recommended: Content being recommended (content B)

    Returns:
        CorrelationOutput with ranked correlation reasons
    """
    logger.info(f"Running correlation: {source.contentId} → {recommended.contentId}")

    prompt = CorrelationPrompt(source=source, recommended=recommended)
    RawSchema = _build_llm_output_schema()

    raw_output = call_with_retry(
        client=client,
        system_prompt=prompt.SYSTEM,
        user_prompt=prompt.render_user(),
        output_schema=RawSchema,
        temperature=TEMPERATURE,
    )

    # Enrich with fields the LLM doesn't need to produce
    result = CorrelationOutput(
        recommendationType=RecommendationType.A_TO_B,
        sourceContentId=source.contentId,
        recommendedContentId=recommended.contentId,
        correlations=raw_output.correlations,
    )

    logger.info(
        f"Correlation complete — {len(result.correlations)} reasons found. "
        f"Top: '{result.correlations[0].reason}'"
    )

    return result
