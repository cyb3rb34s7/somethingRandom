"""
prompts.py

All prompt templates for the correlation/highlight engine.
Prompts are structured objects with a render() method.
No f-strings scattered across business logic.
"""

from dataclasses import dataclass
from schemas import ContentInput, ExternalSignals, RecommendationType


def _format_themes(themes) -> str:
    return "\n".join(f"  {t.rank}. {t.name}" for t in themes)


def _format_list(items: list) -> str:
    return ", ".join(items) if items else "N/A"


def _format_external_signals(signals: ExternalSignals | None) -> str:
    if not signals:
        return "None available"
    parts = []
    if signals.rtCriticScore is not None:
        parts.append(f"RT Critic Score: {signals.rtCriticScore}%")
    if signals.imdbVoteCount is not None:
        parts.append(f"IMDb Votes: {signals.imdbVoteCount:,}")
    if signals.trendingRank is not None:
        parts.append(f"Trending Rank: #{signals.trendingRank}")
    if signals.popularityScore is not None:
        parts.append(f"Popularity Score: {signals.popularityScore}")
    return "\n".join(f"  - {p}" for p in parts) if parts else "None available"


# ---------------------------------------------------------------------------
# Correlation Prompt (A_TO_B)
# ---------------------------------------------------------------------------

@dataclass
class CorrelationPrompt:
    source: ContentInput
    recommended: ContentInput

    SYSTEM = """You are a film analyst for a video streaming platform.

Your job is to find the most compelling correlation between two pieces of content — \
explaining why a viewer who enjoyed content A would also enjoy content B.

You will be given:
- The ranked themes from each content's pretag analysis
- Metadata for both contents (genre, cast, description, awards)

Rules:
- Find up to 3 correlation reasons, ranked by strength
- Use BOTH theme overlap AND metadata signals (shared cast, genre, tonal similarity)
- narrativeAngle must be DOMINANT_MATCH when the correlation is on rank-1 themes of both contents
- narrativeAngle must be HIDDEN_CONNECTION when the correlation is on secondary themes (rank 2+) — \
  this signals a more surprising, intriguing narrative angle
- Do NOT reference specific plot points that could be spoilers
- Output ONLY valid JSON, no explanation, no preamble, no markdown fences

Required output schema:
{
  "correlations": [
    {
      "rank": 1,
      "themeA": "<theme name from content A>",
      "themeB": "<theme name from content B>",
      "reason": "<one sentence — the emotional connection a viewer would feel>",
      "metadataSignals": "<shared cast, genre or tonal notes that reinforce this>",
      "confidence": "HIGH" | "MEDIUM" | "LOW",
      "narrativeAngle": "DOMINANT_MATCH" | "HIDDEN_CONNECTION"
    }
  ]
}"""

    def render_user(self) -> str:
        return f"""Find correlations between these two contents.

Content A — {self.source.contentId}
Description: {self.source.description}
Genre: {_format_list(self.source.genre)}
Cast: {_format_list(self.source.cast)}
Awards: {_format_list(self.source.awards)}
Rating: {self.source.rating}
Themes (ranked):
{_format_themes(self.source.themes)}

Content B — {self.recommended.contentId}
Description: {self.recommended.description}
Genre: {_format_list(self.recommended.genre)}
Cast: {_format_list(self.recommended.cast)}
Awards: {_format_list(self.recommended.awards)}
Rating: {self.recommended.rating}
Themes (ranked):
{_format_themes(self.recommended.themes)}"""


# ---------------------------------------------------------------------------
# Highlight Prompt (non A_TO_B)
# ---------------------------------------------------------------------------

TONE_GUIDE = {
    RecommendationType.TRENDING:           ("URGENT",       "Urgent, FOMO — the moment everyone is watching"),
    RecommendationType.POPULAR:            ("SOCIAL_PROOF", "Confident — millions of viewers can't be wrong"),
    RecommendationType.CRITICALLY_ACCLAIMED:("PRESTIGE",    "Prestige, cinematic — recognized as genuinely great art"),
    RecommendationType.SOCIALLY_BUZZING:   ("ENERGETIC",    "Energetic — fans and communities can't stop discussing this"),
    RecommendationType.GENRE_MOOD_MATCH:   ("ATMOSPHERIC",  "Atmospheric, mood-first — this matches exactly what you're in the mood for"),
    RecommendationType.FRANCHISE_CREATOR:  ("FAMILIAR",     "Warm and familiar — more of what you already love"),
    RecommendationType.REWATCH:            ("NOSTALGIC",    "Nostalgic, warm — some stories are worth experiencing twice"),
}


@dataclass
class HighlightPrompt:
    recommended: ContentInput
    recommendation_type: RecommendationType
    external_signals: ExternalSignals | None

    SYSTEM = """You are a film marketing analyst for a video streaming platform.

Your job is to identify the most compelling narrative angle for a recommendation explanation video.

You will be given the recommendation type, content metadata, ranked themes, and available external signals.

Rules:
- primaryAngle must be a single sentence — the core message of the explanation video
- dominantTheme must be the name of the rank-1 theme from the pretag data
- toneDirection must match the recommendation type (provided in the prompt)
- Only include highlightSignals fields that have actual values — do not invent data
- Output ONLY valid JSON, no explanation, no preamble, no markdown fences

Required output schema:
{
  "primaryAngle": "<one compelling sentence — the core message>",
  "dominantTheme": "<rank-1 theme name>",
  "toneDirection": "<tone value>",
  "highlightSignals": {
    "rating": <number or null>,
    "awards": "<key award string or null>",
    "popularityNote": "<short note on popularity or null>"
  }
}"""

    def render_user(self) -> str:
        tone_value, tone_desc = TONE_GUIDE.get(
            self.recommendation_type,
            ("PRESTIGE", "Prestige and quality")
        )

        return f"""Extract the highlight angle for this recommendation.

Recommendation type: {self.recommendation_type.value}
Tone direction to use: {tone_value} — {tone_desc}

Content: {self.recommended.contentId}
Description: {self.recommended.description}
Genre: {_format_list(self.recommended.genre)}
Cast: {_format_list(self.recommended.cast)}
Awards: {_format_list(self.recommended.awards)}
Rating: {self.recommended.rating}
Themes (ranked):
{_format_themes(self.recommended.themes)}

External signals:
{_format_external_signals(self.external_signals)}"""
