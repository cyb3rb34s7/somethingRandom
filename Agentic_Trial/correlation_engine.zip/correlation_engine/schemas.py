"""
schemas.py

Pydantic models for all inputs and outputs of the correlation/highlight engine.
Used for validation at every stage — input, LLM output, and final response.
"""

from __future__ import annotations
from enum import Enum
from typing import Optional
from pydantic import BaseModel, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class RecommendationType(str, Enum):
    A_TO_B = "A_TO_B"
    TRENDING = "TRENDING"
    POPULAR = "POPULAR"
    CRITICALLY_ACCLAIMED = "CRITICALLY_ACCLAIMED"
    SOCIALLY_BUZZING = "SOCIALLY_BUZZING"
    GENRE_MOOD_MATCH = "GENRE_MOOD_MATCH"
    FRANCHISE_CREATOR = "FRANCHISE_CREATOR"
    REWATCH = "REWATCH"


class Confidence(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class NarrativeAngle(str, Enum):
    DOMINANT_MATCH = "DOMINANT_MATCH"      # Correlation on rank-1 themes of both contents
    HIDDEN_CONNECTION = "HIDDEN_CONNECTION" # Correlation on secondary themes — more surprising


class ToneDirection(str, Enum):
    PRESTIGE = "PRESTIGE"
    URGENT = "URGENT"
    SOCIAL_PROOF = "SOCIAL_PROOF"
    ENERGETIC = "ENERGETIC"
    ATMOSPHERIC = "ATMOSPHERIC"
    FAMILIAR = "FAMILIAR"
    NOSTALGIC = "NOSTALGIC"


class OutputMode(str, Enum):
    CORRELATION = "CORRELATION"
    HIGHLIGHT = "HIGHLIGHT"


# ---------------------------------------------------------------------------
# Shared sub-models
# ---------------------------------------------------------------------------

class Theme(BaseModel):
    name: str
    rank: int


class ContentInput(BaseModel):
    contentId: str
    description: str
    genre: list[str]
    cast: list[str]
    awards: list[str]
    rating: float
    themes: list[Theme]

    @field_validator("themes")
    @classmethod
    def themes_must_be_ranked(cls, v):
        if not v:
            raise ValueError("themes list cannot be empty")
        ranks = [t.rank for t in v]
        if len(ranks) != len(set(ranks)):
            raise ValueError("theme ranks must be unique")
        return sorted(v, key=lambda t: t.rank)  # always sorted by rank


class ExternalSignals(BaseModel):
    rtCriticScore: Optional[float] = None
    imdbVoteCount: Optional[int] = None
    trendingRank: Optional[int] = None
    popularityScore: Optional[float] = None


# ---------------------------------------------------------------------------
# Engine Input
# ---------------------------------------------------------------------------

class EngineInput(BaseModel):
    recommendationType: RecommendationType
    recommendedContent: ContentInput
    sourceContent: Optional[ContentInput] = None
    externalSignals: Optional[ExternalSignals] = None

    @model_validator(mode="after")
    def validate_source_for_a_to_b(self):
        if self.recommendationType == RecommendationType.A_TO_B:
            if self.sourceContent is None:
                raise ValueError("sourceContent is required for A_TO_B recommendation type")
        return self


# ---------------------------------------------------------------------------
# Correlation Output (A_TO_B)
# ---------------------------------------------------------------------------

class CorrelationEntry(BaseModel):
    rank: int
    themeA: str
    themeB: str
    reason: str
    metadataSignals: str
    confidence: Confidence
    narrativeAngle: NarrativeAngle


class CorrelationOutput(BaseModel):
    mode: OutputMode = OutputMode.CORRELATION
    recommendationType: RecommendationType
    sourceContentId: str
    recommendedContentId: str
    correlations: list[CorrelationEntry]

    @field_validator("correlations")
    @classmethod
    def must_have_at_least_one(cls, v):
        if not v:
            raise ValueError("correlations must contain at least one entry")
        return sorted(v, key=lambda c: c.rank)


# ---------------------------------------------------------------------------
# Highlight Output (non A_TO_B)
# ---------------------------------------------------------------------------

class HighlightSignals(BaseModel):
    rating: Optional[float] = None
    awards: Optional[str] = None
    popularityNote: Optional[str] = None


class HighlightOutput(BaseModel):
    mode: OutputMode = OutputMode.HIGHLIGHT
    recommendationType: RecommendationType
    recommendedContentId: str
    primaryAngle: str
    dominantTheme: str
    toneDirection: ToneDirection
    highlightSignals: HighlightSignals


# ---------------------------------------------------------------------------
# Union type — what the engine always returns
# ---------------------------------------------------------------------------

EngineOutput = CorrelationOutput | HighlightOutput
