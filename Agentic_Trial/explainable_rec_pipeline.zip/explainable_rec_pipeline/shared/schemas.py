"""
shared/schemas.py

Single source of truth for all data contracts between modules.
Every module imports from here — nothing defines its own schemas.
"""

from __future__ import annotations
from enum import Enum
from typing import Optional
from pydantic import BaseModel, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class RecommendationType(str, Enum):
    A_TO_B                = "A_TO_B"
    TRENDING              = "TRENDING"
    POPULAR               = "POPULAR"
    CRITICALLY_ACCLAIMED  = "CRITICALLY_ACCLAIMED"
    SOCIALLY_BUZZING      = "SOCIALLY_BUZZING"
    GENRE_MOOD_MATCH      = "GENRE_MOOD_MATCH"
    FRANCHISE_CREATOR     = "FRANCHISE_CREATOR"
    REWATCH               = "REWATCH"


class Confidence(str, Enum):
    HIGH   = "HIGH"
    MEDIUM = "MEDIUM"
    LOW    = "LOW"


class NarrativeAngle(str, Enum):
    DOMINANT_MATCH    = "DOMINANT_MATCH"
    HIDDEN_CONNECTION = "HIDDEN_CONNECTION"


class ToneDirection(str, Enum):
    PRESTIGE     = "PRESTIGE"
    URGENT       = "URGENT"
    SOCIAL_PROOF = "SOCIAL_PROOF"
    ENERGETIC    = "ENERGETIC"
    ATMOSPHERIC  = "ATMOSPHERIC"
    FAMILIAR     = "FAMILIAR"
    NOSTALGIC    = "NOSTALGIC"


class SpoilerRisk(str, Enum):
    LOW    = "LOW"
    MEDIUM = "MEDIUM"
    HIGH   = "HIGH"


class OverlayPosition(str, Enum):
    TOP_CENTER    = "TOP_CENTER"
    BOTTOM_CENTER = "BOTTOM_CENTER"
    CENTER        = "CENTER"


class OverlayStyle(str, Enum):
    CINEMATIC_BOLD = "CINEMATIC_BOLD"
    SUBTLE         = "SUBTLE"
    BRAND          = "BRAND"


class OutputMode(str, Enum):
    CORRELATION = "CORRELATION"
    HIGHLIGHT   = "HIGHLIGHT"


class PipelineStatus(str, Enum):
    AWAITING_TIMESTAMPS = "AWAITING_TIMESTAMPS"
    COMPLETE            = "COMPLETE"


# ---------------------------------------------------------------------------
# Shared sub-models
# ---------------------------------------------------------------------------

class Theme(BaseModel):
    name: str
    rank: int


class ContentMetadata(BaseModel):
    contentId:   str
    description: str
    genre:       list[str]
    cast:        list[str]
    awards:      list[str]
    rating:      float
    themes:      list[Theme]

    @field_validator("themes")
    @classmethod
    def sort_themes_by_rank(cls, v):
        return sorted(v, key=lambda t: t.rank)


class ExternalSignals(BaseModel):
    rtCriticScore:   Optional[float] = None
    imdbVoteCount:   Optional[int]   = None
    trendingRank:    Optional[int]   = None
    popularityScore: Optional[float] = None


class KeyMoment(BaseModel):
    number:      int
    title:       str
    description: str
    startTime:   int
    endTime:     int

    @property
    def duration(self) -> int:
        return self.endTime - self.startTime


class Scene(BaseModel):
    number:      int
    title:       str
    description: str
    startTime:   int
    endTime:     int
    tags:        list[str] = []


# ---------------------------------------------------------------------------
# T1 — Input Aggregator output
# ---------------------------------------------------------------------------

class UnifiedContext(BaseModel):
    recommendationType:  RecommendationType
    recommendedContent:  ContentMetadata
    sourceContent:       Optional[ContentMetadata] = None
    externalSignals:     Optional[ExternalSignals] = None
    availableSignals:    list[str] = []

    @model_validator(mode="after")
    def validate_a_to_b(self):
        if self.recommendationType == RecommendationType.A_TO_B and not self.sourceContent:
            raise ValueError("sourceContent required for A_TO_B")
        return self


# ---------------------------------------------------------------------------
# T2 — Classifier output
# ---------------------------------------------------------------------------

class ClassificationResult(BaseModel):
    primaryType:       RecommendationType
    confidence:        Confidence
    evidence:          str
    secondaryType:     Optional[RecommendationType] = None
    secondaryEvidence: Optional[str]                = None
    sourceContentId:   Optional[str]                = None
    recommendedContentId: str


# ---------------------------------------------------------------------------
# T3 — Pretag Loader output
# ---------------------------------------------------------------------------

class ContentPretag(BaseModel):
    contentId:   str
    themes:      list[Theme]
    scenes:      list[Scene]
    keyMoments:  list[KeyMoment]


class PretagContext(BaseModel):
    recommendedContent: ContentPretag
    sourceContent:      Optional[ContentPretag] = None


# ---------------------------------------------------------------------------
# T5 — Correlation / Highlight Engine output
# ---------------------------------------------------------------------------

class CorrelationEntry(BaseModel):
    rank:             int
    themeA:           str
    themeB:           str
    reason:           str
    metadataSignals:  str
    confidence:       Confidence
    narrativeAngle:   NarrativeAngle


class CorrelationOutput(BaseModel):
    mode:                 OutputMode = OutputMode.CORRELATION
    recommendationType:   RecommendationType
    sourceContentId:      str
    recommendedContentId: str
    correlations:         list[CorrelationEntry]

    @field_validator("correlations")
    @classmethod
    def at_least_one(cls, v):
        if not v:
            raise ValueError("correlations must have at least one entry")
        return sorted(v, key=lambda c: c.rank)


class HighlightSignals(BaseModel):
    rating:        Optional[float] = None
    awards:        Optional[str]   = None
    popularityNote: Optional[str]  = None


class HighlightOutput(BaseModel):
    mode:                 OutputMode = OutputMode.HIGHLIGHT
    recommendationType:   RecommendationType
    recommendedContentId: str
    primaryAngle:         str
    dominantTheme:        str
    toneDirection:        ToneDirection
    highlightSignals:     HighlightSignals


EngineOutput = CorrelationOutput | HighlightOutput


# ---------------------------------------------------------------------------
# T6A — Scene Selector output
# ---------------------------------------------------------------------------

class SelectedScene(BaseModel):
    contentId:        str
    keyMomentNumber:  int
    title:            str
    startTime:        int   # full key moment bounds — for human reference
    endTime:          int
    durationSeconds:  int
    spoilerRisk:      SpoilerRisk
    spoilerReason:    Optional[str] = None
    narrativePurpose: str
    # Manually set after human review:
    clipStart:        Optional[int] = None
    clipEnd:          Optional[int] = None


class SceneSelectionOutput(BaseModel):
    selectedScenes: list[SelectedScene]

    def is_timestamps_complete(self) -> bool:
        return all(
            s.clipStart is not None and s.clipEnd is not None
            for s in self.selectedScenes
        )


# ---------------------------------------------------------------------------
# T7 / T8 — Manifest Builder output
# ---------------------------------------------------------------------------

class Overlay(BaseModel):
    text:            str
    position:        OverlayPosition
    appearAtSecond:  float
    holdSeconds:     float
    style:           OverlayStyle


class ManifestClip(BaseModel):
    clipIndex:   int
    contentId:   str
    clipStart:   int
    clipEnd:     int
    transitionIn:        str
    transitionOut:       str
    transitionDurationMs: int
    overlays:    list[Overlay]


class TransitionOverlay(BaseModel):
    afterClipIndex: int
    text:           str
    position:       OverlayPosition
    style:          OverlayStyle
    durationMs:     int


class EndCard(BaseModel):
    text:            str
    durationSeconds: int
    style:           OverlayStyle = OverlayStyle.BRAND


class Manifest(BaseModel):
    manifestVersion:    str = "1.0"
    recommendationType: RecommendationType
    tag:                str
    oneLiner:           str
    clips:              list[ManifestClip]
    transitionOverlays: list[TransitionOverlay]
    endCard:            EndCard
    metadata:           dict
