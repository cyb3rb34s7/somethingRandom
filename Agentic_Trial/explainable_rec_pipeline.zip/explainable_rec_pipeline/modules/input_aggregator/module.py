"""
modules/input_aggregator/module.py  — T1

Normalizes raw recommendation event + content metadata into UnifiedContext.
No LLM call. Pure data loading and validation.

Expected raw event shape:
{
    "recommendationType": "A_TO_B",
    "recommendedContent": { ...ContentMetadata fields... },
    "sourceContent": { ...ContentMetadata fields... } | null,
    "externalSignals": { ... } | null,
    "availableSignals": ["BECAUSE_YOU_WATCHED", ...]
}
"""

import logging
from shared.schemas import UnifiedContext

logger = logging.getLogger(__name__)


class InputAggregatorError(Exception):
    pass


def run(raw_event: dict) -> UnifiedContext:
    """
    Validate and normalize the raw recommendation event.

    Args:
        raw_event: Raw dict from pipeline entry point

    Returns:
        UnifiedContext — validated, ready for downstream modules
    """
    try:
        context = UnifiedContext.model_validate(raw_event)
        logger.info(
            f"Input aggregated — type: {context.recommendationType.value} | "
            f"recommended: {context.recommendedContent.contentId}"
        )
        return context
    except Exception as e:
        raise InputAggregatorError(f"Invalid recommendation event: {e}") from e
