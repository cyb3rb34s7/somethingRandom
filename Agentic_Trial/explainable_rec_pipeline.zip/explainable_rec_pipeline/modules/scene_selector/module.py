"""
modules/scene_selector/module.py  — T6A

Selects best key moments from pretag data based on correlation/highlight output.
Outputs selectedScenes — clipStart/clipEnd are null until manually set.
"""

import logging
from pydantic import BaseModel
from typing import Optional
from shared.schemas import (
    PretagContext, EngineOutput, SceneSelectionOutput, SelectedScene,
    CorrelationOutput, HighlightOutput,
    RecommendationType, SpoilerRisk, OutputMode,
    KeyMoment,
)
from shared.ai_client import BaseAIClient
from shared.llm_caller import call_llm

logger = logging.getLogger(__name__)
TEMPERATURE = 0.1


# ---------------------------------------------------------------------------
# Raw LLM output schema
# ---------------------------------------------------------------------------

class _RawSelectedScene(BaseModel):
    contentId:        str
    keyMomentNumber:  int
    title:            str
    startTime:        int
    endTime:          int
    durationSeconds:  int
    spoilerRisk:      SpoilerRisk
    spoilerReason:    Optional[str] = None
    narrativePurpose: str


class _RawSceneSelection(BaseModel):
    selectedScenes: list[_RawSelectedScene]


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

SYSTEM = """You are a film editor selecting scenes for a short recommendation explanation video.

Select the best key moment(s) that visually communicate the recommendation reason WITHOUT spoiling the story.

Rules:
- Prefer scenes that establish atmosphere, character, or premise — NOT scenes that resolve the story
- Flag spoilerRisk HIGH if description implies: a twist, death, final confrontation, or revelation
- If spoilerRisk is HIGH, pick the next best scene instead
- For A_TO_B: select exactly one key moment from EACH content (two total)
- For other types: select 1-2 key moments from the recommended content only
- narrativePurpose: what this clip makes the viewer FEEL, not what happens in it
- durationSeconds = endTime - startTime
- Output ONLY valid JSON, no preamble, no markdown fences

Schema:
{
  "selectedScenes": [
    {
      "contentId": "<contentId>",
      "keyMomentNumber": <number>,
      "title": "<title>",
      "startTime": <seconds>,
      "endTime": <seconds>,
      "durationSeconds": <number>,
      "spoilerRisk": "LOW|MEDIUM|HIGH",
      "spoilerReason": "<reason or null>",
      "narrativePurpose": "<what viewer feels>"
    }
  ]
}"""


def _fmt_moments(content_id: str, moments: list[KeyMoment]) -> str:
    lines = [f"\nKey moments from {content_id}:"]
    for km in moments:
        lines.append(
            f"  [{km.number}] {km.title} ({km.startTime}s–{km.endTime}s, {km.duration}s)\n"
            f"      {km.description}"
        )
    return "\n".join(lines)


def _build_user_prompt(engine_output: EngineOutput, pretag: PretagContext) -> str:
    if engine_output.mode == OutputMode.CORRELATION:
        top = engine_output.correlations[0]
        reason = f"Correlation: {top.reason} (theme match: {top.themeA} ↔ {top.themeB})"
        moments_block = (
            _fmt_moments(pretag.sourceContent.contentId, pretag.sourceContent.keyMoments)
            + _fmt_moments(pretag.recommendedContent.contentId, pretag.recommendedContent.keyMoments)
        )
    else:
        reason = f"Highlight angle: {engine_output.primaryAngle}"
        moments_block = _fmt_moments(
            pretag.recommendedContent.contentId,
            pretag.recommendedContent.keyMoments,
        )

    return f"""Select scenes for this explanation video.

Recommendation type: {engine_output.recommendationType.value}
Recommendation reason: {reason}
{moments_block}"""


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(
    engine_output: EngineOutput,
    pretag: PretagContext,
    client: BaseAIClient,
) -> SceneSelectionOutput:
    logger.info("Selecting scenes...")

    raw = call_llm(
        client=client,
        system_prompt=SYSTEM,
        user_prompt=_build_user_prompt(engine_output, pretag),
        output_schema=_RawSceneSelection,
        temperature=TEMPERATURE,
    )

    scenes = [
        SelectedScene(**s.model_dump(), clipStart=None, clipEnd=None)
        for s in raw.selectedScenes
    ]

    result = SceneSelectionOutput(selectedScenes=scenes)

    logger.info(f"Selected {len(scenes)} scene(s):")
    for s in scenes:
        logger.info(
            f"  [{s.contentId}] {s.title} "
            f"({s.startTime}s–{s.endTime}s) spoiler={s.spoilerRisk.value}"
        )

    if not result.is_timestamps_complete():
        logger.info(
            "clipStart/clipEnd are null — manual timestamp injection required before manifest generation."
        )

    return result
