"""
modules/pretag_loader/module.py  — T3

Loads and normalizes pretag JSON files (scenes, themes, key_moments)
for the relevant content(s) based on classification result.
No LLM call. Pure file I/O and normalization.

Expected pretag directory structure:
  pretag_data/
    {contentId}/
      scenes.json
      theme.json
      key_moments.json   (optional — falls back to scenes if missing)
"""

import json
import logging
from pathlib import Path
from shared.schemas import (
    ClassificationResult, PretagContext, ContentPretag,
    Theme, Scene, KeyMoment, RecommendationType,
)

logger = logging.getLogger(__name__)
PRETAG_BASE_DIR = Path("pretag_data")


class PretagLoaderError(Exception):
    pass


# ---------------------------------------------------------------------------
# File loaders
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> dict | list:
    if not path.exists():
        raise PretagLoaderError(f"Pretag file not found: {path}")
    with open(path) as f:
        return json.load(f)


def _load_themes(content_dir: Path) -> list[Theme]:
    data = _load_json(content_dir / "theme.json")
    theme_list = data.get("themeList", [])
    return [Theme(name=t["name"], rank=t["rank"]) for t in theme_list]


def _load_scenes(content_dir: Path) -> list[Scene]:
    data = _load_json(content_dir / "scenes.json")
    raw_scenes = data.get("content", data) if isinstance(data, dict) else data
    scenes = []
    for s in raw_scenes:
        scenes.append(Scene(
            number=s["number"],
            title=s["title"],
            description=s["description"],
            startTime=s.get("startTime", s.get("starttime", 0)),
            endTime=s.get("endTime", s.get("endtime", s.get("endTime", 0))),
            tags=s.get("tag", s.get("tags", [])),
        ))
    return scenes


def _load_key_moments(content_dir: Path, fallback_scenes: list[Scene]) -> list[KeyMoment]:
    km_path = content_dir / "key_moments.json"
    if not km_path.exists():
        logger.warning(f"key_moments.json not found for {content_dir.name} — using scenes as fallback")
        # Use scenes as key moments
        return [
            KeyMoment(
                number=s.number,
                title=s.title,
                description=s.description,
                startTime=s.startTime,
                endTime=s.endTime,
            )
            for s in fallback_scenes
        ]

    data = _load_json(km_path)
    raw = data.get("content", data) if isinstance(data, dict) else data
    return [
        KeyMoment(
            number=km["number"],
            title=km["title"],
            description=km["description"],
            startTime=km.get("startTime", km.get("starttime", 0)),
            endTime=km.get("endTime", km.get("endtime", 0)),
        )
        for km in raw
    ]


def _load_content(content_id: str) -> ContentPretag:
    content_dir = PRETAG_BASE_DIR / content_id
    if not content_dir.exists():
        raise PretagLoaderError(f"No pretag directory found for content: {content_id}")

    themes = _load_themes(content_dir)
    scenes = _load_scenes(content_dir)
    key_moments = _load_key_moments(content_dir, scenes)

    logger.info(
        f"Loaded pretag for '{content_id}' — "
        f"{len(themes)} themes, {len(scenes)} scenes, {len(key_moments)} key moments"
    )
    return ContentPretag(
        contentId=content_id,
        themes=themes,
        scenes=scenes,
        keyMoments=key_moments,
    )


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(classification: ClassificationResult) -> PretagContext:
    recommended = _load_content(classification.recommendedContentId)

    source = None
    if classification.primaryType == RecommendationType.A_TO_B and classification.sourceContentId:
        source = _load_content(classification.sourceContentId)

    return PretagContext(recommendedContent=recommended, sourceContent=source)
