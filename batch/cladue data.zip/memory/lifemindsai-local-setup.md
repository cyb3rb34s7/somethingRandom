---
name: lifemindsai-local-setup
description: How LifeMindsAI runs locally on this machine (WSL2 Ubuntu + Docker + Tailscale rkstgx profile)
metadata: 
  node_type: memory
  type: project
  originSessionId: fbcfff60-58b7-4abd-8e5e-99c05d1fb157
---

LifeMindsAI local dev runs inside **WSL2 Ubuntu**, code stays on Windows at
`/mnt/d/TGXX/work/LifeMindsAI` (edited via Zed on Windows). Set up 2026-07-13.

**Toolchain (WSL):** uv, Node 22 (nvm). JDK 21 + Gradle 8.7 live in `~/tools`
(not sdkman) — source `~/lifeminds-setup/env.sh` before running build/run scripts
so `_java-env.sh` picks up JAVA_HOME/GRADLE_HOME. Setup logs/helpers in
`~/lifeminds-setup/`.

**Config:** `~/.agent.config/deployment.ini`, active profile **`rkstgx`**.
App ports (unique 39xxx block, avoid common-port clashes): ui **39000**, ui-server
**39001**, auth **39002**, ai **39003**, safety-db **39006**, case-db **39080**.
Datastores stay on defaults via `infrastructure/docker.servers` Docker: MySQL 3306,
Neo4j 7474/7687, phpMyAdmin 6061. DB name **`rkstgx`**, app user `rkstgx_user`.

**Networking (changed 2026-07-27):** WSL **mirrored networking was ABANDONED** — it
silently stalls large (~1MB+) transfers (case-db→AI extraction submits, AI→Azure
uploads); full RCA in `/mnt/d/TGXX/work/Utilities/rca-extraction-upload-hang.md` §7a.
New setup: `.wslconfig` → **networkingMode=NAT** (backup `.wslconfig.mirrored.bak`),
**Tailscale runs INSIDE WSL** as node `rkstgx` (Windows node renamed `rkstgx-win`);
tailscaled installed + systemd-enabled. Keep `127.0.0.1 rkstgx` in WSL `/etc/hosts`
(+ `generateHosts=false`). Runbook + post-restart verification:
`~/lifeminds-setup/nat-tailscale-runbook.md` and `verify-net-fix.sh`.
**VERIFIED 2026-07-27:** 9/9 checks passed — the 964KB direct submit that previously
hung forever got its extraction job id in ~6s. WSL node = rkstgx (100.67.19.48),
Windows node renamed rkstgx-win; Docker Desktop localhost ports still work under NAT.
Windows browser reaches services via `127.0.0.1 rkstgx` in the Windows hosts file
(NAT localhost-forwarding). See [[wsl-git-crlf-normalized]].

**Login:** raja.singh@theragenx.com / `Rkstgx@123`, enterprise **`Theragenx`**.
2FA was force-disabled in the auth `.env` (`TWO_FACTOR_AUTH_ENABLED=False`).

**Bring-up:** full stack via `DEPLOY_CLIENT=amneal scripts/nix/recreate-env.sh
--rebuild-db --dangerously-drop-without-backup` (backup skipped since no mysqldump).

**Repo bugs found (candidates to file):** (1) auth `env.template` hardcodes
`TWO_FACTOR_AUTH_ENABLED=True`, ignoring the `[_secrets]` value; (2)
`assign-user-to-groups.sh` invokes `UserGroupAssigner.py` via a non-normalized
`../lib/` path, so its lexical `__file__` math breaks the `com` import and `.env`
lookup — worked around by calling the script with an absolute/normalized path.
