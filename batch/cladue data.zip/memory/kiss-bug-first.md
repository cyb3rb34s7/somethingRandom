---
name: kiss-bug-first
description: "Fix bugs with the simplest correct change first (KISS); defer optimization/refactor to a separate, later step"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fbcfff60-58b7-4abd-8e5e-99c05d1fb157
---

When fixing a bug, do the **simplest correct change first (KISS)**. Bug fixes are
**high priority**; do **not** optimize, refactor, de-duplicate, or re-architect as
part of the fix ("don't optimize from day one").

**Why:** Raja wants the bug closed fast and treats optimization as a separate,
lower-priority concern — bundling a refactor into a bugfix adds risk and scope.

**How to apply:** propose the minimal change that fixes the bug; surface any
cleanup/refactor/optimization opportunity **separately** as an explicit follow-up,
and only pursue it if he asks. Related: [[lifemindsai-local-setup]].
