---
name: wsl-git-crlf-normalized
description: The LifeMindsAI repo working tree was normalized CRLF->LF for WSL; git set to core.autocrlf=false
metadata: 
  node_type: memory
  type: project
  originSessionId: fbcfff60-58b7-4abd-8e5e-99c05d1fb157
---

The LifeMindsAI checkout at `/mnt/d/TGXX/work/LifeMindsAI` was cloned on Windows,
so all ~3600 tracked text files were **CRLF** while the committed blobs are **LF**.
Under WSL (Linux git) this made the whole tree show as modified and broke every
`.sh` script (`$'\r': command not found`).

Fixed 2026-07-13 by setting repo-local `core.autocrlf=false` + `core.eol=lf` and
running `git reset --hard` to rewrite the working tree to LF (matching blobs → git
clean again). If a mass "modified" diff or `\r` script errors reappear (e.g. after
a Windows-side operation re-introduces CRLF), re-run that normalization. Related:
[[lifemindsai-local-setup]].
