---
name: extraction-pipeline
description: "How a PDF becomes a saved case (ai-services LLM extraction → case-db ingestion); domain enums are DB-driven, not code"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2e4269a7-8970-4f93-b20d-5c4d7e1e23e7
---

Full verified walkthrough (file:line refs): `/mnt/d/TGXX/work/Utilities/extraction-pipeline.md`.

Verified 2026-07-21. AI extraction lives **only in `ai-services`** (Python) as a **9-executor
Microsoft Agent Framework workflow** (`…/extraction/workflow/ExtractionWorkflow.py`): PdfStaging →
(MarkdownPresence ∥ GridAnnotation) → PerFieldExtraction → FieldAssembly → **EnumNormalization**
→ MeddraCoding → WhoddCoding → ClinicalAssessment → ExtractionResult.

Trigger/flow: Java **case-db** `AttachmentPoller` polls `bookingattachments`, POSTs the PDF to
`POST /ai-server/api/v1/llm-service/extract`; ai-services runs the workflow and POSTs the result
back to case-db `POST /api/polling/extraction-complete` → `DefaultCaseIngestionService` writes ~25
MySQL tables (the system of record). **ai-services is read-only on the DB.** First pass = per-page
markdown + a *field-presence* report (field→pages), NOT page-type labels. Per-field = one LLM call
per present field. EnumNormalization = 2nd LLM matches extracted strings to **live DB** codelist/
config rows (e.g. "F"→"Female"). label→id happens in Java at ingestion (and at field-review save,
the #1769 path via `resolveByTable`).

**Enumerations:** domain vocab (gender, country, report_type, …) = **DB rows** in `codelist_*`/
`config_*` (source `database/codelists/*.json`), read live by both services; NOT code. Compiled
enums (Java in case-db ~13, Python in ai-services) are **system/workflow/type only**.

**Legacy — do NOT chase (we burned an hour on this once):** `safety-db-service` copies of
`CaseDataOCR.py`, `Codelists.py`, `CodelistFieldResolver.py` are unused. Live OCR schema =
`ai-services/.../extraction/CaseDataOCR.py`. See [[lifemindsai-local-setup]], [[kiss-bug-first]].
