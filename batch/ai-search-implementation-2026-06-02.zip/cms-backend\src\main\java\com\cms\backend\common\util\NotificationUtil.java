package com.cms.backend.common.util;

import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.Regions;
import com.cms.backend.common.model.AlertRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class NotificationUtil {

    public static final String ECS = "ECS";
    @Value("${CMS_NOTIFICATION_SVR_URL}")
    private String notificationServerUrl;


    private final HttpMethodHandler httpMethodHandler;


    public NotificationUtil(HttpMethodHandler httpMethodHandler) {
        this.httpMethodHandler = httpMethodHandler;

    }

    @Async
    public void sendErrorMail(Exception ex, String errorType, String errorCode,
        String errorSource) {
        log.info("Sending error mail");
        AlertRequestDto alertRequestDto = AlertRequestDto.builder().errorCode(errorCode)
            .errorMessage(
                ErrorMessageUtil.generateErrMessage(ex))
            .errorType(errorType).resourceType(ECS).region(Regions.US_REGION.value)
            .sourceService(errorSource).build();
        try {
            String NOTIFICATION_URL = "/cms/monitoring/notification";
            this.httpMethodHandler.handleHttpExchange(notificationServerUrl + NOTIFICATION_URL,
                Constants.METHOD_POST, new HttpEntity<>(alertRequestDto),
                ResponseEntity.class);
            log.info("Notification: Mail successfully sent");
        } catch (Exception exe) {
            log.error("Notification Error: Error in sending mail:", exe.getCause());
        }
    }

    @Async
    public void sendAlarm(Exception ex, String errorType, String errorCode, String errorSource) {
        AlertRequestDto alertRequestDto = AlertRequestDto.builder().errorCode(errorCode)
            .errorMessage(ErrorMessageUtil.generateErrMessage(ex))
            .errorType(errorType).resourceType(ECS).region(Regions.US_REGION.value)
            .sourceService(errorSource).build();
        try {
            String ALARM_URL = "/cms/monitoring/alarm";
            this.httpMethodHandler.handleHttpExchange(notificationServerUrl + ALARM_URL,
                Constants.METHOD_POST, new HttpEntity<>(alertRequestDto),
                ResponseEntity.class);
            log.info("Alarm: Alarm triggered successfully");
        } catch (Exception exe) {
            log.error("Alarm Error: Error in triggering alarm:", exe.getCause());
        }
    }
}