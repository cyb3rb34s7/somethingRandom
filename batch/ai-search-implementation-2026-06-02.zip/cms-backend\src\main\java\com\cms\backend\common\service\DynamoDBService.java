package com.cms.backend.common.service;


import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.common.model.InvalidLicenseWindowVodAsset;
import com.cms.backend.common.model.VodAsset;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementRequest;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementResponse;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;


@Service
@Slf4j
public class DynamoDBService {

    @Value("${CMS_VOD_CONTENT_DYNAMO}")
    private String cmsVodContentDynamo;

    @Value("${CMS_VOD_CONTENT_LICENSE_DYNAMO}")
    private String cmsVodContentLicenseDynamo;

    private final DynamoDbClient dynamoDB;

    private final ObjectMapper objectMapper = new ObjectMapper().setPropertyNamingStrategy(
        PropertyNamingStrategies.SNAKE_CASE);

    public DynamoDBService(DynamoDbClient dynamoDB) {
        this.dynamoDB = dynamoDB;
    }

    public List<VodAsset> getInvalidAssets() {

        Instant currentUTCDate = Instant.now();
        Instant previousUTCDate = currentUTCDate.minusSeconds(24L * 60L * 60L * 90L);
        String partiQlQuery = String.format(
            "select program_id,content_provider,country,api_error  ,api_error_datetime   from \"%s\".\"api_error-api_error_datetime-index\" where attribute_exists(\"%s\") and api_error_datetime >=? ;",
            cmsVodContentDynamo, "api_error");

        ExecuteStatementRequest request = ExecuteStatementRequest.builder().statement(partiQlQuery)
            .parameters(
                AttributeValue.builder().s(formatDate((previousUTCDate))).build()).build();
        ExecuteStatementResponse result = this.dynamoDB.executeStatement(request);
        List<Map<String, AttributeValue>> items = result.items();
        return items.stream().map(
            item -> objectMapper.convertValue(toSimpleMap(item), VodAsset.class)).toList();


    }

    public List<InvalidLicenseWindowVodAsset> getInvalidLicenseWindow() {
        Instant currentUTCDate = Instant.now();
        Instant previousUTCDate = currentUTCDate.minusSeconds(24L * 60L * 60L * 90L);
        String partiQlQuery = String.format(
            "select program_id,content_provider,vod_key,country_code,api_error,api_error_datetime from \"%s\".\"api_error-api_error_datetime-index\" where attribute_exists(\"%s\") and api_error_datetime >=? ;",
            cmsVodContentLicenseDynamo, "api_error");
        ExecuteStatementRequest request = ExecuteStatementRequest.builder().statement(partiQlQuery)
            .parameters(
                AttributeValue.builder().s(formatDate((previousUTCDate))).build()).build();
        ExecuteStatementResponse result = this.dynamoDB.executeStatement(request);
        List<Map<String, AttributeValue>> items = result.items();
        return items.stream().map(item -> objectMapper.convertValue(toSimpleMap(item),
            InvalidLicenseWindowVodAsset.class)).toList();
    }

    public List<AssetKeyDto> getProcessingVodFromDynamo(AssetKeyDto vodAssetDto) {
        GetItemRequest getItemRequest = GetItemRequest.builder().tableName(cmsVodContentDynamo).
            key(Map.of(
                "program_id",
                AttributeValue.builder().s(String.valueOf(vodAssetDto.getContentId())).build(),
                "country_provider", AttributeValue.builder().s(
                    vodAssetDto.getCountryCode() + "_" + vodAssetDto.getVcCpId()).build()
            )).build();
        GetItemResponse result = this.dynamoDB.getItem(getItemRequest);
        Map<String, AttributeValue> item = result.item();
        if (item == null || item.isEmpty() || !item.get("current_state").s()
            .equalsIgnoreCase("processing")) {
            return List.of();
        } else {
            return List.of(AssetKeyDto.builder().vcCpId(item.get("content_provider").s())
                .countryCode(item.get("country").s()).contentId(item.get("program_id").s())
                .build());
        }
    }


    public Map<String, Object> toSimpleMap(Map<String, AttributeValue> item) {
        return item.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,
            entry -> {
                AttributeValue value = entry.getValue();
                if (value.bool() != null) {
                    return value.bool();
                }
                if (value.s() != null) {
                    return value.s();
                }
                if (value.n() != null) {
                    return Integer.parseInt(value.n());
                }
                return null;
            }));
    }

    private String formatDate(Instant instant) {
        ZonedDateTime zonedDateTime = instant.atZone(ZoneOffset.UTC);
        DateTimeFormatter toFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd' 'HH:mm:ss' UTC'");
        return zonedDateTime.format(toFormatter);

    }

}
