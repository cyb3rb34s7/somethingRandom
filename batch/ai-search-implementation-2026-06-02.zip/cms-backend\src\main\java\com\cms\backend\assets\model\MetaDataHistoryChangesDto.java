package com.cms.backend.assets.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MetaDataHistoryChangesDto {

    @JsonProperty("field")
    private String key;
    @JsonProperty("oldValue")
    private String oldValue;
    @JsonProperty("newValue")
    private String newValue;

}
