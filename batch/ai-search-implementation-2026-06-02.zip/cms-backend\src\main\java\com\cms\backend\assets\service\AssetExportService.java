package com.cms.backend.assets.service;

import com.cms.backend.assets.configuration.ExportFieldMappingConfig;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.assets.model.PaginationDto;
import com.cms.backend.assets.model.ExportStateContext;
import com.cms.backend.assets.util.AssetExportDataFormatter;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.CommonMethodUtil;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.evaluation.model.ComparisonAssetListResponseDto;
import com.cms.backend.evaluation.model.CountDto;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AssetExportService {

    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;
    private final ThreadPoolTaskExecutor exportTaskExecutor;

    private static final int PARALLEL_CALLS = 2;
    private static final int PAGE_SIZE = 5000;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public AssetExportService(RegionEndpointService regionEndpointService,
            HttpMethodHandler httpMethodHandler,
            @Qualifier("exportTaskExecutor") ThreadPoolTaskExecutor exportTaskExecutor) {
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
        this.exportTaskExecutor = exportTaskExecutor;
    }

    public ExportHelperDto startExport(AssetFilterBodyDto filterBodyDto, boolean isEvaluation) throws IOException {
        String fileNamePrefix = isEvaluation ? "EvaluationAssets_" : "MediaAssets_";

        int totalAssetCount = getTotalAssetCount(filterBodyDto, isEvaluation);
        log.info("Asset Count Received from API: {}", totalAssetCount);

        Instant exportTime = Instant.now();

        byte[] excelData = createExcelFromAssetsSequential(filterBodyDto, totalAssetCount, exportTime, isEvaluation);

        String fileName = fileNamePrefix + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
                + ".xlsx";

        return ExportHelperDto.builder()
                .excelData(excelData)
                .fileName(fileName)
                .fileType("EXCEL")
                .build();
    }

    private byte[] createExcelFromAssetsSequential(AssetFilterBodyDto filterBody, int totalAssetCount,
            Instant exportTime, boolean isEvaluation) throws IOException {
        long startTime = System.currentTimeMillis();
        try (SXSSFWorkbook workbook = new SXSSFWorkbook(1000);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            log.info("Starting Excel creation for {} assets, isEvaluation: {}", totalAssetCount, isEvaluation);
            workbook.setCompressTempFiles(true);

            ExportStateContext context = new ExportStateContext();
            if (filterBody.getColumns() != null && !filterBody.getColumns().isEmpty()) {
                context.setupSelectiveExport(filterBody.getColumns(), isEvaluation);
            } else {
                context.setupFullExport(isEvaluation);
            }

            Sheet sheet = workbook.createSheet(isEvaluation ? "EvaluationAssets" : "MediaAssets");
            sheet.setDefaultRowHeightInPoints(30.0f);

            initializeStyles(workbook, context);
            context.setCurrentExcel(workbook);
            context.setCurrentSheet(sheet);

            int currentRow = 0;
            currentRow = createGroupHeaders(sheet, currentRow, context);
            currentRow = createColumnHeaders(sheet, currentRow, context);
            context.setCurrentRow(currentRow);

            int currentOffset = 0;
            int totalProcessed = 0;

            while (currentOffset < totalAssetCount) {
                log.info("Fetching batch starting at offset: {}/{}", currentOffset, totalAssetCount);
                List<JsonNode> batchAssets = fetchAssetBatch(filterBody, currentOffset, isEvaluation);
                if (batchAssets.isEmpty()) {
                    log.info("Empty batch received, breaking loop");
                    break;
                }

                log.info("Processing batch of {} assets", batchAssets.size());
                for (JsonNode asset : batchAssets) {
                    Map<String, String> rowData = buildRowData(asset, context, exportTime);
                    createExcelRow(sheet, rowData, context.getCurrentRow(), context);
                    context.setCurrentRow(context.getCurrentRow() + 1);
                    totalProcessed++;
                }

                currentOffset += batchAssets.size();
                log.info("Processed {}/{} assets into excel sheet (batch size: {})", currentOffset, totalAssetCount,
                        batchAssets.size());
                log.info("Total unique assets processed so far: {}", totalProcessed);

                // Memory clearance to prevent OOM
                batchAssets.clear();
            }

            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;
            log.info("Completed Excel creation. Total processed assets: {}, Expected: {}, Time taken: {} ms",
                    totalProcessed,
                    totalAssetCount, duration);
            workbook.write(outputStream);
            return outputStream.toByteArray();

        } catch (Exception e) {
            log.error("Error Creating Excel: {}", e.getMessage());
            throw new IOException("Failed to create Excel: ", e);
        }
    }

    private List<JsonNode> fetchAssetBatch(AssetFilterBodyDto filterBody, int startOffset, boolean isEvaluation) {
        try {
            long startTime = System.currentTimeMillis();
            log.info("Starting to fetch asset batch with startOffset: {}, isEvaluation: {}", startOffset, isEvaluation);
            List<CompletableFuture<List<JsonNode>>> batchFutures = new ArrayList<>();
            for (int i = 0; i < PARALLEL_CALLS; i++) {
                final int offset = startOffset + (i * PAGE_SIZE);
                log.info("Creating async task {} with offset: {}", i, offset);
                batchFutures.add(CompletableFuture.supplyAsync(() -> {
                    try {
                        return fetchAssetsFromAPI(filterBody, offset, isEvaluation);
                    } catch (IOException e) {
                        throw new CompletionException(e);
                    }
                }, exportTaskExecutor));
            }

            List<JsonNode> result = new ArrayList<>(batchFutures.stream()
                    .map(CompletableFuture::join)
                    .flatMap(List::stream)
                    .toList());

            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;
            log.info("Completed fetching asset batch. Total assets in batch: {}, Time taken: {} ms", result.size(),
                    duration);
            return result;

        } catch (CompletionException e) {
            log.error("Failed to fetch asset batch: {}", e.getMessage());
            throw new CustomException("Failed to fetch asset batch");
        }
    }

    public List<JsonNode> fetchAssetsFromAPI(AssetFilterBodyDto assetFilterBodyDto, int offset, boolean isEvaluation)
            throws IOException {
        long startTime = System.currentTimeMillis();
        AssetFilterBodyDto apiFilterBody = AssetFilterBodyDto.builder()
                .columns(assetFilterBodyDto.getColumns())
                .filters(assetFilterBodyDto.getFilters())
                .pagination(PaginationDto.builder().limit(PAGE_SIZE).offset(offset).build())
                .build();

        log.info("Fetching assets with limit: {}, offset: {}, isEvaluation: {}", PAGE_SIZE, offset, isEvaluation);

        HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(apiFilterBody);
        String finalUrl = regionEndpointService.getOpenAPIEndpointNLB() +
                (isEvaluation ? Constants.GET_EVALUATION_VIEW : Constants.EXPORT_ASSET_ENDPOINT);

        ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;

        ResponseDto responseBody = Objects.requireNonNull(responseEntity.getBody());

        if (isEvaluation) {
            ComparisonAssetListResponseDto comparisonDto = objectMapper.convertValue(
                    responseBody.getRsp().getPayload().get("evaluation"), ComparisonAssetListResponseDto.class);
            log.info("Received {} evaluation assets from API in {} ms", comparisonDto.getData().size(), duration);
            return comparisonDto.getData();
        } else {
            List<JsonNode> assets = objectMapper.convertValue(
                    responseBody.getRsp().getPayload().get(Constants.ASSETS),
                    new TypeReference<>() {
                    });
            log.info("Received {} media assets from API in {} ms", assets.size(), duration);
            return assets;
        }
    }

    private Map<String, String> buildRowData(JsonNode asset, ExportStateContext context, Instant exportTime) {
        Map<String, String> rowData = new HashMap<>();

        for (String fieldName : context.getFieldsToProcess()) {
            ExportFieldMappingConfig.FieldMetadata metadata = context.isEvaluation()
                    ? ExportFieldMappingConfig.EVALUATION_FIELD_CONFIG.get(fieldName)
                    : ExportFieldMappingConfig.FIELD_CONFIG.get(fieldName);

            if (metadata != null) {
                if (metadata.type == ExportFieldMappingConfig.FieldType.COMPUTED) {
                    rowData.put(fieldName, AssetExportDataFormatter.extractComputedValue(asset, fieldName, exportTime));
                } else {
                    rowData.put(fieldName, getSimpleValue(asset, fieldName));
                }
            } else {
                rowData.put(fieldName, "");
            }
        }
        return rowData;
    }

    private String getSimpleValue(JsonNode asset, String fieldName) {
        JsonNode value = asset.get(fieldName);
        if (value == null || value.isNull())
            return "";

        String stringValue = value.asText();
        if (isDateField(fieldName) && stringValue.contains("T")) {
            return CommonMethodUtil.formatDateField(stringValue);
        }
        return stringValue;
    }

    private void createExcelRow(Sheet sheet, Map<String, String> rowData, int rowIndex, ExportStateContext context) {
        Row row = sheet.createRow(rowIndex);
        String[] fields = context.getFieldsToProcess();

        for (int i = 0; i < fields.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellStyle(context.getDataStyle());
            String value = rowData.get(fields[i]);
            cell.setCellValue(value != null ? value : "");
        }
    }

    private int createGroupHeaders(Sheet sheet, int rowIndex, ExportStateContext context) {
        if (context.isSelectiveExport())
            return rowIndex;

        Row row = sheet.createRow(rowIndex);
        String[] groups = ExportFieldMappingConfig.getGroupsInOrder(context.isEvaluation());
        String[] fields = context.getFieldsToProcess();

        int colIndex = 0;
        for (String group : groups) {
            int groupStartCol = colIndex;
            int groupColCount = ExportFieldMappingConfig.countColumnsInGroup(fields, group, context.isEvaluation());

            if (groupColCount > 0) {
                Cell cell = row.createCell(groupStartCol);
                cell.setCellValue(group);
                cell.setCellStyle(context.getGroupStyles().get(group));

                if (groupColCount > 1) {
                    sheet.addMergedRegion(
                            new CellRangeAddress(rowIndex, rowIndex, groupStartCol, groupStartCol + groupColCount - 1));
                }
                colIndex += groupColCount;
            }
        }
        return rowIndex + 1;
    }

    private int createColumnHeaders(Sheet sheet, int rowIndex, ExportStateContext context) {
        Row row = sheet.createRow(rowIndex);
        String[] fields = context.getFieldsToProcess();

        for (int i = 0; i < fields.length; i++) {
            Cell cell = row.createCell(i);
            ExportFieldMappingConfig.FieldMetadata metadata = context.isEvaluation()
                    ? ExportFieldMappingConfig.EVALUATION_FIELD_CONFIG.get(fields[i])
                    : ExportFieldMappingConfig.FIELD_CONFIG.get(fields[i]);

            cell.setCellValue(metadata != null ? metadata.columnName : fields[i]);
            cell.setCellStyle(context.getColumnHeaderStyle());
        }
        return rowIndex + 1;
    }

    private void initializeStyles(Workbook workbook, ExportStateContext context) {
        context.setGroupStyles(createGroupHeaderStyle(workbook, context.isEvaluation()));
        context.setDataStyle(createDataStyle(workbook));
        context.setColumnHeaderStyle(createColumnHeaderStyle(workbook));
        context.setBottomBorderStyle(createBottomBorderStyle(workbook));
    }

    public Map<String, CellStyle> createGroupHeaderStyle(Workbook workbook, boolean isEvaluation) {
        Map<String, CellStyle> groupStyles = new HashMap<>();
        for (String group : ExportFieldMappingConfig.getGroupsInOrder(isEvaluation)) {
            CellStyle style = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            font.setFontHeightInPoints((short) 12);
            style.setFont(font);
            IndexedColors color = ExportFieldMappingConfig.GROUP_COLORS.getOrDefault(group, IndexedColors.LIGHT_BLUE);
            style.setFillForegroundColor(color.getIndex());
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setAlignment(HorizontalAlignment.CENTER);
            style.setVerticalAlignment(VerticalAlignment.CENTER);
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            groupStyles.put(group, style);
        }
        return groupStyles;
    }

    public CellStyle createColumnHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 10);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    public CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    public CellStyle createBottomBorderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THICK);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    public int getTotalAssetCount(AssetFilterBodyDto assetFilterBodyDto, boolean isEvaluation) throws IOException {
        HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(assetFilterBodyDto);
        String finalUrl = regionEndpointService.getOpenAPIEndpointNLB() +
                (isEvaluation ? Constants.GET_EVALUATION_COUNT : Constants.EXPORT_ASSET_COUNT_ENDPOINT);

        ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);
        ResponseDto responseBody = Objects.requireNonNull(responseEntity.getBody());

        if (isEvaluation) {
            CountDto countDto = objectMapper.convertValue(
                    responseBody.getRsp().getPayload().get("evaluation"), CountDto.class);
            return countDto.getTotalCount();
        } else {
            return objectMapper.convertValue(
                    responseBody.getRsp().getPayload().get("assetCount"), Integer.class);
        }
    }

    private boolean isDateField(String fieldName) {
        return fieldName.equals("releaseDate") ||
                fieldName.equals("expiryDate") ||
                fieldName.equals("regDate") ||
                fieldName.equals("updateDate") ||
                fieldName.equals("availableStarting") ||
                fieldName.equals("availableEnding") ||
                fieldName.equals("eventStarting") ||
                fieldName.equals("eventEnding");
    }

}
