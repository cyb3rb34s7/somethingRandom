package com.cms.backend.common.model;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SecurityUserTest {

    private SecurityUser securityUser;
    private Map<String, String> allUsers;

    @BeforeEach
    void setUp() {
        allUsers = new HashMap<>();
        allUsers.put("user1", "role1");
        securityUser = new SecurityUser("testUser",
            "US", "testUuid", "testSessionId", allUsers);
    }

    @Test
    void testDefaultConstructor() {
        // Act
        SecurityUser defaultUser = new SecurityUser();

        // Assert
        assertNotNull(defaultUser);
        assertEquals("testUser", defaultUser.getUsername());
    }

    @Test
    void testParameterizedConstructor() {
        // Assert
        assertEquals("testUser", securityUser.getUsername());
        assertEquals("US", securityUser.getServiceRegion());
        assertEquals("testUuid", securityUser.getUuid());
        assertEquals("testSessionId", securityUser.getSessionId());
        assertEquals(allUsers, securityUser.getAllUsers());
    }

    @Test
    void testGettersAndSetters() {
        // Arrange
        Map<String, String> newAllUsers = new HashMap<>();
        newAllUsers.put("user2", "role2");

        // Act
        securityUser.setServiceRegion("EU");
        securityUser.setUserId("newUserId");
        securityUser.setUuid("newUuid");
        securityUser.setSessionId("newSessionId");
        securityUser.setAllUsers(newAllUsers);

        // Assert
        assertEquals("EU", securityUser.getServiceRegion());
        assertEquals("newUserId", securityUser.getUserId());
        assertEquals("newUuid", securityUser.getUuid());
        assertEquals("newSessionId", securityUser.getSessionId());
        assertEquals(newAllUsers, securityUser.getAllUsers());
    }

    @Test
    void testEqualsWithSameObject() {
        // Act & Assert
        assertTrue(securityUser.equals(securityUser));
    }

    @Test
    void testEqualsWithNull() {
        // Act & Assert
        assertFalse(securityUser.equals(null));
    }

    @Test
    void testEqualsWithDifferentClass() {
        // Act & Assert
        assertFalse(securityUser.equals("string"));
    }

    @Test
    void testEqualsWithDifferentSecurityUser() {
        // Arrange
        Map<String, String> differentAllUsers = new HashMap<>();
        differentAllUsers.put("user3", "role3");
        SecurityUser differentUser = new SecurityUser("differentUser",
            "EU", "differentUuid", "differentSessionId", differentAllUsers);

        // Act & Assert
        assertFalse(securityUser.equals(differentUser));
    }

    @Test
    void testEqualsWithSameSecurityUser() {
        // Arrange
        SecurityUser sameUser = new SecurityUser("testUser",
            "US", "testUuid", "testSessionId", allUsers);

        // Act & Assert
        assertTrue(securityUser.equals(sameUser));
    }

    @Test
    void testHashCode() {
        // Arrange
        SecurityUser sameUser = new SecurityUser("testUser",
            "US", "testUuid", "testSessionId", allUsers);

        // Act
        int hashCode1 = securityUser.hashCode();
        int hashCode2 = sameUser.hashCode();

        // Assert
        assertEquals(hashCode1, hashCode2);
    }

    @Test
    void testHashCodeWithDifferentValues() {
        // Arrange
        Map<String, String> differentAllUsers = new HashMap<>();
        differentAllUsers.put("user3", "role3");
        SecurityUser differentUser = new SecurityUser("differentUser",
            "EU", "differentUuid", "differentSessionId", differentAllUsers);

        // Act
        int hashCode1 = securityUser.hashCode();
        int hashCode2 = differentUser.hashCode();

        // Assert
        assertNotEquals(hashCode1, hashCode2);
    }
}