package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetNotEditableFieldMapTest {

    @Test
    void testGetNotEditableFields() {
        Map<String, List<String>> expectedNotEditableFields = new HashMap<>();
        expectedNotEditableFields.put("MOVIE", List.of(
            AssetNotEditableFieldsMap.RUNNING_TIME,
            AssetNotEditableFieldsMap.CHAPTER_TIME,
            AssetNotEditableFieldsMap.CHAPTER_DESCRIPTION,
            AssetNotEditableFieldsMap.STREAM_URI,
            AssetNotEditableFieldsMap.QUALITY,
            AssetNotEditableFieldsMap.AUDIO_LANG,
            AssetNotEditableFieldsMap.SUBTITLE_LANG,
            AssetNotEditableFieldsMap.DRM,
            AssetNotEditableFieldsMap.AD_TAG,
            AssetNotEditableFieldsMap.SEASON_ID,
            AssetNotEditableFieldsMap.SEASON_NO,
            AssetNotEditableFieldsMap.SHOW_ID,
            AssetNotEditableFieldsMap.SCENE_PREVIEW_URL,
            AssetNotEditableFieldsMap.DRM_DATA, AssetNotEditableFieldsMap.SHOW_TITLE,
            AssetNotEditableFieldsMap.SEASON_TITLE));
        Map<String, List<String>> actualNotEditableFields = AssetNotEditableFieldsMap.getNotEditableFields();
        assertEquals(expectedNotEditableFields.get("MOVIE"), actualNotEditableFields.get("MOVIE"));

        // Additional tests for other types
        assertEquals(expectedNotEditableFields.get("MOVIE"), actualNotEditableFields.get("MUSIC"));
        assertEquals(expectedNotEditableFields.get("MOVIE"), actualNotEditableFields.get("SEASON"));
        assertEquals(expectedNotEditableFields.get("MOVIE"), actualNotEditableFields.get("SHOW"));
        assertEquals(expectedNotEditableFields.get("MOVIE"),
            actualNotEditableFields.get("EPISODE"));
        assertEquals(expectedNotEditableFields.get("MOVIE"),
            actualNotEditableFields.get("SINGLEVOD"));
    }
}
