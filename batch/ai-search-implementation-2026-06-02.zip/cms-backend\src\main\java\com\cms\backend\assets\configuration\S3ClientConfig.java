package com.cms.backend.assets.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

@Configuration
@Slf4j
public class S3ClientConfig {

    @Value("${REGION}")
    public String region;

    @Bean
    public S3Client amazonS3() {
        S3Client s3Client = S3Client.builder().region(Region.of(region))
            .credentialsProvider(
                DefaultCredentialsProvider.builder().build()).build();
        log.info("AmazonS3 created");
        return s3Client;
    }

}
