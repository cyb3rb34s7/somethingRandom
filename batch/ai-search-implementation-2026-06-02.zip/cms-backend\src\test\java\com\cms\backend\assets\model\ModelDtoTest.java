package com.cms.backend.assets.model;


import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;

class ModelDtoTest {


    @Test
    void testOtherDto() {
        ModelDtoTestUtility.testModelOrDto(AdBreaksDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetByColumnsReqDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetChangeHistoryDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetDrmDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetEpisodeHierarchyDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetExternalIdDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetFilterBodyDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetHistoryChangesDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetKeyDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetListKeyDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetRequestBodyDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetUpdateByBulkDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetViewFilterDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetDetailsByColumnReqDto.class);
        ModelDtoTestUtility.testModelOrDto(EditValidationDto.class);


    }

    @Test
    void testRemainingDto() {
        ModelDtoTestUtility.testModelOrDto(ExternalProviderDto.class);
        ModelDtoTestUtility.testModelOrDto(FilterDto.class);
        ModelDtoTestUtility.testModelOrDto(ImagePreProcessDto.class);
        ModelDtoTestUtility.testModelOrDto(ImageProcessDetails.class);
        ModelDtoTestUtility.testModelOrDto(ImageProcessedDto.class);
        ModelDtoTestUtility.testModelOrDto(LanguageDto.class);
        ModelDtoTestUtility.testModelOrDto(MetaDataHistoryChangesDto.class);
        ModelDtoTestUtility.testModelOrDto(PaginationDto.class);
        ModelDtoTestUtility.testModelOrDto(PlatformTagData.class);
        ModelDtoTestUtility.testModelOrDto(RatingsDto.class);
        ModelDtoTestUtility.testModelOrDto(SortDto.class);
        ModelDtoTestUtility.testModelOrDto(SqsMessageDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusGetDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusUpdateDto.class);
        ModelDtoTestUtility.testModelOrDto(VodAssetDto.class);
        ModelDtoTestUtility.testModelOrDto(VodAssetDto.class);
    }
}
