package com.cms.backend.assets.model;


import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssetViewFilterDto {

    private List<PlatformTagData> platforms;
    private List<LanguageDto> languages;
    private List<String> parentalRatings;

}

