package com.cms.backend.common.test;

import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for common testing operations to reduce code duplication.
 */
public class TestUtility {
    
    /**
     * Creates a mock list with the specified size
     * 
     * @param size The size of the list
     * @return A mock list
     */
    public static <T> List<T> createMockList(int size) {
        List<T> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add(Mockito.mock((Class<T>) Object.class));
        }
        return list;
    }
    
    /**
     * Creates an empty mock list
     * 
     * @return An empty mock list
     */
    public static <T> List<T> createEmptyMockList() {
        return new ArrayList<>();
    }
    
    /**
     * Asserts that two objects have the same field values
     * 
     * @param expected The expected object
     * @param actual The actual object
     * @param fieldNames The field names to compare
     */
    public static void assertDtoFields(Object expected, Object actual, String... fieldNames) {
        // This is a simplified implementation
        // In a real implementation, this would use reflection to compare field values
        if (expected == null && actual == null) {
            return;
        }
        
        if (expected == null || actual == null) {
            throw new AssertionError("One object is null while the other is not");
        }
        
        // In a real implementation, we would compare the specified fields using reflection
        // For now, we'll just check that both objects are not null
        if (!expected.getClass().equals(actual.getClass())) {
            throw new AssertionError("Objects are of different classes");
        }
    }
    
    /**
     * Creates a test string with a prefix
     * 
     * @param prefix The prefix for the test string
     * @return A test string
     */
    public static String createTestString(String prefix) {
        return prefix + "_TEST";
    }
    
    /**
     * Creates a test integer
     * 
     * @param value The base value
     * @return A test integer
     */
    public static Integer createTestInteger(int value) {
        return value;
    }
    
    /**
     * Creates a standard response entity for testing
     * 
     * @return A standard ResponseEntity with a ResponseDto
     */
    public static ResponseEntity<ResponseDto> createStandardResponseEntity() {
        return ResponseEntity.ok(ResponseDto.builder().rsp(new BaseResponseDto()).build());
    }
    
    /**
     * Creates sample image data for testing
     * 
     * @return A byte array with sample image data
     */
    public static byte[] createSampleImageData() {
        return new byte[]{0x42, 0x4D, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00,
            0x00, 0x00, 0x01, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00};
    }
    
    /**
     * Creates a test MultipartFile for testing
     * 
     * @return A MultipartFile for testing
     */
    public static MultipartFile createTestMultipartFile() {
        return new MockMultipartFile("image", "test.jpg", "image/jpeg", createSampleImageData());
    }
}
