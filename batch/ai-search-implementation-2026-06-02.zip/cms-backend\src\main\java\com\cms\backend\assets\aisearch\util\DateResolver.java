package com.cms.backend.assets.aisearch.util;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DateResolver {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Clock clock;

    public String resolveToken(String token) {
        if (token == null || token.isBlank()) {
            return "";
        }
        LocalDateTime now = LocalDateTime.now(clock);
        return switch (token.toUpperCase()) {
            case "TODAY" -> now.format(FMT);
            case "YESTERDAY" -> now.minusDays(1).format(FMT);
            case "LAST_7_DAYS" -> now.minusDays(7).format(FMT);
            case "LAST_30_DAYS" -> now.minusDays(30).format(FMT);
            case "THIS_MONTH" -> now.withDayOfMonth(1).format(FMT);
            case "LAST_MONTH" -> now.withDayOfMonth(1).minusMonths(1).format(FMT);
            case "THIS_YEAR" -> now.withDayOfYear(1).format(FMT);
            default -> token; // already a real date string
        };
    }

    public List<String> resolveRange(List<String> values) {
        List<String> out = new ArrayList<>();
        if (values == null || values.isEmpty()) {
            return List.of("", "");
        }
        for (int i = 0; i < Math.min(2, values.size()); i++) {
            out.add(resolveToken(values.get(i)));
        }
        while (out.size() < 2) {
            out.add("");
        }
        return out;
    }
}
