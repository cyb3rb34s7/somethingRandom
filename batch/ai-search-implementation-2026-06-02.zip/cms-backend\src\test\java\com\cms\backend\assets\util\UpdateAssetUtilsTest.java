package com.cms.backend.assets.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.cms.backend.assets.mapper.AssetMapper;
import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.test.AssetTestDataProvider;
import com.cms.backend.common.util.HttpMethodHandler;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

class UpdateAssetUtilsTest {

    @InjectMocks
    UpdateAssetUtils updateAssetUtils;

    @Mock
    private AssetMapper assetMapper;

    @Mock
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private RegionEndpointService regionEndpointService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testUpdateDeleteAssetNormalValue() {
        VodAssetDto vodAssetDto1 = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setRatings("ratings");

        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setRatings("ratings");

        BaseResponseDto baseResponseDto = BaseResponseDto.builder().build();
        ResponseDto responseDto = ResponseDto.builder().rsp(baseResponseDto).build();
        responseDto.getRsp().setStat(Constants.STATUS_OK);

        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);

        responseDto.getRsp().setStat(Constants.STATUS_OK);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok().build();
        Mockito.doReturn(responseEntity).when(httpMethodHandler)
            .handleHttpExchange(Mockito.anyString(), Mockito.anyString(), Mockito.any(
                HttpEntity.class), Mockito.any());
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);

        updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1);
        verify(assetMapper, times(1)).deleteEditAsset(Mockito.any());
    }

    @Test
    void testUpdateDeleteAssetUpdateFailTest() {
        VodAssetDto vodAssetDto1 = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setExpiryDate("expiryDATE");
        vodAssetDto1.setAvailableStarting("testStartDate");

        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setExpiryDate("expiryDATE");
        vodAssetDto.setAvailableStarting("testStartDate");

        BaseResponseDto baseResponseDto = BaseResponseDto.builder().build();
        ResponseDto responseDto = ResponseDto.builder().rsp(baseResponseDto).build();
        responseDto.getRsp().setStat(Constants.STATUS_OK);

        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);

        responseDto.getRsp().setStat(Constants.STATUS_OK);
        Mockito.doThrow(new AssetApiFailureException("")).when(httpMethodHandler)
            .handleHttpExchange(Mockito.anyString(), Mockito.anyString(), Mockito.any(
                HttpEntity.class), Mockito.any());
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertThrows(AssetApiFailureException.class,
            () -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void testUpdateDeleteAssetUpdateFailTestNoResponseDto() {
        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setExpiryDate("expiryDATE");
        vodAssetDto.setAvailableStarting("testStartDate");

        VodAssetDto vodAssetDto1 = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setExpiryDate("expiryDATE");
        vodAssetDto1.setAvailableStarting("testStartDate");

        ResponseDto responseDto = null;
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(
            httpMethodHandler).handleHttpExchange(anyString(), anyString(),
            Mockito.any(HttpEntity.class),
            any());
        Assertions.assertDoesNotThrow(
            () -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto));
    }

    @Test
    void testUpdateDeleteAssetUpdateFailTestNoResponseDtoRsp() {
        VodAssetDto vodAssetDto1 = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setExpiryDate("expiryDATE");
        vodAssetDto1.setAvailableStarting("testStartDate");

        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setExpiryDate("expiryDATE");
        vodAssetDto.setAvailableStarting("testStartDate");

        ResponseDto responseDto = ResponseDto.builder().rsp(null).build();
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(),
                Mockito.any(HttpEntity.class),
                any());
        Assertions.assertDoesNotThrow(() -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void testUpdateDeleteAssetUpdateFailTestResponseDtoStatOk() {
        VodAssetDto vodAssetDto1 = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setExpiryDate("expiryDATE");
        vodAssetDto1.setAvailableStarting("testStartDate");

        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setExpiryDate("expiryDATE");
        vodAssetDto.setAvailableStarting("testStartDate");

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(
            httpMethodHandler).handleHttpExchange(anyString(), anyString(),
            Mockito.any(HttpEntity.class),
            any());
        Assertions.assertDoesNotThrow(
            () -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void testUpdateDeleteAssetUpdateFailTestResponseDtoStatNotOk() {
        VodAssetDto vodAssetEditDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetEditDto.setType(Constants.MUSIC);
        vodAssetEditDto.setMainTitle("mainTitle");
        vodAssetEditDto.setReleaseDate("releaseDate");
        vodAssetEditDto.setDescription("description");
        vodAssetEditDto.setStarring("starring");
        vodAssetEditDto.setGenres("genres");
        vodAssetEditDto.setExpiryDate("expiryDATE");
        vodAssetEditDto.setAvailableStarting("testStartDate");

        VodAssetDto vodAssetDto = AssetTestDataProvider.createStandardVodAssetDto();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setMainTitle("mainTitle");
        vodAssetDto.setReleaseDate("releaseDate");
        vodAssetDto.setDescription("description");
        vodAssetDto.setStarring("starring");
        vodAssetDto.setGenres("genres");
        vodAssetDto.setExpiryDate("expiryDATE");
        vodAssetDto.setAvailableStarting("testStartDate");

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_FAIL).build()).build();
        doNothing().when(assetMapper).deleteEditAsset(vodAssetEditDto);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(
            httpMethodHandler).handleHttpExchange(anyString(), anyString(),
            Mockito.any(HttpEntity.class),
            any());
        Assertions.assertThrows(AssetApiFailureException.class,
            () -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetEditDto));
    }


    @Test
    void testUpdateDeleteAssetWithNullRatings() {
        VodAssetDto vodAssetDto1 = new VodAssetDto();
        vodAssetDto1.setContentId("contentId");
        vodAssetDto1.setCountryCode("countryCode");
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setVcCpId("vcCpId");
        vodAssetDto1.setRatings(null); // Null ratings
        vodAssetDto1.setExpiryDate("2023-12-31 23:59:59");
        vodAssetDto1.setAvailableStarting("2023-01-01 00:00:00");

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(httpMethodHandler)
            .handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(HttpEntity.class), Mockito.any());
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertDoesNotThrow(() -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void testUpdateDeleteAssetWithMusicType() {
        VodAssetDto vodAssetDto1 = new VodAssetDto();
        vodAssetDto1.setContentId("contentId");
        vodAssetDto1.setCountryCode("countryCode");
        vodAssetDto1.setType(Constants.MUSIC);
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setVcCpId("vcCpId");
        vodAssetDto1.setArtist("testArtist");
        vodAssetDto1.setExpiryDate("2023-12-31 23:59:59");
        vodAssetDto1.setAvailableStarting("2023-01-01 00:00:00");

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(httpMethodHandler)
            .handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(HttpEntity.class), Mockito.any());
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertDoesNotThrow(() -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void testUpdateDeleteAssetWithNonMusicType() {
        VodAssetDto vodAssetDto1 = new VodAssetDto();
        vodAssetDto1.setContentId("contentId");
        vodAssetDto1.setCountryCode("countryCode");
        vodAssetDto1.setType("MOVIE");
        vodAssetDto1.setMainTitle("mainTitle");
        vodAssetDto1.setReleaseDate("releaseDate");
        vodAssetDto1.setDescription("description");
        vodAssetDto1.setStarring("starring");
        vodAssetDto1.setGenres("genres");
        vodAssetDto1.setVcCpId("vcCpId");
        vodAssetDto1.setArtist("testArtist");
        vodAssetDto1.setExpiryDate("2023-12-31 23:59:59");
        vodAssetDto1.setAvailableStarting("2023-01-01 00:00:00");

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);
        Mockito.doReturn(responseEntity).when(httpMethodHandler)
            .handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(HttpEntity.class), Mockito.any());
        doNothing().when(assetMapper).deleteEditAsset(vodAssetDto1);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertDoesNotThrow(() -> updateAssetUtilsSpy.updateDeleteAsset(vodAssetDto1));
    }

    @Test
    void insertRecordsInUploadtableTestOk() {
        List<VodAssetDto> records = new ArrayList<>();
        records.add(VodAssetDto.builder().build());
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Mockito.doNothing().when(assetMapper).insert(Mockito.any());
        Assertions.assertDoesNotThrow(
            () -> updateAssetUtilsSpy.insertRecordsInUploadtable(records));
    }

    @Test
    void insertRecordsInUploadtableTestEmptyList() {
        List<VodAssetDto> records = new ArrayList<>();
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertDoesNotThrow(
            () -> updateAssetUtilsSpy.insertRecordsInUploadtable(records));
        verify(assetMapper, times(0)).insert(Mockito.any());
    }

    @Test
    void insertRecordsInUploadtableTestMultipleRecords() {
        List<VodAssetDto> records = new ArrayList<>();
        records.add(VodAssetDto.builder().contentId("1").build());
        records.add(VodAssetDto.builder().contentId("2").build());
        records.add(VodAssetDto.builder().contentId("3").build());
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Mockito.doNothing().when(assetMapper).insert(Mockito.any());
        Assertions.assertDoesNotThrow(
            () -> updateAssetUtilsSpy.insertRecordsInUploadtable(records));
        verify(assetMapper, times(3)).insert(Mockito.any());
    }

    @Test
    void testFindUpdateSlotWithEmptyList() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        Assertions.assertThrows(IndexOutOfBoundsException.class,
            () -> updateAssetUtilsSpy.findUpdateSlot(windows));
    }

    @Test
    void testFindUpdateSlotWithSingleWindowCurrentTimeInWindow() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventEnding(Instant.now().plusSeconds(3600).toString()) // 1 hour from now
            .eventId("1")
            .build();
        windows.add(window);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window, result);
    }

    @Test
    void testFindUpdateSlotWithSingleWindowCurrentTimeBeforeWindow() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().plusSeconds(3600).toString()) // 1 hour from now
            .eventEnding(Instant.now().plusSeconds(7200).toString()) // 2 hours from now
            .eventId("1")
            .build();
        windows.add(window);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window, result);
    }

    @Test
    void testFindUpdateSlotWithSingleWindowCurrentTimeAfterWindow() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(7200).toString()) // 2 hours ago
            .eventEnding(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventId("1")
            .build();
        windows.add(window);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window, result);
    }

    @Test
    void testFindUpdateSlotWithMultipleWindows() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window1 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(7200).toString()) // 2 hours ago
            .eventEnding(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventId("1")
            .build();
        AssetEventWindowDto window2 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().plusSeconds(3600).toString()) // 1 hour from now
            .eventEnding(Instant.now().plusSeconds(7200).toString()) // 2 hours from now
            .eventId("2")
            .build();
        AssetEventWindowDto window3 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().plusSeconds(10800).toString()) // 3 hours from now
            .eventEnding(Instant.now().plusSeconds(14400).toString()) // 4 hours from now
            .eventId("3")
            .build();
        windows.add(window1);
        windows.add(window2);
        windows.add(window3);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window2, result); // Should return the next upcoming window
    }

    @Test
    void testFindUpdateSlotWithCurrentTimeInMiddleWindow() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window1 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(7200).toString()) // 2 hours ago
            .eventEnding(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventId("1")
            .build();
        AssetEventWindowDto window2 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(1800).toString()) // 30 minutes ago
            .eventEnding(Instant.now().plusSeconds(1800).toString()) // 30 minutes from now
            .eventId("2")
            .build();
        AssetEventWindowDto window3 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().plusSeconds(3600).toString()) // 1 hour from now
            .eventEnding(Instant.now().plusSeconds(7200).toString()) // 2 hours from now
            .eventId("3")
            .build();
        windows.add(window1);
        windows.add(window2);
        windows.add(window3);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window2, result); // Should return the current window
    }

    @Test
    void testFindUpdateSlotWithNullEventEnding() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventEnding(null) // No ending time
            .eventId("1")
            .build();
        windows.add(window);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window, result);
    }

    @Test
    void testFindUpdateSlotWithMultipleWindowsAndNullEventEnding() {
        List<AssetEventWindowDto> windows = new ArrayList<>();
        AssetEventWindowDto window1 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().minusSeconds(7200).toString()) // 2 hours ago
            .eventEnding(Instant.now().minusSeconds(3600).toString()) // 1 hour ago
            .eventId("1")
            .build();
        AssetEventWindowDto window2 = AssetEventWindowDto.builder()
            .eventStarting(Instant.now().plusSeconds(3600).toString()) // 1 hour from now
            .eventEnding(null) // No ending time
            .eventId("2")
            .build();
        windows.add(window1);
        windows.add(window2);
        UpdateAssetUtils updateAssetUtilsSpy = new UpdateAssetUtils(assetMapper,
            httpMethodHandler, regionEndpointService);
        AssetEventWindowDto result = updateAssetUtilsSpy.findUpdateSlot(windows);
        Assertions.assertEquals(window2,
            result); // Should return the window with no ending (ongoing)
    }
}
