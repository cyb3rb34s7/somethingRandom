package com.cms.backend.assets.aisearch.model.llm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmPayload {

    private List<String> columns = new ArrayList<>();
    private List<LlmFilter> filters = new ArrayList<>();
    private LlmPagination pagination = new LlmPagination();
}
