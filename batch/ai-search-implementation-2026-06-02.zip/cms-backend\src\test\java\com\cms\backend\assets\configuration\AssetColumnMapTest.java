package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetColumnMapTest {

    @Test
    void testInitializeGenresMapping() {
        Map<String, String> expectedMap = new LinkedHashMap<>();
        expectedMap.put("contentId", "Content Id");
        expectedMap.put("assetId", "Asset Id");
        expectedMap.put("countryCode", "Country Code");
        expectedMap.put("vcCpId", "VC CP Id");
        expectedMap.put("type", "Type");
        expectedMap.put("mainTitle", "Main Title");
        expectedMap.put("description", "Description");
        expectedMap.put("showId", "Show Id");
        expectedMap.put("seasonId", "Season Id");
        expectedMap.put("seasonNo", "Season No.");
        expectedMap.put("episodeNo", "Episode No.");
        expectedMap.put("subTitle", "Subtitle");
        expectedMap.put("subtitleLang", "Subtitle Language");
        expectedMap.put("subtitleCode", "Subtitle Code");
        expectedMap.put("audioLang", "Audio Language");
        expectedMap.put("audioCode", "Audio Code");
        expectedMap.put("runningTime", "Running Time");
        expectedMap.put("genres", "Genres");
        expectedMap.put("director", "Director");
        expectedMap.put("starring", "Starring");
        expectedMap.put("ratings", "Ratings");
        expectedMap.put("streamUri", "Stream Uri");
        expectedMap.put("availableStarting", "Available Starting");
        expectedMap.put("expiryDate", "Expiry Date");
        expectedMap.put("releaseDate", "Release Date");
        expectedMap.put("webVttUrl", "Web Vtt Url");
        expectedMap.put("thumbnailUrl", "Thumbnail URL");
        expectedMap.put("deeplinkPayload", "Deep Link Payload");
        expectedMap.put("quality", "Quality");
        expectedMap.put("vcSvcId", "Vc Svc Id");
        expectedMap.put("deeplinkId", "Deep Link Id");
        expectedMap.put("dataplusYn", "DataPlus Yn");
        expectedMap.put("nonAdStreamUri", "Non Ad Stream Uri");
        expectedMap.put("imageLandscapeOriginal", "Image Landscape");
        expectedMap.put("imagePortraitOriginal", "Image Portrait");
        expectedMap.put("imageCircleOriginal", "Image Circle");
        expectedMap.put("artist", "Artist");
        expectedMap.put("status", "Status");
        expectedMap.put("chapterDescription", "Chapter Description");
        expectedMap.put("contentTier", "Content Tier");
        expectedMap.put("chapterTime", "Chapter Time");
        expectedMap.put("adBreak", "Ad Break");

        Map<String, String> actualMap = AssetColumnMap.getColumnMap();

        assertEquals(expectedMap, actualMap);
    }
}
