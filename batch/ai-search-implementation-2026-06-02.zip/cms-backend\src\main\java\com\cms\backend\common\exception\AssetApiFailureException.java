package com.cms.backend.common.exception;

public class AssetApiFailureException extends RuntimeException {

    public AssetApiFailureException(String message) {
        super(message);
    }
}
