package com.cms.backend.assets.aisearch.exception;

import static org.assertj.core.api.Assertions.assertThat;

import com.cms.backend.common.exception_handler.GlobalExceptionHandler;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.NotificationUtil;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Directly exercises the two AI-search exception handlers added to {@link GlobalExceptionHandler}
 * to assert the standard fail-envelope they emit. Also covers the exception constructors.
 */
class AiSearchExceptionHandlerTest {

    private final GlobalExceptionHandler handler =
            new GlobalExceptionHandler(Mockito.mock(NotificationUtil.class));

    @Test
    void llmGatewayExceptionMapsToServiceUnavailableEnvelope() {
        ResponseDto dto = handler.handleLlmGatewayException(
                new LlmGatewayException("gateway down"));

        assertThat(dto.getRsp().getStat()).isEqualTo("fail");
        assertThat(dto.getRsp().getErr().getMsg())
                .isEqualTo("AI service is temporarily unavailable. Please try again.");
        assertThat(dto.getRsp().getErr().getCode()).isNotBlank();
    }

    @Test
    void schemaUnavailableExceptionMapsToInternalErrorEnvelope() {
        ResponseDto dto = handler.handleSchemaUnavailableException(
                new SchemaUnavailableException("no schema", new RuntimeException("io")));

        assertThat(dto.getRsp().getStat()).isEqualTo("fail");
        assertThat(dto.getRsp().getErr().getMsg()).isEqualTo("AI search is not available right now.");
        assertThat(dto.getRsp().getErr().getCode()).isNotBlank();
    }

    @Test
    void llmGatewayExceptionCarriesMessageAndCause() {
        RuntimeException cause = new RuntimeException("root");
        LlmGatewayException withCause = new LlmGatewayException("wrapped", cause);
        assertThat(withCause.getMessage()).isEqualTo("wrapped");
        assertThat(withCause.getCause()).isSameAs(cause);

        LlmGatewayException msgOnly = new LlmGatewayException("only");
        assertThat(msgOnly.getMessage()).isEqualTo("only");
        assertThat(msgOnly.getCause()).isNull();
    }
}
