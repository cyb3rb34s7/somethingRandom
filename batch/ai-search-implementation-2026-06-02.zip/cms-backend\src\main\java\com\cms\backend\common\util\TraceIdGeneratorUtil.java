package com.cms.backend.common.util;

import java.security.SecureRandom;

public class TraceIdGeneratorUtil {

    private static final String CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    private TraceIdGeneratorUtil() {
    }

    public static String generate() {
        String timestampPart = encodeTimestamp(System.currentTimeMillis() / 1000, 5);
        String randomPart = generateRandomString(5);
        return timestampPart + randomPart;
    }

    private static String encodeTimestamp(long timestamp, int length) {
        StringBuilder result = new StringBuilder();
        long value = timestamp;

        for (int i = 0; i < length; i++) {
            result.insert(0, CHARSET.charAt((int) (value % CHARSET.length())));
            value /= CHARSET.length();
        }

        return result.toString();
    }

    private static String generateRandomString(int length) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < length; i++) {
            result.append(CHARSET.charAt(RANDOM.nextInt(CHARSET.length())));
        }
        return result.toString();
    }


}