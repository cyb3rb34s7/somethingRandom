package com.cms.backend.evaluation.service;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.evaluation.model.FilterRequestDto;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

public interface ComparisonService {
    ResponseDto getProgramList(FilterRequestDto filterRequestDto);
    ResponseDto getFilterList();
    ResponseDto getDetail(String contentId, String cpId);
    ResponseDto getCount(FilterRequestDto filterRequestDto);
    ResponseEntity<byte[]> startExport(AssetFilterBodyDto assetFilterBodyDto) throws IOException;
}
