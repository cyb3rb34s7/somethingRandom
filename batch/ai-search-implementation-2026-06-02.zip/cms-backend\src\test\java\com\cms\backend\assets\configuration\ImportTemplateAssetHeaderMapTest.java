package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ImportTemplateAssetHeaderMapTest {

    @Test
    void testGetMap() {
        Map<String, String> expectedMap = new LinkedHashMap<>();
        expectedMap.put("programid", "Program ID");
        expectedMap.put("assetid", "Asset Id");
        expectedMap.put("programtype", "Program Type");
        expectedMap.put("country", "Country");
        expectedMap.put("providerid", "Provider ID");
        expectedMap.put("maintitle", "Main Title");
        expectedMap.put("maintitlelanguage", "Main Title Language");
        expectedMap.put("shorttitle", "Short Title");
        expectedMap.put("shorttitlelanguage", "Short Title Language");
        expectedMap.put("duration(sec)", "Duration (Sec)");
        expectedMap.put("adtags", "Ad tags");
        expectedMap.put("streamurl", "Stream URL");
        expectedMap.put("descriptionlanguage", "Description Language");
        expectedMap.put("synopsis", "Synopsis");
        expectedMap.put("originalreleasedate", "Original Release Date");
        expectedMap.put("genre", "Genre");
        expectedMap.put("externalprogramid", "External Program Id");
        expectedMap.put("provider", "Provider");
        expectedMap.put("idtype", "ID Type");
        expectedMap.put("contentpartner/licensor", "Content Partner/Licensor");
        expectedMap.put("contenttier", "Content Tier");

        Map<String, String> actualMap = ImportTemplateAssetHeaderMap.getMap();
        assertEquals(expectedMap, actualMap);
    }
}
