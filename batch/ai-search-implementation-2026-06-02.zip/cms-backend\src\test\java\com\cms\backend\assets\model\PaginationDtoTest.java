package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PaginationDtoTest {

    @Test
    void testPaginationDto() {
        PaginationDto paginationDto = PaginationDto.builder()
            .limit(10)
            .offset(0)
            .build();

        assertEquals(10, paginationDto.getLimit());
        assertEquals(0, paginationDto.getOffset());
    }

    @Test
    void testDefaultConstructor() {
        PaginationDto paginationDto = new PaginationDto();
        assertEquals(0, paginationDto.getLimit());
        assertEquals(0, paginationDto.getOffset());
    }

    @Test
    void testAllArgsConstructor() {
        PaginationDto paginationDto = new PaginationDto(20, 5);
        assertEquals(20, paginationDto.getLimit());
        assertEquals(5, paginationDto.getOffset());
    }
}