import { Directive, inject, Input } from '@angular/core';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { Subscription } from 'rxjs';

@Directive({
  selector: 'mat-option[selectAll]',
  standalone: true,
})
export class SelectAllDirective {
  @Input({ required: true }) allValues: any[] = [];

  private _matSelect = inject(MatSelect);
  private _matOption = inject(MatOption);

  private _subscriptions: Subscription[] = [];

  ngAfterViewInit(): void {
    const parentSelect = this._matSelect;
    const parentFormControl = parentSelect.ngControl.control;

    // For changing other option selection based on select all
    this._subscriptions.push(
      this._matOption.onSelectionChange.subscribe((ev) => {
        if (ev.isUserInput) {
          if (ev.source.selected) {
            this._matOption.select(false);
            parentFormControl?.setValue(this.allValues);
          } else {
            this._matOption.deselect(false);
            parentFormControl?.setValue([]);
          }
        }
      })
    );

    this._subscriptions.push(
      parentSelect.optionSelectionChanges.subscribe((v) => {
        const validVals = parentFormControl?.value.filter((v: any) => v);
        if (validVals.length === this.allValues.length) {
          this._matOption.select(false);
        } else {
          this._matOption.deselect(false);
        }
      })
    );

    setTimeout(() => {
      if (
        parentFormControl?.value.length === this.allValues.length &&
        this.allValues.length > 0
      ) {
        this._matOption.select(false);
      }
    });
  }

  ngOnDestroy(): void {
    this._subscriptions.forEach((s) => s.unsubscribe());
  }
}
