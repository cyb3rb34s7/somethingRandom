package com.cms.backend.assets.service;

import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AssetMasterDataService {

    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;

    public AssetMasterDataService(RegionEndpointService regionEndpointService,
        HttpMethodHandler httpMethodHandler) {
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
    }

    public ResponseDto getRatings() {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_COMPLETE_RATINGS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting Ratings");
        }
    }

    public ResponseDto getLanguages() {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_LANGUAGES;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting Languages");
        }
    }

    public Map<String, Object> getAllCountryCodes() {
        try {
            String finalUrl =
                regionEndpointService.getEUOpenAPIEndpoint() + Constants.COUNTRY_CODES;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            String finalUrl1 =
                regionEndpointService.getUSOpenAPIEndpoint() + Constants.COUNTRY_CODES;
            ResponseEntity<ResponseDto> responseEntity1 = httpMethodHandler.handleHttpExchange(
                finalUrl1, Constants.METHOD_GET, null, ResponseDto.class);
            Map<String, Object> usCountries = Objects.requireNonNull(responseEntity1.getBody())
                .getRsp().getPayload();
            Map<String, Object> euCountries = Objects.requireNonNull(responseEntity.getBody())
                .getRsp().getPayload();
            Map<String, Object> payload = new HashMap<>();
            payload.put("usCountries", usCountries.get("countries"));
            payload.put("euCountries", euCountries.get("countries"));

            return payload;
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting  country code list");
        }
    }

    public ResponseDto getMasterPlatformData() {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_PLATFORM_DATA;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting  master platform data");
        }
    }

    public ResponseDto getCountryCodes() {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.COUNTRY_CODES;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting  country code list");
        }
    }

    public ResponseDto getFilters() {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_FILTERS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred  getting asset filters:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting filter list");
        }
    }

    public ResponseDto getAssetViewFilters(AssetKeyDto assetKeyDto) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_VIEW_FILTERS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(assetKeyDto), ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while asset View Filters");
        }
    }

    
}
