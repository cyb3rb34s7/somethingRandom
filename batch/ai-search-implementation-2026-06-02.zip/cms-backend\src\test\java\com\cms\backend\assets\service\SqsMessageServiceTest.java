package com.cms.backend.assets.service;

import com.cms.backend.assets.model.SqsMessageDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.NotificationUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SqsMessageServiceTest {

    @Mock
    private RegionEndpointService regionEndpointService;

    @Mock
    private NotificationUtil notificationUtil;

    @Mock
    private SqsClient sqsClient;

    @InjectMocks
    private SqsMessageService sqsMessageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(sqsMessageService, "cmsFeedWorkers", "CMS,CMS_GRACENOTE");
        ReflectionTestUtils.setField(sqsMessageService, "tvplusDeltaFeedWorkers",
            "TVPLUS_DELTA,TVPLUS_DELTA_GRACENOTE");
        ReflectionTestUtils.setField(sqsMessageService, "maxRetryAttempts", 3);
    }

    // Positive test cases for pushMessageToSqs
    @Test
    void pushMessageToSqs_withValidCmsFeedWorker_sendsMessageSuccessfully_P() {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String feedWorker = "CMS";
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/test-queue";

        when(regionEndpointService.getSQSEndpoint()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));

        // Verify
        verify(regionEndpointService).getSqsClient();
        verify(sqsClient).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void pushMessageToSqs_withValidTvplusDeltaFeedWorker_sendsMessageSuccessfully_P() {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String feedWorker = "TVPLUS_DELTA";
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/delta-queue";

        when(regionEndpointService.getSQSEndpointDelta()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));

        // Verify
        verify(regionEndpointService).getSqsClient();
        verify(sqsClient).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void pushMessageToSqs_withValidCmsGracenoteFeedWorker_sendsMessageSuccessfully_P() {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String feedWorker = "CMS_GRACENOTE";
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/test-queue";

        when(regionEndpointService.getSQSEndpoint()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));

        // Verify
        verify(regionEndpointService).getSqsClient();
        verify(sqsClient).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void pushMessageToSqs_withValidTvplusDeltaGracenoteFeedWorker_sendsMessageSuccessfully_P() {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String feedWorker = "TVPLUS_DELTA_GRACENOTE";
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/delta-queue";

        when(regionEndpointService.getSQSEndpointDelta()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));

        // Verify
        verify(regionEndpointService).getSqsClient();
        verify(sqsClient).sendMessage(any(SendMessageRequest.class));
    }

    @Test
    void pushMessageToSqs_withValidMessage_createsCorrectSendMessageRequest_P() {
        // Arrange
        SqsMessageDto sqsMessageDto = SqsMessageDto.builder()
            .assetId("test-asset-id")
            .contentProvider("test-provider")
            .countryCode("US")
            .eventType("UPDATE")
            .eventSource("CMS")
            .messageSender("CMS-ADMIN")
            .traceId("trace-123")
            .host("CMS-Admin")
            .build();
        String feedWorker = "CMS";
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/test-queue";

        when(regionEndpointService.getSQSEndpoint()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act
        sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker);

        // Assert
        ArgumentCaptor<SendMessageRequest> requestCaptor = ArgumentCaptor.forClass(
            SendMessageRequest.class);
        verify(sqsClient).sendMessage(requestCaptor.capture());

        SendMessageRequest capturedRequest = requestCaptor.getValue();
        assertEquals(queueUrl, capturedRequest.queueUrl());
        assertNotNull(capturedRequest.messageBody());
        assertTrue(capturedRequest.messageBody().contains("test-asset-id"));
        assertTrue(capturedRequest.messageBody().contains("test-provider"));
        assertTrue(capturedRequest.messageBody().contains("US"));
    }

    // Negative test cases for pushMessageToSqs
    @Test
    void pushMessageToSqs_withInvalidFeedWorker_throwsIllegalArgumentException_N() {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String invalidFeedWorker = "INVALID_WORKER";

        // Act & Assert
        assertThrows(IllegalArgumentException.class,
            () -> sqsMessageService.pushMessageToSqs(sqsMessageDto, invalidFeedWorker));
    }


    // Test cases for getSqsUrl (private method tested indirectly)
    @ParameterizedTest
    @ValueSource(strings = {"CMS", "cms", "CMS_GRACENOTE", "cms_gracenote"})
    void getSqsUrl_withCmsFeedWorkers_returnsCmsEndpoint_P(String feedWorker) {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/test-queue";

        when(regionEndpointService.getSQSEndpoint()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));
        verify(regionEndpointService).getSQSEndpoint();
    }

    @ParameterizedTest
    @ValueSource(strings = {"TVPLUS_DELTA", "tvplus_delta", "TVPLUS_DELTA_GRACENOTE",
        "tvplus_delta_gracenote"})
    void getSqsUrl_withTvplusDeltaFeedWorkers_returnsDeltaEndpoint_P(String feedWorker) {
        // Arrange
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/123456789012/delta-queue";

        when(regionEndpointService.getSQSEndpointDelta()).thenReturn(queueUrl);
        when(regionEndpointService.getSqsClient()).thenReturn(sqsClient);
        when(sqsClient.sendMessage(any(SendMessageRequest.class))).thenReturn(
            SendMessageResponse.builder().build());

        // Act & Assert
        assertDoesNotThrow(() -> sqsMessageService.pushMessageToSqs(sqsMessageDto, feedWorker));
        verify(regionEndpointService).getSQSEndpointDelta();
    }

    // Test recover method
    @Test
    void recover_withException_sendsErrorNotification_P() {
        // Arrange
        Exception testException = new Exception("Test exception");
        SqsMessageDto sqsMessageDto = createTestSqsMessageDto();
        String feedWorker = "CMS";

        // Act
        sqsMessageService.recover(testException, sqsMessageDto, feedWorker);

        // Assert
        verify(notificationUtil).sendErrorMail(
            testException,
            "SQS_RETRY_FAILURE",
            "500",
            "CMS-ADMIN"
        );
    }

    // Helper method
    private SqsMessageDto createTestSqsMessageDto() {
        return SqsMessageDto.builder()
            .assetId("test-asset-id")
            .contentProvider("test-provider")
            .countryCode("US")
            .eventType("UPDATE")
            .eventSource("CMS")
            .messageSender("CMS-ADMIN")
            .traceId("trace-123")
            .host("CMS-Admin")
            .build();
    }
}