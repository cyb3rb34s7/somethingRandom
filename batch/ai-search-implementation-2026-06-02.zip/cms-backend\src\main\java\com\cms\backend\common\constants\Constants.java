package com.cms.backend.common.constants;

import com.cms.backend.common.enums.AssetColumns;
import java.util.List;

public class Constants {


    public static final String ID = "id";
    public static final String STATUS_OK = "ok";
    public static final String STATUS_FAIL = "fail";
    public static final String QC_SYNC = "QC_SYNC";

    public static final String STATUS_ACTIVE = "Active";
    public static final String STATUS_INACTIVE = "Inactive";
    public static final String METHOD_GET = "GET";
    public static final String STATUS_PENDING = "Pending";

    //asset management
    public static final String ASSETS = "assets";
    public static final String GET_FILTERED_ASSETS = "/cms/tvplus/asset/list";
    public static final String BULK_REVOKE_HIERARCHY = "/cms/tvplus/asset/bulkRevokeHierarchy";
    public static final String GET_FILTERED_ASSETS_BY_COLUMNS = "/cms/tvplus/asset/assetDetailsByColumn";
    public static final String GET_FILTERED_ASSETS_COUNT = "/cms/tvplus/asset/count";
    public static final String GET_ASSET_VIEW = "/cms/tvplus/asset/view";
    public static final String GET_ASSET_CP_VIEW = "/cms/tvplus/asset/view/cp";
    public static final String CP_UPDATE = "/cms/tvplus/asset/update/cp";
    public static final String GET_ASSET_GRACENOTE_VIEW = "/cms/tvplus/asset/view/gracenote";
    public static final String GET_ASSET_VIEW_MEDIA_URLS = "/cms/tvplus/asset/view/streamUris";

    public static final String GET_ASSET_FILTERS = "/cms/tvplus/asset/filters";
    public static final String GET_ASSET_PLATFORM_DATA = "/cms/tvplus/asset/platforms";
    public static final String GET_ASSET_LANGUAGES = "/cms/tvplus/asset/languages";

    public static final String GET_ASSET_COMPLETE_RATINGS = "/cms/tvplus/asset/allRatings";
    public static final String GET_ASSET_EPISODE_HIERARCHY = "/cms/tvplus/asset/view/episode/hierarchy";
    public static final String GET_ASSET_VIEW_FILTERS = "/cms/tvplus/asset/view/filters";
    public static final String UPDATE_ASSET_STATUS = "/cms/tvplus/asset/status";

    public static final String ASSET_UPDATE = "/cms/tvplus/asset/update";
    public static final String VOD_ASSET_UPDATE = "/cms/tvplus/asset/update/vod";
    public static final String COUNTRY_CODES = "/cms/tvplus/asset/countrycodes";

    public static final String UPDATE_API_ERROR = "Request Body is null";

    public static final String GET_STATUS = "/cms/tvplus/asset/assetListDetailsforUpload";
    public static final String VALIDATE_EXTERNAL_ID = "/cms/tvplus/asset/validateExternalId";

    public static final String CONTENT_ID = "contentId";
    public static final String CP_ID = "cpId";
    public static final String VC_CP_ID = "vcCpId";
    public static final String COUNTRY = "countryCode";
    public static final String ASSET_STATUS = "status";

    public static final String METHOD_POST = "POST";

    public static final String ASSET_DETAILS = "assetDetails";
    public static final String VOD_ASSET_IS_NULL = "VodAsset is null";
    public static final int RETRY = 3;

    public static final String GET_SHOW_HIERARCHY = "/cms/tvplus/asset/getShowHierarchy";

    public static final String UPDATE_ASSET_BY_BULK_OF_PORTAL = "/cms/tvplus/asset/bulkUpdateAssets";
    public static final String GET_ASSET_DATA_FOR_HISTORY = "/cms/tvplus/asset/assetDetailsByColumn";

    public static final String EXPORT_ASSET_ENDPOINT = "/cms/tvplus/asset/export";
    public static final String EXPORT_ASSET_COUNT_ENDPOINT = "/cms/tvplus/asset/export/count";
    public static final String GET_EVALUATION_VIEW = "/cms/tvplus/evaluation/comparison/program/list";
    public static final String GET_EVALUATION_ASSET_VIEW = "/cms/tvplus/evaluation/comparison/detail";
    public static final String GET_EVALUATION_COUNT = "/cms/tvplus/evaluation/comparison/count";

    //history mgmt
    public static final String GET_LICENSE_HIST = "/cms/tvplus/license/history/get";
    public static final String GET_LICENSE_UI_FILTER_VALUES = "/cms/tvplus/license/history/get/filters";
    public static final String GET_LICENSE_HIST_ASSET = "/cms/tvplus/license/history/get/asset";
    public static final String ADD_LICENSE_HIST = "/cms/tvplus/license/history/add";
    public static final String GET_METADATA_HIST = "/cms/tvplus/metadata/history/get";
    public static final String ADD_METADATA_HIST = "/cms/tvplus/metadata/history/add";
    public static final String GET_METADATA_UI_FILTER_VALUES = "/cms/tvplus/metadata/history/get/filters";
    public static final String GET_METADATA_HIST_ASSET = "/cms/tvplus/metadata/history/get/asset";
    public static final String GET_ASSETSTATUS_HIST = "/cms/tvplus/asset/status/history/get";
    public static final String EXPORT_ASSET_STATUS_HIST = "/cms/tvplus/asset/status/history/export";
    public static final String ADD_ASSETSTATUS_HIST = "/cms/tvplus/asset/status/history/add";
    public static final String GET_ASSETSTATUS_UI_FILTER_VALUES = "/cms/tvplus/asset/status/history/get/filters";
    public static final String ASSET_VALIDATION_ENDPOINT = "/cms/tvplus/asset/validateAssetDetails";
    public static final List<String> USER_HISTORY_STATUS_FILTERS = List.of(STATUS_ACTIVE,
        STATUS_INACTIVE, STATUS_PENDING);
    public static final String EXPORT_LICENSE_HIST = "/cms/tvplus/license/history/export";
    public static final String ADD_EVENT_HIST = "/cms/tvplus/event/history/add";
    public static final String ADD_LOCK_CHANGE_HIST = "/cms/tvplus/lock/history/add";

    //export
    public static final String DATA = "data";
    public static final String ASSETSTATUS_HISTORY_NESTED_DATA = "statusHistoryChanges";
    public static final String LIC_HISTORY = "LicenseHistory";
    public static final String LIC_HISTORY_NESTED_DATA = "historyChanges";
    public static final String HISTORY_DATE_FMT1 = "latestChangeDateTime";
    public static final String HISTORY_DATE_FMT2 = "changeDateTime";
    public static final String PROGRAM_ID = "Program ID";

    public static final String ASSET_ID = "assetId";
    public static final String TI_NAME = "tiName";
    public static final String CONTENT_PARTNER = "contentPartner";
    public static final String CONTENT_PARTNER_FULL = "CP Name";
    public static final String TI_FULL_NAME = "Tech Integrator";
    public static final String MEDIA_TITLE = "Media Title";
    public static final String EXPORT_FULL_LATESTCHANGEDATETIME = "Change Date Time";

    public static final String EXPORT_FIELD = "field";
    public static final String EXPORT_FULL_FIELD = "Field";
    public static final String EXPORT_OLDVALUE = "oldValue";
    public static final String EXPORT_FULL_OLDVALUE = "Old Value";
    public static final String EXPORT_NEWVALUE = "newValue";
    public static final String EXPORT_FULL_NEWVALUE = "New Value";
    public static final String EXPORT_MAINTITLE = "mainTitle";
    public static final String EXPORT_TYPE = "type";
    public static final String EXPORT_FULL_TYPE = "Type";
    public static final String EXPORT_CURRENTRELEASEDATE = "currentReleaseDate";
    public static final String EXPORT_FULL_LIC_STRT_DT = "License Start Date";
    public static final String EXPORT_CURRENTEXPIRYDATE = "currentExpiryDate";
    public static final String EXPORT_CURRENTSTATUS = "currentStatus";
    public static final String EXPORT_FULL_CURRENTSTATUS = "License Status";
    public static final String EXPORT_FULL_LIC_CHANGEDATETIME = "License Change Date/Time";
    public static final String EXPORT_RELEASEDATE = "releaseDate";
    public static final String EXPIRY_DATE = "expiryDate";
    public static final String EXPORT_FULL_EXPIRYDATE = "License End Date";
    public static final String EXPORT_FULL_STATUS = "Status";
    public static final String EXPORT_MEDIATITLE = "mediaTitle";
    public static final String EXPORT_LATESTUPDATEDBY = "latestUpdatedBy";
    public static final String EXPORT_FULL_LATESTUPDATEDBY = "Last Updated By";
    public static final String EXPORT_LATESTCHANGEDATETIME = "latestChangeDateTime";
    public static final String EXPORT_FULL_UPDATEDDATE = "Updated Date";
    public static final String EXPORT_ALLSTATUS = "allStatus";
    public static final String EXPORT_FULL_LATESTSTATUS = "Latest Status";
    public static final String EXPORT_CHANGEDATETIME = "changeDateTime";
    public static final String EXPORT_FULL_CHANGEDATETIME = "Status Change Date";
    public static final String EXPORT_OLDSTATUS = "oldStatus";
    public static final String EXPORT_FULL_OLDSTATUS = "Old Asset Status";
    public static final String EXPORT_NEWSTATUS = "newStatus";
    public static final String EXPORT_FULL_NEWSTATUS = "New Asset Status";
    public static final String EXPORT_UPDATEDBY = "updatedBy";
    public static final String EXPORT_FULL_UPDATEDBY = "Updated by";
    public static final String EXPORT_TYPE_SELECTED = "selected";

    public static final String REVOKED = "REVOKED";
    public static final String QC_PASS = "QC_PASS";

    public static final String SUCCESSFUL = "Successful";
    public static final String MUSIC = "music";

    public static final String CONFIRM = "Confirm";
    public static final String EPISODE = "episode";
    public static final String SEASON = "season";
    public static final String MOVIE = "movie";
    public static final String SHOW = "show";
    public static final String SINGLEVOD = "singlevod";
    public static final List<String> ASSET_TYPE = List.of(Constants.MOVIE, Constants.SHOW,
        Constants.SEASON, Constants.EPISODE, Constants.SINGLEVOD, Constants.MUSIC);

    public static final List<String> EDITABLE_STATUSES = List.of("ready for qc", "qc in progress",
        "qc fail", "ready for release", "released", "revoked");

    public static final List<String> FEED_WORKERS = List.of("cms", "cms_gracenote", "tvplus_delta",
        "tvplus_delta_gracenote");

    public static final List<String> QC_SYNC_FEED_WORKERS = List.of("tvplus_delta",
        "tvplus_delta_gracenote");

    public static final String DATA_DUPLICATE = "Data Duplicate";
    public static final String DEEPLINK_PAYLOAD = "deeplinkPayload";
    public static final String DEEPLINK_DATA = "deeplink_data";
    public static final String RATINGS = "ratings";
    public static final String AVAILABLE_STARTING = "availableStarting";
    public static final String IS_RELEASED = "isReleased";
    public static final String DIRECTOR = "director";
    public static final String ARTIST = "artist";
    public static final String STARRING = "starring";
    public static final String ACTOR = "actor";
    public static final String CAST = "cast";
    public static final String DESCRIPTION = "description";
    public static final String SHORT_TITLE = "shortTitle";
    public static final String PARENTAL_RATINGS = "parentalRatings";
    public static final String ERROR_GETTING_DATA = "Error while getting asset master data";
    public static final String GENRES = "genres";
    public static final String CONTENT_TIER = "contentTier";
    public static final List<String> EXCEL_HEADERS = List.of(
        ExcelHeadersConstants.PROGRAM_ID,
        ExcelHeadersConstants.ASSET_ID,
        ExcelHeadersConstants.PROGRAM_TYPE,
        ExcelHeadersConstants.COUNTRY,
        ExcelHeadersConstants.PROVIDER_ID,
        ExcelHeadersConstants.MAIN_TITLE,
        ExcelHeadersConstants.SHORT_TITLE,
        ExcelHeadersConstants.DURATION_IN_SEC,
        ExcelHeadersConstants.AD_TAGS,
        ExcelHeadersConstants.STREAM_URL,
        ExcelHeadersConstants.SYNOPSIS,
        ExcelHeadersConstants.RELEASE_DATE,
        ExcelHeadersConstants.GENRE,
        ExcelHeadersConstants.EXTERNAL_PROGRM_ID,
        ExcelHeadersConstants.PROVIDER,
        ExcelHeadersConstants.ID_TYPE,
        ExcelHeadersConstants.CONTENT_PARTNER,
        ExcelHeadersConstants.CONTENT_TIER
    );


    public static final List<String> IMPORTTEMPLATEEDITABLEFIELDS = List.of(Constants.ASSET_ID,
        Constants.EXPORT_MAINTITLE,
        Constants.SHORT_TITLE, Constants.DESCRIPTION, Constants.EXPORT_RELEASEDATE,
        Constants.GENRES, "externalProvider", Constants.CONTENT_PARTNER,
        Constants.CONTENT_TIER);

    public static final List<String> NON_EDITABLE_BULK_IMPORT_FIELDS = List.of("programid",
        "programtype", "country", "providerid", "duration(sec)", "adtags", "streamurl");

    public static final List<String> COMPARE_DATA_FIELDS = List.of(
        Constants.ASSET_ID,
        Constants.EXPORT_MAINTITLE,
        Constants.SHORT_TITLE,
        Constants.DESCRIPTION,
        Constants.EXPORT_RELEASEDATE,
        Constants.GENRES,
        Constants.CONTENT_PARTNER,
        Constants.CONTENT_TIER
    );

    public static final String DASHBOARD_TABLE_NAME = "cms_portal_dashboard";
    public static final String DASHBOARD_PARTITION_KEY = "added_date";
    public static final String DASHBOARD_SORT_KEY = "region_country";
    public static final String DASHBOARD_INDEX = "added_date-country-index";
    public static final String DASHBOARD_DATA_RESPONSE = "dashboard";

    //exif integration
    public static final String INSERT_EXIF_IMAGE = "/cms/exif/image/triggerExifWithImageInsert";
    public static final String GET_STATUS_EXIF_IMAGE = "/cms/exif/image/getProcessingStatus";
    public static final String GET_PROCESSED_IMAGE_EXIF_IMAGE = "/cms/exif/image/getProcessedImages";
    public static final String IMAGE_UPLOAD_FAILED_PLEASE_TRY_AGAIN_LATER = "Image upload failed ,Please try again later...!";
    public static final String LAST_BATCH_RUN_TIME = "lastRunTime";
     
    public static final String ERROR_IN_GETTING_MASTER_DATA = "Error while getting asset data for history";

    public static final String IS_CMS_PROD = "isCmsProd";
    public static final String CONSTANT_UPDATE = "UPDATE";
    public static final String CONSTANT_ASSET = "ASSET";

    public static final String FEED_WORKER_COLUMN = "feedWorker";
    public static final List<String> EXCEL_ASSET_VALIDATION_FIELDS_OF_ORACLE = List.of(
        Constants.CONTENT_ID, Constants.COUNTRY, Constants.VC_CP_ID, Constants.ASSET_STATUS, "type",
        Constants.IS_CMS_PROD, "isSyncBlocked", Constants.IS_RELEASED, Constants.FEED_WORKER_COLUMN,
        Constants.DEEPLINK_PAYLOAD, Constants.EXPORT_MAINTITLE, Constants.EXPORT_RELEASEDATE,
        Constants.DESCRIPTION, Constants.SHORT_TITLE, Constants.STARRING, Constants.RATINGS,
        Constants.GENRES, Constants.AVAILABLE_STARTING, Constants.EXPIRY_DATE,
        Constants.CONTENT_PARTNER, Constants.DIRECTOR, Constants.ARTIST, Constants.ASSET_ID,
        "externalProviderList", Constants.CONTENT_TIER, "lockedFields");


    public static final String LICENSE_WINDOW_LIST = "licenseWindowList";
    public static final String EVENT_WINDOW_LIST = "eventWindowList";
    public static final List<String> BULKEDITABLEFIELDS = List.of(

        Constants.EXPORT_MAINTITLE,
        Constants.EXPORT_RELEASEDATE,
        Constants.DESCRIPTION,
        Constants.SHORT_TITLE, Constants.GENRES,
        Constants.AVAILABLE_STARTING, Constants.EXPIRY_DATE, Constants.CONTENT_PARTNER,
        Constants.DEEPLINK_PAYLOAD, Constants.CAST, Constants.PARENTAL_RATINGS,
        Constants.LICENSE_WINDOW_LIST, Constants.EVENT_WINDOW_LIST,
        AssetColumns.TOTAL_AVAILABLE_STARTING.value, AssetColumns.TOTAL_AVAILABLE_ENDING.value);


    public static final String FILTER_PROGRAM_ID = "programId";
    public static final String FILTER_PROGRAM_TITLE = "programTitle";
    public static final String FILTER_PROGRAM_TYPE = "programType";
    public static final String FILTER_COVERAGE_STATUS = "coverageStatus";
    public static final String FILTER_COMPARISON_STATUS = "comparisonStatus";
    public static final String FILTER_EXTERNAL_PROGRAM_ID = "externalProgramId";
    public static final String FILTER_FEED_WORKER = "feedWorker";

    private Constants() {
    }
}
