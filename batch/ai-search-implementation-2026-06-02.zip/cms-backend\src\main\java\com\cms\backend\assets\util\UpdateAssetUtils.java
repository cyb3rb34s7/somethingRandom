package com.cms.backend.assets.util;

import com.cms.backend.assets.mapper.AssetMapper;
import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.model.VodAssetUpdateDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.google.gson.Gson;
import jakarta.validation.constraints.NotEmpty;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class UpdateAssetUtils {

    private final AssetMapper assetMapper;
    private final HttpMethodHandler httpMethodHandler;
    private final RegionEndpointService regionEndpointService;

    UpdateAssetUtils(AssetMapper assetMapper, HttpMethodHandler httpMethodHandler,
        RegionEndpointService regionEndpointService) {
        this.assetMapper = assetMapper;
        this.httpMethodHandler = httpMethodHandler;
        this.regionEndpointService = regionEndpointService;
    }

    @Transactional
    public void updateDeleteAsset(VodAssetDto vodAssetDto) {
        Gson gson = new Gson();
        VodAssetDto copyDto = gson.fromJson(gson.toJson(vodAssetDto), VodAssetDto.class);

        copyDto.setExpiryDate(vodAssetDto.getExpiryDate() == null ? null
            : vodAssetDto.getExpiryDate().replace(" ", "T").replace("Z", "") + "Z");
        copyDto.setAvailableStarting(vodAssetDto.getAvailableStarting() == null ? null :
            vodAssetDto.getAvailableStarting().replace(" ", "T").replace("Z", "") + "Z");
        copyDto.setArtist(Constants.MUSIC.equalsIgnoreCase(vodAssetDto.getType())
            ? vodAssetDto.getArtist() : null);
        copyDto.setDeeplinkPayload(
            vodAssetDto.getRatings() == null ? null : vodAssetDto.getDeeplinkPayload());

        assetMapper.deleteEditAsset(vodAssetDto);
        ResponseDto responseDto = updateAsset(copyDto);

        if (responseDto != null && responseDto.getRsp() != null && !Objects.equals(
            responseDto.getRsp().getStat(),
            Constants.STATUS_OK)) {
            throw new AssetApiFailureException("Asset does not get updated");
        }
    }

    private ResponseDto updateAsset(VodAssetDto vodAssetDto) {
        try {
            HttpEntity<VodAssetUpdateDto> httpEntity = new HttpEntity<>(
                VodAssetUpdateDto.builder().vodAsset(vodAssetDto).vodCpAsset(vodAssetDto)
                    .build());
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.VOD_ASSET_UPDATE;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while updating asset");
        }
    }


    @Transactional
    public void insertRecordsInUploadtable(List<VodAssetDto> records) {
        for (VodAssetDto recordData : records) {
            assetMapper.insert(recordData);
        }
    }

    public AssetEventWindowDto findUpdateSlot(@NotEmpty List<AssetEventWindowDto> windows) {
        var lo = 0;
        var hi = windows.size() - 1;
        var resInd = hi;
        var now = Instant.now();

        windows.sort(
            Comparator.comparing(AssetEventWindowDto::getEventStarting)
                .thenComparing(AssetEventWindowDto::getEventEnding));
        while (lo <= hi) {
            var mid = lo + (hi - lo) / 2;

            var start = Instant.parse(windows.get(mid).getEventStarting());
            var end = windows.get(mid).getEventEnding() != null
                ? Instant.parse(windows.get(mid).getEventEnding())
                : Instant.MAX;

            if (now.isBefore(end)) {
                resInd = mid;
                if (now.isAfter(start)) {
                    break;
                }

                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }

        return windows.get(resInd);
    }

}
