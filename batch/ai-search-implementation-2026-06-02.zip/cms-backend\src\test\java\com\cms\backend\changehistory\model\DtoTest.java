package com.cms.backend.changehistory.model;

import com.cms.backend.changehistory.configuration.MetadataUpdate;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto.AssetsChanges;
import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;

class DtoTest {

    @Test
    void testHistoryFilterBody(){
        ModelDtoTestUtility.testModelOrDto(ChangeHistoryFilterBodyDto.class);
    }
    @Test
    void testHistoryFilterDto(){
        ModelDtoTestUtility.testModelOrDto(ChangeHistoryFilterDto.class);
    }
    @Test
    void testPaginationDto(){
        ModelDtoTestUtility.testModelOrDto(ChangeHistoryPaginationDto.class);
    }
    @Test
    void testOtherDto() {
        ModelDtoTestUtility.testModelOrDto(ChangeHistoryFilterBodyDto.class);
        ModelDtoTestUtility.testModelOrDto(ChangeHistorySortDto.class);
        ModelDtoTestUtility.testModelOrDto(LicenseHistoryRequestDto.class);
        ModelDtoTestUtility.testModelOrDto(MetadataHistoryRequestDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusHistoryRequestDto.class);
        ModelDtoTestUtility.testModelOrDto(AssetsChanges.class);
        ModelDtoTestUtility.testModelOrDto(MetadataUpdate.class);


    }
}