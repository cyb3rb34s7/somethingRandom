package com.cms.backend.common.enums;

public enum Regions {
    US_REGION("us-west-2"),
    EU_REGION("eu-west-1");


    public final String value;

    Regions(String value) {
        this.value = value;
    }
}
