package com.cms.backend.assets.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class RatingsDto {

    private String countryCode;
    private String type;
    private List<String> parentalRatings;
    private String organization;
    private String ratingList;
}
