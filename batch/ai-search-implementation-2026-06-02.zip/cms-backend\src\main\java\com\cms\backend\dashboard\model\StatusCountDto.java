package com.cms.backend.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Setter
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
public class StatusCountDto {


    private String assetStatus;
    private int assetsCount;

    @DynamoDbAttribute("asset_status")
    public String getAssetStatus() {
        return assetStatus;
    }

    @DynamoDbAttribute("assets_count")
    public int getAssetsCount() {
        return assetsCount;
    }
}
