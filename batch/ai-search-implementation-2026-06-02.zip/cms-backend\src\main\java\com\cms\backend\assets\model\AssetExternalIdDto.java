package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Generated
public class AssetExternalIdDto {

    private String programId;
    private String externalProgramId;
    private String idType;
    private String provider;
    private String countryCode;

    public String generateProgramTypeProviderTuple() {
        return externalProgramId + "$" + idType + "$" + provider;
    }
}
