package com.cms.backend.common.exception;


public class CountryNotAssignedException extends RuntimeException {

    public CountryNotAssignedException(String message) {
        super(message);
    }

}
