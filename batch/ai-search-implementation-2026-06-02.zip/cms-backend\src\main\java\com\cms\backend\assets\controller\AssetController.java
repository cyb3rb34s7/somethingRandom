package com.cms.backend.assets.controller;

import com.cms.backend.assets.model.AssetEpisodeHierarchyDto;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetRequestBodyDto;
import com.cms.backend.assets.model.AssetSingleImageUpdateDto;
import com.cms.backend.assets.model.AssetUpdateByBulkDto;
import com.cms.backend.assets.model.AssetUpdateRequestBodyDto;
import com.cms.backend.assets.model.EditValidationDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.model.VodAssetUpdateDto;
import com.cms.backend.assets.service.AssetExportImportTemplateService;
import com.cms.backend.assets.service.AssetExportService;
import com.cms.backend.assets.service.AssetManagementService;
import com.cms.backend.assets.service.AssetMasterDataService;
import com.cms.backend.assets.service.AssetService;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.ResponseHandler;
import jakarta.validation.Valid;
import java.io.IOException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RequestMapping("/admin/asset")
@RestController
@Slf4j
@Validated
public class AssetController {

    private final AssetService assetService;
    private final AssetManagementService assetManagementService;
    private final AssetExportService assetExportService;
    private final AssetExportImportTemplateService exportImportTemplateService;
    private final AssetMasterDataService assetMasterDataService;

    public AssetController(AssetService assetService,
        AssetManagementService assetManagementService, AssetExportService assetExportService,
        AssetExportImportTemplateService exportImportTemplateService,
        AssetMasterDataService assetMasterDataService) {
        this.assetService = assetService;
        this.assetManagementService = assetManagementService;
        this.assetExportService = assetExportService;
        this.exportImportTemplateService = exportImportTemplateService;
        this.assetMasterDataService = assetMasterDataService;
    }

    @PostMapping("/list")
    public ResponseDto getFilteredAssetsList(@RequestBody AssetFilterBodyDto assetFilterBodyDto
    ) {
        log.info("Request received for filtered assets list with params: {}", assetFilterBodyDto);
        return assetService.getFilteredAssets(assetFilterBodyDto);
    }

    @GetMapping("/view")
    public ResponseDto getAssetView(@RequestParam(name = Constants.CONTENT_ID) String contentId,
        @RequestParam(name = Constants.CP_ID) String cpId,
        @RequestParam(name = Constants.COUNTRY) String countryCode
    ) {
        return assetService.getAssetView(contentId, cpId, countryCode);
    }

    @GetMapping("/view/prd")
    public ResponseDto getPrdAssetView(@RequestParam(name = Constants.CONTENT_ID) String contentId,
        @RequestParam(name = Constants.CP_ID) String cpId,
        @RequestParam(name = Constants.COUNTRY) String countryCode
    ) {
        return assetManagementService.getPrdAssetView(contentId, cpId, countryCode);
    }

    @GetMapping("/filters")
    public ResponseDto getFilters() {
        return assetMasterDataService.getFilters();
    }

    @GetMapping("/platforms")
    public ResponseDto getPlatformData() {
        return assetMasterDataService.getMasterPlatformData();
    }

    @PostMapping("/updateStatus")
    public ResponseDto updateAssetStatus(@RequestBody StatusUpdateDto status) {
        return assetService.updateStatusByBulk(status);
    }

    @PostMapping("/update")
    public ResponseDto updateAsset(@Valid @RequestBody AssetRequestBodyDto assetRequestBodyDto) {
        return assetService.editAndHistoryCall(assetRequestBodyDto);
    }


    @PostMapping("/exportTemplate")
    public ResponseEntity<InputStreamResource> exportSelected(
        @RequestBody AssetFilterBodyDto assetFilterBodyDto, @RequestParam String filterType) {
        return exportImportTemplateService.exportSelected(assetFilterBodyDto, filterType);
    }


    @PostMapping("/export")
    public ResponseEntity<byte[]> exportAssetData(
        @RequestBody AssetFilterBodyDto assetFilterBodyDto) throws IOException {

        ExportHelperDto response = assetExportService.startExport(assetFilterBodyDto, false);
        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_OCTET_STREAM)
            .contentLength(response.getExcelData().length)
            .header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=" + response.getFileName())
            .header("X-File-Type", response.getFileType())
            .body(response.getExcelData());
    }


    @GetMapping("/countryCodes")
    public ResponseDto getCountryCodes() {
        return assetMasterDataService.getCountryCodes();
    }

    @PostMapping("/uploadAction")
    public ResponseDto uploadAction(@RequestParam String request) {
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            assetService.uploadAction(request));
    }

    @PostMapping("/uploadUpdates")
    public ResponseDto uploadUpdates(@RequestParam MultipartFile file) {
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            assetService.uploadUpdates(file));
    }

    @GetMapping("/existingUpdates")
    public ResponseDto existingUpdates() {
        List<VodAssetDto> vodAssetDtoList = assetService.getImportedAssets();
        return ResponseHandler.processMethodResponse(Constants.ASSETS,
            vodAssetDtoList);
    }


    @PostMapping("/uploadSingleImage")
    public ResponseDto uploadSingleImage(AssetSingleImageUpdateDto assetImageUpdateDto) {
        return ResponseDto.builder()
            .rsp(BaseResponseDto.builder()
                .payload(assetService.uploadSingleImage(assetImageUpdateDto))
                .build()).build();
    }

    @PostMapping("/getShowHierarchy")
    public ResponseDto getShowHierarchy(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        return assetService.getShowHierarchy(assetKeyDto);
    }

    @PostMapping("/updateAssetByBulk")
    public ResponseDto updateAssetByBulk(
        @Valid @RequestBody AssetUpdateByBulkDto assetUpdateByBulkDto) {
        return assetService.updateAssetInBulkPortal(assetUpdateByBulkDto);
    }

    @GetMapping("/allCountryCodes")
    public ResponseDto getAllCountryCodes() {
        return ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(assetMasterDataService.getAllCountryCodes())
                .build())
            .build();

    }

    @GetMapping("/languages")
    public ResponseDto getLanguages() {
        return assetMasterDataService.getLanguages();

    }

    @PostMapping("/view/episode/hierarchy")
    public ResponseDto getEpisodeHierarchy(
        @Valid @RequestBody AssetEpisodeHierarchyDto assetEpisodeHierarchyDto) {
        return assetService.getEpisodeHierarchy(assetEpisodeHierarchyDto);
    }

    @PostMapping("/view/filters")
    public ResponseDto getAssetViewFilters(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        return assetMasterDataService.getAssetViewFilters(assetKeyDto);
    }

    @PostMapping("/view/filters/prd")
    public ResponseDto getPrdAssetViewFilters(@Valid @RequestBody AssetKeyDto assetKeyDto) {
        return assetManagementService.getPrdAssetViewFilters(assetKeyDto);
    }

    @PostMapping("/count")
    public ResponseDto getFilteredAssetsListCount(@RequestBody AssetFilterBodyDto assetFilterBodyDto
        , @RequestParam String tab) {
        return assetService.getFilteredAssetsCount(assetFilterBodyDto, tab);
    }

    @PostMapping("/validateAssetDetails")
    public ResponseDto validateAssetDetails(
        @Valid @RequestBody EditValidationDto editValidationDto) {
        return assetService.validateAssetDetails(editValidationDto);
    }

    @PostMapping("/bulkRevokeHierarchy")
    public ResponseDto bulkRevokeHierarchy(
        @Valid @RequestBody List<AssetKeyDto> assetsList) {
        log.info("Request received for bulk Revoke Hierarchy.");
        return assetManagementService.bulkRevokeHierarchy(assetsList);
    }


    @GetMapping("/view/streamUris")
    public ResponseDto getStreamUrls(@RequestParam String contentId, @RequestParam String cpId,
        @RequestParam String countryCode) {
        log.info("Request received for Stream URLs for contentId: {}", contentId);
        return assetManagementService.getStreamUrls(contentId, cpId, countryCode);
    }

    @GetMapping("/view/cp")
    public ResponseDto getCpData(@RequestParam(name = Constants.CONTENT_ID) String contentId,
        @RequestParam(name = Constants.CP_ID) String cpId,
        @RequestParam(name = Constants.COUNTRY) String countryCode
    ) {
        return assetManagementService.getCpData(contentId, cpId, countryCode);
    }

    @GetMapping("/view/gracenote")
    public ResponseDto getGracenoteData(@RequestParam(name = Constants.CONTENT_ID) String contentId,
        @RequestParam(name = Constants.CP_ID) String cpId,
        @RequestParam(name = Constants.COUNTRY) String countryCode
    ) {
        return assetManagementService.getGracenoteData(contentId, cpId, countryCode);
    }

    @PostMapping("/update/cp")
    public ResponseDto updateCPData(@Valid @RequestBody AssetRequestBodyDto assetRequestBodyDto) {
        return assetManagementService.updateCPData(assetRequestBodyDto.getVodAssetDto());
    }

    @GetMapping("/get/static-json")
    public ResponseDto getStaticJson(@RequestParam String fileName) {
        return assetManagementService.getStaticJSON(fileName);
    }

    @GetMapping("/download/file")
    public ResponseEntity<byte[]> downloadFile(@RequestParam String fileName) {
        byte[] file = assetManagementService.getS3File(fileName);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
        return ResponseEntity.ok().headers(headers).body(file);

    }

    @GetMapping("/download/file/s3")
    public ResponseEntity<byte[]> downloadFileFromS3(@RequestParam String fileName,
        @RequestParam String path) {
        return assetManagementService.getFileFromS3(path, fileName);
    }

    @GetMapping("/get/smf-filename")
    public ResponseDto getSmfFileName() {
        return assetManagementService.getSmfFileName();

    }

    @PostMapping("/update/vod")
    public ResponseDto updateVodAsset(
        @Valid @RequestBody AssetUpdateRequestBodyDto assetUpdateRequestBodyDto) {
        return assetManagementService.updateVodAssetFromPortal(assetUpdateRequestBodyDto);
    }
}
