package com.cms.backend.changehistory.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LicenseHistoryRequestDto {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String assetId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String releaseDate;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String expiryDate;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String oldStatus;

    private String updatedBy;
    private String countryCode;
    private String vcCpId;
}
