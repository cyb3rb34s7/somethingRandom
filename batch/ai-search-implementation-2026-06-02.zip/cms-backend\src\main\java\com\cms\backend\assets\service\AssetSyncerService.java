package com.cms.backend.assets.service;


import com.cms.backend.assets.model.SqsMessageDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetEvents;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import java.util.List;


@Component
@Slf4j
public class AssetSyncerService {


    private final SqsMessageService sqsMessageService;
    public static final String X_TRACE_ID = "X-Trace-Id";

    public AssetSyncerService(SqsMessageService sqsMessageService) {
        this.sqsMessageService = sqsMessageService;
    }

    @Async
    public void pushMessageToSqsAsync(String eventType, List<VodAssetDto> vodAssetDtoList) {
        //need to handle push failure case
        if (eventType != null) {
            String traceId = MDC.get(X_TRACE_ID);
            vodAssetDtoList.forEach(vod -> {

                sqsMessageService.pushMessageToSqs(
                    SqsMessageDto.builder().assetId(vod.getContentId())
                        .contentProvider(vod.getVcCpId()).countryCode(vod.getCountryCode())
                        .eventSource(
                            eventType.equalsIgnoreCase(AssetEvents.AUTO_SYNC.value)
                                ? "TVPLUS_DELTA"
                                : Constants.CONSTANT_ASSET).eventType(eventType)
                        .messageSender("CMS")
                        .traceId(traceId).host("CMS-Admin")
                        .build(),
                    vod.getFeedWorker());

            });
        }
    }
}
