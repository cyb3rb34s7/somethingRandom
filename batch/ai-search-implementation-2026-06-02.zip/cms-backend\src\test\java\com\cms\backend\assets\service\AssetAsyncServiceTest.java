package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetChangeHistoryDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.model.SecurityUser;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

@SpringBootTest(classes = AssetAsyncServiceTest.class)
class AssetAsyncServiceTest {

    @Mock
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private RegionEndpointService regionEndpointService;

    @Mock
    private com.cms.backend.changehistory.service.ChangeHistoryService changeHistoryService;

    @Mock
    private AuthenticatedUser authenticatedUser;

    private AssetAsyncService assetAsyncService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        assetAsyncService = new AssetAsyncService(changeHistoryService,
            authenticatedUser);
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getSQSEndpoint()).thenReturn("http://test:8080");
    }

    @Test
    void testInsertAssetModificationHistoryWithAllHistories() {
        AssetChangeHistoryDto assetChangeHistoryDto = mock(AssetChangeHistoryDto.class);
        MetadataHistoryRequestDto assetMetadataHistoryDto = MetadataHistoryRequestDto.builder()
            .assetId("aa").build();
        StatusHistoryRequestDto assetStatusHistoryDto = mock(StatusHistoryRequestDto.class);
        LicenseHistoryRequestDto assetLicenseHistoryDto = LicenseHistoryRequestDto.builder()
            .assetId("aa").build();
        EventHistoryRequestDto eventHistoryRequestDto = EventHistoryRequestDto.builder()
            .contentId("AA").build();

        when(assetChangeHistoryDto.getAssetMetadataHistory()).thenReturn(assetMetadataHistoryDto);
        when(assetChangeHistoryDto.getAssetStatusHistory()).thenReturn(assetStatusHistoryDto);
        when(assetChangeHistoryDto.getAssetLicenseHistory()).thenReturn(assetLicenseHistoryDto);
        when(assetChangeHistoryDto.getEventHistory()).thenReturn(eventHistoryRequestDto);

        assertDoesNotThrow(
            () -> assetAsyncService.insertAssetModificationHistory(assetChangeHistoryDto)
        );
    }

    @Test
    void testInsertAssetModificationHistoryWithOnlyMetadataHistory() {
        AssetChangeHistoryDto assetChangeHistoryDto = mock(AssetChangeHistoryDto.class);
        MetadataHistoryRequestDto assetMetadataHistoryDto = mock(MetadataHistoryRequestDto.class);

        when(assetChangeHistoryDto.getAssetMetadataHistory()).thenReturn(assetMetadataHistoryDto);
        when(assetChangeHistoryDto.getAssetStatusHistory()).thenReturn(null);
        when(assetChangeHistoryDto.getAssetLicenseHistory()).thenReturn(null);

        assertDoesNotThrow(
            () -> assetAsyncService.insertAssetModificationHistory(assetChangeHistoryDto)
        );
    }

//    @Test
//    void testInsertStatusModificationHistory() {
//        StatusHistoryRequestDto assetStatusHistoryDto = mock(StatusHistoryRequestDto.class);
//        assertDoesNotThrow(
//            () -> assetAsyncService.insertStatusModificationHistory(assetStatusHistoryDto)
//        );
//    }

    @Test
    void testInsertAssetModificationHistory() {
        AssetChangeHistoryDto assetChangeHistoryDto = mock(AssetChangeHistoryDto.class);
        LicenseHistoryRequestDto assetLicenseHistoryDto = mock(LicenseHistoryRequestDto.class);
        StatusHistoryRequestDto assetStatusHistoryDto = mock(StatusHistoryRequestDto.class);
        MetadataHistoryRequestDto assetMetadataHistoryDto = mock(MetadataHistoryRequestDto.class);

        when(assetChangeHistoryDto.getAssetLicenseHistory()).thenReturn(assetLicenseHistoryDto);
        when(assetChangeHistoryDto.getAssetStatusHistory()).thenReturn(assetStatusHistoryDto);
        when(assetChangeHistoryDto.getAssetMetadataHistory()).thenReturn(assetMetadataHistoryDto);

        ResponseEntity<ResponseDto> responseEntity = mock(ResponseEntity.class);
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            eq(ResponseDto.class)))
            .thenReturn(responseEntity);
        assertDoesNotThrow(
            () -> assetAsyncService.insertAssetModificationHistory(assetChangeHistoryDto));

    }

    @Test
    void testInsertMetadataModificationHistory() {
        MetadataHistoryRequestDto metadataHistoryRequestDto = mock(MetadataHistoryRequestDto.class);
        assertDoesNotThrow(
            () -> assetAsyncService.insertMetadataModificationHistory(metadataHistoryRequestDto));
    }

    @Test
    void testTriggerMetatdataHistoryAPI() {
        MetadataHistoryRequestDto metadataHistoryRequestDto = mock(MetadataHistoryRequestDto.class);
        assertDoesNotThrow(
            () -> assetAsyncService.triggerMetatdataHistoryAPI(metadataHistoryRequestDto));
    }

    @Test
    void testAddBulkStatusHistory() {

        VodAssetDto vodAsset1 = VodAssetDto.builder()
            .contentId("asset1")
            .status("ACTIVE")
            .vcCpId("cp1")
            .countryCode("US")
            .identifierId("id1")
            .build();

        VodAssetDto vodAsset2 = VodAssetDto.builder()
            .contentId("asset2")
            .status("INACTIVE")
            .vcCpId("cp2")
            .countryCode("UK")
            .identifierId("id2")
            .build();

        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset1, vodAsset2);

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("APPROVED")
            .build();

        SecurityUser securityUser = mock(SecurityUser.class);
        when(securityUser.getUuid()).thenReturn("user-uuid");
        when(authenticatedUser.getUserInfo()).thenReturn(securityUser);

        assertDoesNotThrow(
            () -> assetAsyncService.addBulkStatusHistory(vodAssetDtoList, statusUpdateDto));

        ArgumentCaptor<StatusHistoryRequestDto> statusHistoryCaptor = ArgumentCaptor.forClass(
            StatusHistoryRequestDto.class);
        verify(changeHistoryService, times(1)).addAssetStatusHistory(statusHistoryCaptor.capture());

        StatusHistoryRequestDto capturedRequest = statusHistoryCaptor.getValue();
        assertNotNull(capturedRequest);
        // Now stores userId instead of userName (resolved from cache on retrieval)
        assertEquals("user-uuid", capturedRequest.getUpdatedBy());
        assertNotNull(capturedRequest.getChanges());
        assertEquals(2, capturedRequest.getChanges().size());

        StatusHistoryRequestDto.AssetsChanges firstChange = capturedRequest.getChanges().get(0);
        assertEquals("asset1", firstChange.getAssetId());
        assertEquals("ACTIVE", firstChange.getOldStatus());
        assertEquals("APPROVED", firstChange.getNewStatus());
        assertEquals("cp1", firstChange.getVcCpId());
        assertEquals("US", firstChange.getCountryCode());
        assertEquals("POST", firstChange.getMasterStatus());
        assertEquals("id1", firstChange.getIdentifierId());

        StatusHistoryRequestDto.AssetsChanges secondChange = capturedRequest.getChanges().get(1);
        assertEquals("asset2", secondChange.getAssetId());
        assertEquals("INACTIVE", secondChange.getOldStatus());
        assertEquals("APPROVED", secondChange.getNewStatus());
        assertEquals("cp2", secondChange.getVcCpId());
        assertEquals("UK", secondChange.getCountryCode());
        assertEquals("POST", secondChange.getMasterStatus());
        assertEquals("id2", secondChange.getIdentifierId());
    }

    @Test
    void testAddBulkStatusHistoryWithEmptyList() {

        List<VodAssetDto> emptyList = List.of();
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("APPROVED")
            .build();
        assertDoesNotThrow(
            () -> assetAsyncService.addBulkStatusHistory(emptyList, statusUpdateDto));
        verify(changeHistoryService, times(0)).addAssetStatusHistory(any());
    }

    @Test
    void testAddBulkStatusHistoryWithException() {

        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("asset1")
            .status("ACTIVE")
            .vcCpId("cp1")
            .countryCode("US")
            .identifierId("id1")
            .build();

        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset);

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("APPROVED")
            .build();

        SecurityUser securityUser = mock(SecurityUser.class);
        when(securityUser.getUuid()).thenReturn("user-uuid");
        when(authenticatedUser.getUserInfo()).thenReturn(securityUser);

        when(changeHistoryService.addAssetStatusHistory(any(StatusHistoryRequestDto.class)))
            .thenThrow(new RuntimeException("Service unavailable"));

        assertDoesNotThrow(
            () -> assetAsyncService.addBulkStatusHistory(vodAssetDtoList, statusUpdateDto));

        verify(changeHistoryService, times(3)).addAssetStatusHistory(
            any(StatusHistoryRequestDto.class));
    }


}
