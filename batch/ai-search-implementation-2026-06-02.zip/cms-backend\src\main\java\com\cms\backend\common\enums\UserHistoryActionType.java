package com.cms.backend.common.enums;

public enum UserHistoryActionType {
    ROLE_CHANGE("Role Change"),
    STATUS_CHANGE("Status Change"),
    ROLE_STATUS_CHANGE("Role Status Change"),
    NO_CHANGE("No Change");

    public final String label;

    UserHistoryActionType(String label) {
        this.label = label;
    }
}
