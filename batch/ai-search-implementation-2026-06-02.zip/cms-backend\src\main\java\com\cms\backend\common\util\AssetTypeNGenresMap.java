package com.cms.backend.common.util;

import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AssetTypeNGenresMap {

    @Bean
    public Map<String, String> initializeGenresMapping() {
        HashMap<String, String> genresEnum = new HashMap<>();
        genresEnum.put("action", "Action");
        genresEnum.put("arts/culture", "Arts/Culture");
        genresEnum.put("cartoons/puppets", "Cartoons/Puppets");
        genresEnum.put("comedy", "Comedy");
        genresEnum.put("cooking", "Cooking");
        genresEnum.put("crime", "Crime");
        genresEnum.put("documentary", "Documentary");
        genresEnum.put("drama", "Drama");
        genresEnum.put("education", "Education");
        genresEnum.put("entertainment", "Entertainment");
        genresEnum.put("fantasy", "Fantasy");
        genresEnum.put("history", "History");
        genresEnum.put("horror", "Horror");
        genresEnum.put("kids", "KIDS");
        genresEnum.put("music", "Music");
        genresEnum.put("mystery", "Mystery");
        genresEnum.put("news", "News");
        genresEnum.put("reality", "Reality");
        genresEnum.put("romance", "Romance");
        genresEnum.put("science fiction", "Science fiction");
        genresEnum.put("shopping", "Shopping");
        genresEnum.put("sports", "Sports");
        genresEnum.put("talk", "Talk");
        genresEnum.put("travel", "Travel");
        return genresEnum;
    }

    @Bean
    public Map<String, String> initializeGenresMusicMapping() {
        HashMap<String, String> genresMusic = new HashMap<>();
        genresMusic.put("afro", "Afro");
        genresMusic.put("ambient", "Ambient");
        genresMusic.put("arab", "Arab");
        genresMusic.put("bluegrass", "Bluegrass");
        genresMusic.put("blues", "Blues");
        genresMusic.put("caribbean", "Caribbean");
        genresMusic.put("classical", "Classical");
        genresMusic.put("concert", "Concert");
        genresMusic.put("country", "Country");
        genresMusic.put("dance", "Dance");
        genresMusic.put("disco", "Disco");
        genresMusic.put("electronic", "Electronic");
        genresMusic.put("flamenco", "Flamenco");
        genresMusic.put("folk & acoustic", "Folk & Acoustic");
        genresMusic.put("funk", "Funk");
        genresMusic.put("gospel", "Gospel");
        genresMusic.put("hip-hop", "Hip-Hop");
        genresMusic.put("holiday", "Holiday");
        genresMusic.put("indie & alternative", "Indie & Alternative");
        genresMusic.put("jazz", "Jazz");
        genresMusic.put("karaoke", "Karaoke");
        genresMusic.put("kids", "Kids");
        genresMusic.put("latin", "Latin");
        genresMusic.put("metal", "Metal");
        genresMusic.put("new age", "New Age");
        genresMusic.put("opera", "Opera");
        genresMusic.put("pop", "Pop");
        genresMusic.put("punk", "Punk");
        genresMusic.put("r&b", "R&B");
        genresMusic.put("reggae", "Reggae");
        genresMusic.put("reggaeton", "Reggaeton");
        genresMusic.put("religious", "Religious");
        genresMusic.put("rock", "Rock");
        genresMusic.put("salsa", "Salsa");
        genresMusic.put("ska", "Ska");
        genresMusic.put("soul", "Soul");
        genresMusic.put("traditional", "Traditional");
        return genresMusic;
    }
}
