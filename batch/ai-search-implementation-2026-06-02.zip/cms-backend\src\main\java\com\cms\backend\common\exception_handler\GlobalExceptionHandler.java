package com.cms.backend.common.exception_handler;

import com.cms.backend.assets.aisearch.exception.LlmGatewayException;
import com.cms.backend.assets.aisearch.exception.SchemaUnavailableException;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CountryNotAssignedException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.exception.DataNotFoundException;
import com.cms.backend.common.exception.ForbiddenException;
import com.cms.backend.common.exception.IMSException;
import com.cms.backend.common.exception.IMSTokenExpiredException;
import com.cms.backend.common.exception.InvalidInputDataException;
import com.cms.backend.common.exception.InvalidStatusException;
import com.cms.backend.common.exception.ModifyingRoleOfSelfException;
import com.cms.backend.common.exception.RolesInUseException;
import com.cms.backend.common.exception.UnauthorizedException;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.ErrorCode;
import com.cms.backend.common.util.ErrorMsg;
import com.cms.backend.common.util.NotificationUtil;
import com.cms.backend.common.util.ResponseHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    public static final String BAD_REQUEST = "Bad Request";
    private static final String CMS_ERROR_SOURCE = "CMS-ADMIN";
    private static final String PPLE_ERROR_SOURCE = "TVP-PPLE-MFE";

    private final NotificationUtil notificationUtil;

    public GlobalExceptionHandler(NotificationUtil notificationUtil) {
        this.notificationUtil = notificationUtil;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleMethodArgumentNotValidException(MethodArgumentNotValidException ex,
        HttpServletRequest request) {

        StringBuilder sb = new StringBuilder();

        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            sb.append(fieldName).append(": ").append(errorMessage).append(", ");
        });

        String errorMessage = sb.toString();
        log.error("MethodArgumentNotValidException: {}", errorMessage);
        notificationUtil.sendErrorMail(ex, BAD_REQUEST, "400", resolveSource(request));
        return generateErrorResponse(new InvalidInputDataException(errorMessage));
    }

    @ExceptionHandler(UnauthorizedException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED) // 401
    public ResponseDto handleUnauthorizedException(UnauthorizedException e) {
        return generateErrorResponse(e);
    }

    @ExceptionHandler(ForbiddenException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN) // 403
    public ResponseDto handleForbiddenException(ForbiddenException e) {
        return generateErrorResponse(e);
    }


    @ExceptionHandler({ConstraintViolationException.class,
        MethodArgumentTypeMismatchException.class, InvalidInputDataException.class,
        HandlerMethodValidationException.class, CustomException.class,
        IllegalArgumentException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleConstraintViolationException(Exception ex,
        HttpServletRequest request) {
        log.error("ConstraintViolationException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, BAD_REQUEST, "400", resolveSource(request));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler({NoHandlerFoundException.class, NoResourceFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND) // 404
    public ResponseDto handleNoResourceFoundException(Exception ex) {
        log.error("NoResourceFoundException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(RolesInUseException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseDto handleUsersStillAssignedToRoleException(RolesInUseException ex) {
        log.error("UsersStillAssignedToRoleException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleDataIntegrityViolationException(DataIntegrityViolationException ex,
        HttpServletRequest request) {
        log.error("DataIntegrityViolationException: {}", ex.getMessage());
        notificationUtil.sendErrorMail(ex, BAD_REQUEST, "400", resolveSource(request));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(ModifyingRoleOfSelfException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 405
    public ResponseDto handleModifyingRoleOfSelfException(ModifyingRoleOfSelfException ex) {
        log.error("ModifyingRoleOfSelfException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(CountryNotAssignedException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST) // 400
    public ResponseDto handleCountryNotAssignedException(CountryNotAssignedException ex) {
        log.error("CountryNotAssignedException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(DataNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND) // 404
    public ResponseDto handleDataNotFoundException(DataNotFoundException ex) {
        log.error("DataNotFoundException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    public ResponseDto handleHttpRequestMethodNotSupportedException(
        HttpRequestMethodNotSupportedException ex) {
        log.error("HttpRequestMethodNotSupportedException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseDto handleMissingServletRequestParameterException(
        MissingServletRequestParameterException ex) {
        log.error("MissingServletRequestParameterException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(InvalidStatusException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseDto handleInvalidStatusException(InvalidStatusException ex) {
        log.error("InvalidStatusException: {}", ex.getMessage());
        return generateErrorResponse(ex);
    }

    @ExceptionHandler({IMSException.class, Exception.class, AssetApiFailureException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseDto handleGeneralException(Exception ex, HttpServletRequest request) {
        log.error("General Exception or IMS Exception: {}",
            ResponseHandler.generateBaseMessage(ex));
        notificationUtil.sendAlarm(ex, "INTERNAL_SERVER_ERROR", "500", resolveSource(request));
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(IMSTokenExpiredException.class)
    public ResponseDto handleIMSTokenExpiredException(IMSTokenExpiredException ex,
        HttpServletResponse response) {
        log.error("IMS Token Expired: {}", ex.getMessage());
        response.setStatus(602); // Custom status code for session expiration
        return generateErrorResponse(ex);
    }

    @ExceptionHandler(LlmGatewayException.class)
    @ResponseStatus(HttpStatus.BAD_GATEWAY) // 502
    public ResponseDto handleLlmGatewayException(LlmGatewayException e) {
        log.error("LLM gateway error: {}", e.getMessage());
        return ResponseHandler.processError(new ErrorResponseDto(ErrorCode.SERVICE_UNAVAILABLE,
            "AI service is temporarily unavailable. Please try again."));
    }

    @ExceptionHandler(SchemaUnavailableException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 500
    public ResponseDto handleSchemaUnavailableException(SchemaUnavailableException e) {
        log.error("AI search schema unavailable: {}", e.getMessage());
        return ResponseHandler.processError(new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
            "AI search is not available right now."));
    }

    private ResponseDto generateErrorResponse(Exception ex) {
        return ResponseHandler.processMethodResponse(ex);
    }

    private String resolveSource(HttpServletRequest request) {
        String uri = request.getRequestURI();

        if (uri != null && uri.startsWith("/pple")) {
            return PPLE_ERROR_SOURCE;
        }
        return CMS_ERROR_SOURCE;
    }
}
