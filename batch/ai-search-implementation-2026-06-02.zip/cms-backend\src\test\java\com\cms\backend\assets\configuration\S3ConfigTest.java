package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import com.cms.backend.common.exception.CustomException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sts.model.Credentials;

class S3ConfigTest {

    private S3Config s3Config;

    @Mock
    private Credentials credentials;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        s3Config = new S3Config();
    }

    @Test
    void testUsAmazonS3WithEmptyRoleArn() {
        ReflectionTestUtils.setField(s3Config, "roleArn", "");
        S3Client s3Client = s3Config.usAmazonS3();
        assertNotNull(s3Client);
    }

    @Test
    void testEuAmazonS3WithEmptyRoleArn() {
        ReflectionTestUtils.setField(s3Config, "roleArn", "");
        S3Client s3Client = s3Config.euAmazonS3();
        assertNotNull(s3Client);
    }

    @Test
    void testGetBasicCredentialsWithNullCredentials() {
        ReflectionTestUtils.setField(s3Config, "credentials", null);
        ReflectionTestUtils.setField(s3Config, "roleArn", "arn:aws:iam::123456789012:role/test-role");

        assertThrows(CustomException.class, () -> s3Config.getBasicCredentials());
    }
}
