package com.cms.backend.common.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvalidLicenseWindowVodAsset {

    private String programId;
    private String contentProvider;
    private String vodKey;
    private String countryCode;
    @JsonAlias({"api_error", "error"})
    private String error;
    @JsonAlias({"api_error_datetime", "errorDatetime"})
    private String errorDatetime;
}
