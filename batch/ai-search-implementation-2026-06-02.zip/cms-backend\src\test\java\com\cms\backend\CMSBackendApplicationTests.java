package com.cms.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.backend.common.exception.CountryNotAssignedException;
import com.cms.backend.common.exception.DataNotFoundException;
import com.cms.backend.common.exception.DatabaseException;
import com.cms.backend.common.exception.IMSException;
import com.cms.backend.common.exception.ModifyingRoleOfSelfException;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest(classes = CMSBackendApplicationTests.class)
@TestPropertySource("classpath:application-test.properties")
class CMSBackendApplicationTests {

    @Test
    void contextLoads() {
        assertTrue(true);
    }

    @Test
    void testMainMethod() {
        CMSBackendApplication.main(new String[]{});
        assertTrue(true); // Just to make sure the test is not empty
    }


    @Test
    void testCustomExceptions() {
        CountryNotAssignedException countryNotAssignedException = new CountryNotAssignedException(
            "Test");
        assertEquals("Test", countryNotAssignedException.getMessage());

        DatabaseException databaseException = new DatabaseException(
            "Test");
        assertEquals("Test", databaseException.getMessage());
        DataNotFoundException dataNotFoundException = new DataNotFoundException(
            "Test");
        assertEquals("Test", dataNotFoundException.getMessage());
        IMSException imsException = new IMSException(
            "Test");
        assertEquals("Test", imsException.getMessage());
        ModifyingRoleOfSelfException modifyingRoleOfSelfException = new ModifyingRoleOfSelfException(
            "Test");
        assertEquals("Test", modifyingRoleOfSelfException.getMessage());
    }


}
