package com.cms.backend.assets.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.Instant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class AssetExportDataFormatterTest {

    private ObjectMapper objectMapper;
    private Instant testTime;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        testTime = Instant.parse("2023-06-15T12:00:00Z");
    }

    @Test
    void testExtractComputedValue_ComputedRatings() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("parentalRatings", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("body", "MPAA")
                .put("ratings", "PG-13"))
            .add(objectMapper.createObjectNode()
                .put("body", "BBFC")
                .put("ratings", "12A")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "computedRatings",
            testTime);
        assertTrue(result.contains("MPAA (PG-13)"));
        assertTrue(result.contains("BBFC (12A)"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"computedRatings", "invalidField"})
    void testExtractComputedValue_EmptyOrInvalidFields(String fieldName) {
        ObjectNode asset = objectMapper.createObjectNode();
        if ("computedRatings".equals(fieldName)) {
            asset.set("parentalRatings", objectMapper.createArrayNode());
        }
        String result = AssetExportDataFormatter.extractComputedValue(asset, fieldName, testTime);
        assertEquals("", result);
    }

    @Test
    void testExtractComputedValue_ComputedActor() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("cast", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("name", "Tom Hanks")
                .put("role", "actor")
                .put("characterName", "Forrest Gump"))
            .add(objectMapper.createObjectNode()
                .put("name", "Robin Wright")
                .put("role", "actor")
                .put("characterName", "Jenny Curran"))
            .add(objectMapper.createObjectNode()
                .put("name", "Robert Zemeckis")
                .put("role", "director")
                .put("characterName", "")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "computedActor",
            testTime);
        assertTrue(result.contains("Tom Hanks (Forrest Gump)"));
        assertTrue(result.contains("Robin Wright (Jenny Curran)"));
        assertFalse(result.contains("Robert Zemeckis"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"computedActor", "computedExternalIds"})
    void testExtractComputedValue_EmptyArrayFields(String fieldName) {
        ObjectNode asset = objectMapper.createObjectNode();
        if ("computedActor".equals(fieldName)) {
            asset.set("cast", objectMapper.createArrayNode());
        } else if ("computedExternalIds".equals(fieldName)) {
            asset.set("externalProvider", objectMapper.createArrayNode());
        }
        String result = AssetExportDataFormatter.extractComputedValue(asset, fieldName, testTime);
        assertEquals("", result);
    }

    @Test
    void testExtractComputedValue_ComputedDirector() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("cast", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("name", "Tom Hanks")
                .put("role", "actor")
                .put("characterName", "Forrest Gump"))
            .add(objectMapper.createObjectNode()
                .put("name", "Robert Zemeckis")
                .put("role", "director")
                .put("characterName", "")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "computedDirector",
            testTime);
        assertTrue(result.contains("Robert Zemeckis"));
        assertFalse(result.contains("Tom Hanks"));
    }

    @Test
    void testExtractComputedValue_ComputedExternalIds() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("externalProvider", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("provider", "IMDB")
                .put("externalProgramId", "tt0109830"))
            .add(objectMapper.createObjectNode()
                .put("provider", "TMDB")
                .put("externalProgramId", "12345")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "computedExternalIds",
            testTime);
        assertTrue(result.contains("IMDB: tt0109830"));
        assertTrue(result.contains("TMDB: 12345"));
    }

    @Test
    void testExtractComputedValue_ExpiredLWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("licenseWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2022-01-01T00:00:00Z")
                .put("availableEnding", "2022-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2024-01-01T00:00:00Z")
                .put("availableEnding", "2024-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "expiredLWs",
            testTime);
        assertTrue(result.contains("2022-01-01 00:00:00;2022-12-31 00:00:00"));
        assertFalse(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_CurrentLWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("licenseWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2022-01-01T00:00:00Z")
                .put("availableEnding", "2024-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2024-01-01T00:00:00Z")
                .put("availableEnding", "2024-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "currentLWs",
            testTime);
        assertTrue(result.contains("2022-01-01 00:00:00;2024-12-31 00:00:00"));
        assertFalse(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_FutureLWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("licenseWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2024-01-01T00:00:00Z")
                .put("availableEnding", "2024-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2025-01-01T00:00:00Z")
                .put("availableEnding", "2025-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "futureLWs", testTime);
        assertTrue(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
        assertTrue(result.contains("2025-01-01 00:00:00;2025-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_ExpiredEWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("eventWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2022-01-01T00:00:00Z")
                .put("eventEnding", "2022-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2024-01-01T00:00:00Z")
                .put("eventEnding", "2024-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "expiredEWs",
            testTime);
        assertTrue(result.contains("2022-01-01 00:00:00;2022-12-31 00:00:00"));
        assertFalse(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_CurrentEWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("eventWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2022-01-01T00:00:00Z")
                .put("eventEnding", "2024-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2024-01-01T00:00:00Z")
                .put("eventEnding", "2024-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "currentEWs",
            testTime);
        assertTrue(result.contains("2022-01-01 00:00:00;2024-12-31 00:00:00"));
        assertFalse(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_FutureEWs() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("eventWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2024-01-01T00:00:00Z")
                .put("eventEnding", "2024-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("eventStarting", "2025-01-01T00:00:00Z")
                .put("eventEnding", "2025-12-31T00:00:00Z")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "futureEWs", testTime);
        assertTrue(result.contains("2024-01-01 00:00:00;2024-12-31 00:00:00"));
        assertTrue(result.contains("2025-01-01 00:00:00;2025-12-31 00:00:00"));
    }

    @Test
    void testExtractComputedValue_GeoAccessType() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("geoRestrictions", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("accessType", "ALLOW")
                .put("restrictionType", "COUNTRY")
                .put("teamRegion", "US"))
            .add(objectMapper.createObjectNode()
                .put("accessType", "DENY")
                .put("restrictionType", "COUNTRY")
                .put("teamRegion", "CN")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "geoAccessType",
            testTime);
        assertTrue(result.contains("ALLOW"));
        assertTrue(result.contains("DENY"));
    }

    @Test
    void testExtractComputedValue_GeoRestrictionType() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("geoRestrictions", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("accessType", "ALLOW")
                .put("restrictionType", "COUNTRY")
                .put("teamRegion", "US"))
            .add(objectMapper.createObjectNode()
                .put("accessType", "DENY")
                .put("restrictionType", "REGION")
                .put("teamRegion", "CN")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "geoRestrictionType",
            testTime);
        assertTrue(result.contains("COUNTRY"));
        assertTrue(result.contains("REGION"));
    }

    @Test
    void testExtractComputedValue_GeoTeamRegion() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("geoRestrictions", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("accessType", "ALLOW")
                .put("restrictionType", "COUNTRY")
                .put("teamRegion", "US"))
            .add(objectMapper.createObjectNode()
                .put("accessType", "DENY")
                .put("restrictionType", "COUNTRY")
                .put("teamRegion", "CN")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "geoTeamRegion",
            testTime);
        assertTrue(result.contains("US"));
        assertTrue(result.contains("CN"));
    }

    @Test
    void testExtractComputedValue_InvalidDateFormats() {
        ObjectNode asset = objectMapper.createObjectNode();
        asset.set("licenseWindowList", objectMapper.createArrayNode()
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "Invalid Date")
                .put("availableEnding", "2024-12-31T00:00:00Z"))
            .add(objectMapper.createObjectNode()
                .put("availableStarting", "2023-01-01T00:00:00Z")
                .put("availableEnding", "Also Invalid")));

        String result = AssetExportDataFormatter.extractComputedValue(asset, "currentLWs",
            testTime);
        // Invalid dates should be ignored, only valid ones processed
        // Both windows have at least one invalid date, so result should be empty
        assertEquals("", result,
            "Result should be empty when all windows have invalid dates. Actual result: '"
                + result + "'");
    }

    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    void testExtractComputedValue_WindowListEdgeCases(boolean isEmptyList) {
        ObjectNode asset = objectMapper.createObjectNode();
        if (isEmptyList) {
            asset.set("licenseWindowList", objectMapper.createArrayNode());
        }
        // For false case, we leave the asset node empty (null case)

        String result = AssetExportDataFormatter.extractComputedValue(asset, "currentLWs",
            testTime);
        assertEquals("", result);
    }
}
