package com.cms.backend.common.enums;

public enum AssetStatus {
    QC_PASS("QC Pass"),
    TEMP_QC_PASS("Temp QC Pass"),
    QC_IN_PROGRESS("QC in Progress"),
    REVOKED("Revoked"),
    RELEASED("Released"),
    QC_FAIL("QC Fail"),
    READY_FOR_QC("Ready for QC"),
    SMF_IMPORTED("SMF Imported"),
    TRANSFERRING("Transferring"),
    UNTRACKABLE("Untrackable");

    public final String value;

    AssetStatus(String value) {
        this.value = value;
    }
}
