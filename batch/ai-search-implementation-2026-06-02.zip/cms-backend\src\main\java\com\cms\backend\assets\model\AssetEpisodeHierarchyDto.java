package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssetEpisodeHierarchyDto {
    private String contentId;
    private String countryCode;
    private String vcCpId;
    private String seasonId;
    private String showId;
}
