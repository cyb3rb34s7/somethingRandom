package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class AssetFilterBodyDtoTest {

    @Test
    void testDefaultConstructor() {
        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto();
        assertNotNull(assetFilterBodyDto);
    }

    @Test
    void testAllArgsConstructor() {
        List<FilterDto> filters = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        List<SortDto> sortBy = List.of(new SortDto());
        PaginationDto pagination = new PaginationDto();

        AssetFilterBodyDto assetFilterBodyDto = new AssetFilterBodyDto(filters, columns, sortBy,
            pagination);
        assertNotNull(assetFilterBodyDto);
        assertEquals(filters, assetFilterBodyDto.getFilters());
        assertEquals(columns, assetFilterBodyDto.getColumns());
        assertEquals(sortBy, assetFilterBodyDto.getSortBy());
        assertEquals(pagination, assetFilterBodyDto.getPagination());
    }

    @Test
    void testBuilder() {
        List<FilterDto> filters = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        List<SortDto> sortBy = List.of(new SortDto());
        PaginationDto pagination = new PaginationDto();

        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder()
            .filters(filters)
            .columns(columns)
            .sortBy(sortBy)
            .pagination(pagination)
            .build();

        assertNotNull(assetFilterBodyDto);
        assertEquals(filters, assetFilterBodyDto.getFilters());
        assertEquals(columns, assetFilterBodyDto.getColumns());
        assertEquals(sortBy, assetFilterBodyDto.getSortBy());
        assertEquals(pagination, assetFilterBodyDto.getPagination());
    }
}