package com.cms.backend.dashboard.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementRequest;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementResponse;

@SpringBootTest(classes= DynamoServiceTest.class)
class DynamoServiceTest {

    @InjectMocks
    private DynamoService dynamoService;

    @Mock
    private DynamoDbClient dynamoDB;

    @Test
    void testGetAllDashboardData(){
        String date="2000-09-09";
        assertThrows(RuntimeException.class,() ->dynamoService.getAllDashboardData(date));
    }

    @Test
    void testGetDashboardDataByCountry() {
        String date="2000-09-09";
        List<String> countries= Arrays.asList("US", "AA");
        assertThrows(RuntimeException.class,() ->dynamoService.getDashboardDataByCountry(date,countries));
    }

    @Test
    void testGetDashboardDataByCountryWithNoCountries() {
        String date="2000-09-09";
        List<String> countries= List.of();
        assertDoesNotThrow(() ->dynamoService.getDashboardDataByCountry(date,countries));
    }

    @Test
    void getCountriesHavingDataReturnCorrectCountryList() {
        // Arrange
        String date = "2023-10-01";
        List<Map<String, AttributeValue>> items = new ArrayList<>();
        Map<String, AttributeValue> item1 = new HashMap<>();
        item1.put("country", AttributeValue.builder().s("US").build());
        items.add(item1);
        Map<String, AttributeValue> item2 = new HashMap<>();
        item2.put("country", AttributeValue.builder().s("AA").build());
        items.add(item2);

        ExecuteStatementResponse executeStatementResult = ExecuteStatementResponse.builder().items(items).build();

        when(dynamoDB.executeStatement(any(ExecuteStatementRequest.class))).thenReturn(executeStatementResult);

        // Act
        List<String> countryList = dynamoService.getCountriesHavingData(date);

        // Assert
        assertThat(countryList).containsExactlyInAnyOrder("US", "AA");
    }

    @Test
    void testGetLastBatchRunTime() {
        // Mocking the response from DynamoDB
        List<Map<String, AttributeValue>> items = new ArrayList<>();
        Map<String, AttributeValue> item = new HashMap<>();
        item.put("last_run_time", AttributeValue.builder().s("2021-01-01T00:00:00Z").build());
        items.add(item);
        ExecuteStatementResponse result = ExecuteStatementResponse.builder().items(items).build();

        // Setting up mock behavior
        when(dynamoDB.executeStatement(any(ExecuteStatementRequest.class))).thenReturn(result);

        // Testing the method
        String expectedResult = "01/01/21 00:00 UTC";
        String actualResult = dynamoService.getLastBatchRunTime();

        assertEquals(expectedResult, actualResult);
    }

    @Test
    void testGetLastBatchRunTimeEmpty() {
        // Mocking the response from DynamoDB
        List<Map<String, AttributeValue>> items = new ArrayList<>();
        ExecuteStatementResponse result = ExecuteStatementResponse.builder().items(items).build();

        // Setting up mock behavior
        when(dynamoDB.executeStatement(any(ExecuteStatementRequest.class))).thenReturn(result);

        // Testing the method
        String expectedResult = "";
        String actualResult = dynamoService.getLastBatchRunTime();

        assertEquals(expectedResult, actualResult);
    }
}
