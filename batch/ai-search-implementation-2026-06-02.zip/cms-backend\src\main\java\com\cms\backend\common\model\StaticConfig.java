package com.cms.backend.common.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StaticConfig {

    @JsonProperty("allowedOrigins")
    private List<AllowedOrigin> allowedOrigins;
}
