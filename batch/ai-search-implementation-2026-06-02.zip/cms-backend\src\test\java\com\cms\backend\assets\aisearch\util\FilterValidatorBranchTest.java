package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.llm.LlmFilter;
import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import com.cms.backend.assets.model.FilterDto;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Targets the {@code schema.getValues() == null} branch of
 * {@link FilterValidator#validateAndSanitize} which the bundled schema never reaches because every
 * static filter key in it declares a (possibly empty) values list.
 */
@ExtendWith(MockitoExtension.class)
class FilterValidatorBranchTest {

    @Mock
    FilterSchemaProvider provider;

    private LlmFilter f(String key, String... values) {
        LlmFilter lf = new LlmFilter();
        lf.setKey(key);
        lf.setType("filter");
        lf.setValues(List.of(values));
        return lf;
    }

    @Test
    void staticKeyWithNullValuesListTreatsAllowedAsEmptyAndKeepsValues() {
        FilterKey nullValuesKey = new FilterKey();
        nullValuesKey.setKey("weird");
        nullValuesKey.setType("filter");
        nullValuesKey.setDisplayText("Weird");
        nullValuesKey.setDynamicValues(false);
        nullValuesKey.setValues(null); // exercise the null branch

        when(provider.getByKey("weird")).thenReturn(nullValuesKey);
        FilterValidator validator = new FilterValidator(provider);

        List<FilterDto> out = validator.validateAndSanitize(List.of(f("weird", "anything")), Map.of());
        assertThat(out).hasSize(1);
        // allowed empty -> values pass through unchanged
        assertThat(out.get(0).getValues()).containsExactly("anything");
        assertThat(out.get(0).getType()).isEqualTo("filter");
    }
}
