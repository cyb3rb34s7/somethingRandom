package com.cms.backend.interceptor;

import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.SecurityUser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Slf4j
public class AuthUserHeaderFilter extends OncePerRequestFilter {

    private ObjectMapper objectMapper = new ObjectMapper();

    public AuthUserHeaderFilter() {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain filterChain
    ) throws ServletException, IOException {
        String authUserHeader = request.getHeader("X-AUTH-USER");
        // Skip MDC operations for /admin/ping endpoint
        if ("/admin/ping".equals(request.getRequestURI())) {
            filterChain.doFilter(request, response);
            return;
        }
        if (authUserHeader != null) {
            String allUser = request.getHeader("X-ALL-USERS");
            Map<String, String> allUsers = new HashMap<>();
            if (allUser != null) {
                allUsers = objectMapper.readValue(
                    allUser, new TypeReference<Map<String, String>>() {
                    });
            }
            SecurityUser user = objectMapper.readValue(authUserHeader, SecurityUser.class);
            user.setAllUsers(allUsers);

            // Set the user in our custom context instead of Spring Security context
            AuthenticatedUser.setCurrentUser(user);
        } else {
            // Fail-closed: reject requests without X-AUTH-USER header
            log.warn("No X-AUTH-USER header found for request: {} {}", request.getMethod(),
                request.getRequestURI());
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Missing authentication header");
            return;
        }

        try {
            filterChain.doFilter(request, response);
        } finally {
            // Clear the user context after the request is processed
            AuthenticatedUser.clearContext();
        }
    }
}
