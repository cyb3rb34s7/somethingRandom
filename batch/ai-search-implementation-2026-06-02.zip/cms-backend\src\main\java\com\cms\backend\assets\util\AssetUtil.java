package com.cms.backend.assets.util;

import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.enums.AssetStatus;
import com.cms.backend.common.enums.AssetTypes;
import java.util.Comparator;
import java.util.List;

public class AssetUtil {

    public static void sortAssets(List<VodAssetDto> vodAssetDtoList, String status) {
        if (AssetStatus.REVOKED.value.equalsIgnoreCase(status)) {
            vodAssetDtoList.sort(REVOKED_ORDER_COMPARATOR);
        } else if (List.of(AssetStatus.QC_PASS.value, AssetStatus.TEMP_QC_PASS.value,
            AssetStatus.SMF_IMPORTED.value).contains(status)) {
            vodAssetDtoList.sort(QC_PASS_ORDER_COMPARATOR);
        }
    }

    // Static comparators for hierarchical ordering
    private static final Comparator<VodAssetDto> REVOKED_ORDER_COMPARATOR =
        Comparator.comparing(asset -> {
            if (AssetTypes.EPISODE.value.equalsIgnoreCase(asset.getType())) {
                return 0; // Episodes first for REVOKED
            } else if (AssetTypes.SEASON.value.equalsIgnoreCase(asset.getType())) {
                return 1; // Seasons second
            } else if (AssetTypes.SHOW.value.equalsIgnoreCase(asset.getType())) {
                return 2; // Shows last
            } else {
                return 3; // Other asset types last
            }
        });

    private static final Comparator<VodAssetDto> QC_PASS_ORDER_COMPARATOR =
        Comparator.comparing(asset -> {
            if (AssetTypes.SHOW.value.equalsIgnoreCase(asset.getType())) {
                return 0; // Shows first for QC_PASS
            } else if (AssetTypes.SEASON.value.equalsIgnoreCase(asset.getType())) {
                return 1; // Seasons second
            } else if (AssetTypes.EPISODE.value.equalsIgnoreCase(asset.getType())) {
                return 2; // Episodes last (but handled specially)
            } else {
                return 3; // Other asset types last
            }
        });

}
