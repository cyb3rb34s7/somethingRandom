package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = StatusUpdateDtoTest.class)
class StatusUpdateDtoTest {

    @Test
    void testStatusUpdateDto() {
        // Create a list of AssetKeyDto objects
        List<AssetKeyDto> assetList = Arrays.asList(
            AssetKeyDto.builder().build(),
            AssetKeyDto.builder().build()
        );

        // Create a StatusUpdateDto object with the asset list and status
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(assetList)
            .status("active")
            .build();

        // Verify that the asset list and status are set correctly
        assertNotNull(statusUpdateDto.getAssetList());
        assertEquals(2, statusUpdateDto.getAssetList().size());
        assertEquals("active", statusUpdateDto.getStatus());

        // Verify that the DTO can be built using the builder pattern
        StatusUpdateDto dtoFromBuilder = StatusUpdateDto.builder()
            .assetList(assetList)
            .status("inactive")
            .build();
        assertNotNull(dtoFromBuilder.getAssetList());
        assertEquals(2, dtoFromBuilder.getAssetList().size());
        assertEquals("inactive", dtoFromBuilder.getStatus());

        // Verify that the DTO can be created using the no-args constructor and setters
        StatusUpdateDto dtoFromSetters = new StatusUpdateDto();
        dtoFromSetters.setAssetList(assetList);
        dtoFromSetters.setStatus("active");
        assertNotNull(dtoFromSetters.getAssetList());
        assertEquals(2, dtoFromSetters.getAssetList().size());
        assertEquals("active", dtoFromSetters.getStatus());
    }
}