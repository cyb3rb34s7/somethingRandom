package com.cms.backend.assets.aisearch.util;

import com.cms.backend.assets.aisearch.constant.AiSearchConstants;
import com.cms.backend.assets.aisearch.exception.LlmGatewayException;
import com.cms.backend.assets.aisearch.model.llm.LlmChatRequest;
import com.cms.backend.assets.aisearch.model.llm.LlmChatResponse;
import com.cms.backend.assets.aisearch.model.llm.LlmMessage;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
@Slf4j
public class LlmGatewayHttpClient {

    private final RestTemplate restTemplate; // shared bean: pool + timeouts + TraceId interceptor

    @Value("${LLM_SERVER_URL}")
    private String llmServerUrl;

    public String complete(String systemPrompt, String userQuery) {
        LlmChatRequest body = new LlmChatRequest(
                List.of(new LlmMessage("system", systemPrompt), new LlmMessage("user", userQuery)),
                false);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        try {
            ResponseEntity<LlmChatResponse> resp = restTemplate.exchange(
                    llmServerUrl + AiSearchConstants.CHAT_ENDPOINT,
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    LlmChatResponse.class);

            LlmChatResponse r = resp.getBody();
            if (r == null || !r.isSuccess() || r.getData() == null || r.getData().getContent() == null) {
                String msg = (r != null && r.getError() != null) ? r.getError().getMessage() : "Empty LLM response";
                throw new LlmGatewayException("LLM gateway returned no usable content: " + msg);
            }
            return r.getData().getContent();
        } catch (RestClientException e) {
            throw new LlmGatewayException("LLM gateway call failed: " + e.getMessage(), e);
        }
    }
}
