const {
  withNativeFederation,
  shareAll,
} = require("@angular-architects/native-federation/config");

module.exports = withNativeFederation({
  name: "cms",

  exposes: {
    "./Interceptors": "./src/app/services/app-interceptor.service.ts",
    "./Routes": "./src/app/app.routes.ts",
    // "./Avatar": "./src/app/components/avatar/avatar.component.ts",
    "./ExcelExportProgressBarComponent":
      "./src/app/features/media-assets/excel-export-progress-bar/excel-export-progress-bar.component.ts",
    "./FeatureContainerComponent":
      "./src/app/components/feature-container/feature-container.component.ts",
    "./LoadingComponent": "./src/app/components/loading/loading.component.ts",
    "./UserManagementComponent":
      "./src/app/features/user-management/user-management.component.ts",
    "./LogoutComponent": "./src/app/components/logout/logout.component.ts",
    "./UserProfileComponent":
      "./src/app/components/user-profile/user-profile.component.ts",
  },

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: "auto",
    }),
  },

  skip: [
    "rxjs/ajax",
    "rxjs/fetch",
    "rxjs/testing",
    "rxjs/webSocket",
    "ajv",
    // Add further packages you don't need at runtime
  ],

  // Please read our FAQ about sharing libs:
  // https://shorturl.at/jmzH0
});
