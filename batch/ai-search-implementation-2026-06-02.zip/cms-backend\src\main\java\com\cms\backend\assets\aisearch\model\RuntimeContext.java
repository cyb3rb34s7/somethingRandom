package com.cms.backend.assets.aisearch.model;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class RuntimeContext {

    private List<String> countries = new ArrayList<>();
    private List<String> providers = new ArrayList<>();
}
