package com.cms.backend.common.util;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.*;
import com.nimbusds.jwt.*;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class JwtEncryptionUtil {


    @Value("${SECRET_KEY}")
    private String secretKey;


    public String encrypt(Map<String, Object> inputObj, String keyName) throws Exception {
        JWTClaimsSet claims = new JWTClaimsSet.Builder()
            .claim(keyName, inputObj)
            .issueTime(new Date())
            .build();

        JWEHeader header = new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A256GCM)
            .contentType("JWT")
            .build();

        EncryptedJWT jwt = new EncryptedJWT(header, claims);

        DirectEncrypter encrypter = new DirectEncrypter(secretKey.getBytes(StandardCharsets.UTF_8));
        jwt.encrypt(encrypter);

        return jwt.serialize();
    }

    // Decrypt JWT back into user details
    public Map<String, Object> decrypt(String encryptedToken, String keyName)
        throws Exception {
        EncryptedJWT jwt = EncryptedJWT.parse(encryptedToken);

        DirectDecrypter decrypter = new DirectDecrypter(secretKey.getBytes(StandardCharsets.UTF_8));

        jwt.decrypt(decrypter);

        return jwt.getJWTClaimsSet().getJSONObjectClaim(keyName);
    }
}