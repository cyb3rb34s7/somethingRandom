package com.cms.backend.assets.service;


import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.LicenseWindowDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.AssetTypeNGenresMap;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.common.util.ResponseHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

class ValidationAssetTest {

    public List<RatingsDto> ratingList = new ArrayList<>();
    public VodAssetDto vodAssetDto;
    private ValidationAsset validationAsset;
    private AssetTypeNGenresMap assetTypeNGenresMap;
    private HttpMethodHandler httpMethodHandler;
    private RegionEndpointService regionEndpointService;

    // Helper method to create a genre map for testing
    private HashMap<String, String> createGenreMap(String... genres) {
        HashMap<String, String> genreMap = new HashMap<>();
        for (String genre : genres) {
            genreMap.put(genre.toLowerCase(), genre);
        }
        return genreMap;
    }

    // Helper method to set up common mock expectations
    private void setupCommonMocks() {
        when(assetTypeNGenresMap.initializeGenresMapping()).thenReturn(new HashMap<>());
        when(assetTypeNGenresMap.initializeGenresMusicMapping()).thenReturn(new HashMap<>());
    }

    // Helper method to set up genre mocks with specific genres
    private void setupGenreMocks(HashMap<String, String> genresEnum) {
        when(assetTypeNGenresMap.initializeGenresMapping()).thenReturn(genresEnum);
        when(assetTypeNGenresMap.initializeGenresMusicMapping()).thenReturn(new HashMap<>());
    }

    // Helper method to set up music genre mocks with specific genres
    private void setupMusicGenreMocks(HashMap<String, String> genresEnum) {
        when(assetTypeNGenresMap.initializeGenresMapping()).thenReturn(new HashMap<>());
        when(assetTypeNGenresMap.initializeGenresMusicMapping()).thenReturn(genresEnum);
    }

    // Helper method to create a basic VodAssetDto for testing
    private VodAssetDto createTestVodAssetDto() {
        return VodAssetDto.builder()
            .contentPartner("abcd")
            .contentId("content")
            .countryCode("AA")
            .vcCpId("vcCpId")
            .type("episode")
            .seasonId("abc")
            .showId("abc")
            .releaseDate("2023-01-01")
            .availableStarting("2024-09-05 00:00:00")
            .expiryDate("2024-09-06 00:00:00")
            .ratings("ALL")
            .ratingBody("KCSC")
            .seasonNo(5)
            .genres("ambient")
            .build();
    }

    @BeforeEach
    public void setUp() {
        assetTypeNGenresMap = mock(AssetTypeNGenresMap.class);
        httpMethodHandler = mock(HttpMethodHandler.class);
        regionEndpointService = mock(RegionEndpointService.class);
        validationAsset = new ValidationAsset(assetTypeNGenresMap, httpMethodHandler,
            regionEndpointService);

        // Use helper method to create VodAssetDto
        vodAssetDto = createTestVodAssetDto();

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("ALL")).type("music")
            .countryCode("AA").organization("KCSC").build();
        ratingList.add(ratingDto);
        ratingDto = RatingsDto.builder().parentalRatings(List.of("ALL")).type("episode")
            .countryCode("AA").organization("KCSC").build();
        ratingList.add(ratingDto);
        ratingDto = RatingsDto.builder().parentalRatings(List.of("ALL")).type("singlevod")
            .countryCode("AA").organization("KCSC").build();
        ratingList.add(ratingDto);
        ratingDto = RatingsDto.builder().parentalRatings(List.of("ALL")).type("show")
            .countryCode("AA").organization("KCSC").build();
        ratingList.add(ratingDto);
    }

    @Test
    void testValidateInvalidType() {
        setupCommonMocks();
        vodAssetDto.setType("falseType");
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateNormalInputMusic() {
        HashMap<String, String> genresEnum = new HashMap<>();
        genresEnum.put("afro", "Afro");
        genresEnum.put("ambient", "Ambient");
        vodAssetDto.setType("music");
        setupMusicGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateNormalInputSetGenres() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Action,Arts/Culture");
        HashMap<String, String> genresEnum = new HashMap<>();
        genresEnum.put("action", "Action");
        genresEnum.put("arts/culture", "Arts/Culture");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateInvalidGenresOfMusic() {
        setupCommonMocks();
        vodAssetDto.setGenres("invalid");
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateInvalidGenresOfMusicEmpty() {
        setupCommonMocks();
        vodAssetDto.setType(Constants.MUSIC);
        vodAssetDto.setGenres("invalid");
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateInvalidReleaseDate() {
        vodAssetDto.setReleaseDate("invalidReleaseDate");
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateInvalidTypeNull() {
        vodAssetDto.setType(null);
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateInvalidGenresNull() {
        vodAssetDto.setGenres(null);
        vodAssetDto.setRatings(null);
        vodAssetDto.setRatingBody(null);
        vodAssetDto.setReleaseDate(null);
        vodAssetDto.setSeasonId(null);
        vodAssetDto.setShowId(null);
        vodAssetDto.setAvailableStarting(null);
        vodAssetDto.setExpiryDate(null);
        setupCommonMocks();
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testAvailableStartingAndExpiryFalse() {
        vodAssetDto.setAvailableStarting("2024-09-05 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-04 00:00:00");
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testAvailableStartingAndExpiryTrueOneNullCase() {
        vodAssetDto.setAvailableStarting(null);
        vodAssetDto.setExpiryDate("2024-09-04 00:00:00");
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testAvailableStartingFalse() {
        vodAssetDto.setAvailableStarting("2024-09-05T00:00");
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testExpiryDateFalse() {
        vodAssetDto.setExpiryDate("2024-09-05T00:00");
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testSeasonIdFalse() {
        vodAssetDto.setSeasonId("*****");
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testShowIdIdFalse() {
        vodAssetDto.setShowId("*****");
        setupCommonMocks();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void lengthValidationOfAsset() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5000; i++) {
            sb.append('a');
        }
        sb.append('b');
        String str = sb.toString();
        VodAssetDto.VodAssetDtoBuilder builder = VodAssetDto.builder();
        builder.contentPartner(str);
        builder.contentId(str);
        builder.countryCode(str);
        builder.vcCpId(str);
        builder.type(str);
        builder.seasonId(str);
        builder.showId(str);
        builder.releaseDate(str);
        builder.availableStarting(str);
        builder.expiryDate(str);
        builder.ratings(str);
        builder.seasonNo(2);
        builder.description(str);
        builder.genres(str);
        builder.mainTitle(str);
        builder.artist(str);
        builder.starring(str);
        builder.director(str);
        vodAssetDto = builder.build();
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }


    @Test
    void testRatingsFalse() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        vodAssetDto.setRatings("qqq");
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testReleaseDateFalse() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        vodAssetDto.setReleaseDate("sa");
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testExternalIdTrue() {
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("abc").idProvider("abc").idType("abc").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("abc").countryCode("AA")
            .vcCpId("vc").type("episode").build();
        vodAssetDto.setExternalProvider(List.of(externalProviderDto));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ResponseHandler.processMethodResponse("externalIds",
                List.of("abc"))));
        assertDoesNotThrow(() -> {
            validationAsset.validateAssetExternalField(vodAssetDto);
        });
    }

    @Test
    void testExternalIdEmpty() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("abc").countryCode("AA")
            .vcCpId("vc").type("episode").build();
        vodAssetDto.setExternalProvider(List.of());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ResponseHandler.processMethodResponse("externalIds",
                List.of())));
        assertDoesNotThrow(() -> {
            validationAsset.validateAssetExternalField(vodAssetDto);
        });
    }

    
    @Test
    void testValidateArtistValid() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring("abc");
        vodAssetDto.setArtist("abc");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateArtistLengthCheck() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1005; i++) {
            sb.append("a");
        }
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring("abc");
        vodAssetDto.setArtist(sb.toString());
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }


    @Test
    void testValidateDirectorValid() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring("abc");
        vodAssetDto.setArtist("abc");
        vodAssetDto.setDirector("abc");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateDirectorLengthCheck() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1005; i++) {
            sb.append("a");
        }
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring("abc");
        vodAssetDto.setArtist("abc");
        vodAssetDto.setDirector(sb.toString());

        setupGenreMocks(createGenreMap("crime"));
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }


    @Test
    void testValidateStarringValid() {
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring("abc");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testValidateStarringLengthCheck() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1005; i++) {
            sb.append("a");
        }
        vodAssetDto.setType("episode");
        vodAssetDto.setGenres("Crime");
        vodAssetDto.setAvailableStarting("2024-09-12 00:00:00");
        vodAssetDto.setExpiryDate("2024-09-13 00:00:00");
        vodAssetDto.setStarring(sb.toString());
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertFalse(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testRatingsOfSingleVod() {
        vodAssetDto.setType("singlevod");
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(vodAssetDto, ratingList));
    }

    @Test
    void testRatingsNull() {
        vodAssetDto.setType("episode");
        vodAssetDto.setRatings(null);
        vodAssetDto.setRatingBody(null);
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        vodAssetDto.setExternalIdProvider("test");
        vodAssetDto.setExternalIdType("tmsId");
        vodAssetDto.setExternalId("test1");
        vodAssetDto.setExternalProvider(List.of(
            ExternalProviderDto.builder().externalProgramId("test").idProvider("AA").idType("tmsId")
                .provider("tms").build()));
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("abce").idProvider("abc").idType("abc").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("abc").countryCode("AA")
            .vcCpId("vc").type("episode").build();
        vodAssetDto.setExternalProvider(List.of(externalProviderDto));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ResponseHandler.processMethodResponse("externalIds",
                List.of())));
        setupGenreMocks(genresEnum);
        assertTrue(validationAsset.validate(this.vodAssetDto, ratingList));
    }

    @Test
    void testExternalFalse() {
        vodAssetDto.setType("episode");
        vodAssetDto.setRatings(null);
        vodAssetDto.setRatingBody(null);
        vodAssetDto.setGenres("Crime");
        HashMap<String, String> genresEnum = createGenreMap("crime");
        vodAssetDto.setExternalIdProvider("test");
        vodAssetDto.setExternalIdType("tmsId");

        vodAssetDto.setExternalProvider(List.of(
            ExternalProviderDto.builder().externalProgramId("test").idProvider("AA").idType("tmsId")
                .provider("tms").build()));
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("abce").idProvider("abc").idType("abc").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("abc").countryCode("AA")
            .vcCpId("vc").type("episode").build();
        vodAssetDto.setExternalProvider(List.of(externalProviderDto));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ResponseHandler.processMethodResponse("externalIds",
                List.of("abc"))));
        setupGenreMocks(genresEnum);
        assertFalse(validationAsset.validate(this.vodAssetDto, ratingList));
    }

    @Test
    void testValidateNonOverlappingLicenseWindow() {
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(
            LicenseWindowDto.builder().availableStarting("1").availableEnding("2").build());
        licenseWindowDtos.add(
            LicenseWindowDto.builder().availableStarting("3").availableEnding("4").build());
        assertDoesNotThrow(() -> {
            validationAsset.validateNonOverlappingWindows(licenseWindowDtos,
                Comparator.comparing(LicenseWindowDto::getAvailableStarting),
                LicenseWindowDto::getAvailableStarting,
                LicenseWindowDto::getAvailableEnding,
                "License");
        });
    }

    @Test
    void testValidateNonOverlappingEventWindow() {
        List<AssetEventWindowDto> assetEventWindowDtos = new ArrayList<>();
        assetEventWindowDtos.add(
            AssetEventWindowDto.builder().eventStarting("1").eventEnding("2").build());
        assetEventWindowDtos.add(
            AssetEventWindowDto.builder().eventStarting("3").eventEnding("4").build());
        assertDoesNotThrow(() -> {
            validationAsset.validateNonOverlappingWindows(assetEventWindowDtos,
                Comparator.comparing(AssetEventWindowDto::getEventStarting),
                AssetEventWindowDto::getEventStarting,
                AssetEventWindowDto::getEventEnding,
                "Event");
        });
    }

    @Test
    void testValidateNonOverlappingLicenseWindowNull() {
        assertDoesNotThrow(() -> {
            validationAsset.validateNonOverlappingWindows(null,
                Comparator.comparing(LicenseWindowDto::getAvailableStarting),
                LicenseWindowDto::getAvailableStarting,
                LicenseWindowDto::getAvailableEnding,
                "License");
        });
    }

    @Test
    void nullList_ReturnsTrue() {
        assertTrue(validationAsset.validateLengthsOfListElements(null, 5));
    }

    @Test
    void emptyList_ReturnsTrue() {
        assertTrue(validationAsset.validateLengthsOfListElements(new ArrayList<>(), 5));
    }

    @Test
    void allElementsWithinLimit_ReturnsTrue() {
        List<String> values = Arrays.asList("a", "ab", "abc");
        assertTrue(validationAsset.validateLengthsOfListElements(values, 3));
    }

    @Test
    void oneElementExceedsLimit_ReturnsFalse() {
        List<String> values = Arrays.asList("a", "ab", "abcd");
        assertFalse(validationAsset.validateLengthsOfListElements(values, 3));
    }

    @Test
    void multipleElementsOneExceeds_ReturnsFalse() {
        List<String> values = Arrays.asList("valid", "another", "too long");
        assertFalse(validationAsset.validateLengthsOfListElements(values, 5));
    }

    @Test
    void elementExactlyAtLimit_ReturnsTrue() {
        List<String> values = Arrays.asList("abcde");
        assertTrue(validationAsset.validateLengthsOfListElements(values, 5));
    }

    @Test
    void nullElementInList_ThrowsNPE() {
        List<String> values = Arrays.asList("a", null, "b");
        assertThrows(NullPointerException.class, () ->
            validationAsset.validateLengthsOfListElements(values, 5)
        );
    }


}
