import { Component } from '@angular/core';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { pageMap } from '../../../../interfaces/dev-console-routes-data';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-sqs-management',
    imports: [MatButtonModule, MatTooltipModule],
    templateUrl: './sqs-management.component.html',
    styleUrl: './sqs-management.component.scss'
})
export class SqsManagementComponent {
  constructor(private router: Router) {}
  // pageMap: pageMap = {
  //   'vod-status-updater': {
  //     imageSrc: 'assets/icons/svgs/api-management.webp',
  //     title: SIDE_NAV_ROUTES.VOD_STATUS_UPDATE.title,
  //     routeTo: SIDE_NAV_ROUTES.VOD_STATUS_UPDATE.route_link,
  //     imageAlt: '',
  //     description: '',
  //   },
  // };
  pageMap: pageMap = {
    'invalid-asset': {
      title: SIDE_NAV_ROUTES.INVALID_ASSETS.title,
      description: 'Get the list of invalid assets ',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      imageAlt: SIDE_NAV_ROUTES.INVALID_ASSETS.title,
      routeTo: SIDE_NAV_ROUTES.INVALID_ASSETS.route_link,
    },
    'sqs-management': {
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.SQS_MANAGEMENT.title,
      routeTo: SIDE_NAV_ROUTES.SQS_MANAGEMENT.route_link,
      imageAlt: '',
      description: '',
    },
    'invalid-licence-assets': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.INVALID_LICENSE_ASSETS.title,
      routeTo: SIDE_NAV_ROUTES.INVALID_LICENSE_ASSETS.route_link,
      description: ' ',
    },
    'tech-integrator-management': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.TECH_INTEGRATOR_MANAGEMENT.title,
      routeTo: SIDE_NAV_ROUTES.TECH_INTEGRATOR_MANAGEMENT.route_link,
      description: ' ',
    },
    'api-access-control': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.UPDATE_MENU.title,
      routeTo: SIDE_NAV_ROUTES.UPDATE_MENU.route_link,
      description: ' ',
    },
    'control-queue-urls': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.CONTROL_QUEUE_URLS.title,
      routeTo: SIDE_NAV_ROUTES.CONTROL_QUEUE_URLS.route_link,
      description: ' ',
    },
    'stg-prd-asset-comparison': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/api-management.webp',
      title: SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.title,
      routeTo: SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.route_link,
      description: '',
    },
  };

  pageKeys = Object.keys(this.pageMap);

  navigateTo(route: string) {
    this.router.navigate([route]);
  }
  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }
}
