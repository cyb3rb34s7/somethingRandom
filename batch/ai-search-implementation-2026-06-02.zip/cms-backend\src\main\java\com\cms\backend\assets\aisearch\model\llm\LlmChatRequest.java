package com.cms.backend.assets.aisearch.model.llm;

import java.util.List;

public record LlmChatRequest(List<LlmMessage> messages, boolean stream) {
}
