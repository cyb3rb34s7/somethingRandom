package com.cms.backend.assets.mapper;

import com.cms.backend.assets.model.VodAssetDto;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper

public interface AssetMapper {

    List<VodAssetDto> getSuccessfulAssets(String userId, String region, String sessionId);

    void insert(VodAssetDto vodAssetDto);

    void cleanAssetsByUserId(String userId, String region);

    void deleteEditAsset(VodAssetDto vodAssetDto);

    List<VodAssetDto> getImportedAssetsByUserId(String userId, String region, String sessionId);
}
