package com.cms.backend.evaluation.service.impl;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.assets.model.PaginationDto;
import com.cms.backend.assets.service.AssetExportService;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.evaluation.model.FilterRequestDto;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

@SpringBootTest(classes = ComparisonServiceImplTest.class)
class ComparisonServiceImplTest {

        @InjectMocks
        ComparisonServiceImpl comparisonService;

        @Mock
        RegionEndpointService regionEndpointService;
        @Mock
        HttpMethodHandler httpMethodHandler;
        @Mock
        AssetExportService assetExportService;

        @Test
        void getProgramListTest() {
                FilterRequestDto filterRequestDto = FilterRequestDto.builder()
                                .filters(List.of(new FilterDto()))
                                .pagination(new PaginationDto())
                                .build();

                ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
                                ResponseDto.builder().rsp(new BaseResponseDto()).build());
                when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(),
                                any())).thenReturn(responseEntity);

                assertDoesNotThrow(() -> {
                        comparisonService.getProgramList(filterRequestDto);
                });
        }

        @Test
        void getFilterListTest() {
                ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
                                ResponseDto.builder().rsp(new BaseResponseDto()).build());
                when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(),
                                any())).thenReturn(responseEntity);
                assertDoesNotThrow(() -> {
                        comparisonService.getFilterList();
                });
        }

        @Test
        void getDetailTest() {
                String finalUrl = "http://test:8080" + Constants.GET_EVALUATION_ASSET_VIEW;
                UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(finalUrl);
                builder.queryParam(Constants.CONTENT_ID, "test");
                builder.queryParam(Constants.CP_ID, "test");

                ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
                                ResponseDto.builder().rsp(new BaseResponseDto()).build());
                when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(),
                                any())).thenReturn(responseEntity);

                // Act
                assertDoesNotThrow(() -> {
                        comparisonService.getDetail("test", "test");
                });
        }

        @Test
        void getCountTest() {
                FilterRequestDto filterRequestDto = FilterRequestDto.builder()
                                .filters(List.of(new FilterDto()))
                                .pagination(new PaginationDto())
                                .build();

                ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
                                ResponseDto.builder().rsp(new BaseResponseDto()).build());
                when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(),
                                any())).thenReturn(responseEntity);

                assertDoesNotThrow(() -> {
                        comparisonService.getProgramList(filterRequestDto);
                });
        }

        @Test
        void exportDataTest() throws IOException {
                AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder()
                                .filters(List.of(new FilterDto()))
                                .build();

                // Mock the assetExportService to return a valid ExportHelperDto
                ExportHelperDto mockExportHelperDto = ExportHelperDto.builder()
                                .excelData(new byte[0])
                                .fileName("test.xlsx")
                                .fileType("EXCEL")
                                .build();
                when(assetExportService.startExport(any(AssetFilterBodyDto.class), any(Boolean.class)))
                                .thenReturn(mockExportHelperDto);

                assertDoesNotThrow(() -> {
                        comparisonService.startExport(assetFilterBodyDto);
                });
        }

}
