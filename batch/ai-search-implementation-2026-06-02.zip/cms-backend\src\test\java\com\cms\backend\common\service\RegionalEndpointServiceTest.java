package com.cms.backend.common.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.backend.assets.configuration.S3Config;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.SecurityUser;
import java.lang.reflect.Field;
import java.util.HashMap;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;


@SpringBootTest(classes = RegionalEndpointServiceTest.class)
@TestPropertySource("classpath:application-test.properties")
class RegionalEndpointServiceTest {

    @InjectMocks
    private RegionEndpointService regionEndpointService;

    @Mock
    AuthenticatedUser user;

    @Mock
    S3Config s3Config;

    @Value("${US_ASSET_OPENAPI_URL}")
    private String assetManagementUSOpenApiUrl;
    @Value("${EU_ASSET_OPENAPI_URL}")
    private String assetManagementEUOpenApiUrl;

    @Value("${US_ASSET_OPENAPI_URL_PRD:#{null}}")
    private String assetManagementUSOpenApiUrlPrd;

    @Value("${EU_ASSET_OPENAPI_URL_PRD:#{null}}")
    private String assetManagementEUOpenApiUrlPrd;

    @Value("${US_ASSET_OPENAPI_URL_NLB}")
    private String assetManagementUSOpenApiUrlNlb;
    @Value("${EU_ASSET_OPENAPI_URL_NLB}")
    private String assetManagementEUOpenApiUrlNlb;

    @Value("${US_HISTORY_OPENAPI_URL}")
    private String historyManagementUSOpenApiUrl;
    @Value("${EU_HISTORY_OPENAPI_URL}")
    private String historyManagementEUOpenApiUrl;

    @Value("${US_SYNC_QUEUE_URL}")
    private String syncQueueUSUrl;
    @Value("${EU_SYNC_QUEUE_URL}")
    private String syncQueueEUUrl;

    @Value("${US_EXIF_URL}")
    private String usExifUrl;
    @Value("${EU_EXIF_URL}")
    private String euExifUrl;

    @Value("${US_BUCKET_NAME}")
    private String usBucketName;
    @Value("${EU_BUCKET_NAME}")
    private String euBucketName;


    @Value("${US_CLOUD_FRONT_URL}")
    private String usCloudFrontUrl;
    @Value("${EU_CLOUD_FRONT_URL}")
    private String euCloudFrontUrl;

    @Value("${US_CLOUD_FRONT_URL_CMS}")
    private String usCloudFrontUrlCms;
    @Value("${EU_CLOUD_FRONT_URL_CMS}")
    private String euCloudFrontUrlCms;

    @Value("${US_UPLOAD_PATH}")
    private String usUploadPath;
    @Value("${EU_UPLOAD_PATH}")
    private String euUploadPath;

    @Value("${US_VOD_STATUS_UPDATER_SQS_URL}")
    private String usVodStatusUpdaterSqsUrl;
    @Value("${EU_VOD_STATUS_UPDATER_SQS_URL}")
    private String euVodStatusUpdaterSqsUrl;

    @Value("${ROLE_ARN}")
    private String roleArn;

    SecurityUser euTestSecurityUser = new SecurityUser("2d4xazvqzj",
        "EU", "test", "", new HashMap<>());

    SecurityUser usTestSecurityUser = new SecurityUser("2d4xazvqzj",
        "US", "test", "", new HashMap<>());

    @Test
    void EuUserEndpointTest() {
        setFieldInRegionalEndpointService("assetManagementEUOpenApiUrl",
            assetManagementEUOpenApiUrl);
        setFieldInRegionalEndpointService("assetManagementEUOpenApiUrlNlb",
            assetManagementEUOpenApiUrlNlb);
        setFieldInRegionalEndpointService("historyManagementEUOpenApiUrl",
            historyManagementEUOpenApiUrl);
        setFieldInRegionalEndpointService("syncQueueEUUrl",
            syncQueueEUUrl);
        setFieldInRegionalEndpointService("euExifUrl",
            euExifUrl);
        setFieldInRegionalEndpointService("euCloudFrontUrl",
            euCloudFrontUrl);
        setFieldInRegionalEndpointService("euBucketName",
            euBucketName);
        setFieldInRegionalEndpointService("euUploadPath",
            euUploadPath);
        setFieldInRegionalEndpointService("assetManagementEUOpenApiUrlPrd",
            assetManagementEUOpenApiUrlPrd);
        setFieldInRegionalEndpointService("euCloudFrontUrlCms",
            euCloudFrontUrlCms);
        setFieldInRegionalEndpointService("euVodStatusUpdaterSqsUrl",
            euVodStatusUpdaterSqsUrl);

        Mockito.when(user.getUserInfo()).thenReturn(euTestSecurityUser);

        boolean responseMatched = true;
        responseMatched &= assetManagementEUOpenApiUrl.equals(
            regionEndpointService.getOpenAPIEndpoint());
        responseMatched &= assetManagementEUOpenApiUrlNlb.equals(
            regionEndpointService.getOpenAPIEndpointNLB());
        responseMatched &= historyManagementEUOpenApiUrl.equals(
            regionEndpointService.getHistoryAPIEndpoint());
        responseMatched &= syncQueueEUUrl.equals(regionEndpointService.getSQSEndpoint());
        responseMatched &= euExifUrl.equals(regionEndpointService.getExifEndpoint());
        responseMatched &= euCloudFrontUrl.equals(regionEndpointService.getCloudFrontUrl());
        responseMatched &= euBucketName.equals(regionEndpointService.getBucketName());
        responseMatched &= euUploadPath.equals(regionEndpointService.getUploadPath());
        responseMatched &= assetManagementEUOpenApiUrlPrd.equals(
            regionEndpointService.getOpenAPIEndpointPRD());
        responseMatched &= euCloudFrontUrlCms.equals(regionEndpointService.getCloudFrontUrlCms());
        responseMatched &= euVodStatusUpdaterSqsUrl.equals(
            regionEndpointService.getStatusUpdaterSQSLink());
        assertTrue(responseMatched);
    }

    @Test
    void NullUserEndpointTest() {
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrl",
            assetManagementUSOpenApiUrl);
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrlNlb",
            assetManagementUSOpenApiUrlNlb);
        setFieldInRegionalEndpointService("historyManagementUSOpenApiUrl",
            historyManagementUSOpenApiUrl);
        setFieldInRegionalEndpointService("syncQueueUSUrl",
            syncQueueUSUrl);
        setFieldInRegionalEndpointService("usExifUrl",
            usExifUrl);
        setFieldInRegionalEndpointService("usCloudFrontUrl",
            usCloudFrontUrl);
        setFieldInRegionalEndpointService("usBucketName",
            usBucketName);
        setFieldInRegionalEndpointService("usUploadPath",
            usUploadPath);
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrlPrd",
            assetManagementUSOpenApiUrlPrd);
        setFieldInRegionalEndpointService("usCloudFrontUrlCms",
            usCloudFrontUrlCms);
        setFieldInRegionalEndpointService("usVodStatusUpdaterSqsUrl",
            usVodStatusUpdaterSqsUrl);

        boolean responseMatched = true;

        responseMatched &= assetManagementUSOpenApiUrl.equals(
            regionEndpointService.getOpenAPIEndpoint());
        responseMatched &= assetManagementUSOpenApiUrlNlb.equals(
            regionEndpointService.getOpenAPIEndpointNLB());
        responseMatched &= historyManagementUSOpenApiUrl.equals(
            regionEndpointService.getHistoryAPIEndpoint());
        responseMatched &= syncQueueUSUrl.equals(regionEndpointService.getSQSEndpoint());
        responseMatched &= usExifUrl.equals(regionEndpointService.getExifEndpoint());
        responseMatched &= usCloudFrontUrl.equals(regionEndpointService.getCloudFrontUrl());
        responseMatched &= usBucketName.equals(regionEndpointService.getBucketName());
        responseMatched &= usUploadPath.equals(regionEndpointService.getUploadPath());
        responseMatched &= assetManagementUSOpenApiUrlPrd.equals(
            regionEndpointService.getOpenAPIEndpointPRD());
        responseMatched &= usCloudFrontUrlCms.equals(regionEndpointService.getCloudFrontUrlCms());
        responseMatched &= usVodStatusUpdaterSqsUrl.equals(
            regionEndpointService.getStatusUpdaterSQSLink());
        assertTrue(responseMatched);
    }

    @Test
    void UsUserEndpointTest() {
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrl",
            assetManagementUSOpenApiUrl);
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrlNlb",
            assetManagementUSOpenApiUrlNlb);
        setFieldInRegionalEndpointService("historyManagementUSOpenApiUrl",
            historyManagementUSOpenApiUrl);
        setFieldInRegionalEndpointService("syncQueueUSUrl",
            syncQueueUSUrl);
        setFieldInRegionalEndpointService("usExifUrl",
            usExifUrl);
        setFieldInRegionalEndpointService("usCloudFrontUrl",
            usCloudFrontUrl);
        setFieldInRegionalEndpointService("usBucketName",
            usBucketName);
        setFieldInRegionalEndpointService("usUploadPath",
            usUploadPath);
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrlPrd",
            assetManagementUSOpenApiUrlPrd);
        setFieldInRegionalEndpointService("usCloudFrontUrlCms",
            usCloudFrontUrlCms);
        setFieldInRegionalEndpointService("usVodStatusUpdaterSqsUrl",
            usVodStatusUpdaterSqsUrl);

        Mockito.when(user.getUserInfo()).thenReturn(usTestSecurityUser);
        boolean responseMatched = true;
        responseMatched &= assetManagementUSOpenApiUrl.equals(
            regionEndpointService.getOpenAPIEndpoint());
        responseMatched &= assetManagementUSOpenApiUrlNlb.equals(
            regionEndpointService.getOpenAPIEndpointNLB());
        responseMatched &= historyManagementUSOpenApiUrl.equals(
            regionEndpointService.getHistoryAPIEndpoint());
        responseMatched &= syncQueueUSUrl.equals(regionEndpointService.getSQSEndpoint());
        responseMatched &= usExifUrl.equals(regionEndpointService.getExifEndpoint());
        responseMatched &= usCloudFrontUrl.equals(regionEndpointService.getCloudFrontUrl());
        responseMatched &= usBucketName.equals(regionEndpointService.getBucketName());
        responseMatched &= usUploadPath.equals(regionEndpointService.getUploadPath());
        responseMatched &= assetManagementUSOpenApiUrlPrd.equals(
            regionEndpointService.getOpenAPIEndpointPRD());
        responseMatched &= usCloudFrontUrlCms.equals(regionEndpointService.getCloudFrontUrlCms());
        responseMatched &= usVodStatusUpdaterSqsUrl.equals(
            regionEndpointService.getStatusUpdaterSQSLink());
        assertTrue(responseMatched);
    }

    @Test
    void getUSOpenAPIEndpointTest() {
        setFieldInRegionalEndpointService("assetManagementUSOpenApiUrl",
            assetManagementUSOpenApiUrl);
        assertEquals(assetManagementUSOpenApiUrl, regionEndpointService.getUSOpenAPIEndpoint());
    }

    @Test
    void getEUOpenAPIEndpointTest() {
        setFieldInRegionalEndpointService("assetManagementEUOpenApiUrl",
            assetManagementEUOpenApiUrl);
        assertEquals(assetManagementEUOpenApiUrl, regionEndpointService.getEUOpenAPIEndpoint());
    }

    private void setFieldInRegionalEndpointService(String fieldName, String value) {
        try {
            Field field = RegionEndpointService.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(regionEndpointService, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setFieldInS3ConfigService(String fieldName, String value) {
        try {
            Field field = S3Config.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(s3Config, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
