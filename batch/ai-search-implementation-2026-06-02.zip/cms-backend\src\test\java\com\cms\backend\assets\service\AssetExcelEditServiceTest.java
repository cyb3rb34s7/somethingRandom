package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetCastDto;
import com.cms.backend.assets.model.AssetLockedFieldDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.ParentalRatingsDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.model.SecurityUser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AssetExcelEditServiceTest {

    @InjectMocks
    private AssetExcelEditService assetExcelEditService;

    @Mock
    private AssetHelperService assetHelperService;

    @Mock
    private AssetAsyncService assetAsyncService;

    @Mock
    private AuthenticatedUser authenticatedUser;

    @Mock
    private AssetMasterDataService assetMasterDataService;

    @BeforeEach
    void setUp() {
        SecurityUser securityUser = new SecurityUser();
        securityUser.setUuid("test-user-id");
        securityUser.setServiceRegion("test-region");
        securityUser.setSessionId("test-session-id");
        lenient().when(authenticatedUser.getUserInfo()).thenReturn(securityUser);
    }

    // ==================== checkRecordExists Tests ====================

    @Test
    void checkRecordExists_P() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Test Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Old Title")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
    }

    @Test
    void checkRecordExists_NotFound_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-2")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertFalse(result);
    }

    @Test
    void checkRecordExists_EmptyList_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        List<VodAssetDto> oldAssets = new ArrayList<>();

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertFalse(result);
    }

    @Test
    void checkRecordExists_StatusFailed_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("archived")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert - Record exists but status validation fails
        assertTrue(result);
        assertNotNull(newAsset.getResult());
    }

    @Test
    void checkRecordExists_TypeFailed_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("EPISODE")
            .status("ready for qc")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert - Record exists but type validation fails
        assertTrue(result);
        assertNotNull(newAsset.getResult());
    }

    @Test
    void checkRecordExists_DeeplinkFailed_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("invalid-json")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
        assertEquals("Deeplink Payload failed", newAsset.getResult());
    }

    @Test
    void checkRecordExists_DeltaTypeFailed_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("tvplus_delta")
            .deltaType("invalid")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
        assertEquals("Delta type failed", newAsset.getResult());
    }

    @Test
    void checkRecordExists_FeedWorkerFailed_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("invalid_worker")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
        assertEquals("Feed Worker failed", newAsset.getResult());
    }

    @Test
    void checkRecordExists_NoChangeInAsset_N() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Same Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Same Title")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
        assertEquals("No change in asset", newAsset.getResult());
    }

    // ==================== setCastForAssetUpload Tests ====================

    @Test
    void setCastForAssetUpload_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .starring("Actor1,Actor2")
            .director("Director1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .cast(List.of(AssetCastDto.builder().role("ACTOR").name("OldActor").build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getCast());
    }

    @Test
    void setCastForAssetUpload_UseOldCast_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .type("MOVIE")
            .starring("NewActor")  // Provide new starring to trigger cast setting
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .cast(List.of(
                AssetCastDto.builder().role("ACTOR").name("OldActor").build(),
                AssetCastDto.builder().role("DIRECTOR").name("OldDirector").build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getCast());
    }

    @Test
    void setCastForAssetUpload_NonMusicType_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .artist("Artist1")
            .type("MOVIE")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, oldAssets);

        // Assert - Artist should not be set for non-music type
        assertNull(asset.getCast());
    }

    @Test
    void setCastForAssetUpload_NullOldAssets_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .starring("Actor1")
            .type("MOVIE")
            .build();

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, null);

        // Assert
        assertNull(asset.getCast());
    }

    @Test
    void setCastForAssetUpload_EmptyOldAssets_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .starring("Actor1")
            .type("MOVIE")
            .build();

        List<VodAssetDto> oldAssets = new ArrayList<>();

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, oldAssets);

        // Assert
        assertNull(asset.getCast());
    }

    @Test
    void setCastForAssetUpload_MusicType_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .artist("Artist1,Artist2")
            .type("MUSIC")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setCastForAssetUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getCast());
    }

    // ==================== setDeeplinkPayloadForExcelAsset Tests ====================

    @Test
    void setDeeplinkPayloadForExcelAsset_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        String deeplinkPayload = "{\"deeplink_data\":{\"ratings\":\"G\"}}";
        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload(deeplinkPayload)
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }

    @Test
    void setDeeplinkPayloadForExcelAsset_EmptyDeeplinkPayload_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload("")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }

    @Test
    void setDeeplinkPayloadForExcelAsset_NullRatings_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }

    @Test
    void setDeeplinkPayloadForExcelAsset_InvalidJson_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload("invalid-json")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }

    // ==================== addHistoryForExcelUpdate Tests ====================

    @Test
    void addHistoryForExcelUpdate_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .mainTitle("New Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .mainTitle("Old Title")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("mainTitle");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_EmptyOldAssets_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .build();

        List<VodAssetDto> oldAssets = new ArrayList<>();
        List<String> columns = List.of("mainTitle");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    // ==================== getRowValue Tests ====================

    @Test
    void getRowValue_HeaderNotInMap_N() {
        // Arrange
        Row row = Mockito.mock(Row.class);
        Map<String, Integer> headerMap = new HashMap<>();

        // Act
        String result = assetExcelEditService.getRowValue(row, 0, headerMap);

        // Assert
        assertNull(result);
    }


    @Test
    void getRowValue_NullCell_N() {
        // Arrange
        Row row = Mockito.mock(Row.class);
        Map<String, Integer> headerMap = new HashMap<>();
        headerMap.put("programid", 0);

        when(row.getCell(0)).thenReturn(null);

        // Act
        String result = assetExcelEditService.getRowValue(row, 0, headerMap);

        // Assert
        assertNull(result);
    }

    // ==================== setExternalIDListForUpload Tests ====================

    @Test
    void setExternalIDListForUpload_WithNewValues_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .externalIdType("type1,type2")
            .externalId("id1,id2")
            .externalIdProvider("provider1,provider2")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getExternalProvider());
    }

    @Test
    void setExternalIDListForUpload_EmptyExternalProvider_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .externalProvider(new ArrayList<>())
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getExternalProvider());
    }

    @Test
    void setExternalIDListForUpload_EmptyOldAssets_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = new ArrayList<>();

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert
        assertNull(asset.getExternalProvider());
    }

    @Test
    void setExternalIDListForUpload_UseOldValues_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();

        ExternalProviderDto oldProvider = ExternalProviderDto.builder()
            .provider("provider1")
            .externalProgramId("ext-id-1")
            .idType("type1")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .externalProvider(List.of(oldProvider))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getExternalProvider());
    }

    // ==================== setRatingListForUpload Tests ====================

    @Test
    void setRatingListForUpload_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratingBody("MPAA,BBFC")
            .ratings("PG-13,12")
            .build();

        // Act
        assetExcelEditService.setRatingListForUpload(asset);

        // Assert
        assertNotNull(asset.getParentalRatings());
    }

    @Test
    void setRatingListForUpload_NullRatingBody_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        // Act
        assetExcelEditService.setRatingListForUpload(asset);

        // Assert
        assertNull(asset.getParentalRatings());
    }

    @Test
    void setRatingListForUpload_NullRatings_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratingBody("MPAA")
            .build();

        // Act
        assetExcelEditService.setRatingListForUpload(asset);

        // Assert
        assertNull(asset.getParentalRatings());
    }

    // ==================== headerValidationOfExcelSheet Tests ====================

    @Test
    void headerValidationOfExcelSheet_EmptySheet_N() {
        // Arrange
        XSSFSheet sheet = Mockito.mock(XSSFSheet.class);
        Map<String, Integer> headerMap = new HashMap<>();

        when(sheet.iterator()).thenReturn(new ArrayList<Row>().iterator());

        // Act
        boolean result = assetExcelEditService.headerValidationOfExcelSheet(sheet, headerMap);

        // Assert
        assertTrue(result);
    }

    @Test
    void headerValidationOfExcelSheet_InvalidHeader_N() {
        // Arrange
        XSSFSheet sheet = Mockito.mock(XSSFSheet.class);
        Row row = Mockito.mock(Row.class);
        org.apache.poi.ss.usermodel.Cell cell = Mockito.mock(org.apache.poi.ss.usermodel.Cell.class);

        Map<String, Integer> headerMap = new HashMap<>();

        when(sheet.iterator()).thenReturn(List.of(row).iterator());
        when(row.cellIterator()).thenReturn(List.of(cell).iterator());

        // Act & Assert - Invalid header should return false
        assertDoesNotThrow(() -> assetExcelEditService.headerValidationOfExcelSheet(sheet, headerMap));
    }


    // ==================== emptyRowCheckInExcel Tests ====================

    @Test
    void emptyRowCheckInExcel_AllFieldsPresent_P() {
        // Act
        boolean result = assetExcelEditService.emptyRowCheckInExcel("content-1", "US", "cp-1");

        // Assert
        assertFalse(result);
    }

    @Test
    void emptyRowCheckInExcel_NullContentId_N() {
        // Act
        boolean result = assetExcelEditService.emptyRowCheckInExcel(null, "US", "cp-1");

        // Assert
        assertTrue(result);
    }

    @Test
    void emptyRowCheckInExcel_NullCountryCode_N() {
        // Act
        boolean result = assetExcelEditService.emptyRowCheckInExcel("content-1", null, "cp-1");

        // Assert
        assertTrue(result);
    }

    @Test
    void emptyRowCheckInExcel_NullVcCpId_N() {
        // Act
        boolean result = assetExcelEditService.emptyRowCheckInExcel("content-1", "US", null);

        // Assert
        assertTrue(result);
    }

    @Test
    void emptyRowCheckInExcel_EmptyContentId_N() {
        // Act
        boolean result = assetExcelEditService.emptyRowCheckInExcel("", "US", "cp-1");

        // Assert
        assertTrue(result);
    }

    // ==================== getMasterRatings Tests ====================

    @Test
    void getMasterRatings_P() {
        // Arrange
        Map<String, Object> payload = new HashMap<>();
        payload.put("ratings", List.of(new HashMap<String, Object>()));

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(com.cms.backend.common.model.BaseResponseDto.builder()
                .payload(payload)
                .build())
            .build();

        when(assetMasterDataService.getRatings()).thenReturn(responseDto);

        // Act
        List<RatingsDto> result = assetExcelEditService.getMasterRatings();

        // Assert
        assertNotNull(result);
    }

    @Test
    void getMasterRatings_NullResponse_N() {
        // Arrange
        when(assetMasterDataService.getRatings()).thenReturn(null);

        // Act
        List<RatingsDto> result = assetExcelEditService.getMasterRatings();

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getMasterRatings_NullRsp_N() {
        // Arrange
        ResponseDto responseDto = ResponseDto.builder().build();
        when(assetMasterDataService.getRatings()).thenReturn(responseDto);

        // Act
        List<RatingsDto> result = assetExcelEditService.getMasterRatings();

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ==================== createValidVod Tests ====================

    @Test
    void createValidVod_P() {
        // Arrange
        String contentId = "content-1";
        String countryCode = "US";
        String vcCpId = "cp-1";
        Row row = Mockito.mock(Row.class);
        Map<String, Integer> headerMap = new HashMap<>();

        // Act
        VodAssetDto result = assetExcelEditService.createValidVod(contentId, countryCode, vcCpId, row, headerMap, "success");

        // Assert
        assertNotNull(result);
        assertEquals(contentId, result.getContentId());
        assertEquals(countryCode, result.getCountryCode());
        assertEquals(vcCpId, result.getVcCpId());
        assertEquals("success", result.getResult());
    }

    @Test
    void createValidVod_MusicType_P() {
        // Arrange
        String contentId = "content-1";
        String countryCode = "US";
        String vcCpId = "cp-1";
        Row row = Mockito.mock(Row.class);
        Map<String, Integer> headerMap = new HashMap<>();

        // Act
        VodAssetDto result = assetExcelEditService.createValidVod(contentId, countryCode, vcCpId, row, headerMap, "success");

        // Assert
        assertNotNull(result);
        assertEquals("test-user-id", result.getUserId());
        assertEquals("test-region", result.getRegion());
        assertEquals("test-session-id", result.getSessionId());
    }

    @Test
    void createValidVod_NonMusicType_P() {
        // Arrange
        String contentId = "content-1";
        String countryCode = "US";
        String vcCpId = "cp-1";
        Row row = Mockito.mock(Row.class);
        Map<String, Integer> headerMap = new HashMap<>();

        // Act
        VodAssetDto result = assetExcelEditService.createValidVod(contentId, countryCode, vcCpId, row, headerMap, "success");

        // Assert - For non-music type, artist should be null
        assertNotNull(result);
        assertNull(result.getArtist());
    }

    // ==================== Additional Tests for Coverage ====================

    @Test
    void checkRecordExists_WithGracenoteFeedWorker_P() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Test Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms_gracenote")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Old Title")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
    }

    @Test
    void checkRecordExists_WithTvplusDeltaGracenote_P() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Test Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("tvplus_delta_gracenote")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Old Title")
            .lockedFields(List.of())
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
    }

    @Test
    void checkRecordExists_WithLockedFields_P() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Test Title")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms_gracenote")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Old Title")
            .lockedFields(List.of(AssetLockedFieldDto.builder().fieldName("mainTitle").build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
    }

    @Test
    void checkRecordExists_WithExternalProviderChange_P() {
        // Arrange
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .mainTitle("Same Title")
            .externalProvider(List.of(ExternalProviderDto.builder()
                .externalProgramId("ext-1")
                .provider("provider-1")
                .idType("type-1")
                .build()))
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .status("ready for qc")
            .feedWorker("cms")
            .deltaType("qc_sync")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .mainTitle("Same Title")
            .externalProvider(List.of(ExternalProviderDto.builder()
                .externalProgramId("ext-2")
                .provider("provider-2")
                .idType("type-2")
                .build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        boolean result = assetExcelEditService.checkRecordExists(newAsset, oldAssets);

        // Assert
        assertTrue(result);
    }

    @Test
    void addHistoryForExcelUpdate_WithParentalRatings_P() throws Exception {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .parentalRatings(List.of(ParentalRatingsDto.builder().body("MPAA").ratings("PG-13").build()))
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .parentalRatings(List.of(ParentalRatingsDto.builder().body("MPAA").ratings("G").build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("parentalRatings");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_WithCast_P() throws Exception {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .cast(List.of(AssetCastDto.builder().role("ACTOR").name("NewActor").build()))
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .cast(List.of(AssetCastDto.builder().role("ACTOR").name("OldActor").build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("cast");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_WithAvailableStarting_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .availableStarting("2024-01-01 00:00:00Z")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .availableStarting("2023-01-01 00:00:00Z")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("availableStarting");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_WithDeeplinkPayload_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("MOVIE")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("deeplinkPayload");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_WithShowTypeDeeplinkPayload_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("SHOW")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .type("SHOW")
            .deeplinkPayload("{\"deeplink_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("deeplinkPayload");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void addHistoryForExcelUpdate_WithExternalProviderList_P() throws Exception {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .externalProvider(List.of(ExternalProviderDto.builder()
                .externalProgramId("ext-1")
                .provider("provider-1")
                .idType("type-1")
                .build()))
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("content-1")
            .countryCode("US")
            .vcCpId("cp-1")
            .externalProvider(List.of(ExternalProviderDto.builder()
                .externalProgramId("ext-2")
                .provider("provider-2")
                .idType("type-2")
                .build()))
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);
        List<String> columns = List.of("externalProviderList");

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.addHistoryForExcelUpdate(asset, oldAssets, columns));
    }

    @Test
    void setExternalIDListForUpload_WithNullOldAsset_P() throws Exception {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = new ArrayList<>();
        oldAssets.add(null);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert - When old asset is null, external provider remains null
        assertNull(asset.getExternalProvider());
    }

    @Test
    void setExternalIDListForUpload_WithNullExternalProvider_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder().build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .externalProvider(null)
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert
        assertNotNull(asset.getExternalProvider());
    }

    @Test
    void setExternalIDListForUpload_WithPartialExternalIdFields_P() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .externalIdType("type1")
            .externalId("id1")
            .build();  // Missing externalIdProvider

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act
        assetExcelEditService.setExternalIDListForUpload(asset, oldAssets);

        // Assert - When partial fields are provided, external provider should be empty list
        assertNotNull(asset.getExternalProvider());
    }

    @Test
    void setDeeplinkPayloadForExcelAsset_WithNullDeeplinkPayload_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload(null)
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }

    @Test
    void setDeeplinkPayloadForExcelAsset_WithNoDeeplinkData_N() {
        // Arrange
        VodAssetDto asset = VodAssetDto.builder()
            .ratings("PG-13")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder()
            .deeplinkPayload("{\"other_data\":{}}")
            .build();

        List<VodAssetDto> oldAssets = List.of(oldAsset);

        // Act & Assert
        assertDoesNotThrow(() -> assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, oldAssets));
    }
}
