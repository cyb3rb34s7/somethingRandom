package com.cms.backend.assets.aisearch.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.cms.backend.assets.aisearch.service.AiSearchService;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.NotificationUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(controllers = AiSearchController.class,
        excludeAutoConfiguration = {
                org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration.class})
@AutoConfigureMockMvc(addFilters = false)
class AiSearchControllerTest {

    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;
    @MockBean
    AiSearchService aiSearchService;
    @MockBean
    NotificationUtil notificationUtil;

    @Test
    void returnsResolvedPayload() throws Exception {
        ResponseDto stub = ResponseDto.builder()
                .rsp(BaseResponseDto.builder().stat("ok")
                        .payload(Map.of("status", "resolved")).build())
                .build();
        when(aiSearchService.resolve(ArgumentMatchers.any())).thenReturn(stub);

        mockMvc.perform(post("/admin/asset/ai-search/resolve")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"query\":\"released movies\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rsp.payload.status").value("resolved"));
    }

    @Test
    void rejectsBlankQuery() throws Exception {
        mockMvc.perform(post("/admin/asset/ai-search/resolve")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"query\":\"\"}"))
                .andExpect(status().isBadRequest());
    }
}
