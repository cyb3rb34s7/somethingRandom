package com.cms.backend.common.exception;

public class IMSException extends RuntimeException {

    private static final long serialVersionUID = -153876205628951493L;

    public IMSException(String message) {
        super(message);
    }

}
