package com.cms.backend.evaluation.service.impl;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.assets.service.AssetExportService;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.evaluation.enums.ComparisonStatusEnum;
import com.cms.backend.evaluation.enums.CoverageStatusEnum;
import com.cms.backend.evaluation.enums.FeedWorkerEnum;
import com.cms.backend.evaluation.enums.ProgramTypeEnum;
import com.cms.backend.evaluation.model.*;
import com.cms.backend.evaluation.service.ComparisonService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class ComparisonServiceImpl implements ComparisonService {

    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;
    private final AssetExportService assetExportService;

    @Override
    public ResponseDto getProgramList(FilterRequestDto filterRequestDto) {
        try {
            HttpEntity<FilterRequestDto> httpEntity = new HttpEntity<>(
                filterRequestDto);
            log.info("Finding asset data for evaluation={}", filterRequestDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_EVALUATION_VIEW;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);

            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while finding asset:{}", e.getMessage());
            throw new AssetApiFailureException("Error while finding asset data");
        }
    }

    @Override
    public ResponseDto getFilterList() {
        Map<String, Object> payload = new HashMap<>();

        List<String> programTypeEnumList = Stream.of(ProgramTypeEnum.values())
            .map(programTypeEnum -> programTypeEnum.getValue())
            .collect(Collectors.toList());

        List<String> coverageStatusEnumList = Stream.of(CoverageStatusEnum.values())
            .map(coverageStatusEnum -> coverageStatusEnum.getValue())
            .collect(Collectors.toList());

        List<String> comparisonStatusEnumList = Stream.of(ComparisonStatusEnum.values())
            .map(comparisonStatusEnum -> comparisonStatusEnum.getValue())
            .collect(Collectors.toList());

        List<String> feedWorkerEnumList = Stream.of(FeedWorkerEnum.values())
            .map(feedWorkerEnum -> feedWorkerEnum.getValue())
            .collect(Collectors.toList());

        payload.put(Constants.FILTER_PROGRAM_TITLE, new ArrayList<>());
        payload.put(Constants.FILTER_PROGRAM_TYPE, programTypeEnumList);
        payload.put(Constants.FILTER_COVERAGE_STATUS, coverageStatusEnumList);
        payload.put(Constants.FILTER_COMPARISON_STATUS, comparisonStatusEnumList);
        payload.put(Constants.FILTER_EXTERNAL_PROGRAM_ID, new ArrayList<>());
        payload.put(Constants.FILTER_PROGRAM_ID, new ArrayList<>());
        payload.put(Constants.FILTER_FEED_WORKER, feedWorkerEnumList);

        return ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build())
            .build();
    }

    @Override
    public ResponseDto getDetail(String contentId, String cpId) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_EVALUATION_ASSET_VIEW;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(), Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while finding asset detail:{}", e.getMessage());
            throw new AssetApiFailureException("Error while finding asset detail data");
        }
    }

    @Override
    public ResponseDto getCount(FilterRequestDto filterRequestDto) {
        try {
            HttpEntity<FilterRequestDto> httpEntity = new HttpEntity<>(
                filterRequestDto);
            log.info("Finding asset count data for evaluation={}", filterRequestDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_EVALUATION_COUNT;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);

            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while finding asset count:{}", e.getMessage());
            throw new AssetApiFailureException("Error while finding asset count data");
        }
    }

    @Override
    public ResponseEntity<byte[]> startExport(AssetFilterBodyDto assetFilterBodyDto)
        throws IOException {
        ExportHelperDto response = assetExportService.startExport(assetFilterBodyDto, true);
        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_OCTET_STREAM)
            .contentLength(response.getExcelData().length)
            .header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=" + response.getFileName())
            .header("X-File-Type", response.getFileType())
            .body(response.getExcelData());
    }
}
