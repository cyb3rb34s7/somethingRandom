package com.cms.backend.assets.service;


import com.cms.backend.assets.model.AssetChangeHistoryDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto.AssetsChanges;
import com.cms.backend.changehistory.service.ChangeHistoryService;
import com.cms.backend.common.constants.Constants;

import com.cms.backend.common.model.AuthenticatedUser;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AssetAsyncService {

    private final ChangeHistoryService historyService;
    private final AuthenticatedUser authenticatedUser;

    public AssetAsyncService(ChangeHistoryService historyService,
        AuthenticatedUser authenticatedUser) {
        this.historyService = historyService;
        this.authenticatedUser = authenticatedUser;
    }

    @Async
    public void addBulkStatusHistory(List<VodAssetDto> vodAssetDtoList,
        StatusUpdateDto statusUpdateDto) {
        if (!vodAssetDtoList.isEmpty()) {
            StatusHistoryRequestDto assetStatusHistory = StatusHistoryRequestDto.builder().build();
            List<AssetsChanges> statusChanges = new ArrayList<>();
            vodAssetDtoList.forEach(vod -> {
                AssetsChanges statusChange = AssetsChanges.builder().assetId(vod.getContentId())
                    .oldStatus(vod.getStatus()).newStatus(statusUpdateDto.getStatus())
                    .vcCpId(vod.getVcCpId()).countryCode(vod.getCountryCode()).masterStatus("POST")
                    .identifierId(vod.getIdentifierId()).build();
                statusChanges.add(statusChange);
            });
            // Store userId, not userName - will be resolved to name when reading history
            assetStatusHistory.setUpdatedBy(authenticatedUser.getUserInfo().getUuid());
            assetStatusHistory.setChanges(statusChanges);
            this.insertStatusModificationHistory(assetStatusHistory);
        }
    }

    @Async
    public void insertAssetModificationHistory(AssetChangeHistoryDto assetChangeHistoryDto) {
        if (assetChangeHistoryDto.getAssetLicenseHistory() != null
            && assetChangeHistoryDto.getAssetLicenseHistory().getAssetId() != null) {
            triggerLicenseHistoryAPI(assetChangeHistoryDto.getAssetLicenseHistory());
        }
        if (assetChangeHistoryDto.getAssetStatusHistory() != null) {
            triggerStatusHistoryAPI(assetChangeHistoryDto.getAssetStatusHistory());
        }
        if (assetChangeHistoryDto.getAssetMetadataHistory() != null
            && assetChangeHistoryDto.getAssetMetadataHistory().getAssetId() != null) {
            triggerMetatdataHistoryAPI(assetChangeHistoryDto.getAssetMetadataHistory());
        }
        if (assetChangeHistoryDto.getEventHistory() != null
            && assetChangeHistoryDto.getEventHistory().getContentId() != null) {
            triggerEventHistoryAPI(assetChangeHistoryDto.getEventHistory());
        }
    }


    private void insertStatusModificationHistory(StatusHistoryRequestDto assetStatusHistoryDto) {
        if (assetStatusHistoryDto != null) {
            triggerStatusHistoryAPI(assetStatusHistoryDto);
        }
    }

    @Async
    public void insertMetadataModificationHistory(
        MetadataHistoryRequestDto assetMetadataHistoryDto) {
        if (assetMetadataHistoryDto != null) {
            triggerMetatdataHistoryAPI(assetMetadataHistoryDto);
        }
    }

    public void triggerMetatdataHistoryAPI(MetadataHistoryRequestDto assetMetadataHistoryDto) {
        var retry = Constants.RETRY;
        while (retry > 0) {
            try {
                log.info("Calling Metadata History  with payload: {}",
                    assetMetadataHistoryDto.toString());
                historyService.addMetadataHistory(assetMetadataHistoryDto);
                return;
            } catch (Exception e) {
                log.error("Error while metadata history call for Asset Id: {}. Error: {}",
                    assetMetadataHistoryDto.getAssetId(), e.getMessage());
                retry--;
            }
        }
        log.error("Max retries exceeded for Metadata History API call. Asset Id: {} ",
            assetMetadataHistoryDto.getAssetId());
    }

    private void triggerStatusHistoryAPI(StatusHistoryRequestDto assetStatusHistoryDto) {
        var retry = Constants.RETRY;
        while (retry > 0) {
            try {
                log.info("Calling Status History API with payload: {}",
                    assetStatusHistoryDto.toString());
                historyService.addAssetStatusHistory(assetStatusHistoryDto);
                return;
            } catch (Exception e) {
                log.error("Error while status history call" + e.getMessage());
                retry--;
            }
        }
        log.error("Max retries exceeded for Status Update History API call");
    }

    private void triggerLicenseHistoryAPI(LicenseHistoryRequestDto assetLicenseHistoryDto) {
        var retry = Constants.RETRY;
        while (retry > 0) {
            try {
                log.info("Calling License History API with payload: {}",
                    assetLicenseHistoryDto.toString());
                historyService.addLicenseHistory(assetLicenseHistoryDto);
                return;
            } catch (Exception e) {
                log.error("Error while license history call for Asset Id: {}. Error: {}",
                    assetLicenseHistoryDto.getAssetId(), e.getMessage());
                retry--;
            }
        }
        log.error("Max retries exceeded for License History API call. Asset Id: {} ",
            assetLicenseHistoryDto.getAssetId());
    }

    private void triggerEventHistoryAPI(EventHistoryRequestDto eventHistoryDto) {
        var retry = Constants.RETRY;
        while (retry > 0) {
            try {
                log.info("Calling Event History API with payload: {}",
                    eventHistoryDto.toString());
                historyService.addEventHistory(eventHistoryDto);
                return;
            } catch (Exception e) {
                log.error("Error while Event history call for Asset Id: {}. Error: {}",
                    eventHistoryDto.getContentId(), e.getMessage());
                retry--;
            }
        }
        log.error("Max retries exceeded for Event History API call. Asset Id: {} ",
            eventHistoryDto.getContentId());
    }

}
