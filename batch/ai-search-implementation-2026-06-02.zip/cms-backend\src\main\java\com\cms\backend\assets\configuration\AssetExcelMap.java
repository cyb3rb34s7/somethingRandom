package com.cms.backend.assets.configuration;

import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Generated;

@Generated
public class AssetExcelMap {

    private AssetExcelMap() {
        throw new IllegalStateException("AssetHeaderMap class");
    }

    public static final Map<String, String> getMap() {
        Map<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put("programid","contentId");
        assetHeader.put("assetid","assetId");
        assetHeader.put("programtype","type");
        assetHeader.put("country","countryCode");
        assetHeader.put("providerid","vcCpId");
        assetHeader.put("maintitle","mainTitle");
        assetHeader.put("shorttitle","shortTitle");
        assetHeader.put("duration(sec)","runningTime");
        assetHeader.put("adtags","adTag");
        assetHeader.put("streamurl","streamUri");
        assetHeader.put("synopsis","description");
        assetHeader.put("originalreleasedate","releaseDate");
        assetHeader.put("genre","genres");
        assetHeader.put("externalprogramid","externalProgramId");
        assetHeader.put("contentpartner/licensor","contentPartner");
        assetHeader.put("contenttier","contentTier");
        return assetHeader;
    }
}
