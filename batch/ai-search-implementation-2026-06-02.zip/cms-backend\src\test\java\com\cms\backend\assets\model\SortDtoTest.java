package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SortDtoTest {

    @Test
    void testSortDto() {
        // Create a SortDto object using the builder pattern
        SortDto sortDto = SortDto.builder()
            .field("fieldName")
            .order("ascending")
            .build();

        // Verify that the field and order properties are set correctly
        assertEquals("fieldName", sortDto.getField());
        assertEquals("ascending", sortDto.getOrder());

        // Create another SortDto object using the all-args constructor
        SortDto anotherSortDto = new SortDto("anotherFieldName", "descending");

        // Verify that the field and order properties are set correctly
        assertEquals("anotherFieldName", anotherSortDto.getField());
        assertEquals("descending", anotherSortDto.getOrder());
    }
}