package com.cms.backend.common.model;

import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;

class ModelDtoTest {

    @Test
    void testModelDtos() {
        ModelDtoTestUtility.testModelOrDto(AlertRequestDto.class);
        ModelDtoTestUtility.testModelOrDto(AllowedOrigin.class);
        ModelDtoTestUtility.testModelOrDto(BaseResponseDto.class);
        ModelDtoTestUtility.testModelOrDto(ErrorResponseDto.class);
        ModelDtoTestUtility.testModelOrDto(InvalidLicenseWindowVodAsset.class);
        ModelDtoTestUtility.testModelOrDto(ResponseDto.class);
        ModelDtoTestUtility.testModelOrDto(StaticConfig.class);
        ModelDtoTestUtility.testModelOrDto(VodAsset.class);
        ModelDtoTestUtility.testModelOrDto(AuthenticatedUser.class);
    }

    @Test
    void testSecurityUser() {
        // SecurityUser extends User, so we need to test it using the public method
        ModelDtoTestUtility.testModelOrDto(SecurityUser.class);
    }
}
