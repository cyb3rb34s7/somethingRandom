package com.cms.backend.assets.aisearch.exception;

public class SchemaUnavailableException extends RuntimeException {

    public SchemaUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
