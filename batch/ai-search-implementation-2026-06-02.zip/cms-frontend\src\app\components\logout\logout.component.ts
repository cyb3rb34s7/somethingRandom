import { Component } from '@angular/core';
import { apis } from '../../constants/api-consts';
import { environment } from '../../../environments/environment';

@Component({
    selector: 'app-logout',
    imports: [],
    templateUrl: './logout.component.html',
    styleUrl: './logout.component.scss'
})
export class LogoutComponent {
  constructor() {
    window.location.replace(environment.rootEndpoint + apis.logoutUrl);
  }
}
