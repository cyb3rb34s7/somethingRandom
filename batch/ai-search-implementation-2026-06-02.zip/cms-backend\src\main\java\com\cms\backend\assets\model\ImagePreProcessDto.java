package com.cms.backend.assets.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ImagePreProcessDto {

    @NotNull(message = "Country code is mandatory.")
    private String countryCode;

    @NotNull(message = "Provider Id is mandatory.")
    private String providerId;

    @NotNull(message = "Asset Id is mandatory.")
    private String assetId;

    @NotNull(message = "Image URLs are mandatory.")
    @Size(min = 1, message = "At least 1 image URL is required.")
    private List<String> imageUrls;

    private String serviceBatchId;
}