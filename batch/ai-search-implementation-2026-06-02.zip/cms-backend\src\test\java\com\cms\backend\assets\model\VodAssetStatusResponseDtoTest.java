package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class VodAssetStatusResponseDtoTest {

    @Test
    void testVodAssetStatusResponse() {

        // Act
        VodAssetStatusResponseDto dto = new VodAssetStatusResponseDto();
        dto.setContentId("test");
        dto.setCountryCode("test");
        dto.setVcCpId("test");
        dto.setStatus("test");
        dto.setType("test");

        // Assert
        assertEquals("test", dto.getContentId());
        assertEquals("test", dto.getCountryCode());
        assertEquals("test", dto.getVcCpId());
        assertEquals("test", dto.getStatus());
        assertEquals("test", dto.getType());

    }
}
