package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AdBreaksDtoTest.class)
class AdBreaksDtoTest {

    @Test
    void testNormalValue() {
        ModelDtoTestUtility.testModelOrDto(AdBreaksDto.class);
    }

    @Test
    void testDto() {
        ModelDtoTestUtility.testModelOrDto(ImageProcessedDto.class);
    }
}