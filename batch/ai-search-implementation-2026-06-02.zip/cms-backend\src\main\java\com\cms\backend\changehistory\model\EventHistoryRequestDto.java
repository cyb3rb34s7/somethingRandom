package com.cms.backend.changehistory.model;


import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Setter
@Getter
public class EventHistoryRequestDto {
    private String contentId;
    private String countryCode;
    private String vcCpId;
    private String eventStarting;
    private String eventEnding;
    private String updatedBy;
    private String oldStatus;
    private Instant changeDateTime;
}
