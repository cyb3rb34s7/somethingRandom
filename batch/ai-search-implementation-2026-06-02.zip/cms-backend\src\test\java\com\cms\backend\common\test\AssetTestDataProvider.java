package com.cms.backend.common.test;

import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;

import java.util.ArrayList;
import java.util.List;

/**
 * Factory class for asset-related test data objects
 */
public class AssetTestDataProvider {
    
    /**
     * Creates a standard VodAssetDto for testing
     * 
     * @return A standard VodAssetDto
     */
    public static VodAssetDto createStandardVodAssetDto() {
        return VodAssetDto.builder()
            .contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId")
            .type("type")
            .build();
    }
    
    /**
     * Creates a VodAssetDto with a specific status
     * 
     * @param status The status to set
     * @return A VodAssetDto with the specified status
     */
    public static VodAssetDto createVodAssetDtoWithStatus(String status) {
        return VodAssetDto.builder()
            .contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId")
            .type("type")
            .status(status)
            .build();
    }
    
    /**
     * Creates a VodAssetDto with detailed fields
     * 
     * @return A detailed VodAssetDto
     */
    public static VodAssetDto createDetailedVodAssetDto() {
        return VodAssetDto.builder()
            .contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId")
            .type("type")
            .mainTitle("mainTitle")
            .releaseDate("releaseDate")
            .description("description")
            .starring("starring")
            .genres("genres")
            .ratings("ratings")
            .feedWorker("cms")
            .build();
    }
    
    /**
     * Creates a standard AssetKeyDto for testing
     * 
     * @return A standard AssetKeyDto
     */
    public static AssetKeyDto createStandardAssetKeyDto() {
        return AssetKeyDto.builder()
            .vcCpId("cpId1")
            .countryCode("US")
            .contentId("contentId1")
            .build();
    }
    
    /**
     * Creates a standard StatusUpdateDto for testing
     * 
     * @return A standard StatusUpdateDto
     */
    public static StatusUpdateDto createStandardStatusUpdateDto() {
        return StatusUpdateDto.builder()
            .status("TestStatus")
            .assetList(List.of(createStandardAssetKeyDto()))
            .build();
    }
    
    /**
     * Creates a standard list of ExternalProviderDto for testing
     * 
     * @return A list of ExternalProviderDto
     */
    public static List<ExternalProviderDto> createStandardExternalProviderList() {
        List<ExternalProviderDto> externalProviders = new ArrayList<>();
        externalProviders.add(
            ExternalProviderDto.builder()
                .provider("provider1")
                .externalProgramId("id1")
                .idType("type1")
                .build());
        externalProviders.add(
            ExternalProviderDto.builder()
                .provider("provider2")
                .externalProgramId("id2")
                .idType("type2")
                .build());
        return externalProviders;
    }
}
