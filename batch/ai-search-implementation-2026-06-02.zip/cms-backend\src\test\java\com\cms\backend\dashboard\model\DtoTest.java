package com.cms.backend.dashboard.model;

import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;

class DtoTest {


    @Test
    void testOtherDto() {
        ModelDtoTestUtility.testModelOrDto(CpTypeCountDto.class);
        ModelDtoTestUtility.testModelOrDto(CpTypeStatusTICountDto.class);
        ModelDtoTestUtility.testModelOrDto(CpTypeTICountDto.class);
        ModelDtoTestUtility.testModelOrDto(DashboardCountDto.class);
        ModelDtoTestUtility.testModelOrDto(DashboardFilterBodyDto.class);
        ModelDtoTestUtility.testModelOrDto(LicenseWindowCountDto.class);
        ModelDtoTestUtility.testModelOrDto(LicenseWindowTICountDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusCountDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusTICountDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusTypeCountDto.class);
        ModelDtoTestUtility.testModelOrDto(StatusTICountDto.class);
        ModelDtoTestUtility.testModelOrDto(TypeCountDto.class);
        ModelDtoTestUtility.testModelOrDto(TypeTICountDto.class);


    }
}