package com.cms.backend.assets.model;

import com.cms.backend.common.util.ModelDtoTestUtility;
import org.junit.jupiter.api.Test;

class AssetKeyDtoTest {
    
    @Test
    void testAssetKeyDto() {
        ModelDtoTestUtility.testModelOrDto(AssetKeyDto.class);
    }
}
