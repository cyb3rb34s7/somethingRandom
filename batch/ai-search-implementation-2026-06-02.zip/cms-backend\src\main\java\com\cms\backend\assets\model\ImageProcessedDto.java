package com.cms.backend.assets.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImageProcessedDto {

    private String originalUrl;
    private String processedUrl;
    private String processedWebpUrl;
    private Integer processedImageWidth;
    private Integer processedImageHeight;
}
