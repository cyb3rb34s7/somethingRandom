package com.cms.backend.assets.aisearch.service;

import com.cms.backend.assets.aisearch.model.AiSearchRequest;
import com.cms.backend.assets.aisearch.model.llm.LlmFilter;
import com.cms.backend.assets.aisearch.model.llm.LlmPayload;
import com.cms.backend.assets.aisearch.model.llm.LlmResolveResult;
import com.cms.backend.assets.aisearch.util.DateResolver;
import com.cms.backend.assets.aisearch.util.FilterValidator;
import com.cms.backend.assets.aisearch.util.LlmGatewayHttpClient;
import com.cms.backend.assets.aisearch.util.SystemPromptBuilder;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.assets.model.PaginationDto;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AiSearchService {

    private static final Pattern JSON_OBJECT = Pattern.compile("\\{.*}", Pattern.DOTALL);

    private final FilterSchemaProvider schemaProvider;
    private final SystemPromptBuilder promptBuilder;
    private final LlmGatewayHttpClient gatewayClient;
    private final FilterValidator validator;
    private final DateResolver dateResolver;
    private final ObjectMapper objectMapper;

    public ResponseDto resolve(AiSearchRequest request) {
        Map<String, List<String>> dynamicEnums = buildDynamicEnums(request);
        String prompt = promptBuilder.build(dynamicEnums);

        String raw = gatewayClient.complete(prompt, request.getQuery());
        LlmResolveResult result = parse(raw);

        if (result == null || result.getStatus() == null) {
            return errorResponse("Failed to parse AI response. Please try again.");
        }
        if ("resolved".equals(result.getStatus()) && result.getPayload() != null) {
            return resolvedResponse(result, dynamicEnums);
        }
        if ("error".equals(result.getStatus())) {
            return errorResponse(result.getMessage() != null ? result.getMessage()
                    : "Unable to process this request.");
        }
        return errorResponse("Unexpected AI response. Please try again.");
    }

    private Map<String, List<String>> buildDynamicEnums(AiSearchRequest request) {
        Map<String, List<String>> map = new HashMap<>();
        if (request.getContext() != null) {
            if (request.getContext().getCountries() != null) {
                map.put("countryCode", request.getContext().getCountries());
            }
            if (request.getContext().getProviders() != null) {
                map.put("tiName", request.getContext().getProviders());
                map.put("contentPartner", request.getContext().getProviders());
            }
        }
        return map;
    }

    private ResponseDto resolvedResponse(LlmResolveResult result, Map<String, List<String>> dynamicEnums) {
        LlmPayload p = result.getPayload();

        // Resolve semantic date tokens for dateRange filters in place
        for (LlmFilter f : p.getFilters()) {
            if ("dateRange".equals(f.getType())) {
                f.setValues(dateResolver.resolveRange(f.getValues()));
            }
        }

        List<FilterDto> filters = validator.validateAndSanitize(p.getFilters(), dynamicEnums);
        List<String> columns = validator.validateColumns(p.getColumns());
        if (columns.isEmpty()) {
            columns = new ArrayList<>(schemaProvider.getSchema()
                    .getDefaultColumnsByType().getOrDefault("DEFAULT", List.of()));
        }

        AssetFilterBodyDto body = AssetFilterBodyDto.builder()
                .columns(columns)
                .filters(filters)
                .pagination(PaginationDto.builder()
                        .limit(p.getPagination().getLimit())
                        .offset(p.getPagination().getOffset())
                        .build())
                .build();

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("status", "resolved");
        payload.put("payload", body);
        payload.put("humanSummary", result.getHumanSummary() != null ? result.getHumanSummary() : "Results");
        return ResponseDto.builder()
                .rsp(BaseResponseDto.builder().stat("ok").payload(payload).build())
                .build();
    }

    private ResponseDto errorResponse(String message) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("status", "error");
        payload.put("message", message);
        return ResponseDto.builder()
                .rsp(BaseResponseDto.builder().stat("ok").payload(payload).build())
                .build();
    }

    private LlmResolveResult parse(String raw) {
        if (raw == null) {
            return null;
        }
        String cleaned = raw.replaceAll("```(?:json)?", "").trim();
        try {
            return objectMapper.readValue(cleaned, LlmResolveResult.class);
        } catch (Exception ignored) {
            Matcher m = JSON_OBJECT.matcher(cleaned);
            if (m.find()) {
                try {
                    return objectMapper.readValue(m.group(), LlmResolveResult.class);
                } catch (Exception e) {
                    log.error("Failed to parse extracted JSON from LLM response", e);
                }
            }
            return null;
        }
    }
}
