package com.cms.backend.assets.aisearch.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.aisearch.model.AiSearchRequest;
import com.cms.backend.assets.aisearch.model.RuntimeContext;
import com.cms.backend.assets.aisearch.util.DateResolver;
import com.cms.backend.assets.aisearch.util.FilterValidator;
import com.cms.backend.assets.aisearch.util.LlmGatewayHttpClient;
import com.cms.backend.assets.aisearch.util.SystemPromptBuilder;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.common.model.ResponseDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AiSearchServiceTest {

    @Mock
    LlmGatewayHttpClient gatewayClient;
    @Captor
    ArgumentCaptor<String> promptCaptor;

    private AiSearchService service;

    @BeforeEach
    void setUp() {
        ObjectMapper mapper = new ObjectMapper();
        FilterSchemaProvider provider = new FilterSchemaProvider(mapper);
        provider.init();
        Clock clock = Clock.fixed(Instant.parse("2026-06-02T12:00:00Z"), ZoneId.of("UTC"));
        service = new AiSearchService(
                provider,
                new SystemPromptBuilder(provider),
                gatewayClient,
                new FilterValidator(provider),
                new DateResolver(clock),
                mapper);
    }

    private AiSearchRequest req(String q) {
        AiSearchRequest r = new AiSearchRequest();
        r.setQuery(q);
        return r;
    }

    private AiSearchRequest req(String q, List<String> countries, List<String> providers) {
        AiSearchRequest r = req(q);
        RuntimeContext ctx = new RuntimeContext();
        ctx.setCountries(countries);
        ctx.setProviders(providers);
        r.setContext(ctx);
        return r;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> payloadOf(ResponseDto out) {
        return out.getRsp().getPayload();
    }

    private FilterDto findFilter(AssetFilterBodyDto body, String key) {
        Optional<FilterDto> f = body.getFilters().stream().filter(x -> key.equals(x.getKey())).findFirst();
        assertThat(f).as("filter with key " + key).isPresent();
        return f.get();
    }

    @Test
    void resolvedQueryProducesPayload() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[\"contentId\"],"
                        + "\"filters\":[{\"key\":\"status\",\"type\":\"filter\",\"values\":[\"released\"]}],"
                        + "\"pagination\":{\"limit\":50,\"offset\":0}},\"human_summary\":\"Released items\"}");

        ResponseDto out = service.resolve(req("released stuff"));
        Map<String, Object> payload = payloadOf(out);
        assertThat(out.getRsp().getStat()).isEqualTo("ok");
        assertThat(payload.get("status")).isEqualTo("resolved");
        assertThat(payload.get("humanSummary")).isEqualTo("Released items");
        assertThat(payload).containsKey("payload");

        AssetFilterBodyDto body = (AssetFilterBodyDto) payload.get("payload");
        // enum casing canonicalized "released" -> "Released"
        assertThat(findFilter(body, "status").getValues()).containsExactly("Released");
        assertThat(body.getColumns()).containsExactly("contentId");
        assertThat(body.getPagination().getLimit()).isEqualTo(50);
        assertThat(body.getPagination().getOffset()).isZero();
    }

    @Test
    void scenarioEpisodesOfMirzapurReadyForQc() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[\"contentId\",\"mainTitle\"],"
                        + "\"filters\":["
                        + "{\"key\":\"type\",\"type\":\"filter\",\"values\":[\"episode\"]},"
                        + "{\"key\":\"showTitle\",\"type\":\"filter\",\"values\":[\"Mirzapur\"]},"
                        + "{\"key\":\"status\",\"type\":\"filter\",\"values\":[\"ready for qc\"]}],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}},"
                        + "\"human_summary\":\"Episodes of Mirzapur ready for QC\"}");

        ResponseDto out = service.resolve(req("episodes of Mirzapur ready for QC"));
        AssetFilterBodyDto body = (AssetFilterBodyDto) payloadOf(out).get("payload");

        assertThat(findFilter(body, "type").getValues()).containsExactly("EPISODE");
        // showTitle wrong type corrected to "search"
        FilterDto show = findFilter(body, "showTitle");
        assertThat(show.getType()).isEqualTo("search");
        assertThat(show.getValues()).containsExactly("Mirzapur");
        assertThat(findFilter(body, "status").getValues()).containsExactly("Ready for QC");
        assertThat(payloadOf(out).get("humanSummary")).isEqualTo("Episodes of Mirzapur ready for QC");
    }

    @Test
    void scenarioReleasedMoviesFromSonyUsesInjectedProviderEnum() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[],"
                        + "\"filters\":["
                        + "{\"key\":\"type\",\"type\":\"filter\",\"values\":[\"MOVIE\"]},"
                        + "{\"key\":\"status\",\"type\":\"filter\",\"values\":[\"Released\"]},"
                        + "{\"key\":\"tiName\",\"type\":\"filter\",\"values\":[\"sony\"]}],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}},"
                        + "\"human_summary\":\"Released movies from Sony\"}");

        ResponseDto out = service.resolve(req("released movies from Sony", List.of("US"), List.of("Sony")));
        AssetFilterBodyDto body = (AssetFilterBodyDto) payloadOf(out).get("payload");

        assertThat(findFilter(body, "type").getValues()).containsExactly("MOVIE");
        assertThat(findFilter(body, "status").getValues()).containsExactly("Released");
        // tiName is dynamic; injected provider list canonicalizes "sony" -> "Sony"
        assertThat(findFilter(body, "tiName").getValues()).containsExactly("Sony");

        // empty columns -> DEFAULT columns from schema
        assertThat(body.getColumns()).contains("contentId", "mainTitle", "status", "type");

        // the injected provider enum reaches the prompt
        verify(gatewayClient).complete(promptCaptor.capture(), anyString());
        assertThat(promptCaptor.getValue()).contains("Sony");
    }

    @Test
    void scenarioContentIngestedLastWeekResolvesDateTokens() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[\"contentId\"],"
                        + "\"filters\":[{\"key\":\"assetIngestionRange\",\"type\":\"dateRange\","
                        + "\"values\":[\"LAST_7_DAYS\",\"TODAY\"]}],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}},"
                        + "\"human_summary\":\"Content ingested in the last 7 days\"}");

        ResponseDto out = service.resolve(req("content ingested last week"));
        AssetFilterBodyDto body = (AssetFilterBodyDto) payloadOf(out).get("payload");

        FilterDto range = findFilter(body, "assetIngestionRange");
        assertThat(range.getType()).isEqualTo("dateRange");
        // semantic tokens resolved against the fixed clock (2026-06-02 12:00:00)
        assertThat(range.getValues()).containsExactly("2026-05-26 12:00:00", "2026-06-02 12:00:00");
    }

    @Test
    void dateRangeWithSingleTokenPadsSecondElement() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[\"contentId\"],"
                        + "\"filters\":[{\"key\":\"assetUpdateRange\",\"type\":\"dateRange\","
                        + "\"values\":[\"YESTERDAY\"]}],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}}}");

        ResponseDto out = service.resolve(req("updated yesterday"));
        AssetFilterBodyDto body = (AssetFilterBodyDto) payloadOf(out).get("payload");
        assertThat(findFilter(body, "assetUpdateRange").getValues())
                .containsExactly("2026-06-01 12:00:00", "");
    }

    @Test
    void resolvedWithoutHumanSummaryDefaultsToResults() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[],\"filters\":[],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}}}");

        ResponseDto out = service.resolve(req("everything"));
        assertThat(payloadOf(out).get("humanSummary")).isEqualTo("Results");
    }

    @Test
    void scenarioWhatsTheWeatherProducesError() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"error\",\"message\":\"This query is not related to content search.\"}");

        ResponseDto out = service.resolve(req("what's the weather"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("This query is not related to content search.");
    }

    @Test
    void errorStatusWithoutMessageUsesFallback() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"error\"}");

        ResponseDto out = service.resolve(req("nope"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Unable to process this request.");
    }

    @Test
    void malformedJsonProducesParseError() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("I cannot help with that.");

        ResponseDto out = service.resolve(req("???"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Failed to parse AI response. Please try again.");
    }

    @Test
    void fencedJsonIsStrippedAndParsed() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("```json\n{\"status\":\"resolved\",\"payload\":{\"columns\":[\"contentId\"],"
                        + "\"filters\":[],\"pagination\":{\"limit\":100,\"offset\":0}},"
                        + "\"human_summary\":\"All content\"}\n```");

        ResponseDto out = service.resolve(req("all content"));
        assertThat(payloadOf(out).get("status")).isEqualTo("resolved");
        assertThat(payloadOf(out).get("humanSummary")).isEqualTo("All content");
    }

    @Test
    void jsonEmbeddedInProseIsExtractedViaRegexFallback() {
        // Leading prose makes the whole string invalid JSON, but the embedded object is extractable.
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("Sure, here you go: {\"status\":\"resolved\",\"payload\":{\"columns\":[],"
                        + "\"filters\":[],\"pagination\":{\"limit\":100,\"offset\":0}},"
                        + "\"human_summary\":\"ok\"} hope that helps");

        ResponseDto out = service.resolve(req("show all"));
        assertThat(payloadOf(out).get("status")).isEqualTo("resolved");
    }

    @Test
    void garbageWithBracesButInvalidJsonProducesParseError() {
        // contains { } so regex matches, but the inner content is not valid JSON -> inner parse fails
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("prefix {not: valid, json at all ::} suffix");

        ResponseDto out = service.resolve(req("???"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Failed to parse AI response. Please try again.");
    }

    @Test
    void missingStatusFieldProducesParseError() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"payload\":{\"columns\":[],\"filters\":[],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}}}");

        ResponseDto out = service.resolve(req("no status"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Failed to parse AI response. Please try again.");
    }

    @Test
    void unexpectedStatusValueProducesUnexpectedResponse() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"ambiguous\"}");

        ResponseDto out = service.resolve(req("which one"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Unexpected AI response. Please try again.");
    }

    @Test
    void resolvedStatusButNullPayloadFallsThroughToUnexpected() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\"}");

        ResponseDto out = service.resolve(req("resolved no payload"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Unexpected AI response. Please try again.");
    }

    @Test
    void nullGatewayResponseProducesParseError() {
        when(gatewayClient.complete(anyString(), anyString())).thenReturn(null);

        ResponseDto out = service.resolve(req("nothing"));
        assertThat(payloadOf(out).get("status")).isEqualTo("error");
        assertThat(payloadOf(out).get("message")).isEqualTo("Failed to parse AI response. Please try again.");
    }

    @Test
    void nullContextStillBuildsPromptAndResolves() {
        AiSearchRequest r = req("released");
        r.setContext(null);
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[],\"filters\":[],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}},\"human_summary\":\"ok\"}");

        ResponseDto out = service.resolve(r);
        assertThat(payloadOf(out).get("status")).isEqualTo("resolved");
    }

    @Test
    void countryContextInjectedIntoPrompt() {
        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"error\",\"message\":\"x\"}");

        service.resolve(req("movies in india", List.of("IN"), List.of()));
        verify(gatewayClient).complete(contains("IN"), anyString());
    }

    @Test
    void contextWithNullCountriesAndProvidersStillResolves() {
        // context object present, but both lists null -> exercises the false branches
        // of buildDynamicEnums (getCountries()==null, getProviders()==null).
        AiSearchRequest r = req("anything");
        RuntimeContext ctx = new RuntimeContext();
        ctx.setCountries(null);
        ctx.setProviders(null);
        r.setContext(ctx);

        when(gatewayClient.complete(anyString(), anyString()))
                .thenReturn("{\"status\":\"resolved\",\"payload\":{\"columns\":[],\"filters\":[],"
                        + "\"pagination\":{\"limit\":100,\"offset\":0}},\"human_summary\":\"ok\"}");

        ResponseDto out = service.resolve(r);
        assertThat(payloadOf(out).get("status")).isEqualTo("resolved");
    }
}
