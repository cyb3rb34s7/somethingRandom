package com.cms.backend.assets.configuration;

import java.util.LinkedHashMap;
import java.util.Map;

public class AssetColumnMap {

    private AssetColumnMap() {
        throw new IllegalStateException("AssetColumnMap class");
    }

    public static Map<String, String> getColumnMap() {
        Map<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put("contentId", "Content Id");
        assetHeader.put("assetId", "Asset Id");
        assetHeader.put("countryCode", "Country Code");
        assetHeader.put("vcCpId", "VC CP Id");
        assetHeader.put("type", "Type");
        assetHeader.put("mainTitle", "Main Title");
        assetHeader.put("description", "Description");
        assetHeader.put("showId", "Show Id");
        assetHeader.put("seasonId", "Season Id");
        assetHeader.put("seasonNo", "Season No.");
        assetHeader.put("episodeNo", "Episode No.");
        assetHeader.put("subTitle", "Subtitle");
        assetHeader.put("subtitleLang", "Subtitle Language");
        assetHeader.put("subtitleCode", "Subtitle Code");
        assetHeader.put("audioLang", "Audio Language");
        assetHeader.put("audioCode", "Audio Code");
        assetHeader.put("runningTime", "Running Time");
        assetHeader.put("genres", "Genres");
        assetHeader.put("director", "Director");
        assetHeader.put("starring", "Starring");
        assetHeader.put("ratings", "Ratings");
        assetHeader.put("streamUri", "Stream Uri");
        assetHeader.put("availableStarting", "Available Starting");
        assetHeader.put("expiryDate", "Expiry Date");
        assetHeader.put("releaseDate", "Release Date");
        assetHeader.put("webVttUrl", "Web Vtt Url");
        assetHeader.put("thumbnailUrl", "Thumbnail URL");
        assetHeader.put("deeplinkPayload", "Deep Link Payload");
        assetHeader.put("quality", "Quality");
        assetHeader.put("vcSvcId", "Vc Svc Id");
        assetHeader.put("deeplinkId", "Deep Link Id");
        assetHeader.put("dataplusYn", "DataPlus Yn");
        assetHeader.put("nonAdStreamUri", "Non Ad Stream Uri");
        assetHeader.put("imageLandscapeOriginal", "Image Landscape");
        assetHeader.put("imagePortraitOriginal", "Image Portrait");
        assetHeader.put("imageCircleOriginal", "Image Circle");
        assetHeader.put("artist", "Artist");
        assetHeader.put("status", "Status");
        assetHeader.put("chapterDescription", "Chapter Description");
        assetHeader.put("contentTier", "Content Tier");
        assetHeader.put("chapterTime", "Chapter Time");
        assetHeader.put("adBreak", "Ad Break");
        return assetHeader;
    }
}
