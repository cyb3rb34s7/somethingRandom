package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetUpdateByBulkDtoTest.class)
class AssetUpdateByBulkDtoTest {

    @Test
    void testNormalValueInput() {
        // Create a mock instance of VodAssetDto
        VodAssetDto vodAssetDtoMock = Mockito.mock(VodAssetDto.class);

        // Create a list of content ids
        List<String> contentIds = List.of("contentId1", "contentId2");

        // Create an instance of AssetUpdateByBulkDto with normal values
        AssetUpdateByBulkDto dto = AssetUpdateByBulkDto.builder()
            .contentIds(contentIds)
            .vodAssetDto(vodAssetDtoMock)
            .updatedBy("user123")
            .build();

        // Assertions
        assertEquals(2, dto.getContentIds().size());
        assertEquals("user123", dto.getUpdatedBy());
        assertEquals(vodAssetDtoMock, dto.getVodAssetDto());
    }


}