package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@ExtendWith(MockitoExtension.class)
class AssetExportServiceTest {

        @Mock
        private HttpMethodHandler httpMethodHandler;

        @Mock
        private RegionEndpointService regionEndpointService;

        @Mock
        private ThreadPoolTaskExecutor exportTaskExecutor;

        private AssetExportService assetExportService;
        private ObjectMapper objectMapper;
        private AssetFilterBodyDto mockFilterBody;

        @BeforeEach
        void setUp() {
                objectMapper = new ObjectMapper();
                assetExportService = new AssetExportService(regionEndpointService, httpMethodHandler,
                                exportTaskExecutor);
                mockFilterBody = new AssetFilterBodyDto();

                // Setup external service mocks (always successful)
                when(regionEndpointService.getOpenAPIEndpointNLB()).thenReturn("http://test-url/");

        }

        @Test
        void testStartExport_SmallDataset_ReturnsExcelFile() throws Exception {
                // Arrange - Small dataset (< 5000 assets)
                List<JsonNode> smallAssets = createMockAssets(100);
                mockHttpResponse(smallAssets);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertTrue(result.getFileName().contains("MediaAssets_"));
                assertTrue(result.getFileName().endsWith(".xlsx"));
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);

                // Verify single API call made
                verify(httpMethodHandler, times(3)).handleHttpExchange(
                                anyString(), eq("POST"), any(HttpEntity.class), eq(ResponseDto.class));
        }

        @Test
        void testStartExport_LargeDataset_ReturnsExcelFile() throws Exception {
                // Arrange - Large dataset (>= 5000 assets, will create single Excel file)
                ResponseEntity<ResponseDto> response1 = createMockResponseEntity(createMockAssets(5000));
                ResponseEntity<ResponseDto> response2 = createMockResponseEntity(createMockAssets(5000));
                ResponseEntity<ResponseDto> response3 = createMockResponseEntity(createMockAssets(5000));
                ResponseEntity<ResponseDto> response4 = createMockResponseEntity(createMockAssets(0));
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));
                Map<String, Object> payload = new HashMap<>();
                payload.put("assetCount", 15000);
                ResponseDto countResponse = ResponseDto.builder()
                                .rsp(BaseResponseDto.builder().payload(payload).build()).build();
                ResponseEntity<ResponseDto> entity = new ResponseEntity<>(countResponse,
                                HttpStatus.OK);
                // Mock sequential API responses
                when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
                                eq(ResponseDto.class)))
                                .thenReturn(entity)
                                .thenReturn(response1)
                                .thenReturn(response2)
                                .thenReturn(response3).thenReturn(response4);

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertTrue(result.getFileName().contains("MediaAssets_"));
                assertTrue(result.getFileName().endsWith(".xlsx"));
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);

                // Verify multiple API calls were made (parallel calls for batches)
                verify(httpMethodHandler, atLeast(3)).handleHttpExchange(
                                anyString(), eq("POST"), any(HttpEntity.class), eq(ResponseDto.class));
        }

        @Test
        void testStartExport_EmptyDataset_ReturnsExcelFile() throws Exception {
                // Arrange - Empty dataset
                List<JsonNode> emptyAssets = Collections.emptyList();
                mockHttpResponse(emptyAssets);

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertTrue(result.getFileName().endsWith(".xlsx"));
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0); // Should have headers even with no data
        }

        @Test
        void testStartExport_ExactPageSizeDataset_ReturnsExcelFile() throws Exception {
                // Arrange - Exactly 5000 assets (boundary case)
                ResponseEntity<ResponseDto> response1 = createMockResponseEntity(createMockAssets(5000));
                ResponseEntity<ResponseDto> response2 = createMockResponseEntity(createMockAssets(0));
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));
                Map<String, Object> payload = new HashMap<>();
                payload.put("assetCount", 6000);
                ResponseDto countResponse = ResponseDto.builder()
                                .rsp(BaseResponseDto.builder().payload(payload).build()).build();
                ResponseEntity<ResponseDto> entity = new ResponseEntity<>(countResponse,
                                HttpStatus.OK);

                when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
                                eq(ResponseDto.class))).thenReturn(entity)
                                .thenReturn(response1)
                                .thenReturn(response2);

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertEquals("EXCEL", result.getFileType()); // Should be EXCEL since we always return Excel now
                assertTrue(result.getFileName().endsWith(".xlsx"));
        }

        @Test
        void testStartExport_WithComplexAssetData() throws Exception {
                // Arrange - Assets with arrays, nulls, dates, CSV values
                List<JsonNode> complexAssets = createComplexMockAssets();
                mockHttpResponse(complexAssets);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_WithComputedFields() throws Exception {
                // Arrange - Assets with computed fields data
                List<JsonNode> assetsWithComputedFields = createAssetsWithComputedFields();
                mockHttpResponse(assetsWithComputedFields);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_EvaluationMode() throws Exception {
                // Arrange - Evaluation mode assets
                List<JsonNode> evaluationAssets = createEvaluationAssets(10);
                mockHttpResponseForEvaluation(evaluationAssets);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, true);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertTrue(result.getFileName().contains("EvaluationAssets_"));
                assertTrue(result.getFileName().endsWith(".xlsx"));
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_SelectiveColumns() throws Exception {
                // Arrange - Selective column export
                AssetFilterBodyDto selectiveFilterBody = new AssetFilterBodyDto();
                selectiveFilterBody.setColumns(List.of("contentId", "mainTitle", "type"));

                List<JsonNode> smallAssets = createMockAssets(5);
                mockHttpResponse(smallAssets);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(selectiveFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertTrue(result.getFileName().endsWith(".xlsx"));
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_WithEmptyArrays() throws Exception {
                // Arrange - Assets with empty arrays for computed fields
                List<JsonNode> assetsWithEmptyArrays = createAssetsWithEmptyArrays();
                mockHttpResponse(assetsWithEmptyArrays);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_WithNullValues() throws Exception {
                // Arrange - Assets with null values
                List<JsonNode> assetsWithNulls = createAssetsWithNullValues();
                mockHttpResponse(assetsWithNulls);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_WithInvalidDates() throws Exception {
                // Arrange - Assets with invalid date formats
                List<JsonNode> assetsWithInvalidDates = createAssetsWithInvalidDates();
                mockHttpResponse(assetsWithInvalidDates);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_WithBoundaryLicenseWindows() throws Exception {
                // Arrange - Assets with license windows at boundary conditions
                List<JsonNode> assetsWithBoundaryWindows = createAssetsWithBoundaryWindows();
                mockHttpResponse(assetsWithBoundaryWindows);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        @Test
        void testStartExport_ApiException() throws Exception {
                // Arrange - API throws exception
                when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
                                eq(ResponseDto.class)))
                                .thenThrow(new com.cms.backend.common.exception.AssetApiFailureException("API Error"));

                // Act & Assert
                assertThrows(com.cms.backend.common.exception.AssetApiFailureException.class, () -> {
                        assetExportService.startExport(mockFilterBody, false);
                });
        }

        @Test
        void testStartExport_WithMalformedJson() throws Exception {
                // Arrange - Assets with malformed JSON data
                List<JsonNode> assetsWithMalformedData = createAssetsWithMalformedData();
                mockHttpResponse(assetsWithMalformedData);

                // Mock the exportTaskExecutor to run tasks synchronously
                doAnswer(invocation -> {
                        Runnable task = invocation.getArgument(0);
                        task.run();
                        return null;
                }).when(exportTaskExecutor).execute(any(Runnable.class));

                // Act
                ExportHelperDto result = assetExportService.startExport(mockFilterBody, false);

                // Assert
                assertNotNull(result);
                assertEquals("EXCEL", result.getFileType());
                assertNotNull(result.getExcelData());
                assertTrue(result.getExcelData().length > 0);
        }

        // Helper methods
        private List<JsonNode> createMockAssets(int count) {
                List<JsonNode> assets = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                        assets.add(objectMapper.createObjectNode()
                                        .put("contentId", "asset_" + i)
                                        .put("mainTitle", "Asset Title " + i)
                                        .put("type", "MOVIE")
                                        .put("releaseDate", "2023-01-01T00:00:00Z"));
                }
                return assets;
        }

        private List<JsonNode> createAssetsWithComputedFields() {
                List<JsonNode> assets = new ArrayList<>();

                // Asset with computed fields data
                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "COMPUTED_TEST_001")
                                .put("mainTitle", "Test Asset with Computed Fields")
                                .put("type", "MOVIE");

                // Add parental ratings
                asset.set("parentalRatings", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("body", "MPAA")
                                                .put("ratings", "PG-13"))
                                .add(objectMapper.createObjectNode()
                                                .put("body", "BBFC")
                                                .put("ratings", "12A")));

                // Add cast with different roles
                asset.set("cast", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Tom Hanks")
                                                .put("role", "actor")
                                                .put("characterName", "Forrest Gump"))
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Robin Wright")
                                                .put("role", "actor")
                                                .put("characterName", "Jenny Curran"))
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Robert Zemeckis")
                                                .put("role", "director")
                                                .put("characterName", "")));

                // Add external providers
                asset.set("externalProvider", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("provider", "IMDB")
                                                .put("externalProgramId", "tt0109830"))
                                .add(objectMapper.createObjectNode()
                                                .put("provider", "TMDB")
                                                .put("externalProgramId", "12345")));

                // Add license windows
                asset.set("licenseWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "2023-01-01T00:00:00Z")
                                                .put("availableEnding", "2024-01-01T00:00:00Z"))
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "2024-01-01T00:00:00Z")
                                                .put("availableEnding", "2025-01-01T00:00:00Z")));

                // Add event windows
                asset.set("eventWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("eventStarting", "2023-06-01T00:00:00Z")
                                                .put("eventEnding", "2023-06-30T00:00:00Z")));

                // Add geo restrictions
                asset.set("geoRestrictions", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("accessType", "ALLOW")
                                                .put("restrictionType", "COUNTRY")
                                                .put("teamRegion", "US"))
                                .add(objectMapper.createObjectNode()
                                                .put("accessType", "DENY")
                                                .put("restrictionType", "COUNTRY")
                                                .put("teamRegion", "CN")));

                assets.add(asset);
                return assets;
        }

        private List<JsonNode> createEvaluationAssets(int count) {
                List<JsonNode> assets = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                        assets.add(objectMapper.createObjectNode()
                                        .put("programId", "eval_asset_" + i)
                                        .put("cpId", "CP_" + i)
                                        .put("programType", "MOVIE")
                                        .put("programTitle", "Evaluation Asset " + i)
                                        .put("feedWorker", "Worker_" + i)
                                        .put("tmsId", "TMS_" + i)
                                        .put("coverageStatus", "COVERED")
                                        .put("comparisonStatus", "MATCH"));
                }
                return assets;
        }

        private List<JsonNode> createAssetsWithEmptyArrays() {
                List<JsonNode> assets = new ArrayList<>();

                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "EMPTY_ARRAYS_TEST")
                                .put("mainTitle", "Test Asset with Empty Arrays")
                                .put("type", "MOVIE");

                // Add empty arrays for computed fields
                asset.set("parentalRatings", objectMapper.createArrayNode());
                asset.set("cast", objectMapper.createArrayNode());
                asset.set("externalProvider", objectMapper.createArrayNode());
                asset.set("licenseWindowList", objectMapper.createArrayNode());
                asset.set("eventWindowList", objectMapper.createArrayNode());
                asset.set("geoRestrictions", objectMapper.createArrayNode());

                assets.add(asset);
                return assets;
        }

        private List<JsonNode> createAssetsWithNullValues() {
                List<JsonNode> assets = new ArrayList<>();

                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "NULL_VALUES_TEST")
                                .put("mainTitle", "Test Asset with Null Values")
                                .put("type", "MOVIE")
                                .putNull("releaseDate")
                                .putNull("genres");

                assets.add(asset);
                return assets;
        }

        private List<JsonNode> createAssetsWithInvalidDates() {
                List<JsonNode> assets = new ArrayList<>();

                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "INVALID_DATES_TEST")
                                .put("mainTitle", "Test Asset with Invalid Dates")
                                .put("type", "MOVIE")
                                .put("releaseDate", "Invalid Date Format");

                // Add license windows with invalid dates
                asset.set("licenseWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "Not a date")
                                                .put("availableEnding", "Also not a date"))
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "2023-01-01T00:00:00Z")
                                                .put("availableEnding", "Invalid End Date")));

                assets.add(asset);
                return assets;
        }

        private List<JsonNode> createAssetsWithBoundaryWindows() {
                List<JsonNode> assets = new ArrayList<>();

                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "BOUNDARY_WINDOWS_TEST")
                                .put("mainTitle", "Test Asset with Boundary Windows")
                                .put("type", "MOVIE");

                // Add license windows at boundary conditions (exact match with export time)
                asset.set("licenseWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "2023-01-01T12:00:00Z")
                                                .put("availableEnding", "2023-12-31T12:00:00Z")));

                // Add event windows at boundary conditions
                asset.set("eventWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("eventStarting", "2023-06-01T12:00:00Z")
                                                .put("eventEnding", "2023-06-30T12:00:00Z")));

                assets.add(asset);
                return assets;
        }

        private List<JsonNode> createAssetsWithMalformedData() {
                List<JsonNode> assets = new ArrayList<>();

                // Asset with malformed JSON structure
                ObjectNode asset = objectMapper.createObjectNode()
                                .put("contentId", "MALFORMED_DATA_TEST")
                                .put("mainTitle", "Test Asset with Malformed Data")
                                .put("type", "MOVIE");

                // Add malformed cast data
                asset.set("cast", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Actor with no role"))
                                .add(objectMapper.createObjectNode()
                                                .put("role", "actor")
                                                .put("characterName", "Character with no name")));

                // Add malformed ratings data
                asset.set("parentalRatings", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("body", "Rating with no value"))
                                .add(objectMapper.createObjectNode()
                                                .put("ratings", "Value with no body")));

                assets.add(asset);
                return assets;
        }

        private void mockHttpResponseForEvaluation(List<JsonNode> assets) throws Exception {
                ResponseEntity<ResponseDto> mockResponse = createMockResponseEntityForEvaluation(assets);

                // Create proper evaluation count response structure
                Map<String, Object> evaluationPayload = new HashMap<>();
                Map<String, Object> countData = new HashMap<>();
                countData.put("totalCount", assets.size());
                countData.put("coveredCount", 0);
                countData.put("coveredRate", "0%");
                countData.put("matchedCount", 0);
                countData.put("matchedRate", "0%");
                evaluationPayload.put("evaluation", countData);

                ResponseDto countResponse = ResponseDto.builder()
                                .rsp(BaseResponseDto.builder().payload(evaluationPayload).build()).build();
                ResponseEntity<ResponseDto> entity = new ResponseEntity<>(countResponse,
                                HttpStatus.OK);
                when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
                                eq(ResponseDto.class))).thenReturn(entity)
                                .thenReturn(mockResponse);
        }

        private ResponseEntity<ResponseDto> createMockResponseEntityForEvaluation(List<JsonNode> assets) {
                // Create mock response structure for evaluation assets
                Map<String, Object> payload = new HashMap<>();
                Map<String, Object> evaluationPayload = new HashMap<>();
                evaluationPayload.put("data", assets);
                payload.put("evaluation", evaluationPayload);

                BaseResponseDto mockRsp = BaseResponseDto.builder().payload(payload).build();

                ResponseDto responseDto = ResponseDto.builder().rsp(mockRsp).build();

                ResponseEntity<ResponseDto> mockResponseEntity = new ResponseEntity<>(responseDto,
                                HttpStatus.OK);

                return mockResponseEntity;
        }

        private List<JsonNode> createComplexMockAssets() {
                List<JsonNode> assets = new ArrayList<>();

                // Asset with arrays and various field types
                ObjectNode complexAsset = objectMapper.createObjectNode()
                                .put("contentId", "TEST_ID")
                                .put("countryCode", "AA")
                                .put("releaseDate", "2023-01-01T00:00:00Z");

                complexAsset.set("adTag", objectMapper.createArrayNode().add("action").add("drama"));

                complexAsset.set("cast", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Actor 1")
                                                .put("role", "Lead")
                                                .put("characterName", "Hero"))
                                .add(objectMapper.createObjectNode()
                                                .put("name", "Actor 2")
                                                .put("role", "Supporting")
                                                .put("characterName", "Sidekick")));
                complexAsset.set("licenseWindowList", objectMapper.createArrayNode()
                                .add(objectMapper.createObjectNode()
                                                .put("availableStarting", "2023-01-01T00:00:00Z")
                                                .put("availableEnding", "2024-01-01T00:00:00Z")));

                // Asset with null values
                ObjectNode nullAsset = objectMapper.createObjectNode()
                                .put("contentId", "")
                                .putNull("title")
                                .putNull("description");

                // Asset with empty arrays
                ObjectNode emptyArrayAsset = objectMapper.createObjectNode()
                                .put("contentId", "TEST_ID2")
                                .set("adTag", objectMapper.createArrayNode());
                emptyArrayAsset.set("cast", objectMapper.createArrayNode());

                assets.add(complexAsset);
                assets.add(nullAsset);
                assets.add(emptyArrayAsset);
                return assets;
        }

        private void mockHttpResponse(List<JsonNode> assets) throws Exception {
                ResponseEntity<ResponseDto> mockResponse = createMockResponseEntity(assets);
                ResponseEntity<ResponseDto> response7 = createMockResponseEntity(createMockAssets(0));
                Map<String, Object> payload = new HashMap<>();
                payload.put("assetCount", assets.size());
                ResponseDto countResponse = ResponseDto.builder()
                                .rsp(BaseResponseDto.builder().payload(payload).build()).build();
                ResponseEntity<ResponseDto> entity = new ResponseEntity<>(countResponse,
                                HttpStatus.OK);
                when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
                                eq(ResponseDto.class))).thenReturn(entity)
                                .thenReturn(mockResponse).thenReturn(response7);
        }

        private ResponseEntity<ResponseDto> createMockResponseEntity(List<JsonNode> assets) {
                // Create mock response structure: ResponseDto → getRsp() → getPayload() →
                // get("assets")
                Map<String, Object> payload = new HashMap<>();
                payload.put("assets", assets);

                BaseResponseDto mockRsp = BaseResponseDto.builder().payload(payload).build();

                ResponseDto responseDto = ResponseDto.builder().rsp(mockRsp).build();

                ResponseEntity<ResponseDto> mockResponseEntity = new ResponseEntity<>(responseDto,
                                HttpStatus.OK);

                return mockResponseEntity;
        }
}
