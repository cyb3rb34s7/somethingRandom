package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.cms.backend.assets.aisearch.model.llm.LlmFilter;
import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import com.cms.backend.assets.model.FilterDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FilterValidatorTest {

    private FilterValidator validator;

    @BeforeEach
    void setUp() {
        FilterSchemaProvider provider = new FilterSchemaProvider(new ObjectMapper());
        provider.init();
        validator = new FilterValidator(provider);
    }

    private LlmFilter f(String key, String type, String... values) {
        LlmFilter lf = new LlmFilter();
        lf.setKey(key);
        lf.setType(type);
        lf.setValues(values == null ? null : new ArrayList<>(Arrays.asList(values)));
        return lf;
    }

    @Test
    void dropsUnknownKey() {
        List<FilterDto> out = validator.validateAndSanitize(List.of(f("nonsense", "filter", "x")), Map.of());
        assertThat(out).isEmpty();
    }

    @Test
    void canonicalizesEnumCasing() {
        List<FilterDto> out =
                validator.validateAndSanitize(List.of(f("status", "filter", "ready for qc")), Map.of());
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("Ready for QC");
        assertThat(out.get(0).getKey()).isEqualTo("status");
        assertThat(out.get(0).getDisplayText()).isEqualTo("Media Status");
    }

    @Test
    void dropsInvalidEnumValueAndEmptyFilter() {
        List<FilterDto> out = validator.validateAndSanitize(List.of(f("status", "filter", "bogus")), Map.of());
        assertThat(out).isEmpty();
    }

    @Test
    void keepsValidEnumValueAndDropsInvalidOneFromSameFilter() {
        List<FilterDto> out = validator.validateAndSanitize(
                List.of(f("status", "filter", "bogus", "Released")), Map.of());
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("Released");
    }

    @Test
    void correctsWrongType() {
        // showTitle is "search" in schema even if the model said "filter"
        List<FilterDto> out =
                validator.validateAndSanitize(List.of(f("showTitle", "filter", "Mirzapur")), Map.of());
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getType()).isEqualTo("search");
        // search keys have no static enum, so the free-text value passes through unchanged
        assertThat(out.get(0).getValues()).containsExactly("Mirzapur");
    }

    @Test
    void keepsDynamicValueNotInInjectedList() {
        // countryCode is dynamicValues=true; injected list is partial
        List<FilterDto> out = validator.validateAndSanitize(
                List.of(f("countryCode", "filter", "ZZ")), Map.of("countryCode", List.of("IN", "US")));
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("ZZ");
    }

    @Test
    void canonicalizesDynamicValueWhenInjectedListMatches() {
        List<FilterDto> out = validator.validateAndSanitize(
                List.of(f("countryCode", "filter", "in")), Map.of("countryCode", List.of("IN", "US")));
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("IN");
    }

    @Test
    void dynamicValueWithNoInjectedListKeepsValueAsFreeText() {
        // dynamicValues key but no injected enum -> allowed list empty -> value passes through
        List<FilterDto> out =
                validator.validateAndSanitize(List.of(f("tiName", "filter", "Sony")), Map.of());
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("Sony");
    }

    @Test
    void nullValuesProducesEmptyValuesForSearchKey() {
        List<FilterDto> out =
                validator.validateAndSanitize(List.of(f("showTitle", "search", (String[]) null)), Map.of());
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).isEmpty();
    }

    @Test
    void nullFilterListReturnsEmpty() {
        assertThat(validator.validateAndSanitize(null, Map.of())).isEmpty();
    }

    @Test
    void nullDynamicEnumsTreatedAsEmptyForDynamicKey() {
        List<FilterDto> out =
                validator.validateAndSanitize(List.of(f("tiName", "filter", "Sony")), null);
        assertThat(out).hasSize(1);
        assertThat(out.get(0).getValues()).containsExactly("Sony");
    }

    @Test
    void validateColumnsDropsBlankNullAndBlockedTokens() {
        List<String> in = Arrays.asList("contentId", null, "  ", "drop", "mainTitle", ";", "DELETE");
        List<String> out = validator.validateColumns(in);
        assertThat(out).containsExactly("contentId", "mainTitle");
    }

    @Test
    void validateColumnsNullReturnsEmpty() {
        assertThat(validator.validateColumns(null)).isEmpty();
    }

    @Test
    void validateColumnsKeepsValidColumns() {
        assertThat(validator.validateColumns(List.of("contentId", "status")))
                .containsExactly("contentId", "status");
    }
}
