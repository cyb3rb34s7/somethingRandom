package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.common.util.ResponseHandler;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource("classpath:application-test.properties")
class AssetMasterDataServiceTest {

    @InjectMocks
    AssetMasterDataService assetMasterDataService;
    @Mock
    HttpMethodHandler httpMethodHandler;

    @Mock
    RegionEndpointService regionEndpointService;

    @BeforeEach
    void setUp() {
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
    }

    @Test
    void testGetFilters() {
        // Arrange
        String finalUrl = "http://test:8080" + Constants.GET_ASSET_FILTERS;

        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(finalUrl, Constants.METHOD_GET,
            null,
            ResponseDto.class)).thenReturn(responseEntity);
        // Act
        assertDoesNotThrow(() -> {
            assetMasterDataService.getFilters();
        });
    }

    @Test
    void testGetCountryCodes() {
        // Arrange
        String finalUrl = "http://test:8080" + Constants.COUNTRY_CODES;

        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(finalUrl, Constants.METHOD_GET,
            null,
            ResponseDto.class)).thenReturn(responseEntity);
        // Act
        assertDoesNotThrow(() -> {
            assetMasterDataService.getCountryCodes();
        });
    }

    @Test
    void testGetCountryCodesThrowsException() {
        String finalUrl = "http://test:8080" + Constants.COUNTRY_CODES;
        doThrow(new AssetApiFailureException("ERROR")).when(httpMethodHandler)
            .handleHttpExchange(finalUrl, Constants.METHOD_GET,
                null,
                ResponseDto.class);
        // Act
        assertThrows(AssetApiFailureException.class, () -> {
            assetMasterDataService.getCountryCodes();
        });
    }

    @Test
    void testGetAllCountryCodesException() {
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity).thenReturn(responseEntity);
        // Act
        assertThrows(AssetApiFailureException.class, () ->
            assetMasterDataService.getAllCountryCodes());
    }

    @Test
    void testGetAllPlatformData() {
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        // Act
        assertDoesNotThrow(() -> {
            assetMasterDataService.getMasterPlatformData();
        });
    }

    @Test
    void testGetAllPlatformDataThrowsException() {
        doThrow(new AssetApiFailureException("error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), Mockito.any(),
                Mockito.any());
        // Act
        assertThrows(AssetApiFailureException.class, () -> {
            assetMasterDataService.getMasterPlatformData();
        });
    }

    @Test
    void testGetLanguages() {
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        // Act
        assertDoesNotThrow(() -> {
            assetMasterDataService.getLanguages();
        });
    }


    @Test
    void testGetLanguagesThrowsException() {
        doThrow(new AssetApiFailureException("error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), Mockito.any(),
                Mockito.any());
        // Act
        assertThrows(AssetApiFailureException.class, () -> {
            assetMasterDataService.getLanguages();
        });
    }

    @Test
    void testGetRatingsThrowsException() {
        doThrow(new AssetApiFailureException("error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), Mockito.any(),
                Mockito.any());
        // Act
        assertThrows(AssetApiFailureException.class, () -> {
            assetMasterDataService.getRatings();
        });
    }

    @Test
    void testGetAllCountryCodes() {
        ResponseDto responseCountry = ResponseHandler.processMethodResponse("countries",
            List.of("US", "EU"));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(ResponseEntity.ok(responseCountry))
            .thenReturn(ResponseEntity.ok(responseCountry));
        // Act
        assertDoesNotThrow(() -> {
            assetMasterDataService.getAllCountryCodes();
        });
    }

    @Test
    void testGetAssetViewFiltersException() {
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        assertThrows(AssetApiFailureException.class,
            () -> assetMasterDataService.getAssetViewFilters(assetKeyDto));
    }


    @Test
    void testGetAssetViewFilters() {
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetMasterDataService.getAssetViewFilters(assetKeyDto);
        });
    }

    @Test
    void testGetFiltersException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        assertThrows(AssetApiFailureException.class,
            () -> assetMasterDataService.getFilters());
    }

    @Test
    void testGetFiltersBadRequestException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(IllegalArgumentException.class);
        assertThrows(IllegalArgumentException.class,
            () -> assetMasterDataService.getFilters());
    }
}
