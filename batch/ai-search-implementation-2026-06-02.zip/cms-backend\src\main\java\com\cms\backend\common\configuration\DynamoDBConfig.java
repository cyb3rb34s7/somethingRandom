package com.cms.backend.common.configuration;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

@Configuration
@Slf4j
public class DynamoDBConfig {

    @Value("${REGION}")
    private String awsRegion;

    @Bean
    public DynamoDbClient getDynamodbClient() {
        DynamoDbClient dynamoDbClient = DynamoDbClient.builder()
            .region(Region.of(awsRegion)).credentialsProvider(
                DefaultCredentialsProvider.builder().build())
            .build();
        log.info("DynamoDB Client: Created successfully");
        return dynamoDbClient;

    }

    @Bean
    public DynamoDbEnhancedClient getDynamodbEnhancedClient() {
        DynamoDbEnhancedClient dynamoDbEnhancedClient = DynamoDbEnhancedClient.builder()
            .dynamoDbClient(getDynamodbClient())
            .build();
        log.info("DynamoDB Enhanced Client: Created successfully");
        return dynamoDbEnhancedClient;

    }


}
