package com.cms.backend.assets.aisearch.model.llm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmData {

    private String content;   // raw text (JSON) produced by the model
}
