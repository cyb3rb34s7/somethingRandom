package com.cms.backend.common.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonMethodUtil {

    private CommonMethodUtil() {
    }

    public static String formatDateField(String dateValue) {
        if (dateValue == null || dateValue.trim().isEmpty()) {
            return dateValue;
        }
        try {
            return dateValue.replaceFirst("T", " ")
                .replaceFirst("Z", "")
                .replaceFirst("\\.\\d{3}.*", "");
        } catch (Exception e) {
            log.error("Date formatting failed for date :{}", dateValue);
            return dateValue;
        }
    }

}
