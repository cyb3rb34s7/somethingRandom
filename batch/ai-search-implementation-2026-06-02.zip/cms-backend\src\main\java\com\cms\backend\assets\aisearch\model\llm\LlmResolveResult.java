package com.cms.backend.assets.aisearch.model.llm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmResolveResult {

    private String status;                 // "resolved" | "error"
    private LlmPayload payload;
    @JsonProperty("human_summary")
    private String humanSummary;
    private String message;                // present when status = "error"
}
