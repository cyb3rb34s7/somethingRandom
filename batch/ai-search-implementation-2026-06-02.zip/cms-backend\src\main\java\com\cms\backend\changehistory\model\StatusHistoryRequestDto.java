package com.cms.backend.changehistory.model;


import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class StatusHistoryRequestDto {

    private String updatedBy;
    private List<AssetsChanges> changes;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @ToString
    public static class AssetsChanges {

        private String assetId;
        private String oldStatus;
        private String newStatus;
        private String masterStatus;
        private String identifierId;
        private String countryCode;
        private String vcCpId;
    }
}