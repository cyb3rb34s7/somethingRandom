package com.cms.backend.common.enums;

public enum AssetEvents {
    AUTO_SYNC("AUTOSYNC");
    public final String value;

    AssetEvents(String value) {
        this.value = value;
    }
}
