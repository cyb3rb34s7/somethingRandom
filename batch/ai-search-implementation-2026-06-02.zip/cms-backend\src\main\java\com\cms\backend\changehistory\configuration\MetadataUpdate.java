package com.cms.backend.changehistory.configuration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MetadataUpdate{
    private String field;
    private String oldValue;
    private String newValue;
}
