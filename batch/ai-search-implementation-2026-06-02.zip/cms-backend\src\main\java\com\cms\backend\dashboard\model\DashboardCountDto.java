package com.cms.backend.dashboard.model;

import com.cms.backend.common.constants.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@Builder
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@DynamoDbBean
public class DashboardCountDto {


    private String addedDate;
    @JsonIgnore
    private String regionCountry;
    private int totalAssetCount;
    private int totalTitleCount;
    private int assetsInQcCount;
    private int releasedAssetsCount;
    private int releasedTitlesCount;
    private int disallowedAssetsCount;
    private int liveOnDevicesAssetsCount;
    private int qcFailedAssetsCount;
    private List<StatusCountDto> statusWiseAssetsCountList;
    private List<StatusTypeCountDto> statusTypeWiseAssetsCountList;
    private List<TypeCountDto> typeWiseAssetsCountList;
    private List<CpTypeCountDto> cpTypeWiseAssetsCountList;
    private List<LicenseWindowCountDto> licenseWindowWiseAssetsCountList;
    private List<StatusTICountDto> statusTiWiseAssetsCountList;
    private List<StatusTypeTICountDto> statusTypeTiWiseAssetsCountList;
    private List<TypeTICountDto> typeTiWiseAssetsCountList;
    private List<CpTypeTICountDto> cpTypeTiWiseAssetsCountList;
    private List<CpTypeStatusTICountDto> cpTypeStatusTiWiseAssetsCountList;
    private List<LicenseWindowTICountDto> licenseWindowTiWiseAssetsCountList;
    private String lastRunTime;
    private String region;
    private String countryCode;

    @DynamoDbPartitionKey
    @DynamoDbAttribute(Constants.DASHBOARD_PARTITION_KEY)
    @DynamoDbSecondaryPartitionKey(indexNames = {Constants.DASHBOARD_INDEX})
    public String getAddedDate() {
        return addedDate;
    }

    @DynamoDbSortKey
    @DynamoDbAttribute(Constants.DASHBOARD_SORT_KEY)
    public String getRegionCountry() {
        return regionCountry;
    }

    @DynamoDbAttribute("total_asset_count")
    public int getTotalAssetCount() {
        return totalAssetCount;
    }

    @DynamoDbAttribute("total_title_count")
    public int getTotalTitleCount() {
        return totalTitleCount;
    }

    @DynamoDbAttribute("assets_in_qc_count")
    public int getAssetsInQcCount() {
        return assetsInQcCount;
    }

    @DynamoDbAttribute("released_assets_count")
    public int getReleasedAssetsCount() {
        return releasedAssetsCount;
    }

    @DynamoDbAttribute("released_titles_count")
    public int getReleasedTitlesCount() {
        return releasedTitlesCount;
    }

    @DynamoDbAttribute("disallowed_assets_count")
    public int getDisallowedAssetsCount() {
        return disallowedAssetsCount;
    }

    @DynamoDbAttribute("live_on_devices_assets_count")
    public int getLiveOnDevicesAssetsCount() {
        return liveOnDevicesAssetsCount;
    }

    @DynamoDbAttribute("qc_failed_assets_count")
    public int getQcFailedAssetsCount() {
        return qcFailedAssetsCount;
    }

    @DynamoDbAttribute("status_wise_assets_count_list")
    public List<StatusCountDto> getStatusWiseAssetsCountList() {
        return statusWiseAssetsCountList;
    }

    @DynamoDbAttribute("status_type_wise_assets_count_list")
    public List<StatusTypeCountDto> getStatusTypeWiseAssetsCountList() {
        return statusTypeWiseAssetsCountList;
    }

    @DynamoDbAttribute("type_wise_assets_count_list")
    public List<TypeCountDto> getTypeWiseAssetsCountList() {
        return typeWiseAssetsCountList;
    }

    @DynamoDbAttribute("cp_type_wise_assets_count_list")
    public List<CpTypeCountDto> getCpTypeWiseAssetsCountList() {
        return cpTypeWiseAssetsCountList;
    }

    @DynamoDbAttribute("license_window_wise_assets_count_list")
    public List<LicenseWindowCountDto> getLicenseWindowWiseAssetsCountList() {
        return licenseWindowWiseAssetsCountList;
    }

    @DynamoDbAttribute("status_ti_wise_assets_count_list")
    public List<StatusTICountDto> getStatusTiWiseAssetsCountList() {
        return statusTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("status_type_ti_wise_assets_count_list")
    public List<StatusTypeTICountDto> getStatusTypeTiWiseAssetsCountList() {
        return statusTypeTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("type_ti_wise_assets_count_list")
    public List<TypeTICountDto> getTypeTiWiseAssetsCountList() {
        return typeTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("cp_type_ti_wise_assets_count_list")
    public List<CpTypeTICountDto> getCpTypeTiWiseAssetsCountList() {
        return cpTypeTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("cp_type_status_ti_wise_assets_count_list")
    public List<CpTypeStatusTICountDto> getCpTypeStatusTiWiseAssetsCountList() {
        return cpTypeStatusTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("license_window_ti_wise_assets_count_list")
    public List<LicenseWindowTICountDto> getLicenseWindowTiWiseAssetsCountList() {
        return licenseWindowTiWiseAssetsCountList;
    }

    @DynamoDbAttribute("last_run_time")
    public String getLastRunTime() {
        return lastRunTime;
    }

    public String getRegion() {
        return region;
    }

    @DynamoDbSecondarySortKey(indexNames = {Constants.DASHBOARD_INDEX})
    @DynamoDbAttribute("country")
    public String getCountryCode() {
        return countryCode;
    }
}
