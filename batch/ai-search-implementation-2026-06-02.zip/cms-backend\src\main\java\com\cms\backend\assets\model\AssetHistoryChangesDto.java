package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssetHistoryChangesDto {

    private String assetId;
    private String oldStatus;
    private String newStatus;
    private String masterStatus;
}
