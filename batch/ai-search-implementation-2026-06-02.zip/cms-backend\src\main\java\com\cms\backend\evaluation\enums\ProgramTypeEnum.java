package com.cms.backend.evaluation.enums;

import lombok.Getter;

@Getter
public enum ProgramTypeEnum {
    SHOW("SHOW"),
    SEASON("SEASON"),
    EPISODE("EPISODE"),
    MOVIE("MOVIE"),
    MUSIC("MUSIC"),
    SINGLE_VOD("SINGLEVOD");

    private final String value;

    ProgramTypeEnum(String value) {
        this.value = value;
    }
}
