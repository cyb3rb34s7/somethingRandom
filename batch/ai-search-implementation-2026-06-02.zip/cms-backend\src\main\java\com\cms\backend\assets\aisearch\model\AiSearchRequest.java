package com.cms.backend.assets.aisearch.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AiSearchRequest {

    @NotBlank(message = "query can not be blank")
    private String query;
    private RuntimeContext context = new RuntimeContext();
}
