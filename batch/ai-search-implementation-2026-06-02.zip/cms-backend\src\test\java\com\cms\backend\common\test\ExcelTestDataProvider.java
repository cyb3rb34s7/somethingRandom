package com.cms.backend.common.test;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Factory class for generating standard Excel workbooks for testing
 */
public class ExcelTestDataProvider {
    
    /**
     * Creates a standard test workbook with common headers
     * 
     * @return A standard XSSFWorkbook for testing
     * @throws IOException if there's an error creating the workbook
     */
    public static XSSFWorkbook createStandardTestWorkbook() throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Sheet1");
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("programid");
        row.createCell(1).setCellValue("country");
        row.createCell(2).setCellValue("providerid");
        row.createCell(3).setCellValue("assetid");
        row.createCell(4).setCellValue("programtype");
        row.createCell(5).setCellValue("maintitle");
        row.createCell(6).setCellValue("shorttitle");
        row.createCell(7).setCellValue("synopsis");
        row.createCell(8).setCellValue("originalreleasedate");
        row.createCell(9).setCellValue("genre");
        row.createCell(10).setCellValue("externalprogramid");
        row.createCell(11).setCellValue("provider");
        row.createCell(12).setCellValue("idtype");
        row.createCell(13).setCellValue("contentpartner/licensor");
        row.createCell(14).setCellValue("contenttier");
        return workbook;
    }
    
    /**
     * Creates a test workbook with custom headers
     * 
     * @param headers List of header names
     * @return A XSSFWorkbook with the specified headers
     * @throws IOException if there's an error creating the workbook
     */
    public static XSSFWorkbook createTestWorkbookWithHeaders(List<String> headers) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Sheet1");
        Row row = sheet.createRow(0);
        
        for (int i = 0; i < headers.size(); i++) {
            row.createCell(i).setCellValue(headers.get(i));
        }
        
        return workbook;
    }
    
    /**
     * Creates a MultipartFile from a workbook for testing file uploads
     * 
     * @param workbook The workbook to convert to a MultipartFile
     * @return A MultipartFile representation of the workbook
     * @throws IOException if there's an error converting the workbook
     */
    public static MultipartFile createTestMultipartFileFromWorkbook(XSSFWorkbook workbook) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        return new MockMultipartFile("file", "test.xlsx", 
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);
    }
}
