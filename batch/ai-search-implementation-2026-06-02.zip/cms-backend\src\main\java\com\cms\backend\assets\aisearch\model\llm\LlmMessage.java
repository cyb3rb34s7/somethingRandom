package com.cms.backend.assets.aisearch.model.llm;

public record LlmMessage(String role, String content) {
}
