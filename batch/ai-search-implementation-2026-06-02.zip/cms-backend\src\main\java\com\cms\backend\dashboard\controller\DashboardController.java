package com.cms.backend.dashboard.controller;

import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.ResponseHandler;
import com.cms.backend.dashboard.model.DashboardFilterBodyDto;
import com.cms.backend.dashboard.service.DashboardService;
import jakarta.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/admin/dashboard")
@RestController
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/getdashboarddata")
    public ResponseDto getDashboardData(@NotNull @RequestParam("date") String date) {

        return ResponseHandler.processMethodResponse(Constants.DASHBOARD_DATA_RESPONSE,
            dashboardService.getDashboardData(date));
    }

    @PostMapping("/list")
    public ResponseDto postDashboardData(
        @RequestBody DashboardFilterBodyDto dashboardFilterBodyDto) {

        Map<String, Object> payload = new HashMap<>();
        payload.put(Constants.DASHBOARD_DATA_RESPONSE,
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto));
        payload.put(Constants.LAST_BATCH_RUN_TIME, dashboardService.getLastRunTime());
        return ResponseHandler.processSuccess(payload);
    }
}
