import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowChangesModalComponent } from './show-changes-modal.component';

describe('ShowChangesModalComponent', () => {
  let component: ShowChangesModalComponent;
  let fixture: ComponentFixture<ShowChangesModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowChangesModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ShowChangesModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
