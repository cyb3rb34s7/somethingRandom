package com.cms.backend.evaluation.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.evaluation.model.FilterRequestDto;
import com.cms.backend.evaluation.service.ComparisonService;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

@SpringBootTest(classes = ComparisonControllerTest.class)
public class ComparisonControllerTest {

    @Mock
    ComparisonService comparisonService;

    @InjectMocks
    ComparisonController comparisonController;

    @Test
    void testGetProgramList() {
        Mockito.doReturn(new ResponseDto()).when(comparisonService).getProgramList(any(
            FilterRequestDto.class));
        assertDoesNotThrow(() -> {
            comparisonController.getProgramList(FilterRequestDto.builder().build());
        });
    }

    @Test
    void testGetFilterList() {
        Mockito.doReturn(new ResponseDto()).when(comparisonService)
            .getFilterList();
        assertDoesNotThrow(() -> {
            comparisonController.getFilterList();
        });
    }

    @Test
    void testGetDetail() {
        Mockito.doReturn(new ResponseDto()).when(comparisonService)
            .getDetail(anyString(), anyString());
        assertDoesNotThrow(() -> {
            comparisonController.getDetail("test_id", "test_cp_id");
        });
    }

    @Test
    void testGetCount() {
        Mockito.doReturn(new ResponseDto()).when(comparisonService).getCount(any(
            FilterRequestDto.class));
        assertDoesNotThrow(() -> {
            comparisonController.getCount(FilterRequestDto.builder().build());
        });
    }

    @Test
    void testExport() throws IOException {

        ResponseEntity<byte[]> mockResponse = ResponseEntity.ok(new byte[0]);
        Mockito.doReturn(mockResponse).when(comparisonService).startExport(any(
            AssetFilterBodyDto.class));
        assertDoesNotThrow(() -> {
            comparisonController.exportData(AssetFilterBodyDto.builder().build());
        });
    }
}
