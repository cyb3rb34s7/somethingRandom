package com.cms.backend.evaluation.controller;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.evaluation.model.FilterRequestDto;
import com.cms.backend.evaluation.service.ComparisonService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RequestMapping("/admin/evaluation/comparison")
@RestController
public class ComparisonController {

    private final ComparisonService comparisonService;
    public ComparisonController(ComparisonService comparisonService) {
        this.comparisonService = comparisonService;
    }

    @PostMapping(value="/program/list")
    public ResponseDto getProgramList(@RequestBody FilterRequestDto filterRequestDto) {
        return comparisonService.getProgramList(filterRequestDto);
    }

    @GetMapping(value="/filter/list")
    public ResponseDto getFilterList() {
        return comparisonService.getFilterList();
    }

    @GetMapping(value="/detail")
    public ResponseDto getDetail(@RequestParam(name = Constants.CONTENT_ID) String contentId,
                                 @RequestParam(name = Constants.CP_ID) String cpId) {
        return comparisonService.getDetail(contentId, cpId);
    }

    @PostMapping(value="/count")
    public ResponseDto getCount(@RequestBody FilterRequestDto filterRequestDto) {
        return comparisonService.getCount(filterRequestDto);
    }

    @PostMapping("/export")
    public ResponseEntity<byte[]> exportData(
            @RequestBody AssetFilterBodyDto assetFilterBodyDto) throws IOException {
        return comparisonService.startExport(assetFilterBodyDto);
    }
}