package com.cms.backend.common.configuration;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TraceIdRestTemplateInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(
        HttpRequest request,
        byte[] body,
        ClientHttpRequestExecution execution) throws IOException {

        String traceId = MDC.get("X-Trace-Id");
        long startTime = System.currentTimeMillis();

        if (traceId != null) {
            request.getHeaders().add("X-Trace-Id", traceId);
            request.getHeaders().add("X-Host-Name", "CMS-Admin");
        }

        try {
            return execution.execute(request, body);
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            log.info("Downstream api call with path={} took {} ms", request.getURI(), duration);
        }
    }
}