package com.cms.backend.assets.aisearch.model.llm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmChatResponse {

    private boolean success;
    private LlmData data;
    private LlmError error;
    @JsonProperty("trace_id")
    private String traceId;
}
