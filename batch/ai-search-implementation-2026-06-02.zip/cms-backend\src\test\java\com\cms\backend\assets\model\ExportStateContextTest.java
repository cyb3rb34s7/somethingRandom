package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.backend.assets.configuration.ExportFieldMappingConfig;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ExportStateContextTest {

    private ExportStateContext context;

    @BeforeEach
    void setUp() {
        context = new ExportStateContext();
    }

    @Test
    void testDefaultValues() {
        assertEquals(0, context.getCurrentRow());
        assertFalse(context.isSelectiveExport());
        assertFalse(context.isEvaluation());
        assertNotNull(context.getSelectedColumns());
        assertTrue(context.getSelectedColumns().isEmpty());
        assertNull(context.getFieldsToProcess());
    }

    @Test
    void testSetupSelectiveExport_NonEmptyList() {
        List<String> selectedColumns = Arrays.asList("contentId", "mainTitle", "type");
        boolean isEvaluation = false;

        context.setupSelectiveExport(selectedColumns, isEvaluation);

        assertTrue(context.isSelectiveExport());
        assertEquals(isEvaluation, context.isEvaluation());
        assertEquals(selectedColumns, context.getSelectedColumns());
        assertArrayEquals(selectedColumns.toArray(new String[0]), context.getFieldsToProcess());
    }

    @Test
    void testSetupSelectiveExport_EmptyList() {
        List<String> selectedColumns = Arrays.asList();
        boolean isEvaluation = true;

        context.setupSelectiveExport(selectedColumns, isEvaluation);

        assertFalse(context.isSelectiveExport());
        assertEquals(isEvaluation, context.isEvaluation());
        assertEquals(selectedColumns, context.getSelectedColumns());
        assertArrayEquals(ExportFieldMappingConfig.getFieldsInOrder(isEvaluation), context.getFieldsToProcess());
    }

    @Test
    void testSetupFullExport_NonEvaluation() {
        boolean isEvaluation = false;

        context.setupFullExport(isEvaluation);

        assertFalse(context.isSelectiveExport());
        assertEquals(isEvaluation, context.isEvaluation());
        assertTrue(context.getSelectedColumns().isEmpty());
        assertArrayEquals(ExportFieldMappingConfig.FULL_EXPORT_FIELDS, context.getFieldsToProcess());
    }

    @Test
    void testSetupFullExport_Evaluation() {
        boolean isEvaluation = true;

        context.setupFullExport(isEvaluation);

        assertFalse(context.isSelectiveExport());
        assertEquals(isEvaluation, context.isEvaluation());
        assertTrue(context.getSelectedColumns().isEmpty());
        assertArrayEquals(ExportFieldMappingConfig.EVALUATION_FULL_EXPORT_FIELDS, context.getFieldsToProcess());
    }

    @Test
    void testSettersAndGetters() {
        // Test current row
        context.setCurrentRow(5);
        assertEquals(5, context.getCurrentRow());

        // Test Excel workbook and sheet
        assertNull(context.getCurrentExcel());
        assertNull(context.getCurrentSheet());

        // Test styles
        assertNull(context.getColumnHeaderStyle());
        assertNull(context.getDataStyle());
        assertNull(context.getBottomBorderStyle());
        assertNotNull(context.getGroupStyles());
        assertTrue(context.getGroupStyles().isEmpty());
    }
}
