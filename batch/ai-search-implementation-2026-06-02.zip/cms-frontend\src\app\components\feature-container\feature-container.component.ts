import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-feature-container',
  imports: [RouterOutlet, MatCardModule],
  templateUrl: './feature-container.component.html',
  styleUrl: './feature-container.component.scss',
})
export class FeatureContainerComponent {}
