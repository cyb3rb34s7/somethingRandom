package com.cms.backend.assets.service;

import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.common.util.ResponseHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

@SpringBootTest(classes = AssetExportImportTemplateServiceTest.class)
public class AssetExportImportTemplateServiceTest {
    @Mock
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private RegionEndpointService regionEndpointService;


    @InjectMocks
    private AssetExportImportTemplateService assetExportImportTemplateService;


    @Test
    void testExportSelectedFail() {
        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenThrow(new CustomException("Error in getting data from asset api"));
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().build();
        when(regionEndpointService.getOpenAPIEndpointNLB()).thenReturn("http://test-url/");
        Assertions.assertThrows(AssetApiFailureException.class,
            () -> assetExportImportTemplateService.exportSelected(assetFilterBodyDto, "test-filter"));
    }

    private record ExportSelectedTestParamsRecord(String filterType, FilterDto filterDto,
                                                  LinkedHashMap<String, Object> asset) {

    }

    private static Stream<Arguments> exportSelectedTestParams() {
        FilterDto noContentIdFilterDto = FilterDto.builder().key("licenseRange").build();
        FilterDto contentIdFilterDto = FilterDto.builder().key(Constants.CONTENT_ID)
            .values(List.of("contentId1")).build();
        LinkedHashMap<String, Object> basicAsset = new LinkedHashMap<>();
        basicAsset.put(Constants.CONTENT_ID, "contentId1");
        basicAsset.put(Constants.VC_CP_ID, "vcCpId1");
        basicAsset.put(Constants.COUNTRY, "cc");
        basicAsset.put(Constants.AVAILABLE_STARTING, "2025-05-01T00:00:00Z");
        basicAsset.put(Constants.EXPIRY_DATE, "2025-05-01T00:00:00Z");
        List<ExternalProviderDto> externalProvidersList = List.of(
            ExternalProviderDto.builder().externalProgramId("FSAMS3").idType("tmsId")
                .idProvider("tmssad").provider("tms").build());
        basicAsset.put("externalProvider", externalProvidersList);

        LinkedHashMap<String, Object> noExternalProviderAsset = ObjectUtils.clone(basicAsset);
        if (noExternalProviderAsset != null) {
            noExternalProviderAsset.put("externalProvider", null);
        }

        return Stream.of(
            Arguments.of(
                new ExportSelectedTestParamsRecord(Constants.EXPORT_TYPE,
                    noContentIdFilterDto, basicAsset)),
            Arguments.of(
                new ExportSelectedTestParamsRecord(Constants.EXPORT_TYPE_SELECTED,
                    noContentIdFilterDto, basicAsset)),
            Arguments.of(
                new ExportSelectedTestParamsRecord(Constants.EXPORT_TYPE_SELECTED,
                    contentIdFilterDto, noExternalProviderAsset))
        );
    }

    @ParameterizedTest
    @MethodSource("exportSelectedTestParams")
    void testExportSelected(ExportSelectedTestParamsRecord params) {
        Map<String, Object> payload = new HashMap<>();
        List<Object> assetList = new ArrayList<>();
        assetList.add(params.asset);
        payload.put("assets", assetList);

        ResponseDto listApiResponse = ResponseHandler.processSuccess(payload);

        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenReturn(ResponseEntity.ok(listApiResponse));
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder()
            .filters(List.of(params.filterDto)).build();
        Assertions.assertDoesNotThrow(
            () -> assetExportImportTemplateService.exportSelected(assetFilterBodyDto,
                params.filterType));
    }

}
