package com.cms.backend.assets.model;


import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssetRequestBodyDto {
    @Valid
    private VodAssetDto vodAssetDto;
    private AssetChangeHistoryDto assetChangeHistoryDto;
}