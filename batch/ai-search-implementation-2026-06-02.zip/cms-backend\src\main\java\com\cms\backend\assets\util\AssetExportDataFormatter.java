package com.cms.backend.assets.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.cms.backend.common.util.CommonMethodUtil;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class AssetExportDataFormatter {

    // Private constructor to prevent instantiation
    private AssetExportDataFormatter() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }

    // Constants for duplicated literals
    private static final String AVAILABLE_STARTING = "availableStarting";
    private static final String LICENSE_WINDOW_LIST = "licenseWindowList";
    private static final String EXPIRED = "EXPIRED";
    private static final String AVAILABLE_ENDING = "availableEnding";
    private static final String CURRENT = "CURRENT";
    private static final String FUTURE = "FUTURE";
    private static final String EVENT_STARTING = "eventStarting";
    private static final String EVENT_WINDOW_LIST = "eventWindowList";
    private static final String EVENT_ENDING = "eventEnding";
    private static final String GEO_RESTRICTIONS = "geoRestrictions";

    public static String extractComputedValue(JsonNode asset, String fieldName, Instant exportTime) {
        switch (fieldName) {
            case "computedRatings":
                return formatRatings(asset.get("parentalRatings"));
            case "computedActor":
                return formatCast(asset.get("cast"), "actor");
            case "computedDirector":
                return formatCast(asset.get("cast"), "director");
            case "computedExternalIds":
                return formatExternalIds(asset.get("externalProvider"));

            // License Windows
            case "expiredLWs":
                return categorizeWindows(asset.get(LICENSE_WINDOW_LIST), exportTime, EXPIRED, AVAILABLE_STARTING,
                        AVAILABLE_ENDING);
            case "currentLWs":
                return categorizeWindows(asset.get(LICENSE_WINDOW_LIST), exportTime, CURRENT, AVAILABLE_STARTING,
                        AVAILABLE_ENDING);
            case "futureLWs":
                return categorizeWindows(asset.get(LICENSE_WINDOW_LIST), exportTime, FUTURE, AVAILABLE_STARTING,
                        AVAILABLE_ENDING);

            // Event Windows
            case "expiredEWs":
                return categorizeWindows(asset.get(EVENT_WINDOW_LIST), exportTime, EXPIRED, EVENT_STARTING,
                        EVENT_ENDING);
            case "currentEWs":
                return categorizeWindows(asset.get(EVENT_WINDOW_LIST), exportTime, CURRENT, EVENT_STARTING,
                        EVENT_ENDING);
            case "futureEWs":
                return categorizeWindows(asset.get(EVENT_WINDOW_LIST), exportTime, FUTURE, EVENT_STARTING,
                        EVENT_ENDING);

            // Geo Restrictions
            case "geoAccessType":
                return extractSimpleJsonArray(asset.get(GEO_RESTRICTIONS), "accessType");
            case "geoRestrictionType":
                return extractSimpleJsonArray(asset.get(GEO_RESTRICTIONS), "restrictionType");
            case "geoTeamRegion":
                return extractSimpleJsonArray(asset.get(GEO_RESTRICTIONS), "teamRegion");

            default:
                return "";
        }
    }

    private static String categorizeWindows(JsonNode windowList, Instant now, String targetStatus, String startKey,
            String endKey) {
        if (windowList == null || !windowList.isArray())
            return "";

        List<String> validWindows = new ArrayList<>();

        for (JsonNode window : windowList) {
            String startStr = window.path(startKey).asText(null);
            String endStr = window.path(endKey).asText(null);

            if (startStr == null || startStr.isEmpty())
                continue;

            try {
                Instant startDateTime = Instant.parse(startStr);
                Instant endDateTime = (endStr != null && !endStr.isEmpty()) ? Instant.parse(endStr) : Instant.MAX;

                String currentStatus = determineCurrentStatus(startDateTime, endDateTime, now);

                if (currentStatus.equals(targetStatus)) {
                    String formattedWindow = formatWindowDates(startStr, endStr);
                    validWindows.add(formattedWindow);
                }
            } catch (DateTimeParseException e) {
                // Ignore invalid date mappings and continue parsing valid ones
            }
        }
        return String.join(", ", validWindows);
    }

    private static String determineCurrentStatus(Instant startDateTime, Instant endDateTime, Instant now) {
        if (startDateTime.isAfter(now)) {
            return FUTURE;
        } else if (endDateTime.isBefore(now)) {
            return EXPIRED;
        } else {
            return CURRENT;
        }
    }

    private static String formatWindowDates(String startStr, String endStr) {
        String formattedStart = CommonMethodUtil.formatDateField(startStr);
        String formattedEnd = (endStr != null && !endStr.isEmpty())
                ? CommonMethodUtil.formatDateField(endStr)
                : "";
        return formattedStart + ";" + formattedEnd;
    }

    private static String formatCast(JsonNode castNode, String targetRole) {
        if (castNode == null || !castNode.isArray())
            return "";
        List<String> results = new ArrayList<>();

        for (JsonNode member : castNode) {
            if (targetRole.equalsIgnoreCase(member.path("role").asText(""))) {
                String name = member.path("name").asText("");
                String character = member.path("characterName").asText("");

                if (!character.isEmpty()) {
                    results.add(name + " (" + character + ")");
                } else if (!name.isEmpty()) {
                    results.add(name);
                }
            }
        }
        return String.join(", ", results);
    }

    private static String formatRatings(JsonNode ratingsNode) {
        if (ratingsNode == null || !ratingsNode.isArray())
            return "";
        List<String> results = new ArrayList<>();

        for (JsonNode rating : ratingsNode) {
            String body = rating.path("body").asText("");
            String value = rating.path("ratings").asText("");
            if (!body.isEmpty() || !value.isEmpty()) {
                results.add(body + " (" + value + ")");
            }
        }
        return String.join(", ", results);
    }

    private static String formatExternalIds(JsonNode providerNode) {
        if (providerNode == null || !providerNode.isArray())
            return "";
        List<String> results = new ArrayList<>();

        for (JsonNode provider : providerNode) {
            String prov = provider.path("provider").asText("");
            String extId = provider.path("externalProgramId").asText("");
            if (!prov.isEmpty() && !extId.isEmpty()) {
                results.add(prov + ": " + extId);
            }
        }
        return String.join(", ", results);
    }

    private static String extractSimpleJsonArray(JsonNode arrayNode, String key) {
        if (arrayNode == null || !arrayNode.isArray())
            return "";
        List<String> results = new ArrayList<>();
        for (JsonNode node : arrayNode) {
            String val = node.path(key).asText("");
            if (!val.isEmpty())
                results.add(val);
        }
        return String.join(", ", results);
    }
}
