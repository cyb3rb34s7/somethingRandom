package com.cms.backend.common.test;

import org.junit.jupiter.api.function.Executable;
import org.springframework.dao.DataIntegrityViolationException;

import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Utility class for common exception testing operations to reduce code duplication.
 */
public class ExceptionTestUtility {
    
    /**
     * Asserts that the executable throws a DataIntegrityViolationException
     * 
     * @param executable The code to execute
     */
    public static void assertDataIntegrityViolationException(Executable executable) {
        assertThrows(DataIntegrityViolationException.class, executable);
    }
    
    /**
     * Asserts that the executable throws a CustomException
     * 
     * @param executable The code to execute
     */
    public static void assertCustomException(Executable executable) {
        try {
            Class<?> customExceptionClass = Class.forName(
                "com.cms.backend.common.exception.CustomException");
            assertThrows((Class<? extends Throwable>) customExceptionClass, executable);
        } catch (ClassNotFoundException e) {
            // Fallback to generic exception assertion
            assertThrows(Exception.class, executable);
        }
    }
    
    /**
     * Asserts that the executable throws an exception of the specified type
     * 
     * @param exceptionClass The exception class to expect
     * @param executable The code to execute
     */
    public static <T extends Throwable> void assertException(Class<T> exceptionClass, Executable executable) {
        assertThrows(exceptionClass, executable);
    }
}
