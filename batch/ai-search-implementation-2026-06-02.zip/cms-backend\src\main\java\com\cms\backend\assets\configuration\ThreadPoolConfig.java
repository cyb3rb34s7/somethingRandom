package com.cms.backend.assets.configuration;

import com.cms.backend.common.configuration.MdcTaskDecorator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@Slf4j
public class ThreadPoolConfig {

    @Bean("exportTaskExecutor")
    public ThreadPoolTaskExecutor exportTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);   // Number of threads in the pool
        executor.setMaxPoolSize(5);    // Max number of threads
        executor.setThreadNamePrefix("ExportAsset-");
        executor.setTaskDecorator(new MdcTaskDecorator());
        executor.initialize();

        return executor;
    }


}