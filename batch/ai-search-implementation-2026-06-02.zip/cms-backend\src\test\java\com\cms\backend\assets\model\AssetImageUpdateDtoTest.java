package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.multipart.MultipartFile;

@SpringBootTest(classes = AssetImageUpdateDtoTest.class)
class AssetImageUpdateDtoTest {

    @Mock
    private MultipartFile mockMultipartFile = mock(MultipartFile.class);

    @Test
    void testAssetImageUpdateDtoWithNormalValues() {
        // Create a new instance of AssetImageUpdateDto with normal values
        AssetImageUpdateDto assetImageUpdateDto = new AssetImageUpdateDto();
        
        assetImageUpdateDto.setLandscapeImageBannerFile(mockMultipartFile);
        assetImageUpdateDto.setPortraitImageBannerFile(mockMultipartFile);
        assetImageUpdateDto.setLandscapeImageIconicFile(mockMultipartFile);
        assetImageUpdateDto.setPortraitImageIconicFile(mockMultipartFile);
        assetImageUpdateDto.setImageCircleFile(mockMultipartFile);
        assetImageUpdateDto.setCountryCode("KR");
        assetImageUpdateDto.setProviderId("12345");
        assetImageUpdateDto.setProgramId("67890");

        // Verify that all mandatory fields have been set correctly
        assertEquals("KR", assetImageUpdateDto.getCountryCode());
        assertEquals("12345", assetImageUpdateDto.getProviderId());
        assertEquals("67890", assetImageUpdateDto.getProgramId());

        // Verify that optional fields are not null
        assertNotNull(assetImageUpdateDto.getLandscapeImageBannerFile());
        assertNotNull(assetImageUpdateDto.getPortraitImageBannerFile());
        assertNotNull(assetImageUpdateDto.getLandscapeImageIconicFile());
        assertNotNull(assetImageUpdateDto.getPortraitImageIconicFile());
        assertNotNull(assetImageUpdateDto.getImageCircleFile());
    }

    @Test
    void testAssetImageUpdateDtoWithNullValues() {
        // Create a new instance of AssetImageUpdateDto with null values
        AssetImageUpdateDto assetImageUpdateDto = new AssetImageUpdateDto();

        // Set mandatory fields with null values
        assetImageUpdateDto.setCountryCode(null);
        assetImageUpdateDto.setProviderId(null);
        assetImageUpdateDto.setProgramId(null);

        // Verify that all mandatory fields are null
        assertNull(assetImageUpdateDto.getCountryCode());
        assertNull(assetImageUpdateDto.getProviderId());
        assertNull(assetImageUpdateDto.getProgramId());

        // Verify that optional fields are null by default
        assertNull(assetImageUpdateDto.getLandscapeImageBannerFile());
        assertNull(assetImageUpdateDto.getPortraitImageBannerFile());
        assertNull(assetImageUpdateDto.getLandscapeImageIconicFile());
        assertNull(assetImageUpdateDto.getPortraitImageIconicFile());
        assertNull(assetImageUpdateDto.getImageCircleFile());
    }
}