package com.cms.backend.common.configuration;

import com.cms.backend.common.util.TraceIdGeneratorUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.util.StringUtil;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MDCFilter implements Filter {


    public static final String X_TRACE_ID = "X-Trace-Id";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
        FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;

        // Skip MDC operations for /admin/ping endpoint
        if ("/admin/ping".equals(request.getRequestURI())) {
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }
        String traceId = request.getHeader(X_TRACE_ID);
        if (!StringUtil.isBlank(traceId)) {
            MDC.put(X_TRACE_ID, traceId);
        } else {
            MDC.put(X_TRACE_ID, TraceIdGeneratorUtil.generate());
        }
        long startTime = System.currentTimeMillis();
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            log.info("Total time taken {} ms", duration);
            MDC.clear();
        }
    }
}
