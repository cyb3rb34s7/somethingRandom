package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.s3.S3Client;

class S3ClientConfigTest {

    @InjectMocks
    private S3ClientConfig s3ClientConfig;

    @Mock
    private S3Client s3Client;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(s3ClientConfig, "region", "us-east-1");
    }

    @Test
    void testAmazonS3() {
        S3Client s3Client = s3ClientConfig.amazonS3();
        assertNotNull(s3Client);
    }
}
