package com.cms.backend.assets.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssetSingleImageUpdateDto {

    @NotNull(message = "Country code is mandatory.")
    private String countryCode;

    @NotNull(message = "Provider Id is mandatory.")
    private String providerId;

    @NotNull(message = "Program Id is mandatory.")
    private String programId;
    private MultipartFile imageFile;


}
