package com.cms.backend.common.model;

import java.util.Map;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class SecurityUser {

    private String serviceRegion;
    private String userId;
    private String uuid;
    private String sessionId;
    private String username;
    private Map<String, String> allUsers;

    // Default constructor
    public SecurityUser() {
        this.username = "testUser";


    }

    public SecurityUser(String userId,
        String serviceRegion, String uuid, String sessionId, Map<String, String> allUsers) {
        this.username = userId;
        this.userId = userId;
        this.serviceRegion = serviceRegion;
        this.uuid = uuid;
        this.sessionId = sessionId;
        this.allUsers = allUsers;
    }


    @Override
    public int hashCode() {
        return Objects.hash(username, serviceRegion, userId, uuid,
            sessionId, allUsers);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof SecurityUser)) {
            return false;
        }

        SecurityUser secUser = (SecurityUser) obj;
        return Objects.equals(this.username, secUser.username) &&
            Objects.equals(this.serviceRegion, secUser.serviceRegion) &&
            Objects.equals(this.userId, secUser.userId) &&
            Objects.equals(this.uuid, secUser.uuid) &&
            Objects.equals(this.sessionId, secUser.sessionId) &&
            Objects.equals(this.allUsers, secUser.getAllUsers());
    }


}
