package com.cms.backend.assets.configuration;


import com.cms.backend.common.enums.Regions;
import com.cms.backend.common.exception.CustomException;
import jakarta.annotation.PostConstruct;
import java.time.Duration;
import java.time.Instant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3ClientBuilder;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleResponse;
import software.amazon.awssdk.services.sts.model.Credentials;

@Service
@Slf4j
public class S3Config {

    private static final long FIVE_MIN = 300000;
    @Value("${ROLE_ARN}")
    private String roleArn;
    private Credentials credentials = null;

    @PostConstruct
    private void init() {
        if (!StringUtils.isEmpty(roleArn) && roleArn.indexOf('/') > -1) {
            this.createCredentials();
        }
    }

    public S3Client usAmazonS3() {

        S3ClientBuilder s3Client = S3Client.builder().region(
            Region.of(Regions.US_REGION.value));
        if (!StringUtils.isEmpty(roleArn) && roleArn.indexOf('/') > -1) {
            s3Client.credentialsProvider(StaticCredentialsProvider.create(
                getBasicCredentials()));
        } else {
            s3Client.credentialsProvider(DefaultCredentialsProvider.builder().build());
        }
        log.info(" US AmazonS3 created");
        return s3Client.build();
    }


    public S3Client euAmazonS3() {

        S3ClientBuilder s3Client = S3Client.builder().region(
            Region.of(Regions.EU_REGION.value));
        if (!StringUtils.isEmpty(roleArn) && roleArn.indexOf('/') > -1) {
            s3Client.credentialsProvider(StaticCredentialsProvider.create(
                getBasicCredentials()));
        } else {
            s3Client.credentialsProvider(DefaultCredentialsProvider.builder().build());
        }
        log.info("EU AmazonS3 created");
        return s3Client.build();
    }

    public AwsSessionCredentials getBasicCredentials() {
        if (this.credentials == null) {
            throw new CustomException("Upload Image permission denied");
        }
        if (isCredentialsExpirationTimeWithin(FIVE_MIN)) {
            this.createCredentials();
            log.info("RoleBase Key is updated!!!!!");
        }
        return AwsSessionCredentials.create(credentials.accessKeyId(),
            credentials.secretAccessKey(), credentials.sessionToken());
    }

    private void createCredentials() {
        log.info("Creating Role Based Key for S3");
        StsClient stsClient = StsClient.builder().region(Region.of(Regions.US_REGION.value))
            .build();
        AssumeRoleRequest assumeRoleRequest = AssumeRoleRequest.builder().roleArn(roleArn)
            .durationSeconds(3600).roleSessionName("openapi_assumeRole_session").build();

        AssumeRoleResponse assumeRoleResponse = stsClient.assumeRole(assumeRoleRequest);
        credentials = assumeRoleResponse.credentials();
        stsClient.close();

    }

    private boolean isCredentialsExpirationTimeWithin(long time) {
        return Instant.now().plus(Duration.ofSeconds(time)).isAfter(credentials.expiration());
    }


}
