package com.cms.backend.assets.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssetKeyDto {

    @NotNull(message = "contentId can not be null")
    private String contentId;
    @NotNull(message = "countryCode can not be null")
    private String countryCode;
    @NotNull(message = "vcCpId can not be null")
    private String vcCpId;
    private String type;
    private String showId;
    private String seasonId;
    private String lastAssetStatus;

}