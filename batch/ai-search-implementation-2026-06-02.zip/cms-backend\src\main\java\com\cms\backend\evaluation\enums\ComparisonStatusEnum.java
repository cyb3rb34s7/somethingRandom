package com.cms.backend.evaluation.enums;

import lombok.Getter;

@Getter
public enum ComparisonStatusEnum {
    MATCHING("MATCHING"),
    MISMATCHING("MISMATCHING"),
    NONE("NONE");

    private final String value;

    ComparisonStatusEnum(String value) {
        this.value = value;
    }
}
