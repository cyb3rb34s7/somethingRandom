package com.cms.backend.assets.aisearch.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import org.junit.jupiter.api.Test;

class AiSearchConfigTest {

    @Test
    void providesSystemDefaultZoneClock() {
        Clock clock = new AiSearchConfig().aiSearchClock();
        assertThat(clock).isNotNull();
        assertThat(clock.getZone()).isEqualTo(java.time.ZoneId.systemDefault());
    }
}
