package com.cms.backend.changehistory.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChangeHistoryFilterBodyDto {

    private List<ChangeHistoryFilterDto> filters;
    private List<String> columns;
    private ChangeHistorySortDto sortBy;
    private ChangeHistoryPaginationDto pagination;
}