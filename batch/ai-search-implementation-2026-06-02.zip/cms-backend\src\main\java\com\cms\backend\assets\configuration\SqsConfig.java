package com.cms.backend.assets.configuration;


import com.cms.backend.common.enums.Regions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;


@Configuration
@Slf4j
public class SqsConfig {

    @Value("${REGION}")
    public String region;

    @Bean("usSqsClient")
    public SqsClient amazonUSSQSAsync() {
        SqsClient sqsClient = SqsClient.builder()
            .region(Region.of(Regions.US_REGION.value))
            .credentialsProvider(DefaultCredentialsProvider.builder().build())
            .build();
        log.info("US AmazonSQSAsync created ");
        return sqsClient;
    }

    @Bean("euSqsClient")
    public SqsClient amazonEUSQSAsync() {
        SqsClient sqsClient = SqsClient.builder()
            .region(Region.of(Regions.EU_REGION.value))
            .credentialsProvider(DefaultCredentialsProvider.builder().build())
            .build();
        log.info("EU AmazonSQSAsync created ");
        return sqsClient;
    }
}