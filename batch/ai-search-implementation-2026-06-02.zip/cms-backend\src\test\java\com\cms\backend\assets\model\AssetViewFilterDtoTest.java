package com.cms.backend.assets.model;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetViewFilterDtoTest.class)
class AssetViewFilterDtoTest {

    @Test
    void testAssetViewFilterDtoWithNormalValues() {
        // Arrange
        List<PlatformTagData> platforms = Arrays.asList(Mockito.mock(PlatformTagData.class));
        List<LanguageDto> languages = Arrays.asList(Mockito.mock(LanguageDto.class));
        List<String> parentalRatings = Arrays.asList("G", "PG");
        AssetViewFilterDto assetViewFilterDto1 = new AssetViewFilterDto();
        assetViewFilterDto1.setLanguages(new ArrayList<>());
        assetViewFilterDto1.setPlatforms(new ArrayList<>());
        assetViewFilterDto1.setParentalRatings(new ArrayList<>());

        // Act
        AssetViewFilterDto assetViewFilterDto = AssetViewFilterDto.builder()
            .platforms(platforms)
            .languages(languages)
            .parentalRatings(parentalRatings)
            .build();

        // Assert
        assertThat(assetViewFilterDto.getPlatforms()).isEqualTo(platforms);
        assertThat(assetViewFilterDto.getLanguages()).isEqualTo(languages);
        assertThat(assetViewFilterDto.getParentalRatings()).isEqualTo(parentalRatings);

    }
}