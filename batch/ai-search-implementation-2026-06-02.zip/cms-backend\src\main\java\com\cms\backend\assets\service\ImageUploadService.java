package com.cms.backend.assets.service;

import com.cms.backend.assets.model.ImagePreProcessDto;
import com.cms.backend.assets.model.ImageProcessDetails;
import com.cms.backend.assets.model.ImageProcessedDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Service
@Slf4j
public class ImageUploadService {


    private static final int MAX_RETRY_COUNT = 2;
    public static final String ERROR_WHILE_FETCHING_PROCESSING_STATUS = "Error while fetching  processing status";
    public static final String ERROR_WHILE_FETCHING_PROCESSED_IMAGES_FROM_EXIF_SERVICE = "Error while fetching processed images from exif service";
    private final HttpMethodHandler httpMethodHandler;
    private final RegionEndpointService regionEndpointService;


    public ImageUploadService(HttpMethodHandler httpMethodHandler,
        RegionEndpointService regionEndpointService) {
        this.httpMethodHandler = httpMethodHandler;
        this.regionEndpointService = regionEndpointService;
    }

    public String s3Upload(MultipartFile file, String programId) throws IOException {
        String uuidSubStr = UUID.randomUUID().toString().substring(0, 5);
        try {
            log.debug("Uploading a new object to S3 Bucket{}  with path {}  with name{}",
                regionEndpointService.getBucketName(), regionEndpointService.getUploadPath(),
                file.getOriginalFilename());

            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(regionEndpointService.getBucketName())
                .key(regionEndpointService.getUploadPath() + "/" + programId + "/"
                    + uuidSubStr + "_" + file.getOriginalFilename()).cacheControl("max-age=86400")
                .contentDisposition("inline").contentType("image/*").contentLength(file.getSize())
                .build();

            regionEndpointService.getS3Client().putObject(putObjectRequest,
                RequestBody.fromInputStream(
                    file.getInputStream(), file.getSize()));
        } catch (AwsServiceException e) {
            log.error("Error while uploading image to S3 bucket", e);
            throw AwsServiceException.builder().message("Error while uploading image to S3 bucket")
                .build();
        } catch (IOException e) {
            log.error(
                "Error while uploading image to S3", e);
            throw new IOException(e);
        }
        return createCloudFrontUrl(file.getOriginalFilename(), programId, uuidSubStr);
    }

    public ImageProcessDetails triggerExifWithImageInsert(ImagePreProcessDto imagesDto) {
        try {
            String finalUrl =
                regionEndpointService.getExifEndpoint() + Constants.INSERT_EXIF_IMAGE;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, new HttpEntity<>(imagesDto),
                ResponseDto.class);
            Map<String, Object> imageProcessDetails = Objects.requireNonNull(
                    responseEntity.getBody())
                .getRsp().getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(
                imageProcessDetails.get("imageProcessDetails"),
                new TypeReference<>() {
                });
        } catch (Exception e) {
            log.error("Error while exif insert:{}", e.getMessage());
            throw new CustomException("Error while exif insert");
        }
    }

    public List<ImageProcessedDto> getImagesByRequestId(ImageProcessDetails imageProcessDetails,
        int retrycount) {
        try {
            if (imageProcessDetails.getProcessRequestId() == null
                || imageProcessDetails.getBatchRequestId() == null) {
                return List.of();
            }
            if ("IMG_EXISTS".equalsIgnoreCase(imageProcessDetails.getProcessRequestId())) {
                return this.getProcessedImages(imageProcessDetails.getBatchRequestId());
            }
            while (retrycount < MAX_RETRY_COUNT) {
                Thread.sleep(5000);
                String status = this.getProcessingStatus(imageProcessDetails.getProcessRequestId());
                if ("COMPLETE".equalsIgnoreCase(status)) {
                    return this.getProcessedImages(imageProcessDetails.getBatchRequestId());
                }
                retrycount++;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Thread Interrupted for Image response {}",
                imageProcessDetails.getBatchRequestId());
            throw new CustomException("Thread Interrupted");
        } catch (Exception e) {
            log.error("Error while Processing image:{}", e.getMessage());
        }
        return List.of();
    }

    private String getProcessingStatus(String requestId) {
        try {
            String finalUrl =
                regionEndpointService.getExifEndpoint() + Constants.GET_STATUS_EXIF_IMAGE;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam("requestId", requestId);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            if (responseEntity == null || responseEntity.getBody() == null) {
                log.error(ERROR_WHILE_FETCHING_PROCESSING_STATUS);
                throw new CustomException(
                    ERROR_WHILE_FETCHING_PROCESSING_STATUS);
            }
            ResponseDto response = responseEntity.getBody();
            if (response.getRsp() == null || response.getRsp().getPayload() == null) {
                log.error(ERROR_WHILE_FETCHING_PROCESSING_STATUS);
                throw new CustomException(
                    ERROR_WHILE_FETCHING_PROCESSING_STATUS);
            }
            Map<String, Object> status = Objects.requireNonNull(responseEntity.getBody())
                .getRsp().getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(
                status.get("processingStatus"),
                new TypeReference<>() {
                });
        } catch (IllegalArgumentException e) {
            log.error("Error while fetching processing status:{}", e.getMessage());
            throw new CustomException(e.getMessage());
        }
    }

    private List<ImageProcessedDto> getProcessedImages(String requestId) {
        try {
            String finalUrl =
                regionEndpointService.getExifEndpoint()
                    + Constants.GET_PROCESSED_IMAGE_EXIF_IMAGE;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam("requestId", requestId);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);

            if (responseEntity == null || responseEntity.getBody() == null) {
                log.error(ERROR_WHILE_FETCHING_PROCESSED_IMAGES_FROM_EXIF_SERVICE);
                throw new CustomException(
                    ERROR_WHILE_FETCHING_PROCESSED_IMAGES_FROM_EXIF_SERVICE);
            }
            ResponseDto response = responseEntity.getBody();
            if (response.getRsp() == null || response.getRsp().getPayload() == null) {
                log.error(ERROR_WHILE_FETCHING_PROCESSED_IMAGES_FROM_EXIF_SERVICE);
                throw new CustomException(
                    ERROR_WHILE_FETCHING_PROCESSED_IMAGES_FROM_EXIF_SERVICE);
            }
            Map<String, Object> processedImageList = Objects.requireNonNull(
                    responseEntity.getBody())
                .getRsp().getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(
                processedImageList.get("imageList"),
                new TypeReference<>() {
                });
        } catch (IllegalArgumentException e) {
            log.error("Error while fetching processed images:{}", e.getMessage());
            throw new CustomException(e.getMessage());
        }
    }

    private String createCloudFrontUrl(String fileName, String programId, String uuidSubStr) {
        return regionEndpointService.getCloudFrontUrl() + "/"
            + regionEndpointService.getUploadPath() + "/" + programId + "/" + uuidSubStr + "_"
            + fileName;
    }
}
