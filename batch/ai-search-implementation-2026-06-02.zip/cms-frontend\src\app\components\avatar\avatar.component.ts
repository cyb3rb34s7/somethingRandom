import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { RouterLink } from '@angular/router';
import { UserService } from '../../services/user.service';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { User } from '../../models/user-model';
import { STORE_CONSTS } from '../../constants/store-consts';
import { StateStoreService } from '../../services/store/state-store.service';
import { plainToInstance } from 'class-transformer';

import { RegionSelectorComponent } from '../region-selector/region-selector.component';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../models/assets-columns-filters-model';
import { HttpErrorResponse } from '@angular/common/http';
import { Country } from '../../models/country-model';
import { TimezoneToggleComponent } from '../timezone-toggle/timezone-toggle.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DevConsoleService } from '../../services/dev-console.service';

@Component({
  selector: 'app-avatar',
  imports: [
    RouterLink,
    MatMenuModule,
    MatButtonModule,
    RegionSelectorComponent,
    TimezoneToggleComponent,
  ],
  templateUrl: './avatar.component.html',
  styleUrl: './avatar.component.scss',
})
export class AvatarComponent implements OnInit {
  userDetails: User;
  routeConstants = SIDE_NAV_ROUTES;
  devEmails: string[] = [];
  constructor(
    private userService: UserService,
    private storeService: StateStoreService,
    private devConsoleService: DevConsoleService
  ) {}
  private destroy = inject(DestroyRef);

  ngOnInit(): void {
    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER].subscribe(
      (user: User) => {
        this.userDetails = user;
        this.setUserCountryFilters();
        this.getDevEmailFromStore();
        this.fetchUserAssetPreference();
      }
    );
  }

  setUserCountryFilters() {
    if (this.userDetails.userId) {
      const tmp: AssetColumnsAndFiltersAndFilterTemplates =
        this.storeService.getStoreState(
          STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
        );

      const objFilter: Filter = plainToInstance<Filter, {}>(Filter, {
        key: 'countryCode',
        type: 'filter',
        values: [],
      });

      const masterCountries = this.storeService.getStoreState(
        STORE_CONSTS.MASTER_COUNTRIES
      );

      objFilter.values = masterCountries.map((c: Country) => c.countryCode);
      objFilter.selected = this.userDetails.prefCountryCodes;

      tmp.filters.push(objFilter);

      tmp.userPrefCountrySet = true;

      this.storeService.setStoreState(
        STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
        tmp
      );
    }
  }

  getDevEmailFromStore() {
    const devEmailsID: string[] = this.storeService.getStoreState(
      STORE_CONSTS.DEV_EMAILS
    );

    if (devEmailsID.length > 0) {
      this.devEmails = [...devEmailsID];
    } else {
      this.getDevEmail();
    }
  }

  getDevEmail() {
    this.devConsoleService
      .getDeveloperEmailId()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res: any) => {
          this.storeService.setStoreState(STORE_CONSTS.DEV_EMAILS, res);
          this.devEmails = [...res];
        },
      });
  }

  fetchUserAssetPreference() {
    this.userService.getUserAssetPreference().subscribe({
      next: (res: any) => {
        if (res) {
          sessionStorage.setItem('asset-table-data', res);
        }
      },
      error: (error: HttpErrorResponse) => {},
    });
  }
}
