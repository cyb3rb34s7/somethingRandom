package com.cms.backend.common.constants;

public class VocabConstants {

    public static final String PAYLOAD_KEY = "vocabulary";
    public static final String SUCCESS_INSERT = "Successfully inserted the vocabulary.";
    public static final String SUCCESS_UPDATE = "Successfully updated the vocabulary.";
    public static final String SUCCESS_DELETE = "Successfully deleted the vocabulary.";
    public static final String DUPLICATE_KEYWORD = "Duplicate keyword provided. Please provide a unique keyword.";

    private VocabConstants() {
    }
}
