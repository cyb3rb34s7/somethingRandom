package com.cms.backend.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Setter
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
public class TypeCountDto {


    private String assetType;
    private int assetsCount;

    @DynamoDbAttribute("asset_type")
    public String getAssetType() {
        return assetType;
    }

    @DynamoDbAttribute("assets_count")
    public int getAssetsCount() {
        return assetsCount;
    }
}
