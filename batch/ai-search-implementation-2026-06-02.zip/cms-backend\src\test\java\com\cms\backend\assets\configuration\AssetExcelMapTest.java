package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetExcelMapTest {

    @Test
    void testGetMap() {
        Map<String, String> expectedMap = new LinkedHashMap<>();
        expectedMap.put("programid","contentId");
        expectedMap.put("assetid","assetId");
        expectedMap.put("programtype","type");
        expectedMap.put("country","countryCode");
        expectedMap.put("providerid","vcCpId");
        expectedMap.put("maintitle","mainTitle");
        expectedMap.put("shorttitle","shortTitle");
        expectedMap.put("duration(sec)","runningTime");
        expectedMap.put("adtags","adTag");
        expectedMap.put("streamurl","streamUri");
        expectedMap.put("synopsis","description");
        expectedMap.put("originalreleasedate","releaseDate");
        expectedMap.put("genre","genres");
        expectedMap.put("externalprogramid","externalProgramId");
        expectedMap.put("contentpartner/licensor","contentPartner");
        expectedMap.put("contenttier","contentTier");

        Map<String, String> actualMap = AssetExcelMap.getMap();
        assertEquals(expectedMap, actualMap);
    }
}
