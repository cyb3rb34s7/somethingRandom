package com.cms.backend.common.exception;

public class RolesInUseException extends RuntimeException {

    public RolesInUseException(String message) {
        super(message);
    }
}
