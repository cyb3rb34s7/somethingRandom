package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.services.sqs.SqsClient;

class SqsConfigTest {

    private SqsConfig sqsConfig;

    @BeforeEach
    void setUp() {
        sqsConfig = new SqsConfig();
        ReflectionTestUtils.setField(sqsConfig, "region", "us-east-1");
    }

    @Test
    void testAmazonSQSAsync() {
        SqsClient sqsClient = sqsConfig.amazonUSSQSAsync();
        assertNotNull(sqsClient);
    }
}
