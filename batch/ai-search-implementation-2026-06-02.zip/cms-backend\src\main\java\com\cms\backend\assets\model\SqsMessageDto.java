package com.cms.backend.assets.model;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@ToString()
public class SqsMessageDto {

    @SerializedName("event_type")
    private String eventType;

    @SerializedName("event_source")
    private String eventSource;

    @SerializedName("program_id")
    private String assetId;

    @SerializedName("provider_id")
    private String contentProvider;

    @SerializedName("country_code")
    private String countryCode;

    private String identifierId;

    private String sqsMessageId;

    private String messageSender;

    @SerializedName("trace_id")
    private String traceId;

    private String host;
}