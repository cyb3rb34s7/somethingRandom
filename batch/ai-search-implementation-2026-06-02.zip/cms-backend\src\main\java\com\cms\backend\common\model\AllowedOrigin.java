package com.cms.backend.common.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AllowedOrigin {

    @JsonProperty("shell-url")
    private String shellUrl;

    @JsonProperty("pple-url-frontend")
    private String ppleUrlFrontend;

    @JsonProperty("pple-url-backend-us")
    private String ppleUrlBackendUS;
    
    @JsonProperty("pple-url-backend-eu")
    private String ppleUrlBackendEU;
}
