package com.cms.backend.changehistory.service;

import com.cms.backend.changehistory.configuration.HistoryHeaderMap;
import com.cms.backend.changehistory.configuration.MetadataUpdate;
import com.cms.backend.changehistory.model.ChangeHistoryFilterBodyDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.LockHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.CommonMethodUtil;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.GsonBuilder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
public class ChangeHistoryService {

    private final HistoryHeaderMap historyHeaderMap;
    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;
    private final AuthenticatedUser authenticatedUser;


    private static final String UNKNOWN_USER = "Unknown User";

    // Batch/System user names that shouldn't be resolved from IMS
    private static final Set<String> SYSTEM_USERS = Set.of(
        "CMS_MEDIA_API", "CMS_LICENSE_API",
        "CMS_EVENT_API", "CMS_EVENT_REMOVAL_API", "CMS_ASSET_API", "QCPASS_REVOKE_BATCH",
        "CMS_VOD_IMPORTER", "DELTA_SYNCER", "CMS_SYNCER", "CMS_SYNCER_GREEN", "DELTA_SYNCER_GREEN"
    );

    public ChangeHistoryService(HistoryHeaderMap historyHeaderMap,
        RegionEndpointService regionEndpointService,
        HttpMethodHandler httpMethodHandler, AuthenticatedUser authenticatedUser) {
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
        this.historyHeaderMap = historyHeaderMap;

        this.authenticatedUser = authenticatedUser;
    }

    private void insertCells(Map<String, String> historyHeaderMap,
        LinkedHashMap<String, Object> asset, Row row, AtomicInteger colIdx,
        LinkedHashMap<String, Object> statusHistory) {
        historyHeaderMap.forEach((key, value) -> {
            if (asset != null && asset.get(key) != null) {
                setData(asset, key, row, colIdx);
            }
            if (statusHistory != null && statusHistory.get(key) != null) {
                setData(statusHistory, key, row, colIdx);
            }
            colIdx.getAndIncrement();
        });
    }

    private void setData(Map<String, Object> inputMap, String key, Row row, AtomicInteger colIdx) {
        if (Set.of(Constants.HISTORY_DATE_FMT1, Constants.HISTORY_DATE_FMT2,
            Constants.EXPORT_CURRENTRELEASEDATE, Constants.EXPORT_RELEASEDATE,
            Constants.EXPIRY_DATE, Constants.EXPORT_CURRENTEXPIRYDATE).contains(key)) {
            String correctDate = CommonMethodUtil.formatDateField(inputMap.get(key).toString());
            row.createCell(colIdx.get()).setCellValue(correctDate);
        } else {
            row.createCell(colIdx.get()).setCellValue(inputMap.get(key).toString());
        }

    }


    private void insertMetaChangeHistory(Map<String, String> map,
        LinkedHashMap<String, Object> asset, Row row, AtomicInteger colIdx, MetadataUpdate update,
        boolean allFields) { // all fields will display only for top row.
        map.forEach((key, value) -> {
            if (asset.get(key) == null) {
                insertJsonFields(row, colIdx, update, key);
            } else {
                insertAllFields(asset, row, colIdx, allFields, key);
            }
            colIdx.getAndIncrement();

        });
    }

    private void insertAllFields(LinkedHashMap<String, Object> asset, Row row, AtomicInteger j,
        boolean allFields, String key) {
        if (List.of(Constants.HISTORY_DATE_FMT1,
            Constants.HISTORY_DATE_FMT2).contains(key)) {
            if (allFields) {
                String correctDate = CommonMethodUtil.formatDateField(asset.get(key).toString());
                row.createCell(j.get()).setCellValue(correctDate);
            }
        } else {
            if (allFields) {
                row.createCell(j.get()).setCellValue(asset.get(key).toString());
            }
        }
    }

    private void insertJsonFields(Row row, AtomicInteger j, MetadataUpdate update, String key) {
        if ("field".equals(key)) {
            String mappedValue = historyHeaderMap.getJsonFieldMap()
                .getOrDefault(update.getField(),
                    update.getField());
            row.createCell(j.get()).setCellValue(mappedValue);
        } else if ("oldValue".equals(key)) {
            String val = update.getField().equals("availableStarting") || update.getField()
                .equals("expiryDate") ? CommonMethodUtil.formatDateField(
                update.getOldValue()) : update.getOldValue();

            row.createCell(j.get()).setCellValue(val);
        } else if ("newValue".equals(key)) {
            String val = update.getField().equals("availableStarting") || update.getField()
                .equals("expiryDate") ? CommonMethodUtil.formatDateField(
                update.getNewValue()) : update.getNewValue();

            row.createCell(j.get()).setCellValue(val);
        }
    }

    public ResponseDto getLicenseHistory(ChangeHistoryFilterBodyDto licenseGetFilterBody) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_LICENSE_HIST;
            HttpEntity<ChangeHistoryFilterBodyDto> httpEntity = new HttpEntity<>(
                licenseGetFilterBody);

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting asset license change history: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting asset license change history");
        }
    }

    public ResponseDto addEventHistory(EventHistoryRequestDto eventHistoryDto) {
        try {
            HttpEntity<EventHistoryRequestDto> httpEntity = new HttpEntity<>(eventHistoryDto);
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.ADD_EVENT_HIST;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while adding asset Event change history: {}", e.getMessage());
            throw new AssetApiFailureException("Error while adding asset Event change history");
        }
    }

    public ResponseDto addLockChangeHistory(LockHistoryRequestDto lockHistoryRequestDto) {
        try {
            HttpEntity<LockHistoryRequestDto> httpEntity = new HttpEntity<>(lockHistoryRequestDto);
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.ADD_LOCK_CHANGE_HIST;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while adding asset Lock change history: {}", e.getMessage());
            throw new AssetApiFailureException("Error while adding asset Lock change history");
        }
    }

    public ResponseDto getLicenseHistoryByAssetId(String assetId) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_LICENSE_HIST_ASSET
                    + "/" + assetId;
            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting asset license change history: {}", ex.getMessage());
            throw new AssetApiFailureException(
                "Error while getting license change - asset history");
        }

    }

    public ResponseDto addLicenseHistory(LicenseHistoryRequestDto licensePostBody) {
        try {
            HttpEntity<LicenseHistoryRequestDto> httpEntity = new HttpEntity<>(licensePostBody);
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.ADD_LICENSE_HIST;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while adding asset license change history: {}", e.getMessage());
            throw new AssetApiFailureException("Error while adding asset license change history");
        }
    }

    public ResponseDto getLicenseHistoryFilters() {
        try {
            String finalUrl = regionEndpointService.getHistoryAPIEndpoint()
                + Constants.GET_LICENSE_UI_FILTER_VALUES;

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            log.error("Error while getting filters: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting filters");
        }

    }

    public ResponseDto getMetadataHistory(ChangeHistoryFilterBodyDto metadataGetFilterBody) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_METADATA_HIST;
            HttpEntity<ChangeHistoryFilterBodyDto> httpEntity = new HttpEntity<>(
                metadataGetFilterBody);

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting metadata change history:{}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting metadata change history");
        }

    }

    public ResponseEntity<InputStreamResource> exportAssetStatusHistory(
        ChangeHistoryFilterBodyDto historyFilterBodyDto) {

        return exportHelper(Constants.EXPORT_ASSET_STATUS_HIST, Constants.DATA,
            Constants.ASSETSTATUS_HISTORY_NESTED_DATA,
            historyHeaderMap.getAssetStatusMap(), historyFilterBodyDto);
    }

    public ResponseEntity<InputStreamResource> exportMetadataHistory(
        ChangeHistoryFilterBodyDto historyFilterBodyDto) {

        return exportHelper(Constants.GET_METADATA_HIST, Constants.DATA, "",
            historyHeaderMap.getMetadataHistMap(),
            historyFilterBodyDto);
    }

    public ResponseEntity<InputStreamResource> exportLicenseHistory(
        ChangeHistoryFilterBodyDto historyFilterBodyDto) {

        return exportHelper(Constants.EXPORT_LICENSE_HIST, Constants.LIC_HISTORY,
            Constants.LIC_HISTORY_NESTED_DATA,
            historyHeaderMap.getLicenseHistMap(), historyFilterBodyDto);
    }

    public ResponseDto getMetadataHistoryByAssetId(String assetId,
        ChangeHistoryFilterBodyDto metadataGetFilterBody) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_METADATA_HIST_ASSET
                    + "/" + assetId;
            HttpEntity<ChangeHistoryFilterBodyDto> httpEntity = new HttpEntity<>(
                metadataGetFilterBody);

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting metadata change history:{}", ex.getMessage());
            throw new AssetApiFailureException(
                "Error while getting metadata change - asset history");
        }

    }

    public ResponseDto addMetadataHistory(MetadataHistoryRequestDto metadataPostbody) {
        try {
            HttpEntity<MetadataHistoryRequestDto> httpEntity = new HttpEntity<>(metadataPostbody);
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.ADD_METADATA_HIST;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while adding asset metaddata change history: {}", e.getMessage());
            throw new AssetApiFailureException("Error while adding asset metadata change history");
        }
    }

    public ResponseDto getAssetStatusHistory(ChangeHistoryFilterBodyDto statusGetFilterBody) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_ASSETSTATUS_HIST;
            HttpEntity<ChangeHistoryFilterBodyDto> httpEntity = new HttpEntity<>(
                statusGetFilterBody);

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting asset status change history: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting metadata change history");
        }

    }

    public ResponseDto getStatusHistoryByAssetId(String assetId) {
        try {
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.GET_ASSETSTATUS_HIST + "/"
                    + assetId;
            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);  // Resolve userId -> userName
            return response;
        } catch (Exception ex) {
            log.error("Error while getting asset status change history: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting asset status change history");
        }

    }

    public ResponseDto addAssetStatusHistory(StatusHistoryRequestDto statusPostBody) {
        try {
            HttpEntity<StatusHistoryRequestDto> httpEntity = new HttpEntity<>(statusPostBody);
            String finalUrl =
                regionEndpointService.getHistoryAPIEndpoint() + Constants.ADD_ASSETSTATUS_HIST;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while adding asset status change history: {}", e.getMessage());
            throw new AssetApiFailureException("Error while adding asset status history");
        }
    }

    public ResponseDto getMetadataHistoryFilters() {
        try {
            String finalUrl = regionEndpointService.getHistoryAPIEndpoint()
                + Constants.GET_METADATA_UI_FILTER_VALUES;

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            log.error("Error while getting metadata filters: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting metadata filters");
        }
    }

    public ResponseDto getAssetstatusHistoryFilters() {
        try {
            String finalUrl = regionEndpointService.getHistoryAPIEndpoint()
                + Constants.GET_ASSETSTATUS_UI_FILTER_VALUES;

            var builder = UriComponentsBuilder.fromUriString(finalUrl);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            log.error("Error while getting metadata filters: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting metadata filters");
        }
    }

    private CellStyle getCellStyle(Workbook workbook) {
        var cellStyle = workbook.createCellStyle();
        var font = workbook.createFont();
        font.setFontName("Courier New");
        font.setBold(true);
        font.setColor(HSSFColorPredefined.BLACK.getIndex());
        cellStyle.setFont(font);
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return cellStyle;
    }

    public ResponseEntity<InputStreamResource> exportHelper(
        String endPoint, String mainStructNm, String nestedStructureNm,
        Map<String, String> historyHeaderMap,
        ChangeHistoryFilterBodyDto historyFilterBodyDto) {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            var workbook = new SXSSFWorkbook()) {
            HttpEntity<ChangeHistoryFilterBodyDto> httpEntity = new HttpEntity<>(
                historyFilterBodyDto);

            String historyBackendURL = regionEndpointService.getHistoryAPIEndpoint() + endPoint;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                historyBackendURL,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);

            // Resolve userId -> userName for export
            ResponseDto response = responseEntity.getBody();
            resolveUserNames(response);

            List<LinkedHashMap<String, Object>> assetHistoryList;

            Object assetHistoryObj = Optional.of(responseEntity).map(HttpEntity::getBody)
                .map(ResponseDto::getRsp).map(BaseResponseDto::getPayload)
                .map(el -> el.get(mainStructNm)).orElse(new ArrayList<>());

            assetHistoryList = new ObjectMapper().convertValue(
                assetHistoryObj,
                new TypeReference<>() {
                });

            Sheet xlsSheet = workbook.createSheet(Constants.ASSETS);
            // create header row
            var headerRow = xlsSheet.createRow(0);
            var cellStyle = getCellStyle(workbook);
            headerRow.setRowStyle(cellStyle);
            var headerIndex = new AtomicInteger(0);
            historyHeaderMap.forEach((key, value) -> {
                headerRow.createCell(headerIndex.get()).setCellValue(value);
                headerRow.getCell(headerIndex.get()).setCellStyle(cellStyle);
                headerIndex.getAndIncrement();
            });

            var rowInsertionPoint = 1;
            for (var assetLoop = 0; assetLoop < assetHistoryList.size();
                assetLoop++, rowInsertionPoint++) {
                LinkedHashMap<String, Object> asset = assetHistoryList.get(assetLoop);

                xlsSheet.createRow(rowInsertionPoint);
                rowInsertionPoint++;

                var row = xlsSheet.createRow(rowInsertionPoint);
                var oldRowColIdx = new AtomicInteger(0);

                if (!nestedStructureNm.isEmpty()) { // license, asset status
                    rowInsertionPoint = insertHierarchicalHistory(nestedStructureNm,
                        historyHeaderMap,
                        asset, xlsSheet,
                        rowInsertionPoint, row, oldRowColIdx);
                } else {

                    // metadata has special case, since all structure is flat, and we need to parse
                    // json
                    rowInsertionPoint = insertFlatHistory(historyHeaderMap, asset, xlsSheet,
                        rowInsertionPoint, row,
                        oldRowColIdx);
                }
            }
            // write to byte array output stream
            workbook.write(outputStream);
            var byteArrayInputStream = new ByteArrayInputStream(
                outputStream.toByteArray());
            var httpHeaders = new HttpHeaders();
            httpHeaders.add("Content-Disposition", "attachment; filename=assets.xlsx");
            return ResponseEntity.ok().headers(httpHeaders).contentType(MediaType.parseMediaType(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(new InputStreamResource(byteArrayInputStream));
        } catch (IOException e) {
            log.error("IO error while exporting assets: {}", e.getMessage(), e);
            throw new AssetApiFailureException("Failed to write export file: ");
        }

    }

    private int insertFlatHistory(Map<String, String> historyHeaderMap,
        LinkedHashMap<String, Object> asset, Sheet xlsSheet, int rowInsertionPoint, Row row,
        AtomicInteger oldRowColIdx) {
        var allChanges = asset.get("changes").toString();
        var builder = new GsonBuilder();
        builder.setPrettyPrinting();
        var gson = builder.create();

        try {
            MetadataUpdate[] updates;
            updates = gson.fromJson(allChanges, MetadataUpdate[].class);
            for (var updateLoop = 0; updateLoop < updates.length; updateLoop++) {
                MetadataUpdate update = updates[updateLoop];

                if (updateLoop > 0) {
                    var newRow = xlsSheet.createRow(++rowInsertionPoint);
                    var newRowIdx = new AtomicInteger(0);
                    insertMetaChangeHistory(historyHeaderMap, asset, newRow, newRowIdx, update,
                        false);
                } else {
                    insertMetaChangeHistory(historyHeaderMap, asset, row, oldRowColIdx, update,
                        true);
                }
            }
        } catch (Exception e) {
            log.error("meta json is incorrect for asset id: {}", asset.get("assetId"));
        }

        return rowInsertionPoint;
    }

    private int insertHierarchicalHistory(String nestedStructureNm,
        Map<String, String> historyHeaderMap,
        LinkedHashMap<String, Object> asset, Sheet xlsSheet, int rowInsertionPoint, Row row,
        AtomicInteger oldRowColIdx) {
        List<LinkedHashMap<String, Object>> changeHistoryDetail = (List<LinkedHashMap<String, Object>>) asset
            .get(nestedStructureNm);

        for (var histIter = 0; histIter < changeHistoryDetail.size(); histIter++) {
            LinkedHashMap<String, Object> changeHistory = changeHistoryDetail.get(
                histIter);

            if (histIter > 0) { // change histories are put in new rows ( to Match with UI )
                var newRow = xlsSheet.createRow(++rowInsertionPoint);
                var newRowColIdx = new AtomicInteger(0);
                insertCells(historyHeaderMap, null, newRow, newRowColIdx, changeHistory);
            } else {
                insertCells(historyHeaderMap, asset, row, oldRowColIdx, changeHistory);
            }
        }
        return rowInsertionPoint;
    }

    private void resolveUserNames(ResponseDto response) {
        if (response == null || response.getRsp() == null ||
            response.getRsp().getPayload() == null) {
            return;
        }

        Map<String, Object> payload = response.getRsp().getPayload();

        // Process any List in payload (data, LicenseHistory, etc.)
        for (Object value : payload.values()) {
            if (!(value instanceof List<?> items)) {
                continue;
            }

            for (Object item : items) {
                if (!(item instanceof Map<?, ?> map)) {
                    continue;
                }

                // Level 1: Resolve parent-level fields (O(1) HashMap access)
                resolveField(map, "updatedBy");
                resolveField(map, "latestUpdatedBy");

                // Level 2: Known nested arrays - direct access by key (O(1))
                resolveNestedList(map, "historyChanges");
                resolveNestedList(map, "statusHistoryChanges");
            }
        }
    }

    private void resolveNestedList(Map<?, ?> parentMap, String nestedKey) {
        Object nested = parentMap.get(nestedKey);  // O(1) direct access
        if (!(nested instanceof List<?> list)) {
            return;
        }

        for (Object item : list) {
            if (item instanceof Map<?, ?> map) {
                resolveField(map, "updatedBy");
            }
        }
    }

    private void resolveField(Map<?, ?> map, String field) {
        Object value = map.get(field);  // O(1)
        if (value instanceof String userId && !userId.isEmpty()) {
            String resolvedName = getUserName(userId);  // Handles SYSTEM_USERS + cache lookup
            ((Map<String, Object>) map).put(field, resolvedName);
        }
    }

    public String getUserName(String userId) {
        if (userId == null || userId.isEmpty()) {
            return UNKNOWN_USER;
        }
        // Handle system/batch users without IMS lookup
        if (SYSTEM_USERS.contains(userId.toUpperCase())) {
            return userId.toUpperCase();
        }
        Map<String, String> userMap = authenticatedUser.getUserInfo().getAllUsers();
        return userMap.getOrDefault(userId, UNKNOWN_USER);
    }
}