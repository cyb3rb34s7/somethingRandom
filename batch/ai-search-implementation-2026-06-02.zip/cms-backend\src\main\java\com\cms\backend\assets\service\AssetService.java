package com.cms.backend.assets.service;


import com.cms.backend.assets.mapper.AssetMapper;
import com.cms.backend.assets.model.AssetByColumnsReqDto;
import com.cms.backend.assets.model.AssetDetailsByColumnReqDto;
import com.cms.backend.assets.model.AssetEpisodeHierarchyDto;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetRequestBodyDto;
import com.cms.backend.assets.model.AssetSingleImageUpdateDto;
import com.cms.backend.assets.model.AssetUpdateByBulkDto;
import com.cms.backend.assets.model.EditValidationDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.ImagePreProcessDto;
import com.cms.backend.assets.model.ImageProcessDetails;
import com.cms.backend.assets.model.ImageProcessedDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.StatusGetDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.util.AssetUtil;
import com.cms.backend.assets.util.UpdateAssetUtils;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetColumns;
import com.cms.backend.common.enums.AssetEvents;
import com.cms.backend.common.enums.AssetStatus;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.exception.InvalidInputDataException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.DynamoDBService;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssetService {

    public static final String ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER = "Asset is not editable for this feed worker";
    private final HttpMethodHandler httpMethodHandler;
    private final AssetSyncerService assetSyncerService;
    private final AssetAsyncService assetAsyncService;
    private final AssetMapper assetMapper;
    private final AuthenticatedUser authenticatedUser;
    private final UpdateAssetUtils updateAssetUtils;
    private final ValidationAsset validationAsset;
    private final RegionEndpointService regionEndpointService;
    private final ImageUploadService imageUploadService;
    private final DynamoDBService dynamoDBService;
    private final AssetHelperService assetHelperService;
    private final AssetExcelEditService assetExcelEditService;
    ObjectMapper objectMapper = new ObjectMapper();


    @Value("${BATCH_SIZE:25}")
    private String batchSize;

    @Value("${FEED_WORKER_LIST:CMS,CMS_GRACENOTE}")
    private String feedWorkerList;


    public ResponseDto validateAssetDetails(EditValidationDto editValidationDto) {
        try {
            HttpEntity<EditValidationDto> httpEntity = new HttpEntity<>(editValidationDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.ASSET_VALIDATION_ENDPOINT;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred  validating asset details:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {
            log.error("Error while validating asset details:{}", e.getMessage());
            throw new AssetApiFailureException("Error while validating asset details");
        }
    }

    public ResponseDto getFilteredAssets(AssetFilterBodyDto assetFilterBodyDto) {
        try {
            HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(assetFilterBodyDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_FILTERED_ASSETS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred while getting filtered assets:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception e) {
            log.error("Error while getting filtered assets:{}", e.getMessage());
            throw new AssetApiFailureException("Error while getting filtered list");
        }
    }

    public ResponseDto getAssetView(String contentId, String cpId, String country) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_VIEW;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            builder.queryParam(Constants.COUNTRY, country);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(), Constants.METHOD_GET, null, ResponseDto.class);
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred while getting filtered assets:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (Exception ex) {
            log.error("Error while getting view:{}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting view");
        }

    }

    public ResponseDto updateAsset(VodAssetDto vodAssetDto) {
        try {
            log.info("Updating asset with payload={}", vodAssetDto.toString());
            validationAsset.validateVodContent(vodAssetDto);

            List<VodAssetDto> vodAssetDtoList = getAssetStatusByAPI(StatusGetDto.builder()
                .assetList(List.of(AssetKeyDto.builder().vcCpId(vodAssetDto.getVcCpId())
                    .countryCode(vodAssetDto.getCountryCode()).contentId(vodAssetDto.getContentId())
                    .build())).build());
            assetHelperService.validateStatusForEditing(vodAssetDto, vodAssetDtoList);

            HttpEntity<VodAssetDto> httpEntity = new HttpEntity<>(vodAssetDto);
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.ASSET_UPDATE;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);

            //need to handle push failure case
            vodAssetDtoList.forEach(vod -> {
                if (vod != null && vod.getIsSyncBlocked() != null && Boolean.FALSE.equals(
                    vod.getIsSyncBlocked())) {
                    assetSyncerService.pushMessageToSqsAsync(Constants.CONSTANT_UPDATE, List.of(
                        VodAssetDto.builder().contentId(vod.getContentId())
                            .feedWorker(vod.getFeedWorker()).vcCpId(vod.getVcCpId())
                            .countryCode(vod.getCountryCode()).build()));


                }
            });
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred  updating asset details:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (CustomException ex) {
            log.error("Custom error log:-Error while update asset:{}", ex.getMessage());
            throw new CustomException(ex.getMessage());
        } catch (Exception e) {
            log.error("Error while update asset:{}", e.getMessage());
            throw new AssetApiFailureException("Error while updating asset");
        }
    }

    public ResponseDto updateStatusByBulk(StatusUpdateDto statusUpdateDto) {
        try {
            log.info("Updating status with payload from portal={}", statusUpdateDto.toString());
            List<String> columns = List.of(AssetColumns.CURRENT_STATUS.value,
                AssetColumns.IDENTIFIER_ID.value, AssetColumns.VC_CP_ID.value,
                AssetColumns.COUNTRY_CODE.value,
                AssetColumns.CONTENT_ID.value, AssetColumns.IS_CMS_PRD.value,
                AssetColumns.FEED_WORKER.value,
                AssetColumns.TYPE.value, AssetColumns.SHOW_ID.value,
                AssetColumns.SEASON_ID.value);
            AssetByColumnsReqDto assetByColumnsReqDto = AssetByColumnsReqDto.builder()
                .assetList(statusUpdateDto.getAssetList()).columns(columns).build();
            List<VodAssetDto> vodAssetDtoList = getAssetInfoByAPI(assetByColumnsReqDto);
            if (AssetStatus.TEMP_QC_PASS.value.equalsIgnoreCase(statusUpdateDto.getStatus())
                || AssetStatus.QC_PASS.value.equalsIgnoreCase(
                statusUpdateDto.getStatus()) || AssetStatus.SMF_IMPORTED.value.equalsIgnoreCase(
                statusUpdateDto.getStatus())) {
                List<AssetKeyDto> seasonShowList = assetHelperService.extractSeasonShowList(
                    statusUpdateDto);
                if (!CollectionUtils.isEmpty(seasonShowList)) {
                    AssetByColumnsReqDto assetByColumnsReqDto1 = AssetByColumnsReqDto.builder()
                        .assetList(seasonShowList).columns(columns).build();
                    List<VodAssetDto> seasonShowListNew = new ArrayList<>(getAssetInfoByAPI(
                        assetByColumnsReqDto1).stream()
                        .filter(item -> item.getIsCmsProd() == 0 || item.getIsCmsProd() == 2)
                        .filter(
                            item -> Stream.of(AssetStatus.QC_PASS.value,
                                    AssetStatus.SMF_IMPORTED.value)
                                .noneMatch(item.getStatus()::equalsIgnoreCase))
                        .toList());
                    List<VodAssetDto> readyForQcAssets = new ArrayList<>(
                        seasonShowListNew.stream().filter(
                                item -> item.getStatus()
                                    .equalsIgnoreCase(AssetStatus.READY_FOR_QC.value))
                            .toList());
                    if (!CollectionUtils.isEmpty(readyForQcAssets)) {
                        updateStatus(
                            StatusUpdateDto.builder().status(AssetStatus.QC_IN_PROGRESS.value)
                                .assetList(
                                    new ArrayList<>(readyForQcAssets.stream()
                                        .map(item -> AssetKeyDto.builder().countryCode(
                                                item.getCountryCode()).vcCpId(item.getVcCpId())
                                            .contentId(item.getContentId()).build())
                                        .toList())).build(), readyForQcAssets);
                        readyForQcAssets.forEach(
                            item -> item.setStatus(AssetStatus.QC_IN_PROGRESS.value));
                    }
                    if (!CollectionUtils.isEmpty(seasonShowListNew)) {
                        vodAssetDtoList.addAll(seasonShowListNew);
                        statusUpdateDto.getAssetList()
                            .addAll(new ArrayList<>(seasonShowListNew.stream()
                                .map(item -> AssetKeyDto.builder().countryCode(
                                        item.getCountryCode()).vcCpId(item.getVcCpId())
                                    .contentId(item.getContentId()).build())
                                .toList()));

                    }
                }

            }

            return updateStatus(statusUpdateDto, vodAssetDtoList);
        } catch (CustomException e) {
            log.error("Error While Updating Status:{}", e.getMessage());
            throw new CustomException(e.getMessage());
        } catch (Exception e) {
            log.error("error while updating status:={}", e.getMessage());
            throw new AssetApiFailureException("Error while updating asset status");
        }
    }

    private ResponseDto updateStatus(StatusUpdateDto statusUpdateDto,
        List<VodAssetDto> vodAssetDtoList) {
        log.info("Updating status with modified payload={}", statusUpdateDto.toString());
        List<AssetKeyDto> processingAssets = new ArrayList<>();
        String eventType;

        assetHelperService.validateDeploymentEnv(statusUpdateDto);
        vodAssetDtoList.forEach(vod -> {
            if (AssetStatus.UNTRACKABLE.value.equalsIgnoreCase(vod.getStatus())) {
                throw new CustomException("Asset is not in TRACKABLE state");
            } else if (vod.getFeedWorker() == null || Arrays.stream(feedWorkerList.split(","))
                .noneMatch(vod.getFeedWorker()::equalsIgnoreCase)) {
                throw new CustomException(ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER);
            }
        });
        if (AssetStatus.REVOKED.value.equalsIgnoreCase(statusUpdateDto.getStatus())) {
            eventType = Constants.REVOKED;
            statusUpdateDto.setIsCmsProd(0);
        } else if (AssetStatus.QC_PASS.value.equalsIgnoreCase(statusUpdateDto.getStatus())
            || AssetStatus.TEMP_QC_PASS.value.equalsIgnoreCase(statusUpdateDto.getStatus())) {
            validateEditableStatusForQcPass(vodAssetDtoList);
            processingAssets = this.validateDynamoDbStatus(statusUpdateDto.getAssetList());
            assetHelperService.modifyStatusUpdateRequestBody(statusUpdateDto, processingAssets,
                vodAssetDtoList);
            eventType = Constants.QC_PASS;
        } else if (AssetStatus.SMF_IMPORTED.value.equalsIgnoreCase(statusUpdateDto.getStatus())) {
            this.validateAutoSyncEditableStatus(vodAssetDtoList);
            eventType = AssetEvents.AUTO_SYNC.value;
        } else {
            eventType = null;
        }
        ResponseEntity<ResponseDto> responseEntity = updateStatusInternal(statusUpdateDto,
            vodAssetDtoList, eventType);
        ResponseDto responseDto = responseEntity.getBody();
        prepareResponseDto(responseDto, processingAssets, vodAssetDtoList);
        return responseDto;
    }

    private ResponseEntity<ResponseDto> updateStatusInternal(StatusUpdateDto statusUpdateDto,
        List<VodAssetDto> vodAssetDtoList, String eventType) {
        insertPreviousStatus(statusUpdateDto, vodAssetDtoList);
        String finalUrl =
            regionEndpointService.getOpenAPIEndpoint() + Constants.UPDATE_ASSET_STATUS;
        ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
            finalUrl, Constants.METHOD_POST, new HttpEntity<>(statusUpdateDto),
            ResponseDto.class);
        AssetUtil.sortAssets(vodAssetDtoList, statusUpdateDto.getStatus());
        int batchSizes = Integer.parseInt(this.batchSize);
        for (int start = 0; start < vodAssetDtoList.size(); start += batchSizes) {
            int end = Math.min(vodAssetDtoList.size(), start + batchSizes);
            List<VodAssetDto> batch = vodAssetDtoList.subList(start, end);
            log.debug("Adding status history for assets:{}", statusUpdateDto.toString());
            assetAsyncService.addBulkStatusHistory(batch, statusUpdateDto);
            assetSyncerService.pushMessageToSqsAsync(eventType, batch);
        }

        return responseEntity;
    }


    private void prepareResponseDto(ResponseDto responseDto, List<AssetKeyDto> processingAssets,
        List<VodAssetDto> vodAssetDtoList) {
        if (responseDto != null && responseDto.getRsp() != null && !processingAssets.isEmpty()) {
            Map<String, Object> payload = new HashMap<>();
            if (vodAssetDtoList.isEmpty()) {
                payload.put("warn",
                    "(Asset(s)" + processingAssets.stream().map(AssetKeyDto::getContentId)
                        .collect(Collectors.joining(","))
                        + " assets are still in processing state.Please try after sometime.)");
            } else {
                payload.put("success", "Status Updated Successfully");
                payload.put("warn",
                    "(Asset(s)" + processingAssets.stream().map(AssetKeyDto::getContentId)
                        .collect(Collectors.joining(","))
                        + " assets are still in processing state.Please try after sometime.)");
            }
            responseDto.getRsp().setPayload(payload);
        }
    }


    private List<AssetKeyDto> validateDynamoDbStatus(List<AssetKeyDto> vodAssetDtoList) {
        List<AssetKeyDto> processingVodAssets = new ArrayList<>();
        try {
            log.info("Fetching processing asset list from dynamodb");
            vodAssetDtoList.forEach(vodAssetDto -> {
                List<AssetKeyDto> vodAssetDtos = dynamoDBService.getProcessingVodFromDynamo(
                    vodAssetDto);
                if (!vodAssetDtos.isEmpty() && vodAssetDtos.get(0).getContentId()
                    .equals(vodAssetDto.getContentId())) {
                    processingVodAssets.add(vodAssetDto);
                }
            });
        } catch (Exception ex) {
            log.error("Error while fetching processing asset list from dynamodb={}",
                ex.getMessage());
        }
        return processingVodAssets;
    }


    private void insertPreviousStatus(StatusUpdateDto statusUpdateDto,
        List<VodAssetDto> vodAssetDtoList) {
        log.info("Inserting previous status for assets:{}", statusUpdateDto.toString());
        statusUpdateDto.getAssetList().forEach(vod -> vodAssetDtoList.stream().filter(
                vod1 -> vod1.getContentId().equalsIgnoreCase(vod.getContentId())).findFirst()
            .ifPresent(vod1 -> vod.setLastAssetStatus(vod1.getStatus())));
    }


    private void validateEditableStatusForQcPass(List<VodAssetDto> vodAssetDtoList) {
        vodAssetDtoList.forEach(vod -> {
            if (!(AssetStatus.QC_IN_PROGRESS.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.REVOKED.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.QC_FAIL.value.equalsIgnoreCase(vod.getStatus()))) {
                throw new CustomException(
                    "Asset is not in QC in progress or Revoked state or QC Fail");
            }
        });
    }

    private void validateAutoSyncEditableStatus(List<VodAssetDto> vodAssetDtoList) {
        log.info("Validating editable status for auto sync asset");
        vodAssetDtoList.forEach(vod -> {
            if (!(AssetStatus.REVOKED.value.equalsIgnoreCase(vod.getStatus()))) {
                throw new CustomException(
                    "Asset is  not in Revoked State");
            }
        });
    }


    private List<VodAssetDto> getAssetStatusByAPI(StatusGetDto statusGetDto) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.GET_STATUS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(statusGetDto), ResponseDto.class);
            Map<String, Object> assets = Objects.requireNonNull(responseEntity.getBody()).getRsp()
                .getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(assets.get(Constants.ASSET_DETAILS), new TypeReference<>() {
            });

        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting asset status");
        }
    }

    public ResponseDto editAndHistoryCall(AssetRequestBodyDto assetRequestBodyDto) {
        if (assetRequestBodyDto == null) {
            return ResponseDto.builder().rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK)
                .err(ErrorResponseDto.builder().code(Constants.STATUS_OK)
                    .msg(Constants.UPDATE_API_ERROR).build()).build()).build();
        }
        ResponseDto responseDto = ResponseDto.builder().rsp(
            BaseResponseDto.builder().stat(Constants.STATUS_OK).err(
                ErrorResponseDto.builder().code(Constants.STATUS_OK)
                    .msg(Constants.VOD_ASSET_IS_NULL).build()).build()).build();
        if (assetRequestBodyDto.getVodAssetDto() != null) {
            responseDto = updateAsset(assetRequestBodyDto.getVodAssetDto());
            if (assetRequestBodyDto.getAssetChangeHistoryDto() != null) {
                assetAsyncService.insertAssetModificationHistory(
                    assetRequestBodyDto.getAssetChangeHistoryDto());
            }
        }

        return responseDto;
    }


    public Map<String, Object> uploadSingleImage(
        AssetSingleImageUpdateDto assetSingleImageUpdateDto) {
        Map<String, Object> payload = new HashMap<>();
        String uploadedImage = this.uploadImage(
            assetSingleImageUpdateDto.getImageFile(), assetSingleImageUpdateDto.getProgramId());
        List<String> imageLists = new ArrayList<>();
        if (!uploadedImage.isEmpty()) {
            imageLists.add(uploadedImage);
        }
        if (imageLists.isEmpty()) {
            return Map.of();
        }
        ImagePreProcessDto imagePreProcessDto = ImagePreProcessDto.builder()
            .assetId(assetSingleImageUpdateDto.getProgramId())
            .countryCode(assetSingleImageUpdateDto.getCountryCode())
            .providerId(assetSingleImageUpdateDto.getProviderId()).imageUrls(imageLists).build();
        ImageProcessDetails imageProcessDetails = imageUploadService.triggerExifWithImageInsert(
            imagePreProcessDto);
        List<ImageProcessedDto> imageProcessedDtos = imageUploadService.getImagesByRequestId(
            imageProcessDetails, 0);
        if (imageProcessedDtos == null) {
            throw new CustomException(Constants.IMAGE_UPLOAD_FAILED_PLEASE_TRY_AGAIN_LATER);
        }
        imageProcessedDtos.forEach(image -> {
            if (uploadedImage.equalsIgnoreCase(image.getOriginalUrl())
                && image.getProcessedUrl() != null && !image.getProcessedUrl().isEmpty()) {
                payload.put("originalImageUrl", uploadedImage);
                payload.put("processedImageUrl", image.getProcessedUrl());
                payload.put("processedWebpUrl", image.getProcessedWebpUrl());
            } else {
                throw new CustomException(Constants.IMAGE_UPLOAD_FAILED_PLEASE_TRY_AGAIN_LATER);
            }
        });
        return payload;
    }


    private String uploadImage(MultipartFile file, String programId) {
        try {
            if (file != null && !file.isEmpty() && file.getSize() > 0) {
                return imageUploadService.s3Upload(file, programId);
            } else {
                return "";
            }
        } catch (Exception e) {
            log.error("Error Occurred while uploading image to S3 bucket filename {} {}",
                file.getOriginalFilename(), e);
            throw new CustomException(Constants.IMAGE_UPLOAD_FAILED_PLEASE_TRY_AGAIN_LATER);
        }
    }

    public ResponseDto getShowHierarchy(AssetKeyDto assetKeyDto) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_SHOW_HIERARCHY;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(assetKeyDto), ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while in getting data of show hierarchy {}", e.getMessage());
            throw new AssetApiFailureException("Error while in getting data of show hierarchy");
        }
    }


    private ResponseDto updateAssetByBulk(AssetUpdateByBulkDto assetUpdateByBulkDto,
        List<VodAssetDto> oldVodAssetDtoList) throws JsonProcessingException {
        ResponseEntity<ResponseDto> responseEntity;
        List<VodAssetDto> newVodList = new ArrayList<>();
        VodAssetDto vodAssetDto = assetUpdateByBulkDto.getVodAssetDto();
        var mapper = new ObjectMapper();
        String vodAssetDtoAsString = mapper.writeValueAsString(vodAssetDto);
        for (String contentId : assetUpdateByBulkDto.getContentIds()) {
            vodAssetDto = objectMapper.readValue(vodAssetDtoAsString, VodAssetDto.class);
            vodAssetDto.setContentId(contentId);
            if (assetUpdateByBulkDto.getVodAssetDto().getRatings() != null) {
                for (VodAssetDto oldVodAssetDto : oldVodAssetDtoList) {
                    if (oldVodAssetDto.getContentId().equalsIgnoreCase(contentId)) {
                        assetHelperService.setDeepLinkPayloadOfPortal(vodAssetDto,
                            oldVodAssetDto.getDeeplinkPayload());
                    }
                }
            }
            newVodList.add(vodAssetDto);
        }
        this.assetHelperService.blockGracenoteLockedFields(newVodList, oldVodAssetDtoList);
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint()
                + Constants.UPDATE_ASSET_BY_BULK_OF_PORTAL;

            responseEntity = httpMethodHandler.handleHttpExchange(finalUrl, Constants.METHOD_POST,
                new HttpEntity<>(newVodList), ResponseDto.class);

        } catch (Exception e) {
            log.error("Error while asset update by bulk {}", e.getMessage());
            throw new AssetApiFailureException("Error while asset update by bulk method");
        }
        return responseEntity.getBody();
    }


    private ResponseDto getAssetsDataForHistory(
        AssetDetailsByColumnReqDto assetDetailsByColumnReqDto) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_DATA_FOR_HISTORY;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST,
                new HttpEntity<>(assetDetailsByColumnReqDto), ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while getting multiple assets data for history:{}", e.getMessage());
            throw new AssetApiFailureException(Constants.ERROR_IN_GETTING_MASTER_DATA);
        }
    }

    public ResponseDto updateAssetInBulkPortal(AssetUpdateByBulkDto assetUpdateByBulkDto) {

        try {
            VodAssetDto vodAsset = assetUpdateByBulkDto.getVodAssetDto();
            List<String> columns = assetHelperService.getColumnsForHistory(vodAsset);
            columns.add(Constants.ASSET_STATUS);
            columns.add(Constants.IS_CMS_PROD);
            columns.add(AssetColumns.EXTERNAL_PROVIDER_LIST.value);
            columns.add("lockedFields");

            List<AssetKeyDto> assetKeyList = assetUpdateByBulkDto.getContentIds().stream()
                .map(contentId -> AssetKeyDto.builder().vcCpId(vodAsset.getVcCpId())
                    .countryCode(vodAsset.getCountryCode()).contentId(contentId).build()).toList();
            columns.add(AssetColumns.FEED_WORKER.value);
            AssetDetailsByColumnReqDto assetDetailsByColumnReqDto = AssetDetailsByColumnReqDto.builder()
                .columns(columns).assetList(assetKeyList).build();

            ResponseDto responseDto = getAssetsDataForHistory(assetDetailsByColumnReqDto);

            Map<String, Object> assetsData = new HashMap<>();
            if (responseDto != null && responseDto.getRsp() != null) {
                assetsData = responseDto.getRsp().getPayload();
            }
            var mapper = new ObjectMapper();
            List<VodAssetDto> vodAssetDtos = mapper.convertValue(assetsData.get(Constants.ASSETS),
                new TypeReference<>() {
                });

            assetHelperService.isEditAllowed(vodAssetDtos);
            assetHelperService.validateAssetUpdate(List.of(assetUpdateByBulkDto.getVodAssetDto()),
                null);

            ResponseDto responseOfBulkEdit = updateAssetByBulk(assetUpdateByBulkDto, vodAssetDtos);

            //need to handle push failure case
            vodAssetDtos.forEach(vod -> {
                if (vod != null && vod.getIsSyncBlocked() != null && Boolean.TRUE.equals(
                    !vod.getIsSyncBlocked())) {
                    assetSyncerService.pushMessageToSqsAsync(Constants.CONSTANT_UPDATE, List.of(
                        VodAssetDto.builder().contentId(vod.getContentId())
                            .feedWorker(vod.getFeedWorker())
                            .vcCpId(assetUpdateByBulkDto.getVodAssetDto().getVcCpId())
                            .countryCode(assetUpdateByBulkDto.getVodAssetDto().getCountryCode())
                            .build()));

                }
            });
            if (responseDto == null || responseDto.getRsp() == null) {
                log.error("Error while getting multiple assets data for history");
                return responseOfBulkEdit;
            }
            //history call
            historyCallBulkEdit(vodAssetDtos, assetUpdateByBulkDto, columns);
            return responseOfBulkEdit;
        } catch (AssetApiFailureException e) {
            log.error("Error while asset update by bulk: {}", e.getMessage());
            throw new AssetApiFailureException("Error while asset update by bulk");
        } catch (Exception e) {
            log.error("Error while bulkEdit history call: {}", e.getMessage());
            throw new CustomException("Error while asset update by bulk");
        }

    }


    private void historyCallBulkEdit(List<VodAssetDto> vodAssetDtos,
        AssetUpdateByBulkDto assetUpdateByBulkDto, List<String> columns)
        throws JsonProcessingException {
        for (VodAssetDto vodAssetDto : vodAssetDtos) {
            triggerBulkEditHistoryForAssetByPortal(vodAssetDto, assetUpdateByBulkDto, columns);
        }
    }

    private void triggerBulkEditHistoryForAssetByPortal(VodAssetDto vodAssetDto,
        AssetUpdateByBulkDto assetUpdateByBulkDto, List<String> columns)
        throws JsonProcessingException {
        VodAssetDto vodAsset = assetUpdateByBulkDto.getVodAssetDto();
        assetHelperService.setGraceNoteFieldsNull(vodAssetDto, vodAsset);
        Map<?, ?> assetMap = objectMapper.convertValue(vodAsset, HashMap.class);
        List<String> history = new ArrayList<>();
        Map<?, ?> assetMapResult = objectMapper.convertValue(vodAssetDto, HashMap.class);

        for (String key : columns) {
            assetHelperService.prepareMetadataHistoryForPortalByColumn(key, vodAssetDto, vodAsset,
                assetMap,
                assetMapResult, history);
        }
        MetadataHistoryRequestDto metadataHistoryRequestDto = MetadataHistoryRequestDto.builder()
            .changes(history.toString())
            .updatedBy(authenticatedUser.getUserInfo().getUuid())  // Store userId, not userName
            .assetId(vodAssetDto.getContentId())
            .countryCode(assetUpdateByBulkDto.getVodAssetDto().getCountryCode())
            .vcCpId(assetUpdateByBulkDto.getVodAssetDto().getVcCpId()).build();
        assetAsyncService.insertMetadataModificationHistory(metadataHistoryRequestDto);
    }


    public ResponseDto getEpisodeHierarchy(AssetEpisodeHierarchyDto assetEpisodeHierarchyDto) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_EPISODE_HIERARCHY;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(assetEpisodeHierarchyDto),
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting  episode hierarchy details");
        }
    }


    public ResponseDto getFilteredAssetsCount(AssetFilterBodyDto assetFilterBodyDto, String tab) {
        try {
            HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(assetFilterBodyDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_FILTERED_ASSETS_COUNT;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam("tab", tab);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.toUriString(), Constants.METHOD_POST, httpEntity, ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting filtered list count");
        }
    }

    private List<VodAssetDto> getAssetInfoByAPI(AssetByColumnsReqDto assetByColumnsReqDto) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint()
                + Constants.GET_FILTERED_ASSETS_BY_COLUMNS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(assetByColumnsReqDto),
                ResponseDto.class);
            Map<String, Object> assets = Objects.requireNonNull(responseEntity.getBody()).getRsp()
                .getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(assets.get(Constants.ASSETS), new TypeReference<>() {
            });

        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting asset info");
        }
    }

    public List<VodAssetDto> uploadUpdates(MultipartFile file) {

        try {
            var workbook = new XSSFWorkbook(file.getInputStream());
            var sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            Map<String, Integer> headerMap = new HashMap<>();
            if (!rowIterator.hasNext()) {
                throw new InvalidInputDataException("There are 0 rows in the excel");
            }
            var flag = assetExcelEditService.headerValidationOfExcelSheet(sheet, headerMap);

            if (!flag) {
                throw new InvalidInputDataException("Column names provided in excel are invalid");
            }

            rowIterator.next();
            if (!rowIterator.hasNext()) {
                throw new InvalidInputDataException("There are no rows to edit in the excel");
            }
            ArrayList<AssetKeyDto> assetKeyDtos = new ArrayList<>();
            List<RatingsDto> ratingsList = assetExcelEditService.getMasterRatings();

            int rowNumber = 0;
            Map<String, Integer> contentIndex = new HashMap<>();
            List<VodAssetDto> records = new ArrayList<>();

            while (rowIterator.hasNext() && records.size() < 500) {
                ++rowNumber;
                var row = rowIterator.next();
                String result = Constants.SUCCESSFUL;
                String countryCode = assetExcelEditService.getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf("country"),
                    headerMap);
                String contentId = assetExcelEditService.getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf("programid"),
                    headerMap);
                String vcCpId = assetExcelEditService.getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf("providerid"),
                    headerMap);
                if (assetExcelEditService.emptyRowCheckInExcel(contentId, countryCode, vcCpId)) {
                    continue;
                }

                AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId(contentId)
                    .countryCode(countryCode).vcCpId(vcCpId).build();
                assetKeyDtos.add(assetKeyDto);
                if (contentIndex.containsKey(assetKeyDto.getContentId())) {
                    int prevInd = contentIndex.get(assetKeyDto.getContentId()) - 1;
                    records.get(prevInd).setResult(Constants.DATA_DUPLICATE);
                }
                contentIndex.put(assetKeyDto.getContentId(), rowNumber);
                VodAssetDto vodAssetDto = assetExcelEditService.createValidVod(contentId,
                    countryCode, vcCpId, row, headerMap, result);
                validationAsset.validate(vodAssetDto, ratingsList);

                //duplicate ID are allowed now. So, separate content IDs external IDs are no longer rejected.
                records.add(vodAssetDto);
            }
            if (records.isEmpty()) {
                throw new InvalidInputDataException("There are no rows to edit in the excel");
            }
            assetStatusValidation(assetKeyDtos, records);
            updateAssetUtils.insertRecordsInUploadtable(records);
            return records;
        } catch (InvalidInputDataException e) {
            log.error("Input present in Excel is invalid: {}", e.getMessage());
            throw new InvalidInputDataException(e.getMessage());
        } catch (Exception e) {
            log.error("Invalid file imported: {}", e.getMessage());
            throw new AssetApiFailureException("Invalid file imported.");
        }
    }


    public void assetStatusValidation(List<AssetKeyDto> assetKeyDtos,
        List<VodAssetDto> records) {

        List<String> columns = new ArrayList<>(Constants.EXCEL_ASSET_VALIDATION_FIELDS_OF_ORACLE);
        columns.add(AssetColumns.FEED_WORKER.value);
        columns.add("deltaType");
        AssetByColumnsReqDto assetByColumnsReqDto = AssetByColumnsReqDto.builder()
            .assetList(assetKeyDtos).columns(columns).build();
        List<VodAssetDto> vodAssetDtoList = getAssetInfoByAPI(assetByColumnsReqDto);

        for (VodAssetDto vodAssetDto : records) {
            if (vodAssetDto.getResult().equalsIgnoreCase(Constants.SUCCESSFUL)) {
                var recordExists = assetExcelEditService.checkRecordExists(vodAssetDto,
                    vodAssetDtoList);

                if (!recordExists) {
                    log.error("Record doesn't exist for contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Asset does not exist");
                }
            }

        }
    }


    public List<VodAssetDto> uploadAction(String request) {
        String userId = authenticatedUser.getUserInfo().getUuid();
        String region = authenticatedUser.getUserInfo().getServiceRegion();
        String sessionId = authenticatedUser.getUserInfo().getSessionId();
        if (Constants.CONFIRM.equals(request)) {
            List<VodAssetDto> successfulAssets = assetMapper.getSuccessfulAssets(userId, region,
                sessionId);
            for (VodAssetDto asset : successfulAssets) {
                try {
                    List<ExternalProviderDto> externalProviders = new LinkedList<>();
                    List<String> externalProvidersList = splitElementsWithNullCheck(
                        asset.getExternalIdProvider());
                    List<String> externalIdTypeList = splitElementsWithNullCheck(
                        asset.getExternalIdType());
                    List<String> externalProgramIdList = splitElementsWithNullCheck(
                        asset.getExternalId());
                    for (int i = 0; i < externalProgramIdList.size(); ++i) {
                        externalProviders.add(
                            ExternalProviderDto.builder().provider(externalProvidersList.get(i))
                                .idType(externalIdTypeList.get(i))
                                .externalProgramId(externalProgramIdList.get(i)).build());
                    }
                    asset.setExternalProvider(externalProviders);
                    triggerUpdateAsset(asset);
                } catch (Exception e) {
                    log.error("Error while in updating asset of excel upload:{}",
                        asset.getContentId());
                }
            }
            try {
                assetMapper.cleanAssetsByUserId(userId, region);
            } catch (Exception e) {
                log.error("Error while cleanup, will be cleanup in next api call");
            }
        } else {
            assetMapper.cleanAssetsByUserId(userId, region);
        }
        return Collections.emptyList();
    }

    private List<String> splitElementsWithNullCheck(String str) {
        if (StringUtils.isEmpty(str)) {
            return new ArrayList<>();
        }
        return Arrays.stream(str.split(",")).toList();
    }

    public void triggerUpdateAsset(VodAssetDto asset) {
        List<String> columns = new ArrayList<>();
        List<VodAssetDto> vodAssetDtos = new ArrayList<>();
        try {
            columns = assetHelperService.getEditColumnsForHistory(asset);
            columns.add(Constants.ASSET_STATUS);
            columns.add(Constants.IS_CMS_PROD);
            if (asset.getRatings() != null) {
                columns.add(Constants.DEEPLINK_PAYLOAD);
            }
            List<AssetKeyDto> assetKeyDtos = new ArrayList<>();
            assetKeyDtos.add(
                AssetKeyDto.builder().vcCpId(asset.getVcCpId()).countryCode(asset.getCountryCode())
                    .contentId(asset.getContentId()).build());
            AssetDetailsByColumnReqDto assetHistorybulkEditHistoryReqDto = AssetDetailsByColumnReqDto.builder()
                .columns(columns).assetList(assetKeyDtos).build();
            ResponseDto responseDto = getAssetsDataForHistory(assetHistorybulkEditHistoryReqDto);
            if (responseDto == null || responseDto.getRsp() == null) {
                throw new AssetApiFailureException(Constants.ERROR_GETTING_DATA);
            }
            Map<String, Object> assetsData = responseDto.getRsp().getPayload();
            vodAssetDtos = objectMapper.convertValue(assetsData.get(Constants.ASSETS),
                new TypeReference<>() {
                });
            if (vodAssetDtos.isEmpty()) {
                throw new AssetApiFailureException(
                    Constants.ERROR_GETTING_DATA + ", received empty list");
            }
        } catch (Exception ex) {
            log.error("Error while getting previous asset data for history:{}", ex.getMessage());
        }
        if (!(Constants.SEASON.equalsIgnoreCase(asset.getType()) || Constants.SHOW.equalsIgnoreCase(
            asset.getType()))) {
            assetExcelEditService.setDeeplinkPayloadForExcelAsset(asset, vodAssetDtos);
        }
        assetExcelEditService.setCastForAssetUpload(asset, vodAssetDtos);
        assetExcelEditService.setRatingListForUpload(asset);

        // also sets vodAssetDtos.externalProviders.providers (which are vcCpId) to null, consumed by history (not needed)
        assetExcelEditService.setExternalIDListForUpload(asset, vodAssetDtos);
        int retry = Constants.RETRY;
        while (retry-- > 0) {
            try {
                updateAssetUtils.updateDeleteAsset(asset);
                sendMessageToSyncer(asset);
                assetExcelEditService.addHistoryForExcelUpdate(asset, vodAssetDtos, columns);
                break;
            } catch (Exception e) {
                log.error("Error while updateDelete excel Asset{}", e.getMessage());
            }
        }
    }


    public List<VodAssetDto> getImportedAssets() {
        String userId = authenticatedUser.getUserInfo().getUuid();
        String region = authenticatedUser.getUserInfo().getServiceRegion();
        String sessionId = authenticatedUser.getUserInfo().getSessionId();
        return assetMapper.getImportedAssetsByUserId(userId, region, sessionId);
    }


    private void sendMessageToSyncer(VodAssetDto asset) {
        if (asset.getIsSyncBlocked() != null && !asset.getIsSyncBlocked()) {
            assetSyncerService.pushMessageToSqsAsync(Constants.CONSTANT_UPDATE, List.of(
                VodAssetDto.builder().contentId(asset.getContentId())
                    .feedWorker(asset.getFeedWorker())
                    .vcCpId(asset.getVcCpId())
                    .countryCode(asset.getCountryCode())
                    .build()));
            log.info("Pushed message to sqs for asset id:{} ", asset.getContentId());
        }
    }


}