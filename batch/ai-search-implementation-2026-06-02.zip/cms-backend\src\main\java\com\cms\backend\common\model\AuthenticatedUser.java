package com.cms.backend.common.model;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AuthenticatedUser {

    // ThreadLocal to store the current user context instead of using SecurityContextHolder
    private static final ThreadLocal<SecurityUser> userContext = new ThreadLocal<>();

    public SecurityUser getUserInfo() {
        SecurityUser currentUser = userContext.get();
        if (currentUser == null) {
            log.warn("No authenticated user found in ThreadLocal context");
        }
        return currentUser;
    }

    // Method to set the current user in the context (called by interceptor)
    public static void setCurrentUser(SecurityUser user) {
        userContext.set(user);
    }

    // Method to clear the current user context (called by interceptor)
    public static void clearContext() {
        userContext.remove();
    }


}
