package com.cms.backend.assets.service;


import static com.cms.backend.assets.service.AssetService.ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER;

import com.cms.backend.assets.configuration.AssetColumnMap;
import com.cms.backend.assets.configuration.AssetNotEditableFieldsMap;
import com.cms.backend.assets.model.AssetCastDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetLockedFieldDto;
import com.cms.backend.assets.model.MetaDataHistoryChangesDto;
import com.cms.backend.assets.model.ParentalRatingsDto;
import com.cms.backend.assets.model.StatusGetDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.util.UpdateAssetUtils;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetColumns;
import com.cms.backend.common.enums.AssetFeedWorker;
import com.cms.backend.common.enums.AssetGracenoteFields;
import com.cms.backend.common.enums.AssetStatus;
import com.cms.backend.common.enums.AssetTypes;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.utils.CollectionUtils;

@Service
@Slf4j
public class AssetHelperService {

    public static final String ERROR_WHILE_IN_UPDATING_DEEPLINK_PAYLOAD = "Error while in updating deeplink Payload";
    private final UpdateAssetUtils updateAssetUtils;
    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;

    ObjectMapper objMapper = new ObjectMapper();

    @Value("${FEED_WORKER_LIST:CMS,CMS_GRACENOTE}")
    private String feedWorkerList;

    @Value("${DEPLOYMENT_ENV}")
    private String deploymentEnv;

    public AssetHelperService(UpdateAssetUtils updateAssetUtils,
        RegionEndpointService regionEndpointService, HttpMethodHandler httpMethodHandler) {
        this.updateAssetUtils = updateAssetUtils;
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
    }


    public void prepareMetadataHistoryForPortalByColumn(String key, VodAssetDto vodAssetDto,
        VodAssetDto vodAsset, Map<?, ?> assetMap, Map<?, ?> assetMapResult, List<String> history)
        throws JsonProcessingException {
        var mapper = new ObjectMapper();
        if (List.of(Constants.IS_CMS_PROD, Constants.ASSET_STATUS, Constants.CONTENT_ID,
                "lockedFields")
            .contains(key) || (key.equalsIgnoreCase(Constants.CAST) && (vodAsset.getCast() == null))
            || (AssetHelperService.isSimilarList(vodAssetDto.getParentalRatings(),
            vodAsset.getParentalRatings()) && key.equalsIgnoreCase(Constants.PARENTAL_RATINGS))) {
            return;
        }
        var oldValue = assetMapResult.get(key);
        var newValue = assetMap.get(key);
        if (key.equalsIgnoreCase(Constants.PARENTAL_RATINGS)) {
            List<String> oldAndNewRatings = setParentalRatingsForBulkEdit(
                vodAssetDto.getParentalRatings(), vodAsset.getParentalRatings());
            oldValue = oldAndNewRatings.get(0);
            newValue = oldAndNewRatings.get(1);
        }
        if (key.equalsIgnoreCase(Constants.CAST)) {
            List<String> oldAndNewCasts = setCastByListForBulkEdit(
                vodAssetDto.getCast(),
                vodAsset.getCast());
            oldValue = oldAndNewCasts.get(0);
            newValue = oldAndNewCasts.get(1);
        }

        if (key.equalsIgnoreCase(Constants.LICENSE_WINDOW_LIST)) {
            oldValue = AssetHelperService.convertObjectArrayToString(
                vodAssetDto.getLicenseWindowList());
            newValue = AssetHelperService.convertObjectArrayToString(
                vodAsset.getLicenseWindowList());
        }
        if (key.equalsIgnoreCase(Constants.EVENT_WINDOW_LIST)) {
            oldValue = AssetHelperService.convertObjectArrayToString(
                vodAssetDto.getEventWindowList());
            newValue = AssetHelperService.convertObjectArrayToString(vodAsset.getEventWindowList());
        }

        if (key.equals(Constants.DEEPLINK_PAYLOAD)) {
            newValue = portalBulkEditDeeplinkPayload((String) oldValue, vodAsset);
        }

        if (!Objects.equals(oldValue, newValue) && newValue != null) {
            MetaDataHistoryChangesDto metaDataHistoryChangesDto = MetaDataHistoryChangesDto.builder()
                .oldValue(oldValue == null ? null : String.valueOf(oldValue))
                .newValue(String.valueOf(newValue)).key(key).build();
            history.add(mapper.writeValueAsString(metaDataHistoryChangesDto));
        }
    }


    public List<String> setParentalRatingsForBulkEdit(List<ParentalRatingsDto> oldParentalRatings,
        List<ParentalRatingsDto> newParentalRatings) throws JsonProcessingException {
        List<String> list = new ArrayList<>();
        list.add(convertObjectArrayToString(oldParentalRatings));
        list.add(convertObjectArrayToString(newParentalRatings));
        return list;
    }


    public List<String> setCastByListForBulkEdit(List<AssetCastDto> assetCastDtos,
        List<AssetCastDto> newAssetCastDtos) throws JsonProcessingException {
        List<String> list = new ArrayList<>();
        list.add(convertObjectArrayToString(assetCastDtos));
        list.add(convertObjectArrayToString(newAssetCastDtos));
        return list;
    }


    public static <T> String convertObjectArrayToString(List<T> objectArray)
        throws JsonProcessingException {
        var mapper = new ObjectMapper();
        List<String> stringArray = new ArrayList<>();
        if (objectArray != null) {
            for (T element : objectArray) {
                stringArray.add(mapper.writeValueAsString(element));
            }
        }
        return stringArray.toString();
    }


    public static <T> boolean isSimilarList(List<T> oldList, List<T> newList) {

        if (CollectionUtils.isNullOrEmpty(oldList) && CollectionUtils.isNullOrEmpty(newList)) {
            return true;
        }

        if (CollectionUtils.isNullOrEmpty(oldList) || CollectionUtils.isNullOrEmpty(newList)
            || oldList.size() != newList.size()) {
            return false;
        }

        Map<T, Integer> frequencyMap = new HashMap<>();
        for (T element : oldList) {
            frequencyMap.put(element, frequencyMap.getOrDefault(element, 0) + 1);
        }

        for (T element : newList) {
            if (frequencyMap.getOrDefault(element, 0) <= 0) {
                return false;
            }
            frequencyMap.put(element, frequencyMap.get(element) - 1);
        }

        return true;
    }

    private String portalBulkEditDeeplinkPayload(String oldValue, VodAssetDto vodAsset) {
        String newValue = null;
        if (oldValue != null) {
            var jsonObject = JsonParser.parseString(oldValue).getAsJsonObject();
            if (jsonObject != null && jsonObject.has(Constants.DEEPLINK_DATA)) {
                JsonObject deeplinkData = jsonObject.getAsJsonObject(Constants.DEEPLINK_DATA);
                if (vodAsset.getRatings() != null) {
                    deeplinkData.addProperty(Constants.RATINGS, vodAsset.getRatings());
                }
                modifyDeeplinkOnEventChange(vodAsset, deeplinkData);
                newValue = jsonObject.toString();
            }
        }
        return newValue;
    }

    void modifyDeeplinkOnEventChange(VodAssetDto vodAsset, JsonObject deeplinkData) {
        if (vodAsset.getEventWindowList() == null || vodAsset.getEventWindowList().isEmpty()) {

            deeplinkData.remove("event_info");
            deeplinkData.remove("event");
        } else {
            deeplinkData.addProperty("event", "Y");
            var activeWindow = updateAssetUtils.findUpdateSlot(vodAsset.getEventWindowList());
            JsonObject eventInfo = new JsonObject();
            eventInfo.addProperty("event_starttime", activeWindow.getEventStarting());
            eventInfo.addProperty("event_endtime", activeWindow.getEventEnding());
            deeplinkData.add("event_info", eventInfo);
        }
    }

    public void setDeepLinkPayloadOfPortal(VodAssetDto vodAssetDto, String oldDeeplinkPayload) {
        try {
            var jsonObject = JsonParser.parseString(oldDeeplinkPayload).getAsJsonObject();
            if (jsonObject != null && jsonObject.has(Constants.DEEPLINK_DATA)) {
                JsonObject deeplinkData = jsonObject.getAsJsonObject(Constants.DEEPLINK_DATA);
                deeplinkData.addProperty(Constants.RATINGS, vodAssetDto.getRatings());
                this.modifyDeeplinkOnEventChange(vodAssetDto, deeplinkData);
                vodAssetDto.setDeeplinkPayload(jsonObject.toString());
            } else {
                throw new AssetApiFailureException(ERROR_WHILE_IN_UPDATING_DEEPLINK_PAYLOAD);
            }
        } catch (AssetApiFailureException e) {
            throw new AssetApiFailureException(ERROR_WHILE_IN_UPDATING_DEEPLINK_PAYLOAD);
        }
    }

    public void blockGracenoteLockedFields(List<VodAssetDto> newVodList,
        List<VodAssetDto> oldVodList) {
        oldVodList.forEach(oldVod -> newVodList.stream()
            .filter(newVod -> oldVod.getContentId().equals(newVod.getContentId()))
            .forEach(newVod -> this.setGraceNoteFieldsNull(oldVod, newVod)));
    }

    public void setGraceNoteFieldsNull(VodAssetDto oldVodAssetDto, VodAssetDto newVodAssetDto) {
        VodAssetDto tempVod = VodAssetDto.builder().feedWorker(oldVodAssetDto.getFeedWorker())
            .build();
        if (oldVodAssetDto.getFeedWorker().equalsIgnoreCase(AssetFeedWorker.CMS_GRACENOTE.value)
            || oldVodAssetDto.getFeedWorker()
            .equalsIgnoreCase(AssetFeedWorker.TVPLUS_DELTA_GRACENOTE.value)) {
            List<String> lockedFields = oldVodAssetDto.getLockedFields().stream().map(
                AssetLockedFieldDto::getFieldName).toList();
            FIELD_MAPPERS.entrySet().forEach(entry -> {
                if (!lockedFields.contains(entry.getKey())) {
                    entry.getValue().accept(newVodAssetDto, tempVod);
                    if (entry.getKey().equalsIgnoreCase(AssetColumns.STARRING.value)) {
                        newVodAssetDto.setCast(null);
                    }
                }
            });
        }

    }

    public List<AssetKeyDto> extractSeasonShowList(StatusUpdateDto statusUpdateDto) {
        log.info("Extracting Season and Show list");
        Set<AssetKeyDto> seasonShowList = new HashSet<>();
        statusUpdateDto.getAssetList().forEach(asset -> {
            if (AssetTypes.EPISODE.value.equalsIgnoreCase(asset.getType())) {
                seasonShowList.add(
                    AssetKeyDto.builder().contentId(asset.getSeasonId()).vcCpId(asset.getVcCpId())
                        .countryCode(asset.getCountryCode()).build());
                seasonShowList.add(
                    AssetKeyDto.builder().contentId(asset.getShowId()).vcCpId(asset.getVcCpId())
                        .countryCode(asset.getCountryCode()).build());
            } else if (AssetTypes.SEASON.value.equalsIgnoreCase(asset.getType())) {
                seasonShowList.add(
                    AssetKeyDto.builder().contentId(asset.getShowId()).vcCpId(asset.getVcCpId())
                        .countryCode(asset.getCountryCode()).build());
            }
        });
        List<String> payloadContent = statusUpdateDto.getAssetList().stream()
            .map(AssetKeyDto::getContentId).toList();
        return seasonShowList.stream().filter(item -> !payloadContent.contains(item.getContentId()))
            .toList();

    }


    public static final Map<String, BiConsumer<VodAssetDto, VodAssetDto>> FIELD_MAPPERS =
        Map.ofEntries(
            Map.entry(AssetGracenoteFields.DESCRIPTION.value,
                (t, s) -> t.setDescription(s.getDescription())),
            Map.entry(AssetGracenoteFields.EPISODE_NUMBER.value,
                (t, s) -> t.setEpisodeNo(s.getEpisodeNo())),
            Map.entry(AssetGracenoteFields.SEASON_NUMBER.value,
                (t, s) -> t.setSeasonNo(s.getSeasonNo())),
            Map.entry(AssetGracenoteFields.GENRES.value,
                (t, s) -> t.setGenres(s.getGenres())),
            Map.entry(AssetGracenoteFields.RELEASE_DATE.value,
                (t, s) -> t.setReleaseDate(s.getReleaseDate())),
            Map.entry(AssetGracenoteFields.MAIN_TITLE.value,
                (t, s) -> t.setMainTitle(s.getMainTitle())),
            Map.entry(AssetGracenoteFields.SHORT_TITLE.value,
                (t, s) -> t.setShortTitle(s.getShortTitle())),
            Map.entry(AssetGracenoteFields.DIRECTOR.value,
                (t, s) -> t.setDirector(s.getDirector())),
            Map.entry(AssetGracenoteFields.STARRING.value,
                (t, s) -> t.setStarring(s.getStarring())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE.value,
                (t, s) -> {
                    t.setImageLandscape(s.getImageLandscape());
                    t.setImageLandscapeOriginal(s.getImageLandscapeOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT.value,
                (t, s) -> {
                    t.setImagePortrait(s.getImagePortrait());
                    t.setImagePortraitOriginal(s.getImagePortraitOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_ICONIC.value,
                (t, s) -> {
                    t.setImageLandscapeIconic(s.getImageLandscapeIconic());
                    t.setImageLandscapeIconicOriginal(s.getImageLandscapeIconicOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT_ICONIC.value,
                (t, s) -> {
                    t.setImagePortraitIconic(s.getImagePortraitIconic());
                    t.setImagePortraitIconicOriginal(s.getImagePortraitIconicOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT_DIMENSION.value,
                (t, s) -> t.setImagePortraitDimension(s.getImagePortraitDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_DIMENSION.value,
                (t, s) -> t.setImageLandscapeDimension(s.getImageLandscapeDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_ICONIC_DIMENSION.value,
                (t, s) -> t.setImageLandscapeIconicDimension(s.getImageLandscapeIconicDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT_ICONIC_DIMENSION.value,
                (t, s) -> t.setImagePortraitIconicDimension(s.getImagePortraitIconicDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_ORIGINAL.value,
                (t, s) -> t.setImageLandscapeOriginal(s.getImageLandscapeOriginal())),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT_ORIGINAL.value,
                (t, s) -> t.setImagePortraitOriginal(s.getImagePortraitOriginal())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_ICONIC_ORIGINAL.value,
                (t, s) -> t.setImageLandscapeIconicOriginal(s.getImageLandscapeIconicOriginal())),
            Map.entry(AssetGracenoteFields.IMAGE_PORTRAIT_ICONIC_ORIGINAL.value,
                (t, s) -> t.setImagePortraitIconicOriginal(s.getImagePortraitIconicOriginal())),
            Map.entry(AssetGracenoteFields.FEED_WORKER.value,
                (t, s) -> t.setFeedWorker(s.getFeedWorker())),
            Map.entry(AssetGracenoteFields.IMAGE_TITLE_TREATMENT.value,
                (t, s) -> {
                    t.setImageTitleTreatment(s.getImageTitleTreatment());
                    t.setImageTitleTreatmentOriginal(s.getImageTitleTreatmentOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_TITLE_TREATMENT_ORIGINAL.value,
                (t, s) -> t.setImageTitleTreatmentOriginal(s.getImageTitleTreatmentOriginal())),
            Map.entry(AssetGracenoteFields.IMAGE_TITLE_TREATMENT_DIMENSION.value,
                (t, s) -> t.setImageTitleTreatmentDimension(s.getImageTitleTreatmentDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_BACKDROP.value,
                (t, s) -> {
                    t.setImageLandscapeBackdrop(s.getImageLandscapeBackdrop());
                    t.setImageLandscapeBackdropOriginal(
                        s.getImageLandscapeBackdropOriginal());
                }),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_BACKDROP_DIMENSION.value,
                (t, s) -> t.setImageLandscapeBackdropDimension(
                    s.getImageLandscapeBackdropDimension())),
            Map.entry(AssetGracenoteFields.IMAGE_LANDSCAPE_BACKDROP_ORIGINAL.value,
                (t, s) -> t.setImageLandscapeBackdropOriginal(
                    s.getImageLandscapeBackdropOriginal()))
        );

    public void validateAssetUpdate(List<VodAssetDto> vodAssetDtoList, String type) {
        log.info("Validating asset update for type:{} and list:{}", type,
            vodAssetDtoList.toString());
        if (type == null) {
            //handling bulk edit only for episodes
            type = "EPISODE";
        }
        for (VodAssetDto vodAssetDto : vodAssetDtoList) {
            Map<?, ?> resultMap = objMapper.convertValue(vodAssetDto, Map.class);
            List<String> errors = new ArrayList<>();
            AssetNotEditableFieldsMap.getNotEditableFields().get(type).forEach(item -> {
                try {
                    var val = resultMap.get(item);
                    if (val != null) {
                        errors.add("Field " + AssetColumnMap.getColumnMap().get(item)
                            + " is not editable");
                    }
                } catch (Exception ex) {
                    throw new CustomException("Asset is not Editable");
                }
            });
            if (!errors.isEmpty()) {
                throw new CustomException(String.join(",", errors));
            }
        }
    }

    public void validateStatusForEditing(VodAssetDto vodAssetDto,
        List<VodAssetDto> vodAssetDtoList) {
        vodAssetDtoList.forEach(vod -> {
            this.validateAssetUpdate(List.of(vodAssetDto), vod.getType());
            if (AssetStatus.UNTRACKABLE.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.QC_PASS.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.TEMP_QC_PASS.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.SMF_IMPORTED.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.TRANSFERRING.value.equalsIgnoreCase(vod.getStatus())) {
                throw new CustomException("Asset is  Not Editable");
            }
        });

    }

    public List<String> getEditColumnsForHistory(VodAssetDto vodAssetDto) {
        return getColumnsForHistoryUtil(vodAssetDto, Constants.IMPORTTEMPLATEEDITABLEFIELDS);
    }

    private List<String> getColumnsForHistoryUtil(Object vodAssetDto, List<String> columnList) {
        List<String> columns = new ArrayList<>();
        columns.add(Constants.CONTENT_ID);
        try {
            Map<?, ?> vodMap = objMapper.convertValue(vodAssetDto, HashMap.class);
            for (String key : columnList) {
                var value = vodMap.get(key);
                if (value != null) {
                    if ("externalProvider".equalsIgnoreCase(key)) {
                        columns.add(AssetColumns.EXTERNAL_PROVIDER_LIST.value);
                    } else {
                        columns.add(key);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred while converting asset to map for vodAsset {}",
                e.getMessage());
        }
        return columns;
    }

    public List<String> getColumnsForHistory(VodAssetDto vodAssetDto) {
        return getColumnsForHistoryUtil(vodAssetDto, Constants.BULKEDITABLEFIELDS);
    }

    public void isEditAllowed(List<VodAssetDto> vodAssetDtos) {
        //blocking update
        vodAssetDtos.forEach(vod -> {
            if (AssetStatus.UNTRACKABLE.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.QC_PASS.value.equalsIgnoreCase(vod.getStatus())
                || AssetStatus.TEMP_QC_PASS.value.equalsIgnoreCase(vod.getStatus())) {
                throw new CustomException("Asset is  Not Editable");
            } else if (vod.getFeedWorker() == null || Arrays.stream(feedWorkerList.split(","))
                .noneMatch(vod.getFeedWorker()::equalsIgnoreCase)) {
                throw new CustomException(ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER);
            }
        });
    }

    public List<String> getImageList(String landscapeImageBanner, String portraitImageBanner,
        String landscapeImageIconic, String portraitImageIconic, String imageCircle) {
        List<String> imageLists = new ArrayList<>();
        if (!landscapeImageBanner.isEmpty()) {
            imageLists.add(landscapeImageBanner);
        }
        if (!portraitImageBanner.isEmpty()) {
            imageLists.add(portraitImageBanner);
        }
        if (!landscapeImageIconic.isEmpty()) {
            imageLists.add(landscapeImageIconic);
        }
        if (!portraitImageIconic.isEmpty()) {
            imageLists.add(portraitImageIconic);
        }
        if (!imageCircle.isEmpty()) {
            imageLists.add(imageCircle);
        }
        return imageLists;
    }

    public void validateDeploymentEnv(StatusUpdateDto statusUpdateDto) {
        log.info("Validating Deployment Env");
        List<String> countries = statusUpdateDto.getAssetList().stream()
            .map(AssetKeyDto::getCountryCode).toList();
        if (List.of("AA", "XF").containsAll(countries)) {
            return;
        }
        if (deploymentEnv != null && deploymentEnv.equalsIgnoreCase("green") && (
            AssetStatus.QC_PASS.value.equalsIgnoreCase(statusUpdateDto.getStatus())
                || AssetStatus.TEMP_QC_PASS.value.equalsIgnoreCase(statusUpdateDto.getStatus())
                || AssetStatus.REVOKED.value.equalsIgnoreCase(statusUpdateDto.getStatus()))) {
            throw new CustomException("Asset is not Editable in green env");
        }
    }

    public void modifyStatusUpdateRequestBody(StatusUpdateDto statusUpdateDto,
        List<AssetKeyDto> processingAssets,
        List<VodAssetDto> vodAssetDtoList) {
        log.info("Removing processing assets from update status request:{}",
            processingAssets.toString());
        statusUpdateDto.getAssetList().removeAll(processingAssets);
        processingAssets.forEach(asset ->
            vodAssetDtoList.removeIf(
                vodAssetDto -> vodAssetDto.getContentId().equals(asset.getContentId())
                    && vodAssetDto.getCountryCode().equals(asset.getCountryCode())
                    && vodAssetDto.getVcCpId().equals(asset.getVcCpId()))

        );
        log.info("Final list of assets to be processed:{}",
            statusUpdateDto.getAssetList().toString());
    }

    public List<VodAssetDto> getAssetStatusByAPI(StatusGetDto statusGetDto) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.GET_STATUS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, new HttpEntity<>(statusGetDto), ResponseDto.class);
            Map<String, Object> assets = Objects.requireNonNull(responseEntity.getBody()).getRsp()
                .getPayload();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(assets.get(Constants.ASSET_DETAILS), new TypeReference<>() {
            });

        } catch (Exception e) {
            throw new AssetApiFailureException("Error while getting asset status");
        }
    }
}
