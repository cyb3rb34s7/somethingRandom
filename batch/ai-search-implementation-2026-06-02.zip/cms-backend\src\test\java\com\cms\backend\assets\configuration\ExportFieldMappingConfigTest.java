package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.backend.assets.configuration.ExportFieldMappingConfig.FieldMetadata;
import com.cms.backend.assets.configuration.ExportFieldMappingConfig.FieldType;
import org.junit.jupiter.api.Test;

class ExportFieldMappingConfigTest {

    @Test
    void testFullExportFields() {
        String[] fullExportFields = ExportFieldMappingConfig.FULL_EXPORT_FIELDS;
        assertNotNull(fullExportFields);
        assertTrue(fullExportFields.length > 0);
    }

    @Test
    void testEvaluationFullExportFields() {
        String[] evaluationFullExportFields = ExportFieldMappingConfig.EVALUATION_FULL_EXPORT_FIELDS;
        assertNotNull(evaluationFullExportFields);
        assertTrue(evaluationFullExportFields.length > 0);
    }

    @Test
    void testFieldTypeEnum() {
        assertEquals(2, ExportFieldMappingConfig.FieldType.values().length);
        assertEquals(ExportFieldMappingConfig.FieldType.SIMPLE, ExportFieldMappingConfig.FieldType.valueOf("SIMPLE"));
        assertEquals(ExportFieldMappingConfig.FieldType.COMPUTED,
                ExportFieldMappingConfig.FieldType.valueOf("COMPUTED"));
    }

    @Test
    void testFieldMetadata() {
        FieldMetadata fieldMetadata = new FieldMetadata("columnName", "group", FieldType.SIMPLE);
        assertEquals("columnName", fieldMetadata.columnName);
        assertEquals("group", fieldMetadata.group);
        assertEquals(FieldType.SIMPLE, fieldMetadata.type);
    }

    @Test
    void testFieldConfig() {
        assertNotNull(ExportFieldMappingConfig.FIELD_CONFIG);
        assertFalse(ExportFieldMappingConfig.FIELD_CONFIG.isEmpty());

        // Test a few key fields
        FieldMetadata contentIdMetadata = ExportFieldMappingConfig.FIELD_CONFIG.get("contentId");
        assertNotNull(contentIdMetadata);
        assertEquals("Program ID", contentIdMetadata.columnName);
        assertEquals("Asset Basic Information", contentIdMetadata.group);
        assertEquals(FieldType.SIMPLE, contentIdMetadata.type);

        // Test computed fields
        FieldMetadata computedRatingsMetadata = ExportFieldMappingConfig.FIELD_CONFIG.get("computedRatings");
        assertNotNull(computedRatingsMetadata);
        assertEquals("Ratings", computedRatingsMetadata.columnName);
        assertEquals("Asset Details", computedRatingsMetadata.group);
        assertEquals(FieldType.COMPUTED, computedRatingsMetadata.type);
    }

    @Test
    void testEvaluationFieldConfig() {
        assertNotNull(ExportFieldMappingConfig.EVALUATION_FIELD_CONFIG);
        assertFalse(ExportFieldMappingConfig.EVALUATION_FIELD_CONFIG.isEmpty());

        FieldMetadata programIdMetadata = ExportFieldMappingConfig.EVALUATION_FIELD_CONFIG.get("programId");
        assertNotNull(programIdMetadata);
        assertEquals("Program ID", programIdMetadata.columnName);
        assertEquals("Asset Basic Information", programIdMetadata.group);
        assertEquals(FieldType.SIMPLE, programIdMetadata.type);
    }

    @Test
    void testGroupColors() {
        assertNotNull(ExportFieldMappingConfig.GROUP_COLORS);
        assertFalse(ExportFieldMappingConfig.GROUP_COLORS.isEmpty());

        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("Asset Basic Information"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("Asset Details"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("Cast Details"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("Asset Specifications"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("External Ids"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("License Details"));
        assertTrue(ExportFieldMappingConfig.GROUP_COLORS.containsKey("Evaluation Details"));
    }

    @Test
    void testGetFieldsInOrder() {
        String[] fields = ExportFieldMappingConfig.getFieldsInOrder(false);
        assertNotNull(fields);
        assertTrue(fields.length > 0);

        String[] evaluationFields = ExportFieldMappingConfig.getFieldsInOrder(true);
        assertNotNull(evaluationFields);
        assertTrue(evaluationFields.length > 0);
    }

    @Test
    void testGetGroupsInOrder() {
        String[] groups = ExportFieldMappingConfig.getGroupsInOrder(false);
        assertNotNull(groups);
        assertTrue(groups.length > 0);

        String[] evaluationGroups = ExportFieldMappingConfig.getGroupsInOrder(true);
        assertNotNull(evaluationGroups);
        assertTrue(evaluationGroups.length > 0);
    }

    @Test
    void testCountColumnsInGroup() {
        String[] fields = ExportFieldMappingConfig.getFieldsInOrder(false);
        int count = ExportFieldMappingConfig.countColumnsInGroup(fields, "Asset Basic Information", false);
        assertTrue(count >= 0);

        String[] evaluationFields = ExportFieldMappingConfig.getFieldsInOrder(true);
        int evaluationCount = ExportFieldMappingConfig.countColumnsInGroup(evaluationFields, "Asset Basic Information",
                true);
        assertTrue(evaluationCount >= 0);
    }
}
