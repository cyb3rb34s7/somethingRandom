package com.cms.backend.assets.aisearch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FilterSchema {

    private List<String> semanticDateTokens = List.of();
    private String contentHierarchyNote;
    private Map<String, String> columns = Map.of();
    private Map<String, List<String>> defaultColumnsByType = Map.of();
    private List<FilterKey> filters = List.of();
}
