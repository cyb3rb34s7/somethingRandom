package com.cms.backend.evaluation.model;

import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.assets.model.PaginationDto;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class FilterRequestDtoTest {

    @Test
    void testFilterRequestDto() {
        List<FilterDto> filters = Arrays.asList(Mockito.mock(FilterDto.class));
        PaginationDto paginationDto = Mockito.mock(PaginationDto.class);

        FilterRequestDto filterRequestDto = FilterRequestDto.builder()
                .filters(filters)
                .pagination(paginationDto)
                .build();

        assertThat(filterRequestDto.getFilters()).isEqualTo(filters);
        assertThat(filterRequestDto.getPagination()).isEqualTo(paginationDto);
    }
}
