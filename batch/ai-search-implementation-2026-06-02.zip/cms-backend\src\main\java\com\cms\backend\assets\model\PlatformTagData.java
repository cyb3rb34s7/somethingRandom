package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlatformTagData {

    private String contentId;
    private String countryCode;
    private String vcCpId;
    private String type;
    private String platform;
    private String alias;
}
