package com.cms.backend.assets.service;

import com.cms.backend.assets.model.SqsMessageDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.NotificationUtil;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

import java.util.Arrays;

@Component
@Slf4j
public class SqsMessageService {

    private final RegionEndpointService regionEndpointService;
    private final NotificationUtil notificationUtil;
    private final Gson gson;

    @Value("${CMS_FEEDWORKERS:CMS,CMS_GRACENOTE}")
    private String cmsFeedWorkers;

    @Value("${TVPLUS_DELTA_FEEDWORKERS:TVPLUS_DELTA,TVPLUS_DELTA_GRACENOTE}")
    private String tvplusDeltaFeedWorkers;

    @Value("${sqs.retry.max-attempts:3}")
    private int maxRetryAttempts;

    public SqsMessageService(RegionEndpointService regionEndpointService,
        NotificationUtil notificationUtil) {
        this.regionEndpointService = regionEndpointService;
        this.notificationUtil = notificationUtil;
        this.gson = new Gson();
    }

    @Retryable(
        retryFor = {AwsServiceException.class, Exception.class},
        maxAttemptsExpression = "${sqs.retry.max-attempts:3}",
        backoff = @Backoff(
            delayExpression = "${sqs.retry.initial-delay-ms:1000}",
            multiplierExpression = "${sqs.retry.multiplier:2.0}",
            maxDelayExpression = "${sqs.retry.max-delay-ms:10000}"
        )
    )
    public void pushMessageToSqs(SqsMessageDto sqsMessageDto, String feedWorker) {
        String sqsUrl = this.getSqsUrl(feedWorker);
        var retryContext = org.springframework.retry.support.RetrySynchronizationManager.getContext();
        int attempt = retryContext != null ? retryContext.getRetryCount() + 1 : 1;
        log.info("Pushing message to sqs for content id={}, attempt {}/{}, endpoint:{}",
            sqsMessageDto.getAssetId(), attempt, maxRetryAttempts, sqsUrl);
        String message = gson.toJson(sqsMessageDto);
        SendMessageRequest sendMessageRequest = SendMessageRequest.builder().queueUrl(sqsUrl)
            .messageBody(message).build();
        regionEndpointService.getSqsClient().sendMessage(sendMessageRequest);
        log.info("Pushed message to sqs for content id={}, attempt {}/{}, endpoint:{}",
            sqsMessageDto.getAssetId(), attempt, maxRetryAttempts, sqsUrl);
    }

    @Recover
    public void recover(Exception e, SqsMessageDto sqsMessageDto, String feedWorker) {

        log.error(
            "All retry attempts failed for SQS message send. Content ID: {}, Feed Worker: {}, Error: {}",
            sqsMessageDto.getAssetId(), feedWorker, e.getMessage());

        // Send alarm to monitoring system
        notificationUtil.sendErrorMail(
            e,
            "SQS_RETRY_FAILURE",
            "500",
            "CMS-ADMIN"
        );
    }

    private String getSqsUrl(String feedWorker) {
        if (Arrays.stream(cmsFeedWorkers.split(",")).anyMatch(feedWorker::equalsIgnoreCase)) {
            return regionEndpointService.getSQSEndpoint();
        } else if (Arrays.stream(tvplusDeltaFeedWorkers.split(","))
            .anyMatch(feedWorker::equalsIgnoreCase)) {
            return regionEndpointService.getSQSEndpointDelta();
        } else {
            throw new IllegalArgumentException("Invalid feed worker");
        }
    }
}