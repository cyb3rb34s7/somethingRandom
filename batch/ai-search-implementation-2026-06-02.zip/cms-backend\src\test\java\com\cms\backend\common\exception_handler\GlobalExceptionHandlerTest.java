package com.cms.backend.common.exception_handler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import com.cms.backend.common.exception.CountryNotAssignedException;
import com.cms.backend.common.exception.DataNotFoundException;
import com.cms.backend.common.exception.ForbiddenException;
import com.cms.backend.common.exception.InvalidStatusException;
import com.cms.backend.common.exception.ModifyingRoleOfSelfException;
import com.cms.backend.common.exception.RolesInUseException;
import com.cms.backend.common.exception.UnauthorizedException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.util.NotificationUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.lang.reflect.Method;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.MethodParameter;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpMethod;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private NotificationUtil notificationUtil;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(request.getRequestURI()).thenReturn("/test");
    }

    @Test
    void handleMethodArgumentNotValidException_fieldValidationError_returnsErrorResponse() {
        // Arrange
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError = new FieldError("object", "field", "error message");
        when(bindingResult.getAllErrors()).thenReturn(
            Collections.singletonList((ObjectError) fieldError));
        MethodParameter methodParameter = mock(MethodParameter.class);
        Method mockMethod = mock(Method.class);
        when(methodParameter.getExecutable()).thenReturn(mockMethod);
        when(mockMethod.toGenericString()).thenReturn("testMethod()");

        MethodArgumentNotValidException exception = new MethodArgumentNotValidException(
            methodParameter,
            bindingResult);

        // Act
        ResponseDto response = globalExceptionHandler.handleMethodArgumentNotValidException(exception, request);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleConstraintViolationException_constraintViolation_returnsErrorResponseWithNotification() {
        // Arrange
        ConstraintViolationException exception = new ConstraintViolationException("Constraint violation", null);

        // Act
        ResponseDto response = globalExceptionHandler.handleConstraintViolationException(exception, request);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
        verify(notificationUtil).sendErrorMail(eq(exception), eq("Bad Request"), eq("400"), anyString());
    }

    @Test
    void handleNoResourceFoundException_noResourceFound_returnsNotFoundErrorResponse() {
        // Arrange
        NoResourceFoundException exception = new NoResourceFoundException(HttpMethod.GET, "TEST");

        // Act
        ResponseDto response = globalExceptionHandler.handleNoResourceFoundException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleHttpRequestMethodNotSupportedException_unsupportedMethod_returnsMethodNotAllowedErrorResponse() {
        // Arrange
        HttpRequestMethodNotSupportedException exception = new HttpRequestMethodNotSupportedException("GET");

        // Act
        ResponseDto response = globalExceptionHandler.handleHttpRequestMethodNotSupportedException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleUsersStillAssignedToRoleException_usersAssignedToRole_returnsBadRequestErrorResponse() {
        // Arrange
        RolesInUseException exception = new RolesInUseException("Users are still assigned to this role");

        // Act
        ResponseDto response = globalExceptionHandler.handleUsersStillAssignedToRoleException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleDataIntegrityViolationException_dataIntegrityViolation_returnsBadRequestErrorResponseWithNotification() {
        // Arrange
        DataIntegrityViolationException exception = new DataIntegrityViolationException("Data integrity violation");

        // Act
        ResponseDto response = globalExceptionHandler.handleDataIntegrityViolationException(exception, request);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
        verify(notificationUtil).sendErrorMail(eq(exception), eq("Bad Request"), eq("400"), anyString());
    }

    @Test
    void handleMissingServletRequestParameterException_missingParameter_returnsBadRequestErrorResponse() {
        // Arrange
        MissingServletRequestParameterException exception = new MissingServletRequestParameterException("param", "String");

        // Act
        ResponseDto response = globalExceptionHandler.handleMissingServletRequestParameterException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleModifyingRoleOfSelfException_modifyingSelfRole_returnsBadRequestErrorResponse() {
        // Arrange
        ModifyingRoleOfSelfException exception = new ModifyingRoleOfSelfException("Cannot modify own role");

        // Act
        ResponseDto response = globalExceptionHandler.handleModifyingRoleOfSelfException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleCountryNotAssignedException_countryNotAssigned_returnsBadRequestErrorResponse() {
        // Arrange
        CountryNotAssignedException exception = new CountryNotAssignedException("Country not assigned to user");

        // Act
        ResponseDto response = globalExceptionHandler.handleCountryNotAssignedException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleDataNotFoundException_dataNotFound_returnsNotFoundErrorResponse() {
        // Arrange
        DataNotFoundException exception = new DataNotFoundException("Data not found");

        // Act
        ResponseDto response = globalExceptionHandler.handleDataNotFoundException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleInvalidStatusException_invalidStatus_returnsBadRequestErrorResponse() {
        // Arrange
        InvalidStatusException exception = new InvalidStatusException("Invalid status");

        // Act
        ResponseDto response = globalExceptionHandler.handleInvalidStatusException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }
    
    @Test
    void handleGeneralException_generalException_returnsInternalServerErrorResponseWithNotification() {
        // Arrange
        Exception exception = new Exception("General exception");

        // Act
        ResponseDto response = globalExceptionHandler.handleGeneralException(exception, request);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
        verify(notificationUtil).sendAlarm(eq(exception), eq("INTERNAL_SERVER_ERROR"), eq("500"), anyString());
    }

    @Test
    void handleUnauthorizedException_unauthorized_returnsUnauthorizedErrorResponse() {
        // Arrange
        UnauthorizedException exception = new UnauthorizedException("Unauthorized access");

        // Act
        ResponseDto response = globalExceptionHandler.handleUnauthorizedException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }

    @Test
    void handleForbiddenException_forbidden_returnsForbiddenErrorResponse() {
        // Arrange
        ForbiddenException exception = new ForbiddenException("Forbidden access");

        // Act
        ResponseDto response = globalExceptionHandler.handleForbiddenException(exception);

        // Assert
        assertNotNull(response);
        BaseResponseDto baseResponse = response.getRsp();
        assertNotNull(baseResponse);
        assertEquals("fail", baseResponse.getStat());
        assertNotNull(baseResponse.getErr());
        ErrorResponseDto errorResponse = baseResponse.getErr();
        assertNotNull(errorResponse);
    }
}
