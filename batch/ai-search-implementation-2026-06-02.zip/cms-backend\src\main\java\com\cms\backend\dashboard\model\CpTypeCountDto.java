package com.cms.backend.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Getter
@Setter
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
public class CpTypeCountDto {


    private String cpName;
    private String assetType;
    private int totalAssetsCount;
    private int assetsInProdCount;
    private int assetsInQcCount;

    @DynamoDbAttribute("cp_name")
    public String getCpName() {
        return cpName;
    }

    @DynamoDbAttribute("asset_type")
    public String getAssetType() {
        return assetType;
    }

    @DynamoDbAttribute("total_assets_count")
    public int getTotalAssetsCount() {
        return totalAssetsCount;
    }

    @DynamoDbAttribute("assets_in_prod_count")
    public int getAssetsInProdCount() {
        return assetsInProdCount;
    }

    @DynamoDbAttribute("assets_in_qc_count")
    public int getAssetsInQcCount() {
        return assetsInQcCount;
    }
}
