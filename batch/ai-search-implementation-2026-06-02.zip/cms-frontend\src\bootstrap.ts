import 'reflect-metadata';
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

let region = sessionStorage.getItem('User-Pref-Region');
if (!region || region === 'undefined') {
  sessionStorage.setItem('User-Pref-Region', 'US');
}

bootstrapApplication(AppComponent, appConfig).catch((err) =>
  console.error(err)
);
