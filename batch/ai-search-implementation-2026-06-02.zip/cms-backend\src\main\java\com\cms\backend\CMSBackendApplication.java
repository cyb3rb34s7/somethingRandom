package com.cms.backend;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication(exclude = {UserDetailsServiceAutoConfiguration.class})
@PropertySource("classpath:application-${env}.properties")
@PropertySource("classpath:application.properties")
@EnableAsync
@EnableRetry
@Slf4j
public class CMSBackendApplication {

    public static void main(String[] args) {
        try {
            log.info("Starting CMS Backend Application...");
            SpringApplication.run(CMSBackendApplication.class, args);
            log.info("CMS Backend Application started successfully");
        } catch (IllegalArgumentException e) {
            log.error("Invalid application arguments: {}", e.getMessage(), e);
        } catch (IllegalStateException e) {
            log.error("Application context failed to start: {}", e.getMessage(), e);
        } catch (Exception e) {
            log.error("Application failed to start: {}", e.getMessage(), e);
        }
    }
}
