package com.cms.backend.changehistory.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class LockHistoryRequestDto {

    @NotNull
    private String contentId;
    private String updatedBy;
    private Instant changeDateTime;

    @NotEmpty(message = "No changes found in lockHistory request")
    private List<LockChange> changes;
    @Data
    public static class LockChange {

        private String fieldName;
        @JsonProperty("isLocked")
        private boolean isLocked;
    }

}