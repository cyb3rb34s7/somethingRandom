package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.ImagePreProcessDto;
import com.cms.backend.assets.model.ImageProcessDetails;
import com.cms.backend.assets.model.ImageProcessedDto;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.model.SecurityUser;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@SpringBootTest(classes = ImageUploadServiceTest.class)
class ImageUploadServiceTest {

    @Mock
    AuthenticatedUser authUser;
    @Mock
    private HttpMethodHandler httpMethodHandler;
    @Mock
    private RegionEndpointService regionEndpointService;

    @InjectMocks
    private ImageUploadService imageUploadService;

    @BeforeEach
    void setUp() {
        when(authUser.getUserInfo()).thenReturn(
            new SecurityUser("TEST", "US", "TEST_ADMIN_ID", "TEST_SESSION_ID", new HashMap<>()));
    }

    @Test
    void testS3Upload() throws IOException {
        // Mock dependencies
        MultipartFile mockFile = mock(MultipartFile.class);
        when(mockFile.getOriginalFilename()).thenReturn("test_image.jpg");
        when(mockFile.getInputStream()).thenReturn(
            new java.io.ByteArrayInputStream("test".getBytes(StandardCharsets.UTF_8)));
        when(mockFile.getSize()).thenReturn(4L);

        S3Client mockS3Client = mock(S3Client.class);
        when(regionEndpointService.getS3Client()).thenReturn(mockS3Client);
        when(regionEndpointService.getBucketName()).thenReturn("test-bucket");
        when(regionEndpointService.getUploadPath()).thenReturn("upload-path");

        assertDoesNotThrow(() -> {
            imageUploadService.s3Upload(mockFile, "");
        });
    }

    @Test
    void testS3Upload_AmazonEx() throws IOException {
        // Mock dependencies
        MultipartFile mockFile = mock(MultipartFile.class);
        when(mockFile.getOriginalFilename()).thenReturn("test_image.jpg");
        when(mockFile.getInputStream()).thenReturn(new java.io.ByteArrayInputStream("test".getBytes(
            StandardCharsets.UTF_8)));
        when(mockFile.getSize()).thenReturn(4L);

        S3Client mockS3Client = mock(S3Client.class);
        when(regionEndpointService.getS3Client()).thenReturn(mockS3Client);
        when(regionEndpointService.getBucketName()).thenReturn("test-bucket");
        when(regionEndpointService.getUploadPath()).thenReturn("upload-path");

        Mockito.doThrow(AwsServiceException.builder().message("Exception").build())
            .when(mockS3Client)
            .putObject(Mockito.any(PutObjectRequest.class), Mockito.any(RequestBody.class));

        assertThrows(AwsServiceException.class, () -> {
            imageUploadService.s3Upload(mockFile, "");
        });
    }

    @Test
    void testS3Upload_IOEx() throws IOException {
        // Mock dependencies
        MultipartFile mockFile = mock(MultipartFile.class);
        when(mockFile.getOriginalFilename()).thenReturn("test_image.jpg");
        when(mockFile.getInputStream()).thenThrow(new IOException("Exception"));
        when(mockFile.getSize()).thenReturn(100L);

        S3Client mockS3Client = mock(S3Client.class);
        when(regionEndpointService.getS3Client()).thenReturn(mockS3Client);
        when(regionEndpointService.getBucketName()).thenReturn("test-bucket");
        when(regionEndpointService.getUploadPath()).thenReturn("upload-path");

        assertThrows(IOException.class, () -> {
            imageUploadService.s3Upload(mockFile, "");
        });
    }


    @Test
    void testTriggerExifWithImageInsert() {
        // Mock dependencies
        ImagePreProcessDto imagesDto = mock(ImagePreProcessDto.class);
        ImageProcessDetails expectedResult = ImageProcessDetails.builder().build();
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("imageProcessDetails", expectedResult);
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK
        );
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            any(Class.class))).thenReturn(responseEntity);
        // Execute method under test
        ImageProcessDetails actualResult = imageUploadService.triggerExifWithImageInsert(imagesDto);
        // Verify interactions
        verify(httpMethodHandler).handleHttpExchange(anyString(), anyString(),
            any(HttpEntity.class), any(Class.class));
        // Assert result
        assertEquals(expectedResult, actualResult);
    }

    @Test
    void testTriggerExifWithImageInsert_Ex() {
        // Mock dependencies
        ImagePreProcessDto imagesDto = mock(ImagePreProcessDto.class);

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(HttpEntity.class),
            any(Class.class))).thenThrow(new RuntimeException("exception"));

        assertThrows(CustomException.class, () -> {
            imageUploadService.triggerExifWithImageInsert(imagesDto);
        });
    }

    @Test
    void testGetImagesByRequestId() {
        // Mock dependencies
        ImageProcessDetails imageProcessDetails = ImageProcessDetails.builder()
            .processRequestId("12345").batchRequestId("67890").build();
        Mockito.when(regionEndpointService.getExifEndpoint()).thenReturn("http://test");
        List<ImageProcessedDto> expectedResult = new ArrayList<>();
        HashMap<String, Object> payload = getStringObjectHashMap();
        HashMap<String, Object> payload1 = new HashMap<>();
        payload1.put("processingStatus", "COMPLETE");
        ResponseDto responseDto1 = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload1).build()).build();
        ResponseEntity<ResponseDto> responseEntity1 = new ResponseEntity<>(responseDto1,
            HttpStatus.OK
        );
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK
        );
        Mockito.when(httpMethodHandler.handleHttpExchange(anyString(), anyString(),
            any(),
            any(Class.class))).thenReturn(responseEntity1).thenReturn(responseEntity);

        // Execute method under test
        List<ImageProcessedDto> actualResult = imageUploadService.getImagesByRequestId(
            imageProcessDetails, 0);

        // Assert result
        assertEquals(expectedResult, actualResult);
    }

    @Test
    void testGetImagesByRequestId_Ex() {
        // Mock dependencies
        ImageProcessDetails imageProcessDetails = ImageProcessDetails.builder()
            .processRequestId("12345").batchRequestId("67890").build();
        Mockito.when(regionEndpointService.getExifEndpoint()).thenReturn("http://test");
        HashMap<String, Object> payload = getStringObjectHashMap();

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK
        );
        Mockito.when(httpMethodHandler.handleHttpExchange(anyString(), anyString(),
                any(),
                any(Class.class))).thenThrow(new IllegalArgumentException("Exception"))
            .thenReturn(responseEntity);

        // Assert result
        assertDoesNotThrow(() -> {
            imageUploadService.getImagesByRequestId(imageProcessDetails, 0);
        });
    }

    @Test
    void testGetImagesByRequestId_Exception() {
        // Mock dependencies
        ImageProcessDetails imageProcessDetails = ImageProcessDetails.builder()
            .processRequestId("12345").batchRequestId("67890").build();
        Mockito.when(regionEndpointService.getExifEndpoint()).thenReturn("http://test");
        HashMap<String, Object> payload = getStringObjectHashMap();

        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK
        );
        Mockito.when(httpMethodHandler.handleHttpExchange(anyString(), anyString(),
                any(),
                any(Class.class))).thenReturn(responseEntity)
            .thenThrow(new IllegalArgumentException("Exception"));

        // Assert result
        assertDoesNotThrow(() -> {
            imageUploadService.getImagesByRequestId(imageProcessDetails, 0);
        });
    }

    private static HashMap<String, Object> getStringObjectHashMap() {
        List<ImageProcessedDto> expectedResult = new ArrayList<>();
        HashMap<String, Object> payload = new HashMap<>();
        HashMap<String, Object> payload1 = new HashMap<>();
        payload.put("imageList", expectedResult);
        payload1.put("processingStatus", "COMPLETE");
        return payload;
    }


}
