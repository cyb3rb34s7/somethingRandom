package com.cms.backend.dashboard.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.cms.backend.common.exception.CustomException;
import com.cms.backend.dashboard.model.CpTypeCountDto;
import com.cms.backend.dashboard.model.CpTypeStatusTICountDto;
import com.cms.backend.dashboard.model.CpTypeTICountDto;
import com.cms.backend.dashboard.model.DashboardCountDto;
import com.cms.backend.dashboard.model.DashboardFilterBodyDto;
import com.cms.backend.dashboard.model.LicenseWindowCountDto;
import com.cms.backend.dashboard.model.LicenseWindowTICountDto;
import com.cms.backend.dashboard.model.StatusCountDto;
import com.cms.backend.dashboard.model.StatusTICountDto;
import com.cms.backend.dashboard.model.StatusTypeCountDto;
import com.cms.backend.dashboard.model.StatusTypeTICountDto;
import com.cms.backend.dashboard.model.TypeCountDto;
import com.cms.backend.dashboard.model.TypeTICountDto;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = DashboardServiceTest.class)
class DashboardServiceTest {

    @Mock
    DynamoService dynamoService;
    @InjectMocks
    DashboardService dashboardService;

    @Test
    void testGetDashboardData() {
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder().assetsInQcCount(1)
            .countryCode("AA").region("US").regionCountry("US").build();
        List<DashboardCountDto> dashboardCountDtos = List.of(dashboardCountDto);
        when(dynamoService.getAllDashboardData("2000-09-09")).thenReturn(dashboardCountDtos);
        assertDoesNotThrow(() -> {
            dashboardService.getDashboardData("2000-09-09");
        });
    }

    @Test
    void testGetDashboardDataThrowsException() {
        when(dynamoService.getAllDashboardData(Mockito.any())).thenThrow(
            new CustomException("test"));
        assertThrows(CustomException.class, () -> {
            dashboardService.getDashboardData("2000-09-09");
        });
    }

    private static Stream<Arguments> dashboardCountryOptions() {
        return Stream.of(
            Arguments.of((Object) null),
            Arguments.of(List.of("aa"),
                Arguments.of(List.of())
            ));
    }

    @ParameterizedTest
    @MethodSource("dashboardCountryOptions")
    void testGetDashboardDataByCountry_nullEx(List<String> countriesList) {
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder().assetsInQcCount(1)
            .countryCode("AA").region("US").regionCountry("US").build();
        List<DashboardCountDto> dashboardCountDtos = List.of(dashboardCountDto);
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(countriesList);
        when(dynamoService.getCountriesHavingData("")).thenReturn(List.of("aa"));
        when(dynamoService.getDashboardDataByCountry(anyString(), anyList())).thenReturn(
            List.of(DashboardCountDto.builder().build()));
        when(dynamoService.getAllDashboardData("")).thenReturn(dashboardCountDtos);
        assertDoesNotThrow(() -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
    }

    @Test
    void testGetDashboardDataByCountryWithData() {
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder().assetsInQcCount(1)
            .countryCode("AA").region("US").regionCountry("US_AA").build();
        List<DashboardCountDto> dashboardCountDtos = List.of(dashboardCountDto);
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of("AA"));
        when(dynamoService.getDashboardDataByCountry("2000-09-09", List.of("AA"))).thenReturn(
            dashboardCountDtos);
        when(dynamoService.getAllDashboardData("2000-09-09")).thenReturn(dashboardCountDtos);
        assertDoesNotThrow(() -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
    }


    @Test
    void testGetDashboardDataByCountryThrowsException() {
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("aa"));
        when(dynamoService.getCountriesHavingData(Mockito.any())).thenThrow(
            new CustomException("test"));
        assertThrows(CustomException.class, () -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
    }

    @Test
    void testGetDashboardDataByCountryInvalidDate() {
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("200009-09");
        dashboardFilterBodyDto.setCountries(List.of("aa"));
        assertThrows(CustomException.class, () -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
    }

    @Test
    void testGetDashboardDataByCountryWithEmptyCountriesHavingData() {
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of());
        List<DashboardCountDto> result = dashboardService.getDashboardDataByCountry(
            dashboardFilterBodyDto);
        assertEquals(0, result.size());
    }

    @Test
    void testGetDashboardDataByCountryWithDuplicateCountries() {
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA", "AA", "BB"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of("AA", "BB"));
        when(dynamoService.getDashboardDataByCountry(anyString(), anyList())).thenReturn(List.of());
        assertDoesNotThrow(() -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
        // Verify that duplicates are removed by checking the argument passed to the mock
        Mockito.verify(dynamoService).getDashboardDataByCountry(Mockito.anyString(),
            Mockito.argThat(list -> list.size() == 2));
    }

    @Test
    void testGetDashboardDataByCountryWithFilteredCountries() {
        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA", "BB", "CC"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of("AA", "BB"));
        when(dynamoService.getDashboardDataByCountry(anyString(), anyList())).thenReturn(List.of());
        assertDoesNotThrow(() -> {
            dashboardService.getDashboardDataByCountry(dashboardFilterBodyDto);
        });
        // Verify that only countries with data are passed to the mock
        Mockito.verify(dynamoService).getDashboardDataByCountry(Mockito.anyString(),
            Mockito.argThat(
                list -> list.size() == 2 && list.contains("AA") && list.contains("BB")));
    }

    @Test
    void testGetLastRunTime() {
        when(dynamoService.getLastBatchRunTime()).thenReturn("aa");
        assertDoesNotThrow(() -> {
            dashboardService.getLastRunTime();
        });
    }

    @Test
    void testGetLastRunTimeThrowsException() {
        when(dynamoService.getLastBatchRunTime()).thenThrow(new CustomException("test"));
        assertThrows(CustomException.class, () -> {
            dashboardService.getLastRunTime();
        });
    }

    private static Stream<Arguments> dashboardDataTestParameters() {
        return Stream.of(
            Arguments.of(false, "2000-09-09"),
            Arguments.of(true, "200009-09"),
            Arguments.of(true, "2000-9-09")
        );
    }

    @ParameterizedTest
    @MethodSource("dashboardDataTestParameters")
    void testValidateDateStringWithValidDate(boolean throwError, String date) {
        if (throwError) {
            assertThrows(CustomException.class, () -> dashboardService.getDashboardData(date));
        } else {
            assertDoesNotThrow(() -> {
                dashboardService.getDashboardData(date);
            });
        }
    }

    private static Stream<Arguments> regionCountryTestParams() {
        return Stream.of(
            Arguments.of("US_AA", "US", "AA"),
            Arguments.of("US", (Object) null, (Object) null)
        );
    }

    @ParameterizedTest
    @MethodSource("regionCountryTestParams")
    void testProcessDashboardListWithValidRegionCountry(String regionCountry, String region,
        String country) {
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder()
            .assetsInQcCount(1)
            .regionCountry(regionCountry)
            .build();
        List<DashboardCountDto> dashboardCountDtos = List.of(dashboardCountDto);
        when(dynamoService.getAllDashboardData("2000-09-09")).thenReturn(dashboardCountDtos);
        List<DashboardCountDto> result = dashboardService.getDashboardData("2000-09-09");
        assertEquals(region, result.get(0).getRegion());
        assertEquals(country, result.get(0).getCountryCode());
    }


    @Test
    void testFilterIrrelevantItemsWithCompleteData() {
        // Create a DashboardCountDto with all required fields populated
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder()
            .assetsInQcCount(1)
            .regionCountry("US_AA")
            .statusWiseAssetsCountList(List.of(new StatusCountDto()))
            .statusTypeWiseAssetsCountList(List.of(new StatusTypeCountDto()))
            .typeWiseAssetsCountList(List.of(new TypeCountDto()))
            .cpTypeWiseAssetsCountList(List.of(new CpTypeCountDto()))
            .licenseWindowWiseAssetsCountList(List.of(new LicenseWindowCountDto()))
            .statusTiWiseAssetsCountList(List.of(new StatusTICountDto()))
            .statusTypeTiWiseAssetsCountList(List.of(new StatusTypeTICountDto()))
            .typeTiWiseAssetsCountList(List.of(new TypeTICountDto()))
            .cpTypeTiWiseAssetsCountList(List.of(new CpTypeTICountDto()))
            .cpTypeStatusTiWiseAssetsCountList(List.of(new CpTypeStatusTICountDto()))
            .licenseWindowTiWiseAssetsCountList(List.of(new LicenseWindowTICountDto()))
            .build();

        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of("AA"));
        when(dynamoService.getDashboardDataByCountry("2000-09-09", List.of("AA"))).thenReturn(
            List.of(dashboardCountDto));

        List<DashboardCountDto> result = dashboardService.getDashboardDataByCountry(
            dashboardFilterBodyDto);
        // Should include the item as all fields are populated
        assertEquals(1, result.size());
    }

    @Test
    void testFilterIrrelevantItemsWithIncompleteData() {
        // Create a DashboardCountDto with missing required fields
        DashboardCountDto dashboardCountDto = DashboardCountDto.builder()
            .assetsInQcCount(1)
            .regionCountry("US_AA")
            .statusWiseAssetsCountList(List.of(new StatusCountDto()))
            .statusTypeWiseAssetsCountList(List.of(new StatusTypeCountDto()))
            // Missing other required fields
            .build();

        DashboardFilterBodyDto dashboardFilterBodyDto = new DashboardFilterBodyDto();
        dashboardFilterBodyDto.setDate("2000-09-09");
        dashboardFilterBodyDto.setCountries(List.of("AA"));
        when(dynamoService.getCountriesHavingData("2000-09-09")).thenReturn(List.of("AA"));
        when(dynamoService.getDashboardDataByCountry("2000-09-09", List.of("AA"))).thenReturn(
            List.of(dashboardCountDto));

        List<DashboardCountDto> result = dashboardService.getDashboardDataByCountry(
            dashboardFilterBodyDto);
        // Should filter out the item as not all fields are populated
        assertEquals(0, result.size());
    }
}
