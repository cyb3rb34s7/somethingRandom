package com.cms.backend.assets.aisearch.constant;

public final class AiSearchConstants {

    public static final String CHAT_ENDPOINT = "/v1/chat";
    public static final int DEFAULT_LIMIT = 100;
    public static final int DEFAULT_OFFSET = 0;
    public static final String SCHEMA_RESOURCE = "ai/filter-schema.expected.json";

    private AiSearchConstants() {
    }
}
