package com.cms.backend.common.exception;


import com.cms.backend.common.util.NotificationUtil;
import java.lang.reflect.Method;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

@Slf4j
public class CustomAsyncExceptionHandler implements AsyncUncaughtExceptionHandler {

    private final NotificationUtil notificationUtil;

    public CustomAsyncExceptionHandler(NotificationUtil notificationUtil) {
        this.notificationUtil = notificationUtil;
    }

    @Override
    public void handleUncaughtException(Throwable throwable, Method method, Object... objects) {
        notificationUtil.sendErrorMail(new Exception(throwable.getMessage()), "Async Call Error",
            "ASYNC_ERROR", "CMS-ADMIN");
        log.error("Exception: Message={}, Method={},parameters:{}", throwable.getMessage(),
            method.getName(),
            Arrays.toString(objects));
    }
}
