package com.cms.backend.assets.model;

import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssetChangeHistoryDto {

    private MetadataHistoryRequestDto assetMetadataHistory;
    private LicenseHistoryRequestDto assetLicenseHistory;
    private StatusHistoryRequestDto assetStatusHistory;
    private EventHistoryRequestDto eventHistory;
}