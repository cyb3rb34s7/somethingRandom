package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class AssetRequestBodyDtoTest {

    private AssetRequestBodyDto assetRequestBodyDto;

    @BeforeEach
    void setUp() {
        VodAssetDto vodAssetDto = Mockito.mock(VodAssetDto.class);
        AssetChangeHistoryDto assetChangeHistoryDto = Mockito.mock(AssetChangeHistoryDto.class);

        assetRequestBodyDto = AssetRequestBodyDto.builder()
            .vodAssetDto(vodAssetDto)
            .assetChangeHistoryDto(assetChangeHistoryDto)
            .build();
    }

    @Test
    void testAssetRequestBodyDto() {
        assertNotNull(assetRequestBodyDto.getVodAssetDto());
        assertNotNull(assetRequestBodyDto.getAssetChangeHistoryDto());
    }
}