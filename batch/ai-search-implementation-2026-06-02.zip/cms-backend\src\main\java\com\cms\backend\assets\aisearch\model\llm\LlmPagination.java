package com.cms.backend.assets.aisearch.model.llm;

import com.cms.backend.assets.aisearch.constant.AiSearchConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmPagination {

    private int limit = AiSearchConstants.DEFAULT_LIMIT;
    private int offset = AiSearchConstants.DEFAULT_OFFSET;
}
