package com.cms.backend.evaluation.model;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;

import java.util.List;

@Builder
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString(callSuper = true)
public class ComparisonAssetListResponseDto {
    private long totalCount;
    private long matchedCount;
    private long coveredCount;
    private List<JsonNode> data;
}
