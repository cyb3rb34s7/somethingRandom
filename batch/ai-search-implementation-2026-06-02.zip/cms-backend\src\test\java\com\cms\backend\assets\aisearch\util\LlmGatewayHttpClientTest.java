package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.aisearch.exception.LlmGatewayException;
import com.cms.backend.assets.aisearch.model.llm.LlmChatResponse;
import com.cms.backend.assets.aisearch.model.llm.LlmData;
import com.cms.backend.assets.aisearch.model.llm.LlmError;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class LlmGatewayHttpClientTest {

    @Mock
    RestTemplate restTemplate;
    @InjectMocks
    LlmGatewayHttpClient client;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(client, "llmServerUrl", "http://llm");
    }

    @Test
    void returnsContentOnSuccess() {
        LlmChatResponse body = new LlmChatResponse();
        body.setSuccess(true);
        LlmData data = new LlmData();
        data.setContent("{\"status\":\"resolved\"}");
        body.setData(data);
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(body));

        assertThat(client.complete("system", "query")).isEqualTo("{\"status\":\"resolved\"}");
    }

    @Test
    void throwsWhenSuccessFalseWithErrorMessage() {
        LlmChatResponse body = new LlmChatResponse();
        body.setSuccess(false);
        LlmError error = new LlmError();
        error.setCode("RATE_LIMIT");
        error.setMessage("rate limited");
        body.setError(error);
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(body));

        assertThatThrownBy(() -> client.complete("s", "q"))
                .isInstanceOf(LlmGatewayException.class)
                .hasMessageContaining("rate limited");
    }

    @Test
    void throwsWhenSuccessFalseWithoutError() {
        LlmChatResponse body = new LlmChatResponse();
        body.setSuccess(false);
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(body));

        assertThatThrownBy(() -> client.complete("s", "q"))
                .isInstanceOf(LlmGatewayException.class)
                .hasMessageContaining("Empty LLM response");
    }

    @Test
    void throwsWhenBodyNull() {
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(null));

        assertThatThrownBy(() -> client.complete("s", "q")).isInstanceOf(LlmGatewayException.class);
    }

    @Test
    void throwsWhenDataNull() {
        LlmChatResponse body = new LlmChatResponse();
        body.setSuccess(true);
        body.setData(null);
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(body));

        assertThatThrownBy(() -> client.complete("s", "q")).isInstanceOf(LlmGatewayException.class);
    }

    @Test
    void throwsWhenContentNull() {
        LlmChatResponse body = new LlmChatResponse();
        body.setSuccess(true);
        body.setData(new LlmData()); // content is null
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenReturn(ResponseEntity.ok(body));

        assertThatThrownBy(() -> client.complete("s", "q")).isInstanceOf(LlmGatewayException.class);
    }

    @Test
    void throwsOnTransportError() {
        when(restTemplate.exchange(eq("http://llm/v1/chat"), eq(HttpMethod.POST), any(),
                eq(LlmChatResponse.class)))
                .thenThrow(new RestClientException("connection refused"));

        assertThatThrownBy(() -> client.complete("s", "q"))
                .isInstanceOf(LlmGatewayException.class)
                .hasMessageContaining("connection refused");
    }
}
