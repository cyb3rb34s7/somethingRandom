package com.cms.backend.assets.aisearch.model.llm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LlmFilter {

    private String key;
    private String type;
    private List<String> values = new ArrayList<>();
}
