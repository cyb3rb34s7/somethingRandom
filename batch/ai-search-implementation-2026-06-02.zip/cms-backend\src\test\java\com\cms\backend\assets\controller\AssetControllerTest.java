package com.cms.backend.assets.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.model.AssetEpisodeHierarchyDto;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetRequestBodyDto;
import com.cms.backend.assets.model.AssetSingleImageUpdateDto;
import com.cms.backend.assets.model.AssetUpdateByBulkDto;
import com.cms.backend.assets.model.ExportHelperDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.service.AssetExportImportTemplateService;
import com.cms.backend.assets.service.AssetExportService;
import com.cms.backend.assets.service.AssetManagementService;
import com.cms.backend.assets.service.AssetMasterDataService;
import com.cms.backend.assets.service.AssetService;
import com.cms.backend.common.model.ResponseDto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetControllerTest.class)
class AssetControllerTest {

    @Mock
    AssetService assetService;

    @Mock
    AssetExportService assetExportService;

    @Mock
    AssetExportImportTemplateService assetExportImportTemplateService;

    @Mock
    AssetManagementService assetManagementService;

    @Mock
    AssetMasterDataService assetMasterDataService;

    @InjectMocks
    AssetController assetController;

    @Test
    void testGetFilteredAssetsList() {
        Mockito.doReturn(new ResponseDto()).when(assetService).getFilteredAssets(any(
            AssetFilterBodyDto.class));
        assertDoesNotThrow(() -> {
            assetController.getFilteredAssetsList(AssetFilterBodyDto.builder().build());
        });
    }

    @Test
    void testGetAssetView() {
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .getAssetView(anyString(), anyString(), anyString());
        assertDoesNotThrow(() -> {
            assetController.getAssetView("test_id", "test_cp_id", "test_code");
        });
    }

    @Test
    void testGetPrdAssetView() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getPrdAssetView(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        assertDoesNotThrow(() -> {
            assetController.getPrdAssetView("test_id", "test_cp_id", "test_code");
        });
    }

    @Test
    void testGetFilters() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService).getFilters();
        assertDoesNotThrow(() -> {
            assetController.getFilters();
        });
    }


    @Test
    void testUpdateAssetStatus() {
        Mockito.doReturn(new ResponseDto()).when(assetService).updateStatusByBulk(any(
            StatusUpdateDto.class));
        assertDoesNotThrow(() -> {
            assetController.updateAssetStatus(StatusUpdateDto.builder().build());
        });
    }

    @Test
    void testUpdateAsset() {
        Mockito.doReturn(new ResponseDto()).when(assetService).editAndHistoryCall(any(
            AssetRequestBodyDto.class));
        assertDoesNotThrow(() -> {
            assetController.updateAsset(AssetRequestBodyDto.builder().build());
        });
    }


    @Test
    void testGetCountry() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService).getCountryCodes();
        assertDoesNotThrow(() -> {
            assetController.getCountryCodes();
        });
    }

    @Test
    void testUploadUpdates() {

        Mockito.doReturn(new ArrayList<>()).when(assetService).uploadUpdates(any());
        assertDoesNotThrow(() -> {
            assetService.uploadUpdates(any());
        });
        assertDoesNotThrow(() -> {
            assetController.uploadUpdates(any());
        });

    }

    @Test
    void testUploadAction() {
        String response = "response";
        List<VodAssetDto> expectedResult = mock(List.class);

        when(assetService.uploadAction(response)).thenReturn(expectedResult);
        assertDoesNotThrow(() -> {
            assetController.uploadAction(response);
        });
    }

    @Test
    void testExistingUpdates() {
        List<VodAssetDto> vodAssetDtoList = List.of(VodAssetDto.builder().build());
        when(assetService.getImportedAssets()).thenReturn(vodAssetDtoList);
        assertDoesNotThrow(() -> {
            assetController.existingUpdates();
        });

    }


    @Test
    void testUploadSingleImage() {
        Mockito.doReturn(new HashMap<>()).when(assetService).uploadSingleImage(Mockito.any());
        assertDoesNotThrow(() -> {
            assetController.uploadSingleImage(new AssetSingleImageUpdateDto());
        });
    }

    @Test
    void testAllGetCountry() {
        Mockito.doReturn(new HashMap<>()).when(assetMasterDataService).getAllCountryCodes();
        assertDoesNotThrow(() -> {
            assetController.getAllCountryCodes();
        });
    }

    @Test
    void testLanguages() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService).getLanguages();
        assertDoesNotThrow(() -> {
            assetController.getLanguages();
        });
    }

    @Test
    void testGetEpisodeHierarchy() {
        AssetEpisodeHierarchyDto assetEpisodeHierarchyDto = AssetEpisodeHierarchyDto.builder()
            .build();
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .getEpisodeHierarchy(assetEpisodeHierarchyDto);
        assertDoesNotThrow(() -> assetController.getEpisodeHierarchy(assetEpisodeHierarchyDto));
    }

    @Test
    void testGetViewFilters() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService)
            .getAssetViewFilters(Mockito.any());
        assertDoesNotThrow(() -> {
            assetController.getAssetViewFilters(
                AssetKeyDto.builder().contentId("TEST").countryCode("TEST").vcCpId("TEST").build());
        });
    }

    @Test
    void testPrdGetViewFilters() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getPrdAssetViewFilters(Mockito.any());
        assertDoesNotThrow(() -> {
            assetController.getPrdAssetViewFilters(
                AssetKeyDto.builder().contentId("TEST").countryCode("TEST").vcCpId("TEST").build());
        });
    }


    @Test
    void testGetAssetCount() {
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .getFilteredAssetsCount(Mockito.any(), Mockito.any());
        assertDoesNotThrow(() -> {
            assetController.getFilteredAssetsListCount(AssetFilterBodyDto.builder().build(),
                "TEST");
        });
    }

    @Test
    void testGetPlatforms() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService)
            .getMasterPlatformData();
        assertDoesNotThrow(() -> {
            assetController.getPlatformData();
        });
    }

    @Test
    void testGetShowHierarchy() {
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().vcCpId("aa").countryCode("aa")
            .contentId("aa").build();
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .getShowHierarchy(assetKeyDto);
        assertDoesNotThrow(() -> {
            assetController.getShowHierarchy(assetKeyDto);
        });
    }

    @Test
    void testUpdateAssetByBulk() {
        AssetUpdateByBulkDto assetUpdateByBulkDto = AssetUpdateByBulkDto.builder().vodAssetDto(
            VodAssetDto.builder().build()).contentIds(List.of("aa")).build();
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .updateAssetInBulkPortal(assetUpdateByBulkDto);
        assertDoesNotThrow(() -> {
            assetController.updateAssetByBulk(assetUpdateByBulkDto);
        });
    }

    @Test
    void testValidateAssetDetails() {
        Mockito.doReturn(new ResponseDto()).when(assetService)
            .validateAssetDetails(any());
        assertDoesNotThrow(() -> {
            assetController.validateAssetDetails(any());
        });
    }

    @Test
    void testGetAssetViewFilters() {
        Mockito.doReturn(new ResponseDto()).when(assetMasterDataService)
            .getAssetViewFilters(any());

        assertDoesNotThrow(() -> {
            assetController.getAssetViewFilters(any());
        });
    }

    @Test
    void testBulkRevokeHierarchy() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService).bulkRevokeHierarchy(any(
            List.class));
        assertDoesNotThrow(() -> {
            assetController.bulkRevokeHierarchy(new ArrayList<>());
        });
    }

    @Test
    void testMediaUrls() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService).getStreamUrls(any(
            String.class), any(
            String.class), any(
            String.class));
        assertDoesNotThrow(() -> {
            assetController.getStreamUrls("contentId", "cpId", "countryCode");
        });
    }

    @Test
    void testGetCpData() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getCpData("contentId", "cpId", "countryCode");
        assertDoesNotThrow(
            () -> assetController.getCpData("contentId", "cpId", "countryCode"));
    }

    @Test
    void testGetGracenoteData() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getGracenoteData("contentId", "cpId", "countryCode");
        assertDoesNotThrow(
            () -> assetController.getGracenoteData("contentId", "cpId", "countryCode"));
    }

    @Test
    void testUpdateCPData() {
        AssetRequestBodyDto assetRequestBodyDto = AssetRequestBodyDto.builder().vodAssetDto(
            VodAssetDto.builder().contentId("u").countryCode("eu").vcCpId("dg").build()).build();
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .updateCPData(assetRequestBodyDto.getVodAssetDto());
        assertDoesNotThrow(() -> {
            assetController.updateCPData(assetRequestBodyDto);
        });
    }

    @Test
    void testGetStaticJson() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getStaticJSON(anyString());
        assertDoesNotThrow(() -> {
            assetController.getStaticJson("test_name");
        });
    }

    @Test
    void testGetFilename() {
        Mockito.doReturn(new ResponseDto()).when(assetManagementService)
            .getSmfFileName();
        assertDoesNotThrow(() -> {
            assetController.getSmfFileName();
        });
    }

    @Test
    void testDownloadFile() throws Exception {
        // Arrange
        byte[] fileContent = "Test file content".getBytes(StandardCharsets.UTF_8);
        Mockito.doReturn(fileContent).when(assetManagementService)
            .getS3File(anyString());
        assertDoesNotThrow(() -> {
            assetController.downloadFile("test_name");
        });
    }

    @Test
    void testExport() throws IOException {
        // Arrange
        byte[] fileContent = "Test file content".getBytes(StandardCharsets.UTF_8);
        ExportHelperDto exportHelperDto = ExportHelperDto.builder().excelData(fileContent)
            .fileName("excel").fileType("ZIP").build();
        Mockito.doReturn(exportHelperDto).when(assetExportService)
            .startExport(any(), anyBoolean());
        assertDoesNotThrow(() -> {
            assetController.exportAssetData(AssetFilterBodyDto.builder().build());
        });
    }

    @Test
    void testExportSelected() {
        // Arrange

        Mockito.doReturn(null).when(assetExportImportTemplateService)
            .exportSelected(any(), anyString());
        assertDoesNotThrow(() -> {
            assetController.exportSelected(AssetFilterBodyDto.builder().build(), "search");
        });
    }

    @Test
    void testDownloadFileFromS3() {
        // Arrange
        byte[] fileContent = "Test file content".getBytes(StandardCharsets.UTF_8);
        org.springframework.http.ResponseEntity<byte[]> responseEntity =
            org.springframework.http.ResponseEntity.ok(fileContent);

        Mockito.doReturn(responseEntity).when(assetManagementService)
            .getFileFromS3(anyString(), anyString());
        assertDoesNotThrow(() -> {
            assetController.downloadFileFromS3("test_name", "test/path/");
        });
    }
}
