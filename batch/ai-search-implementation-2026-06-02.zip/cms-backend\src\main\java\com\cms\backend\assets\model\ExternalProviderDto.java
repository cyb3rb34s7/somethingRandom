package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Generated
public class ExternalProviderDto {

    @Pattern(regexp = "^[0-9A-Za-z_-]+$")
    @Size(max = 125)
    @NotNull(message = "provider cannot be null, stated idType, provider given")
    private String externalProgramId;

    @NotNull(message = "idType cannot be null, stated provider, externalProgramId given")
    @Pattern(regexp = "^(?i)(tmsId|rootId)$")
    private String idType;

    private String idProvider;

    @NotNull(message = "provider cannot be null, stated idType, externalProgramId given")
    @Pattern(regexp = "^(?i)(tms)$")
    private String provider;

    public String generateProgramTypeProviderTuple() {
        return externalProgramId + "$" + idType + "$" + provider;
    }
}
