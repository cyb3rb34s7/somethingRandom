package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetHeaderMapTest {

    @Test
    void testGetMap() {
        Map<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put("contentId", "Program ID");
        assetHeader.put("tiName", "TI Name");
        assetHeader.put("cpName", "CP Name");
        assetHeader.put("countryCode", "Country");
        assetHeader.put("vcCpId", "Provider ID");
        assetHeader.put("type", "Program Type");
        assetHeader.put("mainTitle", "Program Title/Episode Title");
        assetHeader.put("description", "Synopsis/Description");
        assetHeader.put("showId", "Show Id");
        assetHeader.put("seasonId", "Season Id");
        assetHeader.put("seasonNo", "Season No.");
        assetHeader.put("episodeNo", "Episode No.");
        assetHeader.put("licenseWindow", "License Window");
        assetHeader.put("status", "Media Status");
        assetHeader.put("assetId", "Asset Id");
        assetHeader.put("runningTime", "Duration (sec)");
        assetHeader.put("genres", "Genres");
        assetHeader.put("updateDate", "Updated Date");
        assetHeader.put("starring", "Cast (Person Name)");
        assetHeader.put("artist", "Artist");
        assetHeader.put("director", "Director");
        assetHeader.put("availableStarting", "Window Start Date");
        assetHeader.put("expiryDate", "Window End Date");
        assetHeader.put("releaseDate", "Original Release Date");
        assetHeader.put("externalId", "TMS/Gracenote ID");
        assetHeader.put("isReleased", "Prod Status");
        assetHeader.put("contentPartner", "Content Partner");
        assetHeader.put("showTitle", "Show Title");
        assetHeader.put("seasonTitle", "Season Title");
        assetHeader.put("ratings", "Ratings");


        Map<String, String> actualMap = AssetHeaderMap.getMap();
        assertEquals(assetHeader, actualMap);
    }
}
