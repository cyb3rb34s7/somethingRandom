package com.cms.backend.assets.aisearch.controller;

import com.cms.backend.assets.aisearch.model.AiSearchRequest;
import com.cms.backend.assets.aisearch.service.AiSearchService;
import com.cms.backend.common.model.ResponseDto;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin/asset/ai-search")
@RequiredArgsConstructor
@Slf4j
public class AiSearchController {

    private final AiSearchService aiSearchService;

    @PostMapping("/resolve")
    public ResponseDto resolve(@Valid @RequestBody AiSearchRequest request) {
        log.info("AI search resolve request: query='{}'", request.getQuery());
        return aiSearchService.resolve(request);
    }
}
