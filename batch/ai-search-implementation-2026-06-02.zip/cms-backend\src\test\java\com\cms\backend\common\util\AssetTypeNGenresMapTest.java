package com.cms.backend.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Map;
import org.junit.jupiter.api.Test;

class AssetTypeNGenresMapTest {

    @Test
    void testInitializeGenresMapping() {
        AssetTypeNGenresMap assetTypeNGenresMap = new AssetTypeNGenresMap();

        Map<String, String> genresMapping = assetTypeNGenresMap.initializeGenresMapping();

        assertEquals("Action", genresMapping.get("action"));
        assertEquals("Arts/Culture", genresMapping.get("arts/culture"));
        assertEquals("Cartoons/Puppets", genresMapping.get("cartoons/puppets"));
        assertEquals("Comedy", genresMapping.get("comedy"));
        assertEquals("Cooking", genresMapping.get("cooking"));
        assertEquals("Crime", genresMapping.get("crime"));
        assertEquals("Documentary", genresMapping.get("documentary"));
        assertEquals("Drama", genresMapping.get("drama"));
        assertEquals("Education", genresMapping.get("education"));
        assertEquals("Entertainment", genresMapping.get("entertainment"));
        assertEquals("Fantasy", genresMapping.get("fantasy"));
        assertEquals("History", genresMapping.get("history"));
        assertEquals("Horror", genresMapping.get("horror"));
        assertEquals("KIDS", genresMapping.get("kids"));
        assertEquals("Music", genresMapping.get("music"));
        assertEquals("Mystery", genresMapping.get("mystery"));
        assertEquals("News", genresMapping.get("news"));
        assertEquals("Reality", genresMapping.get("reality"));
        assertEquals("Romance", genresMapping.get("romance"));
        assertEquals("Science fiction", genresMapping.get("science fiction"));
        assertEquals("Shopping", genresMapping.get("shopping"));
        assertEquals("Sports", genresMapping.get("sports"));
        assertEquals("Talk", genresMapping.get("talk"));
        assertEquals("Travel", genresMapping.get("travel"));
    }

    @Test
    void testInitializeGenresNonMapping() {
        AssetTypeNGenresMap assetTypeNGenresMap = new AssetTypeNGenresMap();
        Map<String, String> genresMusic = assetTypeNGenresMap.initializeGenresMusicMapping();
        assertEquals("Afro", genresMusic.get("afro"));
        assertEquals("Ambient", genresMusic.get("ambient"));
        assertEquals("Arab", genresMusic.get("arab"));
        assertEquals("Bluegrass", genresMusic.get("bluegrass"));
        assertEquals("Blues", genresMusic.get("blues"));
        assertEquals("Caribbean", genresMusic.get("caribbean"));
        assertEquals("Classical", genresMusic.get("classical"));
        assertEquals("Concert", genresMusic.get("concert"));
        assertEquals("Country", genresMusic.get("country"));
        assertEquals("Dance", genresMusic.get("dance"));
        assertEquals("Disco", genresMusic.get("disco"));
        assertEquals("Electronic", genresMusic.get("electronic"));
        assertEquals("Flamenco", genresMusic.get("flamenco"));
        assertEquals("Folk & Acoustic", genresMusic.get("folk & acoustic"));
        assertEquals("Funk", genresMusic.get("funk"));
        assertEquals("Gospel", genresMusic.get("gospel"));
        assertEquals("Hip-Hop", genresMusic.get("hip-hop"));
        assertEquals("Holiday", genresMusic.get("holiday"));
        assertEquals("Indie & Alternative", genresMusic.get("indie & alternative"));
        assertEquals("Jazz", genresMusic.get("jazz"));
        assertEquals("Karaoke", genresMusic.get("karaoke"));
        assertEquals("Kids", genresMusic.get("kids"));
        assertEquals("Latin", genresMusic.get("latin"));
        assertEquals("Metal", genresMusic.get("metal"));
        assertEquals("New Age", genresMusic.get("new age"));

    }

    @Test
    void testInitializeGenresNonmapping() {
        AssetTypeNGenresMap assetTypeNGenresMap = new AssetTypeNGenresMap();
        Map<String, String> genresMusic = assetTypeNGenresMap.initializeGenresMusicMapping();
        assertEquals("Opera", genresMusic.get("opera"));
        assertEquals("Pop", genresMusic.get("pop"));
        assertEquals("Punk", genresMusic.get("punk"));
        assertEquals("R&B", genresMusic.get("r&b"));
        assertEquals("Reggae", genresMusic.get("reggae"));
        assertEquals("Reggaeton", genresMusic.get("reggaeton"));
        assertEquals("Religious", genresMusic.get("religious"));
        assertEquals("Rock", genresMusic.get("rock"));
        assertEquals("Salsa", genresMusic.get("salsa"));
        assertEquals("Ska", genresMusic.get("ska"));
        assertEquals("Soul", genresMusic.get("soul"));
        assertEquals("Traditional", genresMusic.get("traditional"));
    }
}
