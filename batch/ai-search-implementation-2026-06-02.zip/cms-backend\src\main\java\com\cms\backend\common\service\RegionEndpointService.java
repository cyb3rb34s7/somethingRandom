package com.cms.backend.common.service;

import com.cms.backend.assets.configuration.S3Config;
import com.cms.backend.common.model.AuthenticatedUser;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.sqs.SqsClient;

@Service
public class RegionEndpointService {

    private final AuthenticatedUser user;
    private final S3Config s3Config;
    private final SqsClient sqsClientUS;
    private final SqsClient sqsClientEU;

    @Value("${US_ASSET_OPENAPI_URL}")
    private String assetManagementUSOpenApiUrl;
    @Value("${EU_ASSET_OPENAPI_URL}")
    private String assetManagementEUOpenApiUrl;

    @Value("${US_ASSET_OPENAPI_URL_PRD:#{null}}")
    private String assetManagementUSOpenApiUrlPrd;
    @Value("${EU_ASSET_OPENAPI_URL_PRD:#{null}}")
    private String assetManagementEUOpenApiUrlPrd;

    @Value("${US_ASSET_OPENAPI_URL_NLB}")
    private String assetManagementUSOpenApiUrlNlb;
    @Value("${EU_ASSET_OPENAPI_URL_NLB}")
    private String assetManagementEUOpenApiUrlNlb;

    @Value("${US_HISTORY_OPENAPI_URL}")
    private String historyManagementUSOpenApiUrl;
    @Value("${EU_HISTORY_OPENAPI_URL}")
    private String historyManagementEUOpenApiUrl;

    @Value("${US_SYNC_QUEUE_URL}")
    private String syncQueueUSUrl;
    @Value("${EU_SYNC_QUEUE_URL}")
    private String syncQueueEUUrl;

    @Value("${US_SYNC_QUEUE_URL_DELTA}")
    private String syncQueueUSUrlDelta;
    @Value("${EU_SYNC_QUEUE_URL_DELTA}")
    private String syncQueueEUUrlDelta;

    @Value("${US_EXIF_URL}")
    private String usExifUrl;
    @Value("${EU_EXIF_URL}")
    private String euExifUrl;

    @Value("${US_BUCKET_NAME}")
    private String usBucketName;
    @Value("${EU_BUCKET_NAME}")
    private String euBucketName;


    @Value("${US_CLOUD_FRONT_URL}")
    private String usCloudFrontUrl;
    @Value("${EU_CLOUD_FRONT_URL}")
    private String euCloudFrontUrl;

    @Value("${US_CLOUD_FRONT_URL_CMS}")
    private String usCloudFrontUrlCms;
    @Value("${EU_CLOUD_FRONT_URL_CMS}")
    private String euCloudFrontUrlCms;

    @Value("${US_UPLOAD_PATH}")
    private String usUploadPath;
    @Value("${EU_UPLOAD_PATH}")
    private String euUploadPath;

    @Value("${US_VOD_STATUS_UPDATER_SQS_URL}")
    private String usVodStatusUpdaterSqsUrl;
    @Value("${EU_VOD_STATUS_UPDATER_SQS_URL}")
    private String euVodStatusUpdaterSqsUrl;


    public RegionEndpointService(AuthenticatedUser user, S3Config s3Config,
        @Qualifier("usSqsClient") SqsClient sqsClientUS,
        @Qualifier("euSqsClient") SqsClient sqsClientEU) {
        this.user = user;
        this.s3Config = s3Config;
        this.sqsClientUS = sqsClientUS;
        this.sqsClientEU = sqsClientEU;

    }

    public String getOpenAPIEndpoint() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return assetManagementEUOpenApiUrl;
        } else {
            return assetManagementUSOpenApiUrl;
        }
    }

    public String getOpenAPIEndpointNLB() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return assetManagementEUOpenApiUrlNlb;
        } else {
            return assetManagementUSOpenApiUrlNlb;
        }
    }

    public String getHistoryAPIEndpoint() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return historyManagementEUOpenApiUrl;
        } else {
            return historyManagementUSOpenApiUrl;
        }
    }

    public String getSQSEndpoint() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return syncQueueEUUrl;
        } else {
            return syncQueueUSUrl;
        }
    }

    public String getSQSEndpointDelta() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return syncQueueEUUrlDelta;
        } else {
            return syncQueueUSUrlDelta;
        }
    }

    public String getExifEndpoint() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euExifUrl;
        } else {
            return usExifUrl;
        }
    }

    public S3Client getS3Client() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return s3Config.euAmazonS3();
        } else {
            return s3Config.usAmazonS3();
        }
    }

    public SqsClient getSqsClient() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return sqsClientEU;
        } else {
            return sqsClientUS;
        }
    }

    public String getUSOpenAPIEndpoint() {
        return assetManagementUSOpenApiUrl;
    }

    public String getEUOpenAPIEndpoint() {
        return assetManagementEUOpenApiUrl;
    }

    public String getCloudFrontUrl() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euCloudFrontUrl;
        } else {
            return usCloudFrontUrl;
        }
    }

    public String getBucketName() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euBucketName;
        } else {
            return usBucketName;
        }
    }


    public String getUploadPath() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euUploadPath;
        } else {
            return usUploadPath;
        }
    }

    public String getOpenAPIEndpointPRD() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return assetManagementEUOpenApiUrlPrd;
        } else {
            return assetManagementUSOpenApiUrlPrd;
        }
    }

    public String getCloudFrontUrlCms() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euCloudFrontUrlCms;
        } else {
            return usCloudFrontUrlCms;
        }
    }

    public String getStatusUpdaterSQSLink() {
        if (user.getUserInfo() != null && "EU".equals(user.getUserInfo().getServiceRegion())) {
            return euVodStatusUpdaterSqsUrl;
        } else {
            return usVodStatusUpdaterSqsUrl;
        }
    }


}
