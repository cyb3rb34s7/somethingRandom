package com.cms.backend.evaluation.enums;

import lombok.Getter;

@Getter
public enum FeedWorkerEnum {
    CMS("CMS"),
    TVPLUS("TVPLUS");

    private final String value;

    FeedWorkerEnum(String value) {
        this.value = value;
    }
}
