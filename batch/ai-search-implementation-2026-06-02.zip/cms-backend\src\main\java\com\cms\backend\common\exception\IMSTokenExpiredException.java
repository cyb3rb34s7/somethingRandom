package com.cms.backend.common.exception;

public class IMSTokenExpiredException extends RuntimeException {

    public IMSTokenExpiredException(String message) {
        super(message);
    }
}
