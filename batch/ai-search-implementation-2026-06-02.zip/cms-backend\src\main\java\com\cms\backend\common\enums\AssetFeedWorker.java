package com.cms.backend.common.enums;

public enum AssetFeedWorker {
    CMS("CMS"),
    CMS_GRACENOTE("CMS_GRACENOTE"),
    TVPLUS_DELTA_GRACENOTE("TVPLUS_DELTA_GRACENOTE"),
    TVPLUS_DELTA("TVPLUS_DELTA");
    public final String value;

    AssetFeedWorker(String value) {
        this.value = value;
    }
}
