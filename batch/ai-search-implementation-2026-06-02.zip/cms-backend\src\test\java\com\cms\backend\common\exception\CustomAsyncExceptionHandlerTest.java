package com.cms.backend.common.exception;

import static org.mockito.Mockito.*;

import com.cms.backend.common.util.NotificationUtil;
import java.lang.reflect.Method;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class CustomAsyncExceptionHandlerTest {

    private CustomAsyncExceptionHandler customAsyncExceptionHandler;

    @Mock
    private NotificationUtil notificationUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        customAsyncExceptionHandler = new CustomAsyncExceptionHandler(notificationUtil);
    }

    @Test
    void testHandleUncaughtException() throws NoSuchMethodException {
        // Arrange
        Exception testException = new Exception("Test exception");
        Method testMethod = String.class.getMethod("toString");
        Object[] params = {"param1", "param2"};

        // Act
        customAsyncExceptionHandler.handleUncaughtException(testException, testMethod, params);

        // Assert
        verify(notificationUtil).sendErrorMail(any(Exception.class), eq("Async Call Error"),
            eq("ASYNC_ERROR"), eq("CMS-ADMIN"));
    }

    
}
