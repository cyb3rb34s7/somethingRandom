import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  HostListener,
  inject,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../../models/assets-columns-filters-model';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { StateStoreService } from '../../../services/store/state-store.service';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SimpleMatSelectComponent } from './simple-mat-select/simple-mat-select.component';
import { AssetService } from '../../../services/asset.service';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import {
  AiResolvedPayload,
  AiSearchContext,
  AiSearchResult,
} from '../../../models/ai-search-model';

const searchFields = ['contentId', 'mainTitle', 'showTitle', 'seasonTitle'];
@Component({
    selector: 'app-asset-search',
    imports: [
        CommonModule,
        SimpleMatSelectComponent,
        AppMatSimpleSearchComponent,
        MatButtonModule,
        MatTooltipModule,
    ],
    templateUrl: './asset-search.component.html',
    styleUrl: './asset-search.component.scss'
})
export class AssetSearchComponent implements OnInit {
  private destroy = inject(DestroyRef);

  filterDisplayTextList: string[] = [];

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  currentCategory: string;

  currentSearchString: string;

  aiLoading = false;

  @ViewChild(AppMatSimpleSearchComponent)
  matSearch: AppMatSimpleSearchComponent;

  @ViewChild(SimpleMatSelectComponent)
  matSelect: SimpleMatSelectComponent;

  constructor(
    private storeService: StateStoreService,
    private assetService: AssetService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit(): void {
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        this.columnsAndFilterData = obj;
        this.filterDisplayTextList = [];
        searchFields.forEach((key) => {
          const objFilter = this.columnsAndFilterData.filters.find(
            (f) => f.key === key
          );
          if (objFilter) {
            this.filterDisplayTextList.push(objFilter.displayText);
          }
        });

        const last_search = sessionStorage.getItem('asset-search');
        if (last_search) {
          const objLastSearch = JSON.parse(last_search);
          this.currentCategory = objLastSearch.category;
          if (this.checkReset(objLastSearch.text)) {
            setTimeout(() => {
              this.matSearch.searchFormControl.setValue(objLastSearch.text);
            }, 0);
          } else {
            this.clearSearch();
          }
        } else {
          this.currentCategory = this.currentCategory
            ? this.currentCategory
            : this.filterDisplayTextList[0];
        }
      });
  }

  checkReset(text: string) {
    const objFilter = this.columnsAndFilterData.filters.find(
      (f) => f.displayText === this.currentCategory
    );
    if (objFilter) {
      return JSON.stringify(objFilter.selected) === JSON.stringify([text]);
    }
    return true;
  }

  handleSearchStringChange(newSearchString: string): void {
    this.currentSearchString = newSearchString;
  }

  onCategoryChange() {
    const last_search = sessionStorage.getItem('asset-search');

    if (
      this.currentSearchString &&
      this.currentSearchString.trim() &&
      last_search
    ) {
      const objLastSearch = JSON.parse(last_search);
      if (objLastSearch.category !== this.currentCategory) {
        console.log('onCategoryChange');
        this.handleSearch();
      }

      //
    }
  }

  handleSearch(): void {
    const objFilter = this.columnsAndFilterData.filters.find(
      (f) => f.displayText === this.currentCategory
    );
    if (objFilter) {
      const last_search = sessionStorage.getItem('asset-search');
      if (last_search) {
        const objLastSearch = JSON.parse(last_search);
        const prevFilter = this.columnsAndFilterData.filters.find(
          (f) => f.displayText === objLastSearch.category
        );
        if (prevFilter) {
          prevFilter.selected = [];
        }
      }

      objFilter.selected = [this.currentSearchString];
      this.columnsAndFilterData.filterChanged = true;

      sessionStorage.setItem(
        'asset-search',
        JSON.stringify({
          category: this.currentCategory,
          text: this.currentSearchString,
        })
      );
      this.storeService.setStoreState(
        STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
        this.columnsAndFilterData
      );
    }
  }

  cancelSearch() {
    const last_search = sessionStorage.getItem('asset-search');
    if (last_search) {
      const objLastSearch = JSON.parse(last_search);
      const objFilter = this.columnsAndFilterData.filters.find(
        (f) => f.displayText === objLastSearch.category
      );
      if (objFilter) {
        objFilter.selected = [];
        this.clearSearch();
        this.columnsAndFilterData.filterChanged = true;
        this.storeService.setStoreState(
          STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
          this.columnsAndFilterData
        );
      }
    }
  }

  clearSearch() {
    sessionStorage.removeItem('asset-search');
    this.matSearch.searchFormControl.setValue(null);
    this.currentSearchString = '';
  }

  /**
   * Treats the current search box text as a natural-language query, resolves it
   * via the backend AI-search service into a structured filter payload, applies
   * those filters to the shared filter state, and lets the existing pipeline
   * reload the asset list. Errors are surfaced as toasts.
   */
  runAiSearch(): void {
    const query = (this.currentSearchString ?? '').trim();
    if (!query || this.aiLoading) {
      return;
    }
    this.aiLoading = true;

    const context: AiSearchContext = {
      countries: this.getFilterValues('countryCode'),
      providers: this.getFilterValues('tiName'),
    };

    this.assetService
      .resolveAiSearch(query, context)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (result: AiSearchResult) => {
          this.aiLoading = false;
          if (result?.status === 'resolved' && result.payload) {
            this.applyAiPayload(result.payload);
            this.toastr.success(result.humanSummary || 'Showing AI results');
          } else {
            this.toastr.error(
              result?.message ||
                'Could not understand that query. Please rephrase.'
            );
          }
        },
        error: () => {
          this.aiLoading = false;
          this.toastr.error('AI search failed. Please try again.');
        },
      });
  }

  private getFilterValues(key: string): string[] {
    const objFilter = this.columnsAndFilterData?.filters?.find(
      (f: Filter) => f.key === key
    );
    return objFilter?.values ? [...objFilter.values] : [];
  }

  private applyAiPayload(payload: AiResolvedPayload): void {
    // Clear all current filter selections, then apply the AI-resolved set so the
    // grid reflects exactly what the query resolved to.
    this.columnsAndFilterData.filters.forEach((f: Filter) => {
      f.selected = [];
    });
    (payload.filters || []).forEach((af) => {
      const target = this.columnsAndFilterData.filters.find(
        (f: Filter) => f.key === af.key
      );
      if (target) {
        target.selected = [...af.values];
      }
    });

    // The quick-search box no longer reflects the active (AI) filters — clear it.
    sessionStorage.removeItem('asset-search');
    this.columnsAndFilterData.filterChanged = true;
    this.storeService.setStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      this.columnsAndFilterData
    );
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.handleSearch();
      // Add your logic here
    }
  }
}
