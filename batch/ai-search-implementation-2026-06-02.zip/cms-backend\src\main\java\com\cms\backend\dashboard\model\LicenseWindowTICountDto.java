package com.cms.backend.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Setter
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
public class LicenseWindowTICountDto {


    private String licenseWindow;
    private String techIntegrator;
    private String assetType;
    private int assetsCount;

    @DynamoDbAttribute("license_window")
    public String getLicenseWindow() {
        return licenseWindow;
    }

    @DynamoDbAttribute("tech_integrator")
    public String getTechIntegrator() {
        return techIntegrator;
    }

    @DynamoDbAttribute("asset_type")
    public String getAssetType() {
        return assetType;
    }

    @DynamoDbAttribute("assets_count")
    public int getAssetsCount() {
        return assetsCount;
    }
}
