package com.cms.backend.assets.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class EditValidationDto {

    private String contentId;
    private String vcCpId;
    private String countryCode;
    private String seasonId;
    private String showId;
    private String seasonNo;
    private String episodeNo;
    private String assetType;
}