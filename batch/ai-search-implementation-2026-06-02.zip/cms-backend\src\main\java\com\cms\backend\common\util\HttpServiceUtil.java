package com.cms.backend.common.util;

import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class HttpServiceUtil {

    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;

    public HttpServiceUtil(RegionEndpointService regionEndpointService,
        HttpMethodHandler httpMethodHandler) {
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
    }

    public ResponseDto makeApiCall(String endpoint, T requestBody, Class<?> responseClass,
        String method) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + endpoint;
            HttpEntity<T> httpEntity = new HttpEntity<>(requestBody);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, method, httpEntity, responseClass);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("API call failed for endpoint {}: {}", endpoint, e.getMessage());
            throw new AssetApiFailureException("API call failed: " + e.getMessage());
        }
    }

    // Overloaded method for GET requests without body
    public ResponseDto makeApiCall(String endpoint, Class<?> responseClass, String method) {
        try {
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + endpoint;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, method, null, responseClass);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("API call failed for endpoint {}: {}", endpoint, e.getMessage());
            throw new AssetApiFailureException("API call failed: " + e.getMessage());
        }
    }
}
