package com.cms.backend.common.configuration;


import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.io.SocketConfig;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@Slf4j
public class RestTemplateConfig {

    @Value("${connectTimeOut}")
    Long connectTimeOut;
    @Value("${readTimeOut}")
    Long readTimeOut;

    @Value("${MAX_TOTAL_CONNECTIONS:20}")
    private Integer maxTotalConnections;
    @Value("${MAX_CONNECTIONS_PER_ROUTE:10}")
    private Integer maxConnectionsPerRoute;


    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder,
        TraceIdRestTemplateInterceptor traceIdRestTemplateInterceptor) {
        // Connect timeout
        ConnectionConfig connectionConfig = ConnectionConfig.custom()
            .setConnectTimeout(Timeout.ofMilliseconds(connectTimeOut))
            .build();

        // Socket timeout
        SocketConfig socketConfig = SocketConfig.custom()
            .setSoTimeout(Timeout.ofMilliseconds(readTimeOut))
            .build();

        // Connection request timeout
        RequestConfig requestConfig = RequestConfig.custom()
            .setConnectionRequestTimeout(Timeout.ofMilliseconds(connectTimeOut))
            .build();

        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setDefaultSocketConfig(socketConfig);
        connectionManager.setMaxTotal(maxTotalConnections); // Maximum total connections
        connectionManager.setDefaultMaxPerRoute(
            maxConnectionsPerRoute);// Maximum connections per route
        connectionManager.setDefaultConnectionConfig(connectionConfig);

        HttpClient httpClient = HttpClientBuilder.create()
            .setConnectionManager(connectionManager)
            .setDefaultRequestConfig(requestConfig)
            .evictIdleConnections(Timeout.ofSeconds(30)) // Evict idle connections after 30 seconds
            .evictExpiredConnections() // Evict expired connections
            .build();
        log.info("http client created={}", httpClient);

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
            httpClient);

        return restTemplateBuilder.requestFactory(() -> requestFactory)
            .additionalInterceptors(traceIdRestTemplateInterceptor)
            .build();

    }


}
