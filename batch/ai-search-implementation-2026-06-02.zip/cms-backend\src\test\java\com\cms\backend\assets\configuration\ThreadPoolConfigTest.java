package com.cms.backend.assets.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

class ThreadPoolConfigTest {

    @Test
    void testExportTaskExecutor() {
        ThreadPoolConfig threadPoolConfig = new ThreadPoolConfig();
        ThreadPoolTaskExecutor executor = threadPoolConfig.exportTaskExecutor();
        
        assertNotNull(executor);
        assertEquals(5, executor.getCorePoolSize());
        assertEquals(5, executor.getMaxPoolSize());
        assertEquals("ExportAsset-", executor.getThreadNamePrefix());
    }
}
