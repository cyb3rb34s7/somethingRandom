package com.cms.backend.assets.aisearch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FilterKey {

    private String key;
    private String type;            // filter | search | dateRange
    private String displayText;
    private List<String> values = List.of();
    private List<String> aliases = List.of();
    private String description;
    private String notes;
    private boolean dynamicValues;
}
