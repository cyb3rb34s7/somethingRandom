package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetHistoryChangesDtoTest.class)
class AssetHistoryChangesDtoTest {

    @Test
    void testAssetHistoryChangesDto() {
        // Normal value input case test
        String assetId = "12345";
        String oldStatus = "Inactive";
        String newStatus = "Active";
        String masterStatus = "Pending";

        AssetHistoryChangesDto dto = AssetHistoryChangesDto.builder()
            .assetId(assetId)
            .oldStatus(oldStatus)
            .newStatus(newStatus)
            .masterStatus(masterStatus)
            .build();

        assertEquals(assetId, dto.getAssetId());
        assertEquals(oldStatus, dto.getOldStatus());
        assertEquals(newStatus, dto.getNewStatus());
        assertEquals(masterStatus, dto.getMasterStatus());
    }
}