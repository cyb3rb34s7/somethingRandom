package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;

class AssetListKeyDtoTest {

    @Test
    void testNormalValue() {
        // Arrange
        String contentId = "12345";
        String countryCode = "KR";
        String vcCpId = "67890";

        // Act
        AssetKeyDto dto = new AssetKeyDto();
        dto.setContentId(contentId);
        dto.setCountryCode(countryCode);
        dto.setVcCpId(vcCpId);

        AssetListKeyDto assetListKeyDto = new AssetListKeyDto();
        assetListKeyDto.setAssetList(List.of(dto));

        // Act
        List<AssetKeyDto> result = assetListKeyDto.getAssetList();

        // Assert
        assertEquals(List.of(dto), result);
    }
}
