package com.cms.backend.dashboard.model;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardFilterBodyDto {

    private String date;
    private List<String> countries;
}
