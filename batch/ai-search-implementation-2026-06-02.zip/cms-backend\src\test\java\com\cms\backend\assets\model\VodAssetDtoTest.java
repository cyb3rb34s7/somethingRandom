package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = VodAssetDtoTest.class)
class VodAssetDtoTest {

    @Test
    void testVodAssetDto() {
        VodAssetDto vodAssetDto = new VodAssetDto();
        vodAssetDto.setContentId("1234567890");
        vodAssetDto.setCountryCode("US");
        vodAssetDto.setType("Movie");
        vodAssetDto.setMainTitle("Test Movie");
        vodAssetDto.setShortTitle("Test");
        vodAssetDto.setRunningTime(120);
        vodAssetDto.setGenres("Action, Adventure");
        vodAssetDto.setDirector("John Doe");
        vodAssetDto.setStarring("Jane Doe");
        vodAssetDto.setRatings("PG-13");
        vodAssetDto.setDescription("This is a test movie.");
        vodAssetDto.setEpisodeNo(1);
        vodAssetDto.setSeasonNo(1);
        vodAssetDto.setSeasonId("season1");
        vodAssetDto.setStreamUri("http://test.stream");
        vodAssetDto.setImageLandscape("http://test.image.landscape");
        vodAssetDto.setExpiryDate("2023-12-31");
        vodAssetDto.setShowId("show1");
        vodAssetDto.setReleaseDate("2022-01-01");
        vodAssetDto.setRegDate(new Date());
        vodAssetDto.setUpdateDate(new Date());
        vodAssetDto.setRegrId("user1");
        vodAssetDto.setCrctrId("user2");
        vodAssetDto.setImagePortrait("http://test.image.portrait");
        vodAssetDto.setVcCpId("cp1");
        vodAssetDto.setImageCircle("http://test.image.circle");
        vodAssetDto.setWebVttUrl("http://test.web.vtt");
        vodAssetDto.setThumbnailUrl("http://test.thumbnail");
        vodAssetDto.setAudioLang("en");
        vodAssetDto.setSubtitleLang("en");
        vodAssetDto.setDeeplinkPayload("payload");
        vodAssetDto.setAudioCode("audioCode");
        vodAssetDto.setSubtitleCode("subtitleCode");
        vodAssetDto.setQuality("HD");
        vodAssetDto.setVcSvcId("svc1");
        vodAssetDto.setDeeplinkId("deeplink1");
        vodAssetDto.setFileName("test.mp4");
        vodAssetDto.setDataplusYn("Y");
        vodAssetDto.setNonAdStreamUri("http://test.nonad.stream");
        vodAssetDto.setImageLandscapeOriginal("http://test.image.landscape.original");
        vodAssetDto.setImagePortraitOriginal("http://test.image.portrait.original");
        vodAssetDto.setImageCircleOriginal("http://test.image.circle.original");
        vodAssetDto.setProcessedImageUrl("http://test.processed.image");
        vodAssetDto.setArtist("Artist Name");
        vodAssetDto.setAvailableStarting("2022-01-01");
        vodAssetDto.setStatus("Active");

        assertEquals("1234567890", vodAssetDto.getContentId());
        assertEquals("US", vodAssetDto.getCountryCode());
        assertEquals("Movie", vodAssetDto.getType());
        assertEquals("Test Movie", vodAssetDto.getMainTitle());
        assertEquals("Test", vodAssetDto.getShortTitle());
        assertEquals(120, vodAssetDto.getRunningTime());
        assertEquals("Action, Adventure", vodAssetDto.getGenres());
    }
}
