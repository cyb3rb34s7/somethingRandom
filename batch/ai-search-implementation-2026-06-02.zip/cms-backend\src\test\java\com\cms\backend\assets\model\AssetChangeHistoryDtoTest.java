package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetChangeHistoryDtoTest.class)
class AssetChangeHistoryDtoTest {

    @Test
    void testNormalValueInput() {
        // Arrange
        MetadataHistoryRequestDto metadataHistory = mock(MetadataHistoryRequestDto.class);
        LicenseHistoryRequestDto licenseHistory = mock(LicenseHistoryRequestDto.class);
        EventHistoryRequestDto eventHistoryRequestDto = mock(EventHistoryRequestDto.class);
        StatusHistoryRequestDto statusHistory = mock(StatusHistoryRequestDto.class);

        // Act
        AssetChangeHistoryDto assetChangeHistoryDto = new AssetChangeHistoryDto(metadataHistory,
            licenseHistory, statusHistory,eventHistoryRequestDto);

        // Assert
        assertNotNull(assetChangeHistoryDto.getAssetMetadataHistory());
        assertNotNull(assetChangeHistoryDto.getAssetLicenseHistory());
        assertNotNull(assetChangeHistoryDto.getAssetStatusHistory());
        assertNotNull(assetChangeHistoryDto.getEventHistory());
    }
}