package com.cms.backend.dashboard.controller;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cms.backend.dashboard.model.DashboardCountDto;
import com.cms.backend.dashboard.model.DashboardFilterBodyDto;
import com.cms.backend.dashboard.service.DashboardService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = DashboardControllerTest.class)
class DashboardControllerTest {

    @Mock
    DashboardService dashboardService;

    @InjectMocks
    DashboardController dashboardController;

    @Test
    void testGetDashboardData() {
        List<DashboardCountDto> dashboardCountDtos = List.of(DashboardCountDto.builder().build());
        when(dashboardService.getDashboardData("")).thenReturn(dashboardCountDtos);
        assertDoesNotThrow(() -> {
            dashboardController.getDashboardData("");
        });
    }

    @Test
    void testPostDashboardData() {
        List<DashboardCountDto> dashboardCountDtos = List.of(DashboardCountDto.builder().build());
        when(dashboardService.getDashboardDataByCountry(
            any(DashboardFilterBodyDto.class))).thenReturn(dashboardCountDtos);
        when(dashboardService.getLastRunTime()).thenReturn("aa");
        assertDoesNotThrow(() -> {
            dashboardController.postDashboardData(any(DashboardFilterBodyDto.class));
        });
    }
}
