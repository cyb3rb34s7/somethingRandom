package com.cms.backend.common.util;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.ResponseDto;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@SpringBootTest(classes = HttpMethodHandlerTest.class)
class HttpMethodHandlerTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private HttpMethodHandler httpMethodHandler;

    @Test
    void testHandleHttpExchange() {
        // Mocking the response from restTemplate.exchange()
        ResponseEntity<ResponseDto> expectedResponse = new ResponseEntity<>(new ResponseDto(),
            HttpStatus.OK);
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class),
            eq(ResponseDto.class)))
            .thenReturn(expectedResponse);

        // Normal value input case test
        String endPoint = "https://example.com/api";
        String httpMethod = "GET";
        HttpEntity<?> httpEntity = new HttpEntity<>(new HttpHeaders());
        Class<?> className = ResponseDto.class;

        ResponseEntity<ResponseDto> actualResponse = httpMethodHandler.handleHttpExchange(endPoint,
            httpMethod, httpEntity, className);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testHandleHttpExchangeWithException() {
        // Mocking the exception from restTemplate.exchange()
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class),
            any(Class.class)))
            .thenThrow(new RestClientException("Network failure"));

        // Normal value input case test
        String endPoint = "https://example.com/api";
        String httpMethod = "POST";
        HttpEntity<?> httpEntity = new HttpEntity<>(new HttpHeaders());
        Class<?> className = ResponseDto.class;

        assertThrows(AssetApiFailureException.class,
            () -> httpMethodHandler.handleHttpExchange(endPoint, httpMethod, httpEntity,
                className));

    }


    @Test
    void readCloudFrontUrlTest() {
        when(restTemplate.getForObject("testUrl", String.class)).thenReturn("testOutput");
        assertDoesNotThrow(() -> httpMethodHandler.readCloudFrontUrl("testUrl"));
    }

}