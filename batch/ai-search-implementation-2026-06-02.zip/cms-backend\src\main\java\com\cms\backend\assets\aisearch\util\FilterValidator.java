package com.cms.backend.assets.aisearch.util;

import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.llm.LlmFilter;
import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import com.cms.backend.assets.model.FilterDto;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class FilterValidator {

    private static final Set<String> BLOCKED_COLUMNS =
            new HashSet<>(List.of("DROP", "DELETE", "INSERT", "UPDATE", "--", ";"));

    private final FilterSchemaProvider schemaProvider;

    public List<FilterDto> validateAndSanitize(List<LlmFilter> filters, Map<String, List<String>> dynamicEnums) {
        List<FilterDto> sanitized = new ArrayList<>();
        if (filters == null) {
            return sanitized;
        }
        for (LlmFilter op : filters) {
            FilterKey schema = schemaProvider.getByKey(op.getKey());
            if (schema == null) {
                log.warn("Dropping unknown filter key: {}", op.getKey());
                continue;
            }
            String type = schema.getType(); // always trust schema type

            List<String> values = op.getValues() == null ? List.of() : op.getValues();
            List<String> allowed = effectiveAllowedValues(schema, dynamicEnums);

            if (!allowed.isEmpty()) {
                Map<String, String> byLower = new LinkedHashMap<>();
                for (String v : allowed) {
                    byLower.put(v.toLowerCase(), v);
                }
                List<String> resolved = new ArrayList<>();
                for (String v : values) {
                    String canonical = byLower.get(v.toLowerCase());
                    if (canonical != null) {
                        resolved.add(canonical);
                    } else if (schema.isDynamicValues()) {
                        resolved.add(v); // dynamic list may be partial — keep
                    } else {
                        log.warn("Dropping invalid value '{}' for key '{}'", v, op.getKey());
                    }
                }
                if (resolved.isEmpty()) {
                    log.warn("All values invalid for key '{}'. Dropping filter.", op.getKey());
                    continue;
                }
                values = resolved;
            }

            sanitized.add(FilterDto.builder()
                    .key(schema.getKey())
                    .type(type)
                    .displayText(schema.getDisplayText())
                    .values(values)
                    .build());
        }
        return sanitized;
    }

    public List<String> validateColumns(List<String> columns) {
        List<String> out = new ArrayList<>();
        if (columns == null) {
            return out;
        }
        for (String c : columns) {
            if (c != null && !c.isBlank() && !BLOCKED_COLUMNS.contains(c.toUpperCase())) {
                out.add(c);
            }
        }
        return out;
    }

    private List<String> effectiveAllowedValues(FilterKey schema, Map<String, List<String>> dynamicEnums) {
        if (schema.isDynamicValues()) {
            List<String> injected = dynamicEnums == null ? null : dynamicEnums.get(schema.getKey());
            return injected == null ? List.of() : injected;
        }
        return schema.getValues() == null ? List.of() : schema.getValues();
    }
}
