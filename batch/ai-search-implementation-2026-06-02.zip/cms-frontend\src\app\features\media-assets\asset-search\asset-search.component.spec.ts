import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';

import { AssetSearchComponent } from './asset-search.component';
import { StateStoreService } from '../../../services/store/state-store.service';
import { AssetService } from '../../../services/asset.service';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { STORE_CONSTS } from '../../../constants/store-consts';

function buildMockData() {
  return {
    filters: [
      { key: 'contentId', displayText: 'Program ID', selected: [], values: [] },
      { key: 'mainTitle', displayText: 'Program Title', selected: [], values: [] },
      { key: 'showTitle', displayText: 'Show Title', selected: [], values: [] },
      { key: 'seasonTitle', displayText: 'Season Title', selected: [], values: [] },
      { key: 'status', displayText: 'Media Status', selected: [], values: ['Released', 'QC Fail'] },
      { key: 'type', displayText: 'Program Type', selected: [], values: ['MOVIE', 'EPISODE'] },
      { key: 'countryCode', displayText: 'Country', selected: [], values: ['IN', 'US'] },
      { key: 'tiName', displayText: 'Tech Integrator', selected: [], values: ['Sony'] },
    ],
    filterChanged: false,
  } as any;
}

describe('AssetSearchComponent', () => {
  let component: AssetSearchComponent;
  let fixture: ComponentFixture<AssetSearchComponent>;
  let assetServiceSpy: jasmine.SpyObj<AssetService>;
  let toastrSpy: jasmine.SpyObj<CustomToastrService>;
  let storeSpy: any;
  let mockData: any;

  beforeEach(async () => {
    sessionStorage.clear();
    mockData = buildMockData();

    assetServiceSpy = jasmine.createSpyObj<AssetService>('AssetService', ['resolveAiSearch']);
    toastrSpy = jasmine.createSpyObj<CustomToastrService>('CustomToastrService', ['success', 'error', 'warn']);
    storeSpy = {
      stateStore: { [STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES]: of(mockData) },
      setStoreState: jasmine.createSpy('setStoreState'),
    };

    await TestBed.configureTestingModule({
      imports: [AssetSearchComponent],
      providers: [
        { provide: StateStoreService, useValue: storeSpy },
        { provide: AssetService, useValue: assetServiceSpy },
        { provide: CustomToastrService, useValue: toastrSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AssetSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('does nothing when the query is blank', () => {
    component.currentSearchString = '   ';
    component.runAiSearch();
    expect(assetServiceSpy.resolveAiSearch).not.toHaveBeenCalled();
  });

  it('resolves an AI query, applies filters, and pushes to the store', () => {
    assetServiceSpy.resolveAiSearch.and.returnValue(
      of({
        status: 'resolved',
        payload: {
          columns: [],
          filters: [
            { key: 'type', type: 'filter', values: ['MOVIE'] },
            { key: 'status', type: 'filter', values: ['Released'] },
          ],
          pagination: { limit: 100, offset: 0 },
        },
        humanSummary: 'Released movies',
      })
    );

    component.currentSearchString = 'released movies';
    component.runAiSearch();

    // context derived from the available filter option lists
    const ctx = assetServiceSpy.resolveAiSearch.calls.mostRecent().args[1];
    expect(ctx.countries).toEqual(['IN', 'US']);
    expect(ctx.providers).toEqual(['Sony']);

    const typeFilter = mockData.filters.find((f: any) => f.key === 'type');
    const statusFilter = mockData.filters.find((f: any) => f.key === 'status');
    expect(typeFilter.selected).toEqual(['MOVIE']);
    expect(statusFilter.selected).toEqual(['Released']);
    expect(mockData.filterChanged).toBeTrue();
    expect(storeSpy.setStoreState).toHaveBeenCalledWith(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      mockData
    );
    expect(toastrSpy.success).toHaveBeenCalledWith('Released movies');
    expect(component.aiLoading).toBeFalse();
  });

  it('shows an error toast when the backend returns status=error', () => {
    assetServiceSpy.resolveAiSearch.and.returnValue(
      of({ status: 'error', message: 'Not a content query.' })
    );

    component.currentSearchString = 'what is the weather';
    component.runAiSearch();

    expect(toastrSpy.error).toHaveBeenCalledWith('Not a content query.');
    expect(storeSpy.setStoreState).not.toHaveBeenCalled();
    expect(component.aiLoading).toBeFalse();
  });

  it('shows an error toast when the request fails', () => {
    assetServiceSpy.resolveAiSearch.and.returnValue(throwError(() => new Error('boom')));

    component.currentSearchString = 'released movies';
    component.runAiSearch();

    expect(toastrSpy.error).toHaveBeenCalledWith('AI search failed. Please try again.');
    expect(component.aiLoading).toBeFalse();
  });
});
