package com.cms.backend.assets.aisearch.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.aisearch.exception.SchemaUnavailableException;
import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.FilterSchema;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FilterSchemaProviderTest {

    private FilterSchemaProvider provider;

    @BeforeEach
    void setUp() {
        provider = new FilterSchemaProvider(new ObjectMapper());
        provider.init();
    }

    @Test
    void loadsSchemaFromClasspathResource() {
        FilterSchema schema = provider.getSchema();
        assertThat(schema.getFilters()).isNotEmpty();
        assertThat(schema.getSemanticDateTokens()).contains("LAST_7_DAYS");
        assertThat(schema.getDefaultColumnsByType()).containsKey("EPISODE");
    }

    @Test
    void findsStatusKeyWithRealEnumValues() {
        FilterKey status = provider.getByKey("status");
        assertThat(status).isNotNull();
        assertThat(status.getType()).isEqualTo("filter");
        assertThat(status.getValues()).contains("Ready for QC", "Released");
    }

    @Test
    void hasNoTabPresetKeys() {
        assertThat(provider.getByKey("allStatus")).isNull();
        assertThat(provider.getByKey("qcStatus")).isNull();
    }

    @Test
    void getSchemaReloadsWhenCacheNull() {
        // Exercise the lazy reload branch of getSchema() (cached == null).
        FilterSchemaProvider fresh = new FilterSchemaProvider(new ObjectMapper());
        // init() not called, so cached is null.
        FilterSchema schema = fresh.getSchema();
        assertThat(schema).isNotNull();
        assertThat(schema.getFilters()).isNotEmpty();
        // Second call returns the now-cached instance.
        assertThat(fresh.getSchema()).isSameAs(schema);
    }

    @Test
    void throwsSchemaUnavailableWhenObjectMapperFails() throws IOException {
        ObjectMapper failingMapper = mock(ObjectMapper.class);
        when(failingMapper.readValue(any(java.io.InputStream.class), any(Class.class)))
                .thenThrow(new IOException("boom"));
        FilterSchemaProvider failing = new FilterSchemaProvider(failingMapper);
        assertThatThrownBy(failing::init)
                .isInstanceOf(SchemaUnavailableException.class)
                .hasMessageContaining("Failed to load AI-search schema");
    }
}
