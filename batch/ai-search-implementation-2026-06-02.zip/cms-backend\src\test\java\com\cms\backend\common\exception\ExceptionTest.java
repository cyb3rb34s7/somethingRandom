package com.cms.backend.common.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ExceptionTest {

    @Test
    void testAssetApiFailureException() {
        AssetApiFailureException exception = new AssetApiFailureException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testCountryNotAssignedException() {
        CountryNotAssignedException exception = new CountryNotAssignedException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testCustomException() {
        CustomException exception = new CustomException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testDatabaseException() {
        DatabaseException exception = new DatabaseException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testDataNotFoundException() {
        DataNotFoundException exception = new DataNotFoundException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testForbiddenException() {
        ForbiddenException exception = new ForbiddenException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testIMSException() {
        IMSException exception = new IMSException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testIMSTokenExpiredException() {
        IMSTokenExpiredException exception = new IMSTokenExpiredException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testInvalidInputDataException() {
        InvalidInputDataException exception = new InvalidInputDataException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testInvalidStatusException() {
        InvalidStatusException exception = new InvalidStatusException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testModifyingRoleOfSelfException() {
        ModifyingRoleOfSelfException exception = new ModifyingRoleOfSelfException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testRolesInUseException() {
        RolesInUseException exception = new RolesInUseException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testUnauthorizedException() {
        UnauthorizedException exception = new UnauthorizedException("Test message");
        assertEquals("Test message", exception.getMessage());
    }

    @Test
    void testUserNotActiveException() {
        UserNotActiveException exception = new UserNotActiveException("Test message");
        assertEquals("Test message", exception.getMessage());
    }
}
