package com.cms.backend.interceptor;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.SecurityUser;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.HashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AuthUserHeaderFilterTest {

    @InjectMocks
    private AuthUserHeaderFilter authUserHeaderFilter;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        AuthenticatedUser.clearContext();
    }

    @Test
    void testDoFilterInternalWithAuthUserHeader() throws Exception {
        // Arrange
        SecurityUser user = new SecurityUser("userId", "US", "userName", "sessionId", new HashMap<>());
        String userJson = objectMapper.writeValueAsString(user);
        String allUsersJson = "{\"user1\":\"role1\"}";

        when(request.getHeader("X-AUTH-USER")).thenReturn(userJson);
        when(request.getHeader("X-ALL-USERS")).thenReturn(allUsersJson);

        // Act
        authUserHeaderFilter.doFilterInternal(request, response, filterChain);

        // Assert
        verify(filterChain).doFilter(request, response);
    }

    @Test
    void testDoFilterInternalWithoutAuthUserHeader() throws Exception {
        // Arrange
        when(request.getHeader("X-AUTH-USER")).thenReturn(null);

        // Act
        authUserHeaderFilter.doFilterInternal(request, response, filterChain);

        // Assert
        verify(filterChain).doFilter(request, response);
    }

    @Test
    void testDoFilterInternalWithAuthUserHeaderButNoAllUsers() throws Exception {
        // Arrange
        SecurityUser user = new SecurityUser("userId", "US", "userName", "sessionId", new HashMap<>());
        String userJson = objectMapper.writeValueAsString(user);

        when(request.getHeader("X-AUTH-USER")).thenReturn(userJson);
        when(request.getHeader("X-ALL-USERS")).thenReturn(null);

        // Act
        authUserHeaderFilter.doFilterInternal(request, response, filterChain);

        // Assert
        verify(filterChain).doFilter(request, response);
    }

    @Test
    void testConstructor() {
        // Act
        AuthUserHeaderFilter filter = new AuthUserHeaderFilter();

        // Assert
        assertNotNull(filter);
    }
}