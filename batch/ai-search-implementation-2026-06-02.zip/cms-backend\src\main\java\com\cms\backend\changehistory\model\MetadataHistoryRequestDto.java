package com.cms.backend.changehistory.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MetadataHistoryRequestDto {

    private String updatedBy;
    private String assetId;
    private String changes;
    private String countryCode;
    private String vcCpId;


}