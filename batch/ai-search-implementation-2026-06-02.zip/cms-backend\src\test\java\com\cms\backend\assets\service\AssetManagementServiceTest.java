package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.configuration.S3ClientConfig;
import com.cms.backend.assets.model.AssetChangeHistoryDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetUpdateRequestBodyDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.StatusGetDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.model.VodAssetUpdateDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

@ExtendWith(MockitoExtension.class)
class AssetManagementServiceTest {

    @InjectMocks
    private AssetManagementService assetManagementService;

    @Mock
    private RegionEndpointService regionEndpointService;

    @Mock
    private HttpMethodHandler httpMethodHandler;

    @Mock
    private S3ClientConfig s3ClientConfig;

    @Mock
    private AssetAsyncService assetAsyncService;

    @Mock
    private ValidationAsset validationAsset;

    @Mock
    private AssetHelperService assetHelperService;

    @Mock
    private AssetSyncerService assetSyncerService;

    @BeforeEach
    void setUp() {
        lenient().when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
        lenient().when(regionEndpointService.getHistoryAPIEndpoint())
            .thenReturn("http://test:8080");
        lenient().when(regionEndpointService.getSQSEndpoint()).thenReturn("http://test:8080");
        lenient().when(regionEndpointService.getOpenAPIEndpointPRD())
            .thenReturn("http://test:8080");
        lenient().when(regionEndpointService.getCloudFrontUrlCms()).thenReturn("http://test:8080");

        ReflectionTestUtils.setField(assetManagementService, "tvpBucketName", "test-bucket");
        ReflectionTestUtils.setField(assetManagementService, "smfSpecFilename",
            "test-smf-filename.json");
    }

    // ==================== bulkRevokeHierarchy Tests ====================

    @Test
    void bulkRevokeHierarchy_P() {
        // Arrange
        List<AssetKeyDto> assetKeyDtoList = new ArrayList<>();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.bulkRevokeHierarchy(assetKeyDtoList));
    }

    @Test
    void bulkRevokeHierarchy_N() {
        // Arrange
        List<AssetKeyDto> assetKeyDtoList = new ArrayList<>();
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.bulkRevokeHierarchy(assetKeyDtoList));
    }

    // ==================== getStreamUrls Tests ====================

    @Test
    void getStreamUrls_P() {
        // Arrange
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.getStreamUrls("test", "test", "test"));
    }

    @Test
    void getStreamUrls_N() {
        // Arrange
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.getStreamUrls("test", "test", "test"));
    }

    // ==================== getCpData Tests ====================

    @Test
    void getCpData_P() {
        // Arrange
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.getCpData("test", "test", "test"));
    }

    @Test
    void getCpData_N() {
        // Arrange
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.getCpData("test", "test", "test"));
    }

    // ==================== getGracenoteData Tests ====================

    @Test
    void getGracenoteData_P() {
        // Arrange
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.getGracenoteData("test", "test", "test"));
    }

    @Test
    void getGracenoteData_N() {
        // Arrange
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.getGracenoteData("test", "test", "test"));
    }

    // ==================== updateCPData Tests ====================

    @Test
    void updateCPData_P() {
        // Arrange
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("aa").idProvider("aa").idType("aa").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa")
            .externalProvider(List.of(externalProviderDto))
            .isSyncBlocked(false).feedWorker("cms").build();

        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(
            ResponseDto.builder().rsp(BaseResponseDto.builder().build()).build(), HttpStatus.OK);
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.updateCPData(vodAssetDto));
    }

    @Test
    void updateCPData_CustomException_N() {
        // Arrange
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("test").build();
        doThrow(new CustomException("Custom error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.updateCPData(vodAssetDto));
    }

    @Test
    void updateCPData_Exception_N() {
        // Arrange
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("test").build();
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.updateCPData(vodAssetDto));
    }

    // ==================== getStaticJSON Tests ====================

    @Test
    void getStaticJSON_P() {
        // Arrange
        when(httpMethodHandler.readCloudFrontUrl(anyString())).thenReturn("test-content");

        // Act
        ResponseDto responseDto = assetManagementService.getStaticJSON("test.json");

        // Assert
        assertNotNull(responseDto);
        assertNotNull(responseDto.getRsp());
        assertNotNull(responseDto.getRsp().getPayload());
    }

    @Test
    void getStaticJSON_N() {
        // Arrange
        when(httpMethodHandler.readCloudFrontUrl(anyString())).thenThrow(
            new RuntimeException("Error"));

        // Act & Assert
        assertThrows(CustomException.class,
            () -> assetManagementService.getStaticJSON("test.json"));
    }

    // ==================== getS3File Tests ====================

    @Test
    void getS3File_P() {
        // Arrange
        byte[] mockFileContent = "FileContent".getBytes(StandardCharsets.UTF_8);
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(mockFileContent,
            HttpStatus.OK);
        lenient().when(httpMethodHandler.downloadFile(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act
        byte[] result = assetManagementService.getS3File("testFile.txt");

        // Assert
        assertNotNull(result);
    }

    // ==================== getPrdAssetView Tests ====================

    @Test
    void getPrdAssetView_P() {
        // Arrange
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.getPrdAssetView("test", "test", "test"));
    }

    @Test
    void getPrdAssetView_N() {
        // Arrange
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.getPrdAssetView("test", "test", "test"));
    }

    // ==================== getPrdAssetViewFilters Tests ====================

    @Test
    void getPrdAssetViewFilters_P() {
        // Arrange
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(responseEntity);

        // Act & Assert
        assertDoesNotThrow(() -> assetManagementService.getPrdAssetViewFilters(assetKeyDto));
    }

    @Test
    void getPrdAssetViewFilters_N() {
        // Arrange
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        doThrow(new RuntimeException("Error")).when(httpMethodHandler)
            .handleHttpExchange(anyString(), anyString(), any(), any());

        // Act & Assert
        assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.getPrdAssetViewFilters(assetKeyDto));
    }

    // ==================== getSmfFileName Tests ====================

    @Test
    void getSmfFileName_P() {
        // Act
        ResponseDto result = assetManagementService.getSmfFileName();

        // Assert
        assertNotNull(result);
        assertNotNull(result.getRsp());
        assertNotNull(result.getRsp().getPayload());

        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) result.getRsp().getPayload();
        assertNotNull(payload);
        assertTrue(payload.containsKey("name"));
        assertEquals("test-smf-filename.json", payload.get("name"));
    }

    // ==================== getFileFromS3 Tests ====================

    @Test
    void getFileFromS3_P() throws Exception {
        // Arrange
        String path = "test/path/";
        String fileName = "testFile.txt";
        byte[] fileContent = "test content".getBytes(StandardCharsets.UTF_8);

        S3Client mockS3Client = Mockito.mock(S3Client.class);
        ResponseBytes<GetObjectResponse> mockResponseBytes = Mockito.mock(ResponseBytes.class);

        when(s3ClientConfig.amazonS3()).thenReturn(mockS3Client);
        when(mockResponseBytes.asByteArray()).thenReturn(fileContent);
        when(mockS3Client.getObject(any(GetObjectRequest.class), any(ResponseTransformer.class)))
            .thenReturn(mockResponseBytes);

        // Act
        ResponseEntity<byte[]> result = assetManagementService.getFileFromS3(path, fileName);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getHeaders());
        assertNotNull(result.getBody());
    }

    @Test
    void getFileFromS3_N() throws Exception {
        // Arrange
        String path = "test/path/";
        String fileName = "testFile.txt";

        S3Client mockS3Client = Mockito.mock(S3Client.class);
        when(s3ClientConfig.amazonS3()).thenReturn(mockS3Client);
        when(mockS3Client.getObject(any(GetObjectRequest.class), any(ResponseTransformer.class)))
            .thenThrow(new RuntimeException("S3 error"));

        // Act
        ResponseEntity<byte[]> result = assetManagementService.getFileFromS3(path, fileName);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getHeaders());
        assertNull(result.getBody());
    }

    // ==================== updateVodAssetFromPortal Tests ====================

    @Test
    void updateVodAssetFromPortal_NullRequestBody_P() {
        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(null);

        // Assert
        assertNotNull(responseDto);
        assertNotNull(responseDto.getRsp());
        assertEquals(Constants.STATUS_OK, responseDto.getRsp().getStat());
        assertNotNull(responseDto.getRsp().getErr());
        assertEquals(Constants.STATUS_OK, responseDto.getRsp().getErr().getCode());
        assertEquals(Constants.UPDATE_API_ERROR, responseDto.getRsp().getErr().getMsg());
    }

    @Test
    void updateVodAssetFromPortal_NullVodAssetUpdateDto_N() {
        // Arrange
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(null).build();

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
        assertEquals(Constants.VOD_ASSET_IS_NULL, responseDto.getRsp().getErr().getMsg());
    }

    @Test
    void updateVodAssetFromPortal_NullVodAsset_N() {
        // Arrange
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(null)
            .vodCpAsset(VodAssetDto.builder().build())
            .build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
        assertEquals(Constants.VOD_ASSET_IS_NULL, responseDto.getRsp().getErr().getMsg());
    }

    @Test
    void updateVodAssetFromPortal_WithAssetChangeHistory_P() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetChangeHistoryDto assetChangeHistoryDto = AssetChangeHistoryDto.builder().build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).assetChangeHistoryDto(assetChangeHistoryDto)
            .build();

        ResponseDto expectedResponse = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();

        when(assetHelperService.getAssetStatusByAPI(any(StatusGetDto.class))).thenReturn(
            new ArrayList<>());
        doNothing().when(validationAsset).validateVodContent(any(VodAssetDto.class));
        doNothing().when(assetHelperService)
            .validateStatusForEditing(any(VodAssetDto.class), any());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
    }

    @Test
    void updateVodAssetFromPortal_WithoutAssetChangeHistory_P() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).assetChangeHistoryDto(null).build();

        ResponseDto expectedResponse = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();

        when(assetHelperService.getAssetStatusByAPI(any(StatusGetDto.class))).thenReturn(
            new ArrayList<>());
        doNothing().when(validationAsset).validateVodContent(any(VodAssetDto.class));
        doNothing().when(assetHelperService)
            .validateStatusForEditing(any(VodAssetDto.class), any());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
    }

    @Test
    void updateVodAssetFromPortal_IllegalArgumentException_N() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        doThrow(new IllegalArgumentException("Invalid argument")).when(validationAsset)
            .validateVodContent(any(VodAssetDto.class));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
            () -> assetManagementService.updateVodAssetFromPortal(requestBodyDto));
        assertEquals("Invalid argument", exception.getMessage());
    }

    @Test
    void updateVodAssetFromPortal_CustomException_N() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        doThrow(new CustomException("Custom error")).when(validationAsset)
            .validateVodContent(any(VodAssetDto.class));

        // Act & Assert
        CustomException exception = assertThrows(CustomException.class,
            () -> assetManagementService.updateVodAssetFromPortal(requestBodyDto));
        assertEquals("Custom error", exception.getMessage());
    }

    @Test
    void updateVodAssetFromPortal_GeneralException_N() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        doThrow(new RuntimeException("General error")).when(validationAsset)
            .validateVodContent(any(VodAssetDto.class));

        // Act & Assert
        AssetApiFailureException exception = assertThrows(AssetApiFailureException.class,
            () -> assetManagementService.updateVodAssetFromPortal(requestBodyDto));
        assertEquals("Error while updating asset", exception.getMessage());
    }

    @Test
    void updateVodAssetFromPortal_WithSync_P() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        List<VodAssetDto> assetStatusList = new ArrayList<>();
        VodAssetDto statusAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp")
            .isSyncBlocked(false).feedWorker("CMS").build();
        assetStatusList.add(statusAsset);

        ResponseDto expectedResponse = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();

        doNothing().when(validationAsset).validateVodContent(any(VodAssetDto.class));
        when(assetHelperService.getAssetStatusByAPI(any(StatusGetDto.class))).thenReturn(
            assetStatusList);
        doNothing().when(assetHelperService)
            .validateStatusForEditing(any(VodAssetDto.class), any());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(ResponseEntity.ok(expectedResponse));
        doNothing().when(assetSyncerService).pushMessageToSqsAsync(anyString(), any());

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
        assertEquals(Constants.STATUS_OK, responseDto.getRsp().getStat());
    }

    @Test
    void updateVodAssetFromPortal_WithSyncBlocked_P() {
        // Arrange
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp").build();
        VodAssetUpdateDto vodAssetUpdateDto = VodAssetUpdateDto.builder()
            .vodAsset(vodAsset).vodCpAsset(vodAsset).build();
        AssetUpdateRequestBodyDto requestBodyDto = AssetUpdateRequestBodyDto.builder()
            .vodAssetUpdateDto(vodAssetUpdateDto).build();

        List<VodAssetDto> assetStatusList = new ArrayList<>();
        VodAssetDto statusAsset = VodAssetDto.builder()
            .contentId("test-content").countryCode("AA").vcCpId("test-cp")
            .isSyncBlocked(true).feedWorker("CMS").build();
        assetStatusList.add(statusAsset);

        ResponseDto expectedResponse = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK).build()).build();

        doNothing().when(validationAsset).validateVodContent(any(VodAssetDto.class));
        when(assetHelperService.getAssetStatusByAPI(any(StatusGetDto.class))).thenReturn(
            assetStatusList);
        doNothing().when(assetHelperService)
            .validateStatusForEditing(any(VodAssetDto.class), any());
        lenient().when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        ResponseDto responseDto = assetManagementService.updateVodAssetFromPortal(requestBodyDto);

        // Assert
        assertNotNull(responseDto);
        assertEquals(Constants.STATUS_OK, responseDto.getRsp().getStat());
    }
}