package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.mapper.AssetMapper;
import com.cms.backend.assets.model.AssetCastDto;
import com.cms.backend.assets.model.AssetChangeHistoryDto;
import com.cms.backend.assets.model.AssetEpisodeHierarchyDto;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetRequestBodyDto;
import com.cms.backend.assets.model.AssetSingleImageUpdateDto;
import com.cms.backend.assets.model.AssetUpdateByBulkDto;
import com.cms.backend.assets.model.EditValidationDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.assets.model.LicenseWindowDto;
import com.cms.backend.assets.model.PaginationDto;
import com.cms.backend.assets.model.ParentalRatingsDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.SortDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.model.VodAssetStatusResponseDto;
import com.cms.backend.assets.util.UpdateAssetUtils;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto.AssetsChanges;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetStatus;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.exception.InvalidInputDataException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.model.SecurityUser;
import com.cms.backend.common.service.DynamoDBService;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.test.ServiceTestUtility;
import com.cms.backend.common.test.TestUtility;
import com.cms.backend.common.util.HttpMethodHandler;
import com.cms.backend.common.util.ResponseHandler;
import com.cms.backend.common.test.ExcelTestDataProvider;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource("classpath:application-test.properties")
class AssetServiceTest {

    @InjectMocks
    AssetService assetService;

    @Mock
    HttpMethodHandler httpMethodHandler;
    @Mock
    AssetMapper assetMapper;
    @Mock
    AuthenticatedUser authenticatedUser;
    @Mock
    UpdateAssetUtils updateAssetUtils;
    @Mock
    AssetSyncerService assetSyncerService;
    @Mock
    ValidationAsset validationAsset;
    @Mock
    AssetAsyncService assetAsyncService;
    @Mock
    RegionEndpointService regionEndpointService;

    @Mock
    SqsMessageService sqsMessageService;

    @Mock
    ImageUploadService imageUploadService;

    @Mock
    AssetExcelEditService assetExcelEditService;


    @Mock
    AssetHelperService assetHelperService;
    @Mock
    DynamoDBService dynamoDBService;


    @BeforeEach
    void presetDetails() {
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getSQSEndpoint()).thenReturn("http://test:8080");
        ReflectionTestUtils.setField(assetService, "batchSize", "100");
        ReflectionTestUtils.setField(assetService, "feedWorkerList", "cms");
        SecurityUser securityUser = com.cms.backend.common.test.BaseServiceAndControllerTest.createTestSecurityUser();
        Mockito.when(authenticatedUser.getUserInfo()).thenReturn(securityUser);
        HashMap<String, List<String>> map = new HashMap<>();
        map.put("EPISODE", List.of(
            "runningTime",
            "chapterTime",
            "chapterDescription",
            "streamUri",
            "quality",
            "audioLang",
            "subtitleLang",
            "drm",
            "adTag"));
    }


    static final String COUNTRY = "AA", CONTENT_ID = "cc", VCCP_ID = "vccp";


    static final String VALIDDEEPLINKPAYLOAD = """
        {"deeplink_data":{"content_type":"episodic","content_id":"Test_Rashmi_E06","ratings":"TV-Y"}}
        """;

    static final String DEEPLINKPAYLOADWITHOUTKEY = """
        {"deeplink":"content_type":"episodic","content_id":"Test_Rashmi_E06","ratings":"TV-Y"}}
        """;

    static final String INVALIDDEEPLINKPAYLOAD = """
        {"deeplink_data":"content_type":"episodic","content_id":"Test_Rashmi_E06","ratings":"TV-Y"}}
        """;

    static final String NULLDEEPLINKPAYLOAD = "null";


    @Test
    void testUpdateStatusWithRevokedStatus() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Revoked")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        asset.setStatus("Released");
        asset.setContentId("TEST");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().feedWorker("cms").contentId("TEST").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        ResponseDto actualResponse = assetService.updateStatusByBulk(statusUpdateDto);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testUpdateStatusWithUntrackableStatus() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Revoked")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().vcCpId("cpId1")
            .countryCode("US")
            .contentId("contentId1").status("Untrackable").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        assertThrows(CustomException.class,
            () -> assetService.updateStatusByBulk(statusUpdateDto));
    }

    @Test
    void testUpdateStatusWithRevokedAndIsReleasedStatus() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Revoked")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().vcCpId("cpId1")
            .countryCode("US")
            .contentId("contentId1").isReleased(false).build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        assertThrows(CustomException.class,
            () -> assetService.updateStatusByBulk(statusUpdateDto));
    }


    @Test
    void testUpdateStatusWithTempQCPassStatus() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Temp QC Pass")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        asset.setType("season");
        asset.setStatus("READY FOR QC");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(asset));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);
        when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
            any(HttpEntity.class),
            any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        assertThrows(CustomException.class,
            () -> assetService.updateStatusByBulk(statusUpdateDto));
    }

    @Test
    void testUpdateStatusWithInvalidStatus() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("InvalidStatus")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();

        VodAssetDto asset = new VodAssetDto();
        asset.setStatus("QC In Progress");
        asset.setFeedWorker("cms");
        asset.setContentId("TEST");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(asset));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);
        when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
            any(HttpEntity.class),
            any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        ResponseDto actualResponse = assetService.updateStatusByBulk(statusUpdateDto);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testUpdateStatusFailOnGettingAssetInfoByApi() {
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder().assetList(new ArrayList<>())
            .build();
        when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
            any(HttpEntity.class),
            any(Class.class))).thenThrow(new RuntimeException("error in httpMethodHandler"));
        assertThrows(RuntimeException.class,
            () -> assetService.updateStatusByBulk(statusUpdateDto));
    }

    @Test
    void testUpdateStatusWithGreenDeploymentEnvironmentStatRevoked() {
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Revoked")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        asset.setStatus("Released");
        asset.setContentId("TEST");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().feedWorker("cms").contentId("TEST").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));
        Mockito.doThrow(new CustomException("Deployment env Failed")).when(assetHelperService)
            .validateDeploymentEnv(statusUpdateDto);

        assertThrows(CustomException.class, () -> assetService.updateStatusByBulk(statusUpdateDto));
    }

    @ParameterizedTest
    @ValueSource(strings = {"Temp QC Pass", "QC Pass"})
    void testUpdateStatusWithGreenDeploymentEnvironmentStatTempQCPassed(String val) {
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status(val)
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();
        VodAssetDto asset = new VodAssetDto();
        asset.setStatus("Released");
        asset.setContentId("TEST");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().feedWorker("cms").contentId("TEST").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        assertThrows(CustomException.class, () -> assetService.updateStatusByBulk(statusUpdateDto));
    }


    @Test
    void testUpdateStatusWithNonEditableFeedWorker() {

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("InvalidStatus")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();

        VodAssetDto asset = new VodAssetDto();
        asset.setStatus("QC In Progress");
        asset.setFeedWorker("unknownFeedWorker");
        asset.setContentId("TEST");
        BaseResponseDto res = new BaseResponseDto();
        res.setPayload(
            Map.of("assetDetails", List.of(asset)));
        ResponseDto expectedResponse = ResponseDto.builder().rsp(res).build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assets", List.of(asset));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);
        when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
            any(HttpEntity.class),
            any(Class.class)))
            .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

        assertThrows(CustomException.class, () -> assetService.updateStatusByBulk(statusUpdateDto));
    }


    @Test
    void uploadUpdatesWithEmptyRows() throws IOException {
        // Test case for empty rows in Excel
        Workbook workbook = new XSSFWorkbook();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        MultipartFile file = new MockMultipartFile("file", "test.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);

        assertThrows(AssetApiFailureException.class, () -> assetService.uploadUpdates(file));
    }

    @Test
    void uploadUpdatesWithInvalidHeaders() throws IOException {
        // Test case for invalid header validation
        XSSFWorkbook workbook = ExcelTestDataProvider.createStandardTestWorkbook();
        XSSFSheet sheet = workbook.getSheetAt(0);
        Row row = sheet.getRow(0);
        row.getCell(0).setCellValue("invalid header");
        MultipartFile file = ExcelTestDataProvider.createTestMultipartFileFromWorkbook(workbook);

        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }

    @Test
    void uploadUpdatesWithNoDataRows() throws IOException {
        // Test case for no data rows after header
        XSSFWorkbook workbook = ExcelTestDataProvider.createStandardTestWorkbook();
        // We don't add any data rows, just the header row
        MultipartFile file = ExcelTestDataProvider.createTestMultipartFileFromWorkbook(workbook);

        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }

    @Test
    void uploadUpdatesWithNullValues() throws IOException {
        // Test case for empty row check (contentId, countryCode, vcCpId)
        XSSFWorkbook workbook = ExcelTestDataProvider.createStandardTestWorkbook();
        // We create the workbook with standard headers but don't add any data rows
        MultipartFile file = ExcelTestDataProvider.createTestMultipartFileFromWorkbook(workbook);

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("all", "TV-14"))
            .countryCode("AA").type("episode").build();
        ResponseDto ratingResponse = ResponseHandler.processMethodResponse("ratings",
            List.of(ratingDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ratingResponse));

        when(validationAsset.validate(any(VodAssetDto.class), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());

        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }


    @Test
    void testUploadActionConfirmWithNullExternalProviderList() {
        String response = "Confirm";
        // Test case with null externalProvider list to cover setExternalIDListForUpload method
        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle")
            .releaseDate("releaseDate").description("description").starring("starring")
            .externalIdType("type1,type2").externalId("id1,id2").externalProvider(null)
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }

    @Test
    void testUploadActionConfirmWithNullExternalIdFields() {
        String response = "Confirm";
        // Test case with null external ID fields to cover setExternalIDListForUpload method
        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle")
            .releaseDate("releaseDate").description("description").starring("starring")
            .externalIdType(null).externalId(null).externalProvider(null)
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }

    @Test
    void testSetExternalIDListForUploadWithExternalProviders() {
        // Create a VodAssetDto with external provider data
        List<ExternalProviderDto> externalProviders = new ArrayList<>();
        ExternalProviderDto providerDto = ExternalProviderDto.builder()
            .provider("provider1")
            .externalProgramId("id1")
            .idType("type1")
            .idProvider("idProvider1")
            .build();
        externalProviders.add(providerDto);

        VodAssetDto asset = VodAssetDto.builder()
            .contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId")
            .externalIdType("type1,type2")
            .externalId("id1,id2")
            .externalProvider(new ArrayList<>()) // Empty list to trigger the first condition
            .externalIdProvider("provider1,provider2")
            .build();

        VodAssetDto oldVodAsset = VodAssetDto.builder()
            .externalProvider(externalProviders)
            .build();

        List<VodAssetDto> vodAssetDtoList = List.of(oldVodAsset);

        // Mock the getAssetsDataForHistory method to return the old asset data
        Map<String, Object> assetsData = new HashMap<>();
        assetsData.put(Constants.ASSETS, vodAssetDtoList);
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(assetsData).build())
            .build();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(), any()))
            .thenReturn(ResponseEntity.ok(responseDto));

        // Mock other required methods

        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset(any(VodAssetDto.class));
        Mockito.doNothing().when(assetAsyncService).insertMetadataModificationHistory(any());
        Mockito.doNothing().when(assetSyncerService).pushMessageToSqsAsync(anyString(), any());

        // Call the method that will trigger setExternalIDListForUpload
        assertDoesNotThrow(() -> {
            assetService.triggerUpdateAsset(asset);
        });

    }


    @Test
    void testTakeDecision_WhenImportedAssetsNotExist() {
        List<VodAssetDto> result = assetService.getImportedAssets();
        when(assetMapper.getImportedAssetsByUserId("userId", "US", "TEST_SESSION_ID")).thenReturn(
            result);

        assertEquals(0, result.size());
    }

    @Test
    void testUploadActionReject() {
        String response = "REJECT";
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");

        assertDoesNotThrow(() -> assetService.uploadAction(response));
    }


    @Test
    void testUploadActionConfirmHistory() {
        String response = "Confirm";
        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId").type("type").mainTitle("mainTitle").episodeNo(1)
            .releaseDate("releaseDate").description("description").starring("starring")
            .ratings("some rating").ratingBody("some rating body")
            .isSyncBlocked(false)
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode(
            "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").build();
        ResponseDto responseAssets = ResponseHandler.processMethodResponse("assets",
            List.of(vodAssetDto));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(responseAssets));
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }

    @Test
    void testUploadActionErrorUpdateDeleteAsset() {
        String response = "Confirm";
        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode")
            .vcCpId("vcCpId").type("type").mainTitle("mainTitle").episodeNo(1)
            .releaseDate("releaseDate").description("description").starring("starring")
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode(
            "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").build();
        ResponseDto responseAssets = ResponseHandler.processMethodResponse("assets",
            List.of(vodAssetDto));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(responseAssets));
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doThrow(AssetApiFailureException.class).when(updateAssetUtils)
            .updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }


    @Test
    void testHistoryNBulkEditSeasonEpisode() throws JsonProcessingException {

        AssetUpdateByBulkDto assetUpdateByBulkDto = AssetUpdateByBulkDto.builder()
            .vodAssetDto(VodAssetDto.builder().contentId("contentId").countryCode(
                    "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").ratings("ALL")
                .cast(List.of(AssetCastDto.builder().name("new cast").build()))
                .parentalRatings(List.of(ParentalRatingsDto.builder().build()))
                .licenseWindowList(List.of(LicenseWindowDto.builder().build()))
                .deeplinkPayload(
                    "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USs_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
                .build())
            .contentIds(
                List.of("contentId", "contentId1", "contentId2", "contentId3", "contentId4"))
            .updatedBy("test").build();

        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .cast(List.of(AssetCastDto.builder().build()))
            .build();

        VodAssetDto vodAssetDto1 = VodAssetDto.builder().contentId("contentId1").isSyncBlocked(true)
            .countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .build();

        VodAssetDto vodAssetDto2 = VodAssetDto.builder().contentId("contentId2")
            .isSyncBlocked(false)
            .countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .build();
        ResponseDto responseAssets = ResponseHandler.processMethodResponse(Constants.ASSETS,
            List.of(vodAssetDto, vodAssetDto1, vodAssetDto2));
        ResponseDto responseBulkEdit = ResponseHandler.processMethodResponse(Constants.ASSETS,
            "Assets updated");

        Mockito.doNothing().when(sqsMessageService).pushMessageToSqs(Mockito.any(), Mockito.any());
        Mockito.when(assetHelperService.setCastByListForBulkEdit(Mockito.any(), Mockito.any()))
            .thenReturn(List.of("old", "new"));
        Mockito.when(assetHelperService.setParentalRatingsForBulkEdit(Mockito.any(), Mockito.any()))
            .thenReturn(List.of("old", "new"));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(responseAssets))
            .thenReturn(ResponseEntity.ok(responseBulkEdit));
        assertDoesNotThrow(() -> {
            assetService.updateAssetInBulkPortal(assetUpdateByBulkDto);
        });
    }

    @Test
    void testHistoryNBulkEditSeasonEpisodeException() {
        AssetUpdateByBulkDto assetUpdateByBulkDto = AssetUpdateByBulkDto.builder()
            .vodAssetDto(VodAssetDto.builder().contentId("contentId").countryCode(
                    "countryCode").vcCpId("vcCpId").type("EPISODE").mainTitle("mainTitle")
                .ratings("ALL").build())
            .contentIds(List.of("contentId", "contentId1")).updatedBy("test").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode(
                "countryCode").vcCpId("vcCpId").type("MUSIC").mainTitle("mainTitle").ratings("ALL")
            .deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker(
                "cms")
            .build();
        ResponseDto responseAssets = ResponseHandler.processMethodResponse(Constants.ASSETS,
            List.of(vodAssetDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(responseAssets))
            .thenThrow(AssetApiFailureException.class);

        assertThrows(AssetApiFailureException.class,
            () -> assetService.updateAssetInBulkPortal(assetUpdateByBulkDto));
    }


    @Test
    void testUpdateAssetThrowsException() {
        doThrow(new AssetApiFailureException("error")).when(regionEndpointService)
            .getOpenAPIEndpoint();
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("aa").idProvider("aa").idType("aa").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("QC Pass")
            .contentId("aa").countryCode("aa").vcCpId("aa").externalProvider(List.of(
                externalProviderDto)).build();
        assertThrows(AssetApiFailureException.class, () -> {
            assetService.updateAsset(vodAssetDto);
        });
    }


    @Test
    void testUpdateAssetLicenseWindow() {
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");

        ResponseDto expectedResponse = ResponseDto.builder().rsp(BaseResponseDto.builder().build())
            .build();
        List<LicenseWindowDto> licenseWindowDtos = new ArrayList<>();
        licenseWindowDtos.add(
            LicenseWindowDto.builder().availableStarting("1").availableEnding("2").build());
        licenseWindowDtos.add(
            LicenseWindowDto.builder().availableStarting("3").availableEnding("4").build());
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("aa").idProvider("aa").idType("aa").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa").externalProvider(List.of(
                externalProviderDto)).isSyncBlocked(false).feedWorker("cms")
            .licenseWindowList(licenseWindowDtos)
            .build();
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(true);
        Map<String, Object> payload = new HashMap<>();
        payload.put("assetDetails", List.of(vodAssetDto, vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);
        ResponseEntity<ResponseDto> responseEntity1 = new ResponseEntity<>(expectedResponse,
            HttpStatus.OK);
        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity)
            .thenReturn(responseEntity1);
        assertDoesNotThrow(() -> {
            assetService.updateAsset(vodAssetDto);
        });
    }


    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {VALIDDEEPLINKPAYLOAD, NULLDEEPLINKPAYLOAD, INVALIDDEEPLINKPAYLOAD,
        DEEPLINKPAYLOADWITHOUTKEY})
    void testAssetStatusValidationChanges(String deepLinkPayload) {
        VodAssetDto vodAssetEditDto1 = VodAssetDto.builder().vcCpId(VCCP_ID).type("typeA")
            .seasonId("seasonId12")
            .contentId(CONTENT_ID).countryCode(COUNTRY).result(Constants.SUCCESSFUL)
            .description("new description")
            .build();
        VodAssetDto vodAssetEditDto2 = VodAssetDto.builder().vcCpId(VCCP_ID).type("typeA")
            .seasonId("seasonId12")
            .contentId(CONTENT_ID).countryCode(COUNTRY).result("not-successful")
            .description("new description")
            .build();
        List<VodAssetDto> records = List.of(vodAssetEditDto1, vodAssetEditDto2);

        VodAssetDto vodAssetDto1 = VodAssetDto.builder().countryCode(COUNTRY).isReleased(true)
            .deeplinkPayload(deepLinkPayload)
            .status("qc in progress")
            .seasonId("seasonId1")
            .description("old description")
            .type("typeA").feedWorker(Constants.FEED_WORKERS.get(0))
            .isCmsProd(1).isSyncBlocked(false).vcCpId(VCCP_ID).contentId(CONTENT_ID).build();

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put(Constants.ASSETS, List.of(vodAssetDto1)); // return list<VodAssetDto>
        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenReturn(ResponseEntity.ok(
                ResponseDto.builder().rsp(BaseResponseDto.builder().payload(responseMap).build())
                    .build()));

        Assertions.assertDoesNotThrow(() -> assetService.assetStatusValidation(List.of(), records));
    }

    @Test
    void testAssetStatusValidationNoRecordFound() {
        VodAssetDto vodAssetEditDto1 = VodAssetDto.builder().vcCpId(VCCP_ID).type("typeA")
            .seasonId("seasonId12")
            .contentId(CONTENT_ID).countryCode(COUNTRY).result(Constants.SUCCESSFUL)
            .description("new description")
            .build();
        List<VodAssetDto> records = List.of(vodAssetEditDto1);
        VodAssetDto vodAssetDto1 = VodAssetDto.builder().contentId(CONTENT_ID).countryCode(COUNTRY)
            .vcCpId("fdgnubo").build();
        VodAssetDto vodAssetDto2 = VodAssetDto.builder().contentId(CONTENT_ID).countryCode("dj")
            .vcCpId(VCCP_ID).build();
        VodAssetDto vodAssetDto3 = VodAssetDto.builder().contentId("dj").countryCode(COUNTRY)
            .vcCpId(VCCP_ID).build();

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put(Constants.ASSETS,
            List.of(vodAssetDto1, vodAssetDto2, vodAssetDto3)); // return list<VodAssetDto>
        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenReturn(ResponseEntity.ok(
                ResponseDto.builder().rsp(BaseResponseDto.builder().payload(responseMap).build())
                    .build()));

        Assertions.assertDoesNotThrow(() -> assetService.assetStatusValidation(List.of(), records));
    }


    @ParameterizedTest
    @MethodSource("getArgumentsForStatusValid")
    void testAssetStatusValidationChangesStatus(String status, String type) {
        VodAssetDto vodAssetEditDto1 = VodAssetDto.builder().vcCpId(VCCP_ID).type("typeA")
            .seasonId("seasonId12")
            .contentId(CONTENT_ID).countryCode(COUNTRY).result(Constants.SUCCESSFUL)
            .description("new description")
            .build();
        List<VodAssetDto> records = List.of(vodAssetEditDto1);

        VodAssetDto vodAssetDto1 = VodAssetDto.builder().countryCode(COUNTRY).isReleased(true)
            .deeplinkPayload(VALIDDEEPLINKPAYLOAD)
            .seasonId("seasonId1")
            .status(status.equals("null") ? null : status)
            .description("old description")
            .type(type).feedWorker(Constants.FEED_WORKERS.get(0))
            .isCmsProd(1).isSyncBlocked(false).vcCpId(VCCP_ID).contentId(CONTENT_ID).build();

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put(Constants.ASSETS, List.of(vodAssetDto1)); // return list<VodAssetDto>
        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenReturn(ResponseEntity.ok(
                ResponseDto.builder().rsp(BaseResponseDto.builder().payload(responseMap).build())
                    .build()));

        Assertions.assertDoesNotThrow(() -> assetService.assetStatusValidation(List.of(), records));
    }


    private static Stream<Arguments> getArgumentsForStatusValid() {
        return Stream.of(Arguments.of("non-editable-status", "typeA"),
            Arguments.of("null", "typeA"),
            Arguments.of("qc in progress", "typeB"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"random_feed_worker", "cms"})
    void testAssetStatusValidationFieldWorkerError(String val) {
        VodAssetDto vodAssetEditDto1 = VodAssetDto.builder().vcCpId(VCCP_ID).type("typeA")
            .seasonId("seasonId12")
            .contentId(CONTENT_ID).countryCode(COUNTRY).result(Constants.SUCCESSFUL)
            .description("new description")
            .build();
        List<VodAssetDto> records = List.of(vodAssetEditDto1);

        VodAssetDto vodAssetDto1 = VodAssetDto.builder().countryCode(COUNTRY).isReleased(true)
            .deeplinkPayload(VALIDDEEPLINKPAYLOAD)
            .status("qc in progress")
            .seasonId("seasonId1")
            .description("old description")
            .type("typeA").feedWorker(val)
            .isCmsProd(1).isSyncBlocked(false).vcCpId(VCCP_ID).contentId(CONTENT_ID).build();

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put(Constants.ASSETS, List.of(vodAssetDto1)); // return list<VodAssetDto>
        Mockito.when(httpMethodHandler.handleHttpExchange(Mockito.anyString(), Mockito.anyString(),
                Mockito.any(), Mockito.any()))
            .thenReturn(ResponseEntity.ok(
                ResponseDto.builder().rsp(BaseResponseDto.builder().payload(responseMap).build())
                    .build()));

        Assertions.assertDoesNotThrow(() -> assetService.assetStatusValidation(List.of(), records));
    }

    // Helper method to create standard test workbook with common headers
    private XSSFWorkbook createStandardTestWorkbook() throws IOException {
        return ExcelTestDataProvider.createStandardTestWorkbook();
    }

    // Helper method to create sample image data
    private byte[] createSampleImageData() {
        return new byte[]{0x42, 0x4D, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00,
            0x00, 0x00, 0x01, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00};
    }


    @Test
    void uploadUpdatesWithValidationFailure() throws IOException {
        // Test case for validation failures
        XSSFWorkbook workbook = createStandardTestWorkbook();
        XSSFSheet sheet = workbook.getSheetAt(0);
        Row row = sheet.createRow(1);
        extracted(row);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        MultipartFile file = new MockMultipartFile("file", "test.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("all", "TV-14"))
            .countryCode("AA").type("episode").build();
        ResponseDto ratingResponse = ResponseHandler.processMethodResponse("ratings",
            List.of(ratingDto));

        VodAssetDto vodAssetDto = VodAssetDto.builder()
            .status("Released").contentId("content1")
            .countryCode("US").vcCpId("provider1").type("MOVIE").feedWorker("CMS").build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse("assets",
            List.of(vodAssetDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ratingResponse))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        when(validationAsset.validate(any(VodAssetDto.class), Mockito.any()))
            .thenThrow(new InvalidInputDataException("Validation failed"));
        Mockito.doNothing().when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());

        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }

    private static void extracted(Row row) {
        row.createCell(0).setCellValue("content1");
        row.createCell(1).setCellValue("US");
        row.createCell(2).setCellValue("provider1");
        row.createCell(3).setCellValue("asset1");
        row.createCell(4).setCellValue("MOVIE");
        row.createCell(5).setCellValue("Title1");
        row.createCell(6).setCellValue("Short1");
        row.createCell(7).setCellValue("Synopsis1");
        row.createCell(8).setCellValue("2023-01-01");
        row.createCell(9).setCellValue("Action");
        row.createCell(10).setCellValue("ext1");
        row.createCell(11).setCellValue("prov1");
        row.createCell(12).setCellValue("type1");
        row.createCell(13).setCellValue("partner1");
        row.createCell(14).setCellValue("tier1");
    }

    @Test
    void uploadUpdatesWithEmptyRecords() throws IOException {
        // Test case for empty records after processing
        XSSFWorkbook workbook = createStandardTestWorkbook();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        MultipartFile file = new MockMultipartFile("file", "test.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("all", "TV-14"))
            .countryCode("AA").type("episode").build();
        ResponseDto ratingResponse = ResponseHandler.processMethodResponse("ratings",
            List.of(ratingDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ratingResponse));

        when(validationAsset.validate(any(VodAssetDto.class), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());

        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }

    @Test
    void uploadUpdatesWithAssetStatusValidationFailure() throws IOException {
        // Test case for asset status validation failure
        XSSFWorkbook workbook = createStandardTestWorkbook();
        XSSFSheet sheet = workbook.getSheetAt(0);
        Row row = sheet.createRow(1);
        extracted(row);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        MultipartFile file = new MockMultipartFile("file", "test.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("all", "TV-14"))
            .countryCode("AA").type("episode").build();
        ResponseDto ratingResponse = ResponseHandler.processMethodResponse("ratings",
            List.of(ratingDto));

        VodAssetDto vodAssetDto = VodAssetDto.builder()
            .status("Released").contentId("content1")
            .countryCode("US").vcCpId("provider1").type("MOVIE").feedWorker("CMS").build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse("assets",
            List.of(vodAssetDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(ratingResponse))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        when(validationAsset.validate(any(VodAssetDto.class), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());
        Mockito.doThrow(new RuntimeException("Status validation failed"))
            .when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());

        assertThrows(RuntimeException.class, () -> assetService.uploadUpdates(file));
    }


    @Test
    void testUploadActionConfirm() {
        String response = "Confirm";
        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle")
            .releaseDate("releaseDate").description("description").starring("starring")
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }

    @Test
    void testUploadActionConfirmWithExternalIdFields() {
        String response = "Confirm";
        // Test case with external ID fields to cover setExternalIDListForUpload method
        List<ExternalProviderDto> externalProviders = new ArrayList<>();
        externalProviders.add(
            ExternalProviderDto.builder().provider("provider1").externalProgramId("id1")
                .idType("type1").build());
        externalProviders.add(
            ExternalProviderDto.builder().provider("provider2").externalProgramId("id2")
                .idType("type2").build());

        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle")
            .releaseDate("releaseDate").description("description").starring("starring")
            .externalIdType("type1,type2").externalId("id1,id2").externalProvider(externalProviders)
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }

    @Test
    void testUploadActionConfirmWithEmptyExternalIdFields() {
        String response = "Confirm";
        // Test case with empty external ID fields to cover setExternalIDListForUpload method
        List<ExternalProviderDto> externalProviders = new ArrayList<>();

        VodAssetDto vodAssetEditDto = VodAssetDto.builder().contentId("contentId")
            .countryCode("countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle")
            .releaseDate("releaseDate").description("description").starring("starring")
            .externalIdType("").externalId("").externalProvider(externalProviders)
            .ratings("some rating").ratingBody("some rating body")
            .genres("genres").ratings("ratings").userId("userId").result("successful").build();
        when(assetMapper.getSuccessfulAssets("userId", "US", "TEST_SESSION_ID")).thenReturn(
            List.of(vodAssetEditDto));
        Mockito.doNothing().when(assetMapper).cleanAssetsByUserId("userId", "US");
        Mockito.doNothing().when(updateAssetUtils).updateDeleteAsset((any(VodAssetDto.class)));
        Mockito.doNothing().when(assetAsyncService)
            .insertMetadataModificationHistory(Mockito.any());
        assertDoesNotThrow(() -> {
            assetService.uploadAction(response);
        });
    }


    @Test
    void testEditNHistoryCall() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assetDetails", List.of(vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntityAssetDetails = new ResponseEntity<>(responseDto,
            HttpStatus.OK);

        ResponseDto updateAsset = ResponseHandler.processMethodResponse("asset",
            "asset updated");
        vodAssetDto = VodAssetDto.builder().countryCode("AA").contentId("aa").feedWorker("cms")
            .vcCpId("aa").build();
        LicenseHistoryRequestDto licenseHistoryRequestDto = LicenseHistoryRequestDto.builder()
            .assetId("aa").countryCode("AA").vcCpId("aa").updatedBy("aa").build();
        StatusHistoryRequestDto statusHistoryRequestDto = StatusHistoryRequestDto.builder()
            .changes(List.of(
                AssetsChanges.builder().build())).build();
        MetadataHistoryRequestDto metadataHistoryRequestDto = MetadataHistoryRequestDto.builder()
            .assetId("aa").countryCode("cc").vcCpId("aa").build();
        AssetChangeHistoryDto assetChangeHistoryDto = AssetChangeHistoryDto.builder()
            .assetLicenseHistory(licenseHistoryRequestDto)
            .assetStatusHistory(statusHistoryRequestDto)
            .assetMetadataHistory(metadataHistoryRequestDto).build();
        AssetRequestBodyDto assetRequestBodyDto = AssetRequestBodyDto.builder()
            .vodAssetDto(vodAssetDto).assetChangeHistoryDto(assetChangeHistoryDto).build();
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(true);
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntityAssetDetails)
            .thenReturn(ResponseEntity.ok(updateAsset)).thenReturn(responseEntity)
            .thenReturn(responseEntity).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.editAndHistoryCall(assetRequestBodyDto);
        });
    }

    @Test
    void testHeaderValidationWithInvalidHeaders() throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Sheet1");
        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("program id");
        row.createCell(1).setCellValue("countr");
        row.createCell(2).setCellValue("type");
        row.createCell(3).setCellValue("Program Title/Episode Title");
        row.createCell(4).setCellValue("ID Provider");
        row.createCell(5).setCellValue("Original Release Date");
        row.createCell(6).setCellValue("Synopsis/Description");
        row.createCell(7).setCellValue("Actor");
        row.createCell(8).setCellValue("ratings");
        row.createCell(9).setCellValue("genre");
        row = sheet.createRow(1);
        row.createCell(0).setCellValue("aaa");
        row.createCell(1).setCellValue("US");
        row.createCell(2).setCellValue("MOVIE");
        row.createCell(3).setCellValue("GOT");
        row.createCell(4).setCellValue("vcCpId");
        row.createCell(5).setCellValue("01-01-2023");
        row.createCell(6).setCellValue("GOT");
        row.createCell(7).setCellValue("aaa");
        row.createCell(8).setCellValue("US");
        row.createCell(9).setCellValue("MOVIE");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        byte[] excelContent = baos.toByteArray();
        workbook.close();
        MultipartFile file = new MockMultipartFile("file", "test.xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelContent);

        RatingsDto ratingDto = RatingsDto.builder().parentalRatings(List.of("all", "TV-14"))
            .countryCode("AA").type("episode").build();
        ResponseDto ratingResponse = ResponseHandler.processMethodResponse("ratings",
            List.of(ratingDto));

        VodAssetStatusResponseDto vodAssetStatusResponseDto = VodAssetStatusResponseDto.builder()
            .status("Released").contentId("aaa")
            .countryCode("US").vcCpId("vcCpId").type("MOVIE").feedWorker("CMS").build();
        ResponseDto expectedResponse = ResponseHandler.processMethodResponse("assetDetails",
            List.of(vodAssetStatusResponseDto));

        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(
                ResponseEntity.ok(ratingResponse))
            .thenReturn(
                ResponseEntity.ok(expectedResponse)
            );

        when(validationAsset.validate(any(VodAssetDto.class), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(updateAssetUtils).insertRecordsInUploadtable(Mockito.any());
        assertThrows(InvalidInputDataException.class, () -> assetService.uploadUpdates(file));
    }


    @Test
    void testExistingUpdates() {
        List<VodAssetDto> expectedList = new ArrayList<>();
        when(assetMapper.getImportedAssetsByUserId("userId", "US", "TEST_SESSION_ID")).thenReturn(
            expectedList);

        List<VodAssetDto> actualList = assetService.getImportedAssets();
        assertEquals(expectedList, actualList);
    }

    // Test cases for validateAssetDetails
    @Test
    void testValidateAssetDetails() {
        ResponseEntity<ResponseDto> responseEntity = TestUtility.createStandardResponseEntity();
        EditValidationDto editValidationDto = EditValidationDto.builder().build();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.validateAssetDetails(editValidationDto);
        });
    }

    @Test
    void testValidateAssetDetailsException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(IllegalArgumentException.class);
        EditValidationDto editValidationDto = EditValidationDto.builder().build();
        assertThrows(IllegalArgumentException.class,
            () -> assetService.validateAssetDetails(editValidationDto));
    }

    @Test
    void testValidateAssetDetailsBadRequestException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        EditValidationDto editValidationDto = EditValidationDto.builder().build();
        assertThrows(AssetApiFailureException.class,
            () -> assetService.validateAssetDetails(editValidationDto));
    }

    // Test cases for getFilteredAssets
    @Test
    void testGetFilteredAssets() {
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder()
            .filters(List.of(new FilterDto()))
            .columns(Arrays.asList("column1", "column2"))
            .sortBy(List.of(new SortDto()))
            .pagination(new PaginationDto())
            .build();
        HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(assetFilterBodyDto);
        String finalUrl = "http://test:8080" + Constants.GET_FILTERED_ASSETS;
        ResponseEntity<ResponseDto> responseEntity = TestUtility.createStandardResponseEntity();
        when(httpMethodHandler.handleHttpExchange(finalUrl, Constants.METHOD_POST,
            httpEntity,
            ResponseDto.class)).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.getFilteredAssets(assetFilterBodyDto);
        });
    }

    @Test
    void testGetFilteredAssetsException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().build();
        assertThrows(AssetApiFailureException.class,
            () -> assetService.getFilteredAssets(assetFilterBodyDto));
    }

    @Test
    void testGetFilteredAssetsBadRequestException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(IllegalArgumentException.class);
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().build();
        assertThrows(IllegalArgumentException.class,
            () -> assetService.getFilteredAssets(assetFilterBodyDto));
    }

    // Test cases for getAssetView
    @Test
    void testGetAssetView() {
        String finalUrl = "http://test:8080" + Constants.GET_ASSET_VIEW;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
        builder.queryParam(Constants.CONTENT_ID, "test");
        builder.queryParam(Constants.CP_ID, "test");
        builder.queryParam(Constants.COUNTRY, "test");
        ResponseEntity<ResponseDto> responseEntity = TestUtility.createStandardResponseEntity();
        when(httpMethodHandler.handleHttpExchange(builder.build().toUriString(),
            Constants.METHOD_GET,
            null,
            ResponseDto.class)).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.getAssetView("test", "test", "test");
        });
    }

    // Test cases for updateAsset
    @Test
    void testUpdateAsset() {
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
        ResponseDto expectedResponse = ResponseDto.builder().rsp(BaseResponseDto.builder().build())
            .build();
        ExternalProviderDto externalProviderDto = ExternalProviderDto.builder()
            .externalProgramId("aa").idProvider("aa").idType("aa").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa").externalProvider(List.of(
                externalProviderDto)).isSyncBlocked(false).feedWorker("cms").build();
        Map<String, Object> payload = new HashMap<>();
        payload.put("assetDetails", List.of(vodAssetDto, vodAssetDto));
        ResponseDto responseDto = ResponseDto.builder()
            .rsp(BaseResponseDto.builder().payload(payload).build()).build();
        ResponseEntity<ResponseDto> responseEntity = new ResponseEntity<>(responseDto,
            HttpStatus.OK);
        ResponseEntity<ResponseDto> responseEntity1 = new ResponseEntity<>(expectedResponse,
            HttpStatus.OK);
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(true);

        Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                any(HttpEntity.class),
                any(Class.class)))
            .thenReturn(responseEntity)
            .thenReturn(responseEntity1);
        assertDoesNotThrow(() -> {
            assetService.updateAsset(vodAssetDto);
        });
    }

    @Test
    void testUpdateAssetWithOverlappingLicenseWindow() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa").feedWorker("cms").build();
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(false);
        assertThrows(AssetApiFailureException.class, () -> assetService.updateAsset(vodAssetDto));
    }

    @Test
    void testUpdateAssetWithOverlappingEventWindow() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa").feedWorker("cms").build();
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(true).thenReturn(false);
        assertThrows(AssetApiFailureException.class, () -> assetService.updateAsset(vodAssetDto));
    }

    @Test
    void testUpdateAssetWithNonEditableFeedWorker() {
        VodAssetDto vodAssetDto = VodAssetDto.builder().type("EPISODE").status("ready for qc")
            .contentId("aa").countryCode("aa").vcCpId("aa").feedWorker("invalid").build();
        Mockito.when(validationAsset.validateNonOverlappingWindows(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
            .thenReturn(true);
        assertThrows(AssetApiFailureException.class, () -> assetService.updateAsset(vodAssetDto));
    }

    // Test cases for updateStatusByBulk
    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void testUpdateStatusByBulkWithRevokedStatus(boolean isUntrackable) {
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .status("Revoked")
            .assetList(List.of(AssetKeyDto.builder()
                .vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1")
                .build()))
            .build();

        BaseResponseDto res = new BaseResponseDto();
        ResponseDto expectedResponse;
        ResponseEntity<ResponseDto> responseEntity;

        if (isUntrackable) {
            VodAssetDto asset = new VodAssetDto();
            res.setPayload(Map.of("assetDetails", List.of(asset)));
            expectedResponse = ResponseDto.builder().rsp(res).build();
            VodAssetDto vodAssetDto = VodAssetDto.builder().vcCpId("cpId1")
                .countryCode("US")
                .contentId("contentId1").status("Untrackable").build();
            Map<String, Object> payload = new HashMap<>();
            payload.put("assets", List.of(vodAssetDto));
            ResponseDto responseDto = ResponseDto.builder()
                .rsp(BaseResponseDto.builder().payload(payload).build()).build();
            responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK);

            Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                    any(HttpEntity.class), any(Class.class)))
                .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

            assertThrows(CustomException.class,
                () -> assetService.updateStatusByBulk(statusUpdateDto));
        } else {
            VodAssetDto asset = new VodAssetDto();
            asset.setStatus("Released");
            asset.setContentId("TEST");
            res.setPayload(Map.of("assetDetails", List.of(asset)));
            expectedResponse = ResponseDto.builder().rsp(res).build();
            VodAssetDto vodAssetDto = VodAssetDto.builder().feedWorker("cms").contentId("TEST")
                .build();
            Map<String, Object> payload = new HashMap<>();
            payload.put("assets", List.of(vodAssetDto));
            ResponseDto responseDto = ResponseDto.builder()
                .rsp(BaseResponseDto.builder().payload(payload).build()).build();
            responseEntity = new ResponseEntity<>(responseDto, HttpStatus.OK);

            Mockito.when(httpMethodHandler.handleHttpExchange(any(String.class), anyString(),
                    any(HttpEntity.class), any(Class.class)))
                .thenReturn(responseEntity).thenReturn(ResponseEntity.ok(expectedResponse));

            ResponseDto actualResponse = assetService.updateStatusByBulk(statusUpdateDto);
            assertEquals(expectedResponse, actualResponse);
        }
    }


    // Test cases for editAndHistoryCall
    @Test
    void testEditNHistoryCallNull() {
        assertDoesNotThrow(() -> assetService.editAndHistoryCall(null));
    }

    @Test
    void testEditNHistoryCallWithNullVodAssetDto() {
        AssetRequestBodyDto assetRequestBodyDto = AssetRequestBodyDto.builder().build();
        ResponseDto responseDto = ResponseDto.builder().rsp(
            BaseResponseDto.builder().stat(Constants.STATUS_OK).err(
                ErrorResponseDto.builder().code(Constants.STATUS_OK)
                    .msg(Constants.VOD_ASSET_IS_NULL).build()).build()).build();
        assertEquals(responseDto, assetService.editAndHistoryCall(assetRequestBodyDto));
    }

    // Test cases for uploadSingleImage
    @Test
    void testUploadSingleImage() {
        AssetSingleImageUpdateDto assetSingleImageUpdateDto = new AssetSingleImageUpdateDto();
        assetSingleImageUpdateDto.setProgramId("aa");
        assetSingleImageUpdateDto.setProviderId("aa");
        assetSingleImageUpdateDto.setCountryCode("AA");
        Map<String, Object> result = assetService.uploadSingleImage(assetSingleImageUpdateDto);
        assertNotNull(result);
        assertEquals(0, result.size());
    }

    // Test cases for getShowHierarchy
    @Test
    void testGetShowHierarchy() {
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        ResponseEntity<ResponseDto> responseEntity = ServiceTestUtility.createStandardResponseEntity();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.getShowHierarchy(assetKeyDto);
        });
    }

    @Test
    void testGetShowHierarchyException() {
        AssetKeyDto assetKeyDto = AssetKeyDto.builder().contentId("aa").countryCode("aa")
            .vcCpId("aa").build();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        assertThrows(AssetApiFailureException.class,
            () -> assetService.getShowHierarchy(assetKeyDto));
    }

    // Test cases for updateAssetInBulkPortal
    @Test
    void testUpdateAssetInBulkPortal() throws JsonProcessingException {
        AssetUpdateByBulkDto assetUpdateByBulkDto = AssetUpdateByBulkDto.builder()
            .vodAssetDto(VodAssetDto.builder().contentId("contentId").countryCode(
                    "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").ratings("ALL")
                .cast(List.of(AssetCastDto.builder().name("new cast").build()))
                .parentalRatings(List.of(ParentalRatingsDto.builder().build()))
                .licenseWindowList(List.of(LicenseWindowDto.builder().build()))
                .deeplinkPayload(
                    "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USs_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
                .build())
            .contentIds(
                List.of("contentId", "contentId1", "contentId2", "contentId3", "contentId4"))
            .updatedBy("test").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("contentId").countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .cast(List.of(AssetCastDto.builder().build()))
            .build();
        VodAssetDto vodAssetDto1 = VodAssetDto.builder().contentId("contentId1").isSyncBlocked(true)
            .countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .build();
        VodAssetDto vodAssetDto2 = VodAssetDto.builder().contentId("contentId2")
            .isSyncBlocked(false)
            .countryCode(
                "countryCode").vcCpId("vcCpId").type("type").mainTitle("mainTitle").deeplinkPayload(
                "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"USMS_AETN_60DaysInNarcoland_S01_E04_HD\",\"ratings\":\"12\"}}")
            .feedWorker("cms")
            .build();
        ResponseDto responseAssets = ResponseHandler.processMethodResponse(Constants.ASSETS,
            List.of(vodAssetDto, vodAssetDto1, vodAssetDto2));
        ResponseDto responseBulkEdit = ResponseHandler.processMethodResponse(Constants.ASSETS,
            "Assets updated");
        Mockito.doNothing().when(sqsMessageService)
            .pushMessageToSqs(Mockito.any(), Mockito.anyString());
        Mockito.when(assetHelperService.setCastByListForBulkEdit(Mockito.any(), Mockito.any()))
            .thenReturn(List.of("old", "new"));
        Mockito.when(assetHelperService.setParentalRatingsForBulkEdit(Mockito.any(), Mockito.any()))
            .thenReturn(List.of("old", "new"));
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any()))
            .thenReturn(ResponseEntity.ok(responseAssets))
            .thenReturn(ResponseEntity.ok(responseBulkEdit));
        assertDoesNotThrow(() -> {
            assetService.updateAssetInBulkPortal(assetUpdateByBulkDto);
        });
    }

    // Test cases for getEpisodeHierarchy
    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void testGetEpisodeHierarchy(boolean shouldThrowException) {
        AssetEpisodeHierarchyDto assetEpisodeHierarchyDto = AssetEpisodeHierarchyDto.builder()
            .vcCpId("aa").countryCode("AA").contentId("AA").build();

        if (shouldThrowException) {
            when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
                Mockito.any())).thenThrow(AssetApiFailureException.class);
            assertThrows(AssetApiFailureException.class,
                () -> assetService.getEpisodeHierarchy(assetEpisodeHierarchyDto));
        } else {
            ResponseEntity<ResponseDto> responseEntity = ServiceTestUtility.createStandardResponseEntity();
            when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
                Mockito.any())).thenReturn(responseEntity);
            assertDoesNotThrow(() -> {
                assetService.getEpisodeHierarchy(assetEpisodeHierarchyDto);
            });
        }
    }


    // Test cases for getFilteredAssetsCount
    @Test
    void testGetFilteredAssetsCount() {
        ResponseEntity<ResponseDto> responseEntity = ServiceTestUtility.createStandardResponseEntity();
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().build();
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenReturn(responseEntity);
        assertDoesNotThrow(() -> {
            assetService.getFilteredAssetsCount(assetFilterBodyDto, "aa");
        });
    }

    @Test
    void testGetFilteredAssetsCountException() {
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), Mockito.any(),
            Mockito.any())).thenThrow(AssetApiFailureException.class);
        AssetFilterBodyDto assetFilterBodyDto = AssetFilterBodyDto.builder().build();
        assertThrows(AssetApiFailureException.class,
            () -> assetService.getFilteredAssetsCount(assetFilterBodyDto, "aa"));
    }


    // Test cases for private methods (accessed via reflection)
    @Test
    void testValidateEditableStatusForQcPass() throws Exception {
        java.lang.reflect.Method method = AssetService.class.getDeclaredMethod(
            "validateEditableStatusForQcPass", List.class);
        method.setAccessible(true);

        VodAssetDto asset1 = new VodAssetDto();
        asset1.setStatus(AssetStatus.QC_IN_PROGRESS.value);
        VodAssetDto asset2 = new VodAssetDto();
        asset2.setStatus(AssetStatus.REVOKED.value);
        VodAssetDto asset3 = new VodAssetDto();
        asset3.setStatus(AssetStatus.QC_FAIL.value);

        assertDoesNotThrow(() -> method.invoke(assetService, List.of(asset1, asset2, asset3)));

        VodAssetDto asset4 = new VodAssetDto();
        asset4.setStatus("Invalid Status");
        assertThrows(Exception.class, () -> method.invoke(assetService, List.of(asset4)));
    }

    @Test
    void testPrepareResponseDtoWithProcessingAssets() throws Exception {
        java.lang.reflect.Method method = AssetService.class.getDeclaredMethod(
            "prepareResponseDto", ResponseDto.class, List.class, List.class);
        method.setAccessible(true);

        BaseResponseDto baseResponseDto = BaseResponseDto.builder().build();
        ResponseDto responseDto = ResponseDto.builder().rsp(baseResponseDto)
            .build();
        AssetKeyDto processingAsset = AssetKeyDto.builder().contentId("content1").build();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId("content1").build();

        method.invoke(assetService, responseDto, List.of(processingAsset), List.of(vodAssetDto));

        assertNotNull(responseDto.getRsp());
        // Only check payload if it's not null
        if (responseDto.getRsp().getPayload() != null) {
            Map<String, Object> payload = (Map<String, Object>) responseDto.getRsp().getPayload();
            assertNotNull(payload.get("success"));
            assertNotNull(payload.get("warn"));
        }
    }


    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void testSendMessageToSyncerWithSyncBlocked(boolean isSyncBlocked) throws Exception {
        java.lang.reflect.Method method = AssetService.class.getDeclaredMethod(
            "sendMessageToSyncer", VodAssetDto.class);
        method.setAccessible(true);

        VodAssetDto asset = VodAssetDto.builder()
            .contentId("content1")
            .feedWorker("cms")
            .vcCpId("vcCpId")
            .countryCode("US")
            .isSyncBlocked(isSyncBlocked)
            .build();

        method.invoke(assetService, asset);

        // Verify the method call based on the isSyncBlocked value
        int expectedCalls = isSyncBlocked ? 0 : 1;
        verify(assetSyncerService, times(expectedCalls)).pushMessageToSqsAsync(anyString(),
            Mockito.anyList());
    }


}
