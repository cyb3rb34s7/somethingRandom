package com.cms.backend.common.enums;

public enum AssetColumns {
    TOTAL_AVAILABLE_STARTING("totalAvailableStarting"),
    EXTERNAL_PROVIDERS("externalProviders"),
    EXTERNAL_PROVIDER("externalProvider"),
    EXTERNAL_PROVIDER_LIST("externalProviderList"),
    AVAILABLE_STARTING("availableStarting"),
    CURRENT_STATUS("status"),
    IDENTIFIER_ID("identifierId"),
    VC_CP_ID("vcCpId"),
    COUNTRY_CODE("countryCode"),
    CONTENT_ID("contentId"),
    TYPE("type"),
    SHOW_ID("showId"),
    SEASON_ID("seasonId"),
    IS_CMS_PRD("isCmsProd"),
    FEED_WORKER("feedWorker"),
    STARRING("starring"),
    TOTAL_AVAILABLE_ENDING("totalAvailableEnding");


    public final String value;

    AssetColumns(String value) {
        this.value = value;
    }
}
