package com.cms.backend.common.enums;

public enum AssetTypes {
    EPISODE("EPISODE"),
    SEASON("SEASON"),
    SHOW("SHOW"),
    SINGLEVOD("SINGLEVOD"),
    MUSIC("MUSIC"),
    MOVIE("MOVIE");


    public final String value;

    AssetTypes(String value) {
        this.value = value;
    }
}
