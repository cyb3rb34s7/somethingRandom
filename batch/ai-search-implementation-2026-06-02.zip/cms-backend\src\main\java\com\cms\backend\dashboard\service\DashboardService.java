package com.cms.backend.dashboard.service;

import com.cms.backend.common.exception.CustomException;
import com.cms.backend.dashboard.model.DashboardCountDto;
import com.cms.backend.dashboard.model.DashboardFilterBodyDto;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DashboardService {

    private final DynamoService dynamoService;

    public DashboardService(DynamoService dynamoService) {
        this.dynamoService = dynamoService;
    }

    private void validateDateString(String date) {
        if (!date.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            throw new CustomException("Date Format Invalid");
        }
    }

    public List<DashboardCountDto> getDashboardData(String date) {
        validateDateString(date);
        try {
            List<DashboardCountDto> dashboardCountList = dynamoService.getAllDashboardData(date);
            processDashboardList(dashboardCountList);
            return dashboardCountList;

        } catch (Exception ex) {
            log.error("Exception: Error while getting dashboard data from dynamodb");
            throw new CustomException("Error while getting dashboard data from dynamo");
        }
    }

    public List<DashboardCountDto> getDashboardDataByCountry(
        DashboardFilterBodyDto dashboardFilterBodyDto) {
        validateDateString(dashboardFilterBodyDto.getDate());
        //For removing duplicate entries
        if (dashboardFilterBodyDto.getCountries() != null && !dashboardFilterBodyDto.getCountries()
            .isEmpty()) {
            dashboardFilterBodyDto.setCountries(
                dashboardFilterBodyDto.getCountries().stream().distinct().toList());
        }
        try {
            List<DashboardCountDto> dashboardCountList = new ArrayList<>();
            List<String>countriesHavingData = dynamoService.getCountriesHavingData(dashboardFilterBodyDto.getDate());
            if(countriesHavingData.isEmpty()){
                return dashboardCountList;
            }
            if (dashboardFilterBodyDto.getCountries() != null
                && !dashboardFilterBodyDto.getCountries().isEmpty()) {
                dashboardFilterBodyDto.setCountries(dashboardFilterBodyDto.getCountries().stream().filter(
                    countriesHavingData::contains
                ).toList());
                dashboardCountList = dynamoService.getDashboardDataByCountry(
                    dashboardFilterBodyDto.getDate(), dashboardFilterBodyDto.getCountries());
            } else {
                dashboardCountList = dynamoService.getAllDashboardData(
                    dashboardFilterBodyDto.getDate());
            }
            processDashboardList(dashboardCountList);
            dashboardCountList = filterIrrelevantItems(dashboardCountList);
            return dashboardCountList;

        } catch (Exception ex) {
            log.error("Exception: Error while getting dashboard data from dynamodb");
            throw new CustomException("Error while getting dashboard data from dynamo");
        }
    }

    public String getLastRunTime() {
        try {
            return dynamoService.getLastBatchRunTime();
        } catch (Exception ex) {
            log.error("Exception: Error while getting last batch run time from dynamodb");
            throw new CustomException("Error while getting last batch run time from dynamo");
        }

    }

    private void processDashboardList(List<DashboardCountDto> dashboardCountList) {
        dashboardCountList.stream().filter(
            dashboardCount -> dashboardCount.getRegionCountry().contains("_")
        ).forEach(dashboardCount -> {
            String[] regionCountry = dashboardCount.getRegionCountry().split("_");
            dashboardCount.setRegion(regionCountry[0]);
            dashboardCount.setCountryCode(regionCountry[1]);
        });
    }

    private List<DashboardCountDto> filterIrrelevantItems(List<DashboardCountDto> dashboardCountList){
        return dashboardCountList.stream().filter(this::check).toList();

    }

    private boolean check(DashboardCountDto dashboardCount) {
        return (dashboardCount.getCpTypeStatusTiWiseAssetsCountList() != null
            && !dashboardCount.getCpTypeStatusTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getCpTypeTiWiseAssetsCountList() != null
            && !dashboardCount.getCpTypeTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getCpTypeWiseAssetsCountList() != null
            && !dashboardCount.getCpTypeWiseAssetsCountList().isEmpty()
            && dashboardCount.getLicenseWindowTiWiseAssetsCountList() != null
            && !dashboardCount.getLicenseWindowTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getLicenseWindowWiseAssetsCountList() != null
            && !dashboardCount.getLicenseWindowWiseAssetsCountList().isEmpty()
            && dashboardCount.getStatusTiWiseAssetsCountList() != null
            && !dashboardCount.getStatusTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getStatusWiseAssetsCountList() != null
            && !dashboardCount.getStatusWiseAssetsCountList().isEmpty()
            && dashboardCount.getStatusTypeTiWiseAssetsCountList() != null
            && !dashboardCount.getStatusTypeTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getTypeTiWiseAssetsCountList() != null
            && !dashboardCount.getTypeTiWiseAssetsCountList().isEmpty()
            && dashboardCount.getTypeWiseAssetsCountList() != null
            && !dashboardCount.getTypeWiseAssetsCountList().isEmpty()
            && dashboardCount.getStatusTypeWiseAssetsCountList() != null
            && !dashboardCount.getStatusTypeWiseAssetsCountList().isEmpty());
    }

}
