package com.cms.backend.assets.service;


import static com.cms.backend.assets.service.AssetHelperService.FIELD_MAPPERS;
import static com.cms.backend.common.constants.Constants.QC_SYNC_FEED_WORKERS;

import com.cms.backend.assets.model.AssetCastDto;
import com.cms.backend.assets.model.AssetLockedFieldDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.MetaDataHistoryChangesDto;
import com.cms.backend.assets.model.ParentalRatingsDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.constants.ExcelHeadersConstants;
import com.cms.backend.common.enums.AssetColumns;
import com.cms.backend.common.enums.AssetFeedWorker;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.ResponseDto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.util.Pair;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.utils.CollectionUtils;

@Service
@Slf4j
public class AssetExcelEditService {

    ObjectMapper objectMapper = new ObjectMapper();
    private final AssetHelperService assetHelperService;
    private final AssetAsyncService assetAsyncService;
    private final AuthenticatedUser authenticatedUser;
    private final AssetMasterDataService assetMasterDataService;

    public AssetExcelEditService(AssetHelperService assetHelperService,
        AssetAsyncService assetAsyncService, AuthenticatedUser authenticatedUser,
        AssetMasterDataService assetMasterDataService) {
        this.assetHelperService = assetHelperService;
        this.assetAsyncService = assetAsyncService;
        this.authenticatedUser = authenticatedUser;
        this.assetMasterDataService = assetMasterDataService;
    }


    public boolean checkRecordExists(VodAssetDto vodAssetDto,
        List<VodAssetDto> oldVodAssetsDtos) {
        for (VodAssetDto oldVodAssetDto : oldVodAssetsDtos) {

            setGraceNoteFieldsNullImportTemplate(oldVodAssetDto, vodAssetDto);

            if (oldVodAssetDto.getContentId().equals(vodAssetDto.getContentId())
                && (oldVodAssetDto.getCountryCode()
                .equalsIgnoreCase(vodAssetDto.getCountryCode())) && (oldVodAssetDto.getVcCpId()
                .equalsIgnoreCase(vodAssetDto.getVcCpId()))) {
                //For valid records, set syncer fields based on status response
                setFieldsForSyncer(vodAssetDto, oldVodAssetDto);
                //For valid records, set syncer fields based on status response

                if (!deeplinkValidationInExcelUpload(oldVodAssetDto)) {
                    log.error("Validation in deeplink failed of contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Deeplink Payload failed");
                } else if (oldVodAssetDto.getStatus() == null
                    || !Constants.EDITABLE_STATUSES.contains(
                    oldVodAssetDto.getStatus().toLowerCase())) {
                    log.error("Validation in status failed of contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Status failed");
                } else if (
                    QC_SYNC_FEED_WORKERS.contains(oldVodAssetDto.getFeedWorker().toLowerCase())
                        && !Constants.QC_SYNC.equalsIgnoreCase(oldVodAssetDto.getDeltaType())) {
                    log.error("Validation in delta type failed of contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Delta type failed");
                } else if (!oldVodAssetDto.getType().equalsIgnoreCase(vodAssetDto.getType())) {
                    log.error("Validation in type failed of contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Type failed");
                } else if (!Constants.FEED_WORKERS.contains(
                    oldVodAssetDto.getFeedWorker().toLowerCase())) {
                    log.error("Validation in feed worker failed of contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("Feed Worker failed");
                } else if (!this.compareDataChanges(vodAssetDto, oldVodAssetDto)) {
                    log.info(
                        "Comparing data changes with previous data found, both are same so asset will not be ingested for contentId {}",
                        vodAssetDto.getContentId());
                    vodAssetDto.setResult("No change in asset");
                }
                return true;
            }
        }
        return false;
    }

    private boolean setCastForAssetUpload(String position, String newValues,
        VodAssetDto oldVodAsset, List<AssetCastDto> assetCastDtos) {
        boolean flag = false;
        if (newValues != null) {
            flag = true;
            List<String> splitStarring = Arrays.stream(newValues.split(",")).toList();
            for (String starring : splitStarring) {
                assetCastDtos.add(AssetCastDto.builder().role(position).name(starring).build());
            }
        } else if (oldVodAsset.getCast() != null) {
            for (AssetCastDto assetCastDto : oldVodAsset.getCast()) {
                if (assetCastDto.getRole().equalsIgnoreCase(position)) {
                    assetCastDtos.add(assetCastDto);
                }
            }
        }
        return flag;
    }

    public void setCastForAssetUpload(VodAssetDto asset, List<VodAssetDto> vodAssetDtos) {
        if (vodAssetDtos == null || ObjectUtils.isEmpty(vodAssetDtos)) {
            return;
        }
        VodAssetDto oldVodAsset = vodAssetDtos.get(0);
        List<AssetCastDto> assetCastDtos = new ArrayList<>();
        boolean flag = false;
        flag |= setCastForAssetUpload(Constants.ACTOR, asset.getStarring(), oldVodAsset,
            assetCastDtos);
        flag |= setCastForAssetUpload(Constants.DIRECTOR, asset.getDirector(), oldVodAsset,
            assetCastDtos);
        if (Constants.MUSIC.equalsIgnoreCase(asset.getType())) {
            flag |= setCastForAssetUpload(Constants.ARTIST, asset.getArtist(), oldVodAsset,
                assetCastDtos);
        }
        if (flag) {
            asset.setCast(assetCastDtos);
        } else {
            asset.setCast(null);
        }

    }

    public void setDeeplinkPayloadForExcelAsset(VodAssetDto asset,
        List<VodAssetDto> vodAssetDtos) {
        try {
            if (asset.getRatings() != null) {
                for (VodAssetDto vodAssetDto : vodAssetDtos) {
                    if (StringUtils.isNotEmpty(vodAssetDto.getDeeplinkPayload())) {
                        JsonObject jsonObject = JsonParser.parseString(
                            vodAssetDto.getDeeplinkPayload()).getAsJsonObject();
                        if (jsonObject != null && jsonObject.has(Constants.DEEPLINK_DATA)) {
                            JsonObject deeplinkData = jsonObject.getAsJsonObject(
                                Constants.DEEPLINK_DATA);
                            deeplinkData.addProperty(Constants.RATINGS, asset.getRatings());
                            asset.setDeeplinkPayload(jsonObject.toString());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Deeplink Payload failed of contentId {}", asset.getContentId());
            throw new AssetApiFailureException("Error while setting deeplinkPayload of asset");
        }
    }

    public void addHistoryForExcelUpdate(VodAssetDto asset, List<VodAssetDto> vodAssetDtos,
        List<String> columns) {
        try {
            if (ObjectUtils.isEmpty(vodAssetDtos)) {
                log.error("Error while getting asset data for history");
                return;
            }
            for (VodAssetDto vodAssetDto : vodAssetDtos) {
                triggerMetaHistory(asset, columns, vodAssetDto);
            }
        } catch (Exception e) {
            log.error("Error while asset history call: {}", e.getMessage());
        }
    }

    private void triggerMetaHistory(VodAssetDto asset, List<String> columns,
        VodAssetDto vodAssetDto) throws JsonProcessingException {
        Map<?, ?> assetEditMap = objectMapper.convertValue(asset, HashMap.class);
        List<String> history = new ArrayList<>();
        Map<?, ?> assetMap = objectMapper.convertValue(vodAssetDto, HashMap.class);
        for (String key : columns) {
            prepareMetadataHistoryForExcelByColumn(key, asset, vodAssetDto,
                assetEditMap, history,
                assetMap);
        }
        MetadataHistoryRequestDto metadataHistoryRequestDto = MetadataHistoryRequestDto.builder()
            .changes(history.toString())
            .updatedBy(authenticatedUser.getUserInfo().getUuid())  // Store userId, not userName
            .assetId(vodAssetDto.getContentId()).countryCode(asset.getCountryCode())
            .vcCpId(asset.getVcCpId()).build();
        if (!metadataHistoryRequestDto.getChanges().equals("[]")) {
            assetAsyncService.insertMetadataModificationHistory(metadataHistoryRequestDto);
        }
    }

    private boolean compareDataChanges(VodAssetDto vodEditAsset, VodAssetDto oldVodAsset) {
        try {
            Map<?, ?> assetEditMap = objectMapper.convertValue(vodEditAsset, HashMap.class);
            Map<?, ?> assetMap = objectMapper.convertValue(oldVodAsset, HashMap.class);

            List<String> list = new ArrayList<>(Constants.COMPARE_DATA_FIELDS);

            for (String key : list) {
                var oldValue = assetMap.get(key);
                var newValue = assetEditMap.get(key);
                if (newValue == null) {
                    continue;
                }

                if (!String.valueOf(oldValue).equals(String.valueOf(newValue))) {
                    return true;
                }
            }

            if (!areExternalIdListEqual(oldVodAsset.getExternalProvider(),
                vodEditAsset.getExternalProvider())) {
                return true;
            }
        } catch (Exception ex) {
            log.error("Error while asset column call: {}", ex.getMessage());
            throw new AssetApiFailureException("Error while comparing asset with previous data");
        }
        return false;
    }

    private boolean areExternalIdListEqual(List<ExternalProviderDto> oldList,
        List<ExternalProviderDto> newList) {
        if (newList == null) {
            return true;
        }
        if ((oldList == null) || oldList.size() != newList.size()) {
            return false;
        }
        Set<String> oldSet = oldList.stream()
            .map(ExternalProviderDto::generateProgramTypeProviderTuple).collect(Collectors.toSet());
        for (ExternalProviderDto externalIdDto : newList) {
            if (!oldSet.contains(externalIdDto.generateProgramTypeProviderTuple())) {
                return false;
            }
        }
        return true;
    }

    public String getRowValue(Row row, int index, Map<String, Integer> headerMap) {
        if (!headerMap.containsKey(Constants.EXCEL_HEADERS.get(index))) {
            return null;
        }
        Cell cell = row.getCell(headerMap.get(Constants.EXCEL_HEADERS.get(index)));
        if (cell == null) {
            return null;
        }
        DataFormatter fmt = new DataFormatter();
        String cellValue = fmt.formatCellValue(cell).trim();

        if (cellValue.isEmpty()) {
            return null;
        } else {
            return cellValue;
        }
    }

    private void prepareMetadataHistoryForExcelByColumn(String key, VodAssetDto asset,
        VodAssetDto vodAssetDto, Map<?, ?> assetEditMap, List<String> history, Map<?, ?> assetMap)
        throws JsonProcessingException {
        if (this.checkForColumnsToSkip(key, asset, vodAssetDto)) {
            return;
        }
        var oldValue = assetMap.get(key);
        var newValue = assetEditMap.get(key);
        if (Constants.PARENTAL_RATINGS.equalsIgnoreCase(key)) {
            List<String> oldAndNewParentalRatings = assetHelperService.setParentalRatingsForBulkEdit(
                vodAssetDto.getParentalRatings(), asset.getParentalRatings());
            oldValue = oldAndNewParentalRatings.get(0);
            newValue = oldAndNewParentalRatings.get(1);
        }
        if (Constants.CAST.equalsIgnoreCase(key)) {
            List<String> oldAndNewCast = assetHelperService.setCastByListForBulkEdit(
                vodAssetDto.getCast(),
                asset.getCast());
            oldValue = oldAndNewCast.get(0);
            newValue = oldAndNewCast.get(1);
        }
        if (Constants.AVAILABLE_STARTING.equalsIgnoreCase(key)
            || Constants.EXPIRY_DATE.equalsIgnoreCase(key)) {
            String date = (String) newValue;
            newValue = date.replace(" ", "T").replace("Z", "") + "Z";
        }
        if (Constants.DEEPLINK_PAYLOAD.equalsIgnoreCase(key) && (
            Constants.SHOW.equalsIgnoreCase(asset.getType()) || Constants.SEASON.equalsIgnoreCase(
                asset.getType()))) {
            return;
        }
        if (AssetColumns.EXTERNAL_PROVIDER_LIST.value.equalsIgnoreCase(key)) {
            Pair<Object, Object> result = this.handleExternalProviderChangeInExcel(assetEditMap,
                assetMap);
            oldValue = result.getSecond();
            newValue = result.getFirst();
            key = AssetColumns.EXTERNAL_PROVIDER.value;
        }
        if (!String.valueOf(oldValue).equals(String.valueOf(newValue))) {
            MetaDataHistoryChangesDto metaDataHistoryChangesDto = MetaDataHistoryChangesDto.builder()
                .oldValue(oldValue == null ? null : String.valueOf(oldValue))
                .newValue(String.valueOf(newValue)).key(key).build();
            history.add(objectMapper.writeValueAsString(metaDataHistoryChangesDto));
        }
    }

    private boolean checkForColumnsToSkip(String key, VodAssetDto asset,
        VodAssetDto vodAssetDto) {
        return List.of(Constants.IS_CMS_PROD, Constants.ASSET_STATUS, Constants.CONTENT_ID)
            .contains(key) || (Constants.CAST.equalsIgnoreCase(key)
            && (AssetHelperService.isSimilarList(
            vodAssetDto.getCast(), asset.getCast()))) || (
            Constants.PARENTAL_RATINGS.equalsIgnoreCase(key) && (AssetHelperService.isSimilarList(
                vodAssetDto.getParentalRatings(), asset.getParentalRatings())));
    }

    private Pair<Object, Object> handleExternalProviderChangeInExcel(
        Map<?, ?> assetEditMap, Map<?, ?> assetMap)
        throws JsonProcessingException {
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        List<ExternalProviderDto> oldList = objectMapper.convertValue(
            assetMap.get("externalProvider"), new TypeReference<>() {
            });
        if (!CollectionUtils.isNullOrEmpty(oldList)) {
            oldList.forEach(el -> el.setIdProvider(null));
        }
        List<ExternalProviderDto> newList = objectMapper.convertValue(
            assetEditMap.get("externalProvider"), new TypeReference<>() {
            });

        var oldValue =
            CollectionUtils.isNullOrEmpty(oldList) ? "" : objectMapper.writeValueAsString(oldList);
        var newValue =
            CollectionUtils.isNullOrEmpty(newList) ? "" : objectMapper.writeValueAsString(newList);

        return new Pair<>(newValue, oldValue);
    }

    private void setFieldsForSyncer(VodAssetDto vodAssetDto,
        VodAssetDto vodAssetStatusResponseDto) {
        vodAssetDto.setIsCmsProd(vodAssetStatusResponseDto.getIsCmsProd());
        vodAssetDto.setIsSyncBlocked(vodAssetStatusResponseDto.getIsSyncBlocked());
        vodAssetDto.setIsReleased(vodAssetStatusResponseDto.getIsReleased());
        vodAssetDto.setFeedWorker(vodAssetStatusResponseDto.getFeedWorker());
    }

    public void setExternalIDListForUpload(VodAssetDto asset, List<VodAssetDto> vodAssetDto) {
        List<ExternalProviderDto> list = new ArrayList<>();
        if (ObjectUtils.isEmpty(vodAssetDto)) {
            return;
        }
        VodAssetDto oldVodAsset = vodAssetDto.get(0);
        // if new value is present
        if (oldVodAsset != null && oldVodAsset.getExternalProvider() != null) {
            oldVodAsset.getExternalProvider()
                .forEach(externalProvider -> externalProvider.setIdProvider(null));
        }
        if (!ObjectUtils.isEmpty(asset.getExternalIdType()) && !ObjectUtils.isEmpty(
            asset.getExternalId()) && !ObjectUtils.isEmpty(asset.getExternalProvider())) {
            List<String> idTypes = Arrays.stream(asset.getExternalIdType().split(",")).toList();
            List<String> extPrgIds = Arrays.stream(asset.getExternalId().split(","))
                .toList();
            List<String> extProviders = Arrays.stream(asset.getExternalIdProvider().split(","))
                .toList();
            for (int i = 0; i < extPrgIds.size(); i++) {
                list.add(ExternalProviderDto.builder().idType(idTypes.get(i))
                    .externalProgramId(extPrgIds.get(i)).provider(extProviders.get(i)).build());
            }
            asset.setExternalProvider(list);
        } else if (oldVodAsset != null) {
            // getting old value from oracle
            asset.setExternalProvider(
                ObjectUtils.isEmpty(oldVodAsset.getExternalProvider()) ? List.of()
                    : oldVodAsset.getExternalProvider().stream().map(
                        provider -> ExternalProviderDto.builder().provider(provider.getProvider())
                            .externalProgramId(provider.getExternalProgramId())
                            .idType(provider.getIdType())
                            .build()).toList());
        }
    }

    public void setRatingListForUpload(VodAssetDto asset) {
        List<ParentalRatingsDto> list = new ArrayList<>();
        if (asset.getRatingBody() != null && asset.getRatings() != null) {
            List<String> inputRatingBodys = Arrays.stream(asset.getRatingBody().split(","))
                .toList();
            List<String> inputRatings = Arrays.stream(asset.getRatings().split(",")).toList();
            for (int i = 0; i < inputRatingBodys.size(); i++) {
                list.add(ParentalRatingsDto.builder().body(inputRatingBodys.get(i))
                    .ratings(inputRatings.get(i)).build());
            }
            asset.setParentalRatings(list);
        }
    }

    private boolean deeplinkValidationInExcelUpload(VodAssetDto vodAssetDto) {
        try {
            if (vodAssetDto.getDeeplinkPayload() != null) {
                var jsonObject = JsonParser.parseString(vodAssetDto.getDeeplinkPayload())
                    .getAsJsonObject();
                if (jsonObject != null && jsonObject.has(Constants.DEEPLINK_DATA)) {
                    jsonObject.getAsJsonObject(Constants.DEEPLINK_DATA);
                    return true;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    private void setGraceNoteFieldsNullImportTemplate(VodAssetDto oldVodAssetDto,
        VodAssetDto newVodAssetDto) {
        VodAssetDto tempVod = VodAssetDto.builder().feedWorker(oldVodAssetDto.getFeedWorker())
            .build();
        if (AssetFeedWorker.CMS_GRACENOTE.value.equalsIgnoreCase(oldVodAssetDto.getFeedWorker())
            || (AssetFeedWorker.TVPLUS_DELTA_GRACENOTE.value.equalsIgnoreCase(
            oldVodAssetDto.getFeedWorker())
            && Constants.QC_SYNC.equalsIgnoreCase(oldVodAssetDto.getDeltaType()))) {
            List<String> lockedFields = oldVodAssetDto.getLockedFields() == null ? List.of()
                : oldVodAssetDto.getLockedFields().stream().map(
                    AssetLockedFieldDto::getFieldName).toList();
            FIELD_MAPPERS.entrySet().forEach(entry -> {
                if (!lockedFields.contains(entry.getKey())) {
                    entry.getValue().accept(newVodAssetDto, tempVod);
                    if (entry.getKey().equalsIgnoreCase(AssetColumns.STARRING.value)) {
                        newVodAssetDto.setCast(null);
                    }
                }
            });
        }

    }

    public boolean headerValidationOfExcelSheet(XSSFSheet sheet, Map<String, Integer> headerMap) {
        try {
            Iterator<Row> rowIterator = sheet.iterator();
            if (rowIterator.hasNext()) {
                var row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    var cell = cellIterator.next();
                    if (cell == null) {
                        return false;
                    }
                    DataFormatter fmt = new DataFormatter();
                    String cellValue = fmt.formatCellValue(cell).trim().toLowerCase();
                    cellValue = cellValue.replace(" ", "");
                    if (!cellValue.isEmpty() && !Constants.EXCEL_HEADERS.contains(cellValue)) {
                        return false;
                    }
                    if (!cellValue.isEmpty() && !headerMap.containsKey(cellValue)) {
                        headerMap.put(cellValue, cell.getColumnIndex());
                    }
                }
            }
            return true;
        } catch (Exception e) {
            log.error("Exception in excel header validation: {}", e.getMessage());
            return false;
        }
    }

    public boolean emptyRowCheckInExcel(String contentId, String countryCode, String vcCpId) {
        return StringUtils.isEmpty(contentId) || StringUtils.isEmpty(countryCode)
            || StringUtils.isEmpty(vcCpId);
    }

    public List<RatingsDto> getMasterRatings() {
        ResponseDto ratings = assetMasterDataService.getRatings();
        ArrayList<RatingsDto> ratingsList = new ArrayList<>();
        if (ratings != null && ratings.getRsp() != null) {
            Map<String, Object> allRatings = ratings.getRsp().getPayload();
            var mapper = new ObjectMapper();
            ratingsList = mapper.convertValue(allRatings.get("ratings"), new TypeReference<>() {
            });
        }
        return ratingsList;
    }


    public VodAssetDto createValidVod(String contentId, String countryCode, String vcCpId, Row row,
        Map<String, Integer> headerMap, String result) {
        String userId = authenticatedUser.getUserInfo().getUuid();
        String region = authenticatedUser.getUserInfo().getServiceRegion();
        String sessionId = authenticatedUser.getUserInfo().getSessionId();
        VodAssetDto vodAssetDto = VodAssetDto.builder().contentId(contentId)
            .countryCode(countryCode).vcCpId(vcCpId).assetId(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.ASSET_ID),
                    headerMap))
            .type(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.PROGRAM_TYPE),
                    headerMap))
            .mainTitle(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.MAIN_TITLE),
                    headerMap))
            .shortTitle(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.SHORT_TITLE),
                    headerMap))
            .description(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.SYNOPSIS),
                    headerMap))
            .releaseDate(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.RELEASE_DATE),
                    headerMap))
            .genres(getRowValue(row,
                Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.GENRE), headerMap))
            .externalId(
                getRowValue(row, Constants.EXCEL_HEADERS.indexOf(
                        ExcelHeadersConstants.EXTERNAL_PROGRM_ID),
                    headerMap)).externalIdProvider(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.PROVIDER),
                    headerMap))
            .externalIdType(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.ID_TYPE),
                    headerMap))
            .contentPartner(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.CONTENT_PARTNER),
                    headerMap)).contentTier(
                getRowValue(row,
                    Constants.EXCEL_HEADERS.indexOf(ExcelHeadersConstants.CONTENT_TIER),
                    headerMap))
            .userId(userId).region(region).sessionId(sessionId).result(result).build();
        if (!Constants.MUSIC.equalsIgnoreCase(vodAssetDto.getType())) {
            vodAssetDto.setArtist(null);
        }
        return vodAssetDto;
    }
}
