package com.cms.backend.assets.aisearch.service;

import com.cms.backend.assets.aisearch.constant.AiSearchConstants;
import com.cms.backend.assets.aisearch.exception.SchemaUnavailableException;
import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.FilterSchema;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import java.io.InputStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class FilterSchemaProvider {

    private final ObjectMapper objectMapper;
    private volatile FilterSchema cached;

    // TODO O3: S3 loading. Task 12 (load the schema from S3 with periodic refresh)
    //   is intentionally deferred. The project exposes MULTIPLE configured
    //   software.amazon.awssdk.services.s3.S3Client beans
    //   (S3ClientConfig#amazonS3, S3Config#usAmazonS3/#euAmazonS3 and a region-aware
    //   RegionEndpointService#getS3Client), so autowiring a single client is ambiguous,
    //   and the final S3 bucket/key (open item O3) is not yet known. Wiring it now would
    //   not be low-risk and would threaten unit-test hermeticity. Until the bucket/key
    //   are finalized, the bundled classpath resource remains the source of truth.
    @PostConstruct
    public void init() {
        this.cached = loadFromClasspath();
        log.info("AI-search schema loaded: {} filters", cached.getFilters().size());
    }

    public FilterSchema getSchema() {
        if (cached == null) {
            cached = loadFromClasspath();
        }
        return cached;
    }

    public FilterKey getByKey(String key) {
        return getSchema().getFilters().stream()
                .filter(f -> f.getKey().equals(key))
                .findFirst()
                .orElse(null);
    }

    private FilterSchema loadFromClasspath() {
        try (InputStream in = new ClassPathResource(AiSearchConstants.SCHEMA_RESOURCE).getInputStream()) {
            return objectMapper.readValue(in, FilterSchema.class);
        } catch (Exception e) {
            throw new SchemaUnavailableException(
                    "Failed to load AI-search schema from classpath: " + AiSearchConstants.SCHEMA_RESOURCE, e);
        }
    }
}
