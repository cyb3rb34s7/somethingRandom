package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.FilterSchema;
import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Targets the rarely-hit branches of {@link SystemPromptBuilder} that the bundled schema never
 * exercises: a null content-hierarchy note, and a filter key with blank aliases plus null
 * description and notes (so only valid_values is appended).
 */
@ExtendWith(MockitoExtension.class)
class SystemPromptBuilderBranchTest {

    @Mock
    FilterSchemaProvider provider;

    private FilterKey key(String k, String type, List<String> values, List<String> aliases,
            boolean dynamic) {
        FilterKey fk = new FilterKey();
        fk.setKey(k);
        fk.setType(type);
        fk.setValues(values);
        fk.setAliases(aliases);
        fk.setDynamicValues(dynamic);
        // description and notes deliberately left null
        return fk;
    }

    @Test
    void rendersMinimalKeyWithNullHierarchyDescriptionNotesAndBlankAliases() {
        FilterSchema schema = new FilterSchema();
        schema.setContentHierarchyNote(null); // null hierarchy branch
        schema.setSemanticDateTokens(List.of("TODAY"));
        // bare key: blank aliases, null description, null notes, empty values -> "free text"
        FilterKey bare = key("bareKey", "search", List.of(), List.of(), false);
        schema.setFilters(List.of(bare));

        when(provider.getSchema()).thenReturn(schema);
        SystemPromptBuilder builder = new SystemPromptBuilder(provider);

        String prompt = builder.build(Map.of());
        assertThat(prompt).contains("key=\"bareKey\"");
        assertThat(prompt).contains("valid_values: free text");
        // no aliases segment because aliases were blank
        assertThat(prompt).doesNotContain("aliases:");
        // CONTENT HIERARCHY header still present with an empty body (no NPE)
        assertThat(prompt).contains("CONTENT HIERARCHY");
    }

    @Test
    void rendersFreeTextWhenStaticKeyHasNullValuesList() {
        FilterSchema schema = new FilterSchema();
        schema.setContentHierarchyNote("h");
        schema.setSemanticDateTokens(List.of("TODAY"));
        // static key whose values list is null -> exercises getValues()==null branch on line 93
        FilterKey nullValues = key("nullValKey", "filter", null, List.of("alias"), false);
        schema.setFilters(List.of(nullValues));

        when(provider.getSchema()).thenReturn(schema);
        SystemPromptBuilder builder = new SystemPromptBuilder(provider);

        String prompt = builder.build(Map.of());
        assertThat(prompt).contains("key=\"nullValKey\"");
        assertThat(prompt).contains("valid_values: free text");
    }

    @Test
    void rendersStaticValuesWhenPresentForBranchCoverage() {
        FilterSchema schema = new FilterSchema();
        schema.setContentHierarchyNote("hierarchy text");
        schema.setSemanticDateTokens(List.of("TODAY"));
        FilterKey withValues = key("colorKey", "filter", List.of("RED", "BLUE"), List.of("color"), false);
        schema.setFilters(List.of(withValues));

        when(provider.getSchema()).thenReturn(schema);
        SystemPromptBuilder builder = new SystemPromptBuilder(provider);

        String prompt = builder.build(Map.of());
        assertThat(prompt).contains("valid_values: RED, BLUE");
        assertThat(prompt).contains("aliases: color");
        assertThat(prompt).contains("hierarchy text");
    }
}
