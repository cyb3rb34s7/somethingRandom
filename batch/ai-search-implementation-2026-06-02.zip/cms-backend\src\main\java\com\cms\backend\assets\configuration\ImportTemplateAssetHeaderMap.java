package com.cms.backend.assets.configuration;

import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Generated;

@Generated
public class ImportTemplateAssetHeaderMap {

    private ImportTemplateAssetHeaderMap() {
        throw new IllegalStateException("AssetHeaderMap class");
    }

    public static Map<String, String> getMap() {
        Map<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put("programid", "Program ID");
        assetHeader.put("assetid", "Asset Id");
        assetHeader.put("programtype", "Program Type");
        assetHeader.put("country", "Country");
        assetHeader.put("providerid", "Provider ID");
        assetHeader.put("maintitle", "Main Title");
        assetHeader.put("maintitlelanguage", "Main Title Language");
        assetHeader.put("shorttitle", "Short Title");
        assetHeader.put("shorttitlelanguage", "Short Title Language");
        assetHeader.put("duration(sec)", "Duration (Sec)");
        assetHeader.put("adtags", "Ad tags");
        assetHeader.put("streamurl", "Stream URL");
        assetHeader.put("descriptionlanguage", "Description Language");
        assetHeader.put("synopsis", "Synopsis");
        assetHeader.put("originalreleasedate", "Original Release Date");
        assetHeader.put("genre", "Genre");
        assetHeader.put("externalprogramid", "External Program Id");
        assetHeader.put("provider", "Provider");
        assetHeader.put("idtype", "ID Type");
        assetHeader.put("contentpartner/licensor", "Content Partner/Licensor");
        assetHeader.put("contenttier", "Content Tier");
        return assetHeader;
    }
}
