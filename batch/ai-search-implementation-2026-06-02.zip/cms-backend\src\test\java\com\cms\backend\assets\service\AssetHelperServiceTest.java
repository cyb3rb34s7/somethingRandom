package com.cms.backend.assets.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.anyString;

import com.cms.backend.assets.model.AssetCastDto;
import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetLockedFieldDto;
import com.cms.backend.assets.model.ParentalRatingsDto;
import com.cms.backend.assets.model.StatusGetDto;
import com.cms.backend.assets.model.StatusUpdateDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.util.UpdateAssetUtils;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetFeedWorker;
import com.cms.backend.common.enums.AssetGracenoteFields;
import com.cms.backend.common.enums.AssetStatus;
import com.cms.backend.common.enums.AssetTypes;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;


class AssetHelperServiceTest {

    @Mock
    private UpdateAssetUtils updateAssetUtils;

    @Mock
    private RegionEndpointService regionEndpointService;

    @Mock
    private HttpMethodHandler httpMethodHandler;

    private AssetHelperService assetHelperService;
    private ObjectMapper objectMapper;

    @Mock
    private AssetHelperService spyService;

    @Mock
    private AssetExcelEditService assetExcelEditService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        objectMapper = new ObjectMapper();
        assetHelperService = new AssetHelperService(updateAssetUtils, regionEndpointService,
            httpMethodHandler);
        assetHelperService.objMapper = objectMapper;
        ReflectionTestUtils.setField(assetHelperService, "deploymentEnv", "blue");
        spyService = spy(assetHelperService);
    }


    @Test
    void prepareMetadataHistoryForPortalByColumn_CastDifferent() throws JsonProcessingException {
        String key = Constants.CAST;
        List<AssetCastDto> oldCast = List.of(AssetCastDto.builder().name("A").build());
        List<AssetCastDto> newCast = List.of(AssetCastDto.builder().name("B").build());
        VodAssetDto oldAsset = VodAssetDto.builder().cast(oldCast).build();
        VodAssetDto newAsset = VodAssetDto.builder().cast(newCast).build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, newCast));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, oldCast));
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(1, history.size());
        String entry = history.get(0);
        assertTrue(entry.contains("A") && entry.contains("B"));
    }


    @Test
    void prepareMetadataHistoryForPortalByColumn_GeneralValueChange()
        throws JsonProcessingException {
        String key = "mainTitle";
        String oldValue = "Old Title";
        String newValue = "New Title";
        VodAssetDto oldAsset = VodAssetDto.builder().mainTitle(oldValue).build();
        VodAssetDto newAsset = VodAssetDto.builder().mainTitle(newValue).build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, newValue));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, oldValue));
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(1, history.size());
        String entry = history.get(0);
        assertTrue(entry.contains(oldValue) && entry.contains(newValue) && entry.contains(key));
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_DeeplinkValueChange()
        throws JsonProcessingException {
        String key = "deeplinkPayload";
        String oldValue = "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"Test_AvinashB_EPI_1_ran\",\"ratings\":\"\",\"event\":\"Y\",\"event_info\":{\"event_starttime\":\"2025-06-01T14:51:26Z\",\"event_endtime\":\"2025-06-02T14:51:28Z\"}}}";
        String newValue = "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"Test_AvinashB_EPI_1_ran\",\"ratings\":\"\",\"event\":\"Y\",\"event_info\":{\"event_starttime\":\"2025-06-01T14:51:26Z\",\"event_endtime\":\"2025-06-02T14:51:28Z\"}}}";

        VodAssetDto oldAsset = VodAssetDto.builder().mainTitle(oldValue).build();
        VodAssetDto newAsset = VodAssetDto.builder().mainTitle(newValue).build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, newValue));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, oldValue));
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(1, history.size());
        String entry = history.get(0);
        assertTrue(entry.contains(key));
    }


    @Test
    void setDeepLinkPayloadOfPortal_MissingDeeplinkData() {
        String oldPayload = "{}";
        VodAssetDto asset = VodAssetDto.builder().build();

        Exception exception = assertThrows(AssetApiFailureException.class, () -> {
            spyService.setDeepLinkPayloadOfPortal(asset, oldPayload);
        });

        assertEquals("Error while in updating deeplink Payload", exception.getMessage());
    }


    @Test
    void blockGracenoteLockedFields_WithMatchingContentIds() {
        // Create old asset with Gracenote feed worker and locked fields
        List<AssetLockedFieldDto> lockedFields = List.of(
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.DESCRIPTION.value).build(),
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.DIRECTOR.value).build()
        );

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("123")
            .feedWorker(AssetFeedWorker.CMS_GRACENOTE.value)
            .lockedFields(lockedFields)
            .description("Old Description")
            .director("Old Director")
            .mainTitle("Old Title")
            .build();

        // Create new asset with same contentId but different values
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("123")
            .description("New Description")
            .director("New Director")
            .mainTitle("New Title")
            .build();

        List<VodAssetDto> oldVodList = List.of(oldAsset);
        List<VodAssetDto> newVodList = List.of(newAsset);

        // Execute the method
        assetHelperService.blockGracenoteLockedFields(newVodList, oldVodList);

        // Verify that locked fields (description, director) retain their new values (since they are locked)
        // but unlocked fields (mainTitle) are set to null
        assertEquals("New Description", newAsset.getDescription());
        assertEquals("New Director", newAsset.getDirector());
        assertNull(newAsset.getMainTitle());
    }

    @Test
    void blockGracenoteLockedFields_NonGracenoteFeedWorker() {
        // Create old asset with non-Gracenote feed worker
        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("123")
            .feedWorker(AssetFeedWorker.CMS.value)
            .description("Old Description")
            .build();

        // Create new asset with same contentId
        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("123")
            .description("New Description")
            .build();

        List<VodAssetDto> oldVodList = List.of(oldAsset);
        List<VodAssetDto> newVodList = List.of(newAsset);

        // Execute the method
        assetHelperService.blockGracenoteLockedFields(newVodList, oldVodList);

        // Verify that fields are updated since it's not a Gracenote feed
        assertEquals("New Description", newAsset.getDescription());
    }

    @Test
    void blockGracenoteLockedFields_NoMatchingContentIds() {
        // Create assets with different contentIds
        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("123")
            .feedWorker(AssetFeedWorker.CMS_GRACENOTE.value)
            .description("Old Description")
            .build();

        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("456")
            .description("New Description")
            .build();

        List<VodAssetDto> oldVodList = List.of(oldAsset);
        List<VodAssetDto> newVodList = List.of(newAsset);

        // Execute the method
        assetHelperService.blockGracenoteLockedFields(newVodList, oldVodList);

        // Verify that fields are updated since contentIds don't match
        assertEquals("New Description", newAsset.getDescription());
    }

    @Test
    void setGraceNoteFieldsNull_WithLockedFields() {
        // Create old asset with Gracenote feed worker and locked fields
        List<AssetLockedFieldDto> lockedFields = List.of(
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.DESCRIPTION.value).build(),
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.DIRECTOR.value).build()
        );

        VodAssetDto oldAsset = VodAssetDto.builder()
            .feedWorker(AssetFeedWorker.CMS_GRACENOTE.value)
            .lockedFields(lockedFields)
            .description("Old Description")
            .director("Old Director")
            .mainTitle("Old Title")
            .build();

        // Create new asset with different values
        VodAssetDto newAsset = VodAssetDto.builder()
            .description("New Description")
            .director("New Director")
            .mainTitle("New Title")
            .build();

        // Execute the method
        assetHelperService.setGraceNoteFieldsNull(oldAsset, newAsset);

        // Verify that locked fields (description, director) retain their new values (since they are locked)
        // but unlocked fields (mainTitle) are set to null
        assertEquals("New Description", newAsset.getDescription());
        assertEquals("New Director", newAsset.getDirector());
        assertNull(newAsset.getMainTitle());
    }

    @Test
    void setGraceNoteFieldsNull_NonGracenoteFeedWorker() {
        // Create old asset with non-Gracenote feed worker
        VodAssetDto oldAsset = VodAssetDto.builder()
            .feedWorker(AssetFeedWorker.CMS.value)
            .description("Old Description")
            .build();

        // Create new asset with different values
        VodAssetDto newAsset = VodAssetDto.builder()
            .description("New Description")
            .build();

        // Execute the method
        assetHelperService.setGraceNoteFieldsNull(oldAsset, newAsset);

        // Verify that fields remain unchanged since it's not a Gracenote feed
        assertEquals("New Description", newAsset.getDescription());
    }

    @Test
    void setGraceNoteFieldsNull_WithStarringField() {
        // Create old asset with Gracenote feed worker and locked starring field
        List<AssetLockedFieldDto> lockedFields = List.of(
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.STARRING.value).build()
        );

        VodAssetDto oldAsset = VodAssetDto.builder()
            .feedWorker(AssetFeedWorker.CMS_GRACENOTE.value)
            .lockedFields(lockedFields)
            .starring("Old Starring")
            .build();

        // Create new asset with different values and cast
        List<AssetCastDto> newCast = List.of(AssetCastDto.builder().name("New Actor").build());
        VodAssetDto newAsset = VodAssetDto.builder()
            .starring("New Starring")
            .cast(newCast)
            .build();

        // Execute the method
        assetHelperService.setGraceNoteFieldsNull(oldAsset, newAsset);

        // Verify that starring field is preserved (since it is locked) and cast is not set to null (since starring is locked)
        assertEquals("New Starring", newAsset.getStarring());
        assertEquals(newCast, newAsset.getCast());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_DeeplinkValueChange_WithRatings()
        throws JsonProcessingException {
        String key = "deeplinkPayload";
        String oldValue = "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"test_content\",\"ratings\":\"old_rating\"}}";

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        VodAssetDto newAsset = VodAssetDto.builder()
            .ratings("new_rating")
            .build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, oldValue));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, oldValue));
        List<String> history = new ArrayList<>();

        // Mock the updateAssetUtils to avoid null pointer exception
        when(updateAssetUtils.findUpdateSlot(newAsset.getEventWindowList())).thenReturn(null);

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(1, history.size());
        // Just verify that we have a history entry
        assertFalse(history.isEmpty());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_DeeplinkValueChange_WithEventWindow()
        throws JsonProcessingException {
        String key = "deeplinkPayload";
        String oldValue = "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"test_content\"}}";

        // Create event window
        AssetEventWindowDto eventWindow = AssetEventWindowDto.builder()
            .eventStarting("2025-01-01T00:00:00Z")
            .eventEnding("2025-01-01T01:00:00Z")
            .build();

        VodAssetDto oldAsset = VodAssetDto.builder().build();
        VodAssetDto newAsset = VodAssetDto.builder()
            .eventWindowList(List.of(eventWindow))
            .build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, oldValue));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, oldValue));
        List<String> history = new ArrayList<>();

        // Mock the updateAssetUtils to return our event window
        when(updateAssetUtils.findUpdateSlot(newAsset.getEventWindowList())).thenReturn(
            eventWindow);

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(1, history.size());
        // Just verify that we have a history entry
        assertFalse(history.isEmpty());
    }

    @Test
    void setParentalRatingsForBulkEditTest() throws JsonProcessingException {
        List<ParentalRatingsDto> oldRatings = List.of(
            ParentalRatingsDto.builder().ratings("PG").build());
        List<ParentalRatingsDto> newRatings = List.of(
            ParentalRatingsDto.builder().ratings("PG-13").build());

        List<String> result = assetHelperService.setParentalRatingsForBulkEdit(oldRatings,
            newRatings);

        assertEquals(2, result.size());
        assertFalse(result.get(0).isEmpty());
        assertFalse(result.get(1).isEmpty());
    }

    @Test
    void convertObjectArrayToStringTest() throws JsonProcessingException {
        List<AssetCastDto> castList = List.of(AssetCastDto.builder().name("Actor1").build());
        String result = AssetHelperService.convertObjectArrayToString(castList);
        assertFalse(result.isEmpty());
        assertTrue(result.contains("Actor1"));
    }

    @Test
    void convertObjectArrayToStringTest_NullInput() throws JsonProcessingException {
        String result = AssetHelperService.convertObjectArrayToString(null);
        assertEquals("[]", result);
    }

    @Test
    void isSimilarListTest_BothNull() {
        boolean result = AssetHelperService.isSimilarList(null, null);
        assertTrue(result);
    }

    @Test
    void isSimilarListTest_FirstNull() {
        List<AssetCastDto> list = List.of(AssetCastDto.builder().name("Actor1").build());
        boolean result = AssetHelperService.isSimilarList(null, list);
        assertFalse(result);
    }

    @Test
    void isSimilarListTest_SecondNull() {
        List<AssetCastDto> list = List.of(AssetCastDto.builder().name("Actor1").build());
        boolean result = AssetHelperService.isSimilarList(list, null);
        assertFalse(result);
    }

    @Test
    void isSimilarListTest_DifferentSizes() {
        List<AssetCastDto> list1 = List.of(AssetCastDto.builder().name("Actor1").build());
        List<AssetCastDto> list2 = List.of(
            AssetCastDto.builder().name("Actor1").build(),
            AssetCastDto.builder().name("Actor2").build()
        );
        boolean result = AssetHelperService.isSimilarList(list1, list2);
        assertFalse(result);
    }

    @Test
    void isSimilarListTest_DifferentElements() {
        List<AssetCastDto> list1 = List.of(AssetCastDto.builder().name("Actor1").build());
        List<AssetCastDto> list2 = List.of(AssetCastDto.builder().name("Actor2").build());
        boolean result = AssetHelperService.isSimilarList(list1, list2);
        assertFalse(result);
    }

    @Test
    void isSimilarListTest_IdenticalElements() {
        List<AssetCastDto> list1 = List.of(AssetCastDto.builder().name("Actor1").build());
        List<AssetCastDto> list2 = List.of(AssetCastDto.builder().name("Actor1").build());
        boolean result = AssetHelperService.isSimilarList(list1, list2);
        assertTrue(result);
    }


    @Test
    void modifyDeeplinkOnEventChangeTest_NullEventWindowList() {
        VodAssetDto vodAsset = VodAssetDto.builder().build();
        com.google.gson.JsonObject deeplinkData = new com.google.gson.JsonObject();
        deeplinkData.addProperty("event", "Y");

        assetHelperService.modifyDeeplinkOnEventChange(vodAsset, deeplinkData);

        assertFalse(deeplinkData.has("event"));
        assertFalse(deeplinkData.has("event_info"));
    }

    @Test
    void modifyDeeplinkOnEventChangeTest_EmptyEventWindowList() {
        VodAssetDto vodAsset = VodAssetDto.builder().eventWindowList(new ArrayList<>()).build();
        com.google.gson.JsonObject deeplinkData = new com.google.gson.JsonObject();
        deeplinkData.addProperty("event", "Y");

        assetHelperService.modifyDeeplinkOnEventChange(vodAsset, deeplinkData);

        assertFalse(deeplinkData.has("event"));
        assertFalse(deeplinkData.has("event_info"));
    }

    @Test
    void setDeepLinkPayloadOfPortalTest_Success() {
        String oldPayload = "{\"deeplink_data\":{\"content_type\":\"episodic\",\"content_id\":\"test_content\",\"ratings\":\"old_rating\"}}";
        VodAssetDto asset = VodAssetDto.builder().ratings("new_rating").build();

        AssetEventWindowDto eventWindow = AssetEventWindowDto.builder()
            .eventStarting("2025-01-01T00:00:00Z")
            .eventEnding("2025-01-01T01:00:00Z")
            .build();

        when(updateAssetUtils.findUpdateSlot(any())).thenReturn(eventWindow);

        assertDoesNotThrow(() -> {
            assetHelperService.setDeepLinkPayloadOfPortal(asset, oldPayload);
        });

        assertNotNull(asset.getDeeplinkPayload());
        assertTrue(asset.getDeeplinkPayload().contains("new_rating"));
    }

    @Test
    void blockGracenoteLockedFields_TVPlusDeltaGracenoteFeedWorker() {
        List<AssetLockedFieldDto> lockedFields = List.of(
            AssetLockedFieldDto.builder().fieldName(AssetGracenoteFields.DESCRIPTION.value).build()
        );

        VodAssetDto oldAsset = VodAssetDto.builder()
            .contentId("123")
            .feedWorker(AssetFeedWorker.TVPLUS_DELTA_GRACENOTE.value)
            .lockedFields(lockedFields)
            .description("Old Description")
            .mainTitle("Old Title")
            .build();

        VodAssetDto newAsset = VodAssetDto.builder()
            .contentId("123")
            .description("New Description")
            .mainTitle("New Title")
            .build();

        List<VodAssetDto> oldVodList = List.of(oldAsset);
        List<VodAssetDto> newVodList = List.of(newAsset);

        assetHelperService.blockGracenoteLockedFields(newVodList, oldVodList);

        assertEquals("New Description", newAsset.getDescription());
        assertNull(newAsset.getMainTitle());
    }

    @Test
    void extractSeasonShowListTest_EpisodeType() {
        AssetKeyDto episodeAsset = AssetKeyDto.builder()
            .contentId("episode1")
            .type(AssetTypes.EPISODE.value)
            .seasonId("season1")
            .showId("show1")
            .vcCpId("vcCpId")
            .countryCode("AA")
            .build();

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(List.of(episodeAsset))
            .build();

        List<AssetKeyDto> result = assetHelperService.extractSeasonShowList(statusUpdateDto);

        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(asset -> "season1".equals(asset.getContentId())));
        assertTrue(result.stream().anyMatch(asset -> "show1".equals(asset.getContentId())));
    }

    @Test
    void extractSeasonShowListTest_SeasonType() {
        AssetKeyDto seasonAsset = AssetKeyDto.builder()
            .contentId("season1")
            .type(AssetTypes.SEASON.value)
            .showId("show1")
            .vcCpId("vcCpId")
            .countryCode("AA")
            .build();

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(List.of(seasonAsset))
            .build();

        List<AssetKeyDto> result = assetHelperService.extractSeasonShowList(statusUpdateDto);

        assertEquals(1, result.size());
        assertEquals("show1", result.get(0).getContentId());
    }

    @Test
    void extractSeasonShowListTest_OtherType() {
        AssetKeyDto movieAsset = AssetKeyDto.builder()
            .contentId("movie1")
            .type(AssetTypes.MOVIE.value)
            .vcCpId("vcCpId")
            .countryCode("AA")
            .build();

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(List.of(movieAsset))
            .build();

        List<AssetKeyDto> result = assetHelperService.extractSeasonShowList(statusUpdateDto);

        assertEquals(0, result.size());
    }

    @Test
    void validateAssetUpdateTest_NullType() {
        VodAssetDto vodAsset = VodAssetDto.builder().build();
        List<VodAssetDto> vodAssetList = List.of(vodAsset);

        assertDoesNotThrow(() -> {
            assetHelperService.validateAssetUpdate(vodAssetList, null);
        });
    }


    @Test
    void validateStatusForEditingTest_UntrackableStatus() {
        VodAssetDto vodAsset = VodAssetDto.builder().status(AssetStatus.UNTRACKABLE.value).build();
        VodAssetDto targetAsset = VodAssetDto.builder().build();
        List<VodAssetDto> vodAssetList = List.of(vodAsset);

        Exception exception = assertThrows(CustomException.class, () -> {
            assetHelperService.validateStatusForEditing(targetAsset, vodAssetList);
        });

        assertEquals("Asset is  Not Editable", exception.getMessage());
    }

    @Test
    void getEditColumnsForHistoryTest() {
        VodAssetDto vodAsset = VodAssetDto.builder().contentId("test").mainTitle("title").build();

        List<String> result = assetHelperService.getEditColumnsForHistory(vodAsset);

        assertTrue(result.contains(Constants.CONTENT_ID));
        assertTrue(result.contains("mainTitle"));
    }

    @Test
    void getColumnsForHistoryTest() {
        VodAssetDto vodAsset = VodAssetDto.builder().contentId("test").mainTitle("title").build();

        List<String> result = assetHelperService.getColumnsForHistory(vodAsset);

        assertTrue(result.contains(Constants.CONTENT_ID));
        assertTrue(result.contains("mainTitle"));
    }

    @Test
    void isEditAllowedTest_UntrackableStatus() {
        VodAssetDto vodAsset = VodAssetDto.builder().status(AssetStatus.UNTRACKABLE.value).build();
        List<VodAssetDto> vodAssetList = List.of(vodAsset);

        Exception exception = assertThrows(CustomException.class, () -> {
            assetHelperService.isEditAllowed(vodAssetList);
        });

        assertEquals("Asset is  Not Editable", exception.getMessage());
    }

    @Test
    void isEditAllowedTest_InvalidFeedWorker() {
        ReflectionTestUtils.setField(assetHelperService, "feedWorkerList", "CMS,CMS_GRACENOTE");
        VodAssetDto vodAsset = VodAssetDto.builder().feedWorker("INVALID_FEED_WORKER").build();
        List<VodAssetDto> vodAssetList = List.of(vodAsset);

        Exception exception = assertThrows(CustomException.class, () -> {
            assetHelperService.isEditAllowed(vodAssetList);
        });

        assertEquals("Asset is not editable for this feed worker", exception.getMessage());
    }

    @Test
    void getImageListTest() {
        List<String> result = assetHelperService.getImageList("landscape", "portrait", "iconic",
            "portrait_iconic", "circle");

        assertEquals(5, result.size());
        assertTrue(result.contains("landscape"));
        assertTrue(result.contains("portrait"));
        assertTrue(result.contains("iconic"));
        assertTrue(result.contains("portrait_iconic"));
        assertTrue(result.contains("circle"));
    }

    @Test
    void getImageListTest_EmptyStrings() {
        List<String> result = assetHelperService.getImageList("", "", "", "", "");

        assertEquals(0, result.size());
    }

    @Test
    void validateDeploymentEnvTest_AAXFCountries() {
        AssetKeyDto asset = AssetKeyDto.builder().countryCode("AA").build();
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(List.of(asset))
            .status(AssetStatus.QC_PASS.value)
            .build();

        assertDoesNotThrow(() -> {
            assetHelperService.validateDeploymentEnv(statusUpdateDto);
        });
    }

    @Test
    void validateDeploymentEnvTest_GreenEnv_QCPass() {
        ReflectionTestUtils.setField(assetHelperService, "deploymentEnv", "green");
        AssetKeyDto asset = AssetKeyDto.builder().countryCode("US").build();
        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(List.of(asset))
            .status(AssetStatus.QC_PASS.value)
            .build();

        Exception exception = assertThrows(CustomException.class, () -> {
            assetHelperService.validateDeploymentEnv(statusUpdateDto);
        });

        assertEquals("Asset is not Editable in green env", exception.getMessage());
    }

    @Test
    void modifyStatusUpdateRequestBodyTest() {
        AssetKeyDto processingAsset = AssetKeyDto.builder()
            .contentId("content1")
            .countryCode("AA")
            .vcCpId("vcCpId")
            .build();

        AssetKeyDto otherAsset = AssetKeyDto.builder()
            .contentId("content2")
            .countryCode("AA")
            .vcCpId("vcCpId")
            .build();

        VodAssetDto processingVodAsset = VodAssetDto.builder()
            .contentId("content1")
            .countryCode("AA")
            .vcCpId("vcCpId")
            .build();

        VodAssetDto otherVodAsset = VodAssetDto.builder()
            .contentId("content2")
            .countryCode("AA")
            .vcCpId("vcCpId")
            .build();

        StatusUpdateDto statusUpdateDto = StatusUpdateDto.builder()
            .assetList(new ArrayList<>(List.of(processingAsset, otherAsset)))
            .build();

        List<VodAssetDto> vodAssetDtoList = new ArrayList<>(
            List.of(processingVodAsset, otherVodAsset));

        assetHelperService.modifyStatusUpdateRequestBody(statusUpdateDto, List.of(processingAsset),
            vodAssetDtoList);

        assertEquals(1, statusUpdateDto.getAssetList().size());
        assertEquals(1, vodAssetDtoList.size());
        assertEquals("content2", statusUpdateDto.getAssetList().get(0).getContentId());
        assertEquals("content2", vodAssetDtoList.get(0).getContentId());
    }

    @Test
    void getAssetStatusByAPI_Test() {
        StatusGetDto statusGetDto = StatusGetDto.builder().build();
        ResponseDto responseDto = ResponseDto.builder().build();
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(responseDto);

        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test.com");
        when(httpMethodHandler.handleHttpExchange(anyString(), anyString(), any(),
            eq(ResponseDto.class)))
            .thenReturn(responseEntity);

        Exception exception = assertThrows(AssetApiFailureException.class, () -> {
            assetHelperService.getAssetStatusByAPI(statusGetDto);
        });

        assertEquals("Error while getting asset status", exception.getMessage());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_SkippedKeys() throws JsonProcessingException {
        List<String> skippedKeys = List.of(Constants.IS_CMS_PROD, Constants.ASSET_STATUS,
            Constants.CONTENT_ID, "lockedFields");

        for (String key : skippedKeys) {
            VodAssetDto oldAsset = VodAssetDto.builder().build();
            VodAssetDto newAsset = VodAssetDto.builder().build();
            Map<String, Object> assetMap = new HashMap<>();
            Map<String, Object> assetMapResult = new HashMap<>();
            List<String> history = new ArrayList<>();

            assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
                assetMap, assetMapResult, history);

            assertEquals(0, history.size(), "Key " + key + " should be skipped");
        }
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_CastNull() throws JsonProcessingException {
        String key = Constants.CAST;
        VodAssetDto oldAsset = VodAssetDto.builder().build();
        VodAssetDto newAsset = VodAssetDto.builder().cast(null).build();
        Map<String, Object> assetMap = new HashMap<>();
        Map<String, Object> assetMapResult = new HashMap<>();
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(0, history.size());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_ParentalRatingsSimilar()
        throws JsonProcessingException {
        String key = Constants.PARENTAL_RATINGS;
        List<ParentalRatingsDto> ratings = List.of(
            ParentalRatingsDto.builder().ratings("PG").build());
        VodAssetDto oldAsset = VodAssetDto.builder().parentalRatings(ratings).build();
        VodAssetDto newAsset = VodAssetDto.builder().parentalRatings(ratings).build();
        Map<String, Object> assetMap = new HashMap<>();
        Map<String, Object> assetMapResult = new HashMap<>();
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(0, history.size());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_LicenseWindowList()
        throws JsonProcessingException {
        String key = Constants.LICENSE_WINDOW_LIST;
        VodAssetDto oldAsset = VodAssetDto.builder().build();
        VodAssetDto newAsset = VodAssetDto.builder().build();
        Map<String, Object> assetMap = new HashMap<>();
        Map<String, Object> assetMapResult = new HashMap<>();
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(0, history.size());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_EventWindowList() throws JsonProcessingException {
        String key = Constants.EVENT_WINDOW_LIST;
        VodAssetDto oldAsset = VodAssetDto.builder().build();
        VodAssetDto newAsset = VodAssetDto.builder().build();
        Map<String, Object> assetMap = new HashMap<>();
        Map<String, Object> assetMapResult = new HashMap<>();
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(0, history.size());
    }

    @Test
    void prepareMetadataHistoryForPortalByColumn_NoChange() throws JsonProcessingException {
        String key = "title";
        VodAssetDto oldAsset = VodAssetDto.builder().mainTitle("Same Title").build();
        VodAssetDto newAsset = VodAssetDto.builder().mainTitle("Same Title").build();
        Map<String, Object> assetMap = new HashMap<>(Map.of(key, "Same Title"));
        Map<String, Object> assetMapResult = new HashMap<>(Map.of(key, "Same Title"));
        List<String> history = new ArrayList<>();

        assetHelperService.prepareMetadataHistoryForPortalByColumn(key, oldAsset, newAsset,
            assetMap, assetMapResult, history);

        assertEquals(0, history.size());
    }


}
