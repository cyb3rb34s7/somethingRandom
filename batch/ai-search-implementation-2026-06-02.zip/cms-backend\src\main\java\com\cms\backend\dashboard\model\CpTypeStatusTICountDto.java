package com.cms.backend.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Builder
@Getter
@Setter
@DynamoDbBean
@NoArgsConstructor
@AllArgsConstructor
public class CpTypeStatusTICountDto {


    private String cpName;
    private String techIntegrator;
    private String assetType;
    private String assetStatus;
    private int assetsCount;

    @DynamoDbAttribute("cp_name")
    public String getCpName() {
        return cpName;
    }

    @DynamoDbAttribute("tech_integrator")
    public String getTechIntegrator() {
        return techIntegrator;
    }

    @DynamoDbAttribute("asset_type")
    public String getAssetType() {
        return assetType;
    }

    @DynamoDbAttribute("asset_status")
    public String getAssetStatus() {
        return assetStatus;
    }

    @DynamoDbAttribute("assets_count")
    public int getAssetsCount() {
        return assetsCount;
    }
}
