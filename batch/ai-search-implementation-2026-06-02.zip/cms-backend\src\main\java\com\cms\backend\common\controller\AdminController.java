package com.cms.backend.common.controller;

import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import java.util.HashMap;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

    @GetMapping(value = "/admin/ping")
    public ResponseDto healthCheck() {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(Constants.ASSET_STATUS, "ok");
        return ResponseDto.builder().rsp(BaseResponseDto.builder().payload(payload).build())
            .build();
    }

}