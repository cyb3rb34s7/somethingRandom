package com.cms.backend.changehistory.controller;

import com.cms.backend.changehistory.model.ChangeHistoryFilterBodyDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.LockHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.changehistory.service.ChangeHistoryService;
import com.cms.backend.common.model.ResponseDto;
import jakarta.validation.Valid;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/admin/history")
@RestController
@Validated
public class ChangeHistoryController {

    private final ChangeHistoryService assetService;

    public ChangeHistoryController(ChangeHistoryService assetService) {
        this.assetService = assetService;
    }

    @PostMapping("/license/add")
    public ResponseDto addLicenseHistory(@RequestBody LicenseHistoryRequestDto licensePostBody) {
        return assetService.addLicenseHistory(licensePostBody);
    }

    @PostMapping("/license/get")
    public ResponseDto getLicenseHistory(
        @RequestBody ChangeHistoryFilterBodyDto licenseGetFilterBody) {
        return assetService.getLicenseHistory(licenseGetFilterBody);
    }

    @GetMapping("/license/filters")
    public ResponseDto getLicenseHistoryFilters() {
        return assetService.getLicenseHistoryFilters();
    }

    @PostMapping("/metadata/add")
    public ResponseDto addMetadataHistory(
        @RequestBody MetadataHistoryRequestDto metadataHistoryRequestDto) {
        return assetService.addMetadataHistory(metadataHistoryRequestDto);
    }

    @PostMapping("/metadata/get")
    public ResponseDto getMetadataHistory(@RequestBody ChangeHistoryFilterBodyDto filterBody) {
        return assetService.getMetadataHistory(filterBody);
    }


    @PostMapping("/asset/status/add")
    public ResponseDto addAssetstatusHistory(
        @RequestBody StatusHistoryRequestDto statusHistoryRequestDto) {
        return assetService.addAssetStatusHistory(statusHistoryRequestDto);
    }

    @PostMapping("/asset/status/get")
    public ResponseDto getAssetstatusHistory(@RequestBody ChangeHistoryFilterBodyDto filterBody) {
        return assetService.getAssetStatusHistory(filterBody);
    }


    @GetMapping("/asset/status/filters")
    public ResponseDto getAssetStatusFilters() {
        return assetService.getAssetstatusHistoryFilters();

    }

    @GetMapping("/metadata/filters")
    public ResponseDto getMetadataHistoryFilters() {
        return assetService.getMetadataHistoryFilters();
    }

    @GetMapping("/asset/status/get/{assetId}")
    public ResponseDto getStatusHistoryByAssetId(@PathVariable String assetId) {
        return assetService.getStatusHistoryByAssetId(assetId);
    }


    @PostMapping("/metadata/get/asset/{assetId}")
    public ResponseDto getMetadataHistoryByAssetId(@PathVariable String assetId,
        @RequestBody ChangeHistoryFilterBodyDto filterBody) {
        return assetService.getMetadataHistoryByAssetId(assetId, filterBody);
    }

    @GetMapping("/license/get/asset/{assetId}")
    public ResponseDto getLicenseHistoryByAssetId(@PathVariable String assetId) {
        return assetService.getLicenseHistoryByAssetId(assetId);
    }

    @PostMapping("/license/export")
    public ResponseEntity<InputStreamResource> exportLicenseHistory(
        @RequestBody ChangeHistoryFilterBodyDto filterBodyDto) {
        return assetService.exportLicenseHistory(filterBodyDto);
    }

    @PostMapping("/metadata/export")
    public ResponseEntity<InputStreamResource> exportMetadataHistory(
        @RequestBody ChangeHistoryFilterBodyDto filterBodyDto) {
        return assetService.exportMetadataHistory(filterBodyDto);
    }

    @PostMapping("/asset/status/export")
    public ResponseEntity<InputStreamResource> exportAssetStatusHistory(
        @RequestBody ChangeHistoryFilterBodyDto filterBodyDto) {
        return assetService.exportAssetStatusHistory(filterBodyDto);
    }

    @PostMapping("/event/add")
    public ResponseDto addEventHistory(@RequestBody EventHistoryRequestDto eventHistoryDto) {
        return assetService.addEventHistory(eventHistoryDto);
    }

    @PostMapping("/lock/history/add")
    public ResponseDto addLockHistory(@RequestBody @Valid LockHistoryRequestDto lockHistoryRequest) {
        return assetService.addLockChangeHistory(lockHistoryRequest);
    }
}