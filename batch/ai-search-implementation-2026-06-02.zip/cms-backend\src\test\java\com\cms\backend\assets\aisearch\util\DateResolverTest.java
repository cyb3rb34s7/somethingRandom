package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

class DateResolverTest {

    // Fixed "now" = 2026-06-02 12:00:00 UTC
    private final Clock fixedClock = Clock.fixed(Instant.parse("2026-06-02T12:00:00Z"), ZoneId.of("UTC"));
    private final DateResolver resolver = new DateResolver(fixedClock);

    @Test
    void resolvesToday() {
        assertThat(resolver.resolveToken("TODAY")).isEqualTo("2026-06-02 12:00:00");
    }

    @Test
    void resolvesYesterday() {
        assertThat(resolver.resolveToken("YESTERDAY")).isEqualTo("2026-06-01 12:00:00");
    }

    @Test
    void resolvesLast7Days() {
        assertThat(resolver.resolveToken("LAST_7_DAYS")).isEqualTo("2026-05-26 12:00:00");
    }

    @Test
    void resolvesLast30Days() {
        assertThat(resolver.resolveToken("LAST_30_DAYS")).isEqualTo("2026-05-03 12:00:00");
    }

    @Test
    void resolvesThisMonth() {
        assertThat(resolver.resolveToken("THIS_MONTH")).isEqualTo("2026-06-01 12:00:00");
    }

    @Test
    void resolvesLastMonth() {
        assertThat(resolver.resolveToken("LAST_MONTH")).isEqualTo("2026-05-01 12:00:00");
    }

    @Test
    void resolvesThisYear() {
        assertThat(resolver.resolveToken("THIS_YEAR")).isEqualTo("2026-01-01 12:00:00");
    }

    @Test
    void isCaseInsensitiveForTokens() {
        assertThat(resolver.resolveToken("today")).isEqualTo("2026-06-02 12:00:00");
    }

    @Test
    void passesThroughRealDateStrings() {
        assertThat(resolver.resolveToken("2026-01-01 00:00:00")).isEqualTo("2026-01-01 00:00:00");
    }

    @Test
    void nullOrBlankTokenResolvesToEmpty() {
        assertThat(resolver.resolveToken(null)).isEmpty();
        assertThat(resolver.resolveToken("")).isEmpty();
        assertThat(resolver.resolveToken("   ")).isEmpty();
    }

    @Test
    void resolveRangePadsToTwoElements() {
        assertThat(resolver.resolveRange(List.of("LAST_7_DAYS")))
                .containsExactly("2026-05-26 12:00:00", "");
        assertThat(resolver.resolveRange(List.of())).containsExactly("", "");
        assertThat(resolver.resolveRange(null)).containsExactly("", "");
    }

    @Test
    void resolveRangeResolvesBothEnds() {
        assertThat(resolver.resolveRange(List.of("LAST_7_DAYS", "TODAY")))
                .containsExactly("2026-05-26 12:00:00", "2026-06-02 12:00:00");
    }

    @Test
    void resolveRangeTruncatesToTwoElements() {
        assertThat(resolver.resolveRange(Arrays.asList("TODAY", "YESTERDAY", "THIS_YEAR")))
                .containsExactly("2026-06-02 12:00:00", "2026-06-01 12:00:00");
    }
}
