package com.cms.backend.assets.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class VodAssetDto {

    @NotNull(message = "content Id cannot be null")
    @Size(min = 1, max = 125, message = "ProgramId length check failed, allowed length range [1,125].")
    @Pattern(regexp = "^[0-9A-Za-z_-]+$")
    private String contentId;

    @NotNull(message = "Country code cannot be null")
    @Size(max = 2, message = "CountryCode length check failed, , max allowed length 2.")
    @Pattern(regexp = "^(?i)([A-Za-z][A-Za-z])?$")
    private String countryCode;

    @NotNull(message = "Id Provider cannot be null")
    @Size(max = 50, message = "Provider Id length check failed, allowed length range [1,50]")
    private String vcCpId;


    @Size(max = 20, message = "Type length check failed")
    private String type;

    @Size(max = 200, message = "Program Title/Episode Title length check failed")
    private String mainTitle;
    @Size(max = 200, message = "Program Short Title/Episode Short Title length check failed")
    private String shortTitle;

    @Max(value = 21600, message = "Running time exceeds 21600.")
    private Integer runningTime;

    @Size(max = 200, message = "Genre length check failed")
    private String genres;

    @Size(max = 1000)
    private String director;

    @Size(max = 1000)
    private String starring;

    @Size(max = 30, message = "Ratings length check failed")
    private String ratings;

    @Size(max = 4000, message = "Synopsis/Description length check failed")
    private String description;

    @Max(value = 99999)
    private Integer episodeNo;

    @Max(value = 99999)
    private Integer seasonNo;

    @Size(max = 125, message = "Invalid season Id maxLength 125")
    @Pattern(regexp = "^[0-9A-Za-z_-]+$")
    private String seasonId;

    @Size(max = 2000)
    private String streamUri;
    @Size(max = 2000)
    private String imageLandscape;

    @Size(max = 125)
    private String showId;
    @Size(max = 20)
    private String releaseDate;

    private Date regDate;

    private Date updateDate;
    @Size(max = 15)
    private String regrId;
    @Size(max = 15)
    private String crctrId;
    @Size(max = 2000)
    private String imagePortrait;

    @Size(max = 2000)
    private String imageCircle;
    @Size(max = 2000)
    private String webVttUrl;
    @Size(max = 2000)
    private String thumbnailUrl;
    @Size(max = 2000)
    private String audioLang;
    @Size(max = 2000)
    private String subtitleLang;

    @Size(max = 1000, message = "deeplink payload length exceeded 1000.")
    private String deeplinkPayload;
    @Size(max = 2000)
    private String audioCode;
    @Size(max = 2000)
    private String subtitleCode;
    @Size(max = 10)
    private String quality;
    @Size(max = 50)
    private String vcSvcId;
    @Size(max = 400)
    private String deeplinkId;
    @Size(max = 100)
    private String fileName;
    @Size(max = 2)
    private String dataplusYn;
    @Size(max = 2000)
    private String nonAdStreamUri;
    @Size(max = 2000)
    private String imageLandscapeOriginal;
    @Size(max = 2000)
    private String imagePortraitOriginal;
    @Size(max = 2000)
    private String imageCircleOriginal;
    @Size(max = 2000)
    private String processedImageUrl;
    @Size(max = 1000)
    private String artist;

    @Size(max = 30, message = "Window Start Date length check failed")
    private String availableStarting;

    @Size(max = 30, message = "Window End Date length check failed")
    private String expiryDate;

    @Size(max = 30)
    private String totalAvailableStarting;
    @Size(max = 30)
    private String totalAvailableEnding;

    @Size(max = 200, message = "Content Partner length check failed")
    private String contentPartner;

    @Size(max = 2000)
    private String imagePortraitIconic;
    @Size(max = 2000)
    private String imageLandscapeIconic;
    @Size(max = 2000)
    private String imagePortraitIconicOriginal;
    @Size(max = 2000)
    private String imageLandscapeIconicOriginal;
    @Size(max = 100)
    private String addedFrom;
    @Size(max = 100)
    private String identifierId;

    @Size(max = 100, message = "Content Tier length check failed")
    private String contentTier;
    @Size(max = 100)
    private String chapterTime;
    @Size(max = 2000)
    private String chapterDescription;

    @Size(max = 100, message = "Asset Id length check failed")
    private String assetId;

    @Size(max = 100)
    private String status;
    @Size(max = 2000)
    private String adTag;
    @Size(max = 10)
    private String platformTag;
    @Size(max = 100)
    private String qcPassReason;
    @Size(max = 30)
    private String feedWorker;

    private String cpName;
    private String tiName;
    private String licenseWindow;
    private String adBreak;
    private String drm;

    private String externalId;
    private String externalIdProvider;
    private String externalIdType;
    @Valid
    private List<ExternalProviderDto> externalProvider;

    private String seriesDescription;
    private List<AdBreaksDto> adBreaks;
    private List<PlatformTagData> platformTagData;
    private Integer isCmsProd;
    private Boolean isSyncBlocked;
    private Boolean isReleased;
    private List<AssetDrmDto> drmData;
    private String imageLandscapeDimension;
    private String imagePortraitDimension;
    private String imageLandscapeIconicDimension;
    private String imagePortraitIconicDimension;

    @Valid
    private List<ParentalRatingsDto> parentalRatings;

    @Valid
    private List<AssetCastDto> cast;

    private String showTitle;
    private String seasonTitle;

    @Valid
    private List<LicenseWindowDto> licenseWindowList;

    @Valid
    private List<AssetEventWindowDto> eventWindowList;

    private String gracenoteAction;
    private String onDeviceTrans;
    private String streamType;
    private String dbStatus;
    @Size(max = 2000)
    private String imageTitleTreatment;
    @Size(max = 2000)
    private String imageTitleTreatmentOriginal;
    private String imageTitleTreatmentDimension;

    @Size(max = 2000)
    private String imageLandscapeBackdrop;
    @Size(max = 2000)
    private String imageLandscapeBackdropOriginal;
    private String imageLandscapeBackdropDimension;

    // WebP Image Fields
    @Size(max = 2000)
    private String imageTitleTreatmentWebp;
    @Size(max = 2000)
    private String imageLandscapeWebp;
    @Size(max = 2000)
    private String imagePortraitWebp;
    @Size(max = 2000)
    private String imageLandscapeIconicWebp;
    @Size(max = 2000)
    private String imagePortraitIconicWebp;
    @Size(max = 2000)
    private String imageLandscapeBackdropWebp;


    private List<AssetLockedFieldDto> lockedFields;
    private List<AssetImageDto> assetImageList;

    private List<ErrorFieldDto> errorList;
    private String ratingBody;
    private String result;
    private String userId;
    private String region;
    private String sessionId;
    private String attributes;
    private String ingestionType;
    private String isDelete;
    private String deltaType;

    private Boolean isSynced;

    private String subType;
    private String airType;
    private String team1;
    private String team2;
    private String geoRestrictionYn;
    private String matchInformation;
    private List<GeoRestrictionsDto> geoRestrictions;

}
