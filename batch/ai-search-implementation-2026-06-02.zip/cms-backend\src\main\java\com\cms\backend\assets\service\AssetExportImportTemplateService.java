package com.cms.backend.assets.service;

import com.cms.backend.assets.configuration.AssetExcelMap;
import com.cms.backend.assets.configuration.ImportTemplateAssetHeaderMap;
import com.cms.backend.assets.model.AssetFilterBodyDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetColumns;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AssetExportImportTemplateService {

    @Autowired
    private RegionEndpointService regionEndpointService;

    @Autowired
    private HttpMethodHandler httpMethodHandler;

    ObjectMapper objectMapper = new ObjectMapper();

    public ResponseEntity<InputStreamResource> exportSelected(
        AssetFilterBodyDto assetFilterBodyDto, String filterType) {
        log.info("Export Request Service called...at time={}", Instant.now());
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            SXSSFWorkbook workbook = new SXSSFWorkbook()) {
            Set<String> columnSet = new HashSet<>(AssetExcelMap.getMap().values());
            assetFilterBodyDto.setColumns(columnSet.stream().toList());

            // getting assets from assetManagement
            HttpEntity<AssetFilterBodyDto> httpEntity = new HttpEntity<>(assetFilterBodyDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpointNLB() + Constants.GET_FILTERED_ASSETS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            log.info("Data Received from asset Mgmt at time={}", Instant.now());
            List<LinkedHashMap<String, Object>> assetDtoList = (List<LinkedHashMap<String, Object>>) Objects
                .requireNonNull(
                    responseEntity.getBody())
                .getRsp()
                .getPayload()
                .get(Constants.ASSETS);
            if (Constants.EXPORT_TYPE_SELECTED.equalsIgnoreCase(filterType)) {
                assetDtoList = filterAssetDtoListByContentIds(assetDtoList,
                    assetFilterBodyDto.getFilters());
            }

            // _____________creating sheet and header row____________
            CellStyle nonEditableCellStyle = getImportTemplateCellStyle(workbook,
                Constants.NON_EDITABLE_BULK_IMPORT_FIELDS.get(
                    0));

            CellStyle nonEditableCellStyleWithWhiteBackground = getImportTemplateCellStyle(workbook,
                Constants.NON_EDITABLE_BULK_IMPORT_FIELDS.get(
                    0));
            nonEditableCellStyleWithWhiteBackground.setFillForegroundColor(
                IndexedColors.WHITE.getIndex());

            Sheet sheet = workbook.createSheet(Constants.ASSETS);
            Row headerRow = sheet.createRow(0);
            CellStyle editableCellStyle = getImportTemplateCellStyle(workbook,
                "default_editable");
            headerRow.setRowStyle(nonEditableCellStyleWithWhiteBackground);

            int headerRowIndex = 0;
            for (String column : Constants.EXCEL_HEADERS) {
                String columnName = ImportTemplateAssetHeaderMap.getMap()
                    .getOrDefault(column, column);
                headerRow.createCell(headerRowIndex).setCellValue(columnName);
                boolean isNonEditableField = Constants.NON_EDITABLE_BULK_IMPORT_FIELDS.contains(
                    column);
                headerRow.getCell(headerRowIndex)
                    .setCellStyle(getCellStyle(isNonEditableField, nonEditableCellStyle,
                        nonEditableCellStyleWithWhiteBackground)); // first one is a non-editable one
                sheet.setColumnWidth(headerRowIndex, 256 * 20);
                headerRowIndex += 1;
            }

            for (int columnIndex = 0; columnIndex < Constants.EXCEL_HEADERS.size(); ++columnIndex) {
                String excelColumn = Constants.EXCEL_HEADERS.get(columnIndex);
                boolean isNonEditableField = Constants.NON_EDITABLE_BULK_IMPORT_FIELDS.contains(
                    excelColumn);
                sheet.setDefaultColumnStyle(columnIndex,
                    isNonEditableField ? nonEditableCellStyle : editableCellStyle);
            }

            // _____________creating rows_____________
            for (int k = 0; k < assetDtoList.size(); k++) {
                LinkedHashMap<String, Object> asset = assetDtoList.get(k);
                Row row = sheet.createRow(k + 1);

                for (int columnIndex = 0; columnIndex < Constants.EXCEL_HEADERS.size();
                    ++columnIndex) {
                    String excelColumn = Constants.EXCEL_HEADERS.get(columnIndex);
                    String column = AssetExcelMap.getMap().getOrDefault(excelColumn, excelColumn);
                    String cellValue = findCellValue(column, asset);
                    if (!StringUtils.isEmpty(cellValue)) {
                        row.createCell(columnIndex).setCellValue(cellValue);
                    } else {
                        row.createCell(columnIndex).setCellValue("");
                    }
                }
            }
            sheet.protectSheet("");

            // write to byte array output stream
            workbook.write(outputStream);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
                outputStream.toByteArray());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("Content-Disposition", "attachment; filename=assets.xlsx");

            httpHeaders.add("Content-length", String.valueOf(byteArrayInputStream.available()));
            log.info("Sending Data to UI at time={}", Instant.now());
            return ResponseEntity.ok().headers(httpHeaders).contentType(MediaType.parseMediaType(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(new InputStreamResource(byteArrayInputStream));
        } catch (IOException e) {
            log.error("IO error while exporting assets: {}", e.getMessage(), e);
            throw new AssetApiFailureException("Failed to write export file: " + e.getMessage());
        } catch (Exception ex) {
            throw new AssetApiFailureException("Error while exporting assets");
        }

    }

    private CellStyle getCellStyle(boolean isNonEditableField, CellStyle nonEditableCellStyle,
        CellStyle nonEditableCellStyleWithWhiteBackground) {
        return isNonEditableField ? nonEditableCellStyle
            : nonEditableCellStyleWithWhiteBackground;
    }

    private List<LinkedHashMap<String, Object>> filterAssetDtoListByContentIds(
        List<LinkedHashMap<String, Object>> allAssetList, List<FilterDto> filters) {
        List<FilterDto> contentIdFilter = filters.stream()
            .filter(filter -> filter.getKey().equalsIgnoreCase(Constants.CONTENT_ID)).toList();
        if (contentIdFilter.isEmpty()) {
            return allAssetList;
        }
        Set<String> contentIdsSet = new HashSet<>(contentIdFilter.get(0).getValues());
        return allAssetList.stream()
            .filter(asset -> {
                String contentId =
                    asset.containsKey(Constants.CONTENT_ID) ? asset.get(Constants.CONTENT_ID)
                        .toString() : "";
                return contentIdsSet.contains(contentId);
            }).toList();
    }

    private CellStyle getImportTemplateCellStyle(Workbook workbook, String columnName) {
        CellStyle cellStyle = workbook.createCellStyle();

        Font font = workbook.createFont();
        font.setBold(true);

        boolean isNonEditableField = Constants.NON_EDITABLE_BULK_IMPORT_FIELDS.contains(columnName);

        if (isNonEditableField) {
            cellStyle.setLocked(true);
            cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        } else {
            cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
            cellStyle.setLocked(false);
        }
        cellStyle.setFont(font);
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        var dataFormat = workbook.createDataFormat();
        cellStyle.setDataFormat(dataFormat.getFormat("@"));
        font.setColor(HSSFColorPredefined.BLACK.getIndex());
        return cellStyle;
    }


    private String findCellValue(String column, LinkedHashMap<String, Object> asset) {
        if (ObjectUtils.isEmpty(asset.get(column)) && !List.of("provider", "idtype",
                "externalProgramId")
            .contains(column)) {
            return "";
        }
        return switch (column) {
            case "externalProgramId" -> {
                List<ExternalProviderDto> externalDtoList = ObjectUtils
                    .isEmpty(asset.get(AssetColumns.EXTERNAL_PROVIDER.value))
                    ? List.of()
                    : objectMapper.convertValue(
                        asset.get(AssetColumns.EXTERNAL_PROVIDER.value),
                        new TypeReference<>() {
                        });

                yield externalDtoList.stream()
                    .map(ExternalProviderDto::getExternalProgramId).collect(
                        Collectors.joining(","));
            }
            case "provider" -> {
                List<ExternalProviderDto> externalDtoList = ObjectUtils
                    .isEmpty(asset.get(AssetColumns.EXTERNAL_PROVIDER.value))
                    ? List.of()
                    : objectMapper.convertValue(
                        asset.get(AssetColumns.EXTERNAL_PROVIDER.value),
                        new TypeReference<>() {
                        });

                yield externalDtoList.stream()
                    .map(ExternalProviderDto::getProvider).collect(
                        Collectors.joining(","));
            }
            case "idtype" -> {
                List<ExternalProviderDto> externalDtoList = ObjectUtils
                    .isEmpty(asset.get(AssetColumns.EXTERNAL_PROVIDER.value))
                    ? List.of()
                    : objectMapper.convertValue(
                        asset.get(AssetColumns.EXTERNAL_PROVIDER.value),
                        new TypeReference<>() {
                        });

                yield externalDtoList.stream()
                    .map(ExternalProviderDto::getIdType).collect(
                        Collectors.joining(","));
            }
            default -> asset.get(column).toString();
        };

    }

}
