package com.cms.backend.common.test;

import com.cms.backend.common.model.SecurityUser;
import java.util.HashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Base class for service and controller tests to reduce code duplication. Provides common setup
 * methods, generic mocking utilities, and standard assertion methods.
 */
public abstract class BaseServiceAndControllerTest {

    /**
     * Common setup for all tests - can be overridden by subclasses if needed
     */
    @BeforeEach
    void setUp() {
        // Common test setup can be added here
    }

    /**
     * Creates a test security user for testing
     *
     * @return A SecurityUser for testing
     */
    public static SecurityUser createTestSecurityUser() {
        return new SecurityUser("userId", "US",
            "userId", "TEST_SESSION_ID", new HashMap<>());
    }

    /**
     * Generic mocking utility for simple return value mocking
     *
     * @param mock        The mock object
     * @param returnValue The value to return when the method is called
     * @param methodName  The name of the method to mock
     */
    protected <T> void mockDependencyReturn(T mock, T returnValue, String methodName) {
        try {
            Mockito.doReturn(returnValue).when(mock).getClass()
                .getMethod(methodName, (Class<?>[]) null);
        } catch (Exception e) {
            // Fallback to any() matcher
            Mockito.doReturn(returnValue).when(mock).toString(); // This is just a placeholder
        }
    }

    /**
     * Generic mocking utility for void methods
     *
     * @param mock       The mock object
     * @param methodName The name of the method to mock
     */
    protected void mockDependencyVoid(Object mock, String methodName) {
        try {
            Mockito.doNothing().when(mock).getClass().getMethod(methodName, (Class<?>[]) null);
        } catch (Exception e) {
            // Fallback to any() matcher
            Mockito.doNothing().when(mock).toString(); // This is just a placeholder
        }
    }

    /**
     * Standard assertion method for ensuring no exceptions are thrown
     *
     * @param executable The code to execute
     */
    protected void assertNoException(org.junit.jupiter.api.function.Executable executable) {
        assertDoesNotThrow(executable);
    }

    /**
     * Standard assertion method for ensuring an exception is thrown
     *
     * @param exceptionClass The exception class to expect
     * @param executable     The code to execute
     */
    protected <T extends Throwable> void assertException(Class<T> exceptionClass,
        Executable executable) {
        assertThrows(exceptionClass, executable);
    }

    /**
     * Generic mocking utility with Mockito any() matchers
     *
     * @param mock        The mock object
     * @param returnValue The value to return
     */
    protected <T> void mockWithAny(T mock, T returnValue) {
        Mockito.doReturn(returnValue).when(mock);
    }

    /**
     * Generic mocking utility for exceptions
     *
     * @param mock           The mock object
     * @param exceptionClass The exception class to throw
     */
    protected <T extends Throwable> void mockException(Object mock, Class<T> exceptionClass) {
        Mockito.doThrow(exceptionClass).when(mock);
    }
}
