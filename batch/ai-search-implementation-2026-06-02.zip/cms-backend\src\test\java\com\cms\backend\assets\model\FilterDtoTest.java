package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

class FilterDtoTest {

    @Test
    void testFilterDto() {
        FilterDto filterDto = FilterDto.builder()
            .type("type")
            .key("key")
            .values(Arrays.asList("value1", "value2"))
            .build();

        assertNotNull(filterDto);
        assertEquals("type", filterDto.getType());
        assertEquals("key", filterDto.getKey());
        assertEquals(2, filterDto.getValues().size());
        assertTrue(filterDto.getValues().contains("value1"));
        assertTrue(filterDto.getValues().contains("value2"));

        filterDto.setType(null);
        filterDto.setKey(null);
        filterDto.setValues(null);

        assertNull(filterDto.getType());
        assertNull(filterDto.getKey());
        assertNull(filterDto.getValues());
    }
}