package com.cms.backend.assets.service;

import static com.cms.backend.assets.service.AssetService.ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER;

import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.AssetExternalIdDto;
import com.cms.backend.assets.model.ExternalProviderDto;
import com.cms.backend.assets.model.LicenseWindowDto;
import com.cms.backend.assets.model.RatingsDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.AssetTypeNGenresMap;
import com.cms.backend.common.util.HttpMethodHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ValidationAsset {

    private final AssetTypeNGenresMap assetTypeNGenresMap;
    private final HttpMethodHandler httpMethodHandler;
    private final RegionEndpointService regionEndpointService;
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss")
        .withZone(ZoneOffset.UTC)
        .withResolverStyle(ResolverStyle.STRICT);

    @Value("${FEED_WORKER_LIST:CMS,CMS_GRACENOTE}")
    private String feedWorkerList;

    ValidationAsset(AssetTypeNGenresMap assetTypeNGenresMap, HttpMethodHandler httpMethodHandler,
        RegionEndpointService regionEndpointService) {
        this.assetTypeNGenresMap = assetTypeNGenresMap;
        this.httpMethodHandler = httpMethodHandler;
        this.regionEndpointService = regionEndpointService;
    }

    public boolean validate(VodAssetDto vodAssetDto, List<RatingsDto> ratingsDtoList) {
        if (!validateAndSetExternalIdData(vodAssetDto)) {
            return false;
        }
        if (!setValuesAndLengthValidationForVodAssetDto(vodAssetDto)) {
            return false;
        }
        if (!validateType(vodAssetDto.getType())) {
            log.error("Validation in type is failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Type check failed");
            return false;
        }
        if (vodAssetDto.getType() != null) {
            vodAssetDto.setType(vodAssetDto.getType().toUpperCase());
        }
        if (validateAvailableStartingAndExpiry(vodAssetDto.getAvailableStarting())) {
            log.error("Validation in Window Start Date is failed  for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Window Start Date check failed");
            return false;
        }
        if (validateAvailableStartingAndExpiry(vodAssetDto.getExpiryDate())) {
            log.error("Validation in Window End Date is failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Window End Date check failed");
            return false;
        }

        if (!isValidPersonField(vodAssetDto, vodAssetDto.getStarring(), "Actor",
            VodAssetDto::setStarring)) {
            log.error("Validation in Actor failed for contentId {} ", vodAssetDto.getContentId());
            vodAssetDto.setResult("Actor check failed");
            return false;
        }
        if (!isValidPersonField(vodAssetDto, vodAssetDto.getDirector(), "Director",
            VodAssetDto::setDirector)) {
            log.error("Validation in Director failed for contentId {} ",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Director check failed");
            return false;
        }
        if (!isValidPersonField(vodAssetDto, vodAssetDto.getArtist(), "Artist",
            VodAssetDto::setArtist)) {
            log.error("Validation in Artist failed for contentId {} ", vodAssetDto.getContentId());
            vodAssetDto.setResult("Artist check failed");
            return false;
        }

        if (!validateGenres(vodAssetDto.getType(), vodAssetDto.getGenres())) {
            log.error("Validation in genre failed for contentId {} ",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Genre check failed");
            return false;
        }

        if (!validateRatings(vodAssetDto, vodAssetDto.getRatings(),
            vodAssetDto.getType(),
            vodAssetDto.getCountryCode(),
            ratingsDtoList)) {
            log.error("Validation in ratings failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Ratings check failed");
            return false;
        }

        vodAssetDto.setGenres(
            updateGenreWithEnum(vodAssetDto.getType(), vodAssetDto.getGenres()));

        if (!validateAvailableStartingAndExpiryBoth(vodAssetDto.getAvailableStarting(),
            vodAssetDto.getExpiryDate())) {
            log.error(
                "Validation in Window Start Date and Window End Date failed for contentId {} ",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Window Start Date, Window End Date check failed");
            return false;
        }

        if (!validateReleaseDate(vodAssetDto.getReleaseDate())) {
            log.error("Validation in original release Date is failed for contentId{} ",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("Original Release Date check failed");
            return false;
        }

        if (!duplicateExternalIdEntryCheck(vodAssetDto)) {
            return false;
        }

        return externalIdTypeCheck(vodAssetDto);
    }


    public String validateAssetExternalField(VodAssetDto vodAssetDto) {
        String finalUrl =
            regionEndpointService.getOpenAPIEndpoint() + Constants.VALIDATE_EXTERNAL_ID;

        List<AssetExternalIdDto> externalIdDtos = new ArrayList<>();
        vodAssetDto.getExternalProvider()
            .forEach(externalProvider -> externalIdDtos.add(AssetExternalIdDto.builder()
                .externalProgramId(externalProvider.getExternalProgramId())
                .countryCode(vodAssetDto.getCountryCode())
                .programId(vodAssetDto.getContentId()).build()));

        ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
            finalUrl,
            Constants.METHOD_POST, new HttpEntity<>(externalIdDtos),
            ResponseDto.class);
        Map<String, Object> payload = Objects.requireNonNull(responseEntity.getBody())
            .getRsp().getPayload();
        ObjectMapper mapper = new ObjectMapper();
        List<String> ids = mapper.convertValue(
            payload.get("externalIds"),
            new TypeReference<>() {
            });
        if (ids.isEmpty()) {
            return null;
        } else {
            return String.join(",", ids);
        }
    }

    private boolean setValuesAndLengthValidationForVodAssetDto(
        VodAssetDto vodAssetDto) {
        boolean validation = this.validateAndCorrectFieldLength(vodAssetDto, "Content Id",
            vodAssetDto.getContentId(), 125,
            "ProgramId length check failed", VodAssetDto::setContentId);

        if (!this.validateAndCorrectFieldLength(vodAssetDto, "CountryCode",
            vodAssetDto.getCountryCode(), 2, "CountryCode length check failed",
            VodAssetDto::setCountryCode)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Id Provider",
            vodAssetDto.getVcCpId(), 50, "Id Provider length check failed",
            VodAssetDto::setVcCpId)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Type",
            vodAssetDto.getType(), 20, "Type length check failed",
            VodAssetDto::setType)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Program Title/Episode Title",
            vodAssetDto.getMainTitle(), 200, "Program Title/Episode Title length check failed",
            VodAssetDto::setMainTitle)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Genre",
            vodAssetDto.getGenres(), 200, "Genre length check failed",
            VodAssetDto::setGenres)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Synopsis/Description",
            vodAssetDto.getDescription(), 4000, "Synopsis/Description length check failed",
            VodAssetDto::setDescription)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Original Release Date",
            vodAssetDto.getReleaseDate(), 30, "Original Release Date length check failed",
            VodAssetDto::setReleaseDate)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Ratings",
            vodAssetDto.getRatings(), 30, "Ratings length check failed",
            VodAssetDto::setRatings)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Window End Date",
            vodAssetDto.getExpiryDate(), 30, "Window End Date length check failed",
            VodAssetDto::setExpiryDate)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Window Start Date",
            vodAssetDto.getAvailableStarting(), 30, "Window Start Date length check failed",
            VodAssetDto::setAvailableStarting)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "Content Partner",
            vodAssetDto.getContentPartner(), 200, "Content Partner length check failed",
            VodAssetDto::setContentPartner)) {
            validation = false;
        }

        return validation && lengthValidationsExtra(vodAssetDto);
    }

    public boolean lengthValidationsExtra(VodAssetDto vodAssetDto) {
        boolean validation = validateAndCorrectFieldLength(vodAssetDto, "Short Title",
            vodAssetDto.getShortTitle(), 200, "Short Title length check failed",
            VodAssetDto::setShortTitle);

        if (!validateAndCorrectFieldLength(vodAssetDto, "Content Tier",
            vodAssetDto.getContentTier(), 100, "Content Tier length check failed",
            VodAssetDto::setContentTier)) {
            validation = false;
        }

        if (!validateAndCorrectFieldLength(vodAssetDto, "AssetId",
            vodAssetDto.getAssetId(), 100, "Asset Id length check failed",
            VodAssetDto::setAssetId)) {
            validation = false;
        }

        if (vodAssetDto.getExternalProvider() != null && !validateLengthsOfListElements(
            vodAssetDto.getExternalProvider().stream().map(
                ExternalProviderDto::getProvider).toList(), 254)) {
            log.error("Validation in External Provider length has failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("External Provider length check failed");
            validation = false;
        }
        if (vodAssetDto.getExternalProvider() != null && !validateLengthsOfListElements(
            vodAssetDto.getExternalProvider().stream().map(
                ExternalProviderDto::getExternalProgramId).toList(), 20)) {
            log.error("Validation in External Program Id has failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("External Program Id length check failed");
            validation = false;
        }
        if (vodAssetDto.getExternalProvider() != null && !validateLengthsOfListElements(
            vodAssetDto.getExternalProvider().stream().map(
                ExternalProviderDto::getIdType).toList(), 20)) {
            log.error("Validation in External Id Type has failed for contentId {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult("External Id Type length check failed");
            validation = false;
        }

        return validation;
    }

    private boolean lengthCheckOfFieldVodAssetDto(String field, int length) {
        return field != null && field.length() > length;
    }

    public boolean validateLengthsOfListElements(List<String> values, int lengthLimit) {
        if (values == null) {
            return true;
        }

        for (String value : values) {
            if (value.length() > lengthLimit) {
                return false;
            }
        }
        return true;
    }

    private String updateGenreWithEnum(String type, String genres) {
        if (genres == null || genres.isEmpty()) {
            return null;
        }
        List<String> splitGenres = Arrays.stream(genres.split(",")).distinct()
            .toList();
        List<String> updatedGenre = new ArrayList<>();
        if (Constants.MUSIC.equalsIgnoreCase(type)) {
            for (String genre : splitGenres) {
                String requiredGenre = this.assetTypeNGenresMap.initializeGenresMusicMapping()
                    .get(genre.toLowerCase());
                if (!updatedGenre.contains(requiredGenre)) {
                    updatedGenre.add(requiredGenre);
                }
            }

        } else {
            for (String genre : splitGenres) {
                String requiredGenre = this.assetTypeNGenresMap.initializeGenresMapping()
                    .get(genre.toLowerCase());
                if (!updatedGenre.contains(requiredGenre)) {
                    updatedGenre.add(requiredGenre);
                }
            }
        }
        return String.join(",", updatedGenre);
    }

    private boolean validateType(String type) {
        return !(type == null || !Constants.ASSET_TYPE.contains(
            type.toLowerCase()));
    }

    private boolean validateGenres(String type, String genres) {
        if (genres == null || genres.isEmpty()) {
            return true;
        }
        List<String> splitGenres = Arrays.stream(genres.split(",")).distinct()
            .toList();
        if (Constants.MUSIC.equalsIgnoreCase(type)) {
            for (String str : splitGenres) {
                if (!this.assetTypeNGenresMap.initializeGenresMusicMapping()
                    .containsKey(str.toLowerCase())) {
                    return false;
                }
            }
        } else {
            for (String str : splitGenres) {
                if (!this.assetTypeNGenresMap.initializeGenresMapping()
                    .containsKey(str.toLowerCase())) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean validateReleaseDate(String releaseDate) {
        if (releaseDate == null) {
            return true;
        }
        var dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        try {
            LocalDate.parse(releaseDate, dateTimeFormatter);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean validateAvailableStartingAndExpiry(String date) {
        if (date == null) {
            return false;
        }
        try {
            dateFormatter.parse(date);
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    private boolean validateAvailableStartingAndExpiryBoth(String availableStarting,
        String expiryDate) {
        if (availableStarting == null || expiryDate == null) {
            return true;
        }
        try {

            LocalDateTime startDate = LocalDateTime.parse(availableStarting, dateFormatter);
            LocalDateTime endDate = LocalDateTime.parse(expiryDate, dateFormatter);
            //Check for endDate not earlier than startDate
            if (startDate.isAfter(endDate)) {
                return false;
            }

        } catch (Exception e) {
            return false;
        }
        return true;

    }

    private boolean validateRatings(VodAssetDto vodAssetDto, String inputRating,
        String type, String countryCode,
        List<RatingsDto> ratings) {
        String inputRatingBody = vodAssetDto.getRatingBody();
        if (inputRating == null) {
            return true;
        }
        if (inputRatingBody == null) {
            return false;
        }

        List<String> inputRatingBodys = Arrays.stream(inputRatingBody.toLowerCase().split(","))
            .toList();
        List<String> inputRatings = Arrays.stream(inputRating.toLowerCase().split(",")).toList();
        if (inputRatingBodys.size() != inputRatings.size()) {
            return false;
        }
        if (type.equalsIgnoreCase(Constants.SINGLEVOD)) {
            type = Constants.SHOW;
        }
        for (int i = 0; i < inputRatingBodys.size(); i++) {
            boolean isRatingValid = matchSingleRating(ratings, countryCode, type,
                inputRatingBodys.get(i), inputRatings.get(i));
            if (!isRatingValid) {
                return false;
            }
        }
        List<String> ratingsAndRatingBody = updateRatings(vodAssetDto.getRatings(),
            vodAssetDto.getType(),
            vodAssetDto.getCountryCode(), ratings, vodAssetDto.getRatingBody());
        if (ratingsAndRatingBody != null && !ratingsAndRatingBody.isEmpty()) {
            vodAssetDto.setRatings(ratingsAndRatingBody.get(0));
            vodAssetDto.setRatingBody(ratingsAndRatingBody.get(1));
        }
        return true;
    }

    private boolean matchSingleRating(List<RatingsDto> ratings, String countryCode, String type,
        String inputRatingBody, String inputRating) {
        for (RatingsDto ratingDto : ratings) {
            if (type.equalsIgnoreCase(ratingDto.getType()) && countryCode.equalsIgnoreCase(
                ratingDto.getCountryCode()) && inputRatingBody
                .equalsIgnoreCase(ratingDto.getOrganization())) {
                for (String rating : ratingDto.getParentalRatings()) {
                    if (rating.equalsIgnoreCase(inputRating)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private List<String> updateRatings(String inputRating, String type, String countryCode,
        List<RatingsDto> ratings, String ratingBody) {
        if (inputRating == null) {
            return Collections.emptyList();
        }
        List<String> inputRatingBodys = Arrays.stream(ratingBody.split(",")).toList();
        List<String> inputRatings = Arrays.stream(inputRating.split(",")).toList();
        List<String> updatedRating = new ArrayList<>();
        List<String> updatedRatingBody = new ArrayList<>();
        if (type.equalsIgnoreCase(Constants.SINGLEVOD)) {
            type = Constants.SHOW;
        }
        for (int i = 0; i < inputRatingBodys.size(); i++) {
            updateSingleRating(ratings, countryCode, type, inputRatingBodys.get(i),
                inputRatings.get(i), updatedRating, updatedRatingBody);
        }
        return List.of(String.join(",", updatedRating), String.join(",", updatedRatingBody));
    }

    private void updateSingleRating(List<RatingsDto> ratings, String countryCode, String type,
        String inputRatingBody, String inputRating, List<String> updatedRating,
        List<String> updatedRatingBody) {
        for (RatingsDto ratingDto : ratings) {
            if (type.equalsIgnoreCase(ratingDto.getType()) && countryCode.equalsIgnoreCase(
                ratingDto.getCountryCode()) && inputRatingBody
                .equalsIgnoreCase(ratingDto.getOrganization())) {
                for (String rating : ratingDto.getParentalRatings()) {
                    if (rating.equalsIgnoreCase(inputRating)) {
                        updatedRating.add(rating);
                        updatedRatingBody.add(ratingDto.getOrganization());
                        return;
                    }
                }
            }
        }
    }

    private boolean isValidPersonField(VodAssetDto dto, String fieldValue,
        String fieldName, BiConsumer<VodAssetDto, String> setter) {
        if (fieldValue == null) {
            return true;
        }

        List<String> splitValues = new ArrayList<>(Arrays.stream(fieldValue.split(","))
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .limit(10)
            .toList());

        if (splitValues.isEmpty()) {
            return false;
        }

        String finalValue = String.join(",", splitValues);

        if (lengthCheckOfFieldVodAssetDto(finalValue, 1000)) {
            log.error("Validation in {} is failed for contentId{} ", fieldName, dto.getContentId());
            dto.setResult(fieldName + " check failed");
            setter.accept(dto, finalValue.substring(0, 1000));
            return false;
        } else {
            setter.accept(dto, finalValue);
        }
        return true;
    }

    public <T> boolean validateNonOverlappingWindows(List<T> windows,
        Comparator<T> comparator,
        Function<T, String> startGetter,
        Function<T, String> endGetter,
        String windowType) {

        if (Objects.isNull(windows)) {
            return true;
        }
        windows.sort(comparator);
        for (var index = 0; index < windows.size() - 1; index++) {
            String currentEnd = endGetter.apply(windows.get(index));
            String nextStart = startGetter.apply(windows.get(index + 1));

            if (currentEnd.compareTo(nextStart) >= 0) {
                return false;
            }
        }
        log.info("{} window validation passed", windowType);
        return true;
    }

    public boolean validateAndSetExternalIdData(VodAssetDto vodAssetEditDto) {
        if (vodAssetEditDto.getExternalId() == null
            && vodAssetEditDto.getExternalIdProvider() == null
            && vodAssetEditDto.getExternalIdType() == null) {
            return true;
        }

        if (vodAssetEditDto.getExternalId() == null
            || vodAssetEditDto.getExternalIdProvider() == null
            || vodAssetEditDto.getExternalIdType() == null) {
            log.error(
                "External Program Id, External Provider and External Id Type must either all be null or all be non-null, for content ID {}",
                vodAssetEditDto.getContentId());
            vodAssetEditDto.setResult(
                "External Program Id, External Provider and External Id Type must either all be null or all be non-null");
            return false;
        }

        List<String> externalIds = Arrays.stream(vodAssetEditDto.getExternalId().split(","))
            .map(String::trim).toList();
        List<String> externalProviders = Arrays.stream(
                vodAssetEditDto.getExternalIdProvider().split(","))
            .map(String::trim).toList();
        List<String> externalIdTypes = Arrays.stream(vodAssetEditDto.getExternalIdType().split(","))
            .map(String::trim).toList();

        if (externalIds.size() != externalProviders.size()
            || externalIds.size() != externalIdTypes.size()) {
            log.error(
                "Comma separated list of External Program Id, External Provider and External Id Type are not of same length, for content ID {}",
                vodAssetEditDto.getContentId());
            vodAssetEditDto.setResult(
                "Comma separated list of External Program Id, External Provider and External Id Type are not of same length");
            return false;
        }

        List<ExternalProviderDto> result = new ArrayList<>();
        for (int i = 0; i < externalIds.size(); ++i) {
            result.add(ExternalProviderDto.builder()
                .externalProgramId(externalIds.get(i))
                .idType(externalIdTypes.get(i))
                .provider(externalProviders.get(i))
                .build());
        }

        vodAssetEditDto.setExternalProvider(result);
        return true;
    }


    public boolean externalIdTypeCheck(VodAssetDto vodAssetDto) {
        List<ExternalProviderDto> externalProviderDtoList = vodAssetDto.getExternalProvider();
        if (externalProviderDtoList == null) {
            return true;
        }
        // Non DB Check
        Set<String> idTypeSet = externalProviderDtoList.stream()
            .map(ExternalProviderDto::getIdType)
            .collect(Collectors.toSet());
        if (idTypeSet.size() != externalProviderDtoList.size()) {
            log.error(
                "Validation failed as Duplicate External ID 'Type' are present for Content ID {}",
                vodAssetDto.getContentId());
            vodAssetDto.setResult(
                "Validation failed as Duplicate External ID 'Type' are present");
            return false;
        }

        return true;
    }

    //more generic function
    private boolean validateAndCorrectFieldLength(VodAssetDto dto,
        String fieldName,
        String currentValue,
        int maxLength,
        String errorMessage,
        BiConsumer<VodAssetDto, String> setter) {
        if (currentValue != null && currentValue.length() > maxLength) {
            log.error("Validation in {} length has failed for contentId {}",
                fieldName, dto.getContentId());
            dto.setResult(errorMessage);
            setter.accept(dto, currentValue.substring(0, maxLength));
            return false;
        }
        return true;
    }

    private boolean duplicateExternalIdEntryCheck(VodAssetDto vodAssetDto) {
        List<ExternalProviderDto> externalProviderDtoList = vodAssetDto.getExternalProvider();
        if (externalProviderDtoList == null) {
            return true;
        }

        // Non DB Check
        Set<String> tupleSet = new HashSet<>();
        for (var externalProviderDto : externalProviderDtoList) {
            String tuple = externalProviderDto.generateProgramTypeProviderTuple();
            if (tupleSet.contains(tuple)) {
                log.error("Duplicate External ID Data present for Content ID {}",
                    vodAssetDto.getContentId());
                vodAssetDto.setResult("Duplicate External ID Data present");
                return false;
            } else {
                tupleSet.add(tuple);
            }
        }

        //ext prog id duplication allowed now.

        return true;
    }

    public void validateVodContent(VodAssetDto vod) {
        if (vod.getFeedWorker() == null || Arrays.stream(feedWorkerList.split(","))
            .noneMatch(vod.getFeedWorker()::equalsIgnoreCase)) {
            throw new CustomException(ASSET_IS_NOT_EDITABLE_FOR_THIS_FEED_WORKER);
        }
        if (!this.validateNonOverlappingWindows(
            vod.getLicenseWindowList(),
            Comparator.comparing(LicenseWindowDto::getAvailableStarting)
                .thenComparing(LicenseWindowDto::getAvailableEnding),
            LicenseWindowDto::getAvailableStarting,
            LicenseWindowDto::getAvailableEnding,
            "License")) {
            throw new CustomException("Overlapping License window  is Present ");
        }
        if (!this.validateNonOverlappingWindows(
            vod.getEventWindowList(),
            Comparator.comparing(AssetEventWindowDto::getEventStarting)
                .thenComparing(AssetEventWindowDto::getEventEnding),
            AssetEventWindowDto::getEventStarting,
            AssetEventWindowDto::getEventEnding,
            "Event")) {
            throw new CustomException("Overlapping Event window  is Present ");
        }
    }


}
