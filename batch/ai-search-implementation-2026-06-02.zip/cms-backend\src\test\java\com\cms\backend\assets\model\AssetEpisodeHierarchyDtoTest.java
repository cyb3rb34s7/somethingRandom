package com.cms.backend.assets.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AssetEpisodeHierarchyDtoTest.class)
class AssetEpisodeHierarchyDtoTest {

    @Test
    void testAssetEpisodeHierarchyDtoWithNormalValues() {
        // Arrange
        String contentId = "content123";
        String countryCode = "KR";
        String vcCpId = "cp456";
        String seasonId = "season789";
        String showId = "show012";

        // Act
        AssetEpisodeHierarchyDto dto = AssetEpisodeHierarchyDto.builder()
            .contentId(contentId)
            .countryCode(countryCode)
            .vcCpId(vcCpId)
            .seasonId(seasonId)
            .showId(showId)
            .build();

        // Assert
        assertEquals(contentId, dto.getContentId());
        assertEquals(countryCode, dto.getCountryCode());
        assertEquals(vcCpId, dto.getVcCpId());
        assertEquals(seasonId, dto.getSeasonId());
        assertEquals(showId, dto.getShowId());
    }
}