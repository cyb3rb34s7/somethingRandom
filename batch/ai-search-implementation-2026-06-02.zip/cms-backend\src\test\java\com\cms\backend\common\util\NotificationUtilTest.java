package com.cms.backend.common.util;

import com.cms.backend.common.model.AlertRequestDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class NotificationUtilTest {

    @Mock
    private HttpMethodHandler httpMethodHandler;

    @InjectMocks
    private NotificationUtil notificationUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Set the notificationServerUrl field using reflection
        ReflectionTestUtils.setField(notificationUtil, "notificationServerUrl", "http://test-url.com");
    }

    @Test
    void testECSConstant() throws NoSuchFieldException, IllegalAccessException {
        // Arrange
        Field ecsField = NotificationUtil.class.getDeclaredField("ECS");
        ecsField.setAccessible(true);
        
        // Act
        String ecsValue = (String) ecsField.get(null);
        
        // Assert
        assertEquals("ECS", ecsValue);
    }

    @Test
    void sendErrorMail_withValidParameters_callsHttpMethodHandler() {
        // Arrange
        String errorType = "Database Error";
        String errorCode = "DB_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("Database connection failed");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenReturn(ResponseEntity.ok().build());

        // Act
        assertDoesNotThrow(() -> notificationUtil.sendErrorMail(exception, errorType, errorCode, errorSource));

        // Assert
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            eq("http://test-url.com/cms/monitoring/notification"),
            eq("POST"),
            any(HttpEntity.class),
            eq(ResponseEntity.class)
        );
    }

    @Test
    void sendErrorMail_withHttpMethodHandlerException_doesNotThrow() {
        // Arrange
        String errorType = "Database Error";
        String errorCode = "DB_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("Database connection failed");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenThrow(new RuntimeException("Network error"));

        // Act & Assert
        assertDoesNotThrow(() -> notificationUtil.sendErrorMail(exception, errorType, errorCode, errorSource));
        
        // Verify that handleHttpExchange was called
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            anyString(),
            eq("POST"),
            any(HttpEntity.class),
            eq(ResponseEntity.class)
        );
    }

    @Test
    void sendAlarm_withValidParameters_callsHttpMethodHandler() {
        // Arrange
        String errorType = "System Alert";
        String errorCode = "AL_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("System overload detected");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenReturn(ResponseEntity.ok().build());

        // Act
        assertDoesNotThrow(() -> notificationUtil.sendAlarm(exception, errorType, errorCode, errorSource));

        // Assert
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            eq("http://test-url.com/cms/monitoring/alarm"),
            eq("POST"),
            any(HttpEntity.class),
            eq(ResponseEntity.class)
        );
    }

    @Test
    void sendAlarm_withHttpMethodHandlerException_doesNotThrow() {
        // Arrange
        String errorType = "System Alert";
        String errorCode = "AL_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("System overload detected");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenThrow(new RuntimeException("Network error"));

        // Act & Assert
        assertDoesNotThrow(() -> notificationUtil.sendAlarm(exception, errorType, errorCode, errorSource));
        
        // Verify that handleHttpExchange was called
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            anyString(),
            eq("POST"),
            any(HttpEntity.class),
            eq(ResponseEntity.class)
        );
    }
    
    @Test
    void sendErrorMail_withNullExceptionMessage_usesRootCause() {
        // Arrange
        String errorType = "Database Error";
        String errorCode = "DB_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception();
        exception.initCause(new Exception("Root cause"));

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenReturn(ResponseEntity.ok().build());

        // Act
        assertDoesNotThrow(() -> notificationUtil.sendErrorMail(exception, errorType, errorCode, errorSource));

        // Assert
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            anyString(),
            eq("POST"),
            any(HttpEntity.class),
            eq(ResponseEntity.class)
        );
    }
    
    @Test
    void sendErrorMail_createsCorrectAlertRequestDto() {
        // Arrange
        String errorType = "Database Error";
        String errorCode = "DB_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("Database connection failed");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenReturn(ResponseEntity.ok().build());

        // Act
        assertDoesNotThrow(() -> notificationUtil.sendErrorMail(exception, errorType, errorCode, errorSource));

        // Assert
        ArgumentCaptor<HttpEntity<AlertRequestDto>> entityCaptor = ArgumentCaptor.forClass((Class)HttpEntity.class);
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            eq("http://test-url.com/cms/monitoring/notification"),
            eq("POST"),
            entityCaptor.capture(),
            eq(ResponseEntity.class)
        );
        
        // Verify entity content
        AlertRequestDto alertRequestDto = entityCaptor.getValue().getBody();
        assertNotNull(alertRequestDto);
        assertEquals(errorSource, alertRequestDto.getSourceService());
        assertEquals("us-west-2", alertRequestDto.getRegion());
        assertEquals("ECS", alertRequestDto.getResourceType());
        assertEquals(errorType, alertRequestDto.getErrorType());
        assertEquals(errorCode, alertRequestDto.getErrorCode());
        assertEquals("Database connection failed", alertRequestDto.getErrorMessage());
    }
    
    @Test
    void sendAlarm_createsCorrectAlertRequestDto() {
        // Arrange
        String errorType = "System Alert";
        String errorCode = "AL_001";
        String errorSource = "CMS-ADMIN";
        Exception exception = new Exception("System overload detected");

        when(httpMethodHandler.handleHttpExchange(anyString(), eq("POST"), any(HttpEntity.class),
            eq(ResponseEntity.class)))
            .thenReturn(ResponseEntity.ok().build());

        // Act
        assertDoesNotThrow(() -> notificationUtil.sendAlarm(exception, errorType, errorCode, errorSource));

        // Assert
        ArgumentCaptor<HttpEntity<AlertRequestDto>> entityCaptor = ArgumentCaptor.forClass((Class)HttpEntity.class);
        verify(httpMethodHandler, times(1)).handleHttpExchange(
            eq("http://test-url.com/cms/monitoring/alarm"),
            eq("POST"),
            entityCaptor.capture(),
            eq(ResponseEntity.class)
        );
        
        // Verify entity content
        AlertRequestDto alertRequestDto = entityCaptor.getValue().getBody();
        assertNotNull(alertRequestDto);
        assertEquals(errorSource, alertRequestDto.getSourceService());
        assertEquals("us-west-2", alertRequestDto.getRegion());
        assertEquals("ECS", alertRequestDto.getResourceType());
        assertEquals(errorType, alertRequestDto.getErrorType());
        assertEquals(errorCode, alertRequestDto.getErrorCode());
        assertEquals("System overload detected", alertRequestDto.getErrorMessage());
    }
}
