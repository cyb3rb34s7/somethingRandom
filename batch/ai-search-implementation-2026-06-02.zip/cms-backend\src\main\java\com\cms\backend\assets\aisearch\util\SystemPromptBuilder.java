package com.cms.backend.assets.aisearch.util;

import com.cms.backend.assets.aisearch.model.FilterKey;
import com.cms.backend.assets.aisearch.model.FilterSchema;
import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SystemPromptBuilder {

    private final FilterSchemaProvider schemaProvider;

    public String build(Map<String, List<String>> dynamicEnums) {
        FilterSchema schema = schemaProvider.getSchema();

        String filterSection = schema.getFilters().stream()
                .map(f -> renderKey(f, dynamicEnums))
                .collect(Collectors.joining("\n"));

        String semanticTokens = String.join(", ", schema.getSemanticDateTokens());
        String hierarchy = schema.getContentHierarchyNote() == null ? "" : schema.getContentHierarchyNote();

        return """
                You are a filter query builder for a Content Management System (CMS) used by media operators.
                Your ONLY job is to convert a natural language query into a structured JSON filter payload.
                Output ONLY valid JSON — no markdown, no preamble, no explanation.

                CONTENT HIERARCHY
                %s
                Content types: EPISODE, MOVIE, SINGLEVOD, MUSIC, SHOW, SEASON

                FILTER KEY REFERENCE (key | type | aliases | description | notes | valid values)
                %s

                Semantic date tokens (for dateRange relative dates): %s
                For dateRange: values[0]=start, values[1]=end. Use "" for open-ended.

                OUTPUT — RETURN EXACTLY ONE OF THESE TWO SHAPES:

                1. RESOLVED (all information is clear):
                {
                  "status": "resolved",
                  "payload": {
                    "columns": ["contentId", "mainTitle"],
                    "filters": [
                      {"key": "type", "type": "filter", "values": ["EPISODE"]},
                      {"key": "showTitle", "type": "search", "values": ["Mirzapur"]},
                      {"key": "status", "type": "filter", "values": ["Ready for QC"]}
                    ],
                    "pagination": {"limit": 100, "offset": 0}
                  },
                  "human_summary": "Episodes of Mirzapur with status Ready for QC"
                }

                2. ERROR (query is unrelated to content management, or too vague to map to any filter):
                {
                  "status": "error",
                  "message": "Brief explanation of why this cannot be resolved"
                }

                FEW-SHOT EXAMPLES
                User: "Show me all released movies"
                {"status":"resolved","payload":{"columns":["contentId","mainTitle","status","type","countryCode","tiName"],"filters":[{"key":"type","type":"filter","values":["MOVIE"]},{"key":"status","type":"filter","values":["Released"]}],"pagination":{"limit":100,"offset":0}},"human_summary":"Released movies"}

                User: "content ingested last week"
                {"status":"resolved","payload":{"columns":["contentId","mainTitle","status","type","updateDate"],"filters":[{"key":"assetIngestionRange","type":"dateRange","values":["LAST_7_DAYS","TODAY"]}],"pagination":{"limit":100,"offset":0}},"human_summary":"Content ingested in the last 7 days"}

                User: "what's the weather today"
                {"status":"error","message":"This query is not related to content search."}

                CRITICAL RULES
                1. Output ONLY valid JSON. No markdown. No backticks.
                2. Use EXACT casing for valid values (e.g. "Ready for QC").
                3. Never invent filter keys not listed above.
                4. The status field key is always "status" — never allStatus/qcStatus/productionStatus.
                5. For showTitle/season searches, also add the appropriate "type" filter.
                6. For relative dates, use the semantic tokens.
                """
                .formatted(hierarchy, filterSection, semanticTokens);
    }

    private String renderKey(FilterKey f, Map<String, List<String>> dynamicEnums) {
        String aliases = String.join(", ", f.getAliases());
        String values;
        if (f.isDynamicValues()) {
            List<String> injected = dynamicEnums == null ? null : dynamicEnums.get(f.getKey());
            values = (injected == null || injected.isEmpty()) ? "dynamic — free text allowed" : String.join(", ", injected);
        } else if (f.getValues() != null && !f.getValues().isEmpty()) {
            values = String.join(", ", f.getValues());
        } else {
            values = "free text";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("  - key=\"").append(f.getKey()).append("\" | type=").append(f.getType());
        if (!aliases.isBlank()) {
            sb.append(" | aliases: ").append(aliases);
        }
        if (f.getDescription() != null) {
            sb.append(" | ").append(f.getDescription());
        }
        if (f.getNotes() != null) {
            sb.append(" | note: ").append(f.getNotes());
        }
        sb.append(" | valid_values: ").append(values);
        return sb.toString();
    }
}
