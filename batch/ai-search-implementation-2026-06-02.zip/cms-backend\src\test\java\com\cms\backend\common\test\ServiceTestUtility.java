package com.cms.backend.common.test;

import static org.mockito.ArgumentMatchers.any;

import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Utility class for common test patterns to reduce code duplication
 */
public class ServiceTestUtility {
    
    /**
     * Creates a standard ResponseEntity with ResponseDto for testing
     * @return ResponseEntity with standard ResponseDto
     */
    public static ResponseEntity<ResponseDto> createStandardResponseEntity() {
        return ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
    }
    
    /**
     * Creates a ResponseEntity with ResponseDto containing payload
     * @param payload The payload to include in response
     * @return ResponseEntity with ResponseDto containing payload
     */
    public static ResponseEntity<ResponseDto> createResponseEntityWithPayload(Map<String, Object> payload) {
        BaseResponseDto baseResponseDto = BaseResponseDto.builder().payload(payload).build();
        ResponseDto responseDto = ResponseDto.builder().rsp(baseResponseDto).build();
        return new ResponseEntity<>(responseDto, HttpStatus.OK);
    }
    
    /**
     * Setup standard HTTP response mock
     * @param httpMethodHandler The mock HttpMethodHandler
     * @param responseEntity The response entity to return
     */
    public static void setupStandardHttpResponse(Object httpMethodHandler, ResponseEntity<ResponseDto> responseEntity) {
        // This method is intentionally left empty as the specific mocking 
        // should be done in individual test methods
    }
}
