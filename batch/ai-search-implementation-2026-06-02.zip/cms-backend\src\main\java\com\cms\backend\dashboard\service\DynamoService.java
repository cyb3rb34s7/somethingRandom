package com.cms.backend.dashboard.service;

import com.cms.backend.common.constants.Constants;
import com.cms.backend.dashboard.model.DashboardCountDto;
import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.pagination.sync.SdkIterable;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementRequest;
import software.amazon.awssdk.services.dynamodb.model.ExecuteStatementResponse;

@Service
@Slf4j
public class DynamoService {

    private final DynamoDbEnhancedClient enhancedClient;
    private DynamoDbTable<DashboardCountDto> dashboardTable;
    private final DynamoDbClient dynamoDbClient;

    public DynamoService(
        DynamoDbEnhancedClient enhancedClient, DynamoDbClient dynamoDbClient) {
        this.enhancedClient = enhancedClient;
        this.dynamoDbClient = dynamoDbClient;
    }

    @PostConstruct
    public void initializeDynamoDbMapper() {
        log.info("Initializing DynamoDB mapper for table: {}", Constants.DASHBOARD_TABLE_NAME);
        this.dashboardTable = enhancedClient.table(Constants.DASHBOARD_TABLE_NAME,
            TableSchema.fromBean(DashboardCountDto.class));
        log.info("Successfully initialized DynamoDB mapper for table: {}", Constants.DASHBOARD_TABLE_NAME);
    }

    public List<DashboardCountDto> getAllDashboardData(String date) {
        log.info("Fetching data for the date {}", date);
        try {
            QueryConditional queryConditional = QueryConditional.keyEqualTo(
                Key.builder()
                    .partitionValue(date)
                    .build()
            );
            QueryEnhancedRequest queryRequest = QueryEnhancedRequest.builder()
                .queryConditional(queryConditional)
                .build();
            PageIterable<DashboardCountDto> results = this.dashboardTable.query(queryRequest);
            List<DashboardCountDto> dashboardData = new ArrayList<>(results.items().stream().toList());
            log.info("Successfully fetched {} dashboard records for date {}", dashboardData.size(), date);
            return dashboardData;
        } catch (Exception e) {
            log.error("Error fetching dashboard data for date {}: {}", date, e.getMessage(), e);
            throw e;
        }
    }

    public List<DashboardCountDto> getDashboardDataByCountry(String date, List<String> countries) {
        log.info("Fetching dashboard data for date {} and {} countries", date, countries.size());
        try {
            List<DashboardCountDto> dashboardList = new ArrayList<>();

            for (String country : countries) {
                QueryConditional queryConditional = QueryConditional.keyEqualTo(
                    Key.builder()
                        .partitionValue(date).sortValue(country)
                        .build());
                QueryEnhancedRequest queryRequest = QueryEnhancedRequest.builder()
                    .queryConditional(queryConditional)
                    .build();
                SdkIterable<Page<DashboardCountDto>> results = this.dashboardTable.index(
                    Constants.DASHBOARD_INDEX).query(queryRequest);

                results.forEach(page -> {
                    dashboardList.addAll(page.items());
                });
            }
            
            log.info("Successfully fetched {} dashboard records for date {} and {} countries", 
                dashboardList.size(), date, countries.size());
            return dashboardList;
        } catch (Exception e) {
            log.error("Error fetching dashboard data for date {} and countries {}: {}", 
                date, countries, e.getMessage(), e);
            throw e;
        }
    }

    public List<String> getCountriesHavingData(String date) {
        log.info("Fetching countries having data for date {}", date);
        try {
            List<String> countryList = new ArrayList<>();
            String partiQlQuery = "SELECT country FROM " + Constants.DASHBOARD_TABLE_NAME + " where added_date = ?";
            ExecuteStatementRequest request = ExecuteStatementRequest.builder().statement(partiQlQuery)
                .parameters(
                    AttributeValue.builder().s(date).build()).build();
            
            log.debug("Executing PartiQL query: {} with parameter: {}", partiQlQuery, date);
            ExecuteStatementResponse result = this.dynamoDbClient.executeStatement(request);
            List<Map<String, AttributeValue>> items = result.items();
            
            if (!items.isEmpty()) {
                items.forEach(item -> {
                    String country = item.get("country").s();
                    if (!countryList.contains(country)) {
                        countryList.add(country);
                    }
                });
            }
            
            log.info("Successfully fetched {} countries having data for date {}", countryList.size(), date);
            return countryList;
        } catch (Exception e) {
            log.error("Error fetching countries having data for date {}: {}", date, e.getMessage(), e);
            throw e;
        }
    }

    public String getLastBatchRunTime() {
        log.info("Fetching last batch run time");
        try {
            Instant currentUTCDate = Instant.now();
            Instant previousUTCDate = currentUTCDate.minusSeconds(24L * 60L * 60L);
            String currentDateStr = currentUTCDate.toString().substring(0, 10);
            String previousDateStr = previousUTCDate.toString().substring(0, 10);
            
            log.info("Querying for last batch run time between dates: {} and {}", previousDateStr, currentDateStr);
            
            String partiQlQuery = "select last_run_time from " + Constants.DASHBOARD_TABLE_NAME
                + " where added_date in (?,?) order by added_date desc;";
            ExecuteStatementRequest request = ExecuteStatementRequest.builder().statement(partiQlQuery)
                .parameters(
                    AttributeValue.builder().s(currentDateStr).build(),
                    AttributeValue.builder().s(previousDateStr).build())
                .build();
                
            log.debug("Executing PartiQL query: {} with parameters: {}, {}", partiQlQuery, currentDateStr, previousDateStr);
            ExecuteStatementResponse result = this.dynamoDbClient.executeStatement(request);
            List<Map<String, AttributeValue>> items = result.items();
            
            if (!items.isEmpty()) {
                Map<String, AttributeValue> item = items.get(0);
                String lastRunTime = item.get("last_run_time").s();
                String formattedDate = formatDate(lastRunTime);
                log.info("Successfully fetched last batch run time: {}", formattedDate);
                return formattedDate;
            } else {
                log.info("No last batch run time found for dates: {} and {}", previousDateStr, currentDateStr);
                return "";
            }
        } catch (Exception e) {
            log.error("Error fetching last batch run time: {}", e.getMessage(), e);
            throw e;
        }
    }

    private String formatDate(String date) {
        Instant instant = Instant.parse(date);
        ZonedDateTime zonedDateTime = instant.atZone(ZoneOffset.UTC);
        DateTimeFormatter toFormatter = DateTimeFormatter.ofPattern("dd/MM/yy' 'HH:mm' UTC'");
        return zonedDateTime.format(toFormatter);

    }

}
