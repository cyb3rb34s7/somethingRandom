package com.cms.backend.evaluation.model;

import com.cms.backend.assets.model.FilterDto;
import com.cms.backend.assets.model.PaginationDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FilterRequestDto {
    private List<FilterDto> filters;
    private PaginationDto pagination;
}