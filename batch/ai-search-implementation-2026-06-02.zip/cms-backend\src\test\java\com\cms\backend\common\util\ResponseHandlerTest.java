package com.cms.backend.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CountryNotAssignedException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.exception.DataNotFoundException;
import com.cms.backend.common.exception.IMSException;
import com.cms.backend.common.exception.InvalidInputDataException;
import com.cms.backend.common.exception.InvalidStatusException;
import com.cms.backend.common.exception.ModifyingRoleOfSelfException;
import com.cms.backend.common.exception.RolesInUseException;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.validation.method.MethodValidationResult;
import org.springframework.validation.method.ParameterErrors;
import org.springframework.validation.method.ParameterValidationResult;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@SpringBootTest(classes = ResponseHandlerTest.class)
class ResponseHandlerTest {


    @Test
    void testProcessMethodResponseSuccessWithNullPayloadKey() {
        // Arrange
        boolean isSuccess = true;
        Object payloadObj = "testPayload";

        // Act
        ResponseDto response = ResponseHandler.processMethodResponse(isSuccess, payloadObj,
            null, null);

        // Assert
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
        assertNull(response.getRsp().getPayload());
    }

    @Test
    void testProcessMethodResponseSuccessWithValidPayloadKey() {
        // Arrange
        boolean isSuccess = true;
        Object payloadObj = "testPayload";
        String payloadKey = "key";

        // Act
        ResponseDto response = ResponseHandler.processMethodResponse(isSuccess, payloadObj,
            payloadKey, null);

        // Assert
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertEquals(Constants.STATUS_OK, response.getRsp().getStat());
        assertNotNull(response.getRsp().getPayload());
        assertEquals(payloadObj, response.getRsp().getPayload().get(payloadKey));
    }

    @Test
    void testProcessMethodResponseError() {
        // Arrange
        boolean isSuccess = false;
        Exception err = new Exception("Test Exception");

        // Act
        ResponseDto response = ResponseHandler.processMethodResponse(isSuccess, null,
            null, err);

        // Assert
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertEquals(Constants.STATUS_FAIL, response.getRsp().getStat());
        assertNotNull(response.getRsp().getErr());
    }

    @Test
    void processMethodResponse_NullPayloadKey_SuccessWithNullPayload() {
        ResponseDto response = ResponseHandler.processMethodResponse(null, "testPayload");
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertNull(response.getRsp().getPayload());
    }

    @Test
    void processMethodResponse_ValidPayloadKey_SuccessWithNonNullPayload() {
        ResponseDto response = ResponseHandler.processMethodResponse("testKey", "testPayload");
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertNotNull(response.getRsp().getPayload());
        assertEquals("testPayload", response.getRsp().getPayload().get("testKey"));
    }

    @Test
    void processMethodResponse_NullPayloadObj_SuccessWithNonNullPayload() {
        ResponseDto response = ResponseHandler.processMethodResponse("testKey", null);
        assertNotNull(response);
        assertNotNull(response.getRsp());
        assertNotNull(response.getRsp().getPayload());
        assertNull(response.getRsp().getPayload().get("testKey"));
    }

    @Test
    void testGenerateBaseMessageWithMessage() {
        Exception e = new Exception("Custom error message");
        String expectedMessage = ": Custom error message";
        String actualMessage = ResponseHandler.generateBaseMessage(e);
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void testGenerateBaseMessageWithCause() {
        Throwable cause = new IllegalArgumentException("Cause message");
        Exception e = new Exception(cause);
        String expectedMessage = ": java.lang.IllegalArgumentException: Cause message";
        String actualMessage = ResponseHandler.generateBaseMessage(e);
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void testGenerateBaseMessageWithNullCause() {
        Exception e = new Exception((Throwable) null);
        String expectedMessage = ": An Error has occurred";
        String actualMessage = ResponseHandler.generateBaseMessage(e);
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void testGenerateBaseMessageWithCauseMessage() {
        String expectedMessage = ": An Error has occurred.";
        Exception e = new Exception((String) null, new Throwable("An Error has occurred."));
        String actualMessage = ResponseHandler.generateBaseMessage(e);
        assertEquals(expectedMessage, actualMessage);
    }


    @Test
    void testGenerateBaseMessageWithNullMessageAndCause() {
        Exception e = new Exception((String) null, (Throwable) null);
        String expectedMessage = ": An Error has occurred";
        String actualMessage = ResponseHandler.generateBaseMessage(e);
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void setResponseDetailsTest() {
        boolean responses = true;

        // ConstraintViolationException Test
        responses &= ResponseHandler.processMethodResponse(
                new ConstraintViolationException(Set.of())).getRsp().getErr().getCode()
            .equals(ErrorCode.INVALID_INPUT_DATA);

        // InvalidInputDataException Test
        responses &= ResponseHandler.processMethodResponse(
                new InvalidInputDataException(ErrorMsg.INVALID_INPUT_DATA)).getRsp().getErr().getCode()
            .equals(ErrorCode.INVALID_INPUT_DATA);

        //HandlerMethodValidationException Test
        MethodValidationResult methodValidationResult = new HandlerMethodExceptionMethodValidationResult();
        responses &= ResponseHandler.processMethodResponse(
                new HandlerMethodValidationException(methodValidationResult)).getRsp().getErr()
            .getCode()
            .equals(ErrorCode.INVALID_INPUT_DATA);

        // customException Test
        responses &= ResponseHandler.processMethodResponse(
                new CustomException(ErrorMsg.INVALID_INPUT_DATA)).getRsp().getErr().getCode()
            .equals(ErrorCode.INVALID_INPUT_DATA);

        // noHandlerException Test
        responses &= ResponseHandler.processMethodResponse(
                new NoHandlerFoundException(Constants.METHOD_POST, "testUrl", new HttpHeaders()))
            .getRsp().getErr().getCode()
            .equals(ErrorCode.REQUIRED_URI_NOT_EXISTS);

        // noResourceFoundException Test
        responses &= ResponseHandler.processMethodResponse(
                new NoResourceFoundException(HttpMethod.GET, "testUrl")).getRsp().getErr().getCode()
            .equals(ErrorCode.REQUIRED_URI_NOT_EXISTS);

        // MissingServletRequestParameterException Test
        responses &= ResponseHandler.processMethodResponse(
                new MissingServletRequestParameterException("testParam", "String")).getRsp().getErr()
            .getCode()
            .equals(ErrorCode.MISSING_REQUIRED_QUERY_PARAM);

        // HttpRequestMethodNotSupportedException Test
        responses &= ResponseHandler.processMethodResponse(
                new HttpRequestMethodNotSupportedException("unsupported Method")).getRsp().getErr()
            .getCode()
            .equals(ErrorCode.UNSUPPORTED_HTTP_METHOD);

        // CountryNotAssignedException Test
        responses &= ResponseHandler.processMethodResponse(
                new CountryNotAssignedException("COUNTRY_NOT_ASSIGNED")).getRsp().getErr().getCode()
            .equals(ErrorCode.COUNTRY_NOT_ASSIGNED);

        // IMSException Test
        responses &= ResponseHandler.processMethodResponse(
                new IMSException("Ims Exception occcured")).getRsp().getErr().getCode()
            .equals(ErrorCode.IMS_ERROR);

        // AssetApiFailureException Test
        responses &= ResponseHandler.processMethodResponse(
                new AssetApiFailureException("Asset Api Failure Exception")).getRsp().getErr().getCode()
            .equals(ErrorCode.ASSET_API_ERROR);
        assertTrue(responses);
    }

    @Test
    void testSetResponseDetails_WithNullException() {
        ErrorResponseDto errorResponseDto = ResponseHandler.setResponseDetails(null);
        assertEquals(ErrorCode.INTERNAL_SERVER_ERROR, errorResponseDto.getCode());
        assertEquals(ErrorMsg.INTERNAL_SERVER_ERROR, errorResponseDto.getMsg());
    }

    @Test
    void setDataExceptionsTest() {
        boolean responses = true;
        responses &= ResponseHandler.processMethodResponse(
                new DataNotFoundException("Data Not Found")).getRsp().getErr().getCode()
            .equals(ErrorCode.DATA_NOT_FOUND);

        responses &= ResponseHandler.processMethodResponse(
                new ModifyingRoleOfSelfException(ErrorMsg.MODIFYING_ROLE_OF_SELF)).getRsp().getErr()
            .getCode()
            .equals(ErrorCode.MODIFYING_ROLE_OF_SELF);

        responses &= ResponseHandler.processMethodResponse(
                new DataIntegrityViolationException(ErrorMsg.DATA_INTEGRITY_VIOLATION)).getRsp()
            .getErr().getCode()
            .equals(ErrorCode.DATA_INTEGRITY_VIOLATION);

        responses &= ResponseHandler.processMethodResponse(
                new RolesInUseException(ErrorMsg.USERS_STILL_ASSIGNED)).getRsp().getErr().getCode()
            .equals(ErrorCode.USERS_STILL_ASSIGNED);

        responses &= ResponseHandler.processMethodResponse(
                new InvalidStatusException(ErrorMsg.INVALID_STATUS)).getRsp().getErr().getCode()
            .equals(ErrorCode.INVALID_STATUS);

        Assertions.assertTrue(responses);
    }

}

class HandlerMethodExceptionMethodValidationResult implements MethodValidationResult {

    @Override
    public Object getTarget() {
        return MethodValidationResult.emptyResult().getTarget();
    }

    @Override
    public Method getMethod() {
        return MethodValidationResult.emptyResult().getMethod();
    }

    @Override
    public boolean isForReturnValue() {
        return false;
    }

    @Override
    public boolean hasErrors() {
        return MethodValidationResult.super.hasErrors();
    }

    @Override
    public List<? extends MessageSourceResolvable> getAllErrors() {
        return MethodValidationResult.super.getAllErrors();
    }

    @Override
    public List<ParameterValidationResult> getParameterValidationResults() {
        return List.of();
    }


    @Override
    public List<ParameterValidationResult> getValueResults() {
        return MethodValidationResult.super.getValueResults();
    }

    @Override
    public List<ParameterErrors> getBeanResults() {
        return MethodValidationResult.super.getBeanResults();
    }

    @Override
    public List<MessageSourceResolvable> getCrossParameterValidationResults() {
        return List.of();
    }
}