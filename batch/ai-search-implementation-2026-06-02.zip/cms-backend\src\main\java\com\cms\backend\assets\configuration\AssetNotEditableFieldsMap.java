package com.cms.backend.assets.configuration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AssetNotEditableFieldsMap {

    public static final String RUNNING_TIME = "runningTime";
    public static final String CHAPTER_TIME = "chapterTime";
    public static final String CHAPTER_DESCRIPTION = "chapterDescription";
    public static final String STREAM_URI = "streamUri";
    public static final String QUALITY = "quality";
    public static final String AUDIO_LANG = "audioLang";
    public static final String SUBTITLE_LANG = "subtitleLang";
    public static final String DRM = "drm";
    public static final String AD_TAG = "adTag";
    public static final String SEASON_ID = "seasonId";
    public static final String SHOW_ID = "showId";
    public static final String SEASON_NO = "seasonNo";
    public static final String SCENE_PREVIEW_URL = "webVttUrl";
    public static final String DRM_DATA = "drmData";
    public static final String SHOW_TITLE = "showTitle";
    public static final String SEASON_TITLE = "seasonTitle";

    private AssetNotEditableFieldsMap() {
        throw new IllegalStateException("AssetNotEditableFieldsMap class");
    }

    public static Map<String, List<String>> getNotEditableFields() {
        Map<String, List<String>> notEditableFields = new HashMap<>();
        notEditableFields.put("MOVIE", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        notEditableFields.put("MUSIC", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        notEditableFields.put("SEASON", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        notEditableFields.put("SHOW", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        notEditableFields.put("EPISODE", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        notEditableFields.put("SINGLEVOD", List.of(
            RUNNING_TIME,
            CHAPTER_TIME,
            CHAPTER_DESCRIPTION,
            STREAM_URI,
            QUALITY,
            AUDIO_LANG,
            SUBTITLE_LANG,
            DRM,
            AD_TAG, SEASON_ID, SEASON_NO, SHOW_ID, SCENE_PREVIEW_URL, DRM_DATA, SHOW_TITLE,
            SEASON_TITLE));
        return notEditableFields;
    }
}
