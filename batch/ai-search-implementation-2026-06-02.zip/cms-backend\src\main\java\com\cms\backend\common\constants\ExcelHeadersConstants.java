package com.cms.backend.common.constants;

import lombok.Generated;

@Generated
public class ExcelHeadersConstants {

    private ExcelHeadersConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String PROGRAM_ID = "programid";
    public static final String ASSET_ID = "assetid";
    public static final String PROGRAM_TYPE = "programtype";
    public static final String COUNTRY = "country";
    public static final String PROVIDER_ID = "providerid";


    public static final String MAIN_TITLE = "maintitle";
    public static final String SHORT_TITLE = "shorttitle";
    public static final String DURATION_IN_SEC = "duration(sec)";
    public static final String AD_TAGS = "adtags";
    public static final String STREAM_URL = "streamurl";
    public static final String SYNOPSIS = "synopsis";
    public static final String RELEASE_DATE = "originalreleasedate";
    public static final String GENRE = "genre";
    public static final String ID_TYPE = "idtype";
    public static final String CONTENT_PARTNER = "contentpartner/licensor";
    public static final String EXTERNAL_PROGRM_ID = "externalprogramid";
    public static final String PROVIDER = "provider";
    public static final String CONTENT_TIER = "contenttier";
}
