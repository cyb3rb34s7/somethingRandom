package com.cms.backend.common.exception;

public class ModifyingRoleOfSelfException extends RuntimeException {

    public ModifyingRoleOfSelfException(String message) {
        super(message);
    }
}
