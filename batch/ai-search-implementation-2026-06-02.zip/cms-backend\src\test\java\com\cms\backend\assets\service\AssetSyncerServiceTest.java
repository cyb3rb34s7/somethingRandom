package com.cms.backend.assets.service;

import com.cms.backend.assets.model.SqsMessageDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.enums.AssetEvents;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AssetSyncerServiceTest {

    @Mock
    private SqsMessageService sqsMessageService;

    @InjectMocks
    private AssetSyncerService assetSyncerService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Positive test cases
    @Test
    void pushMessageToSqsAsync_withAutoSyncEvent_callsSqsMessageService_P() {
        // Arrange
        String eventType = AssetEvents.AUTO_SYNC.value;
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("asset1")
            .vcCpId("cp1")
            .countryCode("US")
            .feedWorker("CMS")
            .build();
        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset);

        try (MockedStatic<org.slf4j.MDC> mdcMock = mockStatic(org.slf4j.MDC.class)) {
            mdcMock.when(() -> org.slf4j.MDC.get(AssetSyncerService.X_TRACE_ID))
                .thenReturn("trace-123");

            // Act
            assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

            // Assert
            verify(sqsMessageService, times(1)).pushMessageToSqs(any(SqsMessageDto.class),
                anyString());
        }
    }

    @Test
    void pushMessageToSqsAsync_withNonAutoSyncEvent_callsSqsMessageService_P() {
        // Arrange
        String eventType = "UPDATE";
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("asset1")
            .vcCpId("cp1")
            .countryCode("US")
            .feedWorker("CMS")
            .build();
        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset);

        try (MockedStatic<org.slf4j.MDC> mdcMock = mockStatic(org.slf4j.MDC.class)) {
            mdcMock.when(() -> org.slf4j.MDC.get(AssetSyncerService.X_TRACE_ID))
                .thenReturn("trace-456");

            // Act
            assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

            // Assert
            ArgumentCaptor<SqsMessageDto> messageCaptor = ArgumentCaptor.forClass(
                SqsMessageDto.class);
            ArgumentCaptor<String> feedWorkerCaptor = ArgumentCaptor.forClass(String.class);
            verify(sqsMessageService, times(1)).pushMessageToSqs(messageCaptor.capture(),
                feedWorkerCaptor.capture());

            SqsMessageDto capturedMessage = messageCaptor.getValue();
            assertEquals("asset1", capturedMessage.getAssetId());
            assertEquals("cp1", capturedMessage.getContentProvider());
            assertEquals("US", capturedMessage.getCountryCode());
            assertEquals(eventType, capturedMessage.getEventType());
            assertEquals(Constants.CONSTANT_ASSET, capturedMessage.getEventSource());
            assertEquals("CMS-Admin", capturedMessage.getHost());
            assertEquals("trace-456", capturedMessage.getTraceId());
            assertEquals("CMS", feedWorkerCaptor.getValue());
        }
    }

    @Test
    void pushMessageToSqsAsync_withMultipleAssets_callsSqsMessageServiceForEach_P() {
        // Arrange
        String eventType = "CREATE";
        VodAssetDto vodAsset1 = VodAssetDto.builder()
            .contentId("asset1")
            .vcCpId("cp1")
            .countryCode("US")
            .feedWorker("CMS")
            .build();
        VodAssetDto vodAsset2 = VodAssetDto.builder()
            .contentId("asset2")
            .vcCpId("cp2")
            .countryCode("UK")
            .feedWorker("CMS_GRACENOTE")
            .build();
        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset1, vodAsset2);

        // Act
        assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

        // Assert
        verify(sqsMessageService, times(2)).pushMessageToSqs(any(SqsMessageDto.class), anyString());
    }

    @Test
    void pushMessageToSqsAsync_withAutoSyncEventType_setsTvplusDeltaEventSource_P() {
        // Arrange
        String eventType = AssetEvents.AUTO_SYNC.value;
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("asset1")
            .vcCpId("cp1")
            .countryCode("US")
            .feedWorker("TVPLUS_DELTA")
            .build();
        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset);

        try (MockedStatic<org.slf4j.MDC> mdcMock = mockStatic(org.slf4j.MDC.class)) {
            mdcMock.when(() -> org.slf4j.MDC.get(AssetSyncerService.X_TRACE_ID))
                .thenReturn("trace-789");

            // Act
            assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

            // Assert
            ArgumentCaptor<SqsMessageDto> messageCaptor = ArgumentCaptor.forClass(
                SqsMessageDto.class);
            verify(sqsMessageService, times(1)).pushMessageToSqs(messageCaptor.capture(),
                anyString());

            SqsMessageDto capturedMessage = messageCaptor.getValue();
            assertEquals("TVPLUS_DELTA", capturedMessage.getEventSource());
            assertEquals(eventType, capturedMessage.getEventType());
        }
    }

    // Negative test cases
    @Test
    void pushMessageToSqsAsync_withNullEventType_doesNotCallSqsMessageService_N() {
        // Arrange
        String eventType = null;
        VodAssetDto vodAsset = VodAssetDto.builder()
            .contentId("asset1")
            .vcCpId("cp1")
            .countryCode("US")
            .feedWorker("CMS")
            .build();
        List<VodAssetDto> vodAssetDtoList = List.of(vodAsset);

        // Act
        assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

        // Assert
        verify(sqsMessageService, never()).pushMessageToSqs(any(SqsMessageDto.class), anyString());
    }

    @Test
    void pushMessageToSqsAsync_withEmptyList_doesNotCallSqsMessageService_N() {
        // Arrange
        String eventType = "UPDATE";
        List<VodAssetDto> vodAssetDtoList = List.of();

        // Act
        assetSyncerService.pushMessageToSqsAsync(eventType, vodAssetDtoList);

        // Assert
        verify(sqsMessageService, never()).pushMessageToSqs(any(SqsMessageDto.class), anyString());
    }


}
