package com.cms.backend.assets.model;

import com.cms.backend.assets.configuration.ExportFieldMappingConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

@Data
public class ExportStateContext {

    private Workbook currentExcel;
    private Sheet currentSheet;
    private int currentRow = 0;

    private CellStyle columnHeaderStyle;
    private CellStyle dataStyle;
    private CellStyle bottomBorderStyle;
    private Map<String, CellStyle> groupStyles = new HashMap<>();

    private boolean isSelectiveExport = false;
    private boolean isEvaluation = false; // Fixes concurrency bug
    private List<String> selectedColumns = new ArrayList<>();
    private String[] fieldsToProcess;

    public ExportStateContext() {
        // Default constructor required for framework instantiation
    }

    public void setupSelectiveExport(List<String> selectedColumns, boolean isEvaluation) {
        this.isEvaluation = isEvaluation;
        this.isSelectiveExport = !selectedColumns.isEmpty();
        this.selectedColumns = new ArrayList<>(selectedColumns);

        if (this.isSelectiveExport) {
            this.fieldsToProcess = selectedColumns.toArray(new String[0]);
        } else {
            this.fieldsToProcess = ExportFieldMappingConfig.getFieldsInOrder(isEvaluation);
        }
    }

    public void setupFullExport(boolean isEvaluation) {
        this.isEvaluation = isEvaluation;
        this.isSelectiveExport = false;
        this.selectedColumns = new ArrayList<>();
        this.fieldsToProcess = isEvaluation ? ExportFieldMappingConfig.EVALUATION_FULL_EXPORT_FIELDS
                : ExportFieldMappingConfig.FULL_EXPORT_FIELDS;
    }
}
