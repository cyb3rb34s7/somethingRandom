package com.cms.backend.assets.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AssetCastDto {

    private String contentId;
    private String vcCpId;
    private String countryCode;
    @Size(max = 254)
    private String name;
    @Size(max = 254)
    private String role;
    @Size(max = 254)
    private String characterName;
    private String regrId;
    private String crctrId;
    private String feedWorker;
    
}