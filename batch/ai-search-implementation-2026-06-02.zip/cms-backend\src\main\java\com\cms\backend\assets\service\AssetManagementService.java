package com.cms.backend.assets.service;


import com.cms.backend.assets.configuration.S3ClientConfig;
import com.cms.backend.assets.model.AssetEventWindowDto;
import com.cms.backend.assets.model.AssetKeyDto;
import com.cms.backend.assets.model.AssetUpdateRequestBodyDto;
import com.cms.backend.assets.model.LicenseWindowDto;
import com.cms.backend.assets.model.StatusGetDto;
import com.cms.backend.assets.model.VodAssetDto;
import com.cms.backend.assets.model.VodAssetUpdateDto;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.time.Instant;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

@Service
@Slf4j
public class AssetManagementService {

    private final RegionEndpointService regionEndpointService;
    private final HttpMethodHandler httpMethodHandler;
    private final AssetAsyncService assetAsyncService;
    private final S3ClientConfig s3Client;
    private final ValidationAsset validationAsset;
    private final AssetHelperService assetHelperService;
    private final AssetSyncerService assetSyncerService;
    @Value("${SMF_SPEC_FILENAME}")
    private String smfSpecFilename;
    @Value("${TVP_BUCKET_NAME}")
    private String tvpBucketName;

    public AssetManagementService(RegionEndpointService regionEndpointService,
        HttpMethodHandler httpMethodHandler, AssetAsyncService assetAsyncService,
        S3ClientConfig s3Client, ValidationAsset validationAsset,
        AssetHelperService assetHelperService, AssetSyncerService assetSyncerService) {
        this.regionEndpointService = regionEndpointService;
        this.httpMethodHandler = httpMethodHandler;
        this.assetAsyncService = assetAsyncService;
        this.s3Client = s3Client;
        this.validationAsset = validationAsset;
        this.assetHelperService = assetHelperService;
        this.assetSyncerService = assetSyncerService;
    }

    public ResponseDto bulkRevokeHierarchy(List<AssetKeyDto> assetsList) {
        try {
            log.info("Bulk revoke hierarchy request received for assets={}", assetsList);
            HttpEntity<List<AssetKeyDto>> httpEntity = new HttpEntity<>(assetsList);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.BULK_REVOKE_HIERARCHY;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);
            log.info("Response from asset api for bulk revoke hierarchy received ");
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Error while revoking bulk hierarchy={}", e.getMessage());
            throw new AssetApiFailureException("Error while revoking bulk hierarchy");
        }
    }

    public ResponseDto getStreamUrls(String contentId, String cpId, String countryCode) {

        try {
            log.info("Get stream urls request received for contentId={}, cpId={}, countryCode={}",
                contentId, cpId, countryCode);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_VIEW_MEDIA_URLS;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            builder.queryParam(Constants.COUNTRY, countryCode);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            log.error("Error while getting view Media Urls={}", ex.getMessage());
            throw new AssetApiFailureException("Error while getting view Media Urls");
        }

    }

    public ResponseDto getCpData(String contentId, String cpId, String country) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_CP_VIEW;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            builder.queryParam(Constants.COUNTRY, country);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            throw new AssetApiFailureException("Error while getting  cp data");
        }

    }

    public ResponseDto getGracenoteData(String contentId, String cpId, String country) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.GET_ASSET_GRACENOTE_VIEW;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            builder.queryParam(Constants.COUNTRY, country);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            throw new AssetApiFailureException("Error while getting  gracenote data");
        }

    }

    public ResponseDto updateCPData(VodAssetDto vodAssetDto) {
        try {
            HttpEntity<VodAssetDto> httpEntity = new HttpEntity<>(
                vodAssetDto);
            log.info("Updating cp data for asset={}", vodAssetDto);
            String finalUrl = regionEndpointService.getOpenAPIEndpoint() + Constants.CP_UPDATE;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, httpEntity,
                ResponseDto.class);

            return responseEntity.getBody();
        } catch (CustomException ex) {
            log.error("Error while updating cp data:{}", ex.getMessage());
            throw new AssetApiFailureException(ex.getMessage());
        } catch (Exception e) {
            log.error("Error while update asset:{}", e.getMessage());
            throw new AssetApiFailureException("Error while updating cp data");
        }
    }

    public ResponseDto getStaticJSON(String fileName) {
        log.debug("Fetching static JSON file with name {} and cloudfront{}", fileName,
            regionEndpointService.getCloudFrontUrlCms());
        try {
            Map<String, Object> payload = new HashMap<>();
            String url = regionEndpointService.getCloudFrontUrlCms() + "/" + fileName + "?dt="
                + Instant.now().toEpochMilli();
            payload.put("data", httpMethodHandler.readCloudFrontUrl(url));
            return ResponseDto.builder().rsp(BaseResponseDto.builder().payload(payload).build())
                .build();
        } catch (Exception ex) {
            log.error("Error while fetching static json file:{}", ex.getMessage());
            throw new CustomException("Error while fetching static json file");
        }
    }

    public byte[] getS3File(String fileName) {

        log.debug("Fetching S3 file with  name{}", fileName);
        String fileUrl =
            regionEndpointService.getCloudFrontUrlCms() + "/ " + fileName + "?dt=" + Instant.now()
                .toEpochMilli();
        ResponseEntity<byte[]> response = httpMethodHandler.downloadFile(fileUrl,
            Constants.METHOD_GET, null, byte[].class);
        return response.getBody();
    }

    public ResponseDto getPrdAssetView(String contentId, String cpId, String country) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpointPRD() + Constants.GET_ASSET_VIEW;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(finalUrl);
            builder.queryParam(Constants.CONTENT_ID, contentId);
            builder.queryParam(Constants.CP_ID, cpId);
            builder.queryParam(Constants.COUNTRY, country);
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                builder.build().toUriString(),
                Constants.METHOD_GET, null,
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception ex) {
            throw new AssetApiFailureException("Error while getting view");
        }
    }

    public ResponseDto getPrdAssetViewFilters(AssetKeyDto assetKeyDto) {
        try {
            String finalUrl =
                regionEndpointService.getOpenAPIEndpointPRD() + Constants.GET_ASSET_VIEW_FILTERS;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl,
                Constants.METHOD_POST, new HttpEntity<>(assetKeyDto),
                ResponseDto.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new AssetApiFailureException("Error while Prd asset View Filters");
        }
    }

    public ResponseDto getSmfFileName() {
        Map<String, Object> payload = new HashMap<>();
        payload.put("name", smfSpecFilename);
        return ResponseDto.builder().rsp(BaseResponseDto.builder().payload(payload).build())
            .build();
    }

    public ResponseEntity<byte[]> getFileFromS3(String path, String fileName) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(
            ContentDisposition.attachment().filename(fileName).build());
        try {
            log.debug("Downloading file from S3 with path={} and filename={}", path, fileName);
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(tvpBucketName)
                .key(path + fileName).build();
            ResponseBytes<GetObjectResponse> objectBytes = s3Client.amazonS3()
                .getObject(getObjectRequest, ResponseTransformer.toBytes());
            byte[] fileContent = objectBytes.asByteArray();
            return ResponseEntity.ok().headers(headers).body(fileContent);
        } catch (Exception e) {
            log.error("Error while downloading file from S3: {}", e.getMessage());
            return ResponseEntity.ok().headers(headers).body(null);
        }
    }

    public ResponseDto updateVodAssetFromPortal(
        AssetUpdateRequestBodyDto assetUpdateRequestBodyDto) {
        if (assetUpdateRequestBodyDto == null) {
            return ResponseDto.builder().rsp(BaseResponseDto.builder().stat(Constants.STATUS_OK)
                .err(ErrorResponseDto.builder().code(Constants.STATUS_OK)
                    .msg(Constants.UPDATE_API_ERROR).build()).build()).build();
        }
        ResponseDto responseDto = ResponseDto.builder().rsp(
            BaseResponseDto.builder().stat(Constants.STATUS_OK).err(
                ErrorResponseDto.builder().code(Constants.STATUS_OK)
                    .msg(Constants.VOD_ASSET_IS_NULL).build()).build()).build();
        if (assetUpdateRequestBodyDto.getVodAssetUpdateDto() != null
            && assetUpdateRequestBodyDto.getVodAssetUpdateDto().getVodAsset() != null) {
            responseDto = updateVodAsset(assetUpdateRequestBodyDto.getVodAssetUpdateDto());
            if (assetUpdateRequestBodyDto.getAssetChangeHistoryDto() != null) {
                assetAsyncService.insertAssetModificationHistory(
                    assetUpdateRequestBodyDto.getAssetChangeHistoryDto());
            }
        }

        return responseDto;
    }

    private ResponseDto updateVodAsset(VodAssetUpdateDto vodAssetUpdateDto) {
        try {
            log.info("Updating asset with payload={}", vodAssetUpdateDto.getVodAsset().toString());
            validationAsset.validateVodContent(vodAssetUpdateDto.getVodAsset());

            List<VodAssetDto> vodAssetDtoList = assetHelperService.getAssetStatusByAPI(
                StatusGetDto.builder()
                    .assetList(List.of(
                        AssetKeyDto.builder().vcCpId(vodAssetUpdateDto.getVodAsset().getVcCpId())
                            .countryCode(vodAssetUpdateDto.getVodAsset().getCountryCode())
                            .contentId(vodAssetUpdateDto.getVodAsset().getContentId())
                            .build())).build());
            assetHelperService.validateStatusForEditing(vodAssetUpdateDto.getVodAsset(),
                vodAssetDtoList);

            HttpEntity<VodAssetUpdateDto> httpEntity = new HttpEntity<>(vodAssetUpdateDto);
            String finalUrl =
                regionEndpointService.getOpenAPIEndpoint() + Constants.VOD_ASSET_UPDATE;
            ResponseEntity<ResponseDto> responseEntity = httpMethodHandler.handleHttpExchange(
                finalUrl, Constants.METHOD_POST, httpEntity, ResponseDto.class);

            //need to handle push failure case
            vodAssetDtoList.forEach(vod -> {
                if (vod != null && vod.getIsSyncBlocked() != null && !vod.getIsSyncBlocked()) {
                    assetSyncerService.pushMessageToSqsAsync(Constants.CONSTANT_UPDATE, List.of(
                        VodAssetDto.builder().contentId(vod.getContentId())
                            .feedWorker(vod.getFeedWorker()).vcCpId(vod.getVcCpId())
                            .countryCode(vod.getCountryCode()).build()));


                }
            });
            return responseEntity.getBody();
        } catch (IllegalArgumentException e) {
            log.error("Bad request exception occurred  updating asset details:{}",
                e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (CustomException ex) {
            log.error("Custom error log:-Error while update asset:{}", ex.getMessage());
            throw new CustomException(ex.getMessage());
        } catch (Exception e) {
            log.error("Error while update asset:{}", e.getMessage());
            throw new AssetApiFailureException("Error while updating asset");
        }
    }
}
