package com.cms.backend.common.util;


import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.exception.AssetApiFailureException;
import com.cms.backend.common.exception.CountryNotAssignedException;
import com.cms.backend.common.exception.CustomException;
import com.cms.backend.common.exception.DataNotFoundException;
import com.cms.backend.common.exception.IMSException;
import com.cms.backend.common.exception.InvalidInputDataException;
import com.cms.backend.common.exception.InvalidStatusException;
import com.cms.backend.common.exception.ModifyingRoleOfSelfException;
import com.cms.backend.common.exception.RolesInUseException;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ErrorResponseDto;
import com.cms.backend.common.model.ResponseDto;
import jakarta.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;


public class ResponseHandler {

    private ResponseHandler() {
    }

    public static ResponseDto processSuccess(Map<String, Object> daoResponse) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_OK).payload(daoResponse).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }

    public static ResponseDto processError(ErrorResponseDto errorDto) {
        BaseResponseDto baseDto = BaseResponseDto.builder()
            .stat(Constants.STATUS_FAIL).err(errorDto).build();
        return ResponseDto.builder().rsp(baseDto).build();
    }

    public static ResponseDto processMethodResponse(boolean isSuccess, Object payloadObj,
        String payloadKey, Exception err) {
        if (isSuccess) {
            //Success
            if (payloadKey == null) {
                return processSuccess(null);
            } else {
                Map<String, Object> payload = new HashMap<>();
                payload.put(payloadKey, payloadObj);
                return processSuccess(payload);
            }
        } else {
            // Error
            return processError(
                setResponseDetails(err)
            );
        }
    }

    public static ResponseDto processMethodResponse(String payloadKey, Object payloadObj) {
        if (payloadKey == null) {
            return processSuccess(null);
        } else {
            Map<String, Object> payload = new HashMap<>();
            payload.put(payloadKey, payloadObj);
            return processSuccess(payload);
        }
    }

    public static ResponseDto processMethodResponse(Exception err) {
        return processError(
            setResponseDetails(err)
        );
    }

    public static ErrorResponseDto setResponseDetails(Exception e) {
        if (e == null) {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR);
        }

        String baseMessage = generateBaseMessage(e);
        ErrorResponseDto resp = setDataExceptions(e, baseMessage);
        if (resp != null) {
            return resp;
        }
        if (e instanceof MethodArgumentTypeMismatchException
            || e instanceof MethodArgumentNotValidException
            || e instanceof ConstraintViolationException
            || e instanceof InvalidInputDataException
            || e instanceof HandlerMethodValidationException
            || e instanceof CustomException) {
            return new ErrorResponseDto(ErrorCode.INVALID_INPUT_DATA,
                ErrorMsg.INVALID_INPUT_DATA + baseMessage);
        } else if (e instanceof NoHandlerFoundException || e instanceof NoResourceFoundException) {
            return new ErrorResponseDto(ErrorCode.REQUIRED_URI_NOT_EXISTS,
                ErrorMsg.REQUIRED_URI_NOT_EXISTS + baseMessage);
        } else if (e instanceof MissingServletRequestParameterException) {
            return new ErrorResponseDto(ErrorCode.MISSING_REQUIRED_QUERY_PARAM,
                ErrorMsg.MISSING_REQUIRED_QUERY_PARAM + baseMessage);
        } else if (e instanceof HttpRequestMethodNotSupportedException) {
            return new ErrorResponseDto(ErrorCode.UNSUPPORTED_HTTP_METHOD,
                ErrorMsg.UNSUPPORTED_HTTP_METHOD + baseMessage);
        } else if (e instanceof CountryNotAssignedException) {
            return new ErrorResponseDto(ErrorCode.COUNTRY_NOT_ASSIGNED,
                ErrorMsg.COUNTRY_NOT_ASSIGNED + baseMessage);
        } else if (e instanceof IMSException) {
            return new ErrorResponseDto(ErrorCode.IMS_ERROR,
                ErrorMsg.IMS_ERROR + baseMessage);
        } else if (e instanceof AssetApiFailureException) {
            return new ErrorResponseDto(ErrorCode.ASSET_API_ERROR,
                ErrorMsg.ASSET_API_ERROR + baseMessage);
        } else {
            return new ErrorResponseDto(ErrorCode.INTERNAL_SERVER_ERROR,
                ErrorMsg.INTERNAL_SERVER_ERROR + baseMessage);
        }
    }

    private static ErrorResponseDto setDataExceptions(Exception e, String baseMessage) {
        if (e instanceof DataNotFoundException) {
            return new ErrorResponseDto(ErrorCode.DATA_NOT_FOUND,
                ErrorMsg.DATA_NOT_FOUND + baseMessage);
        } else if (e instanceof ModifyingRoleOfSelfException) {
            return new ErrorResponseDto(ErrorCode.MODIFYING_ROLE_OF_SELF,
                ErrorMsg.MODIFYING_ROLE_OF_SELF + baseMessage);
        } else if (e instanceof DataIntegrityViolationException) {
            return new ErrorResponseDto(ErrorCode.DATA_INTEGRITY_VIOLATION,
                ErrorMsg.DATA_INTEGRITY_VIOLATION);
        } else if (e instanceof RolesInUseException) {
            return new ErrorResponseDto(ErrorCode.USERS_STILL_ASSIGNED,
                ErrorMsg.USERS_STILL_ASSIGNED + baseMessage);
        } else if (e instanceof InvalidStatusException) {
            return new ErrorResponseDto(ErrorCode.INVALID_STATUS,
                ErrorMsg.INVALID_STATUS + baseMessage);
        }
        return null;
    }

    public static String generateBaseMessage(Exception e) {
        String baseMessage = ": ";
        if (e.getMessage() != null) {
            baseMessage += e.getMessage();
        } else if (e.getCause() != null && e.getCause().getMessage() != null) {
            baseMessage += e.getCause().getMessage();
        } else {
            baseMessage += "An Error has occurred";
        }
        return baseMessage;
    }
}
