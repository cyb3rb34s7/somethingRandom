package com.cms.backend.common.configuration;

import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.SecurityUser;
import java.util.Map;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

public class MdcTaskDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        Map<String, String> contextMap = MDC.getCopyOfContextMap();
        SecurityUser user = new AuthenticatedUser().getUserInfo();
        return () -> {
            try {
                if (contextMap != null) {
                    MDC.setContextMap(contextMap);
                } else {
                    MDC.clear();
                }
                AuthenticatedUser.setCurrentUser(user);
                runnable.run();
            } finally {
                MDC.clear();
                AuthenticatedUser.clearContext();
            }
        };
    }
}