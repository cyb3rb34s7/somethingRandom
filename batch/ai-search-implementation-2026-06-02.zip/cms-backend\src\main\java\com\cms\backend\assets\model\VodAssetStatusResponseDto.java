package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VodAssetStatusResponseDto {

    private String contentId;
    private String countryCode;
    private String vcCpId;
    private String status;
    private String type;
    private Integer isCmsProd;
    private Boolean isSyncBlocked;
    private Boolean isReleased;
    private String feedWorker;
}
