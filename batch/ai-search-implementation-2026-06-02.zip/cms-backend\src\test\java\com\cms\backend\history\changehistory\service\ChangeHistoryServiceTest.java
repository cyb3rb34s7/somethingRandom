package com.cms.backend.history.changehistory.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.cms.backend.changehistory.configuration.HistoryHeaderMap;
import com.cms.backend.changehistory.model.ChangeHistoryFilterBodyDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.LockHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.changehistory.service.ChangeHistoryService;
import com.cms.backend.common.constants.Constants;
import com.cms.backend.common.model.AuthenticatedUser;
import com.cms.backend.common.model.BaseResponseDto;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.model.SecurityUser;
import com.cms.backend.common.service.RegionEndpointService;
import com.cms.backend.common.util.HttpMethodHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

@SpringBootTest(classes = ChangeHistoryServiceTest.class)
class ChangeHistoryServiceTest {

    @InjectMocks
    ChangeHistoryService changeHistoryService;
    @Mock
    RegionEndpointService regionEndpointService;
    @Mock
    HttpMethodHandler httpMethodHandler;

    @Mock
    HistoryHeaderMap historyHeaderMap;
    @Mock
    AuthenticatedUser user;

    SecurityUser usTestSecurityUser = new SecurityUser("2d4xazvqzj",
        "US", "test", "", new HashMap<>());

    @BeforeEach
    void presetDetails() {
        when(regionEndpointService.getOpenAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn("http://test:8080");
        when(regionEndpointService.getSQSEndpoint()).thenReturn("http://test:8080");
        Mockito.when(user.getUserInfo()).thenReturn(usTestSecurityUser);
    }

    @Test
    void testValidCases() {
        ResponseEntity<ResponseDto> responseEntity = ResponseEntity.ok(
            ResponseDto.builder().rsp(new BaseResponseDto()).build());
        Mockito.doReturn(responseEntity)
            .when(httpMethodHandler).handleHttpExchange(anyString(), anyString(), any(),
                any());

        ChangeHistoryFilterBodyDto changeHistoryFilterBodyDto = ChangeHistoryFilterBodyDto.builder()
            .build();

        changeHistoryService.getLicenseHistory(changeHistoryFilterBodyDto);
        changeHistoryService.getLicenseHistoryByAssetId("assetId");

        changeHistoryService.addLicenseHistory(LicenseHistoryRequestDto.builder().build());
        changeHistoryService.getLicenseHistoryFilters();

        changeHistoryService.getMetadataHistory(changeHistoryFilterBodyDto);
        changeHistoryService.getMetadataHistoryByAssetId("assetId", changeHistoryFilterBodyDto);
        changeHistoryService.addMetadataHistory(MetadataHistoryRequestDto.builder().build());

        changeHistoryService.getAssetStatusHistory(changeHistoryFilterBodyDto);
        changeHistoryService.getStatusHistoryByAssetId("aa");
        changeHistoryService.addAssetStatusHistory(StatusHistoryRequestDto.builder().build());
        changeHistoryService.getAssetstatusHistoryFilters();

        changeHistoryService.getMetadataHistoryFilters();
        changeHistoryService.addEventHistory(EventHistoryRequestDto.builder().build());
        changeHistoryService.addLockChangeHistory(LockHistoryRequestDto.builder().build());
        Assertions.assertTrue(true);
    }

    @Test
    void testInValidCases() {
        Mockito.doThrow(new RuntimeException("some exception occurred"))
            .when(httpMethodHandler).handleHttpExchange(anyString(), anyString(), any(), any());

        ChangeHistoryFilterBodyDto changeHistoryFilterBodyDto = ChangeHistoryFilterBodyDto.builder()
            .build();

        List<Executable> executables = Arrays.asList(
            () -> changeHistoryService.getLicenseHistory(changeHistoryFilterBodyDto),
            () -> changeHistoryService.getLicenseHistoryByAssetId("assetId"),
            () -> changeHistoryService.addLicenseHistory(
                LicenseHistoryRequestDto.builder().build()),
            () -> changeHistoryService.getLicenseHistoryFilters(),
            () -> changeHistoryService.getMetadataHistory(changeHistoryFilterBodyDto),
            () -> changeHistoryService.getMetadataHistoryByAssetId("assetId",
                changeHistoryFilterBodyDto),
            () -> changeHistoryService.addMetadataHistory(
                MetadataHistoryRequestDto.builder().build()),
            () -> changeHistoryService.getAssetStatusHistory(changeHistoryFilterBodyDto),
            () -> changeHistoryService.getStatusHistoryByAssetId("aa"),
            () -> changeHistoryService.addAssetStatusHistory(
                StatusHistoryRequestDto.builder().build()),
            () -> changeHistoryService.getAssetstatusHistoryFilters(),
            () -> changeHistoryService.getMetadataHistoryFilters(),
            () -> changeHistoryService.addEventHistory(EventHistoryRequestDto.builder().build()),
            () -> changeHistoryService.addLockChangeHistory(LockHistoryRequestDto.builder().build())
        );

        int errorCount = 0;
        for (Executable executable : executables) {
            try {
                executable.execute();
            } catch (Exception e) {
                errorCount++;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
        Assertions.assertEquals(executables.size(), errorCount);
    }

    @Test
    void testExportAssetStatusHistory() {
        // Mock dependencies
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        ResponseDto responseDto = new ResponseDto();
        when(httpMethodHandler.handleHttpExchange(any(), any(), any(), any())).thenReturn(
            ResponseEntity.ok(responseDto));

        // Execute the method under test
        ResponseEntity<InputStreamResource> result = changeHistoryService.exportAssetStatusHistory(
            historyFilterBodyDto);

        // Assertions
        assertNotNull(result);
    }

    @Test
    void testExportHistory() throws Throwable {
        // Mock dependencies
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        ResponseDto responseDto = new ResponseDto();
        Mockito.doReturn(ResponseEntity.ok(responseDto)).when(httpMethodHandler)
            .handleHttpExchange(any(), any(), any(), any());

        List<Supplier<ResponseEntity<InputStreamResource>>> executables = List.of(
            () -> changeHistoryService.exportMetadataHistory(
                historyFilterBodyDto),
            () -> changeHistoryService.exportLicenseHistory(
                historyFilterBodyDto)
        );
        int okExports = 0;
        for (var supplier : executables) {
            ResponseEntity<InputStreamResource> result = supplier.get();
            if (result != null) {
                ++okExports;
            }
        }
        // Assertions
        Assertions.assertEquals(okExports, executables.size());
    }

    @Test
    void testExportLicenseHistory_NOT_EMPTY_CASE() {
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        Map<String, Object> payload = new HashMap<>();
        List<LinkedHashMap<String, Object>> payloadOfPayload = new ArrayList<>();
        payloadOfPayload.add(new LinkedHashMap<>());

        List<LinkedHashMap<String, Object>> assetPayload = new ArrayList<>();
        assetPayload.add(new LinkedHashMap<>());
        assetPayload.add(new LinkedHashMap<>());
        assetPayload.get(0).put("assetId", "abc");
        assetPayload.get(1).put("type", "def");
        payloadOfPayload.get(0).put("historyChanges", assetPayload);
        payload.put("LicenseHistory", payloadOfPayload);

        HistoryHeaderMap historyHeaderMap1 = new HistoryHeaderMap();
        when(historyHeaderMap.getLicenseHistMap()).thenReturn(
            historyHeaderMap1.getLicenseHistMap());

        when(httpMethodHandler.handleHttpExchange(any(), any(), any(), any())).thenReturn(
            ResponseEntity.ok(
                ResponseDto.builder().rsp(
                        BaseResponseDto.builder().stat(Constants.STATUS_OK).payload(payload).build())
                    .build()));
        assertDoesNotThrow(
            () -> {
                changeHistoryService.exportLicenseHistory(historyFilterBodyDto);
            });

    }

    @Test
    void testExportMetadatHistory_NOT_EMPTY_CASE() {
        // Mock the endpoint URL
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        // Prepare the filter DTO (can be empty for this test)
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();

        // Build a payload with ONE asset that contains a "changes" entry
        Map<String, Object> payload = new HashMap<>();
        List<LinkedHashMap<String, Object>> assetList = new ArrayList<>();

        // Create a dummy change entry (the structure matches MetadataUpdate)
        List<LinkedHashMap<String, Object>> changes = new ArrayList<>();
        LinkedHashMap<String, Object> change = new LinkedHashMap<>();
        change.put("field", "availableString");
        change.put("oldValue", "old");
        change.put("newValue", "new");
        change.put("changeDateTime", "2023-01-01T12:00:00.000Z");
        changes.add(change);

        // Asset map with the "changes" key
        LinkedHashMap<String, Object> asset = new LinkedHashMap<>();
        asset.put("changes", changes);
        assetList.add(asset);

        payload.put("data", assetList);

        // Mock the header map
        HistoryHeaderMap historyHeaderMap1 = new HistoryHeaderMap();
        when(historyHeaderMap.getMetadataHistMap()).thenReturn(
            historyHeaderMap1.getMetadataHistMap());

        // Mock the HTTP call to return the payload
        mockHttpHandler(Constants.STATUS_OK, payload);

        // The method should complete without throwing any exception
        assertDoesNotThrow(() -> {
            changeHistoryService.exportMetadataHistory(historyFilterBodyDto);
        });
    }

    @Test
    void testExportAssetStatusHistory_WITH_DATA() {
        // Mock the endpoint URL
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        // Prepare the filter DTO
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();

        // Build a payload with asset status history data
        Map<String, Object> payload = new HashMap<>();
        List<LinkedHashMap<String, Object>> assetList = new ArrayList<>();

        // Asset map with status history changes
        LinkedHashMap<String, Object> asset = new LinkedHashMap<>();
        asset.put("assetId", "test-asset-id");
        asset.put("contentPartner", "test-cp");
        asset.put("tiName", "test-ti");
        asset.put("mediaTitle", "test-title");
        asset.put("type", "movie");

        // Status history changes
        List<LinkedHashMap<String, Object>> statusHistoryChanges = new ArrayList<>();
        LinkedHashMap<String, Object> statusChange = new LinkedHashMap<>();
        statusChange.put("changeDateTime", "2023-01-01T12:00:00.000Z");
        statusChange.put("oldStatus", "draft");
        statusChange.put("newStatus", "published");
        statusChange.put("updatedBy", "test-user");
        statusHistoryChanges.add(statusChange);

        asset.put("statusHistoryChanges", statusHistoryChanges);
        assetList.add(asset);
        payload.put("data", assetList);

        // Mock the header map
        HistoryHeaderMap historyHeaderMap1 = new HistoryHeaderMap();
        when(historyHeaderMap.getAssetStatusMap()).thenReturn(
            historyHeaderMap1.getAssetStatusMap());

        // Mock the HTTP call to return the payload
        mockHttpHandler(Constants.STATUS_OK, payload);

        // The method should complete without throwing any exception
        assertDoesNotThrow(() -> {
            changeHistoryService.exportAssetStatusHistory(historyFilterBodyDto);
        });
    }

    @Test
    void testExportLicenseHistory_WITH_DATA() {
        // Mock the endpoint URL
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        // Prepare the filter DTO
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();

        // Build a payload with license history data
        Map<String, Object> payload = new HashMap<>();
        List<LinkedHashMap<String, Object>> licenseHistoryList = new ArrayList<>();

        // License history entry
        LinkedHashMap<String, Object> licenseHistory = new LinkedHashMap<>();
        licenseHistory.put("assetId", "test-asset-id");
        licenseHistory.put("contentPartner", "test-cp");
        licenseHistory.put("tiName", "test-ti");
        licenseHistory.put("mediaTitle", "test-title");
        licenseHistory.put("type", "movie");
        licenseHistory.put("currentReleaseDate", "2023-01-01T00:00:00.000Z");
        licenseHistory.put("currentExpiryDate", "2024-01-01T00:00:00.000Z");
        licenseHistory.put("currentStatus", "active");

        // History changes
        List<LinkedHashMap<String, Object>> historyChanges = new ArrayList<>();
        LinkedHashMap<String, Object> historyChange = new LinkedHashMap<>();
        historyChange.put("changeDateTime", "2023-01-01T12:00:00.000Z");
        historyChange.put("releaseDate", "2023-01-01T00:00:00.000Z");
        historyChange.put("expiryDate", "2024-01-01T00:00:00.000Z");
        historyChange.put("updatedBy", "test-user");
        historyChange.put("oldStatus", "inactive");
        historyChanges.add(historyChange);

        licenseHistory.put("historyChanges", historyChanges);
        licenseHistoryList.add(licenseHistory);
        payload.put("LicenseHistory", licenseHistoryList);

        // Mock the header map
        HistoryHeaderMap historyHeaderMap1 = new HistoryHeaderMap();
        when(historyHeaderMap.getLicenseHistMap()).thenReturn(
            historyHeaderMap1.getLicenseHistMap());

        // Mock the HTTP call to return the payload
        mockHttpHandler(Constants.STATUS_OK, payload);

        // The method should complete without throwing any exception
        assertDoesNotThrow(() -> {
            changeHistoryService.exportLicenseHistory(historyFilterBodyDto);
        });
    }

    @Test
    void testExportMetadataHistory_WITH_MULTIPLE_CHANGES() {
        // Mock the endpoint URL
        String historyBackendURL = "http://example.com/history";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(historyBackendURL);

        // Prepare the filter DTO
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();

        // Build a payload with metadata history data
        Map<String, Object> payload = new HashMap<>();
        List<LinkedHashMap<String, Object>> assetList = new ArrayList<>();

        // Asset map with multiple changes
        LinkedHashMap<String, Object> asset = new LinkedHashMap<>();
        asset.put("assetId", "test-asset-id");
        asset.put("contentPartner", "test-cp");
        asset.put("tiName", "test-ti");
        asset.put("mediaTitle", "test-title");

        // Multiple metadata changes as JSON string
        String changesJson =
            "[{\"field\":\"mainTitle\",\"oldValue\":\"old title\",\"newValue\":\"new title\",\"changeDateTime\":\"2023-01-01T12:00:00.000Z\"},"
                +
                "{\"field\":\"description\",\"oldValue\":\"old desc\",\"newValue\":\"new desc\",\"changeDateTime\":\"2023-01-02T12:00:00.000Z\"}]";
        asset.put("changes", changesJson);
        assetList.add(asset);

        payload.put("data", assetList);

        // Mock the header map
        HistoryHeaderMap historyHeaderMap1 = new HistoryHeaderMap();
        when(historyHeaderMap.getMetadataHistMap()).thenReturn(
            historyHeaderMap1.getMetadataHistMap());

        // Mock json field map
        Map<String, String> jsonFieldMap = new HashMap<>();
        jsonFieldMap.put("mainTitle", "Program Title/Episode Title");
        jsonFieldMap.put("description", "Synopsis/Description");
        when(historyHeaderMap.getJsonFieldMap()).thenReturn(jsonFieldMap);

        // Mock the HTTP call to return the payload
        mockHttpHandler(Constants.STATUS_OK, payload);
        // The method should complete without throwing any exception
        assertDoesNotThrow(() -> {
            changeHistoryService.exportMetadataHistory(historyFilterBodyDto);
        });
    }

    private void mockHttpHandler(String status, Map<String, Object> payload) {
        when(httpMethodHandler.handleHttpExchange(any(), any(), any(), any()))
            .thenReturn(ResponseEntity.ok(
                ResponseDto.builder()
                    .rsp(BaseResponseDto.builder()
                        .stat(status)
                        .payload(payload)
                        .build())
                    .build()));
    }

}
