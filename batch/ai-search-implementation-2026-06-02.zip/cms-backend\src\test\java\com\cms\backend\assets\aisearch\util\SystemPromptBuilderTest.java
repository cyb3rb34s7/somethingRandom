package com.cms.backend.assets.aisearch.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.cms.backend.assets.aisearch.service.FilterSchemaProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SystemPromptBuilderTest {

    private SystemPromptBuilder builder;

    @BeforeEach
    void setUp() {
        FilterSchemaProvider provider = new FilterSchemaProvider(new ObjectMapper());
        provider.init();
        builder = new SystemPromptBuilder(provider);
    }

    @Test
    void promptContainsSchemaKeysAndInstructions() {
        String prompt = builder.build(Map.of());
        assertThat(prompt).contains("status");
        assertThat(prompt).contains("showTitle");
        assertThat(prompt).contains("\"status\": \"resolved\"");
        assertThat(prompt).contains("\"status\": \"error\"");
        assertThat(prompt).doesNotContain("\"status\": \"ambiguous\"");
    }

    @Test
    void promptRendersStaticEnumValuesAndAliases() {
        String prompt = builder.build(Map.of());
        // static enum value of status
        assertThat(prompt).contains("Ready for QC");
        // alias listed for status
        assertThat(prompt).contains("media status");
        // content hierarchy note from schema
        assertThat(prompt).contains("SHOW");
    }

    @Test
    void promptMarksDynamicKeyAsFreeTextWhenNoInjection() {
        String prompt = builder.build(Map.of());
        // countryCode is dynamicValues with no injection
        assertThat(prompt).contains("dynamic — free text allowed");
    }

    @Test
    void promptInjectsDynamicEnumValues() {
        String prompt = builder.build(Map.of("countryCode", List.of("IN", "US"), "tiName", List.of("Sony")));
        assertThat(prompt).contains("IN");
        assertThat(prompt).contains("Sony");
    }

    @Test
    void promptHandlesNullDynamicEnumsMap() {
        String prompt = builder.build(null);
        assertThat(prompt).contains("dynamic — free text allowed");
    }

    @Test
    void promptTreatsEmptyInjectedListAsFreeText() {
        Map<String, List<String>> enums = new HashMap<>();
        enums.put("countryCode", List.of());
        String prompt = builder.build(enums);
        assertThat(prompt).contains("dynamic — free text allowed");
    }
}
