package com.cms.backend.history.changehistory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cms.backend.changehistory.controller.ChangeHistoryController;
import com.cms.backend.changehistory.model.ChangeHistoryFilterBodyDto;
import com.cms.backend.changehistory.model.EventHistoryRequestDto;
import com.cms.backend.changehistory.model.LicenseHistoryRequestDto;
import com.cms.backend.changehistory.model.LockHistoryRequestDto;
import com.cms.backend.changehistory.model.MetadataHistoryRequestDto;
import com.cms.backend.changehistory.model.StatusHistoryRequestDto;
import com.cms.backend.changehistory.service.ChangeHistoryService;
import com.cms.backend.common.model.ResponseDto;
import com.cms.backend.common.service.RegionEndpointService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.time.Instant;
import java.util.List;

@SpringBootTest(classes = ChangeHistoryControllerTest.class)
class ChangeHistoryControllerTest {


    @InjectMocks
    private ChangeHistoryController changeHistoryController;

    @Mock
    private ChangeHistoryService changeHistoryService;

    @Mock
    private RegionEndpointService regionEndpointService;

    private String TEST_ASSET = "TestAsset";

//License History Unit Tests

    @Test
    void testAddLicenseHistory() {
        // Arrange
        LicenseHistoryRequestDto licensePostBody = new LicenseHistoryRequestDto();
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.addLicenseHistory(licensePostBody)).thenReturn(expectedResponse);

        // Act
        ResponseDto actualResponse = changeHistoryController.addLicenseHistory(licensePostBody);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetLicenseHistory() throws Exception {
        // Arrange
        ChangeHistoryFilterBodyDto filterRequestBody = new ChangeHistoryFilterBodyDto();
        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(changeHistoryService.getLicenseHistory(filterRequestBody))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getLicenseHistory(filterRequestBody);
        assertEquals(expectedResponse, actualResponse);

    }

    @Test
    void testGetLicenseHistoryByAssetId() throws Exception {
        // Arrange

        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(changeHistoryService.getLicenseHistoryByAssetId(TEST_ASSET))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getLicenseHistoryByAssetId(TEST_ASSET);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetLicenseHistoryFilters() {
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.getLicenseHistoryFilters()).thenReturn(expectedResponse);

        ResponseDto response = changeHistoryController.getLicenseHistoryFilters();

        assertEquals(expectedResponse, response);
    }

//Metadata History Unit Tests

    @Test
    void testAddMetadataHistory() throws Exception {

        // Arrange
        MetadataHistoryRequestDto postBody = new MetadataHistoryRequestDto();
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.addMetadataHistory(postBody)).thenReturn(expectedResponse);

        // Act
        ResponseDto actualResponse = changeHistoryController.addMetadataHistory(postBody);

        // Assert
        assertEquals(expectedResponse, actualResponse);

    }

    @Test
    void testGetMetadataHistory() throws Exception {

        // Arrange
        ChangeHistoryFilterBodyDto filterRequestBody = new ChangeHistoryFilterBodyDto();
        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(changeHistoryService.getMetadataHistory(filterRequestBody))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getMetadataHistory(filterRequestBody);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetMetadataHistoryByAssetId() throws Exception {

        // Arrange
        ChangeHistoryFilterBodyDto filterRequestBody = new ChangeHistoryFilterBodyDto();
        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(
                changeHistoryService.getMetadataHistoryByAssetId(TEST_ASSET, filterRequestBody))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getMetadataHistoryByAssetId(TEST_ASSET,
            filterRequestBody);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetMetadataHistoryFilters() throws Exception {
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.getMetadataHistoryFilters()).thenReturn(expectedResponse);

        ResponseDto response = changeHistoryController.getMetadataHistoryFilters();

        assertEquals(expectedResponse, response);
    }

//Asset Status History Unit Tests

    @Test
    void testAddAssetStatusHistory() throws Exception {
        // Arrange
        StatusHistoryRequestDto postBody = new StatusHistoryRequestDto();
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.addAssetStatusHistory(postBody)).thenReturn(expectedResponse);

        // Act
        ResponseDto actualResponse = changeHistoryController.addAssetstatusHistory(postBody);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetAssetStatusHistory() throws Exception {

        // Arrange
        ChangeHistoryFilterBodyDto filterRequestBody = new ChangeHistoryFilterBodyDto();
        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(changeHistoryService.getAssetStatusHistory(filterRequestBody))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getAssetstatusHistory(
            filterRequestBody);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetStatusHistoryByAssetId() throws Exception {

        // Arrange

        ResponseDto expectedResponse = new ResponseDto();
        Mockito.when(changeHistoryService.getStatusHistoryByAssetId(TEST_ASSET))
            .thenReturn(expectedResponse);

        // Act & Assert
        ResponseDto actualResponse = changeHistoryController.getStatusHistoryByAssetId(TEST_ASSET);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testGetAssetStatusFilters() throws Exception {
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.getAssetstatusHistoryFilters()).thenReturn(expectedResponse);

        ResponseDto response = changeHistoryController.getAssetStatusFilters();

        assertEquals(expectedResponse, response);
    }


    @Test
    public void testExportAssetStatusHistory() throws Exception {
        // Mock dependencies
        String finalUrl = "http://example.com/history-api-endpoint/get-assetstatus-hist";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(finalUrl);

        ResponseEntity<InputStreamResource> result = new ResponseEntity<InputStreamResource>(
            HttpStatus.OK);
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        when(changeHistoryService.exportAssetStatusHistory(historyFilterBodyDto)).thenReturn(
            result);

        ResponseEntity<InputStreamResource> resultActual = changeHistoryController.
            exportAssetStatusHistory(historyFilterBodyDto);

        assertEquals(result, resultActual);
    }


    @Test
    public void testExportLicHistory() throws Exception {
        // Mock dependencies
        String finalUrl = "http://example.com/history-api-endpoint/get-assetstatus-hist";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(finalUrl);

        ResponseEntity<InputStreamResource> result = new ResponseEntity<InputStreamResource>(
            HttpStatus.OK);
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        when(changeHistoryService.exportLicenseHistory(historyFilterBodyDto)).thenReturn(
            result);

        ResponseEntity<InputStreamResource> resultActual = changeHistoryController.
            exportLicenseHistory(historyFilterBodyDto);

        assertEquals(result, resultActual);
    }

    @Test
    public void testExportMetadataHistory() throws Exception {
        // Mock dependencies
        String finalUrl = "http://example.com/history-api-endpoint/get-assetstatus-hist";
        when(regionEndpointService.getHistoryAPIEndpoint()).thenReturn(finalUrl);

        ResponseEntity<InputStreamResource> result = new ResponseEntity<InputStreamResource>(
            HttpStatus.OK);
        ChangeHistoryFilterBodyDto historyFilterBodyDto = new ChangeHistoryFilterBodyDto();
        when(changeHistoryService.exportMetadataHistory(historyFilterBodyDto)).thenReturn(
            result);

        ResponseEntity<InputStreamResource> resultActual = changeHistoryController.
            exportMetadataHistory(historyFilterBodyDto);

        assertEquals(result, resultActual);
    }

//Event and Lock History Unit Tests

    @Test
    void testAddEventHistory() {
        // Arrange
        EventHistoryRequestDto eventHistoryRequestDto = EventHistoryRequestDto.builder()
            .contentId("content123")
            .countryCode("US")
            .vcCpId("vcCp123")
            .eventStarting("2023-01-01T10:00:00Z")
            .eventEnding("2023-01-01T12:00:00Z")
            .updatedBy("user1")
            .oldStatus("OLD")
            .changeDateTime(Instant.now())
            .build();
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.addEventHistory(eventHistoryRequestDto)).thenReturn(
            expectedResponse);

        // Act
        ResponseDto actualResponse = changeHistoryController.addEventHistory(
            eventHistoryRequestDto);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testAddLockHistory() {
        // Arrange
        LockHistoryRequestDto.LockChange lockChange = new LockHistoryRequestDto.LockChange();
        lockChange.setFieldName("testField");
        lockChange.setLocked(true);

        LockHistoryRequestDto lockHistoryRequest = LockHistoryRequestDto.builder()
            .contentId("lockContent123")
            .updatedBy("user2")
            .changeDateTime(Instant.now())
            .changes(List.of(lockChange))
            .build();
        ResponseDto expectedResponse = new ResponseDto();
        when(changeHistoryService.addLockChangeHistory(lockHistoryRequest)).thenReturn(
            expectedResponse);

        // Act
        ResponseDto actualResponse = changeHistoryController.addLockHistory(lockHistoryRequest);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

}
