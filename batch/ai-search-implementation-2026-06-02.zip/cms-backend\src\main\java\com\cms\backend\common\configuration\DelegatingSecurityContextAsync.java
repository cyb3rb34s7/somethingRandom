package com.cms.backend.common.configuration;

import com.cms.backend.common.exception.CustomAsyncExceptionHandler;
import com.cms.backend.common.util.NotificationUtil;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;


@Configuration
public class DelegatingSecurityContextAsync implements AsyncConfigurer {

    private final NotificationUtil notificationUtil;

    public DelegatingSecurityContextAsync(NotificationUtil notificationUtil) {
        this.notificationUtil = notificationUtil;
    }

    @Bean
    @Primary
    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(100);
        executor.setQueueCapacity(50);
        executor.setKeepAliveSeconds(300);
        executor.setThreadNamePrefix("async-");
        executor.setTaskDecorator(new MdcTaskDecorator());
        executor.initialize();
        return executor;
    }


    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return (AsyncUncaughtExceptionHandler) new CustomAsyncExceptionHandler(notificationUtil);
    }

}
