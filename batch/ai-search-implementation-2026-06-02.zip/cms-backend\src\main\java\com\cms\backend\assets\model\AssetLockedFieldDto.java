package com.cms.backend.assets.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Generated
public class AssetLockedFieldDto {

    private String contentId;
    private String providerId;
    private String countryCode;
    private String fieldName;
    private String fieldType;
    private String lockedBy;
    private String tableName;
}
