package com.cms.backend.changehistory.configuration;

import com.cms.backend.common.constants.Constants;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HistoryHeaderMap {


    @Bean
    public Map<String, String> getMetadataHistMap() {
        LinkedHashMap<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put(Constants.EXPORT_CHANGEDATETIME,
            Constants.EXPORT_FULL_LATESTCHANGEDATETIME);
        assetHeader.put(Constants.ASSET_ID, Constants.PROGRAM_ID);
        assetHeader.put(Constants.CONTENT_PARTNER, Constants.CONTENT_PARTNER_FULL);
        assetHeader.put(Constants.TI_NAME, Constants.TI_FULL_NAME);
        assetHeader.put(Constants.EXPORT_MEDIATITLE, Constants.MEDIA_TITLE);
        assetHeader.put(Constants.EXPORT_UPDATEDBY, Constants.EXPORT_FULL_LATESTUPDATEDBY);

        assetHeader.put(Constants.EXPORT_FIELD, Constants.EXPORT_FULL_FIELD);
        assetHeader.put(Constants.EXPORT_OLDVALUE, Constants.EXPORT_FULL_OLDVALUE);
        assetHeader.put(Constants.EXPORT_NEWVALUE, Constants.EXPORT_FULL_NEWVALUE);

        return assetHeader;
    }

    @Bean
    public Map<String, String> getLicenseHistMap() {
        LinkedHashMap<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put(Constants.CONTENT_PARTNER, Constants.CONTENT_PARTNER_FULL);
        assetHeader.put(Constants.TI_NAME, Constants.TI_FULL_NAME);
        assetHeader.put(Constants.ASSET_ID, Constants.PROGRAM_ID);
        assetHeader.put(Constants.EXPORT_MEDIATITLE, Constants.MEDIA_TITLE);
        assetHeader.put(Constants.EXPORT_TYPE, Constants.EXPORT_FULL_TYPE);
        assetHeader.put(Constants.EXPORT_CURRENTRELEASEDATE, Constants.EXPORT_FULL_LIC_STRT_DT);
        assetHeader.put(Constants.EXPORT_CURRENTEXPIRYDATE, Constants.EXPORT_FULL_EXPIRYDATE);
        assetHeader.put(Constants.EXPORT_CURRENTSTATUS, Constants.EXPORT_FULL_STATUS);

        assetHeader.put(Constants.EXPORT_CHANGEDATETIME, Constants.EXPORT_FULL_LIC_CHANGEDATETIME);
        assetHeader.put(Constants.EXPORT_RELEASEDATE, Constants.EXPORT_FULL_LIC_STRT_DT);
        assetHeader.put(Constants.EXPIRY_DATE, Constants.EXPORT_FULL_EXPIRYDATE);
        assetHeader.put(Constants.EXPORT_UPDATEDBY, Constants.EXPORT_FULL_UPDATEDBY);
        assetHeader.put(Constants.EXPORT_OLDSTATUS, Constants.EXPORT_FULL_STATUS);
        return assetHeader;
    }

    @Bean
    public Map<String, String> getAssetStatusMap() {
        LinkedHashMap<String, String> assetHeader = new LinkedHashMap<>();
        assetHeader.put(Constants.CONTENT_PARTNER, Constants.CONTENT_PARTNER_FULL);
        assetHeader.put(Constants.TI_NAME, Constants.TI_FULL_NAME);
        assetHeader.put(Constants.ASSET_ID, Constants.PROGRAM_ID);
        assetHeader.put(Constants.EXPORT_MEDIATITLE, Constants.MEDIA_TITLE);
        assetHeader.put(Constants.EXPORT_TYPE, Constants.EXPORT_FULL_TYPE);
        assetHeader.put(Constants.EXPORT_LATESTUPDATEDBY, Constants.EXPORT_FULL_LATESTUPDATEDBY);
        assetHeader.put(Constants.EXPORT_LATESTCHANGEDATETIME, Constants.EXPORT_FULL_UPDATEDDATE);

        assetHeader.put(Constants.EXPORT_CHANGEDATETIME, Constants.EXPORT_FULL_CHANGEDATETIME);
        assetHeader.put(Constants.EXPORT_OLDSTATUS, Constants.EXPORT_FULL_OLDSTATUS);
        assetHeader.put(Constants.EXPORT_NEWSTATUS, Constants.EXPORT_FULL_NEWSTATUS);
        assetHeader.put(Constants.EXPORT_UPDATEDBY, Constants.EXPORT_FULL_UPDATEDBY);
        return assetHeader;
    }

    @Bean
    public Map<String, String> getJsonFieldMap() {
        LinkedHashMap<String, String> jsonFieldMap = new LinkedHashMap<>();
        jsonFieldMap.put("contentId", "Program ID");
        jsonFieldMap.put("cpName", "CP Name");
        jsonFieldMap.put("mainTitle", "Program Title/Episode Title");
        jsonFieldMap.put("type", "Program Type");
        jsonFieldMap.put("countryCode", "Country");
        jsonFieldMap.put("subTitle", "Subtitle");
        jsonFieldMap.put("licenseWindow", "License Window");
        jsonFieldMap.put("status", "Status");
        jsonFieldMap.put("updateDate", "Updated Date");
        jsonFieldMap.put("showId", "Show ID");
        jsonFieldMap.put("seasonNo", "Season No");
        jsonFieldMap.put("seasonId", "Season ID");
        jsonFieldMap.put("episodeNo", "Episode No");
        jsonFieldMap.put("vcCpId", "CP ID");
        jsonFieldMap.put("externalId", "TMS/Gracenote ID");
        jsonFieldMap.put("releaseDate", "Original Release Date");
        jsonFieldMap.put("runningTime", "Duration (sec)");
        jsonFieldMap.put("description", "Synopsis/Description");
        jsonFieldMap.put("starring", "Cast (Person Name)");
        jsonFieldMap.put("genres", "Genre");
        jsonFieldMap.put("drm", "Content Rights");
        jsonFieldMap.put("availableStarting", "Window Start Date");
        jsonFieldMap.put("expiryDate", "Window End Date");
        jsonFieldMap.put("director", "Director");
        jsonFieldMap.put("ratings", "Ratings");
        jsonFieldMap.put("streamUri", "Stream Uri");
        jsonFieldMap.put("regDate", "Registered Date");
        jsonFieldMap.put("crctrId", "Available Starting");
        jsonFieldMap.put("webVttUrl", "Web Vtt Url");
        jsonFieldMap.put("thumbnailUrl", "Thumbnail URL");
        jsonFieldMap.put("audioLang", "Audio Language");
        jsonFieldMap.put("subtitleLang", "Subtitle Language");
        jsonFieldMap.put("deeplinkPayload", "Deep Link Payload");
        jsonFieldMap.put("audioCode", "Audio Code");
        jsonFieldMap.put("subtitleCode", "Subtitle Code");
        jsonFieldMap.put("quality", "Quality");
        jsonFieldMap.put("vcSvcId", "Vc Svc Id");
        jsonFieldMap.put("deeplinkId", "Deep Link Id");
        jsonFieldMap.put("fileName", "FileName");
        jsonFieldMap.put("dataplusYn", "DataPlus Yn");
        jsonFieldMap.put("nonAdStreamUri", "Non Ad Stream Uri");
        jsonFieldMap.put("artist", "Artist");
        jsonFieldMap.put("identifierId", "Identifier ID");
        jsonFieldMap.put("contentTier", "Content Tier");
        jsonFieldMap.put("chapterTime", "Chapter Time");
        jsonFieldMap.put("chapterDescription", "Chapter Description");
        jsonFieldMap.put("assetId", "Asset ID");
        jsonFieldMap.put("adTag", "Ad Tag");
        jsonFieldMap.put("platformTag", "Platform Tag");
        jsonFieldMap.put("contentPartner", "Content Partner");
        jsonFieldMap.put("role", "Role");
        jsonFieldMap.put("externalProgramId", "External Program Id");
        jsonFieldMap.put("idType", "Id Type");
        jsonFieldMap.put("qcPassReason", "QC pass Reason");
        jsonFieldMap.put("tiName", "Tech Integrator");
        jsonFieldMap.put("adBreak", "Ad Break");
        jsonFieldMap.put("imageLandscapeOriginal", "Banner Landscape Image");
        jsonFieldMap.put("imagePortraitOriginal", "Banner Portrait Image");
        jsonFieldMap.put("imageLandscapeIconicOriginal", "Iconic Landscape Image");
        jsonFieldMap.put("imagePortraitIconicOriginal", "Iconic Portrait Image");
        jsonFieldMap.put("imageCircleOriginal", "Circle Image");
        jsonFieldMap.put("imageLandscape", "Processed Banner Landscape Image");
        jsonFieldMap.put("imagePortrait", "Processed Banner Portrait Image");
        jsonFieldMap.put("imageLandscapeIconic", "Processed Iconic Landscape Image");
        jsonFieldMap.put("imagePortraitIconic", "Processed Iconic Portrait Image");
        jsonFieldMap.put("imageLandscapeDimension", "Landscape Image Dimension");
        jsonFieldMap.put("imagePortraitDimension", "Portrait Image Dimension");
        jsonFieldMap.put("imageLandscapeIconicDimension", "Iconic Landscape Image Dimension");
        jsonFieldMap.put("imagePortraitIconicDimension", "Iconic Portrait Image Dimension");
        jsonFieldMap.put("imageCircle", "Processed Circle Image");
        jsonFieldMap.put("externalProvider", "External Provider");

        return jsonFieldMap;
    }


}
