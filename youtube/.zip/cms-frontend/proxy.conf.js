// //var defaultTarget = "http://localhost:8080/";
// var defaultTarget = "https://tvpn-internal-cmsadmin-dev-us.samsungcloud.tv/";
// // var defaultTarget = "https://tvpcms-admin.samsungcloud.tv/";
// const HttpsAgent = require("agentkeepalive").HttpsAgent;

// const keepaliveAgent = new HttpsAgent({
//   maxSockets: 1,
//   keepAlive: true,
//   maxFreeSockets: 10,
//   keepAliveMsecs: 1000,
//   timeout: 60000,
//   keepAliveTimeout: 30000, // free socket keepalive for 30 seconds
// });

// module.exports = [
//   {
//     context: ["/admin/**"],
//     target: defaultTarget,
//     secure: false,
//     changeOrigin: true,
//     agent: keepaliveAgent,
//   },
// ];
