import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Input,
  Output,
} from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Country } from '../../../models/country-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SelectAllDirective } from './select-all-directive';
import { UserService } from '../../../services/user.service';
import { plainToInstance } from 'class-transformer';
import { ReplaySubject } from 'rxjs';
import { Subjectize } from 'subjectize';
import { StateStoreService } from '../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { User } from '../../../models/user-model';

@Component({
  selector: 'app-country-selector',
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    SelectAllDirective,
  ],
  templateUrl: './country-selector.component.html',
  styleUrl: './country-selector.component.scss',
})
export class CountrySelectorComponent {
  private destroy = inject(DestroyRef);

  @Input() countries: Country[] | any = [];

  countryCodes: string[] = [];

  fc = new FormControl<string[] | undefined>([]);

  @Output() selectionChange: EventEmitter<string[]> = new EventEmitter();

  searchVal: string;

  _countriesCopy: Country[];

  constructor(private storeService: StateStoreService) {}

  ngOnInit() {
    this.countryCodes = this.countries.map((c: Country) => c.countryCode);
    this._countriesCopy = this.countries.map((c: Country) => c);
    this.fc.valueChanges
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((v: any) => {
        this.selectionChange.emit(v);
      });

    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER].subscribe(
      (user: User) => {
        const usCon = user.orderedPrefUSCountryCodes;
        const euCon = user.orderedPrefEUCountryCodes;
        if (usCon && euCon) {
          let merged = [...usCon, ...euCon].sort();
          let prefCountries: Country[] = [];
          merged.forEach((cc: string) => {
            let found = this.countries.find(
              (c: Country) => c.countryCode === cc
            );
            if (found) {
              prefCountries = [...prefCountries, found];
              this.countries = this.countries.filter(
                (c: Country) => c.countryCode !== cc
              );
            }
          });
          this.countries = [...prefCountries, ...this.countries];
          merged = merged.filter((item, pos) => merged.indexOf(item) === pos);
          if (merged.length) {
            this.fc.setValue(merged);
          } else {
            this.fc.setValue([...this.countryCodes]);
          }
        }
      }
    );
  }

  filterList() {
    this.countries = this._countriesCopy.map((c: any) => {
      delete c.hide;
      return c;
    });
    if (this.searchVal) {
      this.countries.forEach((c: any) => {
        if (
          !c.countryName.toLowerCase().includes(this.searchVal.toLowerCase())
        ) {
          c['hide'] = true;
        }
      });
    }
  }
}
