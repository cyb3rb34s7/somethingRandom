import {
  AfterViewInit,
  Component,
  ComponentRef,
  DestroyRef,
  ElementRef,
  HostListener,
  inject,
  PlatformRef,
  ViewChild,
} from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { DashboardService } from '../../services/dashboard.service';
import { Dashboard, Dashboards } from '../../models/dashboard-model';
import { plainToInstance } from 'class-transformer';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  DateAdapter,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
  MatOption,
  NativeDateAdapter,
} from '@angular/material/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { DoughnutChartComponent } from './doughnut-chart/doughnut-chart.component';
import { MatButton } from '@angular/material/button';
import { AppMatTableComponent } from '../../mat-components/app-mat-table/app-mat-table.component';
import { MatMenu, MatMenuModule } from '@angular/material/menu';
import { Country } from '../../models/country-model';
import { CountrySelectorComponent } from './country-selector/country-selector.component';
import { BehaviorSubject, take } from 'rxjs';
import { UserService } from '../../services/user.service';
import { HttpErrorResponse } from '@angular/common/http';
import { CustomToastrService } from '../../services/custom-toastr.service';
import { ExeljsService } from '../../services/exeljs.service';
import { NumberFormatterPipe } from '../../pipes/number-formatter.pipe';

export class CustomDateAdapter extends NativeDateAdapter {
  override format(date: Date, displayFormat: any): string {
    const db = new Dashboards();
    return db.dateFormatUtil(date);
  }
}
@Component({
  selector: 'app-dashboard',
  imports: [
    MatCardModule,
    PieChartComponent,
    DoughnutChartComponent,
    AppMatTableComponent,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    MatButton,
    MatMenuModule,
    CountrySelectorComponent,
    MatTooltipModule,
    NumberFormatterPipe,
  ],
  providers: [
    MatDatepickerModule,
    {
      provide: DateAdapter,
      useClass: CustomDateAdapter,
      deps: [MAT_DATE_LOCALE, PlatformRef],
    },
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent {
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.setGraphConstraints();
  }

  private destroy = inject(DestroyRef);

  @ViewChild('bar') barEl: ElementRef;

  @ViewChild('pie') pieEl: ElementRef<HTMLElement>;

  @ViewChild('doughnut') doughnutEl: ElementRef;

  dashboardData: Dashboards | null;

  selectedCountryCodes: string[];

  sizeObj: any = {};

  fg = new FormGroup({
    selectedDate: new FormControl(),
  });

  assetTypes: string[] | undefined = [];

  selectedAssetType: string | null;

  tableData: any;

  max = new Date();

  lastUpdatedTime: string = '';

  totalCpsCount: number = 0;

  countries: Country[];

  onLoadDependenciesOk: BehaviorSubject<any> = new BehaviorSubject({
    allCountries: undefined,
    prefCountries: undefined,
    date: undefined,
  });

  constructor(
    private dashboardSvc: DashboardService,
    private userService: UserService,
    private exlSvc: ExeljsService
  ) {
    this.fg
      .get('selectedDate')
      ?.valueChanges.pipe()
      .subscribe(() => {
        const current = this.onLoadDependenciesOk.getValue();
        this.onLoadDependenciesOk.next({ ...current, date: true });
      });

    this.onLoadDependenciesOk
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((data) => {
        if (data.allCountries && data.prefCountries && data.date) {
          this.onLoadDependenciesOk.complete();
          this.fetchDashboardData();
        }
      });
  }

  ngAfterViewInit() {
    this.sizeObj = {};
    this.sizeObj.pie = this.pieEl.nativeElement.offsetWidth - 160;
    if (this.pieEl.nativeElement.offsetHeight - 60 < this.sizeObj.pie) {
      this.sizeObj.pie = this.pieEl.nativeElement.offsetHeight - 60;
    }
    this.sizeObj.doughnut =
      (this.doughnutEl.nativeElement.offsetWidth - 20) / 3;

    if (
      this.doughnutEl.nativeElement.offsetHeight - 60 <
      this.sizeObj.doughnut
    ) {
      this.sizeObj.doughnut = this.doughnutEl.nativeElement.offsetHeight - 60;
    }
  }

  ngOnInit() {
    document.body.classList.add('dashboard');

    this.userService
      .getAllCountries()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: ({ usCountries, euCountries }) => {
          let clubbed = [...usCountries, ...euCountries];
          clubbed = clubbed.map((x) => JSON.stringify(x));
          clubbed = clubbed.filter(
            (item, pos) => clubbed.indexOf(item) === pos
          );
          clubbed = clubbed.map((x) => JSON.parse(x));
          this.countries = plainToInstance<Country, []>(Country, clubbed);
          this.fg.get('selectedDate')?.setValue(new Date());
          const current = this.onLoadDependenciesOk.getValue();
          this.onLoadDependenciesOk.next({
            ...current,
            date: true,
            allCountries: true,
          });
        },
        error: (error: HttpErrorResponse) => {
          this.fg.get('selectedDate')?.setValue(new Date());
          const current = this.onLoadDependenciesOk.getValue();
          this.onLoadDependenciesOk.next({
            ...current,
            date: true,
            allCountries: true,
          });
          console.log('====Error===', error);
        },
      });
  }

  handleCountrySelection(e: any) {
    this.selectedCountryCodes = e.filter((cc: string) => cc.trim().length);
    const current = this.onLoadDependenciesOk.getValue();
    this.onLoadDependenciesOk.next({ ...current, prefCountries: true });
  }

  setGraphConstraints() {
    this.sizeObj = {};
    const dd = this.dashboardData;
    const td = this.tableData;
    if (dd && td) {
      this.dashboardData = null;
      this.tableData = null;
    }

    setTimeout(() => {
      this.sizeObj.pie = this.pieEl.nativeElement.offsetWidth - 160;
      if (this.pieEl.nativeElement.offsetHeight - 60 < this.sizeObj.pie) {
        this.sizeObj.pie = this.pieEl.nativeElement.offsetHeight - 60;
      }
      this.sizeObj.doughnut =
        (this.doughnutEl.nativeElement.offsetWidth - 20) / 3;

      if (
        this.doughnutEl.nativeElement.offsetHeight - 60 <
        this.sizeObj.doughnut
      ) {
        this.sizeObj.doughnut = this.doughnutEl.nativeElement.offsetHeight - 60;
      }
      if (dd && td) {
        this.dashboardData = dd;
        this.tableData = td;
      }
    }, 500);
  }

  fetchDashboardData() {
    const db = new Dashboards();
    const d = db.dateFormatUtil(new Date(this.fg.get('selectedDate')?.value));
    this.dashboardData = null;
    this.dashboardSvc
      .getDashboardData(this.selectedCountryCodes, d)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((data: any) => {
        this.dashboardData = plainToInstance<Dashboards, {}>(Dashboards, {
          dashboards: data.dashboard,
        });

        if (this.countries) {
          this.dashboardData.allCountries = this.countries;
        }
        this.lastUpdatedTime = data.lastRunTime;
        this.totalCpsCount = data.totalCpsCount;
        this.prepareTableData();
      });
  }

  prepareTableData() {
    this.dashboardData?.gettableChartData();
    this.assetTypes = this.dashboardData?.allAssetTypes.map(
      (s: string) =>
        s.toLowerCase().charAt(0).toUpperCase() +
        s.replace(s.charAt(0), '').toLowerCase()
    );
    this.selectedAssetType = this.assetTypes?.includes(
      this.selectedAssetType || ''
    )
      ? this.selectedAssetType
      : null;
    this.tableData = this.selectedAssetType
      ? this.dashboardData?.gettableChartData(
          this.selectedAssetType.toUpperCase()
        )
      : this.dashboardData?.gettableChartData();

    if (!this.selectedAssetType) {
      let Cps = this.tableData.map((d: any) => d['CP Name'].toLowerCase());
      Cps = Cps.filter((item: any, pos: number) => Cps.indexOf(item) === pos);
      this.totalCpsCount = Cps.length;
    }
  }

  handleExport(type: string) {
    switch (type) {
      case 'bar':
        this.dashboardData?.barChartExport(this.exlSvc);
        break;
      case 'pie':
        this.dashboardData?.pieChartExport(this.exlSvc);
        break;
      case 'doughnut':
        this.dashboardData?.doughnutChartExport(this.exlSvc);
        break;
      case 'table':
        const assetType = this.selectedAssetType
          ? this.selectedAssetType.toUpperCase()
          : '';
        this.dashboardData?.tableChartExport(this.exlSvc, assetType);
        break;
    }
  }

  ngOnDestroy() {
    document.body.classList.remove('dashboard');
  }
}
