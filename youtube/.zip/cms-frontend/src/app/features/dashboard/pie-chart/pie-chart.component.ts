import { Component, DestroyRef, inject, Input } from '@angular/core';
import {
  CanvasJS,
  CanvasJSAngularChartsModule,
} from '@canvasjs/angular-charts';
import { Dashboard, Dashboards } from '../../../models/dashboard-model';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ReplaySubject } from 'rxjs';
import { Subjectize } from 'subjectize';

@Component({
  selector: 'app-pie-chart',
  imports: [CommonModule, CanvasJSAngularChartsModule],
  templateUrl: './pie-chart.component.html',
  styleUrl: './pie-chart.component.scss',
})
export class PieChartComponent {
  private destroy = inject(DestroyRef);

  @Input() dashBoardData: Dashboards;

  @Subjectize('dashBoardData')
  dashBoardData$ = new ReplaySubject(1);

  @Input() size: number;

  chartOptions: any;

  legends: any = [];

  ngOnInit() {
    this.dashBoardData$.pipe(takeUntilDestroyed(this.destroy)).subscribe(() => {
      this.chartOptions = {
        animationEnabled: false,
        data: [
          {
            type: 'pie',
            showInLegend: false,
            legendText: '{legendText}',
            cursor: 'pointer',
            width: this.size - 60,
            height: this.size - 60,
            dataPoints: this.dashBoardData.pieChartData.map((obj) => ({
              legendText: obj.assetType,
              toolTipContent: this.dashBoardData.getPieChartToolTip(
                obj.assetType
              ),
              name: obj.assetType,
              y: obj.assetsCount,
              color: this.dashBoardData.getColorForType(obj.assetType),
            })),
          },
        ],
      };
    });

    this.dashBoardData.pieChartData.forEach((obj) => {
      const { assetType, color } = obj;
      this.legends = [...this.legends, { assetType, color }];
    });
  }
}
