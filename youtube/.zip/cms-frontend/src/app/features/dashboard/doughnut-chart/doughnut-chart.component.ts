import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  inject,
  Input,
  ViewChild,
} from '@angular/core';
import {
  CanvasJSAngularChartsModule,
  CanvasJS,
  CanvasJSChart,
} from '@canvasjs/angular-charts';
import { Dashboard, Dashboards } from '../../../models/dashboard-model';
import { ReplaySubject } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subjectize } from 'subjectize';
import { NumberFormatterPipe } from '../../../pipes/number-formatter.pipe';

@Component({
  selector: 'app-doughnut-chart',
  imports: [CommonModule, CanvasJSAngularChartsModule, NumberFormatterPipe],
  templateUrl: './doughnut-chart.component.html',
  styleUrl: './doughnut-chart.component.scss',
})
export class DoughnutChartComponent {
  private destroy = inject(DestroyRef);

  @ViewChild('upcoming') upcomingRef: ElementRef;

  @ViewChild('active') activeRef: ElementRef;

  @ViewChild('expired') expiredRef: ElementRef;

  @Input() dashBoardData: Dashboards;

  @Input() size: number;

  @Subjectize('dashBoardData')
  dashBoardData$ = new ReplaySubject(1);

  upcomingChartOptions: any;

  activeChartOptions: any;

  expiredChartOptions: any;

  dougnutChartData: any;

  legends: any = [];

  ngOnInit() {
    this.dashBoardData$.pipe(takeUntilDestroyed(this.destroy)).subscribe(() => {
      this.dougnutChartData = this.dashBoardData.dougnutChartData;
      console.log('---xxx---', this.size);
      this.prepareChartOptions();
    });
  }

  prepareChartOptions() {
    const common = {
      animationEnabled: false,
      backgroundColor: 'transparent',
      title: {
        verticalAlign: 'top',
        horizontalAlign: 'center',
        fontFamily: 'arial',
        fontSize: '16',
        fontWeight: '500',
        dockInsidePlotArea: true,
      },
      width: this.size - 60,
      height: this.size - 60,
      data: [
        {
          type: 'doughnut',
          cursor: 'pointer',
        },
      ],
    };

    this.expiredChartOptions = {
      ...common,
      data: [
        {
          ...common.data[0],
          showInLegend: false,
          dataPoints: [...this.dougnutChartData.expired.dataPoints],
        },
      ],
    };

    this.upcomingChartOptions = {
      ...common,
      data: [
        {
          ...common.data[0],
          showInLegend: false,
          dataPoints: [...this.dougnutChartData.upcoming.dataPoints],
        },
      ],
    };

    this.activeChartOptions = {
      ...common,
      data: [
        {
          ...common.data[0],
          showInLegend: false,
          dataPoints: [...this.dougnutChartData.active.dataPoints],
        },
      ],
    };

    const temp = [
      ...this.dougnutChartData.expired.dataPoints,
      ...this.dougnutChartData.upcoming.dataPoints,
      ...this.dougnutChartData.active.dataPoints,
    ];

    temp.forEach((obj) => {
      const f = this.legends.find((l: any) => l.legendText === obj.legendText);
      if (!f) {
        const { legendText, color } = obj;
        this.legends = [...this.legends, { legendText, color }];
      }
    });
  }
}
