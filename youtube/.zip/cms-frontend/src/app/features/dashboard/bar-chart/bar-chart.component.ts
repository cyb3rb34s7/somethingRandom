import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  inject,
  Input,
} from '@angular/core';
import {
  CanvasJS,
  CanvasJSAngularChartsModule,
} from '@canvasjs/angular-charts';
import { Dashboard, Dashboards } from '../../../models/dashboard-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ReplaySubject } from 'rxjs';
import { Subjectize } from 'subjectize';

@Component({
    selector: 'app-bar-chart',
    imports: [CommonModule, CanvasJSAngularChartsModule],
    templateUrl: './bar-chart.component.html',
    styleUrl: './bar-chart.component.scss'
})
export class BarChartComponent {
  private destroy = inject(DestroyRef);

  @Input() dashBoardData: Dashboards;

  @Subjectize('dashBoardData')
  dashBoardData$ = new ReplaySubject(1);

  @Input() height: number;
  @Subjectize('height')
  height$ = new ReplaySubject(1);

  chartOptions: any;

  ngOnInit() {
    CanvasJS.addColorSet('bar-chart-color', ['#C2A3FF']);
    this.dashBoardData$.pipe(takeUntilDestroyed(this.destroy)).subscribe(() => {
      this.chartOptions = {
        animationEnabled: false,
        colorSet: 'bar-chart-color',
        backgroundColor: 'transparent',
        dataPointMaxWidth: 20,
        // height: this.height,
        axisX: {
          title: 'Media Status',
          titleFontSize: 14,
        },
        axisY: {
          gridDashType: 'dash',
          gridColor: '#dde5ff',
          minimum: 0,
          // maximum: 12000,
          // interval: 5000,
          // labelPlacement: 'outside',
          tickPlacement: 'inside',
          title: 'Number of Count',
          titleFontSize: 14,
          titleMaxWidth: 150,

          // labelFormatter: function (e: any) {
          //   const k = Math.floor(e.value / 1000);
          //   return k > 0 ? k + 'k' : 0;
          // },
        },
        data: [
          {
            type: 'column',
            cursor: 'pointer',
            dataPoints: this.dashBoardData.barChartData,
          },
        ],
      };
    });

    // this.height$.pipe(takeUntilDestroyed(this.destroy)).subscribe(() => {
    //   this.chartOptions.data[0].height = this.height;
    //   this.chartOptions = { ...this.chartOptions };
    // });
  }
}
