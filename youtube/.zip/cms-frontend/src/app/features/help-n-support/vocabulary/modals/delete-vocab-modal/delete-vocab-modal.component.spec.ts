import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteVocabModalComponent } from './delete-vocab-modal.component';

describe('DeleteVocabModalComponent', () => {
  let component: DeleteVocabModalComponent;
  let fixture: ComponentFixture<DeleteVocabModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteVocabModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteVocabModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
