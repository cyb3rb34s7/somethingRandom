import { Component, DestroyRef, inject, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { VocabService } from '../../../../../services/vocab.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { Vocab } from '../../../../../models/vocab-model';

@Component({
    selector: 'app-delete-vocab-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './delete-vocab-modal.component.html',
    styleUrl: './delete-vocab-modal.component.scss'
})
export class DeleteVocabModalComponent {
  private destroy = inject(DestroyRef);

  constructor(
    public dialogRef: MatDialogRef<DeleteVocabModalComponent>,
    private toastr: CustomToastrService,
    private vocabService: VocabService,
    @Inject(MAT_DIALOG_DATA) public data: Vocab | Vocab[]
  ) {}

  deleteRoles() {
    if (Array.isArray(this.data)) {
      this.vocabService
        .deleteVocabularyInBulk({
          vocabIds: this.data.map((vocab) => vocab.vocabId),
        })
        .subscribe((r) => {
          this.toastr.success(r.message);
          this.dialogRef.close(true);
        });
    } else {
      this.vocabService
        .deleteVocabulary(this.data.vocabId)
        .pipe(takeUntilDestroyed(this.destroy))
        .subscribe((r) => {
          this.toastr.success(r.message);
          this.dialogRef.close(true);
        });
    }
  }
}
