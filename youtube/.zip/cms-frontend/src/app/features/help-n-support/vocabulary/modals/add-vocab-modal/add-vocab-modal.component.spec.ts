import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddVocabModalComponent } from './add-vocab-modal.component';

describe('AddVocabModalComponent', () => {
  let component: AddVocabModalComponent;
  let fixture: ComponentFixture<AddVocabModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddVocabModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddVocabModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
