import {
  Component,
  DestroyRef,
  OnInit,
  ViewChild,
  inject,
} from '@angular/core';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import { Vocab } from '../../../models/vocab-model';
import { VocabService } from '../../../services/vocab.service';
import { plainToInstance } from 'class-transformer';
import { MatButton, MatButtonModule } from '@angular/material/button';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { ICONS_CONSTS } from '../../../constants/icons-consts';
import { AddVocabModalComponent } from './modals/add-vocab-modal/add-vocab-modal.component';
import { DeleteVocabModalComponent } from './modals/delete-vocab-modal/delete-vocab-modal.component';
import { EditVocabModalComponent } from './modals/edit-vocab-modal/edit-vocab-modal.component';
import { MatDialog } from '@angular/material/dialog';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-vocabulary',
    imports: [
        AppMatSimpleSearchComponent,
        AppMatTableComponent,
        MatButtonModule,
        MatButton,
        MatTooltipModule,
    ],
    templateUrl: './vocabulary.component.html',
    styleUrl: './vocabulary.component.scss'
})
export class VocabularyComponent implements OnInit {
  private destroy = inject(DestroyRef);

  @ViewChild(AppMatSimpleSearchComponent)
  searchBar: AppMatSimpleSearchComponent;

  vocabList: Vocab[];
  tableData: any[];

  constructor(private vocabService: VocabService, public dialog: MatDialog) {}

  selectedKeys: number[] = [];

  ngOnInit(): void {
    this.fetchVocabs();
  }

  fetchVocabs() {
    this.vocabService.getAllVocabulary().subscribe((res) => {
      this.vocabList = plainToInstance<Vocab, []>(Vocab, res);
      this.prepareTableData(this.vocabList);
      this.selectedKeys = [];
    });
  }

  handleSearch(value: string) {
    if (value) {
      const data = this.vocabList.filter((vocab) => {
        const searchIn = vocab.keyword.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
    } else {
      this.prepareTableData(this.vocabList);
    }
  }

  openAddNewModal() {
    const dialogRef = this.dialog.open(AddVocabModalComponent, {
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        result && this.fetchVocabs();
      });
  }

  openDeleteModal(vocab: Vocab | Vocab[]) {
    const dialogRef = this.dialog.open(DeleteVocabModalComponent, {
      data: Array.isArray(vocab) ? [...vocab] : { ...vocab },
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        result && this.fetchVocabs();
      });
  }

  openUpdateModal(vocab: Vocab) {
    const dialogRef = this.dialog.open(EditVocabModalComponent, {
      data: { ...vocab },
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        result && this.fetchVocabs();
      });
  }

  prepareTableData(vocabList: Vocab[]) {
    this.tableData = vocabList.map((vocab: Vocab) => {
      const obj: any = {};
      obj[TABLE_CONSTS.RENDER_CHECKBOX_COLUMN] = '';

      obj[TABLE_CONSTS.NO_RENDER_COLUMN] = vocab.vocabId;

      obj['Keyword'] = vocab.keyword;

      obj['Description'] = vocab.desc;

      obj[TABLE_CONSTS.RENDER_ACTIONS_COLUMN] = [
        ICONS_CONSTS.TABLE_EDIT,
        ICONS_CONSTS.TABLE_DELETE,
      ];

      return obj;
    });
  }

  onAction(icon: string, data: any) {
    const vocab = new Vocab(
      data['Keyword'],
      data['Description'],
      data[TABLE_CONSTS.NO_RENDER_COLUMN]
    );

    switch (icon) {
      case ICONS_CONSTS.TABLE_EDIT: {
        this.openUpdateModal(vocab);
        break;
      }

      case ICONS_CONSTS.TABLE_DELETE: {
        this.openDeleteModal(vocab);
        break;
      }

      case TABLE_CONSTS.RENDER_CHECKBOX_COLUMN:
        if (Array.isArray(data)) {
          const ids: number[] = data.map(
            (d) => d[TABLE_CONSTS.NO_RENDER_COLUMN]
          );

          this.selectedKeys = ids;
        }
        break;

      default:
        return;
    }
  }
  deleteBulk(): void {
    this.openDeleteModal(
      this.vocabList.filter((vocab) =>
        this.selectedKeys.includes(vocab.vocabId)
      )
    );
  }
}
