import { Component, DestroyRef, inject, Inject } from '@angular/core';
import { VocabService } from '../../../../../services/vocab.service';
import { Vocab } from '../../../../../models/vocab-model';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-add-vocab-modal',
    imports: [MatDialogModule, AppMatInputComponent, MatButtonModule],
    templateUrl: './add-vocab-modal.component.html',
    styleUrl: './add-vocab-modal.component.scss'
})
export class AddVocabModalComponent {
  private destroy = inject(DestroyRef);

  newVocab: Vocab = new Vocab('', '');

  constructor(
    public dialogRef: MatDialogRef<AddVocabModalComponent>,
    private vocabService: VocabService,
    private toastr: CustomToastrService,
  ) {}

  onSubmit() {
    this.vocabService
      .insertVocabulary(this.newVocab)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((r) => {
        this.toastr.success(r.message);
        this.dialogRef.close(true);
      });
  }
}
