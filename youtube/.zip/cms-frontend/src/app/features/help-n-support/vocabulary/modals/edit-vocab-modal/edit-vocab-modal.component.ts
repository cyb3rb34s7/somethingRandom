import { Component, DestroyRef, inject, Inject } from '@angular/core';
import { Vocab } from '../../../../../models/vocab-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { VocabService } from '../../../../../services/vocab.service';
import { AddVocabModalComponent } from '../add-vocab-modal/add-vocab-modal.component';

@Component({
    selector: 'app-edit-vocab-modal',
    imports: [MatDialogModule, AppMatInputComponent, MatButtonModule],
    templateUrl: './edit-vocab-modal.component.html',
    styleUrl: './edit-vocab-modal.component.scss'
})
export class EditVocabModalComponent {
  private destroy = inject(DestroyRef);

  currVocab: Vocab;

  constructor(
    public dialogRef: MatDialogRef<AddVocabModalComponent>,
    private vocabService: VocabService,
    private toastr: CustomToastrService,
    @Inject(MAT_DIALOG_DATA) public data: Vocab,
  ) {
    this.currVocab = data;
  }

  onSubmit() {
    this.vocabService
      .updateVocabulary(this.currVocab)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((r) => {
        this.toastr.success(r.message);
        this.dialogRef.close(true);
      });
  }
}
