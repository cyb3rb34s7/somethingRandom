import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TicketService } from '../../../services/ticket.service';

@Component({
    selector: 'app-queries',
    imports: [],
    templateUrl: './queries.component.html',
    styleUrl: './queries.component.scss'
})
export class QueriesComponent implements OnInit {
  private destroy = inject(DestroyRef);
  jiraLink: string = '';
  displayLink: string = '';

  constructor(private ticketService: TicketService) {}

  ngOnInit(): void {
    this.ticketService
      .getJiraLink()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((link: string) => {
        this.jiraLink = link;
        this.displayLink = this.jiraLink.replace('https://', '');
      });
  }
}
