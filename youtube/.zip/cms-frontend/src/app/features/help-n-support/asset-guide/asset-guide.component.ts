import { Component } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { AssetService } from '../../../services/asset.service';
import { CustomToastrService } from '../../../services/custom-toastr.service';

@Component({
    selector: 'app-asset-guide',
    imports: [MatButtonModule, MatTooltipModule, MatIconModule],
    templateUrl: './asset-guide.component.html',
    styleUrl: './asset-guide.component.scss'
})
export class AssetGuideComponent {
  srcUrl: string;
  constructor(
    private assetService: AssetService,
    private toastr: CustomToastrService
  ) {}
  ngOnInit() {
    this.srcUrl = environment.flowChartS3Link;
  }
  downloadSpecs() {
    this.assetService.getSmfFileName().subscribe((fileName) => {
      this.saveFile(fileName);
    });
  }

  private saveFile(fileName: string) {
    this.assetService.downloadSpecs(fileName).subscribe((blob) => {
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(objectUrl);
      this.toastr.success('Sample File Downloaded Successfully!');
    });
  }
}
