import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetGuideComponent } from './asset-guide.component';

describe('AssetGuideComponent', () => {
  let component: AssetGuideComponent;
  let fixture: ComponentFixture<AssetGuideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetGuideComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AssetGuideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
