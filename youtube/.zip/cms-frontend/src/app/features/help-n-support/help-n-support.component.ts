import { Component } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { ITabLabel } from '../../interfaces/i-tab-label';
import { QueriesComponent } from './queries/queries.component';
import { AssetGuideComponent } from './asset-guide/asset-guide.component';
import { VocabularyComponent } from './vocabulary/vocabulary.component';

@Component({
    selector: 'app-help-n-support',
    imports: [
        MatTabsModule,
        QueriesComponent,
        AssetGuideComponent,
        VocabularyComponent,
    ],
    templateUrl: './help-n-support.component.html',
    styleUrl: './help-n-support.component.scss'
})
export class HelpNSupportComponent {
  labels: ITabLabel[] = [];
  selectedTabIndex = 0;

  constructor() {
    this.labels = [
      {
        text: 'Queries',
        count: -1,
      },
      {
        text: 'Asset Guide',
        count: -1,
      },
      {
        text: 'System Vocabulary',
        count: -1,
      },
    ];
  }

  handleTabChange(index: number) {
    this.selectedTabIndex = index;
  }
}
