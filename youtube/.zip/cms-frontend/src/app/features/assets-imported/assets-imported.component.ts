import {
  Component,
  Input,
  DestroyRef,
  inject,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  Output,
} from '@angular/core';
import { Asset } from '../../models/asset-model';
import { MatDialog, MatDialogActions } from '@angular/material/dialog';
import { AppMatTableComponent } from '../../mat-components/app-mat-table/app-mat-table.component';
import { Router } from '@angular/router';
import { plainToInstance } from 'class-transformer';
import { AssetService } from '../../services/asset.service';

import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AppMatInputComponent } from '../../mat-components/app-mat-input/app-mat-input.component';

import { MatButtonModule } from '@angular/material/button';

import { STATUS_HTML } from '../../constants/status-html-const';

import { DownloadsAndImportsComponent } from '../../components/downloads-imports/downloads-and-imports/downloads-and-imports.component';
import { CommonModule } from '@angular/common';
import { ProgressBarModalComponent } from '../../components/downloads-imports/progress-bar-modal/progress-bar-modal.component';
@Component({
    selector: 'app-assets-imported',
    imports: [AppMatTableComponent, MatButtonModule, CommonModule],
    templateUrl: './assets-imported.component.html',
    styleUrl: './assets-imported.component.scss'
})
export class AssetsImportedComponent {
  private destroy = inject(DestroyRef);
  @Input() filteredDataAll: any;
  filteredDataObj: any;
  allAssetsData: Asset[];
  tableAllData: any[];

  importedAssets: any;

  success: number = 0;
  fail: number = 0;
  result: string = '';
  fileToUpload: any;

  progress = 0;

  existingImportData: Asset[];

  @ViewChild('file') file: ElementRef;

  constructor(
    private assetService: AssetService,
    public dialog: MatDialog,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
    // @Output this.existingImportData=
    console.log('Imported media asset works');
    this.getExcelData();
  }
  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    this.changeDetectorRef.detectChanges();
  }
  getExcelData() {
    if (
      this.assetService.existingUpdates &&
      this.assetService.existingUpdates.length > 0
    ) {
      this.allAssetsData = this.assetService.existingUpdates;
      this.prepareTableData();
    } else {
      this.assetService.getExistingUpdates().subscribe((res: any) => {
        this.allAssetsData = res;
        this.prepareTableData();
      });
    }
  }

  prepareTableData() {
    this.tableAllData = this.helper(this.allAssetsData);
    this.success = 0;
    this.fail = 0;
    this.allAssetsData.forEach((objAsset: Asset) => {
      if (objAsset.result === 'Successful') {
        this.success++;
      } else {
        this.fail++;
      }
    });
  }

  helper(allAssetsData: Asset[]) {
    let newAllAssetsData;
    let include: any = [];
    for (let i = 0; i < allAssetsData.length; i++) {
      const keys = Object.keys(allAssetsData[i]);
      keys.forEach((k) => {
        if (allAssetsData.some((d: any) => d[k])) {
          if (include.includes(k) === false) {
            include.push(k);
          }
        }
      });
      include = include.filter((k: string) => k !== 'result');
      include.push('result');
    }

    const assetsToShow: any = [];

    newAllAssetsData = allAssetsData.map((d: any) => {
      const data: any = {};
      include.forEach((k: string) => {
        data[k] = d[k];
      });
      return data;
    });

    newAllAssetsData.forEach((d) => {
      let obj: any = {};
      include.forEach((k: string) => {
        switch (k) {
          case 'contentId':
            obj['Program ID'] = d.contentId;
            break;
          case 'countryCode':
            obj['Country Code'] = d.countryCode;
            break;
          case 'vcCpId':
            obj['Provider ID'] = d.vcCpId;
            break;
          case 'assetId':
            obj['Asset Id'] = d.assetId;
            break;
          case 'type':
            obj['Type'] = d.type;
            break;
          case 'mainTitle':
            obj['Main Title'] = d.mainTitle;
            break;
          case 'shortTitle':
            obj['Short Title'] = d.shortTitle;
            break;
          case 'releaseDate':
            obj['Original Release Date'] = d.releaseDate;
            break;
          case 'description':
            obj['Synopsis/Description'] = d.description;
            break;
          case 'starring':
            obj['Actor'] = d.starring;
            break;
          case 'director':
            obj['Director'] = d.director;
            break;
          case 'artist':
            obj['Artist'] = d.artist;
            break;
          case 'genres':
            obj['Genre'] = d.genres;
            break;
          case 'availableStarting':
            obj['Window Start Date'] = d.availableStarting;
            break;
          case 'expiryDate':
            obj['Window End Date'] = d.expiryDate;
            break;
          case 'ratingBody':
            obj['Organization'] = d.ratingBody;
            break;
          case 'ratings':
            obj['Ratings'] = d.ratings;
            break;
          case 'contentPartner':
            obj['Content Partner'] = d.contentPartner;
            break;
          case 'contentTier':
            obj['Content Tier'] = d.contentTier;
            break;
          case 'externalId':
            obj['External Program Id'] = d.externalId;
            break;
          case 'externalIdProvider':
            obj['ID Provider'] = d.externalIdProvider;
            break;
          case 'externalIdType':
            obj['Id Type'] = d.externalIdType;
            break;
          case 'result':
            obj['Import Status'] =
              d.result === 'Successful'
                ? STATUS_HTML.ACTIVE + d.result
                : STATUS_HTML.MISSING + d.result;
            break;
        }
      });

      assetsToShow.push(obj);
    });
    return assetsToShow;
  }

  handleCancel() {
    this.assetService
      .uploadAction('cancel')
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.assetService.existingUpdates = [];
        this.router.navigate(['media-assets']);
      });
  }

  confirm() {
    this.assetService
      .uploadAction('Confirm')
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.assetService.existingUpdates = [];
        this.router.navigate(['media-assets']);
      });
  }

  reImport() {
    this.assetService
      .uploadAction('reImport')
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.assetService.existingUpdates = [];
        this.file.nativeElement.click();
      });
  }
  handleFileInput(event: any) {
    let files: FileList = event.target.files;
    this.fileToUpload = files.item(0);

    let formData = new FormData();

    formData.append('file', this.fileToUpload);
    this.openProgressBarModal(formData);
  }
  openProgressBarModal(data: any) {
    const dialogRef = this.dialog.open(ProgressBarModalComponent, {
      data: data,
      panelClass: 'progress-bar-modal',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'Upload Success') {
        this.getExcelData();
      }
    });
  }
}
