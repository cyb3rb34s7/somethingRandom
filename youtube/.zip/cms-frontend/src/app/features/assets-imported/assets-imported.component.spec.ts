import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsImportedComponent } from './assets-imported.component';

describe('AssetsImportedComponent', () => {
  let component: AssetsImportedComponent;
  let fixture: ComponentFixture<AssetsImportedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetsImportedComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AssetsImportedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
