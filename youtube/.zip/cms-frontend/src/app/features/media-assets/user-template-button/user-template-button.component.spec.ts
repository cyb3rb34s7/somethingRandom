import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTemplateButtonComponent } from './user-template-button.component';

describe('UserTemplateButtonComponent', () => {
  let component: UserTemplateButtonComponent;
  let fixture: ComponentFixture<UserTemplateButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserTemplateButtonComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserTemplateButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
