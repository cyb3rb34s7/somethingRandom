import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Output,
  ViewChild,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule, MatMenuTrigger } from '@angular/material/menu';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { StateStoreService } from '../../../services/store/state-store.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { instanceToInstance, plainToInstance } from 'class-transformer';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../../models/assets-columns-filters-model';
import {
  FilterTemplate,
  UserFilterTemplates,
} from '../../../models/filter-templates-model';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CommonModule } from '@angular/common';
import { FilterTemplateUtilService } from '../../../services/filter-template-util.service';

@Component({
  selector: 'app-user-template-button',
  imports: [
    MatMenuModule,
    MatButtonModule,
    AppMatSimpleSearchComponent,
    MatTooltipModule,
    CommonModule,
  ],
  templateUrl: './user-template-button.component.html',
  styleUrl: './user-template-button.component.scss'
})
export class UserTemplateButtonComponent {
  private destroy = inject(DestroyRef);

  @Output() openSavedTemplatesList: EventEmitter<any> = new EventEmitter();

  userFilterTemplates: UserFilterTemplates;

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  templateData: FilterTemplate[];

  _backup: FilterTemplate[] = [];

  templateSearchString: string;

  appliedTemplateId: number;

  @ViewChild('templateMenu') templateMenuTrigger: MatMenuTrigger;

  constructor(
    private storeService: StateStoreService,
    private templateUtils: FilterTemplateUtilService
  ) { }

  ngOnInit() {
    const objColumnsAndFilterData = this.storeService.getStoreState(STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES);
    if (!objColumnsAndFilterData.filtersMerged) {
      this.templateUtils.fetchFilters();
    }
    this.getUserTemplatesFromStorage();
    this.subscribeToAppliedTemplate();
  }

  subscribeToAppliedTemplate() {
    this.storeService.stateStore[STORE_CONSTS.APPLIED_FILTER_TEMPLATE]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((appliedTemplateId: number) => {
        this.appliedTemplateId = appliedTemplateId;
      });
  }

  getUserTemplatesFromStorage() {
    this.storeService.stateStore[STORE_CONSTS.USER_FILTER_TEMPLATES]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((userFilterTemplates: UserFilterTemplates) => {
        this.userFilterTemplates = userFilterTemplates;
        if (!userFilterTemplates.templatesMerged) {
          this.templateUtils.fetchUserTemplates();
        } else {
          this.templateData = userFilterTemplates.userTemplates;
          this._backup = [...this.templateData];
        }
      });

    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        this.columnsAndFilterData = instanceToInstance(obj);
      });
  }

  handleTemplateSearch(value: string) {
    if (value) {
      this.templateData = this._backup.filter((d: FilterTemplate) => {
        const searchIn = d.templateName.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
    } else {
      this.templateData = [...this._backup];
    }
  }

  handleApplyUserTemplate(objTemplate: FilterTemplate) {
    objTemplate.handleRelevantStatus();

    this.columnsAndFilterData.filters.forEach((f) => {
      const found = objTemplate.filters.find((_f) => _f.key === f.key);
      if (found) {
        f.selected = [...found.selected];
      } else {
        f.selected = [];
      }
    });

    this.columnsAndFilterData.filterChanged = true;

    this.storeService.setStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      this.columnsAndFilterData
    );

    this.storeService.setStoreState(
      STORE_CONSTS.APPLIED_FILTER_TEMPLATE,
      objTemplate.templateId
    );
  }

  closeTemplateMenu() {
    this.templateMenuTrigger.closeMenu();
  }
}
