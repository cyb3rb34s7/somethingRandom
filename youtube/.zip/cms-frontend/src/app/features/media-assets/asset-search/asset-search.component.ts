import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  HostListener,
  inject,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../../models/assets-columns-filters-model';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { StateStoreService } from '../../../services/store/state-store.service';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SimpleMatSelectComponent } from './simple-mat-select/simple-mat-select.component';

const searchFields = ['contentId', 'mainTitle', 'showTitle', 'seasonTitle'];
@Component({
    selector: 'app-asset-search',
    imports: [
        CommonModule,
        SimpleMatSelectComponent,
        AppMatSimpleSearchComponent,
        MatButtonModule,
        MatTooltipModule,
    ],
    templateUrl: './asset-search.component.html',
    styleUrl: './asset-search.component.scss'
})
export class AssetSearchComponent implements OnInit {
  private destroy = inject(DestroyRef);

  filterDisplayTextList: string[] = [];

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  currentCategory: string;

  currentSearchString: string;

  @ViewChild(AppMatSimpleSearchComponent)
  matSearch: AppMatSimpleSearchComponent;

  @ViewChild(SimpleMatSelectComponent)
  matSelect: SimpleMatSelectComponent;

  constructor(private storeService: StateStoreService) {}

  ngOnInit(): void {
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        this.columnsAndFilterData = obj;
        this.filterDisplayTextList = [];
        searchFields.forEach((key) => {
          const objFilter = this.columnsAndFilterData.filters.find(
            (f) => f.key === key
          );
          if (objFilter) {
            this.filterDisplayTextList.push(objFilter.displayText);
          }
        });

        const last_search = sessionStorage.getItem('asset-search');
        if (last_search) {
          const objLastSearch = JSON.parse(last_search);
          this.currentCategory = objLastSearch.category;
          if (this.checkReset(objLastSearch.text)) {
            setTimeout(() => {
              this.matSearch.searchFormControl.setValue(objLastSearch.text);
            }, 0);
          } else {
            this.clearSearch();
          }
        } else {
          this.currentCategory = this.currentCategory
            ? this.currentCategory
            : this.filterDisplayTextList[0];
        }
      });
  }

  checkReset(text: string) {
    const objFilter = this.columnsAndFilterData.filters.find(
      (f) => f.displayText === this.currentCategory
    );
    if (objFilter) {
      return JSON.stringify(objFilter.selected) === JSON.stringify([text]);
    }
    return true;
  }

  handleSearchStringChange(newSearchString: string): void {
    this.currentSearchString = newSearchString;
  }

  onCategoryChange() {
    const last_search = sessionStorage.getItem('asset-search');

    if (
      this.currentSearchString &&
      this.currentSearchString.trim() &&
      last_search
    ) {
      const objLastSearch = JSON.parse(last_search);
      if (objLastSearch.category !== this.currentCategory) {
        console.log('onCategoryChange');
        this.handleSearch();
      }

      //
    }
  }

  handleSearch(): void {
    const objFilter = this.columnsAndFilterData.filters.find(
      (f) => f.displayText === this.currentCategory
    );
    if (objFilter) {
      const last_search = sessionStorage.getItem('asset-search');
      if (last_search) {
        const objLastSearch = JSON.parse(last_search);
        const prevFilter = this.columnsAndFilterData.filters.find(
          (f) => f.displayText === objLastSearch.category
        );
        if (prevFilter) {
          prevFilter.selected = [];
        }
      }

      objFilter.selected = [this.currentSearchString];
      this.columnsAndFilterData.filterChanged = true;

      sessionStorage.setItem(
        'asset-search',
        JSON.stringify({
          category: this.currentCategory,
          text: this.currentSearchString,
        })
      );
      this.storeService.setStoreState(
        STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
        this.columnsAndFilterData
      );
    }
  }

  cancelSearch() {
    const last_search = sessionStorage.getItem('asset-search');
    if (last_search) {
      const objLastSearch = JSON.parse(last_search);
      const objFilter = this.columnsAndFilterData.filters.find(
        (f) => f.displayText === objLastSearch.category
      );
      if (objFilter) {
        objFilter.selected = [];
        this.clearSearch();
        this.columnsAndFilterData.filterChanged = true;
        this.storeService.setStoreState(
          STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
          this.columnsAndFilterData
        );
      }
    }
  }

  clearSearch() {
    sessionStorage.removeItem('asset-search');
    this.matSearch.searchFormControl.setValue(null);
    this.currentSearchString = '';
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.handleSearch();
      // Add your logic here
    }
  }
}
