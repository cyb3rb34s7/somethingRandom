import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleMatSelectComponent } from './simple-mat-select.component';

describe('SimpleMatSelectComponent', () => {
  let component: SimpleMatSelectComponent;
  let fixture: ComponentFixture<SimpleMatSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SimpleMatSelectComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SimpleMatSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
