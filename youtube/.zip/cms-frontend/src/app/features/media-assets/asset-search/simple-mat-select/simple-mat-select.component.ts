import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

@Component({
    selector: 'app-simple-mat-select',
    imports: [
        CommonModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule,
    ],
    templateUrl: './simple-mat-select.component.html',
    styleUrl: './simple-mat-select.component.scss'
})
export class SimpleMatSelectComponent implements OnInit, OnChanges {
  @Input({ required: true })
  optionList: string[];

  @Input()
  defaultOption?: string;

  @Output()
  selectionChange = new EventEmitter<string>();

  optionControl = new FormControl<string | null>(null);

  ngOnInit(): void {
    this.setDefaultOption();

    this.optionControl.valueChanges.subscribe((value) => {
      if (value) {
        this.selectionChange.emit(value);
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['optionList'] || changes['defaultOption']) {
      this.setDefaultOption();
    }
  }

  private setDefaultOption(): void {
    if (this.defaultOption && this.optionList.includes(this.defaultOption)) {
      this.optionControl.setValue(this.defaultOption);
    } else if (this.optionList.length > 0) {
      this.optionControl.setValue(this.optionList[0]);
    }
  }

  getSelectedValue(): string | null {
    return this.optionControl.value;
  }

  setSelectedValue(value: string): void {
    if (this.optionList.includes(value)) {
      this.optionControl.setValue(value);
    } else {
      console.warn(
        `Value ${value} is not in the option list and cannot be selected`,
      );
    }
  }
}
