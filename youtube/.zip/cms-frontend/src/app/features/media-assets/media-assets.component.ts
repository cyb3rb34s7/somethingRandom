import { Component, DestroyRef, inject, ViewChild } from '@angular/core';

import { MatDialog } from '@angular/material/dialog';
import {
  instanceToInstance,
  instanceToPlain,
  plainToInstance,
} from 'class-transformer';

import { MediaAssetsTabLabels } from '../../interfaces/media-assets-tab-label';

import { AssetService } from '../../services/asset.service';
import { AppAssetsColumnModalComponent } from './modals/app-assets-column-modal/app-assets-column-modal.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';

import { StateStoreService } from '../../services/store/state-store.service';
import { STORE_CONSTS } from '../../constants/store-consts';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Column,
  Filter,
} from '../../models/assets-columns-filters-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { UserTemplateButtonComponent } from './user-template-button/user-template-button.component';
import { Asset } from '../../models/asset-model';
import { BulkActionComponent } from './bulk-actions/bulk-action/bulk-action.component';
import { DownloadsAndImportsComponent } from '../../components/downloads-imports/downloads-and-imports/downloads-and-imports.component';
import { AssetsFilterModalBaseComponent } from './modals/assets-filter-modal-base/assets-filter-modal-base.component';
import { FilterRequestBody } from '../../models/license-filter-model';
import { HttpErrorResponse } from '@angular/common/http';
import {
  prepareTableData,
  onViewDetail,
  formatCellValueForTable,
} from '../media-assets/_helper';
import { ICONS_CONSTS } from '../../constants/icons-consts';
import { TABLE_CONSTS } from '../../constants/table-consts';
import { Router } from '@angular/router';
import { getFileName } from '../change-history/_helper';
import { HISTORY_CONSTS } from '../../constants/history-consts';
import { CustomToastrService } from '../../services/custom-toastr.service';
import { AssetsTableComponent } from './assets-table/assets-table.component';
import { AssetExcelExportService } from '../../services/asset-excel-export.service';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AssetSearchComponent } from './asset-search/asset-search.component';
import { SortingPanelComponent } from './modals/sorting-panel/sorting-panel.component';

@Component({
  selector: 'app-media-assets',
  imports: [
    MatTabsModule,
    BulkActionComponent,
    UserTemplateButtonComponent,
    DownloadsAndImportsComponent,
    MatButtonModule,
    AssetsTableComponent,
    MatMenuModule,
    MatTooltipModule,
    AssetSearchComponent,
  ],
  templateUrl: './media-assets.component.html',
  styleUrl: './media-assets.component.scss',
})
export class MediaAssetsComponent {
  private destroy = inject(DestroyRef);

  @ViewChild(AssetSearchComponent)
  assetSearchComponent: AssetSearchComponent;

  @ViewChild(AssetsTableComponent)
  assetTable: AssetsTableComponent;

  @ViewChild(DownloadsAndImportsComponent)
  downloadImport: DownloadsAndImportsComponent;

  selecetedAssets: Asset[];

  labels: MediaAssetsTabLabels[] = [
    { text: 'All Assets', count: -1 },
    { text: 'Assets In QC', count: -1 },
    { text: 'Assets In Production', count: -1 },
  ];

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  selectedTabIndex: number;

  _tabIndex = parseInt(sessionStorage.getItem('assets-last-tab')!, 10);

  allAssetsData: Asset[];

  assetDataBackup: Asset[];

  tableData: any[];

  lastPayload: any;

  searchPlaceHolderTxt: string = 'Search ';

  showActualCount: boolean = false;

  offsetIndex: number = 0;

  initialLoad: number = 1000;

  bNoMoreData: boolean = false;

  timer: any;

  isExcelExporting: boolean;

  bS3CallMade = false;

  constructor(
    public dialog: MatDialog,
    private storeService: StateStoreService,
    private assetService: AssetService,
    private router: Router,
    private toastr: CustomToastrService,
    private excelExportService: AssetExcelExportService
  ) {
    sessionStorage.setItem(
      'last-region',
      storeService.getStoreState(STORE_CONSTS.REGION)
    );
    let tableSessionData = sessionStorage.getItem('asset-table-data');
    if (tableSessionData) {
      const _data = JSON.parse(tableSessionData);
      if (_data.paginationData) {
        const { pageIndex, pageSize } = _data.paginationData;
        const count = ((pageIndex + 1) * pageSize) / 1000;
        if (count >= 1) {
          this.initialLoad = Math.ceil(count > 1 ? count : 2) * 1000;
        }
      }
    }
  }

  ngOnInit() {
    this.labels[0].count = sessionStorage.getItem('allAssets')
      ? parseInt(sessionStorage.getItem('allAssets')!, 10)
      : this.labels[0].count;
    this.labels[1].count = sessionStorage.getItem('assetsInQC')
      ? parseInt(sessionStorage.getItem('assetsInQC')!, 10)
      : this.labels[1].count;
    this.labels[2].count = sessionStorage.getItem('assetsInProduction')
      ? parseInt(sessionStorage.getItem('assetsInProduction')!, 10)
      : this.labels[2].count;

    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        if (
          obj.userPrefCountrySet === true ||
          obj.userPrefCountrySet === false
        ) {
          if (!obj.columnsMerged) {
            this.bS3CallMade = true;
            this.assetService
              .getColumnAndFilterFromS3()
              .pipe(takeUntilDestroyed(this.destroy))
              .subscribe({
                next: (staticJsonData: any) => {
                  this.setStaticData(staticJsonData);
                },
                error: (error: HttpErrorResponse) => {
                  this.assetService
                    .getColumnAndFilterFromAsset()
                    .pipe(takeUntilDestroyed(this.destroy))
                    .subscribe((staticJsonData: any) => {
                      this.setStaticData(staticJsonData);
                    });
                },
              });
          } else if (obj.columnsMerged && obj.filterChanged) {
            const nObj = instanceToInstance(obj);
            nObj.filterChanged = false;
            this.clearUpDataAndResetTable();
            this.storeService.setStoreState(
              STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
              nObj
            );
          } else if (obj.columnsMerged) {
            this.columnsAndFilterData = obj;
            const lastTabIndex = sessionStorage.getItem('assets-last-tab');

            if (lastTabIndex !== this.selectedTabIndex?.toString()) {
              this.handleTabChange(parseInt(lastTabIndex!, 10), true);
            } else {
              this.getAssetsAndCounts();
            }
          }
        }
      });
    this.storeService.stateStore[STORE_CONSTS.IS_EXCEL_DOWNLOADING]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.isExcelExporting = this.storeService.getStoreState(
          STORE_CONSTS.IS_EXCEL_DOWNLOADING
        );
      });
    this.storeService.stateStore[STORE_CONSTS.SORTING_CHANGED]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((v: boolean) => {
        if (v) {
          this.getAssets();
          this.storeService.setStoreState(STORE_CONSTS.SORTING_CHANGED, false);
        }
      });
  }

  clearUpDataAndResetTable() {
    this.allAssetsData = [];
    this.offsetIndex = 0;
    this.initialLoad = 1000;
    if (this.assetTable) {
      this.assetTable.setSessionData({ paginationData: null });
      this.assetTable.pageIndex = 0;
      this.assetTable.selection = [];
      if (this.assetTable.paginator) {
        this.assetTable.paginator.pageIndex = 0;
      }
    }
  }

  setStaticData(staticJsonData: any) {
    const assetsColumnAndFilters = instanceToInstance(
      this.storeService.getStoreState(
        STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
      )
    );

    const columnEntries = Object.entries(staticJsonData.columns);
    const tablePref = sessionStorage.getItem('asset-table-data');
    let columnsRaw = columnEntries.map((c) => {
      const obj: any = {};
      obj.key = c[0];
      obj.name = c[1];
      obj.isDefault = staticJsonData.mandatoryColumns[c[0]] ? true : false;
      obj.selected = staticJsonData.defaultColumns[c[0]] ? true : false;
      if (staticJsonData.numericColumns[c[0]]) {
        obj.type = 'numeric';
      } else if (staticJsonData.dateColumns[c[0]]) {
        obj.type = 'date';
      } else if (staticJsonData.alphabeticColumns[c[0]]) {
        obj.type = 'alphabetic';
      }

      return obj;
    });
    if (tablePref) {
      const { columnSelected } = JSON.parse(tablePref);
      if (columnSelected) {
        columnsRaw = columnsRaw.map((c) => {
          if (columnSelected.includes(c.name)) {
            c.selected = true;
          } else {
            c.selected = false;
          }
          return c;
        });
      }
    }

    assetsColumnAndFilters.columns = plainToInstance<Column, []>(
      Column,
      columnsRaw
    );

    assetsColumnAndFilters.columnOrder = assetsColumnAndFilters.columns.map(
      (c: Column) => c.name
    );

    const filters = [
      ...assetsColumnAndFilters.filters,
      ...staticJsonData.filters,
    ];

    const clubbedFilters: any = [];
    filters.forEach((f: any) => {
      const found = clubbedFilters.find((_f: any) => _f.key === f.key);
      if (!found) {
        clubbedFilters.push(f);
      }
    });

    assetsColumnAndFilters.filters = plainToInstance<Filter, []>(
      Filter,
      clubbedFilters
    );

    assetsColumnAndFilters.columnsMerged = true;

    this.storeService.setStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      assetsColumnAndFilters
    );
  }

  handleTabChange(index: number, init?: boolean) {
    this.selectedTabIndex = index;
    sessionStorage.setItem('assets-last-tab', index.toString());
    //to tell filter model which tab is selected
    this.columnsAndFilterData.filtersQcDefaultsApplied = false;
    this.columnsAndFilterData.filtersProdDefaultsApplied = false;
    switch (index) {
      case 1:
        this.columnsAndFilterData.setFilterSelection('productionStatus', []);
        this.columnsAndFilterData.setFilterSelection('qcStatus', [
          'QC in Progress',
          'QC Pass',
          'QC Fail',
        ]);
        this.columnsAndFilterData.setFilterSelection('allStatus', []);
        this.columnsAndFilterData.filtersQcDefaultsApplied = true;
        break;
      case 2:
        this.columnsAndFilterData.setFilterSelection('productionStatus', [
          'Released',
        ]);
        this.columnsAndFilterData.setFilterSelection('qcStatus', []);
        this.columnsAndFilterData.setFilterSelection('allStatus', []);
        this.columnsAndFilterData.filtersProdDefaultsApplied = true;
        break;
      default:
        this.columnsAndFilterData.setFilterSelection('productionStatus', []);
        this.columnsAndFilterData.setFilterSelection('qcStatus', []);
        this.columnsAndFilterData.setFilterSelection('allStatus', []);
        break;
    }

    if (this.assetTable && !init) {
      this.assetTable.setSessionData({ paginationData: null });
      this.assetTable.pageIndex = 0;
      this.assetTable.paginator.pageIndex = 0;
      this.offsetIndex = 0;
      this.initialLoad = 1000;
      this.bNoMoreData = false;
      this.assetTable.selection = [];
    }

    this.storeService.setStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      this.columnsAndFilterData
    );
  }

  getAssetsAndCounts() {
    if (
      this.lastPayload &&
      this.columnsAndFilterData.comparePayload(this.lastPayload)
    ) {
      this.tableData = this.tableData ? [...this.tableData] : this.tableData;
      return;
    }
    this.lastPayload = this.columnsAndFilterData.preparePayload();
    const lastTab = sessionStorage.getItem('assets-last-tab') as any;
    if (lastTab !== '0' && !isNaN(lastTab)) {
      if (!this.lastPayload.filters.find((obj: any) => obj.key === 'status')) {
        this.allAssetsData = [];
        this.assetDataBackup = [];
        this.tableData = [];
        this.lastPayload = null;
        switch (lastTab) {
          case '1':
            this.labels[1].count = -1;
            sessionStorage.setItem('assetsInQC', '-1');
            break;
          case '2':
            this.labels[2].count = -1;
            sessionStorage.setItem('assetsInProduction', '-1');
            break;
        }

        return;
      }
    }
    this.getCounts();
  }

  getCounts() {
    this.lastPayload = this.columnsAndFilterData.preparePayload();
    const currentTab =
      this.selectedTabIndex === 1
        ? 'qc'
        : this.selectedTabIndex === 2
        ? 'prod'
        : 'all';
    this.assetService
      .getAssetsCounts(currentTab, this.lastPayload)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          const some = this.labels.some((obj) => {
            return (obj.count as number) > -1;
          });

          if (some) {
            const lbl = this.labels[this.selectedTabIndex | 0];
            switch (lbl.text) {
              case 'All Assets':
                lbl.count = res.allAssets;
                sessionStorage.setItem('allAssets', res.allAssets);
                break;
              case 'Assets In QC':
                lbl.count = res.assetsInQC;
                sessionStorage.setItem('assetsInQC', res.assetsInQC);
                break;
              case 'Assets In Production':
                lbl.count = res.assetsInProduction;
                sessionStorage.setItem(
                  'assetsInProduction',
                  res.assetsInProduction
                );
                break;
            }
          } else {
            this.labels = this.labels.map((l, i) => {
              if (i === 0) {
                l.count = res.allAssets > 0 ? res.allAssets : -1;
                sessionStorage.setItem('allAssets', res.allAssets);
              } else if (i === 1) {
                l.count = res.assetsInQC > 0 ? res.assetsInQC : -1;
                sessionStorage.setItem('assetsInQC', res.assetsInQC);
              } else {
                l.count =
                  res.assetsInProduction > 0 ? res.assetsInProduction : -1;
                sessionStorage.setItem(
                  'assetsInProduction',
                  res.assetsInProduction
                );
              }
              return l;
            });
          }
          this.getAssets();
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }

  getAssets() {
    this.lastPayload = this.columnsAndFilterData.preparePayload();
    let finalPayload = {
      ...this.lastPayload,
      pagination: {
        limit: this.initialLoad,
        offset: this.offsetIndex * 1000,
      },
    };

    finalPayload = this.checkForAppliedSorting(finalPayload);

    this.assetService
      .getAssets(finalPayload)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          if (res.length < 1000) {
            this.bNoMoreData = true;
          }
          if (this.offsetIndex > 0) {
            this.allAssetsData.splice(this.offsetIndex * 1000);
            this.allAssetsData = [
              ...this.allAssetsData,
              ...plainToInstance<Asset, []>(Asset, res),
            ];
            this.assetDataBackup.splice(this.offsetIndex * 1000);
            this.assetDataBackup = [
              ...this.assetDataBackup,
              ...plainToInstance<Asset, []>(Asset, res),
            ];
          } else {
            this.allAssetsData = plainToInstance<Asset, []>(Asset, res);
            this.assetDataBackup = plainToInstance<Asset, []>(Asset, res);
            if (this.initialLoad > 1000) {
              this.offsetIndex = this.initialLoad / 1000;
              this.initialLoad = 1000;
            }
          }

          this.prepareTableData();

          this.selecetedAssets = [];
        },
        error: (error: HttpErrorResponse) => {
          this.allAssetsData = [];
          this.assetDataBackup = [];
          this.tableData = [];
          this.lastPayload = null;
          console.log('====Error===', error);
        },
      });
  }

  /*********Temporarily restored ************************** */

  // appliedSortBy: string;

  // applySortBy(str: string) {
  //   this.appliedSortBy = str;
  //   const arrSelected = [{ field: str, active: true, order: 'DESC' }];
  //   sessionStorage.setItem('assets-sorting', JSON.stringify(arrSelected));
  //   this.storeService.setStoreState(STORE_CONSTS.SORTING_CHANGED, true);
  // }

  /*************************************** */

  checkForAppliedSorting(finalPayload: any) {
    let appliedSortBy = sessionStorage.getItem('assets-sorting')
      ? JSON.parse(sessionStorage.getItem('assets-sorting')!)
      : [];
    if (appliedSortBy.length) {
      appliedSortBy = appliedSortBy.filter((obj: any) =>
        finalPayload.columns.find(
          (c: string) => c.includes(obj.field) && obj.order
        )
      );

      appliedSortBy = appliedSortBy.map((obj: any) => {
        return { field: obj.field, order: obj.order };
      });

      finalPayload = appliedSortBy.length
        ? {
            ...finalPayload,
            sortBy: appliedSortBy,
          }
        : finalPayload;
    }
    return finalPayload;
  }

  prepareTableData() {
    this.tableData = prepareTableData(
      this.allAssetsData,
      this.columnsAndFilterData.columns
    );

    this.displayBulkActionToastrResponse();
  }

  displayBulkActionToastrResponse() {
    const response: any = this.storeService.getStoreState(
      STORE_CONSTS.BULK_ACTION_RESPONSE
    );
    if (response.warn) {
      this.toastr.warn(response.warn);
      this.storeService.setStoreState(STORE_CONSTS.BULK_ACTION_RESPONSE, {});
    }
    if (response.success) {
      this.toastr.success(response.success);
      this.storeService.setStoreState(STORE_CONSTS.BULK_ACTION_RESPONSE, {});
    }
  }

  handleAction(e: any) {
    if (e.icon === ICONS_CONSTS.TABLE_DETAILS) {
      sessionStorage.setItem(
        'filtersApplied',
        JSON.stringify(instanceToPlain(this.columnsAndFilterData))
      );
      onViewDetail(e.data, this.router, this.allAssetsData);
    }

    if (e.icon === TABLE_CONSTS.RENDER_CHECKBOX_COLUMN) {
      const ids = e.data;

      const selected: Asset[] = this.allAssetsData.filter((val: Asset) =>
        ids.includes(val.contentId)
      );
      this.selecetedAssets = selected;

      this.storeService.setStoreState(STORE_CONSTS.SELECTEDASSETS, selected);
    }
  }

  openFilterPanel(bOpenSavedTemplateList?: boolean) {
    const dialogRef = this.dialog.open(AssetsFilterModalBaseComponent, {
      panelClass: 'media-assets-filter-modal',
      position: { right: '0' },
      height: '100vh',
      data: {
        bOpenList: bOpenSavedTemplateList,
      },
    });
  }

  openColumnPanel() {
    const dialogRef = this.dialog.open(AppAssetsColumnModalComponent, {
      panelClass: 'media-assets-column-modal',
      position: { right: '0' },
      height: '100vh',
      enterAnimationDuration: '0ms',
      exitAnimationDuration: '0ms',
    });
  }

  refreshAssets() {
    this.labels.forEach((obj) => {
      obj.count = -1;
    });
    this.lastPayload = null;
    this.selecetedAssets = [];
    this.assetTable.selection = [];
    this.getAssetsAndCounts();
  }

  exportAllAssets(columns: 'current-columns' | 'all-columns') {
    const selectedColumns: string[] =
      columns === 'all-columns' ? [] : this.getCurrentSelectedColumns();
    this.handleExport(selectedColumns, [], null);
  }

  exportFilteredAssets(columns: 'current-columns' | 'all-columns') {
    const selectedColumns: string[] =
      columns === 'all-columns' ? [] : this.getCurrentSelectedColumns();
    const filters = [...this.lastPayload.filters];
    this.handleExport(selectedColumns, filters, null);
  }

  exportSelectedAssets(columns: 'current-columns' | 'all-columns') {
    const selectedColumns: string[] =
      columns === 'all-columns' ? [] : this.getCurrentSelectedColumns();
    const filters = [
      {
        key: 'contentId',
        type: 'filter',
        values: this.selecetedAssets.map((asset) => asset.contentId),
      },
    ];
    this.handleExport(selectedColumns, filters, null);
  }

  handleExport(selectedColumns: string[], filters: any, pagination: any) {
    const filename = getFileName('MediaAssets');
    this.storeService.setStoreState(
      STORE_CONSTS.EXCEL_DOWNLOAD_FILENAME,
      filename
    );

    const filterBody: FilterRequestBody = {
      columns: selectedColumns,
      filters: filters,
      pagination: pagination,
    };
    // Saving Subscription Before returning to implement Cancellation
    return (this.excelExportService.currentExportSubscription =
      this.excelExportService.exportAssetToExcel(filterBody).subscribe({
        next: (res) => {
          if (res) {
            const fileName = this.extractFileName(res.headers);

            this.downloadFile(res.body, fileName);

            this.toastr.success('Data is Exported Successfully');
          }
        },
        error: (error) => {
          this.toastr.error('Export Failed');
        },
      }));
  }

  getCurrentSelectedColumns(): string[] {
    let columns: string[] = [];
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        const plain = instanceToPlain(obj);
        columns = plainToInstance(
          AssetColumnsAndFiltersAndFilterTemplates,
          plain
        )
          .columns.filter((c) => c.selected)
          .map((c) => c.key);
      });
    return columns;
  }

  private extractFileName(headers: any): string {
    let fileName;
    const contentDisposition =
      headers.get('Content-Disposition') || headers.get('content-disposition');
    if (contentDisposition) {
      const matches = contentDisposition.match(/filename\s*=\s*"?([^";\s]+)"?/);
      if (matches && matches[1]) {
        fileName = matches[1];
        return fileName;
      }
    }
    return '';
  }

  exportAssetForBulkImport(filterType: 'selected' | 'filtered') {
    const filename = getFileName('MediaAssetsExportTemplate');
    this.storeService.setStoreState(
      STORE_CONSTS.EXCEL_DOWNLOAD_FILENAME,
      filename
    );
    let searchFilter, pagination;
    if (filterType === 'selected') {
      searchFilter = [
        {
          key: 'contentId',
          type: 'search',
          values: this.selecetedAssets.map((asset) => asset.contentId),
        },
      ];
    } else {
      searchFilter = this.lastPayload.filters;
      pagination = {
        limit: 5000,
        offset: 0,
      };
      const totalFilteredAssetsCount: number =
        Number(sessionStorage.getItem('allAssets')) ?? -1;
      if (totalFilteredAssetsCount > 500) {
        this.toastr.success(
          'The first 500 assets will be applicable for import changes'
        );
      }
    }
    const filterBody: FilterRequestBody = {
      filters: searchFilter,
      pagination: pagination,
    };

    //Saving Subscription Before returning to implement Cancellation
    return (this.excelExportService.currentExportSubscription =
      this.excelExportService
        .exportTemplatateToExcel(filterBody, filterType)
        .subscribe({
          next: (res) => {
            if (res) {
              this.downloadImportFile(res);

              this.toastr.success('Data is Exported Successfully');
            }
          },
          error: (error) => {
            this.toastr.error('Export Failed');
          },
        }));
  }
  downloadImportFile(data: any) {
    const blob = new Blob([data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const filename = this.storeService.getStoreState(
      STORE_CONSTS.EXCEL_DOWNLOAD_FILENAME
    );
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  downloadFile(data: any, fileName: string) {
    const url = window.URL.createObjectURL(new Blob([data]));
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  onLoadMore(e: any) {
    if (!this.bNoMoreData) {
      this.lastPayload = null;
      this.offsetIndex++;
      this.getAssets();
    }
  }

  openSortPanel() {
    const dialogRef = this.dialog.open(SortingPanelComponent, {
      panelClass: 'media-assets-sort-modal',
      position: { right: '0' },
      height: '100vh',
      enterAnimationDuration: '0ms',
      exitAnimationDuration: '0ms',
    });
  }

  handleImport() {
    this.downloadImport.decisionForImport();
  }

  ngOnDestroy() {
    this.columnsAndFilterData.setFilterSelection('productionStatus', []);
    this.columnsAndFilterData.setFilterSelection('qcStatus', []);
    this.columnsAndFilterData.setFilterSelection('allStatus', []);
  }
}
