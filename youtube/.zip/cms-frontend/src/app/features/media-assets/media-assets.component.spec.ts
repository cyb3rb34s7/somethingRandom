import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaAssetsComponent } from './media-assets.component';

describe('MediaAssetsComponent', () => {
  let component: MediaAssetsComponent;
  let fixture: ComponentFixture<MediaAssetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MediaAssetsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(MediaAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
