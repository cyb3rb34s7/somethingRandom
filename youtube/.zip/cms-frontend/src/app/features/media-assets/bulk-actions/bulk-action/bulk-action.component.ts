import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Output,
} from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Asset } from '../../../../models/asset-model';
import { MatDialog } from '@angular/material/dialog';
import { AssetService } from '../../../../services/asset.service';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { AssetsAddReasonModalComponent } from '../assets-add-reason-modal/assets-add-reason-modal.component';
import { AssetRevokeConfirmComponent } from '../asset-revoke-confirm/asset-revoke-confirm.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import staticJson from '../../../../../assets/AssetsStatusMapping.json';
import {
  cmsFeedWorkersList,
  deltaFeedWorkersList,
  feedWorkersList,
} from '../../assets-details/media-asset-complete-view/utils/asset-feedworker-util';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-bulk-action',
  imports: [MatFormFieldModule, MatButtonModule, MatMenuModule],
  templateUrl: './bulk-action.component.html',
  styleUrl: './bulk-action.component.scss',
})
export class BulkActionComponent {
  selectedAssets: Asset[];

  @Output() refreshRequired = new EventEmitter<void>();

  BulkActionsList: string[] = [];

  assetsStatusMapping: any;

  addedFromOtherFound: any;
  isBulkActionAllowed: boolean = false;
  private destroy = inject(DestroyRef);

  constructor(
    private storeService: StateStoreService,
    private assetService: AssetService,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.assetsStatusMapping = staticJson;

    this.storeService.stateStore[STORE_CONSTS.SELECTEDASSETS].subscribe(
      (assets: Asset[]) => {
        this.selectedAssets = assets;
        this.BulkActionsList =
          this.selectedAssets.length > 0
            ? this.getActionStatus()
            : this.BulkActionsList;
      }
    );
  }

  ngOnDestroy() {
    this.storeService.setStoreState(STORE_CONSTS.SELECTEDASSETS, []);
  }

  performBulkAction(bulkAction: any) {
    const payloadObj = {
      assetList: this.selectedAssets.map((d: any) => {
        return {
          contentId: d.contentId,
          countryCode: d.countryCode,
          vcCpId: d.vcCpId,
          seasonId: d.seasonId,
          showId: d.showId,
          type: d.type,
        };
      }),
      status: bulkAction,
    };

    if (bulkAction === 'Temp QC Pass') {
      this.openAddReason(payloadObj);
    } else if (bulkAction === 'Revoked') {
      this.openConfirmRevoke();
    } else {
      this.assetService
        .updateAssetsStatus(payloadObj)
        .pipe(takeUntilDestroyed(this.destroy))
        .subscribe((res) => {
          if (res) {
            this.refreshRequired.emit();
            this.storeService.setStoreState(
              STORE_CONSTS.BULK_ACTION_RESPONSE,
              res
            );
          }
        });
    }
  }

  getActionStatus() {
    this.addedFromOtherFound = this.selectedAssets.find(
      (asset: any) => asset.status === 'Untrackable'
    );

    const isAssetQCType: boolean = this.selectedAssets.every(
      (asset: any) =>
        cmsFeedWorkersList.includes(asset.feedWorker) ||
        (deltaFeedWorkersList.includes(asset.feedWorker) &&
          asset.deltaType === 'QC_SYNC')
    );
    const isAssetAutoQCType: boolean = this.selectedAssets.every(
      (asset: any) =>
        deltaFeedWorkersList.includes(asset.feedWorker) &&
        asset.deltaType === 'AUTO_SYNC'
    );

    const areAllAssetsReleased: boolean = this.selectedAssets.every(
      (asset: any) =>
        (asset.status === 'Released' || asset.status === 'Ready for Release') &&
        feedWorkersList.includes(asset.feedWorker)
    );
    this.isBulkActionAllowed =
      isAssetAutoQCType || isAssetQCType || areAllAssetsReleased;

    const possibleBulkActions: string[] = [];

    const jsonEntries = Object.entries(
      isAssetQCType || areAllAssetsReleased
        ? this.assetsStatusMapping.QC_SYNC
        : this.assetsStatusMapping.AUTO_SYNC
    );

    jsonEntries.forEach((e: any) => possibleBulkActions.push(e[0]));

    const statusChangeObj: any = [];

    possibleBulkActions.forEach((a: any) => {
      const currStatus: string[] = [];

      jsonEntries.forEach((v: any) => {
        if (v[1].includes(a)) currStatus.push(v[0]);
      });
      statusChangeObj.push({
        actionButton: a,
        currStatus: currStatus,
      });
    });

    const selectedAssetsCurrStatus: any = [];

    this.selectedAssets?.forEach((item: any) => {
      if (!selectedAssetsCurrStatus.includes(item.status)) {
        selectedAssetsCurrStatus.push(item.status);
      }
    });

    this.BulkActionsList = [];
    statusChangeObj.forEach((i: any) => {
      if (
        selectedAssetsCurrStatus.every((val: any) => i.currStatus.includes(val))
      )
        this.BulkActionsList.push(i.actionButton);
    });

    const isReleasedAsstets = this.selectedAssets.filter((f) => f.isReleased);
    if (
      isReleasedAsstets.length === this.selectedAssets.length &&
      !this.BulkActionsList.includes('Revoked')
    ) {
      this.BulkActionsList.push('Revoked');
    }

    return this.BulkActionsList;
  }

  openAddReason(payload: any) {
    const dialogRef = this.dialog.open(AssetsAddReasonModalComponent, {
      width: '600px',
      panelClass: 'media-assets-filter-modal',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        payload = { ...payload, qcPassReason: result };
        this.assetService
          .updateAssetsStatus(payload)
          .pipe(takeUntilDestroyed(this.destroy))
          .subscribe((res) => {
            if (res) {
              this.refreshRequired.emit();
              this.storeService.setStoreState(
                STORE_CONSTS.BULK_ACTION_RESPONSE,
                res
              );
            }
          });
      }
    });
  }

  openConfirmRevoke() {
    const payloadReq = this.selectedAssets.map((d: any) => {
      return {
        contentId: d.contentId,
        countryCode: d.countryCode,
        vcCpId: d.vcCpId,
        seasonId: d.seasonId,
        showId: d.showId,
        type: d.type,
      };
    });

    const dialogRef = this.dialog.open(AssetRevokeConfirmComponent, {
      width: '800px',
      data: payloadReq,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const updateStatusObj = {
          assetList: result.map((d: any) => {
            return {
              contentId: d.contentId,
              countryCode: d.countryCode,
              vcCpId: d.vcCpId,
              type: d.type,
              seasonId: d.seasonId,
              showId: d.showId,
            };
          }),
          status: 'Revoked',
        };
        this.assetService
          .updateAssetsStatus(updateStatusObj)
          .pipe(takeUntilDestroyed(this.destroy))
          .subscribe((res) => {
            if (res) {
              this.refreshRequired.emit();
              this.storeService.setStoreState(
                STORE_CONSTS.BULK_ACTION_RESPONSE,
                res
              );
            }
          });
      }
    });
  }
}
