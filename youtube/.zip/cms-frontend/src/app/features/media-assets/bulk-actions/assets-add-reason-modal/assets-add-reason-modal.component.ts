import { Component, Inject, NgModule, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../mat-components/app-mat-select/app-mat-select.component';
import { MatRadioGroupComponent } from '../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
// import { Filter } from '../../../../models/filter-model';
import { plainToInstance } from 'class-transformer';
import { MatCheckbox } from '@angular/material/checkbox';
import { AssetService } from '../../../../services/asset.service';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatCard, MatCardHeader, MatCardTitle } from '@angular/material/card';

@Component({
    selector: 'app-assets-add-reason-modal',
    imports: [
        MatDialogModule,
        MatButtonModule,
        MatExpansionModule,
        MatIconModule,
        FormsModule,
        CommonModule,
    ],
    templateUrl: './assets-add-reason-modal.component.html',
    styleUrl: './assets-add-reason-modal.component.scss'
})
export class AssetsAddReasonModalComponent {
  reason: string;
  constructor(
    public dialofRef: MatDialogRef<AssetsAddReasonModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  close(): void {
    this.dialofRef.close(this.reason);
  }
}
