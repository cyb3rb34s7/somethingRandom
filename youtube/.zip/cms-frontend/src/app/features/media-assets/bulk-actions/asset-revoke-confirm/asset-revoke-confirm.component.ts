import { Component, DestroyRef, Inject, inject } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AssetService } from '../../../../services/asset.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'app-asset-revoke-confirm',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './asset-revoke-confirm.component.html',
    styleUrl: './asset-revoke-confirm.component.scss'
})
export class AssetRevokeConfirmComponent {
  private destroy = inject(DestroyRef);

  processedData: [];

  hiearchyResponse: any;

  constructor(
    private assetService: AssetService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialofRef: MatDialogRef<AssetRevokeConfirmComponent>
  ) {}

  ngOnInit(): void {
    this.assetService
      .getAssetsToRevokeHierarchy(this.data)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (resp: any) => {
          if (resp) {
            this.hiearchyResponse = resp;
          }
        },
        error: (error: HttpErrorResponse) => {
          this.dialofRef.close();
          console.log('====Error===', error);
        },
      });
  }

  close(): void {
    this.dialofRef.close(this.hiearchyResponse);
  }
}
