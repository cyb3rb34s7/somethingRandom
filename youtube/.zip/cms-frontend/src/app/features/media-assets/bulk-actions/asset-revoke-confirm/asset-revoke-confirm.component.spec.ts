import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetRevokeConfirmComponent } from './asset-revoke-confirm.component';

describe('AssetRevokeConfirmComponent', () => {
  let component: AssetRevokeConfirmComponent;
  let fixture: ComponentFixture<AssetRevokeConfirmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetRevokeConfirmComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AssetRevokeConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
