import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsAddReasonModalComponent } from './assets-add-reason-modal.component';

describe('AssetsAddReasonModalComponent', () => {
  let component: AssetsAddReasonModalComponent;
  let fixture: ComponentFixture<AssetsAddReasonModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetsAddReasonModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AssetsAddReasonModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
