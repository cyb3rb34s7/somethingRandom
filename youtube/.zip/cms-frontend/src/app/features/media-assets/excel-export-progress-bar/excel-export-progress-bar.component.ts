import { Component, OnDestroy, OnInit } from '@angular/core';
import { StateStoreService } from '../../../services/store/state-store.service';
import { AssetExcelExportService } from '../../../services/asset-excel-export.service';
import { interval, map, Subject, takeUntil } from 'rxjs';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'app-excel-export-progress-bar',
    imports: [CommonModule, FormsModule],
    templateUrl: './excel-export-progress-bar.component.html',
    styleUrl: './excel-export-progress-bar.component.scss'
})
export class ExcelExportProgressBarComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  isDownloading = false;
  progress = 0;
  fileName = '';
  downloadState = '';
  constructor(
    private stateStore: StateStoreService,
    private exportService: AssetExcelExportService
  ) {}

  ngOnInit(): void {
    this.subscribeToStoreChanges();
    this.downloadState = this.stateStore.getStoreState(
      STORE_CONSTS.EXCEL_DOWNLOAD_STATE
    );
  }

  private subscribeToStoreChanges() {
    interval(100)
      .pipe(
        takeUntil(this.destroy$),
        map(() => ({
          isDownloading: this.stateStore.getStoreState(
            STORE_CONSTS.IS_EXCEL_DOWNLOADING
          ),
          progress: this.stateStore.getStoreState(
            STORE_CONSTS.EXCEL_DOWNLOAD_PROGRESS
          ),
          fileName: this.stateStore.getStoreState(
            STORE_CONSTS.EXCEL_DOWNLOAD_FILENAME
          ),
          downloadState: this.stateStore.getStoreState(
            STORE_CONSTS.EXCEL_DOWNLOAD_STATE
          ),
        }))
      )
      .subscribe((state) => {
        this.isDownloading = state.isDownloading;
        this.progress = state.progress;
        this.fileName = state.fileName;
        this.downloadState = state.downloadState;
      });
  }
  cancelDownload() {
    this.exportService.cancelExcelExport();
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
