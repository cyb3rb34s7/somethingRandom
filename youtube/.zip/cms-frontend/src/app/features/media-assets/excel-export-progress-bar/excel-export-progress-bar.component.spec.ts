import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcelExportProgressBarComponent } from './excel-export-progress-bar.component';

describe('ExcelExportProgressBarComponent', () => {
  let component: ExcelExportProgressBarComponent;
  let fixture: ComponentFixture<ExcelExportProgressBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ExcelExportProgressBarComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ExcelExportProgressBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
