import { Directive, OnInit, Renderer2, Input, ElementRef } from '@angular/core';

const SESSION_KEY = 'asset-table-data';
@Directive({
  selector: '[resizeColumn]',
  standalone: true,
})
export class ResizeColumnDirective implements OnInit {
  @Input('resizeColumn') resizable: boolean;

  @Input() index: number;

  private startX: number;

  private startWidth: number;

  private column: HTMLElement;

  private pressed: boolean;

  private originalWidth: number = 185;

  constructor(private renderer: Renderer2, private el: ElementRef) {
    this.column = this.el.nativeElement;
  }

  ngOnInit() {
    if (this.resizable) {
      const resizer = this.renderer.createElement('i');
      this.renderer.addClass(resizer, 'bi');
      this.renderer.addClass(resizer, 'bi-arrows-expand-vertical');
      this.renderer.addClass(resizer, 'resize-holder');
      this.renderer.insertBefore(this.column, resizer, this.column.firstChild);
      this.renderer.listen(resizer, 'mousedown', this.onMouseDown);
    }
  }

  ngAfterViewInit() {
    const currentWidth = this.column.offsetWidth;
    if (this.originalWidth > currentWidth) {
      this.renderer.setStyle(this.column, 'width', '185px');
    }
    const isData: any = sessionStorage.getItem(SESSION_KEY);
    const colWidths = isData ? JSON.parse(isData).colWidths : null;
    if (isData && colWidths) {
      const name = this.column.getAttribute('name');
      if (name && colWidths[name]) {
        this.renderer.setStyle(
          this.column,
          'min-width',
          `${colWidths[name]}px`
        );
        this.renderer.setStyle(this.column, 'width', `${colWidths[name]}px`);
      }
    }
  }

  onMouseDown = (event: MouseEvent) => {
    this.pressed = true;
    this.startX = event.pageX;
    this.startWidth = this.column.offsetWidth;

    this.renderer.listen('document', 'mousemove', this.onMouseMove);
    this.renderer.listen('document', 'mouseup', this.onMouseUp);
  };

  onMouseMove = (event: MouseEvent) => {
    if (this.pressed && event.buttons) {
      this.renderer.addClass(this.column, 'select-none');
      // Calculate width of column

      let width = this.startWidth + (event.pageX - this.startX);

      if (width < 185) {
        width = 185;
      } else if (width > 600) {
        width = 600;
      }
      // Set table header width
      this.renderer.setStyle(this.column, 'min-width', `${width}px`);
      this.renderer.setStyle(this.column, 'width', `${width}px`);
    }
  };

  onMouseUp = (event: MouseEvent) => {
    if (this.pressed) {
      this.pressed = false;
      const isData: any = sessionStorage.getItem(SESSION_KEY);
      let obj: any = {};
      if (isData && JSON.parse(isData).colWidths) {
        obj = { ...JSON.parse(isData).colWidths };
      }
      obj[this.column.getAttribute('name')!] = this.column.offsetWidth;
      this.setSessionData({ colWidths: obj });
    }
    this.renderer.removeClass(this.column, 'select-none');
  };

  setSessionData(data: any) {
    let _data = sessionStorage.getItem(SESSION_KEY);
    _data = _data ? JSON.parse(_data) : {};
    _data = { ...(_data as Object), ...data };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(_data));
  }
}
