import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsFilterModalBaseComponent } from './assets-filter-modal-base.component';

describe('AssetsFilterModalBaseComponent', () => {
  let component: AssetsFilterModalBaseComponent;
  let fixture: ComponentFixture<AssetsFilterModalBaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetsFilterModalBaseComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AssetsFilterModalBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
