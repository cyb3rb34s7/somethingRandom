import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Output,
} from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import {
  FilterTemplate,
  UserFilterTemplates,
} from '../../../../models/filter-templates-model';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FilterTemplateUtilService } from '../../../../services/filter-template-util.service';
import { CustomToastrService } from '../../../../services/custom-toastr.service';

@Component({
    selector: 'app-saved-templates-list',
    imports: [MatDialogModule, AppMatSimpleSearchComponent, MatTooltipModule],
    templateUrl: './saved-templates-list.component.html',
    styleUrl: './saved-templates-list.component.scss'
})
export class SavedTemplatesPanelComponent {
  private destroy = inject(DestroyRef);

  userFilterTemplates: UserFilterTemplates;

  arrTemplates: FilterTemplate[] = [];

  @Output() changePanelDisplay = new EventEmitter<{
    index: number;
    template?: FilterTemplate;
    edit?: boolean;
  }>();

  constructor(
    private storeService: StateStoreService,
    public dialogRef: MatDialogRef<SavedTemplatesPanelComponent>,
    private templateUtils: FilterTemplateUtilService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {
    this.getUserTemplatesFromStorage();
  }

  getUserTemplatesFromStorage() {
    this.storeService.stateStore[STORE_CONSTS.USER_FILTER_TEMPLATES]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: UserFilterTemplates) => {
        this.userFilterTemplates = obj;
        this.arrTemplates = [...this.userFilterTemplates.userTemplates];
      });
  }

  handleTemplateSearch(value: string) {
    if (value) {
      this.arrTemplates = this.arrTemplates.filter((d: FilterTemplate) => {
        const searchIn = d.templateName.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
    } else {
      this.arrTemplates = [...this.userFilterTemplates.userTemplates];
    }
  }

  setTemplateForPreview(currTemplate: FilterTemplate) {
    this.changePanelDisplay.emit({ index: 2, template: currTemplate });
  }

  showFiltersPanel() {
    this.changePanelDisplay.emit({ index: 0 });
  }

  handleAction(event: Event, action: string, template: FilterTemplate) {
    event.stopImmediatePropagation();
    switch (action) {
      case 'apply':
        template.templateId &&
          this.templateUtils.applyFilterTemplate(template.filters);
        this.storeService.setStoreState(
          STORE_CONSTS.APPLIED_FILTER_TEMPLATE,
          template.templateId
        );
        break;
      case 'edit':
        this.changePanelDisplay.emit({
          index: 2,
          template: template,
          edit: true,
        });
        break;
      case 'delete':
        template.templateId &&
          this.openDeleteTemplateModal(template.templateId);
        break;
    }
  }

  openDeleteTemplateModal(id: number) {
    this.templateUtils.openDeleteTemplateModal(id);
  }
}
