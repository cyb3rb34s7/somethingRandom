import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAssetsColumnModalComponent } from './app-assets-column-modal.component';

describe('AppAssetsColumnModalComponent', () => {
  let component: AppAssetsColumnModalComponent;
  let fixture: ComponentFixture<AppAssetsColumnModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppAssetsColumnModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AppAssetsColumnModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
