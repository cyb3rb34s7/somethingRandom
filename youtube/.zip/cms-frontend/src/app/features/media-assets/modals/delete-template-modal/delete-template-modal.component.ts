import { Component, DestroyRef, Inject, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AssetService } from '../../../../services/asset.service';
import { CustomToastrService } from '../../../../services/custom-toastr.service';

@Component({
    selector: 'app-delete-template-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './delete-template-modal.component.html',
    styleUrl: './delete-template-modal.component.scss'
})
export class DeleteTemplateModalComponent {
  private destroy = inject(DestroyRef);
  templateId: number;

  constructor(
    public dialogRef: MatDialogRef<DeleteTemplateModalComponent>,
    private assetService: AssetService,
    private toastr: CustomToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.templateId = data.id;
  }

  deleteTemplate() {
    this.assetService
      .deleteFilterTemplate(this.templateId)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.data.cb();
        this.dialogRef.close(true);
      });
  }
}
