import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardHeader, MatCardTitle } from '@angular/material/card';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialogModule,
} from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';

@Component({
    selector: 'app-app-assets-reason-modal',
    imports: [
        MatDialogModule,
        MatButtonModule,
        MatExpansionModule,
        MatIconModule,
        CommonModule,
    ],
    templateUrl: './app-assets-reason-modal.component.html',
    styleUrl: './app-assets-reason-modal.component.scss'
})
export class AppAssetsReasonModalComponent {
  reason: String;
  constructor(
    public dialofRef: MatDialogRef<AppAssetsReasonModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.reason = data;
  }

  close(): void {
    this.dialofRef.close();
  }
}
