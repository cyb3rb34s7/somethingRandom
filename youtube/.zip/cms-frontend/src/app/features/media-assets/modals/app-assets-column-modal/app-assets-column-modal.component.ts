import { Component, DestroyRef, HostListener, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../mat-components/app-mat-select/app-mat-select.component';
import { MatRadioGroupComponent } from '../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatCheckbox } from '@angular/material/checkbox';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { StateStoreService } from '../../../../services/store/state-store.service';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Column,
} from '../../../../models/assets-columns-filters-model';
import { instanceToPlain, plainToInstance } from 'class-transformer';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  CdkDragDrop,
  CdkDrag,
  CdkDropList,
  moveItemInArray,
  CdkDragHandle,
} from '@angular/cdk/drag-drop';
import { UserService } from '../../../../services/user.service';

const SESSION_KEY = 'asset-table-data';
@Component({
    selector: 'app-app-assets-column-modal',
    imports: [
        MatDialogModule,
        MatButtonModule,
        AppMatSimpleSearchComponent,
        MatExpansionModule,
        MatIconModule,
        FormsModule,
        MatCheckbox,
        CommonModule,
        CdkDropList,
        CdkDrag,
        CdkDragHandle,
    ],
    templateUrl: './app-assets-column-modal.component.html',
    styleUrl: './app-assets-column-modal.component.scss'
})
export class AppAssetsColumnModalComponent {
  private destroy = inject(DestroyRef);

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  slideIn: boolean = false;

  searchText: any;

  bReordering: boolean;

  lastOrder: string[];

  originalPref: string;

  constructor(
    public dialogRef: MatDialogRef<AppAssetsColumnModalComponent>,
    private storeService: StateStoreService,
    private userService: UserService
  ) {
    this.dialogRef
      .afterOpened()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((s) => {
        this.slideIn = true;
      });
  }

  ngOnInit() {
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        const plain = instanceToPlain(obj);
        this.columnsAndFilterData = plainToInstance(
          AssetColumnsAndFiltersAndFilterTemplates,
          plain
        );

        this.arrangeAsLastSorted();
        this.originalPref = JSON.stringify(
          instanceToPlain(this.columnsAndFilterData)
        );
      });
  }

  arrangeAsLastSorted() {
    const isData = sessionStorage.getItem(SESSION_KEY);
    if (isData) {
      const { columnOrder } = JSON.parse(isData);
      if (columnOrder) {
        const columns = this.columnsAndFilterData.columns.map((c) => c);

        this.columnsAndFilterData.columns = [];
        columnOrder.forEach(
          (c: string) =>
            (this.columnsAndFilterData.columns = [
              ...this.columnsAndFilterData.columns,
              columns.find((_c) => _c.name === c)!,
            ])
        );
        this.columnsAndFilterData.columns =
          this.columnsAndFilterData.columns.filter((c) => c);
        columns.forEach((c) => {
          const found = this.columnsAndFilterData.columns.find(
            (_c) => _c.name === c.name
          );
          if (!found) {
            this.columnsAndFilterData.columns = [
              ...this.columnsAndFilterData.columns,
              c,
            ];
          }
        });

        if (!this.lastOrder) {
          this.lastOrder = this.columnsAndFilterData.columns.map((c) => c.name);
        }
      } else {
        this.resetToOriginalOrder();
      }
    } else {
      this.resetToOriginalOrder();
    }
  }

  applySelection() {
    const isPrefChanged =
      JSON.stringify(instanceToPlain(this.columnsAndFilterData)) !==
      this.originalPref;
    this.setSessionData({
      columnOrder: this.columnsAndFilterData.columns.map((c) => c.name),
      columnSelected: this.columnsAndFilterData.columns
        .filter((c) => c.selected)
        .map((c) => c.name),
    });
    this.storeService.setStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
      this.columnsAndFilterData
    );
    const data = {
      columnOrder: this.columnsAndFilterData.columns.map((c) => c.name),
      columnSelected: this.columnsAndFilterData.columns
        .filter((c) => c.selected)
        .map((c) => c.name),
    };

    if (isPrefChanged) {
      this.userService
        .updateUserAssetPreference(JSON.stringify(data))
        .subscribe({
          next: () => {
            console.log('------------------');
            this.dialogRef.close();
          },
          error: () => {},
        });
    } else {
      // this.dialogRef.close();
    }
  }

  drop(event: CdkDragDrop<any[]>) {
    moveItemInArray(
      this.columnsAndFilterData.columns,
      event.previousIndex,
      event.currentIndex
    );
  }

  setSessionData(data: any) {
    let _data = sessionStorage.getItem(SESSION_KEY);
    _data = _data ? JSON.parse(_data) : {};
    _data = { ...(_data as Object), ...data };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(_data));
  }

  resetToOriginalOrder() {
    this.setSessionData({
      columnOrder: this.columnsAndFilterData.columnOrder,
    });
    this.arrangeAsLastSorted();
  }

  handleCancel() {
    if (this.lastOrder) {
      this.setSessionData({
        columnOrder: this.lastOrder,
      });
      this.arrangeAsLastSorted();
    }
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.applySelection();
    }
  }
}
