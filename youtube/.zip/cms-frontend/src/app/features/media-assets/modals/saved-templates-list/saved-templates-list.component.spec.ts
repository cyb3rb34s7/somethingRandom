import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavedTemplatesPanelComponent } from './saved-templates-list.component';

describe('SavedTemplatesPanelComponent', () => {
  let component: SavedTemplatesPanelComponent;
  let fixture: ComponentFixture<SavedTemplatesPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SavedTemplatesPanelComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SavedTemplatesPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
