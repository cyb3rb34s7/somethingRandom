import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AppMatSimpleSearchComponent } from '../../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatCheckbox, MatCheckboxChange } from '@angular/material/checkbox';
import { MatButton } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Item } from '../../../../../interfaces/sort-panel-item';

@Component({
  selector: 'app-sort-selection',
  imports: [
    CommonModule,
    AppMatSimpleSearchComponent,
    MatCheckbox,
    MatButton,
    MatTooltipModule,
  ],
  templateUrl: './sort-selection.component.html',
  styleUrl: './sort-selection.component.scss',
})
export class SortSelectionComponent {
  @Input() list: Item[] = [];

  @Output() onSelection: EventEmitter<any> = new EventEmitter();

  bListOpen: boolean;

  searchTxt: string;

  selected: Item[] = [];

  handleSelection(item: Item) {
    const found = this.selected.find(
      (_item: Item) => _item.field === item.field
    );
    this.selected = found
      ? this.selected.filter((_item) => _item.field !== item.field)
      : [...this.selected, item];
  }

  handleSelectAll(e: MatCheckboxChange) {
    this.selected =
      this.selected.length !== this.list.length ? [...this.list] : [];
  }

  reset() {
    // this.selected = this.selected.map((obj: Item) => {
    //   obj.order = '';
    //   return obj;
    // });
    this.selected = [];
  }

  select() {
    this.onSelection.emit([...this.selected]);
    this.selected = [];
  }
}
