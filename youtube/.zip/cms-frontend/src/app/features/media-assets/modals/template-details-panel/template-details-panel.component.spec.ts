import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateDetailsPanelComponent } from './template-details-panel.component';

describe('TemplateDetailsPanelComponent', () => {
  let component: TemplateDetailsPanelComponent;
  let fixture: ComponentFixture<TemplateDetailsPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemplateDetailsPanelComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TemplateDetailsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
