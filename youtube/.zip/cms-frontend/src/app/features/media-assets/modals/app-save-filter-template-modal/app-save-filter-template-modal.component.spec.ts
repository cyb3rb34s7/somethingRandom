import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppSaveFilterTemplateModalComponent } from './app-save-filter-template-modal.component';

describe('AppSaveFilterTemplateModalComponent', () => {
  let component: AppSaveFilterTemplateModalComponent;
  let fixture: ComponentFixture<AppSaveFilterTemplateModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppSaveFilterTemplateModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AppSaveFilterTemplateModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
