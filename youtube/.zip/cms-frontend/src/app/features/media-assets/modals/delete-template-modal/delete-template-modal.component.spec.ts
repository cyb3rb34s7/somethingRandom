import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteTemplateModalComponent } from './delete-template-modal.component';

describe('DeleteTemplateModalComponent', () => {
  let component: DeleteTemplateModalComponent;
  let fixture: ComponentFixture<DeleteTemplateModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteTemplateModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteTemplateModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
