import {
  Component,
  DestroyRef,
  ElementRef,
  EventEmitter,
  HostListener,
  inject,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import {
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppAssetsFilterModalComponent } from '../app-assets-filter-modal/app-assets-filter-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatExpansionModule } from '@angular/material/expansion';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatButtonModule } from '@angular/material/button';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../mat-components/app-mat-select/app-mat-select.component';
import { MatRadioGroupComponent } from '../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { MatCheckbox } from '@angular/material/checkbox';
import { CommonModule } from '@angular/common';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { AppSaveFilterTemplateModalComponent } from '../app-save-filter-template-modal/app-save-filter-template-modal.component';
import { AssetService } from '../../../../services/asset.service';
import { FilterTemplate } from '../../../../models/filter-templates-model';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../../../models/assets-columns-filters-model';
import { plainToInstance } from 'class-transformer';
import { CustomToastrService } from '../../../../services/custom-toastr.service';
import { EllipsesLengthDirective } from '../../../../directives/ellipses-length.directive';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule } from '@angular/forms';
import { MatCard, MatCardHeader, MatCardTitle } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

import { DateRangeSelectorComponent } from '../../../../components/date-range-selector/date-range-selector.component';
import { FilterTemplateUtilService } from '../../../../services/filter-template-util.service';
import { MatTooltip } from '@angular/material/tooltip';
import { BehaviorSubject } from 'rxjs';

@Component({
    selector: 'app-template-details-panel',
    imports: [
        MatDialogModule,
        AppMatInputComponent,
        MatButtonModule,
        AppMatSimpleSearchComponent,
        MatExpansionModule,
        MatIconModule,
        FormsModule,
        MatCheckbox,
        CommonModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatNativeDateModule,
        MatDatepickerModule,
        FormsModule,
        EllipsesLengthDirective,
        DateRangeSelectorComponent,
        MatTooltip,
    ],
    templateUrl: './template-details-panel.component.html',
    styleUrl: './template-details-panel.component.scss'
})
export class TemplateDetailsPanelComponent {
  private destroy = inject(DestroyRef);

  @Input() currTemplate: FilterTemplate;

  @Input() editMode: boolean;

  @Output() changePanelDisplay = new EventEmitter<{ index: number }>();

  @ViewChild('accord') $accordian: ElementRef;

  slideIn: boolean = false;

  searchText: any;

  withInFilterSearches: any = {};

  appliedFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  templateFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  region: string;

  countryPanelOpenState = false;

  expandedFiltersMap: any = {};

  bDisabledSaveNew: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<TemplateDetailsPanelComponent>,
    private storeService: StateStoreService,
    private assetService: AssetService,
    public dialog: MatDialog,
    private toastr: CustomToastrService,
    private templateUtils: FilterTemplateUtilService
  ) {}

  ngOnInit() {
    this.templateFilterData = plainToInstance<
      AssetColumnsAndFiltersAndFilterTemplates,
      {}
    >(AssetColumnsAndFiltersAndFilterTemplates, { ...this.currTemplate });
    this.templateUtils.placeSavedCountriesOnTop(
      this.templateFilterData.filters.find((f) => f.key === 'countryCode')
    );
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        if (!obj.filtersMerged) {
          this.templateUtils.fetchFilters();
          // this.appliedFilterData = instanceToInstance(obj);
        } else if (this.editMode) {
          this.templateFilterData.filters =
            this.templateUtils.getOrderedFiltersForEdit(
              this.templateFilterData.filters
            );
        }
      });

    this.region = this.storeService.getStoreState(STORE_CONSTS.REGION);
  }

  ngAfterViewInit() {
    this.fixLicenseStatusFilter();
  }

  fixLicenseStatusFilter() {
    setTimeout(() => {
      const $rangePanel = this.$accordian.nativeElement.querySelector(
        '#licenseStatusRange'
      ) as HTMLElement;

      const $rangePanelFlds = this.$accordian.nativeElement.querySelector(
        '#licenseStatusRange app-date-range-selector'
      ) as HTMLElement;

      const $statusPanelTarget = this.$accordian.nativeElement.querySelector(
        '#licenseStatus .items'
      ) as HTMLElement;

      if ($statusPanelTarget && $rangePanelFlds) {
        $statusPanelTarget.appendChild($rangePanelFlds);
      }
      if ($rangePanel) {
        $rangePanel.classList.add('disappear');
      }
    }, 1000);
  }

  showSavedTemplatesList() {
    // 0 -> Apply filters, 1 -> show All templates, 2 -> template details
    this.changePanelDisplay.emit({ index: 1 });
  }

  validateInput(event: any, filter: Filter) {
    const regexExp: RegExp = new RegExp(filter.regex);
    if (regexExp.test(event.value)) {
      return event.value;
    } else if (event.value === '') {
      return '';
    } else {
      event.value = filter.selected[0] ? filter.selected[0] : '';
      return filter.selected[0] ? filter.selected[0] : '';
    }
  }

  handleDateRange(date: any, dateRange: String, f: Filter) {
    if (dateRange === 'dateFrom') {
      f.selected[0] = date.value;
      f.selected[1] = f.selected[1] ? f.selected[1] : '';
    }
    if (dateRange === 'dateTo') {
      f.selected[0] = f.selected[0] ? f.selected[0] : '';
      f.selected[1] = date.value;
    }
  }

  delete() {
    this.templateUtils.openDeleteTemplateModal(this.currTemplate.templateId!);
    this.changePanelDisplay.emit({ index: 1 });
  }

  edit() {
    this.editMode = true;
    this.templateFilterData.filters =
      this.templateUtils.getOrderedFiltersForEdit(
        this.templateFilterData.filters
      );

    this.fixLicenseStatusFilter();
  }

  applyFilter() {
    this.templateUtils.applyFilterTemplate(this.templateFilterData.filters);
    this.storeService.setStoreState(
      STORE_CONSTS.APPLIED_FILTER_TEMPLATE,
      this.currTemplate.templateId
    );
  }

  reset() {
    this.withInFilterSearches = {};
    this.templateFilterData.filters = this.templateFilterData.filters.map(
      (f) => {
        f.selected = [];
        return f;
      }
    );
  }

  saveNew() {
    const dialogRef = this.dialog.open(AppSaveFilterTemplateModalComponent, {
      data: this.templateFilterData.filters.filter((f) => f.selected.length),
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        result && this.templateUtils.fetchUserTemplates();
        this.changePanelDisplay.emit({ index: 1 });
      });
  }

  saveAndApply() {
    if (this.bDisabledSaveNew) {
      this.applyFilter();
      this.dialogRef.close();
      return;
    }

    this.currTemplate.templateJson = JSON.stringify(
      this.templateFilterData.filters.filter((f) => f.selected.length)
    );

    this.assetService
      .saveFilterTemplate(this.currTemplate)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.templateUtils.fetchUserTemplates();
        this.applyFilter();
        this.dialogRef.close();
      });
  }

  checkSaveNewState() {
    const filters = this.templateFilterData.filters.filter(
      (f) => f.selected.length
    );
    this.bDisabledSaveNew =
      JSON.stringify(this.currTemplate.filters) === JSON.stringify(filters) ||
      filters.length === 0;
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.applyFilter();
    }
  }
}
