import {
  Component,
  DestroyRef,
  ElementRef,
  EventEmitter,
  HostListener,
  inject,
  Output,
  ViewChild,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  instanceToInstance,
  instanceToPlain,
  plainToInstance,
} from 'class-transformer';
import { MatCheckbox } from '@angular/material/checkbox';
import { AssetService } from '../../../../services/asset.service';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  AssetColumnsAndFiltersAndFilterTemplates,
  Filter,
} from '../../../../models/assets-columns-filters-model';
import { AppSaveFilterTemplateModalComponent } from '../app-save-filter-template-modal/app-save-filter-template-modal.component';
import {
  FilterTemplate,
  UserFilterTemplates,
} from '../../../../models/filter-templates-model';
import {
  MatNativeDateModule,
  provideNativeDateAdapter,
} from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { EllipsesDirective } from '../../../../mat-components/app-mat-table/ellipses.directive';
import { MatTooltipModule } from '@angular/material/tooltip';

import { DateRangeSelectorComponent } from '../../../../components/date-range-selector/date-range-selector.component';
import { FilterTemplateUtilService } from '../../../../services/filter-template-util.service';

@Component({
    selector: 'app-assets-filter-modal',
    imports: [
        MatDialogModule,
        AppMatInputComponent,
        MatButtonModule,
        AppMatSimpleSearchComponent,
        MatExpansionModule,
        MatIconModule,
        FormsModule,
        MatCheckbox,
        CommonModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatNativeDateModule,
        MatDatepickerModule,
        FormsModule,
        EllipsesDirective,
        MatTooltipModule,
        DateRangeSelectorComponent,
    ],
    providers: [provideNativeDateAdapter()],
    templateUrl: './app-assets-filter-modal.component.html',
    styleUrl: './app-assets-filter-modal.component.scss'
})
export class AppAssetsFilterModalComponent {
  private destroy = inject(DestroyRef);

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  columnsAndFilterDataBackup: AssetColumnsAndFiltersAndFilterTemplates;

  userFilterTemplates: UserFilterTemplates;

  searchText: any;

  withInFilterSearches: any = {};

  region: string;

  countryPanelOpenState = false;

  expandedFiltersMap: any = {};

  @Output() changePanelDisplay = new EventEmitter<{ index: number }>();

  @ViewChild('accord') $accordian: ElementRef;

  constructor(
    private storeService: StateStoreService,
    private templateUtils: FilterTemplateUtilService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AppAssetsFilterModalComponent>
  ) {}

  ngOnInit() {
    this.storeService.stateStore[
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: AssetColumnsAndFiltersAndFilterTemplates) => {
        const plain = instanceToPlain(obj);
        this.columnsAndFilterData = plainToInstance(
          AssetColumnsAndFiltersAndFilterTemplates,
          plain
        );
        if (this.columnsAndFilterData.filtersMerged) {
          let selected = this.columnsAndFilterData.filters.filter(
            (f) => f.selected.length
          );
          let unselected = this.columnsAndFilterData.filters.filter(
            (f) => !f.selected.length
          );
          this.columnsAndFilterData.filters = [...selected, ...unselected];
          // this.columnsAndFilterData.filters =
          //   this.templateUtils.placePreferredCountriesOnTop(
          //     this.columnsAndFilterData.filters
          //   );

          this.templateUtils.placeSavedCountriesOnTop(
            this.columnsAndFilterData.filters.find(
              (f) => f.key === 'countryCode'
            )
          );

          this.columnsAndFilterDataBackup = instanceToInstance(
            this.columnsAndFilterData
          );
        }
      });

    this.storeService.stateStore[STORE_CONSTS.USER_FILTER_TEMPLATES]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((obj: UserFilterTemplates) => {
        this.userFilterTemplates = obj;
      });

    if (!this.columnsAndFilterData.filtersMerged) {
      this.templateUtils.fetchFilters();
    }

    this.region = this.storeService.getStoreState(STORE_CONSTS.REGION);
  }

  ngAfterViewInit() {
    this.waitUntilFound();
  }

  waitUntilFound() {
    if (this.$accordian) {
      this.setupLicenseWindowAssetFilter();
    } else {
      setTimeout(() => {
        this.waitUntilFound();
      }, 1000);
    }
  }

  setupLicenseWindowAssetFilter() {
    const $rangePanel = this.$accordian.nativeElement.querySelector(
      '#licenseStatusRange'
    ) as HTMLElement;

    const $rangePanelFlds = this.$accordian.nativeElement.querySelector(
      '#licenseStatusRange app-date-range-selector'
    ) as HTMLElement;

    const $statusPanelTarget = this.$accordian.nativeElement.querySelector(
      '#licenseStatus .items'
    ) as HTMLElement;

    if ($statusPanelTarget && $rangePanelFlds) {
      $statusPanelTarget.appendChild($rangePanelFlds);
    }
    if ($rangePanel) {
      $rangePanel.classList.add('disappear');
    }
  }

  launchSavedTemplatesPanel() {
    this.changePanelDisplay.emit({ index: 1 });
  }

  reset() {
    this.withInFilterSearches = {};
    this.columnsAndFilterData.filters.forEach(
      (f) => (f.changeSelectAll = false)
    );
    this.columnsAndFilterData.setFilterSelection('allStatus', []);
    this.columnsAndFilterData.setFilterSelection('qcStatus', []);
    this.columnsAndFilterData.setFilterSelection('productionStatus', []);
    if (sessionStorage.getItem('assets-last-tab') === '1') {
      this.columnsAndFilterData.setFilterSelection('qcStatus', [
        'QC in Progress',
        'QC Pass',
        'QC Fail',
      ]);
    } else if (sessionStorage.getItem('assets-last-tab') === '2') {
      this.columnsAndFilterData.setFilterSelection('productionStatus', [
        'Released',
      ]);
    }

    const currentUser = this.storeService.getStoreState(
      STORE_CONSTS.CURRENT_USER
    );
    const currentRegion = sessionStorage.getItem('User-Pref-Region');
    const codes =
      currentRegion === 'EU'
        ? currentUser.prefEUCountryCodes
        : currentUser.prefUSCountryCodes;
    const targetFilter = this.columnsAndFilterData.filters.find(
      (f) => f.key === 'countryCode'
    );
    if (targetFilter) {
      targetFilter.selected = [...codes];
    }
    this.storeService.setStoreState(STORE_CONSTS.APPLIED_FILTER_TEMPLATE, -1);
  }

  saveAsTemplate() {
    const dialogRef = this.dialog.open(AppSaveFilterTemplateModalComponent, {
      data: [...this.columnsAndFilterData.filters],
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        result && this.templateUtils.fetchUserTemplates();
      });
  }

  handleDateRange(date: any, dateRange: String, f: Filter) {
    if (dateRange === 'dateFrom') {
      f.selected[0] = date.value;
      f.selected[1] = f.selected[1] ? f.selected[1] : '';
    }
    if (dateRange === 'dateTo') {
      f.selected[0] = f.selected[0] ? f.selected[0] : '';
      f.selected[1] = date.value;
    }
  }

  validateInput(event: any, filter: Filter) {
    const regexExp: RegExp = new RegExp(filter.regex);
    if (regexExp.test(event.value)) {
      return event.value;
    } else if (event.value === '') {
      return '';
    } else {
      event.value = filter.selected[0] ? filter.selected[0] : '';
      return filter.selected[0] ? filter.selected[0] : '';
    }
  }

  applyFilter() {
    const jsonStrCurr = JSON.stringify(
      instanceToPlain(this.columnsAndFilterData.filters)
    );
    const jsonStrBcup = JSON.stringify(
      instanceToPlain(this.columnsAndFilterDataBackup.filters)
    );
    if (jsonStrCurr !== jsonStrBcup) {
      this.columnsAndFilterData.filterChanged = true;
      this.storeService.setStoreState(
        STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
        this.columnsAndFilterData
      );
      this.dialogRef.close();
    }
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.applyFilter();
      // this.dialogRef.close(); // Add your logic here
    }
  }
}
