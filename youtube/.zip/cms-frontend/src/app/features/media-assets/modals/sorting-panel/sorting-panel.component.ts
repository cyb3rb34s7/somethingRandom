import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { AssetColumnsAndFiltersAndFilterTemplates } from '../../../../models/assets-columns-filters-model';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { SortOrderComponent } from './sort-order/sort-order.component';
import { SortSelectionComponent } from './sort-selection/sort-selection.component';
import { Item } from '../../../../interfaces/sort-panel-item';

@Component({
  selector: 'app-sorting-panel',
  imports: [
    MatDialogModule,
    MatButtonModule,
    SortOrderComponent,
    SortSelectionComponent,
  ],
  templateUrl: './sorting-panel.component.html',
  styleUrl: './sorting-panel.component.scss',
})
export class SortingPanelComponent {
  private destroy = inject(DestroyRef);

  @ViewChild(SortSelectionComponent) sortingSelComp!: SortSelectionComponent;

  slideIn: boolean = false;

  columnsAndFilterData: AssetColumnsAndFiltersAndFilterTemplates;

  selectableArr: Item[] = [];

  selectedArr: Item[] = [];

  bApplyDisabled: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<SortingPanelComponent>,
    private storeService: StateStoreService
  ) {
    this.dialogRef
      .afterOpened()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((s) => {
        this.slideIn = true;
      });
  }

  setApplyState() {
    const old = sessionStorage.getItem('assets-sorting');
    if (!old) {
      if (this.selectedArr.length === 0) {
        this.bApplyDisabled = true;
      } else if (this.selectedArr.some((_s) => _s.order.length)) {
        this.bApplyDisabled = false;
      }
    } else {
      if (this.selectedArr.length === 0) {
        this.bApplyDisabled = false;
      } else if (this.selectedArr.some((_s) => _s.order.length)) {
        if (JSON.stringify(this.selectedArr) !== old) {
          this.bApplyDisabled = false;
        } else {
          this.bApplyDisabled = true;
        }
      } else {
        this.bApplyDisabled = true;
      }
    }
  }

  ngOnInit() {
    this.columnsAndFilterData = this.storeService.getStoreState(
      STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
    ) as AssetColumnsAndFiltersAndFilterTemplates;

    const savedInSession = sessionStorage.getItem('assets-sorting');
    const arrSortBy = savedInSession ? JSON.parse(savedInSession) : [];
    this.selectedArr = arrSortBy.length ? [...arrSortBy] : [];
    this.selectableArr = [];
    this.setSelectable();
    this.setApplyState();
  }

  setSelectable() {
    const columns = this.columnsAndFilterData.columns.map((c) => c);
    this.selectableArr = [];
    columns.forEach((c) => {
      const found = this.selectedArr.find((obj: Item) => obj.field === c.key);
      if (!found && c.type) {
        this.selectableArr = [
          ...this.selectableArr,
          {
            field: c.key,
            name: c.name,
            order: '',
            type: c.type,
          },
        ];
      }
    });
  }

  handleSelection(e: Item[]) {
    this.selectedArr = [...this.selectedArr, ...e];
    this.setSelectable();
    this.setApplyState();
  }

  mutateSelection(obj: any) {
    const targetIndex = this.selectedArr.findIndex(
      (item) => item.field === obj.old
    );
    const newItem = this.selectableArr.find((item) => item.field === obj.new);
    if (newItem) {
      this.selectedArr[targetIndex] = newItem;
      this.setSelectable();
      this.setApplyState();
    }
  }

  remove(item: Item) {
    this.selectedArr = this.selectedArr.filter(
      (_item) => _item.field !== item.field
    );
    this.setSelectable();
    this.setApplyState();
  }

  apply() {
    if (this.selectedArr.length) {
      sessionStorage.setItem(
        'assets-sorting',
        JSON.stringify(this.selectedArr)
      );
    } else {
      sessionStorage.removeItem('assets-sorting');
    }

    this.storeService.setStoreState(STORE_CONSTS.SORTING_CHANGED, true);
  }

  reset() {
    this.selectedArr = this.selectedArr.map((obj: any) => {
      const nObj = { ...obj, order: '' };
      return nObj;
    });
    this.bApplyDisabled = true;
    this.setApplyState();
  }

  removeAll() {
    this.reset();
    this.selectedArr.forEach((obj) => this.remove(obj));
    this.setApplyState();
  }
}
