import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAssetsReasonModalComponent } from './app-assets-reason-modal.component';

describe('AppAssetsReasonModalComponent', () => {
  let component: AppAssetsReasonModalComponent;
  let fixture: ComponentFixture<AppAssetsReasonModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppAssetsReasonModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AppAssetsReasonModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
