import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAssetsFilterModalComponent } from './app-assets-filter-modal.component';

describe('AppAssetsFilterModalComponent', () => {
  let component: AppAssetsFilterModalComponent;
  let fixture: ComponentFixture<AppAssetsFilterModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppAssetsFilterModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AppAssetsFilterModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
