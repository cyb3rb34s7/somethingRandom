import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortOrderChildComponent } from './sort-order-child.component';

describe('SortOrderChildComponent', () => {
  let component: SortOrderChildComponent;
  let fixture: ComponentFixture<SortOrderChildComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SortOrderChildComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SortOrderChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
