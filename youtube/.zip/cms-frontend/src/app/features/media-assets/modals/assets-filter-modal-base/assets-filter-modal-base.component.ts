import { Component, DestroyRef, Inject, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { SavedTemplatesPanelComponent } from '../saved-templates-list/saved-templates-list.component';
import { TemplateDetailsPanelComponent } from '../template-details-panel/template-details-panel.component';
import { AppAssetsFilterModalComponent } from '../app-assets-filter-modal/app-assets-filter-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FilterTemplate } from '../../../../models/filter-templates-model';

@Component({
    selector: 'app-assets-filter-modal-base',
    imports: [
        AppAssetsFilterModalComponent,
        SavedTemplatesPanelComponent,
        TemplateDetailsPanelComponent,
    ],
    templateUrl: './assets-filter-modal-base.component.html',
    styleUrl: './assets-filter-modal-base.component.scss'
})
export class AssetsFilterModalBaseComponent {
  private destroy = inject(DestroyRef);

  filterPanelIndex: number;

  slideIn: boolean = false;

  selectedTemplate: FilterTemplate;

  bEditMode: boolean;

  constructor(
    public dialogRef: MatDialogRef<AssetsFilterModalBaseComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.filterPanelIndex = data.bOpenList ? 1 : 0;
  }

  changeFilterPanelIndex(data: any) {
    this.filterPanelIndex = data.index;
    this.selectedTemplate = data.template;
    this.bEditMode = data.edit;
  }

  ngOnInit() {
    this.dialogRef
      .afterOpened()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((_) => {
        this.slideIn = true;
      });

    this.dialogRef
      .beforeClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((_) => {
        this.slideIn = false;
      });
  }
}
