import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import {
  CdkDragDrop,
  CdkDrag,
  CdkDropList,
  moveItemInArray,
  CdkDragHandle,
} from '@angular/cdk/drag-drop';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Item } from '../../../../../interfaces/sort-panel-item';
import { SortOrderChildComponent } from './sort-order-child/sort-order-child.component';

@Component({
  selector: 'app-sort-order',
  imports: [
    CdkDropList,
    CdkDrag,
    CdkDragHandle,
    MatInputModule,
    MatSelectModule,
    SortOrderChildComponent,
  ],
  templateUrl: './sort-order.component.html',
  styleUrl: './sort-order.component.scss',
})
export class SortOrderComponent {
  @Input() list: Item[] = [];

  @Input() selectable: Item[] = [];

  @Output() onRemove: EventEmitter<Item> = new EventEmitter();

  @Output() onMutation: EventEmitter<any> = new EventEmitter();

  @Output() orderSet: EventEmitter<any> = new EventEmitter();

  ngOnInit() {}

  drop(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.list, event.previousIndex, event.currentIndex);
  }

  remove(item: Item) {
    this.onRemove.emit(item);
  }

  mutateChild(obj: any) {
    this.onMutation.emit(obj);
  }
}
