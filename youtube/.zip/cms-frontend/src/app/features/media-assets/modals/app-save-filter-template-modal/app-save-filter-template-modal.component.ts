import {
  Component,
  DestroyRef,
  HostListener,
  inject,
  Inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { AssetService } from '../../../../services/asset.service';
import { Filter } from '../../../../models/assets-columns-filters-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FilterTemplate } from '../../../../models/filter-templates-model';
import { CustomToastrService } from '../../../../services/custom-toastr.service';

@Component({
    selector: 'app-app-assets-filter-template-modal',
    imports: [MatDialogModule, AppMatInputComponent, MatButtonModule],
    templateUrl: './app-save-filter-template-modal.component.html',
    styleUrl: './app-save-filter-template-modal.component.scss'
})
export class AppSaveFilterTemplateModalComponent {
  private destroy = inject(DestroyRef);
  filterTemplate: FilterTemplate;

  constructor(
    public dialogRef: MatDialogRef<AppSaveFilterTemplateModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Filter[],
    private assetService: AssetService,
    private toastr: CustomToastrService
  ) {
    this.filterTemplate = new FilterTemplate();
    this.filterTemplate.templateJson = JSON.stringify(
      data.filter((f) => f.selected.length)
    );
    this.filterTemplate.templateName = '';
  }

  save(): void {
    this.assetService
      .saveFilterTemplate(this.filterTemplate)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.save();
    }
  }
}
