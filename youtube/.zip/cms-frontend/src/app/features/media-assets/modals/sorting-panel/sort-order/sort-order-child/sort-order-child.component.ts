import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Item } from '../../../../../../interfaces/sort-panel-item';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-sort-order-child',
  imports: [
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  templateUrl: './sort-order-child.component.html',
  styleUrl: './sort-order-child.component.scss',
})
export class SortOrderChildComponent {
  private _items: Item[];

  @Input()
  set items(arr: Item[]) {
    this._items = arr;
    this.totalItems = [this.selectedItem, ...arr];
  }

  get items(): Item[] {
    return this._items;
  }

  private _selectedItem: Item;

  @Input()
  set selectedItem(newValue: Item) {
    this._selectedItem = newValue;
    this.totalItems = [newValue, ...this.items];
    this.initSelectedItemOrder();
  }

  get selectedItem(): Item {
    return this._selectedItem;
  }

  @Output() updateOrder: EventEmitter<string> = new EventEmitter();

  @Output() onItemChange: EventEmitter<{ old: string; new: string }> =
    new EventEmitter();

  totalItems: Item[] = [];

  directions: string[];

  direction = new FormControl('');

  initSelectedItemOrder() {
    switch (this.selectedItem.type) {
      case 'numeric':
        this.directions = ['0-9', '9-0'];
        break;
      case 'alphabetic':
        this.directions = ['A-Z', 'Z-A'];
        break;
      case 'date':
        this.directions = ['Oldest', 'Earliest'];
        break;
    }
    if (this.selectedItem.order) {
      if (this.selectedItem.order === 'DESC') {
        this.direction.setValue(this.directions[1]);
      } else if (this.selectedItem.order === 'ASC') {
        this.direction.setValue(this.directions[0]);
      }
    } else {
      this.direction.setValue('');
    }
  }

  onSelectionChange(field: string) {
    this.selectedItem.order = '';
    this.onItemChange.emit({ old: this.selectedItem.field, new: field });
  }
  ngOnInit() {
    this.direction.valueChanges.subscribe((v) => {
      if (v) {
        this.onOrderChange(v);
      }
    });
  }

  onOrderChange(val: string) {
    switch (val) {
      case '0-9':
      case 'A-Z':
      case 'Oldest':
        this.selectedItem.order = 'ASC';
        break;
      default:
        this.selectedItem.order = 'DESC';
    }
    this.updateOrder.emit(this.selectedItem.order);
  }
}
