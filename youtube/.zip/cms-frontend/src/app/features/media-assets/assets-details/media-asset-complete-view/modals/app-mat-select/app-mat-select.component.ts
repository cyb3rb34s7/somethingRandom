import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  ElementRef,
  EventEmitter,
  inject,
  input,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { AppMatSimpleSearchComponent } from '../../../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-mat-select',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    AppMatSimpleSearchComponent,
    CommonModule,
  ],
  templateUrl: './app-mat-select.component.html',
  styleUrl: './app-mat-select.component.scss',
})
export class AppMatSelectComponent implements OnChanges {
  private destroy = inject(DestroyRef);
  @Input() label: string;
  @Input() allowMultiple: boolean;
  @Input() isMandatory: boolean;
  @Input() isSearchable: boolean;
  @Input() items: any[];
  @Input() value: string | string[];
  @Input() initVal: string;
  @Input() disabled: boolean;
  @Input() name: string;
  @Input() placeholder: string = '';
  @Input() rightLabel: string = '';
  @ViewChild('tag') selectEl: MatSelect;
  private changeDetectorRef = inject(ChangeDetectorRef);
  constructor() {}

  @Output() currentValue: EventEmitter<string | any> = new EventEmitter();

  searchString: string;

  filteredItems: any[];

  selectFormControl: FormControl = new FormControl({
    value: null,
    disabled: true,
  });

  fg: FormGroup = new FormGroup({
    selectFormControl: this.selectFormControl,
  });
  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }
  private valueChangeInProgress = false;
  ngOnInit(): void {
    setTimeout(() => {
      this.filteredItems = this.items;

      if (!this.disabled) {
        this.fg.get('selectFormControl')?.enable();
      }
      if (this.value) {
        this.fg.setValue({ selectFormControl: this.value });
      }
      if (this.initVal) {
        this.fg.setValue({ selectFormControl: this.initVal });
      }
      if (this.isMandatory) {
        this.selectFormControl.addValidators(Validators.required);
      }

      this.selectFormControl.valueChanges
        .pipe(takeUntilDestroyed(this.destroy))
        .subscribe((inp) => {
          if (this.valueChangeInProgress) return;
          this.valueChangeInProgress = true;
          try {
            if (
              this.isMandatory &&
              (inp === null ||
                inp === '' ||
                (Array.isArray(inp) && inp.length === 0))
            ) {
              this.selectFormControl.setErrors({ required: true });
              this.selectFormControl.setValue(null);
              const obj = {
                name: this.name,
                valid: !this.selectFormControl.invalid,
                value: null,
              };

              if (this.name) {
                this.currentValue.emit(obj);
              } else {
                this.currentValue.emit(inp);
              }
            } else if (
              this.areValuesDifferent(this.value, inp) &&
              !this.allowMultiple
            ) {
              const obj = {
                name: this.name,
                valid: !this.selectFormControl.invalid,
                value: inp,
              };

              if (this.name) {
                this.currentValue.emit(obj);
              } else {
                this.currentValue.emit(inp);
              }
            } else if (this.allowMultiple && typeof this.value !== 'string') {
              const ob1 = this.value?.join(',');
              const ob2 = inp?.join(',');
              if (ob1 !== ob2) {
                const obj = {
                  name: this.name,
                  valid: !this.selectFormControl.invalid,
                  value: inp,
                };

                if (this.name) {
                  this.currentValue.emit(obj);
                } else {
                  this.currentValue.emit(inp);
                }
              }
            }
          } finally {
            this.valueChangeInProgress = false;
          }
        });
    }, 500);
  }

  emptySelection() {
    // this.fg.setValue({ selectFormControl: '' });
    if (this.isMandatory) {
      // Set to null to trigger required validator
      this.selectFormControl.setValue(null);
      this.selectFormControl.markAsTouched();
    } else {
      this.selectFormControl.setValue('');
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.disabled) {
      this.fg.get('selectFormControl')?.enable();
    } else {
      this.fg.get('selectFormControl')?.disable();
    }
    if (this.value && this.selectFormControl.value != this.value) {
      this.selectFormControl.setValue(this.value);
    }
    if (this.value === '') {
      this.selectFormControl.setValue(undefined);
    }

    if (this.items) {
      if (this.searchString) {
        this.handleSearch(this.searchString);
      } else {
        this.filteredItems = this.items;
      }
    }
  }

  handleSearch(value: string) {
    if (value) {
      this.searchString = value;
      this.filteredItems = this.items.filter((d: string) => {
        const searchIn = d.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
    } else {
      this.searchString = '';
      this.filteredItems = this.items;
    }
  }

  triggerElement(): void {
    this.selectFormControl.markAsTouched();
    
    if (this.isMandatory && (!this.selectFormControl.value || this.selectFormControl.value === '')) {
      this.selectFormControl.setErrors({ required: true });
    }
    
    this.changeDetectorRef.detectChanges();
  }
  
  noCompareFunc() {
    return 0;
  }
  areValuesDifferent(
    str1: string | string[] | null | undefined,
    str2: string | string[] | null | undefined,
    options: { trimStrings?: boolean } = {}
  ): boolean {
    const { trimStrings = false } = options;

    const normalize = (
      value: string | string[] | null | undefined
    ): string | null => {
      if (!value) return null;

      if (Array.isArray(value)) {
        const filtered = value.filter((v) => v != null);
        const joined = filtered
          .map((v) => {
            const str = String(v);
            return trimStrings ? str.trim() : str;
          })
          .join(',');
        return trimStrings ? joined.trim() : joined;
      }

      const str = String(value);
      return trimStrings ? str.trim() : str;
    };

    return normalize(str1) !== normalize(str2);
  }
}
