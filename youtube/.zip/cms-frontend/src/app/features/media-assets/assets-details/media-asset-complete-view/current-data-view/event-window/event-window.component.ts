import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Input,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { CustomDatetimePickerComponent } from '../../custom-datetime-picker/custom-datetime-picker.component';
import { NoRecordFoundComponent } from '../../no-record-found/no-record-found.component';
import { MatDialog } from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';
import { AssetHelperService } from '../../utils/asset-helper.service';
import { v4 as randomString } from 'uuid';
import { AssetEventWindowModel } from '../../../../../../models/asset-event-window-model';
import { LowerCasePipe } from '../../../../../../pipes/lower-case.pipe';
import { NormalizeCasePipe } from '../../../../../../pipes/normalize-case.pipe';
import { MatButton } from '@angular/material/button';

@Component({
  selector: 'app-event-window',
  imports: [
    CustomDatetimePickerComponent,
    NoRecordFoundComponent,
    LowerCasePipe,
    NormalizeCasePipe,
    LowerCasePipe,
    MatButton,
  ],
  templateUrl: './event-window.component.html',
  styleUrl: './event-window.component.scss',
})
export class EventWindowComponent {
  private destroy = inject(DestroyRef);
  constructor(
    public assetHelperService: AssetHelperService,
    public dialog: MatDialog,
    private toaster: CustomToastrService
  ) {}

  @Input() disabled: boolean = false;
  @Input() eventWindow: AssetEventWindowModel[] | any[] = [];
  @Output() currentValue = new EventEmitter<any>();
  @Input() currentWindowItem: number = 0;

  @ViewChildren('datePickers', { read: CustomDatetimePickerComponent })
  matInputs: QueryList<CustomDatetimePickerComponent>;
  
  eventCount: number = 0;
  windowButton: string[] = ['All', 'Active', 'Upcoming', 'Expired'];
  eventWindowcopy: AssetEventWindowModel[] | any[] = [];
  ngOnInit() {
    if (!this.eventWindow) this.eventWindow = [];
    this.eventWindow.sort((a, b) => {
      const startDateComp = a.eventStarting.localeCompare(b.eventEnding);
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.eventEnding.localeCompare(b.eventEnding);
    });

    const now = new Date(); // Current date and time

    this.eventWindow = this.eventWindow.map((window: AssetEventWindowModel) => {
      const start = new Date(window.eventStarting);
      const end = new Date(window.eventEnding);

      if (now >= start && now <= end) {
        return { ...window, status: 'ACTIVE' };
      } else if (now > end) {
        return { ...window, status: 'EXPIRED' };
      } else {
        return { ...window, status: 'UPCOMING' };
      }
    });
    this.eventCount = this.eventWindow.length;
    this.eventWindowcopy = [...this.eventWindow];
  }

  scollToInvalidField() {
    this.assetHelperService.scrollToInvalidField();
  }

  onDeleteClick(idx: number) {
    this.eventWindowcopy.splice(idx, 1);
    this.emitChanges();
  }

  emitChanges() {
    this.currentValue.emit({
      name: 'eventWindowList',
      valid: true,
      eventWindowList: [...this.eventWindowcopy],
      changed: true,
    });
  }

  getRandomLicenseId() {
    const ob = randomString() + '-CMS';
    return ob;
  }

  visibilityCheck(index: number) {
    if (this.currentWindowItem === 0) {
      this.eventCount = this.eventWindowcopy.length;
      return false;
    }
    this.eventCount = this.eventWindowcopy.filter(
      (item) =>
        item.status?.toLowerCase() ===
        this.windowButton[this.currentWindowItem].toLowerCase()
    ).length;
    if (
      this.eventWindowcopy[index].status?.toLowerCase() ===
      this.windowButton[this.currentWindowItem].toLowerCase()
    ) {
      return false;
    } else {
      return true;
    }
  }

  onDateChange(evt: { date: Date; value: string }, index: number, key: string) {
    this.eventWindowcopy[index][key] =
      evt.value ?? this.eventWindowcopy[index][key];
    this.emitChanges();
  }

  addEmptyEventWindowSlot() {
    this.eventWindowcopy.push({
      eventEnding: '',
      eventStarting: '',
      eventId: this.getRandomLicenseId(),
    } as AssetEventWindowModel);
  }

  triggerValidation() {
    this.matInputs.forEach(input => input.triggerElement());
  }
}
