import { Component } from '@angular/core';
import { LicenseHistoryComponent } from "../../../change-history/license-history/license-history.component";
import { ActivatedRoute, Route, Router } from '@angular/router';
import { MatButton } from '@angular/material/button';
import { Location } from '@angular/common';

@Component({
    selector: 'app-single-asset-license-history',
    imports: [LicenseHistoryComponent, MatButton],
    templateUrl: './single-asset-license-history.component.html',
    styleUrl: './single-asset-license-history.component.scss'
})
export class SingleAssetLicenseHistoryComponent {
  title:string|null;
  assetId:string;
  vodType:string|null;
  constructor(private route:ActivatedRoute,private location:Location){}

  ngOnInit(){
    this.assetId=this.route.snapshot.queryParams["assetId"];
    this.title=sessionStorage.getItem('mainTitle');
    this.vodType=sessionStorage.getItem('vodType');
  }
  onBackClick(){
    this.location.back();
  }

}
