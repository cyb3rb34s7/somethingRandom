import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentalRatingsComponent } from './parental-ratings.component';

describe('ParentalRatingsComponent', () => {
  let component: ParentalRatingsComponent;
  let fixture: ComponentFixture<ParentalRatingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParentalRatingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParentalRatingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
