import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiImageViewEditModalComponent } from './multi-image-view-edit-modal.component';

describe('MultiImageViewEditModalComponent', () => {
  let component: MultiImageViewEditModalComponent;
  let fixture: ComponentFixture<MultiImageViewEditModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MultiImageViewEditModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MultiImageViewEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
