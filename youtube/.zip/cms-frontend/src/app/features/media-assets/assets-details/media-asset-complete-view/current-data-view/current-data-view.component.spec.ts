import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentDataViewComponent } from './current-data-view.component';

describe('CurrentDataViewComponent', () => {
  let component: CurrentDataViewComponent;
  let fixture: ComponentFixture<CurrentDataViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CurrentDataViewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CurrentDataViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
