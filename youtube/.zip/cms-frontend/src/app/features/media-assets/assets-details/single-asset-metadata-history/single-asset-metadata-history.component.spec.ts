import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleAssetMetadataHistoryComponent } from './single-asset-metadata-history.component';

describe('SingleAssetMetadataHistoryComponent', () => {
  let component: SingleAssetMetadataHistoryComponent;
  let fixture: ComponentFixture<SingleAssetMetadataHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SingleAssetMetadataHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SingleAssetMetadataHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
