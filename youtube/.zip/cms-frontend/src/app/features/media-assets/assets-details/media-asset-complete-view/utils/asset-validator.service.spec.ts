import { TestBed } from '@angular/core/testing';

import { AssetValidatorService } from './asset-validator.service';

describe('AssetValidatorService', () => {
  let service: AssetValidatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetValidatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
