import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppMatSelectComponent } from './app-mat-select.component';

describe('AppMatSelectComponent', () => {
  let component: AppMatSelectComponent;
  let fixture: ComponentFixture<AppMatSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppMatSelectComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AppMatSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
