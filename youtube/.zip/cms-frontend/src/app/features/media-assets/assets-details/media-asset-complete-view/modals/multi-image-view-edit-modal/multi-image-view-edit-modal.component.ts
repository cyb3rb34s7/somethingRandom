import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  ElementRef,
  inject,
  Inject,
  ViewChild,
} from '@angular/core';
import { MatButton } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AssetService } from '../../../../../../services/asset.service';
import { CommonModule } from '@angular/common';

import { MatInputModule } from '@angular/material/input';
import { FormsModule, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';

import { MatTooltip } from '@angular/material/tooltip';
import { allImageObj } from '../../../../../../models/asset-images-model';
import { MatCheckbox, MatCheckboxChange } from '@angular/material/checkbox';
import { isGracenoteFeedWorker } from '../../utils/asset-feedworker-util';

@Component({
  selector: 'app-multi-images-view-edit-modal',
  imports: [
    MatDialogModule,
    MatButton,
    CommonModule,
    FormsModule,
    MatInputModule,
    MatTooltip,
    MatCheckbox,
  ],
  templateUrl: './multi-image-view-edit-modal.component.html',
  styleUrls: [
    './multi-image-view-edit-modal.component.scss',
    './multi-image-view-edit-modal.new.component.scss',
  ],
})
export class MultiImageViewEditModalComponent {
  allImageData: allImageObj = {
    landscapeImages: [],
    landscapeIconicImages: [],
    portraitImages: [],
    portraitIconicImages: [],
    portraitBackdropImages: [],
    titleTreatmentImages: [],
    landscapeBackdropImages: [],
  };

  allImagesRenderData: { [key: string]: any[] } = {
    landscapeImages: [],
    landscapeIconicImages: [],
    portraitImages: [],
    portraitIconicImages: [],
    portraitBackdropImages: [],
    titleTreatmentImages: [],
    landscapeBackdropImages: [],
  };

  maxImages: number = 5;

  defaultImages: { [key: string]: number } = {
    landscapeImages: 0,
    landscapeIconicImages: 0,
    portraitImages: 0,
    portraitIconicImages: 0,
    titleTreatmentImages: 0,
    portraitBackdropImages: 0,
    landscapeBackdropImages: 0,
  };

  private destroy = inject(DestroyRef);
  inputFormControl = new FormControl({ value: '', disabled: false });
  constructor(
    public dialogRef: MatDialogRef<MultiImageViewEditModalComponent>,
    @Inject(MAT_DIALOG_DATA) public images: any,
    private assetService: AssetService,
    private toastr: CustomToastrService,

    private cdref: ChangeDetectorRef
  ) {}
  @ViewChild('input') inp: ElementRef;
  file: HTMLElement | null;
  editing: boolean = this.images['editMode'];
  formData: FormData = new FormData();
  notEditable: string[] = this.images['notEditable'];
  deletedImage: string[] = [];
  validObj: any;
  isGracenote: boolean = this.images['gracenote'] ?? false;

  defaultImagesCount: { [key: string]: number } = {
    landscapeImages: 0,
    portraitImages: 0,
    landscapeIconicImages: 0,
    portraitIconicImages: 0,
    portraitBackdropImages: 0,
    landscapeBackdropImages: 0,
    titleTreatmentImages: 0,
  };

  imageTypesHeaders: {
    name: string;
    label: string;
    type: string;
    key: string;
    processedKey: string;
    count: number;
    values: string;
    dimensionName: string;
  }[] = [
    {
      name: 'landscapeImageBanner',
      label: 'Landscape Banner (16:9)',
      type: 'landscape',
      key: 'imageLandscapeOriginal',
      processedKey: 'imageLandscape',
      count: this.allImageData.landscapeImages.length,
      values: 'landscapeImages',
      dimensionName: 'imageLandscapeDimension',
    },
    {
      name: 'portraitImageBanner',
      label: 'Portrait Banner (2:3)',
      type: 'portrait',
      key: 'imagePortraitOriginal',
      processedKey: 'imagePortrait',
      count: this.allImageData.portraitImages.length,
      values: 'portraitImages',
      dimensionName: 'imagePortraitDimension',
    },
    {
      name: 'landscapeImageIconic',
      label: 'Landscape Iconic (16:9)',
      key: 'imageLandscapeIconicOriginal',
      processedKey: 'imageLandscapeIconic',
      type: 'landscape',
      count: this.allImageData.landscapeIconicImages.length,
      dimensionName: 'imageLandscapeIconicDimension',
      values: 'landscapeIconicImages',
    },
    {
      name: 'portraitImageIconic',
      label: 'Portrait Iconic (2:3)',
      type: 'portrait',
      key: 'imagePortraitIconicOriginal',
      processedKey: 'imagePortraitIconic',
      count: this.allImageData.portraitIconicImages.length,
      dimensionName: 'imagePortraitIconicDimension',
      values: 'portraitIconicImages',
    },
    {
      name: 'landscapeImageBackdrop',
      label: 'Backdrop (16:9)',
      key: 'imageLandscapeBackdropOriginal',
      processedKey: 'imageLandscapeBackdrop',
      type: 'landscape',
      count: this.allImageData.landscapeBackdropImages.length,
      dimensionName: 'imageLandscapeBackdropDimension',
      values: 'landscapeBackdropImages',
    },
    {
      name: 'titleTreatment',
      label: 'Title Treatment',
      type: 'landscape',
      key: 'imageTitleTreatmentOriginal',
      processedKey: 'imageTitleTreatment',
      count: this.allImageData.titleTreatmentImages.length,
      dimensionName: 'imageTitleTreatmentDimension',
      values: 'titleTreatmentImages',
    },
  ];

  ngOnInit() {
    this.loadImages();
    this.formData.append('countryCode', this.images['countryCode']);
    this.formData.append('providerId', this.images['vcCpId']);
    this.formData.append('programId', this.images['contentId']);
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  updateCount(index: number, count: any) {
    this.imageTypesHeaders[index].count = count;
  }
  showCount() {
    for (let i = 0; i < this.imageTypesHeaders.length; i++) {
      this.updateCount(
        i,
        this.allImageData[this.imageTypesHeaders[i].values as keyof allImageObj]
          .length
      );
    }

    for (let item of this.images.assetImageList) {
      if (item.isDefault === 'Y') {
        this.defaultImagesCount[imageTypeDBMapping[item.imageType]] = 1;
      }
    }
  }

  loadImages() {
    this.images.assetImageList.forEach((file: any) => {
      const mappedType: string = imageTypeDBMapping[file.imageType];

      if (mappedType && this.allImageData[mappedType as keyof allImageObj]) {
        this.allImageData[mappedType as keyof allImageObj].push({
          imageUrl: file.imageUrlOriginal,
          processedImageUrl: file.imageUrlProcessed,
          default: file.isDefault,
          imgDimension: file.imgDimension,
        });
      }
    });

    this.showCount();

    this.allImagesRenderData = Object.fromEntries(
      Object.entries(this.allImageData).map(([key, arr]) => [
        key,
        arr.map((item: any) => ({
          ...item,
          loading: false,
          deletable:
            item.default === 'Y' &&
            (key === 'landscapeImages' ||
              (key === 'portraitImages' && this.images['type'] === 'MOVIE'))
              ? false
              : true,
        })),
      ])
    ) as any;

    for (const key in this.allImagesRenderData) {
      if (Array.isArray(this.allImagesRenderData[key])) {
        this.defaultImages[key] = this.allImagesRenderData[key].findIndex(
          (item) => item.default === 'Y'
        );
      }
    }
  }

  onFileSelected(event: Event, item: any, headerIndex: number) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      this.validObj = this.validateImageAspectRatio(file, item.type);
      this.validObj.subscribe((obj: any) => {
        if (!obj.valid) {
          this.toastr.warn('Invalid Image Format');
        } else {
          const reader = new FileReader();
          this.allImagesRenderData[item.values].push({
            default: 'N',
            imageUrl: null,
            loading: true,
            processedImageUrl: null,
            deletable: true,
            imgDimension: null,
          });
          this.imageTypesHeaders[headerIndex].count =
            this.imageTypesHeaders[headerIndex].count + 1;
          let index = this.allImagesRenderData[item.values].length;

          this.onSaveSingleImage(item.values, file, index - 1, obj.dimension);
          reader.onload = (e) => {
            item.image = e.target?.result;
            if (this.formData.has(item.name + 'File')) {
              this.formData.set(item.name + 'File', file);
            } else {
              this.formData.append(item.name + 'File', file);
            }
            this.images[item.dimensionName] = obj.dimension;
          };
          reader.readAsDataURL(file);
        }
      });

      input.value = '';
    } else {
      item.image = null;
    }
  }

  onFileSelectedToEdit(event: Event, item: any, imageIndex: number) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      this.validObj = this.validateImageAspectRatio(file, item.type);
      this.validObj.subscribe((obj: any) => {
        if (!obj.valid) {
          this.toastr.warn('Invalid Image Format');
        } else {
          const reader = new FileReader();
          this.allImagesRenderData[item.values][imageIndex] = {
            default: this.allImagesRenderData[item.values][imageIndex].default,
            imageUrl:
              this.allImagesRenderData[item.values][imageIndex].imageUrl,
            loading: true,
            processedImageUrl:
              this.allImagesRenderData[item.values][imageIndex]
                .processedImageUrl,
            deletable:
              this.allImagesRenderData[item.values][imageIndex].deletable,
          };

          this.onSaveSingleImage(
            item.values,

            file,
            imageIndex,
            obj.dimension
          );
          reader.onload = (e) => {
            item.image = e.target?.result;
            if (this.formData.has(item.name + 'File')) {
              this.formData.set(item.name + 'File', file);
            } else {
              this.formData.append(item.name + 'File', file);
            }
            this.images[item.dimensionName] = obj.dimension;
          };
          reader.readAsDataURL(file);
        }
      });

      input.value = '';
    } else {
      item.image = null;
    }
  }
  validateImageAspectRatio(file: File, type: String): Subject<any> {
    const img = new Image();
    const reader = new FileReader();
    const valid = new Subject<{ valid: boolean; dimension: string }>();
    reader.onload = (e: any) => {
      img.src = e.target.result;
      img.onload = () => {
        const width = img.width;
        const height = img.height;
        const aspectRatio = width / height;
        const landscapeAspectRatio = 16 / 9;
        const portraitAspectRatio = 2 / 3;
        const circleAspectRatio = 1;

        if (type === 'landscape') {
          valid.next({
            valid:
              Math.abs(aspectRatio - landscapeAspectRatio) <= 0.05 &&
              width >= 928 &&
              height >= 522,
            dimension: `${width}_${height}`,
          });
        } else if (type === 'portrait') {
          valid.next({
            valid:
              Math.abs(aspectRatio - portraitAspectRatio) <= 0.05 &&
              width >= 348 &&
              height >= 522,
            dimension: `${width}_${height}`,
          });
        } else {
          valid.next({
            valid:
              Math.abs(aspectRatio - circleAspectRatio) <= 0.05 &&
              width >= 250 &&
              height >= 250,
            dimension: `${width}_${height}`,
          });
        }
      };
    };
    reader.readAsDataURL(file);

    return valid;
  }

  editImage(item: any, itemtype?: any, index?: number) {
    if (itemtype) {
      this.file = document.getElementById(itemtype.name + index + 'edit');

      this.file?.click();
    } else {
      this.file = document.getElementById(item.name);

      this.file?.click();
    }
  }

  onSaveSingleImage(
    name: string,
    file: File,
    index: number,
    dimension: string
  ) {
    let formData = new FormData();
    formData.append('countryCode', this.images['countryCode']);
    formData.append('providerId', this.images['vcCpId']);
    formData.append('programId', this.images['contentId']);
    formData.append('imageFile', file);

    this.assetService.postSingleImageFile(formData).subscribe({
      next: (res: any) => {
        this.allImagesRenderData[name][index].imageUrl =
          res['originalImageUrl'];
        this.allImagesRenderData[name][index].processedImageUrl =
          res['processedImageUrl'];
        this.allImagesRenderData[name][index].loading = false;
        this.allImagesRenderData[name][index].imgDimension = dimension;
      },
      error: (error) => {
        this.allImagesRenderData[name][index].loading = false;
      },
    });
  }

  onSave() {
    this.images['saved'] = true;
    this.images['deleted'] = this.deletedImage;
    for (let header of this.imageTypesHeaders) {
      if (
        this.defaultImages[header['values']] === -1 &&
        this.images[header['key']] &&
        this.images[header['processedKey']]
      ) {
        this.deletedImage.push(header.key);
        this.deletedImage.push(header.key.substring(0, header.key.length - 8));
        this.deletedImage.push(header.dimensionName);
      }
      this.images[header['key']] =
        this.defaultImages[header['values']] !== -1
          ? this.allImagesRenderData[header['values']][
              this.defaultImages[header['values']]
            ].imageUrl
          : undefined;

      this.images[header['processedKey']] =
        this.defaultImages[header['values']] !== -1
          ? this.allImagesRenderData[header['values']][
              this.defaultImages[header['values']]
            ].processedImageUrl
          : undefined;

      this.images[header['dimensionName']] =
        this.defaultImages[header['values']] !== -1
          ? this.allImagesRenderData[header['values']][
              this.defaultImages[header['values']]
            ].imgDimension
          : undefined;
    }

    this.preapreImageData();
  }

  preapreImageData() {
    let result: any[] = [];
    for (const imageType of this.imageTypesHeaders) {
      const images = this.allImagesRenderData[imageType.values];

      for (const img of images) {
        result.push({
          contentId: this.images['contentId'],
          providerId: this.images['vcCpId'],
          countryCode: this.images['countryCode'],
          imageUrlOriginal: img['imageUrl'],
          imageUrlProcessed: img['processedImageUrl'],
          imageType: imageTypeResultMapping[imageType['values']],
          isDefault: img['default'],
          imgDimension: img['imgDimension'],
        });
      }
    }

    result = result.filter(
      (item: any) =>
        item.imageUrlOriginal !== null || item.imageUrlProcessed !== null
    );

    this.images['assetImageList'] = result;
    this.dialogRef.close(this.images);
  }

  openDetailedView(item: any) {
    if (this.editing) {
      this.openDetailedViewImage(item);
    }
  }
  openDetailedViewImage(image: any) {
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`
        <html>
        <body style="margin:0;display:flex;justify-content:center;align-items:center;height:100vh">
         <img style="max-height:100%;max-width:100%"
        src="${this.isGracenote ? image.processedImageUrl : image.imageUrl}"
      />
        </body>
        </html>
        `);
      newWindow?.document.close();
    }
  }
  deleteImage(headerIndex: number, imageIndex: number, name: string) {
    this.allImagesRenderData[name][imageIndex].imageUrl = null;
    this.allImagesRenderData[name][imageIndex].processedImageUrl = null;
    this.imageTypesHeaders[headerIndex].count =
      this.imageTypesHeaders[headerIndex].count - 1;
    if (this.allImagesRenderData[name][imageIndex].default === 'Y') {
      this.defaultImages[name] = -1;

      this.deletedImage.push(this.imageTypesHeaders[headerIndex].key);
      this.deletedImage.push(
        this.imageTypesHeaders[headerIndex].key.substring(
          0,
          this.imageTypesHeaders[headerIndex].key.length - 8
        )
      );
      this.deletedImage.push(this.imageTypesHeaders[headerIndex].dimensionName);
    }
    this.defaultImagesCount[this.imageTypesHeaders[headerIndex].values] = 0;
  }
  ngOnDestroy() {
    this.validObj?.unsubscribe();
  }

  checkExternalAllowed(item: any, feedWorker: string) {
    if (!Array.isArray(this.notEditable)) return false;
    else if (this.notEditable.includes(item.processedKey)) return false;
    return isGracenoteFeedWorker(feedWorker);
  }
  check(data: MatCheckboxChange, headerIndex: number, imageIndex: number) {
    if (
      isGracenoteFeedWorker(this.images['feedWorker']) &&
      this.notEditable.includes(
        this.imageTypesHeaders[headerIndex].processedKey
      )
    ) {
      data.source.checked = true;
      return;
    }

    if (
      imageIndex ===
        this.defaultImages[this.imageTypesHeaders[headerIndex].values] &&
      (this.imageTypesHeaders[headerIndex].values === 'landscapeImages' ||
        (this.imageTypesHeaders[headerIndex].values === 'portraitImages' &&
          this.images['type'] === 'MOVIE'))
    ) {
      data.source.checked = true;
    } else if (data.source.checked) {
      this.allImagesRenderData[this.imageTypesHeaders[headerIndex].values][
        imageIndex
      ].default = 'Y';

      if (
        this.imageTypesHeaders[headerIndex].values === 'landscapeImages' ||
        (this.imageTypesHeaders[headerIndex].values === 'portraitImages' &&
          this.images['type'] === 'MOVIE')
      ) {
        this.allImagesRenderData[this.imageTypesHeaders[headerIndex].values][
          imageIndex
        ].deletable = false;
      }
      if (this.defaultImages[this.imageTypesHeaders[headerIndex].values] !== -1)
        this.allImagesRenderData[this.imageTypesHeaders[headerIndex].values][
          this.defaultImages[this.imageTypesHeaders[headerIndex].values]
        ].default = 'N';
      if (this.defaultImages[this.imageTypesHeaders[headerIndex].values] !== -1)
        this.allImagesRenderData[this.imageTypesHeaders[headerIndex].values][
          this.defaultImages[this.imageTypesHeaders[headerIndex].values]
        ].deletable = true;

      this.defaultImages[this.imageTypesHeaders[headerIndex].values] =
        imageIndex;
    } else {
      this.allImagesRenderData[this.imageTypesHeaders[headerIndex].values][
        imageIndex
      ].default = 'N';
      this.defaultImages[this.imageTypesHeaders[headerIndex].values] = -1;
    }
  }
  isCpFeedWorker(val: string): boolean {
    return !isGracenoteFeedWorker(val);
  }
}

const imageTypeDBMapping: Record<string, string> = {
  landscape_banner: 'landscapeImages',
  landscape_iconic: 'landscapeIconicImages',
  portrait_banner: 'portraitImages',
  portrait_iconic: 'portraitIconicImages',
  portrait_backdrop: 'portraitBackdropImages',
  landscape_backdrop: 'landscapeBackdropImages',
  title_treatment: 'titleTreatmentImages',
};

const imageTypeResultMapping: Record<string, string> = {
  landscapeImages: 'landscape_banner',
  landscapeIconicImages: 'landscape_iconic',
  portraitImages: 'portrait_banner',
  portraitIconicImages: 'portrait_iconic',
  titleTreatmentImages: 'title_treatment',
  landscapeBackdropImages: 'landscape_backdrop',
  portraitBackdropImages: 'portrait_backdrop',
};
