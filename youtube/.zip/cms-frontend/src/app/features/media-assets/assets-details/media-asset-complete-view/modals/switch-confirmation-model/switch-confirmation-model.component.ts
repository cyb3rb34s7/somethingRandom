import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
    selector: 'app-switch-confirmation-model',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './switch-confirmation-model.component.html',
    styleUrl: './switch-confirmation-model.component.scss'
})
export class SwitchConfirmationModelComponent {
  constructor(
    public dialogRef: MatDialogRef<SwitchConfirmationModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router
  ) {}

  onProceedClick() {
    //this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
    this.dialogRef.close(true);
  }
}
