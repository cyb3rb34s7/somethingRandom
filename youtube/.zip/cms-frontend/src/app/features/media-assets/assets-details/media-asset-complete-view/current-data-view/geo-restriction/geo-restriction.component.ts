import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { ChipInputComponent } from '../../cp-gracenote-cmp-view/chip-input/chip-input.component';
import { Asset } from '../../../../../../models/asset-model';
import { AssetGeoRestrictionModel } from '../../../../../../models/asset-geo-restriction-model';

@Component({
  selector: 'app-geo-restriction',
  imports: [AppMatInputComponent, ChipInputComponent],
  templateUrl: './geo-restriction.component.html',
  styleUrl: './geo-restriction.component.scss',
})
export class GeoRestrictionComponent {
  accessType: string;
  restrictionType: string;
  teamRegions: string[] = [];
  geoRestrictionsCopy: AssetGeoRestrictionModel[];
  @Input() vodData: Asset;

  constructor() {}

  ngOnInit() {
    this.geoRestrictionsCopy = JSON.parse(
      JSON.stringify(this.vodData.geoRestrictions ?? {})
    );
    if (this.geoRestrictionsCopy && this.geoRestrictionsCopy.length > 0) {
      const firstAccessType = this.geoRestrictionsCopy[0].accessType;
      const firstRestrictionType = this.geoRestrictionsCopy[0].restrictionType;

      const allHaveSameValues = this.geoRestrictionsCopy.every(
        (obj) =>
          obj.accessType === firstAccessType &&
          obj.restrictionType === firstRestrictionType
      );
      if (allHaveSameValues) {
        this.accessType = firstAccessType;
        this.restrictionType = firstRestrictionType;
      }
      this.teamRegions = this.geoRestrictionsCopy.map(
        (item) => item.teamRegion
      );
    }
  }
}
