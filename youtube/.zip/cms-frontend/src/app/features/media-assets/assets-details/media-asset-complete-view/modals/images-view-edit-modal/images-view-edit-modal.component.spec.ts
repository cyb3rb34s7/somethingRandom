import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImagesViewEditModalComponent } from './images-view-edit-modal.component';

describe('ImagesViewEditModalComponent', () => {
  let component: ImagesViewEditModalComponent;
  let fixture: ComponentFixture<ImagesViewEditModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImagesViewEditModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ImagesViewEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
