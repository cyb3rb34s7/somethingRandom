import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MetadataHistoryComponent } from "../../../change-history/metadata-history/metadata-history.component";
import { MatButton } from '@angular/material/button';
import { Location } from '@angular/common';
import { map } from 'rxjs';

@Component({
    selector: 'app-single-asset-metadata-history',
    imports: [MetadataHistoryComponent, MatButton],
    templateUrl: './single-asset-metadata-history.component.html',
    styleUrl: './single-asset-metadata-history.component.scss'
})
export class SingleAssetMetadataHistoryComponent {
  title:string|null;
  assetId:string;
  constructor(private route:ActivatedRoute,private location:Location){}

  ngOnInit(){
    this.assetId=this.route.snapshot.queryParams["assetId"];
    this.title=sessionStorage.getItem('mainTitle');
  }
  onBackClick(){
    this.location.back();
  }

}
