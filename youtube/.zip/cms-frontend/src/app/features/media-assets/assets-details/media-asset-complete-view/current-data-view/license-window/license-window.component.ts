import {
  Component,
  DestroyRef,
  EventEmitter,
  inject,
  Input,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { AssetLicenseWindow } from '../../../../../../models/asset-license-window-model';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AssetHelperService } from '../../utils/asset-helper.service';
import { MatDialog } from '@angular/material/dialog';
import { NoRecordFoundComponent } from '../../no-record-found/no-record-found.component';
import { MatButtonModule } from '@angular/material/button';
import { NormalizeCasePipe } from '../../../../../../pipes/normalize-case.pipe';
import { LowerCasePipe } from '../../../../../../pipes/lower-case.pipe';
import { v4 as randomString } from 'uuid';
import { MatTooltip } from '@angular/material/tooltip';
import { CustomDatetimePickerComponent } from '../../custom-datetime-picker/custom-datetime-picker.component';

@Component({
  selector: 'app-license-window',
  imports: [
    NoRecordFoundComponent,
    MatButtonModule,
    NormalizeCasePipe,
    LowerCasePipe,
    MatTooltip,
    CustomDatetimePickerComponent,
  ],
  templateUrl: './license-window.component.html',
  styleUrl: './license-window.component.scss',
})
export class LicenseWindowComponent {
  private destroy = inject(DestroyRef);
  constructor(
    public assetHelperService: AssetHelperService,
    public dialog: MatDialog
  ) {}

  licenseCount: number = 0;

  @Input() disabled: boolean = false;
  @Input() licenseWindow: AssetLicenseWindow[] | any[] = [];
  @Output() currentValue = new EventEmitter<any>();
  @Input() currentWindowItem: number = 0;
  @Output() currentWindowItemChange = new EventEmitter<any>();

  @Output() pendingLicenseWindowValidationFailed: EventEmitter<void> =
    new EventEmitter<void>();
  windowButton: string[] = ['All', 'Active', 'Upcoming', 'Expired'];

  @ViewChildren('datePickers', { read: CustomDatetimePickerComponent })
  matInputs: QueryList<CustomDatetimePickerComponent>;

  licenseWindowCopy: AssetLicenseWindow[] | any[] = [];

  ngOnInit() {
    if (!this.licenseWindow) this.licenseWindow = [];
    this.licenseWindow.sort((a, b) => {
      const startDateComp = a.availableStarting.localeCompare(
        b.availableStarting
      );
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.availableEnding.localeCompare(b.availableEnding);
    });
    this.licenseCount = this.licenseWindow.length;
    this.licenseWindowCopy = [...this.licenseWindow];
  }

  scollToInvalidField() {
    this.assetHelperService.scrollToInvalidField();
  }

  onDeleteClick(idx: number) {
    this.licenseWindowCopy.splice(idx, 1);
    this.emitChanges();
  }

  emitChanges() {
    this.currentValue.emit({
      name: 'licenseWindowList',
      valid: true,
      licenseWindowList: this.licenseWindowCopy.map((item) => {
        return {
          licenseId: item.licenseId,
          availableStarting: item.availableStarting,
          availableEnding: item.availableEnding,
        };
      }),
      changed: true,
    });
  }
  onWindowClick(index: number) {
    this.currentWindowItem = index;
    this.licenseCount = this.licenseWindowCopy.filter(
      (item) =>
        item.windowStatus?.toLowerCase() ===
        this.windowButton[this.currentWindowItem].toLowerCase()
    ).length;
    this.currentWindowItemChange.emit(this.currentWindowItem);
  }
  visibilityCheck(index: number) {
    if (this.currentWindowItem === 0) {
      this.licenseCount = this.licenseWindowCopy.length;
      return false;
    }

    if (
      this.licenseWindowCopy[index].windowStatus?.toLowerCase() ===
      this.windowButton[this.currentWindowItem].toLowerCase()
    ) {
      return false;
    } else {
      return true;
    }
  }
  getRandomLicenseId() {
    const ob = randomString() + '-CMS';
    return ob;
  }

  onDateChange(evt: { date: Date; value: string }, index: number, key: string) {
    this.licenseWindowCopy[index][key] =
      evt.value ?? this.licenseWindowCopy[index][key];

    this.emitChanges();
  }
  addEmptyLicenseWindowSlot() {
    this.licenseWindowCopy.push({
      availableEnding: '',
      availableStarting: '',
      licenseId: this.getRandomLicenseId(),
    } as AssetLicenseWindow);
  }

  triggerValidation() {
    this.matInputs.forEach(input => input.triggerElement());
  }
}
