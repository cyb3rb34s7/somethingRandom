import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
    selector: 'app-cancel-confirmation-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './cancel-confirmation-modal.component.html',
    styleUrl: './cancel-confirmation-modal.component.scss'
})
export class CancelConfirmationModalComponent {
  constructor(
    public dialogRef: MatDialogRef<CancelConfirmationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router
  ) {}

  onProceedClick() {
    //this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
    this.dialogRef.close(true);
  }
}
