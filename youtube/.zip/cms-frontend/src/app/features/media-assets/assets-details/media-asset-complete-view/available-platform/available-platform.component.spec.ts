import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailablePlatformComponent } from './available-platform.component';

describe('AvailablePlatformComponent', () => {
  let component: AvailablePlatformComponent;
  let fixture: ComponentFixture<AvailablePlatformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AvailablePlatformComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AvailablePlatformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
