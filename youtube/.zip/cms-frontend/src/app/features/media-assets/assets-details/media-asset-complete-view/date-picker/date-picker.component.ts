import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  PlatformRef,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
  NativeDateAdapter,
} from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
function dateFormatUtil(d: Date | string | null) {
  if (!d) return null;

  if (typeof d === 'string') {
    if (/^\d{4}$/.test(d)) return d;

    if (/^\d{4}-\d{2}-\d{2}$/.test(d)) return d;
  }

  const date = new Date(d);

  const days = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
  const months =
    date.getMonth() + 1 < 10
      ? '0' + (date.getMonth() + 1)
      : date.getMonth() + 1;
  const year = date.getFullYear();
  return year + '-' + months + '-' + days;
}
export class CustomDateAdapter extends NativeDateAdapter {
  override format(date: Date, displayFormat: any): string {
    const formatted = dateFormatUtil(date);
    return formatted || '';
  }
}
@Component({
    selector: 'app-date-picker',
    providers: [
        MatDatepickerModule,
        {
            provide: DateAdapter,
            useClass: CustomDateAdapter,
            deps: [MAT_DATE_LOCALE, PlatformRef],
        },
    ],
    imports: [
        MatFormFieldModule,
        MatDatepickerModule,
        MatNativeDateModule,
        ReactiveFormsModule,
        CommonModule,
        MatInputModule,
    ],
    templateUrl: './date-picker.component.html',
    styleUrl: './date-picker.component.scss'
})
export class DatePickerComponent {
  @Input() date: any = null;
  @Output() dateChange = new EventEmitter<any>();
  @Input() label: string = '';
  @Input() required: boolean = false;
  @Input() disabled: boolean = true;
  @Input() rightLabel: string = '';
  @Input() highlight: boolean = false;
  fg = new FormGroup({
    selectedDate: new FormControl({
      value: this.date ? new Date(this.date) : null,
      disabled: true,
    }),
  });
  ngOnInit() {
    if (/^\d{4}$/.test(this.date)) this.date = this.date + '-01-01T00:00:00';

    if (/^\d{4}-\d{2}-\d{2}$/.test(this.date))
      this.date = this.date + 'T00:00:00';

    this.fg
      .get('selectedDate')
      ?.setValue(this.date ? new Date(this.date) : null);

    if (this.required) {
      this.fg.get('selectedDate')?.addValidators(Validators.required);
    }
    this.fg.get('selectedDate')?.valueChanges.subscribe(() => {
      const dtVal = this.fg.get('selectedDate')?.value;
      if (dtVal !== undefined && dtVal !== null) {
        const d = dateFormatUtil(dtVal);
        this.dateChange.emit(d);
      } else {
        this.dateChange.emit(null);
      }
    });
  }
  ngOnChanges() {
    if (this.disabled) {
      this.fg.get('selectedDate')?.disable();
    }
    if (!this.disabled) {
      this.fg.get('selectedDate')?.enable();
    }
  }
}
