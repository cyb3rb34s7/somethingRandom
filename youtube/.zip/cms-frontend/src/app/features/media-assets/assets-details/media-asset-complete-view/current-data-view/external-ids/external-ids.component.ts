import {
  Component,
  EventEmitter,
  Input,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../modals/app-mat-select/app-mat-select.component';
import { NoRecordFoundComponent } from '../../no-record-found/no-record-found.component';
import { ExternalProvider } from '../../../../../../models/external-provider-model';
import { ValidatorsCustom } from '../../../asset-constants/asset-fields-constants';
import { MatTooltip } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-external-ids',
  imports: [
    AppMatInputComponent,
    AppMatSelectComponent,
    NoRecordFoundComponent,
    MatTooltip,
    MatButtonModule,
  ],
  templateUrl: './external-ids.component.html',
  styleUrl: './external-ids.component.scss',
})
export class ExternalIdsComponent {
  constructor() {}
  @Input() isDisabled: boolean = true;
  @Input() externalIds: ExternalProvider[] | any[] = [];
  @Input() bulkEditFlag: boolean = false;

  @Output() currentValue = new EventEmitter<any>();

  externalValidator: ValidatorsCustom = { minLength: 1 };
  @ViewChildren('matSelect', { read: AppMatSelectComponent })
  matSelects: QueryList<AppMatSelectComponent>;

  @ViewChildren('matInput', { read: AppMatInputComponent })
  matInputs: QueryList<AppMatInputComponent>;

  externalIdsCopy: ExternalProvider[] | any[] = [];

  ngOnInit() {
    this.externalIdsCopy = JSON.parse(JSON.stringify(this.externalIds));
  }

  onFormChangeExternal(obj: any, index: number) {
    this.externalIdsCopy[index][obj['name']] = obj['value']?.trim();
    this.emitChanges(obj['changed']);
  }
  dropDownValueChangeExternal(obj: any, index: number) {
    this.externalIdsCopy[index]['idType'] = obj['value']?.trim();
    this.emitChanges();
  }

  deleteExternalProvider(index: number) {
    if (!this.isDisabled && !this.bulkEditFlag) {
      this.externalIdsCopy.splice(index, 1);
      this.emitChanges(true);
      this.matSelects.forEach((select) => {
        select.selectFormControl?.markAsDirty();
      });
    }
  }
  emitChanges(change?: boolean) {
    this.currentValue.emit({
      name: 'externalProvider',
      changed: change,
      valid: true,
      value: [...this.externalIdsCopy],
    });
  }
  addEmptyExternalId() {
    this.externalIdsCopy.push({
      externalProgramId: '',
      idType: '',
      provider: '',
    });
  }

  triggerValidation() {
    this.matInputs.forEach(input => input.triggerElement());
    this.matSelects.forEach(select => select.triggerElement());
  }
}
