import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import {
  MatRadioButton,
  MatRadioChange,
  MatRadioModule,
} from '@angular/material/radio';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ValidatorsObj } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AssetHelperService } from '../utils/asset-helper.service';
import { ImagesViewEditModalComponent } from '../modals/images-view-edit-modal/images-view-edit-modal.component';
import { MatDialog } from '@angular/material/dialog';
import {
  gracenoteFields,
  imageFields,
  imageResponseKey,
  notVisibleFields,
  validCheck,
} from '../../asset-constants/asset-fields-constants';
import { plainToInstance } from 'class-transformer';
import { AssetGracenote } from '../../../../../models/asset-gracenote-model';
import { CommonModule } from '@angular/common';
import { NoComparisonAvailableComponent } from '../no-comparison-available/no-comparison-available.component';
import { ChipInputComponent } from './chip-input/chip-input.component';
import { ToggleButtonComponent } from './toggle-button/toggle-button.component';
import { AssetLockedField } from '../../../../../models/asset-locked-field';
import {
  deltaFeedWorkersList,
  feedWorkerTypeConverter,
  isGracenoteFeedWorker,
} from '../utils/asset-feedworker-util';
import { AssetOnApi } from '../../../../../models/asset-onapi-model';
import { StateStoreService } from '../../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../../constants/store-consts';

@Component({
  selector: 'app-cp-gracenote-cmp-view',
  imports: [
    MatRadioModule,
    MatExpansionModule,
    MatIconModule,
    MatButtonModule,
    CommonModule,
    NoComparisonAvailableComponent,
    ChipInputComponent,
    ToggleButtonComponent,
  ],
  templateUrl: './cp-gracenote-cmp-view.component.html',
  styleUrls: [
    './cp-gracenote-cmp-view.component.scss',
    './cp-gracenote-cmp-view.component.extended.scss',
  ],
})
export class CpGracenoteCmpViewComponent {
  @Input() currentVodData: any;

  radioButtonSelected: string = '';

  invisibleFields: string[] = [];
  @Input()
  externalIdFlag: boolean;

  nonEditableFields: any;
  @Input() formChanged: boolean;
  @Input() feedWorker: string;
  @Output() formChangedChange = new EventEmitter<boolean>();
  @Output() radioButtonChange = new EventEmitter<any>();

  imageFields: any = imageFields;
  inpValue: any = null;

  allowedTypes: string[] = [];

  constructor(
    public assetHelperService: AssetHelperService,
    public dialog: MatDialog,
    private store: StateStoreService
  ) {}
  fieldList: {
    key: string;
    value: string;
    validator: ValidatorsObj;
    isCp: boolean;
    isGracenote: boolean;
  }[] = [
    {
      key: 'mainTitle',
      value: 'Program Main Title',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'shortTitle',
      value: 'Program Short Title',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'seasonNo',
      value: 'Season No',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'episodeNo',
      value: 'Episode No',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'releaseDate',
      value: 'Release Date',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'genres',
      value: 'Genre',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'description',
      value: 'Synopsis',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'image',
      value: 'Images',
      validator: {},
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'director',
      value: 'Director',
      validator: { commaSeparated: true },
      isCp: true,
      isGracenote: false,
    },
    {
      key: 'starring',
      value: 'Actor',
      validator: { commaSeparated: true },
      isCp: true,
      isGracenote: false,
    },
  ];

  @Input() disabled: boolean = true;
  @Input() cpProviderData: any;
  @Input() gracenoteData: any;
  @Input() lockedFieldList: AssetLockedField[] = [];
  @Output() cpProviderDataChange = new EventEmitter<any>();
  mandatoryFields: any = [];
  @Input() genres: any[];
  validCheck = validCheck;

  @ViewChild('cpDataButton') cpDataButton!: MatRadioButton;

  imageTypes = [
    {
      key: 'landscapeBanner',
      label: 'Landscape Banner (16:9)',
      type: 'landscape',
    },
    { key: 'portraitBanner', label: 'Portrait Banner (2:3)', type: 'portrait' },
    {
      key: 'landscapeIconic',
      label: 'Landscape Iconic (16:9)',
      type: 'landscape',
    },
    { key: 'portraitIconic', label: 'Portrait Iconic (2:3)', type: 'portrait' },
    {
      key: 'landscapeBackdrop',
      label: 'Landscape Backdrop (16:9)',
      type: 'landscape',
    },
    {
      key: 'portraitBackdrop',
      label: 'Portrait Backdrop (2:3)',
      type: 'portrait',
    },
    { key: 'titleTreatment', label: 'Title Treatment', type: 'landscape' },
  ];

  private accordionStates: { [key: string]: boolean } = {};

  ngOnInit() {
    this.invisibleFields = notVisibleFields
      .filter(
        (item: { type: string; value: string[] }) =>
          item.type === this.cpProviderData['type']
      )
      .flatMap((item) => {
        return item.value;
      });
    this.fieldList = this.fieldList.filter(
      (field) => !this.invisibleFields.includes(field.key)
    );
    if (
      isGracenoteFeedWorker(this.feedWorker) &&
      this.lockedFieldList.length === 0
    ) {
      this.radioButtonSelected = 'gracenote';
      this.fieldList.forEach((field) => {
        field.isCp = false;
        field.isGracenote = true;
      });
    } else if (!isGracenoteFeedWorker(this.feedWorker)) {
      this.radioButtonSelected = 'cp';
      this.fieldList.forEach((field) => {
        field.isCp = true;
        field.isGracenote = false;
      });
    } else {
      this.radioButtonSelected = 'custom';
      this.fieldList.forEach((field) => {
        const cmp = field.key === 'image' ? 'imageLandscape' : field.key;
        const el = this.lockedFieldList.filter(
          (el) => el.fieldName === FieldMappings.getDBColumn(cmp)
        );
        if (el.length > 0) {
          field.isCp = true;
          field.isGracenote = false;
        } else {
          field.isCp = false;
          field.isGracenote = true;
        }
      });
    }
    this.allowedTypes =
      this.store.getStoreState(STORE_CONSTS.ASSET_MASTER_DATA)?.gnAllowed ?? [];
  }

  handleCustomSelection() {
    this.radioButtonSelected = 'custom';
    //need to hanndle tvplus delta
    const tempFeedworkerFlag: boolean = deltaFeedWorkersList.includes(
      this.currentVodData['feedWorker']
    );
    this.feedWorker =
      feedWorkerTypeConverter.get(
        tempFeedworkerFlag ? 'TVPLUS_DELTA' : 'CMS'
      ) ?? '';
    const obj: any = {};
    obj['feedWorker'] = feedWorkerTypeConverter.get(
      tempFeedworkerFlag ? 'TVPLUS_DELTA' : 'CMS'
    );

    const gracenoteFields: string[] = [];
    let gnCount: number = 0;
    let cpCount: number = 0;
    this.fieldList.forEach((field) => {
      gnCount += field.isGracenote ? 1 : 0;
      cpCount += field.isCp ? 1 : 0;
    });
    if (gnCount === 0) {
      this.applyCpSelection();
    } else if (cpCount === 0) {
      this.applyGNSelection();
    } else {
      this.fieldList.forEach((field) => {
        if (field.key === 'image') {
          if (field.isCp) {
            this.intializeImageValue(obj, this.cpProviderData, 'cp');
          } else if (field.isGracenote) {
            this.intializeImageValue(obj, this.gracenoteData, 'gracenote');
            this.intializeImageKey(gracenoteFields);
          }
        } else {
          if (field.isCp) {
            obj[field.key] = this.cpProviderData[field.key];
          } else if (field.isGracenote) {
            obj[field.key] = this.gracenoteData[field.key];
            gracenoteFields.push(field.key);
          }
        }
      });

      let objTemp: any;
      if (this.gracenoteData.externalSource === GracenoteExternalSources.GVD) {
        objTemp = plainToInstance(AssetGracenote, obj, {
          excludeExtraneousValues: true,
        });
      } else if (
        this.gracenoteData.externalSource === GracenoteExternalSources.ONAPI
      ) {
        objTemp = plainToInstance(AssetOnApi, obj, {
          excludeExtraneousValues: true,
        });
      }
      objTemp['gracenoteFields'] = [...gracenoteFields];
      this.radioButtonChange.emit({ ...objTemp, isCp: false });
    }
  }
  intializeImageKey(gracenoteFields: string[]) {
    if (this.gracenoteData.externalSource === GracenoteExternalSources.GVD) {
      gracenoteFields.push(...imageKeysGvd);
    } else if (
      this.gracenoteData.externalSource === GracenoteExternalSources.ONAPI
    ) {
      gracenoteFields.push(...imageKeysOnApi);
    }
  }

  onViewImages(isGracenote: boolean, data: any) {
    this.viewImagesAndEditModal(isGracenote, data);
  }
  imageResponseKey: string[] = imageResponseKey;
  viewImagesAndEditModal(isGracenote: boolean, data: any) {
    var images: any = {};
    images['imageLandscapeOriginal'] = data['imageLandscapeOriginal'];
    images['imagePortraitOriginal'] = data['imagePortraitOriginal'];
    images['imageCircleOriginal'] = data['imageCircleOriginal'];
    images['imagePortraitIconicOriginal'] = data['imagePortraitIconicOriginal'];
    images['imageLandscapeIconicOriginal'] =
      data['imageLandscapeIconicOriginal'];

    this.dialog.open(ImagesViewEditModalComponent, {
      data: {
        ...images,
        editMode: true,
        ...data,
        gracenote: isGracenote,
      },
      panelClass: 'view-edit-image-modal',
      disableClose: true,
    });
  }

  intializeImageValue(obj: any, data: any, dataType: string) {
    if (
      this.gracenoteData.externalSource === GracenoteExternalSources.GVD &&
      dataType === 'gracenote'
    ) {
      for (let item of imageKeysGvd) {
        obj[item] = data[item] ?? '';
      }
    } else if (
      this.gracenoteData.externalSource === GracenoteExternalSources.ONAPI
    ) {
      for (let item of imageKeysOnApi) {
        obj[item] = data[item] ?? '';
      }
    } else {
      for (let item of imageKeysOnApi) {
        obj[item] = data[item] ?? '';
      }
    }
  }

  individualToggleChecked(fieldName: string, buttonType: string) {
    const obj = this.fieldList.filter((field) => field.key === fieldName)[0];
    return buttonType === 'cp' ? obj.isCp : obj.isGracenote;
  }
  toggleChange($event: any, key: string, buttonType: string) {
    this.fieldList.forEach((field) => {
      if (
        field.key === key ||
        (field.key === 'starring' && key === 'director') ||
        (field.key === 'director' && key === 'starring')
      ) {
        field.isCp = buttonType === 'cp' ? $event.checked : !$event.checked;
        field.isGracenote =
          buttonType === 'gracenote' ? $event.checked : !$event.checked;

        if (
          (field.isCp && this.radioButtonSelected === 'gracenote') ||
          (field.isGracenote && this.radioButtonSelected === 'cp') ||
          this.radioButtonSelected === 'custom'
        ) {
          this.radioButtonSelected = 'custom';

          this.handleCustomSelection();
        }
        if (field.isCp) {
          if (field.key === 'image') {
            (this.gracenoteData.externalSource === GracenoteExternalSources.GVD
              ? imageKeysGvd
              : imageKeysOnApi
            ).forEach((item) => this.addFieldToLockedList({ key: item }));
          } else {
            this.addFieldToLockedList(field);
          }
        } else if (field.isGracenote) {
          if (field.key === 'image') {
            (this.gracenoteData.externalSource === GracenoteExternalSources.GVD
              ? imageKeysGvd
              : imageKeysOnApi
            ).forEach((item) => this.removeFieldFromLockedList({ key: item }));
          } else {
            this.removeFieldFromLockedList(field);
          }
        }
      }
    });
  }
  onRadioButtonChange($event: MatRadioChange) {
    if ($event.value === '1') {
      this.applyCpSelection();
    } else if ($event.value === '2') {
      this.applyGNSelection();
    } else if ($event.value === '3') {
      this.handleCustomSelection();
    }
  }
  applyCpSelection() {
    this.cpProviderData['feedWorker'] = feedWorkerTypeConverter.get(
      this.currentVodData['feedWorker']
    );
    this.feedWorker =
      feedWorkerTypeConverter.get(this.currentVodData['feedWorker']) ?? '';
    var obj = plainToInstance(AssetGracenote, this.cpProviderData, {
      excludeExtraneousValues: true,
    });

    this.radioButtonChange.emit({ ...obj, isCp: true });
    this.radioButtonSelected = 'cp';
    this.fieldList.forEach((field) => {
      field.isCp = true;
      field.isGracenote = false;
      if (field.key === 'image') {
        (this.gracenoteData.externalSource === GracenoteExternalSources.GVD
          ? imageKeysGvd
          : imageKeysOnApi
        ).forEach((item) => this.addFieldToLockedList({ key: item }));
      } else {
        this.addFieldToLockedList(field);
      }
    });
  }
  applyGNSelection() {
    const tempFeedworkerFlag: boolean = deltaFeedWorkersList.includes(
      this.currentVodData['feedWorker']
    );

    this.gracenoteData['feedWorker'] = feedWorkerTypeConverter.get(
      tempFeedworkerFlag ? 'TVPLUS_DELTA' : 'CMS'
    );

    this.feedWorker =
      feedWorkerTypeConverter.get(
        tempFeedworkerFlag ? 'TVPLUS_DELTA' : 'CMS'
      ) ?? '';
    let obj: any;
    if (this.gracenoteData.externalSource === GracenoteExternalSources.GVD) {
      obj = plainToInstance(AssetGracenote, this.gracenoteData, {
        excludeExtraneousValues: true,
      });
    } else if (
      this.gracenoteData.externalSource === GracenoteExternalSources.ONAPI
    ) {
      obj = plainToInstance(AssetOnApi, this.gracenoteData, {
        excludeExtraneousValues: true,
      });
    }

    obj['gracenoteFields'] = [...gracenoteFields];
    const len = gracenoteFields.length;
    if (this.gracenoteData.externalSource === GracenoteExternalSources.GVD)
      obj['gracenoteFields'].splice(len - 6, len);
    this.intializeImageValue(obj, this.gracenoteData, 'gracenote');
    this.radioButtonChange.emit({ ...obj, isCp: false });
    this.radioButtonSelected = 'gracenote';
    this.lockedFieldList.splice(0, this.lockedFieldList.length);
    this.fieldList.forEach((field) => {
      field.isCp = false;
      field.isGracenote = true;
    });
  }
  addFieldToLockedList(field: any) {
    const obj = this.lockedFieldList.find(
      (el) => el.fieldName === FieldMappings.getDBColumn(field.key)
    );
    if (!obj) {
      const newObj: AssetLockedField = new AssetLockedField(
        this.cpProviderData.contentId,
        this.cpProviderData.vcCpId,
        this.cpProviderData.countryCode,
        FieldMappings.getDBColumn(field.key),
        this.gracenoteData.externalSource === GracenoteExternalSources.GVD
          ? 'GN_SELECT'
          : 'ONAPI_SELECT'
      );
      this.lockedFieldList.push({ ...newObj });
    }
  }
  removeFieldFromLockedList(field: any) {
    const ind = this.lockedFieldList.findIndex(
      (el) => el.fieldName === FieldMappings.getDBColumn(field.key)
    );
    this.lockedFieldList.splice(ind, 1);
  }

  isCPButtonChecked(): boolean {
    return !isGracenoteFeedWorker(this.feedWorker);
  }

  isGracenoteChecked(): boolean {
    return isGracenoteFeedWorker(this.feedWorker);
  }

  isAccordionExpanded(dataSource: string, imageTypeKey: string): boolean {
    const key = `${dataSource}-${imageTypeKey}`;
    return this.accordionStates[key] || true;
  }

  getImageKey(imageTypeKey: string): string {
    const keyMap: { [key: string]: string } = {
      landscapeBanner: 'imageLandscape',
      portraitBanner: 'imagePortrait',
      landscapeIconic: 'imageLandscapeIconic',
      portraitIconic: 'imagePortraitIconic',
      landscapeBackdrop: 'imageLandscapeBackdrop',
      portraitBackdrop: 'imagePortraitBackdrop',
      titleTreatment: 'imageTitleTreatment',
    };
    return keyMap[imageTypeKey] || '';
  }

  getImageUrl(dataSource: string, imageTypeKey: string): string {
    const data = dataSource === 'cp' ? this.cpProviderData : this.gracenoteData;
    const imageKey = this.getImageKey(imageTypeKey);
    return data?.[imageKey] || '';
  }

  shouldShowImageType(imageTypeKey: string): boolean {
    const cpImage = this.cpProviderData?.[this.getImageKey(imageTypeKey)];
    const gracenoteImage = this.gracenoteData?.[this.getImageKey(imageTypeKey)];
    return cpImage || gracenoteImage;
  }

  isTypeSame(cpProviderDataType: string, gracenoteDataType: string) {
    if (!cpProviderDataType || !gracenoteDataType) return false;
    return cpProviderDataType.toLowerCase() === gracenoteDataType.toLowerCase();
  }

  isRadioButtonDisabled() {
    return (
      this.disabled ||
      !this.gracenoteData ||
      !this.externalIdFlag ||
      !this.allowedTypes.includes(this.currentVodData.type) ||
      !this.isTypeSame(this.cpProviderData.type, this.gracenoteData.type)
    );
  }
}
export const gracenoteField: string[] = [
  'mainTitle',
  'shortTitle',
  'releaseDate',
  'genres',
  'description',
  'image',
  'director',
  'starring',
];

export const imageKeysGvd: string[] = [
  'imageLandscape',
  'imagePortrait',
  'imagePortraitIconic',
  'imageLandscapeIconic',
  'imageLandscapeDimension',
  'imagePortraitDimension',
  'imagePortraitIconicDimension',
  'imageLandscapeIconicDimension',
];
export const imageKeysOnApi: string[] = [
  'imageLandscape',
  'imagePortrait',
  'imagePortraitIconic',
  'imageLandscapeIconic',
  'imageLandscapeDimension',
  'imagePortraitDimension',
  'imagePortraitIconicDimension',
  'imageLandscapeIconicDimension',
  'imageTitleTreatment',
  'imageTitleTreatmentDimension',
  'imageLandscapeBackdrop',
  'imageLandscapeBackdropDimension',
];

const fieldKeyToDBMapping: Record<string, string> = {
  mainTitle: 'MAIN_TITLE',
  shortTitle: 'SHORT_TITLE',
  seasonNo: 'SEASON_NO',
  episodeNo: 'EPISODE_NO',
  releaseDate: 'REL_DATE',
  genres: 'GENRES',
  description: 'DESCR',
  image: 'IMAGE',
  director: 'DIRECTOR',
  starring: 'STARRING',
  artist: 'ARTIST',
  imagePortraitIconic: 'IMG_PORTRAIT_ICONIC',
  imageLandscapeIconic: 'IMG_LANDSCAPE_ICONIC',
  imageLandscapeIconicOriginal: 'IMG_LANDSCAPE_ICONIC_ORIGINAL',
  imagePortraitIconicOriginal: 'IMG_PORTRAIT_ICONIC_ORIGINAL',
  imageLandscapeDimension: 'IMG_LANDSCAPE_W_H',
  imagePortraitDimension: 'IMG_PORTRAIT_W_H',
  imageLandscapeIconicDimension: 'IMG_LANDSCAPE_ICONIC_W_H',
  imagePortraitIconicDimension: 'IMG_PORTRAIT_ICONIC_W_H',
  imageLandscape: 'IMG_LANDSCAPE',
  imagePortrait: 'IMG_PORTRAIT',
  imageLandscapeOriginal: 'IMG_LANDSCAPE_ORIGINAL',
  imagePortraitOriginal: 'IMG_PORTRAIT_ORIGINAL',
  imageTitleTreatment: 'IMG_TITLE_TREATMENT',
  imageTitleTreatmentOriginal: 'IMG_TITLE_TREATMENT_ORIGINAL',
  imageTitleTreatmentDimension: 'IMG_TITLE_TREATMENT_W_H',
  imageLandscapeBackdrop: 'IMG_LANDSCAPE_BACKDROP',
  imageLandscapeBackdropOriginal: 'IMG_LANDSCAPE_BACKDROP_ORIGINAL',
  imageLandscapeBackdropDimension: 'IMG_LANDSCAPE_BACKDROP_W_H',
};

const dbToFieldKeyMapping: Record<string, string> = {
  MAIN_TITLE: 'mainTitle',
  SHORT_TITLE: 'shortTitle',
  SEASON_NO: 'seasonNo',
  EPISODE_NO: 'episodeNo',
  REL_DATE: 'releaseDate',
  GENRES: 'genres',
  DESCR: 'description',
  IMG: 'image',
  DIRECTOR: 'director',
  STARRING: 'starring',
  ARTIST: 'artist',
  IMG_PORTRAIT_ICONIC: 'imagePortraitIconic',
  IMG_LANDSCAPE_ICONIC: 'imageLandscapeIconic',
  IMG_LANDSCAPE_ICONIC_ORIGINAL: 'imageLandscapeIconicOriginal',
  IMG_PORTRAIT_ICONIC_ORIGINAL: 'imagePortraitIconicOriginal',
  IMG_LANDSCAPE_W_H: 'imageLandscapeDimension',
  IMG_PORTRAIT_W_H: 'imagePortraitDimension',
  IMG_LANDSCAPE_ICONIC_W_H: 'imageLandscapeIconicDimension',
  IMG_PORTRAIT_ICONIC_W_H: 'imagePortraitIconicDimension',
  IMG_LANDSCAPE: 'imageLandscape',
  IMG_PORTRAIT: 'imagePortrait',
  IMG_LANDSCAPE_ORIGINAL: 'imageLandscapeOriginal',
  IMG_PORTRAIT_ORIGINAL: 'imagePortraitOriginal',
  IMG_TITLE_TREATMENT: 'imageTitleTreatment',
  IMG_TITLE_TREATMENT_ORIGINAL: 'imageTitleTreatmentOriginal',
  IMG_TITLE_TREATMENT_W_H: 'imageTitleTreatmentDimension',
  IMG_LANDSCAPE_BACKDROP: 'imageLandscapeBackdrop',
  IMG_LANDSCAPE_BACKDROP_ORIGINAL: 'imageLandscapeBackdropOriginal',
  IMG_LANDSCAPE_BACKDROP_W_H: 'imageLandscapeBackdropDimension',
};

export class FieldMappings {
  static getDBColumn(fieldKey: string): string {
    return fieldKeyToDBMapping[fieldKey] || fieldKey;
  }

  static getFieldKey(dbColumn: string): string {
    return dbToFieldKeyMapping[dbColumn] || dbColumn;
  }

  static getAllFieldKeys(): string[] {
    return Object.keys(fieldKeyToDBMapping);
  }

  static getAllDBColumns(): string[] {
    return Object.keys(dbToFieldKeyMapping);
  }
}
export enum GracenoteExternalSources {
  GVD = 'GVD',
  ONAPI = 'ONAPI',
}
