import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CpGracenoteCmpViewComponent } from './cp-gracenote-cmp-view.component';

describe('CpGracenoteCmpViewComponent', () => {
  let component: CpGracenoteCmpViewComponent;
  let fixture: ComponentFixture<CpGracenoteCmpViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CpGracenoteCmpViewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CpGracenoteCmpViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
