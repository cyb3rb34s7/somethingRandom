class BiDirectionalMap {
  private map: Map<string, string> = new Map();
  constructor(pairs: [string, string][]) {
    for (const [a, b] of pairs) {
      this.map.set(a, b);
      this.map.set(b, a);
    }
  }
  get(key: string): string | undefined {
    return this.map.get(key);
  }
}

const feedWorkerTypeMap: [string, string][] = [
  ['CMS', 'CMS_GRACENOTE'],
  ['TVPLUS_DELTA', 'TVPLUS_DELTA_GRACENOTE'],
  ['TVPLUS', 'TVPLUS_GRACENOTE'],
];

export const feedWorkerTypeConverter = new BiDirectionalMap(feedWorkerTypeMap);

export const feedWorkersList: string[] = [
  'CMS_GRACENOTE',
  'TVPLUS_DELTA_GRACENOTE',
  'CMS',
  'TVPLUS_DELTA',
];

export const cmsFeedWorkersList: string[] = ['CMS_GRACENOTE', 'CMS'];

export const deltaFeedWorkersList: string[] = [
  'TVPLUS_DELTA_GRACENOTE',
  'TVPLUS_DELTA',
];
export function isGracenoteFeedWorker(val: string): boolean {
  if (feedWorkersList.includes(val) && val.toLowerCase().endsWith('_gracenote'))
    return true;
  return false;
}
