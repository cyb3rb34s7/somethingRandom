import { Component } from '@angular/core';

@Component({
    selector: 'app-no-comparison-available',
    imports: [],
    templateUrl: './no-comparison-available.component.html',
    styleUrl: './no-comparison-available.component.scss'
})
export class NoComparisonAvailableComponent {

}
