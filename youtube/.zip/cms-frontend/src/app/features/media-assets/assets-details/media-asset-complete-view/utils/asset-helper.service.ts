import { Injectable } from '@angular/core';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { AvailablePlatform } from '../../../../../models/asset-available-platform-model';
import { AssetLicenseWindow } from '../../../../../models/asset-license-window-model';
import { AssetEventWindowModel } from '../../../../../models/asset-event-window-model';
import { isGracenoteFeedWorker } from './asset-feedworker-util';
import { AssetLockedField } from '../../../../../models/asset-locked-field';
import { notVisibleBlock } from '../../asset-constants/asset-fields-constants';
import { Asset } from '../../../../../models/asset-model';
import { AssetGeoRestrictionModel } from '../../../../../models/asset-geo-restriction-model';

export enum AssetTypes {
  EPISODE = 'EPISODE',
  MOVIE = 'MOVIE',
  SHOW = 'SHOW',
  SEASON = 'SEASON',
  SINGLEVOD = 'SINGLEVOD',
  MUSIC = 'MUSIC',
}

@Injectable({
  providedIn: 'root',
})
export class AssetHelperService {
  constructor(private toastr: CustomToastrService) {}
  scrollToInvalidField() {
    const mi: any = document.querySelectorAll(
      'app-mat-input:not(.invisible) .ng-invalid'
    )[0];

    const ms: any = document.querySelectorAll(
      'app-mat-select:not(.invisible) .ng-invalid'
    )[0];

    var inp;
    if (mi && ms) {
      if (mi.offsetParent.offsetTop === ms.offsetParent.offsetTop) {
        if (mi.offsetTop < ms.offsetTop) {
          mi.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'nearest',
          });
          inp = mi;
        } else {
          ms.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'nearest',
          });
          inp = ms;
        }
      } else if (mi.offsetParent.offsetTop < ms.offsetParent.offsetTop) {
        mi.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'nearest',
        });
        inp = mi;
      } else {
        ms.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'nearest',
        });
        inp = ms;
      }
    } else if (mi) {
      mi.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest',
      });
      inp = mi;
    } else if (ms) {
      ms.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest',
      });
      inp = ms;
    }
    inp?.inputFormControl?.markAllAsTouched();

    console.log(inp);

    this.toastr.error(`${inp?.id} is having invalid Input`);
  }
  detectFormChange() {
    const ms: any = document.querySelectorAll('.ng-dirty');

    if (ms && ms.length > 0) {
      return true;
    } else {
      return false;
    }
  }
  checkDuplicateExternalIdPerType(
    externalIds: any[],
    tempExtObj: any
  ): boolean {
    var mp = new Map();
    if (externalIds) {
      for (var itm of externalIds) {
        if (mp.has(itm['idType'])) {
          return false;
        } else {
          mp.set(itm['idType'], 1);
        }
      }
      if (mp.has(tempExtObj.idType)) {
        return false;
      }
    }
    return true;
  }
  checkDuplicateExternalId(vodAssetDto: any, currTab: number): boolean {
    if (currTab === 1) return true;
    var mp = new Map();
    if (vodAssetDto['externalProvider']) {
      for (var itm of vodAssetDto['externalProvider']) {
        if (!itm['externalProgramId'] || !itm['idType'] || !itm['provider']) {
          this.toastr.error('Invalid Entry for External Ids');
          return false;
        }

        if (
          mp.has(itm['externalProgramId'] + itm['idType'] + itm['provider'])
        ) {
          this.toastr.error('Duplicate External Ids');
          return false;
        } else if (mp.has(itm['idType'])) {
          this.toastr.error('Duplicate External Ids');
          return false;
        } else {
          mp.set(itm['externalProgramId'] + itm['idType'] + itm['provider'], 1);
          mp.set(itm['idType'], 1);
        }
      }
    }
    return true;
  }
  getDateTimeWithTZ(value: string) {
    if (!value) {
      return null;
    }
    const [datePart, timePart] = value?.split(' ');
    return datePart.concat('T', timePart.concat('Z')).trim();
  }
  getDateTimeWithoutTZ(value: string) {
    if (!value) {
      return null;
    }
    return value.replace('T', ' ').replace('Z', '');
  }
  validateExternalProvider(tempExtObj: any): boolean {
    if (
      tempExtObj.externalProgramId &&
      tempExtObj.idType &&
      tempExtObj.provider
    ) {
      return true;
    } else {
      return false;
    }
  }
  validateCastOnSave(val: any): boolean {
    var actorCount = 0;
    var directorCount = 0;
    var artistCount = 0;
    if (val) {
      for (var item of val) {
        if (!item.role || !item.name) {
          this.toastr.warn('Invalid input in cast details');
          return false;
        }
        switch (item.role) {
          case 'actor':
            actorCount = actorCount + 1;
            break;
          case 'director':
            directorCount = directorCount + 1;
            break;
          case 'artist':
            artistCount = artistCount + 1;
            break;
        }
      }
    }
    if (actorCount > 10) {
      this.toastr.warn('Maximum 10 actors allowed');
      return false;
    } else if (directorCount > 10) {
      this.toastr.warn('Maximum 10 directors allowed');
      return false;
    } else if (artistCount > 10) {
      this.toastr.warn('Maximum 10 artists allowed');
      return false;
    }
    return true;
  }
  validateDuplicateEntryForCast(val: any) {
    var mp = new Map();
    if (val) {
      for (var item of val) {
        if (
          item.characterName &&
          mp.has(item.name + item.role + item.characterName)
        ) {
          this.toastr.error('Duplicate entry for ' + item.role);

          return false;
        } else if (
          item.characterName &&
          !mp.has(item.name + item.role + item.characterName)
        ) {
          mp.set(item.name + item.role + item.characterName, 1);
        } else if (mp.has(item.name + item.role)) {
          this.toastr.error('Duplicate entry for ' + item.role);

          return false;
        } else {
          mp.set(item.name + item.role, 1);
        }
      }
    }
    return true;
  }

  transfromObject(obj: any): string {
    return JSON.stringify(obj);
  }

  setPlatformTagData(
    finalAsset: any,
    availablePlatform: AvailablePlatform,
    assets: any,
    platformChanged: boolean,
    changedArray: string[],
    assetChangeDto: any,
    metaDatahistory: any
  ) {
    finalAsset['platformTag'] = availablePlatform.type;
    if (finalAsset['platformTag'] !== assets['platformTag']) {
      platformChanged = true;
    }

    if (!assets['platformTagData']) {
      assets['platformTagData'] = [];
    }

    //checking for change
    if (
      availablePlatform.fHubValues.length !==
        assets['platformTagData']?.filter((e: any) => e.type === 'FHUB')
          .length ||
      availablePlatform.mobileValues.length !==
        assets['platformTagData']?.filter((e: any) => e.type === 'MOB')
          .length ||
      availablePlatform.tvValues.length !==
        assets['platformTagData']?.filter((e: any) => e.type === 'TV').length ||
      availablePlatform.webValues.length !==
        assets['platformTagData']?.filter((e: any) => e.type === 'WEB').length
    ) {
      platformChanged = true;
    }

    availablePlatform.mobileValues.forEach(
      (item: { platformName: string; platformAlias?: string }) => {
        if (
          assets['platformTagData']?.filter(
            (e: any) => e.platform === item.platformName
          ).length === 0 ||
          availablePlatform.mobileValues.length !==
            assets['platformTagData']?.filter((e: any) => e.type === 'MOB')
              .length
        ) {
          platformChanged = true;
        }
      }
    );
    availablePlatform.tvValues.forEach(
      (item: { platformName: string; platformAlias?: string }) => {
        if (
          assets['platformTagData']?.filter(
            (e: any) => e.platform === item.platformName
          ).length === 0 ||
          availablePlatform.tvValues.length !==
            assets['platformTagData']?.filter((e: any) => e.type === 'TV')
              .length
        ) {
          platformChanged = true;
        }
      }
    );
    availablePlatform.webValues.forEach(
      (item: { platformName: string; platformAlias?: string }) => {
        if (
          assets['platformTagData']?.filter(
            (e: any) => e.platform === item.platformName
          ).length === 0 ||
          availablePlatform.webValues.length !==
            assets['platformTagData']?.filter((e: any) => e.type === 'WEB')
              .length
        ) {
          platformChanged = true;
        }
      }
    );
    availablePlatform.fHubValues.forEach(
      (item: { platformName: string; platformAlias?: string }) => {
        if (
          assets['platformTagData']?.filter(
            (e: any) => e.platform === item.platformName
          ).length === 0 ||
          availablePlatform.fHubValues.length !==
            assets['platformTagData']?.filter((e: any) => e.type === 'FHUB')
              .length
        ) {
          platformChanged = true;
        }
      }
    );
    if (!platformChanged) {
      return;
    }
    finalAsset['platformTagData'] = [];
    //need to push the final value
    availablePlatform.mobileValues.forEach(
      (item: { platformName: string; platformAlias?: string }) =>
        finalAsset['platformTagData']?.push({
          type: 'MOB',
          platform: item.platformName,
          alias: item.platformAlias,
        })
    );
    availablePlatform.tvValues.forEach(
      (item: { platformName: string; platformAlias?: string }) =>
        finalAsset['platformTagData']?.push({
          type: 'TV',
          platform: item.platformName,
          alias: item.platformAlias,
        })
    );
    availablePlatform.webValues.forEach(
      (item: { platformName: string; platformAlias?: string }) =>
        finalAsset['platformTagData']?.push({
          type: 'WEB',
          platform: item.platformName,
          alias: item.platformAlias,
        })
    );
    availablePlatform.fHubValues.forEach(
      (item: { platformName: string; platformAlias?: string }) =>
        finalAsset['platformTagData']?.push({
          type: 'FHUB',
          platform: item.platformName,
          alias: item.platformAlias,
        })
    );
    if (availablePlatform.type === 'common') {
      finalAsset['platformTagData'] = [];
    }
    changedArray.push('Available Platforms');

    assetChangeDto['field'] = 'platformTagData';
    assetChangeDto['oldValue'] = JSON.stringify(assets['platformTagData']);
    assetChangeDto['newValue'] = JSON.stringify(finalAsset['platformTagData']);
    metaDatahistory.push({ ...assetChangeDto });
    for (var item in assetChangeDto) {
      delete assetChangeDto[item];
    }
  }

  checkChangeForCast(
    finalAsset: any,
    assets: any,
    vodAssetDto: any,
    changedArray: string[],
    assetChangeDto: any,
    metaDatahistory: any,
    currTab: number
  ) {
    let changed = false;
    if (assets['cast'] && vodAssetDto['cast']) {
      if (assets['cast'].length !== vodAssetDto['cast'].length) {
        changed = true;
      } else {
        for (let [index1, newCastObj] of vodAssetDto['cast']?.entries()) {
          let found = false;
          for (let [index2, oldCastObj] of assets['cast']?.entries()) {
            if (
              newCastObj['name'] === oldCastObj['name'] &&
              newCastObj['role'] === oldCastObj['role'] &&
              newCastObj['characterName'] === oldCastObj['characterName']
            ) {
              found = true;
              break;
            }
          }
          if (!found) {
            changed = true;
            break;
          }
        }
      }
    } else if (!assets['cast'] && vodAssetDto['cast']) {
      changed = true;
    }

    let b1: boolean = this.isStringEqual(
      assets['starring'],
      vodAssetDto['starring']
    );
    let b2: boolean = this.isStringEqual(
      assets['director'],
      vodAssetDto['director']
    );

    if (!b1 || !b2) {
      //gracenote cmp component only

      if (currTab === 1) {
        changed = true;
        this.intializeCastArray(vodAssetDto);
      }
    }

    if (changed) {
      finalAsset['cast'] = vodAssetDto['cast'];
      finalAsset['starring'] = vodAssetDto['starring'];
      finalAsset['director'] = vodAssetDto['director'];
      finalAsset['artist'] = vodAssetDto['artist'];
      assetChangeDto['field'] = 'cast';
      assetChangeDto['oldValue'] = JSON.stringify(assets['cast']);
      assetChangeDto['newValue'] = JSON.stringify(vodAssetDto['cast']);
      metaDatahistory.push({ ...assetChangeDto });
      for (var item in assetChangeDto) {
        delete assetChangeDto[item];
      }
      changedArray.push('cast');
    }
  }
  editExternalId(
    finalAsset: any,
    assets: any,
    vodAssetDto: any,
    changedArray: string[],
    assetChangeDto: any,
    metaDatahistory: any
  ) {
    var changed = false;
    if (assets['externalProvider'] && vodAssetDto['externalProvider']) {
      if (
        assets['externalProvider'].length !==
        vodAssetDto['externalProvider'].length
      ) {
        changed = true;
      } else {
        for (let [index1, newExtObj] of vodAssetDto[
          'externalProvider'
        ]?.entries()) {
          var found = false;
          for (let [index2, oldExtObj] of assets[
            'externalProvider'
          ]?.entries()) {
            if (
              newExtObj['externalProgramId'] ===
                oldExtObj['externalProgramId'] &&
              newExtObj['provider'] === oldExtObj['provider'] &&
              newExtObj['idType'] === oldExtObj['idType']
            ) {
              found = true;
              break;
            }
          }
          if (!found) {
            changed = true;
            break;
          }
        }
      }
    } else if (!assets['externalProvider'] && vodAssetDto['externalProvider']) {
      assets['externalProvider'] = [];
      changed = true;
    }

    if (changed) {
      finalAsset['externalProvider'] = vodAssetDto['externalProvider'];
      assetChangeDto['field'] = 'externalProvider';
      assetChangeDto['oldValue'] = JSON.stringify(assets['externalProvider']);
      assetChangeDto['newValue'] = JSON.stringify(
        vodAssetDto['externalProvider']
      );
      metaDatahistory.push({ ...assetChangeDto });
      for (var item in assetChangeDto) {
        delete assetChangeDto[item];
      }
      changedArray.push('externalProvider');
    }
  }

  checkForOverlappingLicenseWindow(licenseWindow: AssetLicenseWindow[]) {
    licenseWindow.sort((a, b) => {
      const startDateComp = a.availableStarting.localeCompare(
        b.availableStarting
      );
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.availableEnding.localeCompare(b.availableEnding);
    });
    for (let it = 0; it < licenseWindow.length - 1; it++) {
      if (
        licenseWindow[it].availableEnding >=
        licenseWindow[it + 1].availableStarting
      ) {
        this.toastr.error('Overlapping license window exists. ');
        const className = 'license-window' + it;
        const licenseRow: any = document.querySelectorAll(`.${className}`)[0];
        licenseRow.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
          inline: 'nearest',
        });
        licenseRow.classList.add('overlap-license-window');
        setTimeout(() => {
          licenseRow.classList.remove('overlap-license-window');
        }, 5000);
        return false;
      }
    }
    return true;
  }
  checkForOverlappingEventWindow(eventWindow: AssetEventWindowModel[]) {
    eventWindow.sort((a, b) => {
      const startDateComp = a.eventStarting.localeCompare(b.eventStarting);
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.eventEnding.localeCompare(b.eventEnding);
    });
    for (let it = 0; it < eventWindow.length - 1; it++) {
      if (eventWindow[it].eventEnding >= eventWindow[it + 1].eventStarting) {
        this.toastr.error('Overlapping Event window exists. ');
        const className = 'event-window' + it;
        const licenseRow: any = document.querySelectorAll(`.${className}`)[0];
        licenseRow.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
          inline: 'nearest',
        });
        licenseRow.classList.add('overlap-license-window');
        setTimeout(() => {
          licenseRow.classList.remove('overlap-license-window');
        }, 5000);
        return false;
      }
    }
    return true;
  }

  checkChangeForLicense(
    finalAsset: any,
    assets: any,
    vodAssetDto: any,
    changedArray: string[],
    assetChangeDto: any,
    metaDatahistory: any
  ): boolean {
    var changed = false;
    if (assets['licenseWindowList'] && vodAssetDto['licenseWindowList']) {
      if (
        assets['licenseWindowList'].length !==
        vodAssetDto['licenseWindowList'].length
      ) {
        changed = true;
      } else {
        for (let [index1, newWindow] of vodAssetDto[
          'licenseWindowList'
        ]?.entries()) {
          var found = false;
          for (let [index2, oldWindow] of assets[
            'licenseWindowList'
          ]?.entries()) {
            if (
              newWindow['availableStarting'] ===
                oldWindow['availableStarting'] &&
              newWindow['availableEnding'] === oldWindow['availableEnding']
            ) {
              found = true;
              break;
            }
          }
          if (!found) {
            changed = true;
            break;
          }
        }
      }
    } else if (
      !assets['licenseWindowList'] &&
      vodAssetDto['licenseWindowList']
    ) {
      assets['licenseWindowList'] = [];
      changed = true;
    }

    if (changed) {
      finalAsset['licenseWindowList'] = vodAssetDto['licenseWindowList'];
      assetChangeDto['field'] = 'licenseWindowList';
      assetChangeDto['oldValue'] = JSON.stringify(
        assets['licenseWindowList'].map((item: AssetLicenseWindow) => {
          return {
            availableStarting: item.availableStarting,
            availableEnding: item.availableEnding,
            licenseId: item.licenseId,
          };
        })
      );
      assetChangeDto['newValue'] = JSON.stringify(
        vodAssetDto['licenseWindowList']
      );
      metaDatahistory.push({ ...assetChangeDto });

      for (var item in assetChangeDto) {
        delete assetChangeDto[item];
      }
      changedArray.push('licenseWindowList');
    }
    return changed;
  }

  checkChangeForEvent(
    finalAsset: any,
    assets: any,
    vodAssetDto: any,
    changedArray: string[],
    assetChangeDto: any,
    metaDatahistory: any
  ): boolean {
    var changed = false;

    if (assets['eventWindowList'] && vodAssetDto['eventWindowList']) {
      if (
        assets['eventWindowList'].length !==
        vodAssetDto['eventWindowList'].length
      ) {
        changed = true;
      } else {
        for (let [index1, newWindow] of vodAssetDto[
          'eventWindowList'
        ]?.entries()) {
          var found = false;
          for (let [index2, oldWindow] of assets[
            'eventWindowList'
          ]?.entries()) {
            if (
              newWindow['eventStarting'] === oldWindow['eventStarting'] &&
              newWindow['eventEnding'] === oldWindow['eventEnding']
            ) {
              found = true;
              break;
            }
          }
          if (!found) {
            changed = true;
            break;
          }
        }
      }
    } else if (!assets['eventWindowList'] && vodAssetDto['eventWindowList']) {
      assets['eventWindowList'] = [];
      changed = true;
    }

    if (changed) {
      finalAsset['eventWindowList'] = vodAssetDto['eventWindowList'];
      assetChangeDto['field'] = 'eventWindowList';
      assetChangeDto['oldValue'] = JSON.stringify(
        assets['eventWindowList'].map((item: AssetEventWindowModel) => {
          return {
            eventStarting: item.eventStarting,
            eventEnding: item.eventEnding,
            eventId: item.eventId,
          };
        })
      );
      assetChangeDto['newValue'] = JSON.stringify(
        vodAssetDto['eventWindowList']
      );
      metaDatahistory.push({ ...assetChangeDto });

      for (var item in assetChangeDto) {
        delete assetChangeDto[item];
      }
      changedArray.push('eventWindowList');
    }
    return changed;
  }

  prepareDeeplinkPayload(bulkEditFlag: boolean, vodAssetDto: any) {
    if (!bulkEditFlag && !['SHOW', 'SEASON'].includes(vodAssetDto['type'])) {
      try {
        const payload = JSON.parse(vodAssetDto['deeplinkPayload']);
        payload['deeplink_data']['ratings'] = vodAssetDto['ratings'] || '';
        vodAssetDto['deeplinkPayload'] = JSON.stringify(payload);
      } catch (error) {
        console.error('Invalid Deeplink payload');
      }
    }
  }
  handleCastChange(obj: any, vodAssetDto: any) {
    vodAssetDto['starring'] = obj['starring']?.trim();
    vodAssetDto['artist'] = obj['artist']?.trim();
    vodAssetDto['director'] = obj['director']?.trim();
    vodAssetDto[obj['name']] = obj['cast'];
  }
  getImagePlaceholder(isDisabled: boolean) {
    return isDisabled ? `View Attachments` : `+ Add Attachments`;
  }
  setImageCount(imageFields: any, vodAssetDto: any) {
    var imageCount = 0;

    for (let item of imageFields) {
      const obj = item.value.slice(0, -8);
      if (vodAssetDto[obj]) {
        imageCount = imageCount + 1;
      }
    }
    return imageCount;
  }
  intializeCastData(assets: any, vodAssetDto: any) {
    if (!assets) return;
    if (
      !vodAssetDto['cast'] ||
      (!vodAssetDto['lockedFields']?.find(
        (item: AssetLockedField) => item.fieldName === 'STARRING'
      ) &&
        isGracenoteFeedWorker(vodAssetDto['feedWorker']))
    ) {
      vodAssetDto['cast'] = [];

      if (vodAssetDto['starring']) {
        vodAssetDto['starring'].split(',').forEach((item: any) => {
          vodAssetDto['cast'].push({
            name: item,
            role: 'actor',
          });
        });
      }
      if (vodAssetDto['artist']) {
        vodAssetDto['artist'].split(',').forEach((item: any) => {
          vodAssetDto['cast'].push({
            name: item,
            role: 'artist',
          });
        });
      }
      if (vodAssetDto['director']) {
        vodAssetDto['director'].split(',').forEach((item: any) => {
          vodAssetDto['cast'].push({
            name: item,
            role: 'director',
          });
        });
      }
      assets['cast'] = JSON.parse(JSON.stringify(vodAssetDto['cast']));
    }
  }
  intializeCastArray(vodAssetDto: any) {
    vodAssetDto['cast'] = [];

    if (vodAssetDto['starring']) {
      vodAssetDto['starring'].split(',').forEach((item: any) => {
        vodAssetDto['cast'].push({
          name: item,
          role: 'actor',
        });
      });
    }
    if (vodAssetDto['artist']) {
      vodAssetDto['artist'].split(',').forEach((item: any) => {
        vodAssetDto['cast'].push({
          name: item,
          role: 'artist',
        });
      });
    }
    if (vodAssetDto['director']) {
      vodAssetDto['director'].split(',').forEach((item: any) => {
        vodAssetDto['cast'].push({
          name: item,
          role: 'director',
        });
      });
    }
  }
  isStringEqual(s1: string, s2: string): boolean {
    const n1 = !s1 || s1.trim() === '' ? '' : s1.trim();
    const n2 = !s2 || s2.trim() === '' ? '' : s2.trim();

    return (
      (n1 === '' && n2 === '') ||
      (n1 !== '' &&
        n2 !== '' &&
        n1
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
          .sort()
          .join(',') ===
          n2
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
            .sort()
            .join(','))
    );
  }

  findUpdateSlot(windows: AssetEventWindowModel[]): AssetEventWindowModel {
    if (windows.length === 0) {
      throw new Error('The list of windows must not be empty.');
    }

    windows.sort((a, b) => {
      const startDateComp = a.eventStarting.localeCompare(b.eventStarting);
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.eventEnding.localeCompare(b.eventEnding);
    });

    let lo = 0;
    let hi = windows.length - 1;
    let resInd = hi;
    const now = new Date();

    while (lo <= hi) {
      const mid = lo + Math.floor((hi - lo) / 2);
      const start = new Date(windows[mid].eventStarting);
      const end = windows[mid].eventEnding
        ? new Date(windows[mid].eventEnding)
        : new Date(8640000000000000);

      if (now < end) {
        resInd = mid;
        if (now > start) {
          break;
        }
        hi = mid - 1;
      } else {
        lo = mid + 1;
      }
    }

    return windows[resInd];
  }

  detectImageChanges(originalImageList: any[], newImageList: any[]) {
    if (originalImageList.length !== newImageList.length) return true;

    const serialize = (obj: any) =>
      JSON.stringify(
        Object.entries(obj).sort((a, b) => a[0].localeCompare(b[0]))
      );

    const sortedOriginalImageList = originalImageList.map(serialize).sort();
    const sortedNewImageList = newImageList.map(serialize).sort();

    for (let index = 0; index < sortedOriginalImageList.length; index++) {
      if (sortedOriginalImageList[index] !== sortedNewImageList[index])
        return true;
    }
    return false;
  }

  filterVisibleBlock(assets: Asset): string[] {
    const isSportsEpisodeOrSinglevod =
      (assets.type?.toLowerCase() === AssetTypes.EPISODE.toLowerCase() ||
        assets.type?.toLowerCase() === AssetTypes.SINGLEVOD.toLowerCase()) &&
      assets.subType === 'sports event';

    const isGeoRestrictionsAvailable: boolean =
      assets?.geoRestrictions?.length > 0;
    const foundObj = notVisibleBlock.find(
      (obj: any) => obj.type === assets.type
    );

    return (
      foundObj?.value
        ?.filter((item: any) =>
          isGeoRestrictionsAvailable ? item !== 'Geo Restriction' : true
        )
        .filter((item: any) =>
          isSportsEpisodeOrSinglevod ? item !== 'Sports Information' : true
        ) ?? []
    );
  }
}
