import {
  Component,
  DestroyRef,
  ElementRef,
  inject,
  Inject,
  ViewChild,
} from '@angular/core';
import { MatButton } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AssetService } from '../../../../../../services/asset.service';
import { CommonModule } from '@angular/common';

import { MatInputModule } from '@angular/material/input';
import { FormsModule, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';

import { MatTooltip } from '@angular/material/tooltip';

@Component({
    selector: 'app-images-view-edit-modal',
    imports: [
        MatDialogModule,
        MatButton,
        CommonModule,
        FormsModule,
        MatInputModule,
        MatTooltip,
    ],
    templateUrl: './images-view-edit-modal.component.html',
    styleUrl: './images-view-edit-modal.component.scss'
})
export class ImagesViewEditModalComponent {
  private destroy = inject(DestroyRef);
  inputFormControl = new FormControl({ value: '', disabled: false });
  constructor(
    public dialogRef: MatDialogRef<ImagesViewEditModalComponent>,
    @Inject(MAT_DIALOG_DATA) public images: any,
    private assetService: AssetService,
    private toastr: CustomToastrService,
    private dialog: MatDialog
  ) {}
  @ViewChild('input') inp: ElementRef;
  file: HTMLElement | null;
  editing: boolean = this.images['editMode'];
  formData: FormData = new FormData();
  notEditable: string[] = this.images['notEditable'] ?? [];
  deletedImage: string[] = [];
  validObj: any;
  isGracenote: boolean = this.images['gracenote'] ?? false;
  imageArray: imageObj[] = [
    {
      name: 'landscapeImageBanner',
      image: this.images['imageLandscapeOriginal'],
      label: 'Landscape Banner (16:9)',
      key: 'imageLandscapeOriginal',
      type: 'landscape',
      deletable: false,
      dimensionName: 'imageLandscapeDimension',
      processedUrl: this.images['imageLandscape'],
    },
    {
      name: 'portraitImageBanner',
      image: this.images['imagePortraitOriginal'],
      label: 'Portrait Banner (2:3)',
      key: 'imagePortraitOriginal',
      type: 'portrait',
      deletable: this.images['type'] !== 'MOVIE',
      dimensionName: 'imagePortraitDimension',
      processedUrl: this.images['imagePortrait'],
    },
    {
      name: 'landscapeImageIconic',
      image: this.images['imageLandscapeIconicOriginal'],
      label: 'Landscape Iconic (16:9)',
      key: 'imageLandscapeIconicOriginal',
      type: 'landscape',
      deletable: true,
      dimensionName: 'imageLandscapeIconicDimension',
      processedUrl: this.images['imageLandscapeIconic'],
    },
    {
      name: 'portraitImageIconic',
      image: this.images['imagePortraitIconicOriginal'],
      label: 'Portrait Iconic (2:3)',
      key: 'imagePortraitIconicOriginal',
      type: 'portrait',
      deletable: true,
      dimensionName: 'imagePortraitIconicDimension',
      processedUrl: this.images['imagePortraitIconic'],
    },

    {
      name: 'landscapeImageBackdrop',
      label: 'Landscape Backdrop (16:9)',
      image: this.images['imageLandscapeBackdropOriginal'],
      key: 'imageLandscapeBackdropOriginal',
      deletable: true,
      type: 'landscape',
      dimensionName: 'imageLandscapeBackdropDimension',
      processedUrl: this.images['imageLandscapeBackdrop'],
    },
    {
      name: 'portraitImageBackdrop',
      label: 'Portrait Backdrop (2:3)',
      image: this.images['imagePortraitBackdropOriginal'],
      type: 'portrait',
      key: 'imagePortraitBackdropOriginal',
      deletable: true,
      dimensionName: 'imagePortraitBackdropDimension',
      processedUrl: this.images['imagePortraitBackdrop'],
    },
    {
      name: 'titleTreatment',
      label: 'Title Treatment',
      type: 'landscape',
      key: 'imageTitleTreatmentOriginal',
      image: this.images['imageTitleTreatmentOriginal'],
      deletable: true,
      dimensionName: 'imageTitleTreatmentDimension',
      processedUrl: this.images['imageTitleTreatment'],
    },
    // {
    //   name: 'imageCircle',
    //   image: this.images['imageCircleOriginal'],
    //   label: 'Circle Image',
    //   key: 'imageCircleOriginal',
    //   type: 'circle',
    //   deletable: true,
    //   dimensionName: '',
    // },
  ];
  ngOnInit() {
    this.formData.append('countryCode', this.images['countryCode']);
    this.formData.append('providerId', this.images['vcCpId']);
    this.formData.append('programId', this.images['contentId']);
  }

  onFileSelected(event: Event, item: imageObj) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      this.validObj = this.validateImageAspectRatio(file, item.type);
      this.validObj.subscribe((obj: any) => {
        console.log(obj);

        if (!obj.valid) {
          this.toastr.warn('Invalid Image Format');
        } else {
          const reader = new FileReader();
          reader.onload = (e) => {
            item.image = e.target?.result;
            if (this.formData.has(item.name + 'File')) {
              this.formData.set(item.name + 'File', file);
            } else {
              this.formData.append(item.name + 'File', file);
            }
            this.images[item.dimensionName] = obj.dimension;
          };
          reader.readAsDataURL(file);
        }
      });

      input.value = '';
    } else {
      item.image = null;
    }
  }
  validateImageAspectRatio(file: File, type: String): Subject<any> {
    const img = new Image();
    const reader = new FileReader();
    const valid = new Subject<{ valid: boolean; dimension: string }>();
    reader.onload = (e: any) => {
      img.src = e.target.result;
      img.onload = () => {
        const width = img.width;
        const height = img.height;
        const aspectRatio = width / height;
        const landscapeAspectRatio = 16 / 9;
        const portraitAspectRatio = 2 / 3;
        const circleAspectRatio = 1;

        if (type === 'landscape') {
          valid.next({
            valid:
              Math.abs(aspectRatio - landscapeAspectRatio) <= 0.05 &&
              width >= 928 &&
              height >= 522,
            dimension: `${width}_${height}`,
          });
        } else if (type === 'portrait') {
          valid.next({
            valid:
              Math.abs(aspectRatio - portraitAspectRatio) <= 0.05 &&
              width >= 348 &&
              height >= 522,
            dimension: `${width}_${height}`,
          });
        } else {
          valid.next({
            valid:
              Math.abs(aspectRatio - circleAspectRatio) <= 0.05 &&
              width >= 250 &&
              height >= 250,
            dimension: `${width}_${height}`,
          });
        }
      };
    };
    reader.readAsDataURL(file);

    return valid;
  }

  editImage(item: imageObj) {
    this.file = document.getElementById(item.name);
    this.file?.click();
  }

  onSave() {
    this.assetService.postImageFile(this.formData).subscribe((res: any) => {
      this.images['imageLandscapeOriginal'] = res['landscapeImageBanner'];
      this.images['imagePortraitOriginal'] = res['portraitImageBanner'];
      this.images['imageLandscapeIconicOriginal'] = res['landscapeImageIconic'];
      this.images['imagePortraitIconicOriginal'] = res['portraitImageIconic'];
      this.images['imageCircleOriginal'] = res['imageCircle'];
      this.images['imageLandscape'] = res['processedLandscapeBanner'];
      this.images['imagePortrait'] = res['processedPortraitBanner'];
      this.images['imageLandscapeIconic'] = res['processedLandscapeIconic'];
      this.images['imagePortraitIconic'] = res['processedPortraitIconic'];
      this.images['imageCircle'] = res['processedCircle'];
      this.images['saved'] = true;
      this.images['deleted'] = this.deletedImage;

      this.dialogRef.close(this.images);
    });
  }

  openDetailedView(item: any) {
    if (this.editing) {
      this.openDetailedViewImage(item);
    }
  }
  openDetailedViewImage(item: any) {
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`
        <html>
        <body style="margin:0;display:flex;justify-content:center;align-items:center;height:100vh">
         <img style="max-height:100%;max-width:100%"
        src="${this.isGracenote ? item.processedUrl : item.image}"
      />
        </body>
        </html>
        `);
      newWindow?.document.close();
    }
  }
  deleteImage(item: imageObj) {
    this.imageArray.forEach((ite) => {
      if (ite.key === item.key) {
        ite.image = null;
      }
    });
    this.images[item.key] = null;
    this.deletedImage.push(item.key);
    this.deletedImage.push(item.key.substring(0, item.key.length - 8));
    this.deletedImage.push(item.dimensionName);
  }
  ngOnDestroy() {
    this.validObj?.unsubscribe();
  }
}

type imageObj = {
  name: string;
  image: string | ArrayBuffer | null | undefined;
  label: string;
  key: string;
  type: string;
  deletable: boolean;
  dimensionName: string;
  processedUrl: string;
};
