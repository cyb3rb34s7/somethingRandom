import {
  Component,
  EventEmitter,
  Input,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';

import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../modals/app-mat-select/app-mat-select.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AssetCast } from '../../../../../../models/asset-cast-model';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';
import { MatButtonModule } from '@angular/material/button';
import { NoRecordFoundComponent } from '../../no-record-found/no-record-found.component';
import { MatLabel } from '@angular/material/form-field';

@Component({
  selector: 'app-casts',
  imports: [
    AppMatInputComponent,
    AppMatSelectComponent,
    MatTooltipModule,
    MatButtonModule,
    NoRecordFoundComponent,
    MatLabel,
  ],
  templateUrl: './casts.component.html',
  styleUrl: './casts.component.scss',
})
export class CastsComponent {
  @Input() castData: any[] = [];
  @Input() disabled: boolean = false;
  @Input() bulkEdit: boolean = false;
  @Input() type: string;
  @Input() isEditable: boolean = false;
  @Input() isCPData: boolean = false;
  @Input() rightLabel: string = '';

  castDataCopy: any[] = [];

  castCount: number = 0;

  @Output() currentValue = new EventEmitter<any>();

  @ViewChildren('matSelect', { read: AppMatSelectComponent })
  matSelects: QueryList<AppMatSelectComponent>;


  @ViewChildren('matInput', { read: AppMatInputComponent })
  matInput: QueryList<AppMatInputComponent>;

  castButton: string[] = ['All', 'Director', 'Actor', 'Artist'];
  currentItem: number = 0;

  constructor(private tostr: CustomToastrService) {}

  ngOnInit() {
    if (this.type === 'MUSIC') {
      this.castButton = ['All', 'Director', 'Actor', 'Artist'];
    } else {
      this.castButton = ['All', 'Director', 'Actor'];
    }
    this.castCount = this.castData.length;
    this.castDataCopy = this.castData.map((obj) => {
      return {
        role: obj.role,
        name: obj.name,
        characterName: obj.characterName,
      };
    });
  }

  onDropdownChange(obj: any, index: number) {
    this.castDataCopy[index].role = obj['value']?.trim().toLowerCase();
    if (
      this.castDataCopy[index].role === 'artist' ||
      this.castDataCopy[index].role === 'director'
    ) {
      this.castDataCopy[index].characterName = '';
    }
    this.emitChanges();
  }
  onFormChange(obj: any, index: number) {
    if (obj['name'] === 'name') {
      this.castDataCopy[index].name = obj['value']?.trim();
    } else if (obj['name'] === 'charName') {
      this.castDataCopy[index].characterName = obj['value']?.trim();
    }

    this.emitChanges(obj['changed']);
  }

  onDeleteClick(index: number) {
    if (!this.disabled && this.isEditable) {
      this.castDataCopy.splice(index, 1);
      this.emitChanges(true);
      this.matSelects.forEach((select) => {
        select.selectFormControl?.markAsDirty();
      });
    }
  }
  emitChanges(change?: boolean) {
    const newActorValue = this.castDataCopy
      .filter((el) => el.role === 'actor')
      .map((el) => el.name)
      .join(',');
    const newDirectorValue = this.castDataCopy
      .filter((el) => el.role === 'director')
      .map((el) => el.name)
      .join(',');
    const newArtistValue = this.castDataCopy
      .filter((el) => el.role === 'artist')
      .map((el) => el.name)
      .join(',');

    this.currentValue.emit({
      name: 'cast',
      changed: change,
      valid: true,
      starring: newActorValue,
      director: newDirectorValue,
      artist: newArtistValue,
      cast: [...this.castDataCopy],
    });
  }

  validateCastCount(val: string) {
    const actorCount = this.castDataCopy.filter(
      (el) => el.role === 'actor'
    ).length;
    const artistCount = this.castDataCopy.filter(
      (el) => el.role === 'artist'
    ).length;
    const directorCount = this.castDataCopy.filter(
      (el) => el.role === 'director'
    ).length;
    if (actorCount >= 10 && val === 'actor') {
      this.tostr.warn('Maximum 10 actors allowed');
      return false;
    } else if (artistCount >= 10 && val === 'artist') {
      this.tostr.warn('Maximum 10 artists allowed');
      return false;
    } else if (directorCount >= 10 && val === 'director') {
      this.tostr.warn('Maximum 10 directors allowed');
      return false;
    }
    return true;
  }

  capitalizeWord(word: any) {
    if (!word) return '';
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }
  getItems(): any[] {
    return this.type === 'MUSIC'
      ? ['Actor', 'Director', 'Artist']
      : ['Actor', 'Director'];
  }
  onCastClick(index: number) {
    this.currentItem = index;
  }
  visibilityCheck(index: number) {
    if (this.currentItem === 0) {
      this.castCount = this.castDataCopy.length;
      return false;
    }
    this.castCount = this.castDataCopy.filter(
      (item) =>
        item.role.toLowerCase() ===
        this.castButton[this.currentItem].toLowerCase()
    ).length;

    if (
      this.castDataCopy[index].role.toLowerCase() ===
      this.castButton[this.currentItem].toLowerCase()
    ) {
      return false;
    } else {
      return true;
    }
  }
  addEmptyCast() {
    this.castDataCopy.push({ role: '', name: '' } as AssetCast);
  }

  triggerValidation() {
    this.matInput.forEach(input => input.triggerElement());
    this.matSelects.forEach(select => select.triggerElement());
  }
}
