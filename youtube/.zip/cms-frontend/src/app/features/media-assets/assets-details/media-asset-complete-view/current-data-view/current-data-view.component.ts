import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  ElementRef,
  EventEmitter,
  inject,
  Input,
  Output,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { MatAccordianComponent } from '../../../../../mat-components/mat-accordian/mat-accordian.component';
import { AppMatSelectComponent } from '../modals/app-mat-select/app-mat-select.component';
import { CastsComponent } from './casts/casts.component';
import { NoRecordFoundComponent } from '../no-record-found/no-record-found.component';
import { ExternalIdsComponent } from './external-ids/external-ids.component';
import {
  imageFields,
  assetBasicInformation,
  assetSpecifications,
  playBackUriEditable,
  validCheck,
  assetDetails,
  licenseDetail,
  externalProvider,
  mandatoryFields,
  notVisibleFields,
  notVisibleBlock,
  notEditableInSingleEdit,
  imageResponseKey,
  assetViewTitle,
} from '../../asset-constants/asset-fields-constants';
import { MatExpansionModule } from '@angular/material/expansion';
import { AssetHelperService } from '../utils/asset-helper.service';
import { VideoPlayerModalComponent } from '../modals/video-player-modal/video-player-modal.component';
import { DeeplinkInfoModalComponent } from '../modals/deeplink-info-modal/deeplink-info-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatDialog } from '@angular/material/dialog';
import { DateTimePickerComponent } from '../date-time-picker/date-time-picker.component';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { AvailablePlatformComponent } from '../available-platform/available-platform.component';
import { MatRadioModule } from '@angular/material/radio';
import { SeriesDetailsComponent } from '../series-details/series-details.component';
import { SeasonDetailsComponent } from '../season-details/season-details.component';
import { AllSeasonsComponent } from '../all-seasons/all-seasons.component';
import { SIDE_NAV_ROUTES } from '../../../../../constants/app-consts';
import { Router } from '@angular/router';
import { DrmComponent } from '../drm/drm.component';
import { DatePickerComponent } from '../date-picker/date-picker.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { LicenseWindowComponent } from './license-window/license-window.component';
import { EventWindowComponent } from './event-window/event-window.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MultiImageViewEditModalComponent } from '../modals/multi-image-view-edit-modal/multi-image-view-edit-modal.component';
import { AssetLicenseWindow } from '../../../../../models/asset-license-window-model';
import { isGracenoteFeedWorker } from '../utils/asset-feedworker-util';
import { SportsInfoComponent } from './sports-info/sports-info.component';
import { GeoRestrictionComponent } from './geo-restriction/geo-restriction.component';
import { ParentalRatingsComponent } from './parental-ratings/parental-ratings.component';
import { AssetService } from '../../../../../services/asset.service';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { StateStoreService } from '../../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../../constants/store-consts';

@Component({
  selector: 'app-current-data-view',
  providers: [],
  imports: [
    AppMatInputComponent,
    MatAccordianComponent,
    AppMatSelectComponent,
    CastsComponent,
    NoRecordFoundComponent,
    ExternalIdsComponent,
    MatExpansionModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    AvailablePlatformComponent,
    MatRadioModule,
    SeriesDetailsComponent,
    SeasonDetailsComponent,
    AllSeasonsComponent,
    DrmComponent,
    DatePickerComponent,
    MatTooltipModule,
    LicenseWindowComponent,
    EventWindowComponent,
    MatSlideToggleModule,
    SportsInfoComponent,
    GeoRestrictionComponent,
    ParentalRatingsComponent,
  ],
  templateUrl: './current-data-view.component.html',
  styleUrl: './current-data-view.component.scss',
})
export class CurrentDataViewComponent {
  currentWindowItem: number = 0;
  @Input() currentVodData: any = {};
  @Output() currentVodDataChange = new EventEmitter<any>();
  @Input() isDisabled: boolean = true;
  @Input() formChanged: boolean = false;
  @Output() formChangedChange = new EventEmitter<boolean>();
  @Input() sectionIndex: number = 0;
  @Output() sectionIndexChange = new EventEmitter<number>();
  @Input() availablePlatform: any = {};
  @Output() availablePlatformChange = new EventEmitter<number>();
  @Input() isResponseOk: boolean = false;
  @Input() assets: any;
  @Input() seriesData: any;
  @Input() bulkEditFlag: boolean;

  @Input() language: any;
  @Input() videoQualityList: any;
  @Input() bulkEditFields: any;
  @Input() seasonCount: any;
  imageFields = imageFields;
  imageResponseKey = imageResponseKey;

  observer: any;
  @ViewChildren('accordianRef', { read: ElementRef })
  accordianRefs: QueryList<ElementRef>;

  @ViewChildren('matInput', { read: AppMatInputComponent })
  matInputs: QueryList<AppMatInputComponent>;

  @ViewChildren('matSelect', { read: AppMatSelectComponent })
  matSelects: QueryList<AppMatSelectComponent>;

  @ViewChild('castComp') castComp!: CastsComponent;
  @ViewChild('externalIdComp') externalIdComp!: ExternalIdsComponent;
  @ViewChild('licenseComp') licenseComp!: LicenseWindowComponent;
  @ViewChild('eventWindowComp') eventWindowComp!: EventWindowComponent;
  @ViewChild('parentalRatingsComp') parentalRatingsComp!: ParentalRatingsComponent;

  @Input() genres: any[];
  @Input()
  externalIdFlag: boolean = true;

  @Input() parentalRatings: any = [];
  seriesButton: string[] = ['Series', `Episode's Season`, 'All Seasons'];
  selectedRadioButton: number = 0;
  radioChange(obj: any) {
    this.selectedRadioButton = obj['value'];
  }

  constructor(
    public assetHelperService: AssetHelperService,
    public dialog: MatDialog,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private assetService: AssetService,
    private toaster: CustomToastrService,
    private storeService: StateStoreService
  ) {}

  private destroy = inject(DestroyRef);
  mandatoryFields: string[] = [];
  @Input() nonEditableFields: string[] = [];
  @Output() nonEditableFieldsChange = new EventEmitter<string[]>();
  notEditableFieldsSingleEdit: string[] = [];
  notVisibleFields: string[] = [];
  assetBasicInformation = assetBasicInformation;
  assetSpecifications = assetSpecifications;
  playbackUriEditable = playBackUriEditable;
  validCheck = validCheck;
  assetDetails = assetDetails;
  licenseDetail = licenseDetail;
  externalProvider = externalProvider;
  notVisibleBlock: string[] = [];
  assetViewTitle: string[] = assetViewTitle;
  arrSectionTops: number[] = [];
  @Input()
  attributesList: string[] = [];

  ngOnInit() {
    this.mandatoryFields =
      mandatoryFields.find((obj) => obj.type === this.currentVodData['type'])
        ?.value ?? [];
    this.notVisibleFields =
      notVisibleFields.find((obj) => obj.type === this.currentVodData['type'])
        ?.value ?? [];

    this.notVisibleBlock = this.assetHelperService.filterVisibleBlock(
      this.assets
    );

    this.notEditableFieldsSingleEdit =
      notEditableInSingleEdit.find(
        (obj) => obj.type === this.currentVodData['type']
      )?.value ?? [];
  }

  ngAfterViewInit() {
    const lastAcc = this.accordianRefs.get(this.accordianRefs.length - 1)
      ?.nativeElement as HTMLElement;
    const scrollCont = document.querySelector(
      'app-current-data-view #assetView'
    ) as HTMLElement;
    const lastPanel = lastAcc.querySelector(
      'mat-expansion-panel'
    ) as HTMLElement;
    if (lastAcc.offsetHeight < scrollCont.offsetHeight) {
      lastPanel.style.minHeight = `${scrollCont.offsetHeight - 15}px`;
    }
    this.arrSectionTops = [];
    this.setImageLabelStyle();
  }

  setImageLabelStyle() {
    const inp = document.querySelector(
      '#image-input .mat-mdc-form-field-infix'
    ) as HTMLElement;
    if (inp) {
      inp.setAttribute(
        'style',
        `--after-content: "${this.assetHelperService.setImageCount(
          imageFields,
          this.currentVodData
        )}";`
      );
    }
  }

  timer: any;
  onScroll(e: Event) {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (!this.arrSectionTops.length) {
      const firstAcc = this.accordianRefs.get(0)?.nativeElement as HTMLElement;
      const parentOt = firstAcc.parentElement?.offsetTop;
      this.arrSectionTops = [
        firstAcc.offsetTop - parentOt! + firstAcc.offsetHeight + 15,
      ];

      for (let j = 1; j < this.accordianRefs.length; j++) {
        let h = (this.accordianRefs.get(j)?.nativeElement as HTMLElement)
          .offsetHeight;
        this.arrSectionTops[j] = this.arrSectionTops[j - 1] + h + 15;
      }
    }
    this.timer = setTimeout(() => {
      let scrl = e.target as HTMLElement;
      let st = Math.floor(scrl.scrollTop);

      const ind = this.arrSectionTops.findIndex((t) => t > st);
      this.sectionIndex = ind >= 0 ? ind : this.arrSectionTops.length - 1;

      this.sectionIndexChange.emit(this.sectionIndex);
    }, 50);
  }

  openVideo() {
    this.videoVideoModal(this.currentVodData);
  }

  openDeeplinkModal() {
    const dialogRef = this.dialog.open(DeeplinkInfoModalComponent, {
      data: { deeplinkData: this.currentVodData['deeplinkPayload'] },
      panelClass: 'deeplink-info-modal',
      width: '600px',
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {});
  }
  videoVideoModal(data: any) {
    const dialogRef = this.dialog.open(VideoPlayerModalComponent, {
      data: { ...data },
      panelClass: 'media-assets-video-modal',
      position: { right: '0' },
      height: '100%',
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        console.log(result);
      });
  }
  openDatePicker(date: any) {
    if (this.isDisabled) return;
    const dialogRef = this.dialog.open(DateTimePickerComponent, {
      data: {
        date: this.assetHelperService.getDateTimeWithoutTZ(
          this.currentVodData[date]
        ),
      },
      panelClass: 'date-time-picker',
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        const res =
          this.assetHelperService.getDateTimeWithTZ(result) ??
          this.currentVodData[date];
        if (res !== this.currentVodData[date]) {
          this.formChanged = true;
          this.currentVodData[date] = res;
          this.formChangedChange.emit(this.formChanged);
        }
        this.currentVodDataChange.emit(this.currentVodData);
        this.cdr.detectChanges();
      });
  }
  checkValidationofBulkEdit(key: string): boolean {
    if (!this.bulkEditFlag) {
      return (
        this.isDisabled ||
        this.nonEditableFields.includes(key) ||
        this.notEditableFieldsSingleEdit.includes(key)
      );
    } else {
      if (key === 'seasonNo' && this.seasonCount >= 2) {
        return true;
      } else if (this.bulkEditFields.includes(key)) {
        return this.isDisabled;
      } else {
        return true;
      }
    }
  }
  onLicenseHistoryClick() {
    sessionStorage.setItem('mainTitle', this.assets['mainTitle']);
    sessionStorage.setItem('vodType', this.assets['type']);
    sessionStorage.setItem(
      `${this.currentVodData['contentId']}`,
      JSON.stringify(this.currentVodData)
    );

    sessionStorage.setItem(
      `${this.currentVodData['contentId']}-status`,
      this.isDisabled ? 'Not-Editing' : 'Editing'
    );

    sessionStorage.setItem(
      `${this.currentVodData['contentId']}-change`,
      this.formChanged ? 'Change' : 'No-Change'
    );

    this.router.navigate([SIDE_NAV_ROUTES.LICENSE_HISTORY.route_link], {
      queryParams: {
        assetId: this.assets['contentId'],
      },
    });
  }
  onGeorestrictionClick() {
    const masterdata = this.storeService.getStoreState(
      STORE_CONSTS.ASSET_MASTER_DATA
    );

    const path =
      masterdata?.zipcodeBucketPath + this.currentVodData.countryCode + '/';
    const fileName = masterdata?.zipcodeFileName;
    this.assetService.downloadFileFromS3(path, fileName).subscribe({
      next: (blob) => {
        if (blob.size > 0) {
          const a = document.createElement('a');
          const objectUrl = URL.createObjectURL(blob);
          a.href = objectUrl;
          a.download = fileName;
          a.click();
          URL.revokeObjectURL(objectUrl);
          this.toaster.success('Zipcode File Downloaded Successfully!');
        } else {
          this.toaster.warn('File Not Found,Please try again later..');
        }
      },
      error: (error) => {
        this.toaster.warn('File Not Found,Please try again later..');
      },
    });
  }
  onPlatformChange(event: any) {
    this.availablePlatform = { ...event };
    this.formChanged = true;
    this.formChangedChange.emit(this.formChanged);
    this.availablePlatformChange.emit(this.availablePlatform);
  }
  onViewImages() {
    if (this.bulkEditFlag) return;
    this.viewImagesAndEditModal();
  }

  viewImagesAndEditModal() {
    //have to send the all image data from here
    var images: any = {};
    images['imageLandscapeOriginal'] =
      this.currentVodData['imageLandscapeOriginal'];
    images['imagePortraitOriginal'] =
      this.currentVodData['imagePortraitOriginal'];
    images['imageCircleOriginal'] = this.currentVodData['imageCircleOriginal'];
    images['imagePortraitIconicOriginal'] =
      this.currentVodData['imagePortraitIconicOriginal'];
    images['imageLandscapeIconicOriginal'] =
      this.currentVodData['imageLandscapeIconicOriginal'];

    images['notEditable'] = this.externalIdFlag
      ? [...this.nonEditableFields]
      : [];

    const newDialogRef = this.dialog.open(MultiImageViewEditModalComponent, {
      data: {
        ...images,
        editMode: this.isDisabled,
        ...this.currentVodData,
        gracenote:
          isGracenoteFeedWorker(this.currentVodData['feedWorker']) ||
          this.nonEditableFields.includes('imageLandscape'),
      },
      panelClass: 'view-edit-multi-image-modal',
      disableClose: true,
    });

    //Contains the processed image data after save
    newDialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((image) => {
        if (image['saved']) {
          for (let item of this.imageResponseKey) {
            if (!image[item] && image['deleted'].includes(item)) {
              this.currentVodData[item] = '';
              this.currentVodData[item + 'Dimension'] = '';
            } else {
              this.currentVodData[item] =
                image[item] ?? this.currentVodData[item];
            }
          }

          this.currentVodData['assetImageList'] = image['assetImageList'];

          this.formChanged = true;
          this.formChangedChange.emit(this.formChanged);
          this.currentVodDataChange.emit(this.currentVodData);
          this.setImageLabelStyle();
          this.cdr.detectChanges();
        }
      });
  }
  handleLicenseWindowChange(obj: any) {
    this.currentVodData[obj['name']] = obj[obj['name']];
    this.currentVodData[obj['name']].sort(
      (a: AssetLicenseWindow, b: AssetLicenseWindow) => {
        const startDateComp = a.availableStarting.localeCompare(
          b.availableStarting
        );
        if (startDateComp !== 0) {
          return startDateComp;
        }
        return a.availableEnding.localeCompare(b.availableEnding);
      }
    );
    const len: number = this.currentVodData[obj['name']].length;
    const firstWindow: AssetLicenseWindow = this.currentVodData[obj['name']][0];
    const lastWindow: AssetLicenseWindow =
      this.currentVodData[obj['name']][len - 1];
    this.currentVodData['totalAvailableStarting'] =
      firstWindow?.availableStarting;
    this.currentVodData['totalAvailableEnding'] = lastWindow?.availableEnding;
  }

  handleEventWindowChange(obj: any) {
    this.currentVodData[obj['name']] = obj[obj['name']];
    if (!['SHOW', 'SEASON'].includes(this.currentVodData['type'])) {
      try {
        const payload = JSON.parse(this.currentVodData['deeplinkPayload']);
        if (
          !this.currentVodData['eventWindowList'] ||
          this.currentVodData['eventWindowList'].length === 0
        ) {
          delete payload['deeplink_data']['event'];
          delete payload['deeplink_data']['event_info'];
        } else if (this.currentVodData['eventWindowList'].length > 0) {
          payload['deeplink_data']['event'] = 'Y';
          var activeEventWindow = this.assetHelperService.findUpdateSlot(
            this.currentVodData['eventWindowList']
          );

          var eventInfo = {
            event_starttime: activeEventWindow.eventStarting,
            event_endtime: activeEventWindow.eventEnding,
          };
          payload['deeplink_data']['event_info'] = { ...eventInfo };
        }
        this.currentVodData['deeplinkPayload'] = JSON.stringify(payload);
      } catch (error) {
        console.error('Invalid Deeplink payload');
      }
    }
  }
  getGracenoteLabel(item: string): string {
    if (
      item != 'casts' &&
      isGracenoteFeedWorker(this.currentVodData['feedWorker']) &&
      this.nonEditableFields.includes(item)
    ) {
      return 'Gracenote';
    } else if (
      item == 'casts' &&
      isGracenoteFeedWorker(this.currentVodData['feedWorker']) &&
      this.nonEditableFields.includes('starring')
    ) {
      return 'Gracenote';
    }
    return '';
  }

  onToggleChange(evt: any) {
    this.currentVodData['onDeviceTrans'] = evt.checked ? 'Y' : 'N';
    this.formChanged = true;
    this.formChangedChange.emit(this.formChanged);
    this.currentVodDataChange.emit(this.currentVodData);
    this.cdr.detectChanges();
  }
  dropDownValueChange(obj: any) {
    if (obj['name'] === 'genres' || obj['name'] === 'attributes') {
      this.currentVodData[obj['name']] = obj['value']?.join(',');
    } else if (obj['name'] === 'ratings') {
      this.currentVodData[obj['name']] = obj['value']?.trim();
      this.currentVodData['parentalRatings'] = obj['parentalVal'];
      this.formChanged = true;
      this.formChangedChange.emit(this.formChanged);
      this.assetHelperService.prepareDeeplinkPayload(
        false,
        this.currentVodData
      );
    } else {
      this.currentVodData[obj['name']] = obj['value']?.trim();
    }
    const ob = this.validCheck.find((item) => item.name === obj['name']);
    if (ob) {
      ob.status = obj['valid'];
    }
    this.currentVodDataChange.emit(this.currentVodData);
    this.cdr.detectChanges();
  }
  onFormChange(obj: any) {
    if (obj['name'] === 'cast') {
      this.assetHelperService.handleCastChange(obj, this.currentVodData);
    } else if (obj['name'] === 'licenseWindowList') {
      this.handleLicenseWindowChange(obj);
    } else if (obj['name'] === 'eventWindowList') {
      this.handleEventWindowChange(obj);
    } else if (obj['name'] === 'externalProvider') {
      this.currentVodData[obj['name']] = obj['value'];
    } else if (obj['value'] !== undefined && obj['value'] !== null) {
      if (typeof obj['value'] === 'number' && !isNaN(obj['value'])) {
        this.currentVodData[obj['name']] = obj['value'];
      } else {
        this.currentVodData[obj['name']] = obj['value']?.trim();
      }
    }

    this.formChanged = !!(this.formChanged || obj['changed']);

    this.formChangedChange.emit(this.formChanged);
    const ob = this.validCheck.find((item) => item.name === obj['name']);

    if (ob) {
      ob.status = obj['valid'];
    }

    this.currentVodDataChange.emit(this.currentVodData);
    this.cdr.detectChanges();
  }

  isCastEditable(): boolean {
    return !this.nonEditableFields.includes('starring');
  }

  markInputFieldsAsTouched() {
    this.matInputs.forEach((input) => {
      input.inputFormControl?.markAllAsTouched();
    });
    this.matSelects.forEach((select) => {
      select.selectFormControl?.markAllAsTouched();
    });
  }

  triggerSaveValidation() {
    this.triggerChildComponentValidation();
  }

  private triggerChildComponentValidation() {
    // Trigger validation in child components
    this.castComp?.triggerValidation();
    this.externalIdComp?.triggerValidation();
    this.licenseComp?.triggerValidation();
    this.eventWindowComp?.triggerValidation();
    this.parentalRatingsComp?.triggerValidation();
    
    // Also trigger the current component's matInputs and matSelects
    this.matInputs.forEach(input => input.triggerElement());
    this.matSelects.forEach(select => select.triggerElement());
  }
}
