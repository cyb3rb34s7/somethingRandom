import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { Asset } from '../../../../../../models/asset-model';

@Component({
  selector: 'app-sports-info',
  imports: [AppMatInputComponent],
  templateUrl: './sports-info.component.html',
  styleUrl: './sports-info.component.scss',
})
export class SportsInfoComponent {
  @Input() vodData: Asset;
  @Input() isEditMode: boolean;
  @Output() currentValue: EventEmitter<any> = new EventEmitter<any>();

  constructor() {}

  ngOnInit() {}
  onChange(evt: Event) {
    this.currentValue.emit(evt);
  }
}
