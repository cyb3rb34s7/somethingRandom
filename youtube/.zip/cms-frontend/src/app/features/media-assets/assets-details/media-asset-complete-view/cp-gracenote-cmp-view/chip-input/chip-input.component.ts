import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatChipInputEvent, MatChipsModule } from '@angular/material/chips';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';

@Component({
    selector: 'app-chip-input',
    imports: [
        MatButtonModule,
        MatChipsModule,
        MatSelectModule,
        FormsModule,
        MatRadioModule,
        ReactiveFormsModule,
    ],
    templateUrl: './chip-input.component.html',
    styleUrl: './chip-input.component.scss'
})
export class ChipInputComponent {
  @Input() dataArray: string[] = [];
  @Input() disabled: boolean = true;
  @Input() name: string;
  @Output() currentValue = new EventEmitter<any>();
  constructor(private toster: CustomToastrService) {}
  data: string[] = [];
  ngOnInit() {
    this.data = [...this.dataArray];
  }

  formControl = new FormControl(['angular']);

  removeKeyword(keyword: string) {
    const index = this.data.indexOf(keyword);
    if (index >= 0) {
      this.data.splice(index, 1);
      this.emitChange();
    }
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    if (this.data.length >= 10) {
      this.toster.warn('Maximum 10 cast allowed');
      return;
    }
    if (this.data.includes(value)) {
      this.toster.warn(`${value} already exits`);
      return;
    }
    if (value) {
      this.data.push(value);
      this.emitChange();
    }
    event.chipInput!.clear();
  }

  emitChange() {
    const obj = {
      name: this.name,
      value: this.data.join(','),
      changed: true,
      valid: true,
    };
    this.currentValue.emit(obj);
  }
}
