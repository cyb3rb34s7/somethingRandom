import { DragScrollDirective } from './drag-scroll.directive';

describe('DragScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new DragScrollDirective();
    expect(directive).toBeTruthy();
  });
});
