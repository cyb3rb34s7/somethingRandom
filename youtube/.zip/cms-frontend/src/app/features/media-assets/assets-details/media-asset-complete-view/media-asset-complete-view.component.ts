import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  ElementRef,
  HostListener,
  inject,
  Input,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDialog } from '@angular/material/dialog';

import { CancelConfirmationModalComponent } from './modals/cancel-confirmation-modal/cancel-confirmation-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AssetService } from '../../../../services/asset.service';
import { User } from '../../../../models/user-model';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { UserService } from '../../../../services/user.service';
import { plainToInstance } from 'class-transformer';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { BulkEditDialogComponent } from '../bulk-edit-dialog/bulk-edit-dialog.component';
import assetStaticJson from '../../../../../assets/schemas/StaticAssetContent.json';

import {
  assetBasicInformation,
  assetDetails,
  assetSpecifications,
  imageFields,
  licenseDetail,
  mandatoryFields,
  bulkEditMandatoryFields,
  playBackUriEditable,
  validCheck,
  bulkEditEditableFields,
  videoQualityList,
  notVisibleFields,
  notEditableInSingleEdit,
  notVisibleBlock,
  imageResponseKey,
  ValidatorsCustom,
  assetViewTitle,
  gracenoteFields,
  sportsInformation,
} from '../asset-constants/asset-fields-constants';
import { ShowHierarchy } from '../../../../models/show-hierarchy';
import { MatMenuModule } from '@angular/material/menu';
import { MatFormFieldModule } from '@angular/material/form-field';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';

import { CustomToastrService } from '../../../../services/custom-toastr.service';
import { MatRadioModule } from '@angular/material/radio';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AssetHelperService } from './utils/asset-helper.service';
import { AvailablePlatform } from '../../../../models/asset-available-platform-model';
import { CurrentDataViewComponent } from './current-data-view/current-data-view.component';

import {
  CpGracenoteCmpViewComponent,
  FieldMappings,
} from './cp-gracenote-cmp-view/cp-gracenote-cmp-view.component';
import { NoRecordFoundComponent } from './no-record-found/no-record-found.component';
import { AssetImageModel } from '../../../../models/asset-image-model';
import {
  cmsFeedWorkersList,
  deltaFeedWorkersList,
  isGracenoteFeedWorker,
} from './utils/asset-feedworker-util';
import { AssetValidatorService } from './utils/asset-validator.service';
import { forkJoin, of } from 'rxjs';

@Component({
  selector: 'app-media-asset-complete-view',
  imports: [
    MatButtonModule,
    MatExpansionModule,
    MatStepperModule,
    MatMenuModule,
    FormsModule,
    MatSelectModule,
    MatRadioModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    CommonModule,
    MatTooltipModule,
    CurrentDataViewComponent,
    CpGracenoteCmpViewComponent,
    NoRecordFoundComponent,
  ],
  templateUrl: './media-asset-complete-view.component.html',
  styleUrls: [
    './media-asset-complete-view.component.scss',
    './media-asset-complete-view.component.extended.scss',
  ],
  providers: [],
})
export class MediaAssetCompleteViewComponent {
  currentItem: number = 0;

  @Input() assetKeys: any;

  routeConstants = SIDE_NAV_ROUTES;
  user: User;
  editMode: boolean = false;
  formChanged: boolean = false;
  licenseChanged: boolean = false;
  eventchanged: boolean = false;
  platformChanged: boolean = false;
  externalIdFlag: boolean = false;
  assets: any;
  finalAsset: any = {};
  vodAssetDto: any = {};
  assetChangeHistory: any = {};
  licenseHistory: any = {};
  eventHistory: any = {};
  metaDatahistory: any[] = [];
  assetChangeDto: any = {};
  metadataChangedObject: any = {};
  statushistory: any = {};
  changedArray: string[] = [];
  mandatoryFields: string[] = [];
  nonEditableFields: string[] = [];
  notEditableFieldsSingleEdit: string[] = [];
  notVisibleFields: string[] = [];
  finalData: any = {};
  languageList: { text: string; code: string }[] = [];
  language: string[] = [];
  genres: string[] = [];
  imageFields = imageFields;
  playbackUriEditable = playBackUriEditable;
  validCheck = validCheck;
  @Input() panelOpenState = true;
  @Input() isDisabled: boolean = true;
  @Input() index: number;
  @Input() isSubmitted: boolean;
  observer: any;
  imageCount: number = 0;
  sectionIndex: number = 0;
  episodeData: ShowHierarchy[] = [];
  episodeDataDisplay: string = '';
  contentIds: string[] = [];
  bulkEditFlag: boolean = false;
  bulkEditFields: string[] = [];
  videoQualityList = videoQualityList;
  userName: string = '';
  parentalRatings: any[] = [];
  externalValidator: ValidatorsCustom = { minLength: 1 };
  seasonCount: number = 0;
  notVisibleBlock: string[] = [];
  visibleBlockLabels: string[] = [];
  availablePlatform: AvailablePlatform = {
    type: 'common',
    tvValues: [],
    tvItems: [],
    mobileItems: [],
    mobileValues: [],
    fHubItems: [],
    fHubValues: [],
    webItems: [],
    webValues: [],
  };
  isResponseOk: boolean = false;
  imageResponseKey = imageResponseKey;
  canProceedWithSave: boolean = true;
  isCompleteCpData: boolean | any = null;

  private destroy = inject(DestroyRef);

  viewButton: string[] = ['Current Data', 'Gracenote Comparison'];
  assetViewTitle: any = assetViewTitle;
  assetMasterData: any = null;
  private cdr = inject(ChangeDetectorRef);
  public assetValidatorService = inject(AssetValidatorService);
  constructor(
    private assetService: AssetService,
    private router: Router,
    private route: ActivatedRoute,
    private storeService: StateStoreService,
    public dialog: MatDialog,
    private userService: UserService,
    private toastr: CustomToastrService,
    public assetHelperService: AssetHelperService
  ) {}

  @ViewChildren('accordianRef', { read: ElementRef })
  accordianRefs: QueryList<ElementRef>;

  @ViewChild('currentDataView') currentDataViewRef!: CurrentDataViewComponent;

  @HostListener('keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    const target = event?.target as HTMLElement;
    const isNotAllowed =
      target?.classList?.contains('mat-mdc-form-field-textarea-control') ||
      target?.classList?.contains('mat-mdc-chip-input');
    if (event.key === 'Enter' && this.formChanged && !isNotAllowed) {
      this.onSubmitForm(this.currentItem);
    }
  }

  ngOnInit() {
    document.body.classList.add('asset-details-view');
    this.user = this.storeService.getStoreState(STORE_CONSTS.CURRENT_USER);
    if (!this.user.userId) {
      this.fetchUserData();
    }

    this.userName = this.user?.firstName + ' ' + this.user?.lastName;
    this.onViewClick(0);
  }
  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  intializeDropDownValues() {
    this.assetMasterData = this.storeService.getStoreState(
      STORE_CONSTS.ASSET_MASTER_DATA
    );
    const payload = {
      contentId: this.assets['contentId'],
      vcCpId: this.assets['vcCpId'],
      countryCode: this.assets['countryCode'],
      type: this.assets['type'],
    };
    forkJoin({
      res: this.assetService.getViewFilters(payload),
      masterData: this.assetMasterData
        ? of(this.assetMasterData)
        : this.assetService.getAssetStaticJsonFromS3(),
    })
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result: any) => {
        const res = result.res;
        const masterData = result.masterData;
        this.languageList = res['languages'] ?? [];
        this.language = this.languageList.map((item) => item.text);

        res['platforms']?.forEach(
          (item: { type: string; platform: string }) => {
            if (item.type === 'TV') {
              this.availablePlatform.tvItems.push({
                platformName: item.platform,
              });
            } else if (item.type === 'MOB') {
              this.availablePlatform.mobileItems.push({
                platformName: item.platform,
              });
            } else if (item.type === 'FHUB') {
              this.availablePlatform.fHubItems.push({
                platformName: item.platform,
              });
            } else if (item.type === 'WEB') {
              this.availablePlatform.webItems.push({
                platformName: item.platform,
              });
            }
          }
        );
        this.parentalRatings = res['parentalRatings'];
        this.isResponseOk = true;
        this.assetMasterData = masterData
          ? { ...masterData }
          : { ...assetStaticJson };

        this.storeService.setStoreState(
          STORE_CONSTS.ASSET_MASTER_DATA,
          this.assetMasterData
        );

        this.genres =
          this.assets['type'] === 'MUSIC'
            ? this.assetMasterData.genres.music
            : this.assetMasterData.genres.others;
      });
  }
  intializePlatformValues() {
    this.availablePlatform = {
      type: 'common',
      tvValues: [],
      tvItems: [],
      mobileItems: [],
      mobileValues: [],
      fHubItems: [],
      fHubValues: [],
      webItems: [],
      webValues: [],
    };
    this.availablePlatform.type = this.assets['platformTag'];
    this.assets['platformTagData']?.forEach(
      (item: { type: string; platform: string; alias: string }) => {
        if (item.type === 'TV') {
          this.availablePlatform.tvValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'MOB') {
          this.availablePlatform.mobileValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'FHUB') {
          this.availablePlatform.fHubValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'WEB') {
          this.availablePlatform.webValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        }
      }
    );
  }

  onEditClick() {
    this.isDisabled = !this.isDisabled;
  }
  onSubmitForm(currTab: number) {
    // Trigger validation in child components before save
    this.currentDataViewRef?.triggerSaveValidation();
    this.onSaveClick(this.assets, this.vodAssetDto, currTab);
  }

  onSaveClick(oldValue: any, newValue: any, currTab: number) {
    this.finalAsset = {};
    
    const validationResult: { valid: boolean; errors: string[] | null } =
      this.assetValidatorService.validateAsset(newValue);
    if (!validationResult.valid) {
      this.toastr.errorList(validationResult.errors ?? [], 10000);
      return;
    }

    var toasterError: string[] = [];
    var valid: boolean = true;
    if (
      !this.assetHelperService.validateCastOnSave(newValue['cast']) ||
      !this.assetHelperService.validateDuplicateEntryForCast(newValue['cast'])
    ) {
      return;
    }
    if (!this.assetHelperService.checkDuplicateExternalId(newValue, currTab)) {
      return;
    }

    this.currentDataViewRef?.markInputFieldsAsTouched();

    if (this.checkValidation() || !valid) {
      this.assetHelperService.scrollToInvalidField();
    }

    this.changedArray = [];
    this.metaDatahistory = [];
    for (let item of assetBasicInformation) {
      this.changeDetectorFn(item, oldValue, newValue);
    }
    for (let item of assetSpecifications) {
      this.changeDetectorFn(item, oldValue, newValue);
    }
    for (let item of assetDetails) {
      this.changeDetectorFn(item, oldValue, newValue);
    }

    for (let item of sportsInformation) {
      this.changeDetectorFn(item, oldValue, newValue);
    }
    for (let item of licenseDetail) {
      if (
        newValue[item.value] !== undefined &&
        newValue[item.value] !== String(oldValue[item.value])
      ) {
        if (!newValue[item.value] && !oldValue[item.value]) continue;
        if (item.value === 'licenseWindowList') {
          this.licenseChanged = this.assetHelperService.checkChangeForLicense(
            this.finalAsset,
            this.assets,
            this.vodAssetDto,
            this.changedArray,
            this.assetChangeDto,
            this.metaDatahistory
          );
        } else if (item.value === 'eventWindowList') {
          if (!this.assets['eventWindowList'])
            this.assets['eventWindowList'] = [];

          this.eventchanged = this.assetHelperService.checkChangeForEvent(
            this.finalAsset,
            this.assets,
            this.vodAssetDto,
            this.changedArray,
            this.assetChangeDto,
            this.metaDatahistory
          );
        } else {
          this.finalAsset[item.value] = this.vodAssetDto[item.value];
          this.setAssetChangeDto(item.value, oldValue, newValue);
          this.changedArray.push(item.key);
          this.licenseChanged = true;
          this.eventchanged = true;
        }

        //licensehistory
        if (this.licenseChanged === true) {
          this.licenseHistory['releaseDate'] = this.assets['availableStarting'];
          this.licenseHistory['expiryDate'] = this.assets['expiryDate'];
          this.licenseHistory['assetId'] = this.assets['contentId'];
          this.licenseHistory['oldStatus'] = this.assets['licenseWindow'];
          this.licenseHistory['updatedBy'] = this.userName;
          this.licenseHistory['vcCpId'] = this.assets['vcCpId'];
          this.licenseHistory['countryCode'] = this.assets['countryCode'];
          this.licenseChanged = false;
        }

        //EventHistory
        if (this.eventchanged) {
          this.eventHistory['contentId'] = this.assets['contentId'];
          this.eventHistory['eventStarting'] = this.assets['eventStarting'];
          this.eventHistory['eventEnding'] = this.assets['eventEnding'];
          this.eventHistory['oldStatus'] = null;
          this.eventHistory['updatedBy'] = this.userName;
          this.eventHistory['countryCode'] = this.assets['countryCode'];
          this.eventHistory['vcCpId'] = this.assets['vcCpId'];
          this.eventchanged = false;
        }
      }
    }

    //handle images
    for (let item of this.imageResponseKey) {
      if (
        newValue[item] !== undefined &&
        newValue[item] !== String(oldValue[item])
      ) {
        if (!newValue[item] && !oldValue[item]) continue;
        this.finalAsset[item] = newValue[item];
        this.setAssetChangeDto(item, oldValue, newValue);
        this.changedArray.push(item);
      }
    }

    let oldAssetImageList = oldValue['assetImageList'].map((item: any) => ({
      contentId: item.contentId,
      providerId: item.providerId,
      countryCode: item.countryCode,
      imageUrlOriginal: item.imageUrlOriginal,
      imageUrlProcessed: item.imageUrlProcessed,
      imageType: item.imageType,
      isDefault: item.isDefault,
      imgDimension: item.imgDimension,
    }));
    let newAssetImageList = newValue['assetImageList'].map((item: any) => ({
      contentId: item.contentId,
      providerId: item.providerId,
      countryCode: item.countryCode,
      imageUrlOriginal: item.imageUrlOriginal,
      imageUrlProcessed: item.imageUrlProcessed,
      imageType: item.imageType,
      isDefault: item.isDefault,
      imgDimension: item.imgDimension,
    }));

    if (
      this.assetHelperService.detectImageChanges(
        oldAssetImageList,
        newAssetImageList
      )
    ) {
      newAssetImageList = newAssetImageList.filter(
        (image: any) => image.isDefault === 'N'
      );
      this.finalAsset['assetImageList'] = newAssetImageList;
      this.changedArray.push('assetImageList');
    }

    //handle Cast change()

    this.assetHelperService.checkChangeForCast(
      this.finalAsset,
      oldValue,
      newValue,
      this.changedArray,
      this.assetChangeDto,
      this.metaDatahistory,
      currTab
    );

    //External Id editing

    this.assetHelperService.editExternalId(
      this.finalAsset,
      oldValue,
      newValue,
      this.changedArray,
      this.assetChangeDto,
      this.metaDatahistory
    );

    //platformdata updating
    if (currTab == 0) {
      this.assetHelperService.setPlatformTagData(
        this.finalAsset,
        this.availablePlatform,
        this.assets,
        this.platformChanged,
        this.changedArray,
        this.assetChangeDto,
        this.metaDatahistory
      );
    }

    this.finalAsset['contentId'] = oldValue['contentId'];
    this.finalAsset['countryCode'] = oldValue['countryCode'];
    this.finalAsset['vcCpId'] = oldValue['vcCpId'];
    this.finalAsset['crctrId'] = 'CMS';
    //handling gracenote data
    this.finalAsset['feedWorker'] =
      newValue['feedWorker'] ?? oldValue['feedWorker'];
    this.finalAsset['lockedFields'] = newValue['lockedFields'];

    this.finalAsset['gracenoteAction'] =
      this.isCompleteCpData != undefined
        ? this.isCompleteCpData === true
          ? 'add'
          : 'delete'
        : null;

    if (this.metaDatahistory.length > 0) {
      this.metadataChangedObject['updatedBy'] = this.userName;
      this.metadataChangedObject['assetId'] = oldValue['contentId'];
      this.metadataChangedObject['vcCpId'] = oldValue['vcCpId'];
      this.metadataChangedObject['countryCode'] = oldValue['countryCode'];
      this.metadataChangedObject['changes'] = JSON.stringify(
        this.metaDatahistory
      );
    }

    this.assetChangeHistory['assetStatusHistory'] = null;
    this.assetChangeHistory['assetLicenseHistory'] = this.licenseHistory;
    this.assetChangeHistory['assetMetadataHistory'] =
      this.metadataChangedObject;
    this.assetChangeHistory['eventHistory'] = this.eventHistory;

    this.finalData['vodAssetDto'] = this.finalAsset;
    if (this.bulkEditFlag === false) {
      this.finalData['assetChangeHistoryDto'] = this.assetChangeHistory;
    }
    this.finalData['contentIds'] = this.contentIds;

    if (!this.checkValidation() && valid) {
      this.updateAsset(this.finalData, this.changedArray);
    } else {
      this.toastr.errorList(toasterError, 10000);
    }
  }

  updateAsset(data: any, changedArray: string[]) {
    if (
      data.contentIds !== null &&
      data.contentIds.length > 0 &&
      changedArray.length > 0
    ) {
      data['updatedBy'] = this.userName;
      this.updateBulkAsset(data);
    } else if (changedArray.length > 0) {
      this.updateSingleAsset(data);

      if (isGracenoteFeedWorker(data.vodAssetDto.feedWorker)) {
        for (let key of this.nonEditableFields) {
          delete data.vodAssetDto[key];
        }
        this.updateCpData(data);
      } else {
        this.updateCpData(data);
      }
    } else {
      this.resetViewToIntialState();
    }
  }

  setAssetChangeDto(val: string, oldValue: any, newValue: any) {
    this.assetChangeDto['field'] = val;
    this.assetChangeDto['oldValue'] = oldValue[val];
    this.assetChangeDto['newValue'] = newValue[val];
    this.metaDatahistory.push(this.assetChangeDto);
    this.assetChangeDto = {};
  }

  changeDetectorFn(item: any, oldValue: any, newValue: any) {
    if (
      newValue[item.value] !== undefined &&
      String(newValue[item.value]) !== String(oldValue[item.value])
    ) {
      if (
        !newValue[item.value] &&
        !oldValue[item.value] &&
        oldValue[item.value] !== 0
      )
        return;
      if (item.value === 'ratings') {
        this.finalAsset[item.value] = newValue[item.value];
        this.finalAsset['parentalRatings'] = newValue['parentalRatings'];
        this.handleChangeForRating(oldValue, newValue);
        this.changedArray.push(item.key);
      } else {
        this.finalAsset[item.value] = newValue[item.value];
        this.setAssetChangeDto(item.value, oldValue, newValue);
        this.changedArray.push(item.key);
      }
    }
  }

  fetchUserData() {
    this.userService
      .getUserDetails()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.storeService.setStoreState(
          STORE_CONSTS.CURRENT_USER,
          plainToInstance<User, {}>(User, res.user)
        );
        this.user = res.user;
        this.userName = this.user?.firstName + ' ' + this.user?.lastName;
      });
  }

  onBackClick() {
    this.router.navigate(['/media-assets']);
  }
  scroll(index: number) {
    this.sectionIndex = index;
    document.getElementById(this.visibleBlockLabels[index])?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }

  onCancelEdit() {
    if (this.formChanged || this.assetHelperService.detectFormChange()) {
      this.openCancelConfirmationModal(this.vodAssetDto);
    } else {
      this.resetViewToIntialState();
    }
  }

  openCancelConfirmationModal(data: any) {
    const dialogRef = this.dialog.open(CancelConfirmationModalComponent, {
      data: { ...data },
      panelClass: 'cancel-confirmation-modal',
      disableClose: true,
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.resetViewToIntialState();
        }
      });
  }

  onChangeHistoryClick() {
    sessionStorage.setItem('mainTitle', this.assets['mainTitle']);
    sessionStorage.setItem(
      `${this.vodAssetDto['contentId']}`,
      JSON.stringify(this.vodAssetDto)
    );
    sessionStorage.setItem(
      `${this.vodAssetDto['contentId']}-status`,
      this.isDisabled ? 'Not-Editing' : 'Editing'
    );
    sessionStorage.setItem(
      `${this.vodAssetDto['contentId']}-change`,
      this.formChanged ? 'Change' : 'No-Change'
    );

    this.router.navigate([SIDE_NAV_ROUTES.METADATA_HISTORY.route_link], {
      queryParams: {
        assetId: this.assets['contentId'],
      },
    });
  }
  checkValidation() {
    for (let item of this.validCheck) {
      if (!item.status && !this.notVisibleFields.includes(item.name)) {
        return true;
      }
    }
    return false;
  }

  notEditableStatus: string[] = [
    'QC Pass',
    'Temp QC Pass',
    'Untrackable',
    'SMF Imported',
  ];

  isEditable() {
    if (this.notEditableStatus.includes(this.assets['status'])) {
      return false;
    } else if (
      cmsFeedWorkersList.includes(this.assets.feedWorker) ||
      (deltaFeedWorkersList.includes(this.assets.feedWorker) &&
        this.assets.deltaType === 'QC_SYNC')
    ) {
      return true;
    }
    return false;
  }
  seriesData: any = {};
  bulkEdit(): void {
    const dialogRef = this.dialog.open(BulkEditDialogComponent, {
      data: {
        contentId: this.assets['contentId'],
        countryCode: this.assets['countryCode'],
        vcCpId: this.assets['vcCpId'],
        seasonNo: this.assets['seasonNo'],
        episodeNo: this.assets['episodeNo'],
        seasonId: this.assets['seasonId'],
        showId: this.assets['showId'],
      },
      panelClass: 'bulk-edit-modal',
      disableClose: true,
      width: '550px',
      height: '500px',
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(
        (data: {
          selectedEpisode: ShowHierarchy[];
          seriesData: any;
          seasonCount: number;
        }) => {
          this.seriesData = data?.seriesData;
          this.seasonCount = data?.seasonCount;

          if (
            data?.selectedEpisode !== null &&
            data?.selectedEpisode.length > 0
          ) {
            this.bulkEditFlag = true;
            this.mandatoryFields = bulkEditMandatoryFields;
            this.episodeData = data?.selectedEpisode;

            this.episodeData.sort(
              (a, b) => +a.seasonNo - +b.seasonNo || +a.episodeNo - +b.episodeNo
            );
            let lastSeason = -1;
            this.episodeDataDisplay = ' > ';
            for (let i = 0; i < this.episodeData.length; i++) {
              if (!this.episodeData[i]) continue;
              this.contentIds?.push(this.episodeData[i].contentId);
              if (this.episodeData[i].seasonNo !== lastSeason) {
                this.episodeDataDisplay =
                  this.episodeDataDisplay +
                  ' Season ' +
                  this.episodeData[i].seasonNo +
                  ' > ' +
                  'E' +
                  this.episodeData[i].episodeNo;
                lastSeason = this.episodeData[i].seasonNo;
              } else {
                this.episodeDataDisplay =
                  this.episodeDataDisplay +
                  ',E' +
                  this.episodeData[i].episodeNo;
              }
            }
            this.bulkEditFields = bulkEditEditableFields;
            this.mandatoryFields = bulkEditMandatoryFields;
            this.onEditClick();
          }
        }
      );
  }

  ngOnDestroy() {
    document.body.classList.remove('asset-details-view');
  }

  bulkEditButton(): boolean {
    if (this.currentItem !== 0) {
      return true;
    }
    if (this.assets['showId'] !== null && this.assets['type'] === 'EPISODE') {
      return !this.isEditable();
    }
    return true;
  }

  seriesButton: string[] = ['Series', `Episode's Season`, 'All Seasons'];
  selectedRadioButton: number = 0;
  radioChange(obj: any) {
    this.selectedRadioButton = obj['value'];
  }

  resetViewToIntialState() {
    this.assets = null;
    this.isResponseOk = false;
    setTimeout(() => {
      this.isDisabled = true;
      this.intializeVariables();
      this.getCurrentData();
    }, 0);
  }
  intializeVariables() {
    this.currentItem = 0;
    this.assets = null;
    this.cpProviderDataOrg = null;
    this.cpProviderDataCopy = null;
    this.gracenoteData = null;
    this.gracenoteDataCopy = null;
    this.editMode = false;
    this.formChanged = false;
    this.licenseChanged = false;
    this.platformChanged = false;
    this.externalIdFlag = false;
    this.finalAsset = {};
    this.vodAssetDto = {};
    this.assetChangeHistory = {};
    this.licenseHistory = {};
    this.eventHistory = {};
    this.metaDatahistory = [];
    this.assetChangeDto = {};
    this.metadataChangedObject = {};
    this.statushistory = {};
    this.changedArray = [];
    this.mandatoryFields = [];
    this.nonEditableFields = [];
    this.notEditableFieldsSingleEdit = [];
    this.notVisibleFields = [];
    this.finalData = {};
    this.languageList = [];
    this.language = [];
    this.genres = [];
    this.imageCount = 0;
    this.sectionIndex = 0;
    this.episodeData = [];
    this.episodeDataDisplay = '';
    this.contentIds = [];
    this.bulkEditFlag = false;
    this.bulkEditFields = [];
    this.parentalRatings = [];
    this.seasonCount = 0;
    this.notVisibleBlock = [];
    this.isResponseOk = false;
  }

  handleChangeForRating(oldValue: any, newValue: any) {
    this.assetChangeDto['field'] = 'parentalRatings';
    this.assetChangeDto['oldValue'] = JSON.stringify(
      oldValue['parentalRatings']
    );
    this.assetChangeDto['newValue'] = JSON.stringify(
      newValue['parentalRatings']
    );
    this.metaDatahistory.push(this.assetChangeDto);
    this.assetChangeDto = {};
  }

  cpProviderDataCopy: any;
  cpProviderDataOrg: any;
  gracenoteData: any;
  gracenoteDataCopy: any;
  onViewClick(index: number) {
    if (index === 0 && this.assets && !this.vodAssetDto) {
      this.vodAssetDto = JSON.parse(JSON.stringify(this.assets));
      this.currentItem = index;
    } else if (index === 0 && this.assets && this.vodAssetDto) {
      this.currentItem = index;
    } else if (index === 0 && !this.assets) {
      this.getCurrentData(index);
    } else if (index === 1 && !this.cpProviderDataOrg && !this.gracenoteData) {
      this.getCPProviderData(index);
      this.getGraceNoteData(index);
    } else if (index === 1 && this.cpProviderDataOrg && !this.gracenoteData) {
      this.getGraceNoteData(index);
    } else {
      this.cpProviderDataCopy = JSON.parse(
        JSON.stringify(this.cpProviderDataOrg)
      );
      this.gracenoteDataCopy = JSON.parse(JSON.stringify(this.gracenoteData));
      this.currentItem = index;
    }
  }

  getCPProviderData(tab?: number) {
    this.assetService
      .getCPProviderData(
        this.route.snapshot.queryParams['contentId'] ||
          this.assetKeys.contentId,
        this.route.snapshot.queryParams['cpId'] || this.assetKeys.cpId,
        this.route.snapshot.queryParams['countryCode'] ||
          this.assetKeys.countryCode
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.cpProviderDataOrg = res;
        this.cpProviderDataCopy = JSON.parse(JSON.stringify(res));
        this.assetHelperService.intializeCastData(
          this.cpProviderDataOrg,
          this.cpProviderDataCopy
        );
        this.currentItem = tab ?? this.currentItem;
      });
  }
  getGraceNoteData(tab?: number) {
    this.assetService
      .getGracenoteData(
        this.route.snapshot.queryParams['contentId'] ||
          this.assetKeys.contentId,
        this.route.snapshot.queryParams['cpId'] || this.assetKeys.cpId,
        this.route.snapshot.queryParams['countryCode'] ||
          this.assetKeys.countryCode
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.gracenoteData = res;
        this.gracenoteDataCopy = JSON.parse(JSON.stringify(res));
        this.assetHelperService.intializeCastData(
          this.gracenoteData,
          this.gracenoteDataCopy
        );
        this.currentItem = tab ?? this.currentItem;
      });
  }
  getCurrentData(tab?: number) {
    //for detailed view
    this.assetService
      .getAssetDetailedView(
        this.route.snapshot.queryParams['contentId'] ||
          this.assetKeys.contentId,
        this.route.snapshot.queryParams['cpId'] || this.assetKeys.cpId,
        this.route.snapshot.queryParams['countryCode'] ||
          this.assetKeys.countryCode
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.assets = res;
        if (!this.assets['lockedFields']) {
          this.assets['lockedFields'] = [];
        }
        this.vodAssetDto = JSON.parse(JSON.stringify(res));
        if (
          sessionStorage.getItem(this.assets['contentId']) !== null &&
          sessionStorage.getItem(`${this.assets['contentId']}-status`) ===
            'Editing'
        ) {
          this.isDisabled = false;
          this.formChanged =
            sessionStorage.getItem(`${this.assets['contentId']}-change`) ===
            'Change';

          this.vodAssetDto = JSON.parse(
            sessionStorage.getItem(this.assets['contentId'])!
          );
          sessionStorage.removeItem(this.assets['contentId']);
          sessionStorage.removeItem(`${this.assets['contentId']}-status`);
          sessionStorage.removeItem(`${this.assets['contentId']}-change`);
        }

        this.mandatoryFields =
          mandatoryFields.find((obj) => obj.type === this.assets['type'])
            ?.value ?? [];

        this.notVisibleFields =
          notVisibleFields.find((obj) => obj.type === this.assets['type'])
            ?.value ?? [];
        this.notVisibleBlock = this.assetHelperService.filterVisibleBlock(
          this.assets
        );

        this.visibleBlockLabels = assetViewTitle.filter(
          (t) => !this.notVisibleBlock.includes(t)
        );

        this.externalIdFlag =
          this.assets['externalProvider'] &&
          this.assets['externalProvider'].length > 0;

        if (isGracenoteFeedWorker(this.assets['feedWorker'])) {
          this.nonEditableFields =
            gracenoteFields.filter((item) => {
              const obj = this.assets['lockedFields'].find(
                (lock: any) =>
                  FieldMappings.getFieldKey(lock.fieldName) === item
              );
              return !obj;
            }) ?? [];
        }
        this.notEditableFieldsSingleEdit =
          notEditableInSingleEdit.find(
            (obj) => obj.type === this.assets['type']
          )?.value ?? [];
        this.assetMasterData = this.storeService.getStoreState(
          STORE_CONSTS.ASSET_MASTER_DATA
        );
        this.intializeDropDownValues();

        this.intializePlatformValues();

        this.assetHelperService.intializeCastData(
          this.assets,
          this.vodAssetDto
        );
        this.currentItem = tab ?? this.currentItem;
      });
  }
  onRadioButtonChange(evt: any) {
    const obj = JSON.parse(JSON.stringify(this.vodAssetDto));

    this.editAssetImageMasterList(obj, evt);

    this.vodAssetDto = { ...this.vodAssetDto, ...evt };
    const gracenoteFields = this.vodAssetDto['gracenoteFields'];
    this.assetHelperService.intializeCastArray(this.vodAssetDto);
    this.formChanged = true;
    this.isCompleteCpData = evt.isCp;

    this.externalIdFlag =
      this.vodAssetDto['externalProvider'] &&
      this.vodAssetDto['externalProvider'].length > 0;

    if (this.externalIdFlag && gracenoteFields && gracenoteFields.length > 0) {
      this.nonEditableFields = gracenoteFields;
    } else {
      this.nonEditableFields = [];
    }
  }

  updateCpData(data: any) {
    this.assetService
      .updateCpData(data)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res);
      });
  }

  updateBulkAsset(data: any) {
    this.assetService
      .updateAssetByBulk(data)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res);
        this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
      });
  }
  updateSingleAsset(data: any) {
    this.assetService
      .updateAsset(data)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res);
        this.resetViewToIntialState();
      });
  }

  editAssetImageMasterList(vodAssetDto: any, evt: any) {
    const images: AssetImageModel[] =
      vodAssetDto['assetImageList']?.filter(
        (image: any) => image.isDefault === 'N'
      ) ?? [];
    let obj: AssetImageModel = {};
    obj.contentId = vodAssetDto['contentId'];
    obj.countryCode = vodAssetDto['countryCode'];
    obj.providerId = vodAssetDto['vcCpId'];

    if (evt.imageLandscapeIconic) {
      obj.imageUrlOriginal = evt.imageLandscapeIconicOriginal;
      obj.imageUrlProcessed = evt.imageLandscapeIconic;
      obj.imageType = 'landscape_iconic';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imageLandscapeIconicDimension;
      images.push({ ...obj });
    }
    if (evt.imagePortraitIconic) {
      obj.imageUrlOriginal = evt.imagePortraitIconicOriginal;
      obj.imageUrlProcessed = evt.imagePortraitIconic;
      obj.imageType = 'portrait_iconic';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imagePortraitIconicDimension;

      images.push({ ...obj });
    }
    if (evt.imageLandscape) {
      obj.imageUrlOriginal = evt.imageLandscapeOriginal;
      obj.imageUrlProcessed = evt.imageLandscape;
      obj.imageType = 'landscape_banner';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imageLandscapeDimension;
      images.push({ ...obj });
    }
    if (evt.imagePortrait) {
      obj.imageUrlOriginal = evt.imagePortraitOriginal;
      obj.imageUrlProcessed = evt.imagePortrait;
      obj.imageType = 'portrait_banner';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imagePortraitDimension;
      images.push({ ...obj });
    }
    if (evt.imageLandscapeBackdrop) {
      obj.imageUrlOriginal = evt.imageLandscapeBackdropOriginal;
      obj.imageUrlProcessed = evt.imageLandscapeBackdrop;
      obj.imageType = 'landscape_backdrop';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imageLandscapeBackdropDimension;
      images.push({ ...obj });
    }

    if (evt.imageTitleTreatment) {
      obj.imageUrlOriginal = evt.imageTitleTreatmentOriginal;
      obj.imageUrlProcessed = evt.imageTitleTreatment;
      obj.imageType = 'title_treatment';
      obj.isDefault = 'Y';
      obj.imgDimension = evt.imageTitleTreatmentDimension;
      images.push({ ...obj });
    }

    this.vodAssetDto['assetImageList'] = [...images];
  }
}
