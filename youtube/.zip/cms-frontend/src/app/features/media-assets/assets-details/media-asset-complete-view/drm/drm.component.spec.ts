import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrmComponent } from './drm.component';

describe('DrmComponent', () => {
  let component: DrmComponent;
  let fixture: ComponentFixture<DrmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DrmComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DrmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
