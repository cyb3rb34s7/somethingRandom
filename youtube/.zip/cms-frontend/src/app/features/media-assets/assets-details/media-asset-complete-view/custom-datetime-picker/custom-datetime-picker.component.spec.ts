import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomDatetimePickerComponent } from './custom-datetime-picker.component';

describe('CustomDatetimePickerComponent', () => {
  let component: CustomDatetimePickerComponent;
  let fixture: ComponentFixture<CustomDatetimePickerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomDatetimePickerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomDatetimePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
