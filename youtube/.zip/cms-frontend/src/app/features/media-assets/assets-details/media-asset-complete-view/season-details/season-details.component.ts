import { Component, Input } from '@angular/core';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';

@Component({
    selector: 'app-season-details',
    imports: [AppMatInputComponent],
    templateUrl: './season-details.component.html',
    styleUrl: './season-details.component.scss'
})
export class SeasonDetailsComponent {
  @Input() data: any = {};
  ngOnInit() {}
}
