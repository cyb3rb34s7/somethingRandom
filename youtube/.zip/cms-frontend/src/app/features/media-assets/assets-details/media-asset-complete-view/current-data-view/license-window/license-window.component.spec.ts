import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenseWindowComponent } from './license-window.component';

describe('LicenseWindowComponent', () => {
  let component: LicenseWindowComponent;
  let fixture: ComponentFixture<LicenseWindowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LicenseWindowComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LicenseWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
