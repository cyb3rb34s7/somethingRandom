import { Injectable } from '@angular/core';
import { z, ZodError, ZodType } from 'zod';

const ParentalRatingSchema = z
  .object({
    body: z.string().max(500, 'Body must not have more than 500 characters'),
    ratings: z
      .string()
      .max(20, 'Ratings must not have more than 20 characters'),
  })
  .refine((data) => !isNullish(data.body) && !isNullish(data.ratings), {
    message: 'Parent rating object must have body and ratings fields',
    path: ['parentalRatings'],
  });

const ExternalProviderSchema = z
  .object({
    externalProgramId: z
      .string('External program ID must have at least 1 character')
      .max(125, 'External program ID must not have more than 125 characters')
      .regex(
        /^[0-9A-Za-z_-]+$/,
        'External program ID must only contain alphanumeric characters and underscores'
      ),
    idType: z.enum(['tmsId', 'rootId'], {
      message: 'ID type must be either tmsId or rootId',
    }),
    provider: z.string('Provider must have at least 1 character'),
  })
  .refine(
    (data) =>
      !isNullish(data.externalProgramId) &&
      !isNullish(data.idType) &&
      !isNullish(data.provider),
    {
      message:
        'External provider object must have External Program Id, Id Type, and Provider fields',
      path: ['externalProvider'],
    }
  );

const PlatformTagDataSchema = z
  .object({
    type: z.string('Platform Type must have at least 1 character'),
    platform: z.string('Platform must have at least 1 character'),
    alias: z.string('Alias must have at least 1 character'),
  })
  .refine(
    (data) =>
      !isNullish(data.type) &&
      !isNullish(data.platform) &&
      !isNullish(data.alias),
    {
      message:
        'Platform Tag Data object must have type, platform, and alias fields',
      path: ['platformTagData'],
    }
  );

const CastSchema = z
  .object({
    name: z
      .string('Person Name must have at least 1 character')
      .max(200, 'Person Name must not have more than 200 characters')
      .regex(/^(?!\s*$)[^,]+$/, 'Person Name must not contain commas'),
    role: z.enum(['actor', 'director', 'artist'], {
      message: 'Person Role must be either actor, director, or artist',
    }),
    characterName: z
      .string()
      .max(200, 'Character name must not have more than 200 characters')
      .optional(),
  })
  .refine((data) => !isNullish(data.name) && !isNullish(data.role), {
    message: 'Cast object must have person name and person role fields',
    path: ['cast'],
  });

const LicenseWindowSchema = z
  .object({
    licenseId: z
      .string()
      .max(100, 'License ID must not have more than 100 characters')
      .regex(
        /^[0-9A-Za-z_-]+$/,
        'License ID must only contain alphanumeric characters and underscores'
      ),
    availableStarting: z
      .string()
      .regex(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/,
        'Available starting date must be in the format YYYY-MM-DDTHH:MM:SSZ'
      ),
    availableEnding: z
      .string()
      .regex(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/,
        'Available ending date must be in the format YYYY-MM-DDTHH:MM:SSZ'
      ),
  })
  .refine(
    (data) =>
      !isNullish(data.licenseId) &&
      !isNullish(data.availableStarting) &&
      !isNullish(data.availableEnding) != undefined,
    {
      message:
        'License window object must have licenseId, availableStarting, and availableEnding fields',
      path: ['licenseWindowList'],
    }
  )
  .refine((data) => data.availableEnding > data.availableStarting, {
    message: 'Window End Date must be after Window Start Date',
    path: ['licenseWindowList', 'availableEnding'],
  });
const LicenseWindowListSchema = z
  .array(LicenseWindowSchema)
  .superRefine((licenseWindow, ctx) => {
    licenseWindow.sort((a, b) => {
      const startDateComp = a.availableStarting.localeCompare(
        b.availableStarting
      );
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.availableEnding.localeCompare(b.availableEnding);
    });
    for (let it = 0; it < licenseWindow.length - 1; it++) {
      if (
        licenseWindow[it].availableEnding >=
        licenseWindow[it + 1].availableStarting
      ) {
        ctx.addIssue({
          code: 'custom',
          message: `License Window ${it + 1} overlaps with License Window ${
            it + 2
          }`,
          path: [it, 'availableEnding'],
        });
      }
    }
  });
const EventWindowSchema = z
  .object({
    eventId: z
      .string()
      .max(100, 'Event ID must not have more than 100 characters')
      .regex(
        /^[0-9A-Za-z_-]+$/,
        'Event ID must only contain alphanumeric characters and underscores'
      ),
    eventStarting: z
      .string()
      .regex(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/,
        'Event starting date must be in the format YYYY-MM-DDTHH:MM:SSZ'
      ),
    eventEnding: z
      .string()
      .regex(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/,
        'Event ending date must be in the format YYYY-MM-DDTHH:MM:SSZ'
      ),
  })
  .refine(
    (data) =>
      !isNullish(data.eventId) &&
      !isNullish(data.eventStarting) &&
      !isNullish(data.eventEnding),
    {
      message:
        'Event window object must have eventId, eventStarting, and eventEnding fields',
      path: ['eventWindowList'],
    }
  )
  .refine((data) => data.eventEnding > data.eventStarting, {
    message: 'Event End Date must be after Event Start Date',
    path: ['eventWindowList', 'eventEnding'],
  });
const EventWindowListSchema = z
  .array(EventWindowSchema)
  .superRefine((eventWindow, ctx) => {
    eventWindow.sort((a, b) => {
      const startDateComp = a.eventStarting.localeCompare(b.eventStarting);
      if (startDateComp !== 0) {
        return startDateComp;
      }
      return a.eventEnding.localeCompare(b.eventEnding);
    });
    for (let it = 0; it < eventWindow.length - 1; it++) {
      if (eventWindow[it].eventEnding >= eventWindow[it + 1].eventStarting) {
        ctx.addIssue({
          code: 'custom',
          message: `Event Window ${it + 1} overlaps with Event Window ${
            it + 2
          }`,
          path: [it, 'eventEnding'],
        });
      }
    }
  });

const BaseAssetSchema = z.object({
  type: z.enum(['SHOW', 'SEASON', 'EPISODE', 'MOVIE', 'MUSIC', 'SINGLEVOD'], {
    message:
      'Type must be one of the following: SHOW, SEASON, EPISODE, MOVIE, MUSIC, SINGLEVOD',
  }),
  contentId: z
    .string()
    .min(1, 'Content ID must have at least 1 character')
    .max(125, 'Content ID must not have more than 125 characters'),
  assetId: z
    .string()
    .max(100, 'Asset ID must not have more than 100 characters')
    .optional(),
  countryCode: z
    .string()
    .min(2, 'Country code must be exactly 2 characters')
    .max(2, 'Country code must be exactly 2 characters'),
  vcCpId: z.string(),
  mainTitle: z
    .string()
    .max(200, 'Main title must not have more than 200 characters'),
  shortTitle: z
    .string()
    .min(0, 'Short title must have at least 0 character')
    .max(200, 'Short title must not have more than 200 characters')
    .optional(),
  language: z
    .string()
    .min(1, 'Language must have at least 1 character')
    .max(200, 'Language must not have more than 200 characters')
    .optional(),
  showId: z
    .string()
    .regex(
      /^[0-9A-Za-z_-]+$/,
      'Show ID must only contain alphanumeric characters and underscores'
    )
    .optional(),
  showTitle: z.string().optional(),
  seasonTitle: z.string().optional(),
  seasonId: z
    .string()
    .regex(
      /^[0-9A-Za-z_-]+$/,
      'Season ID must only contain alphanumeric characters and underscores'
    )
    .min(0, 'Season ID must have at least 0 character')
    .max(125, 'Season ID must not have more than 125 characters')
    .optional(),
  runningTime: z
    .number()
    .min(0, 'Running time must be greater than or equal to 0')
    .max(21600, 'Running time must be less than or equal to 21600')
    .optional(),
  adTag: z
    .string()
    .min(1, 'Ad tag must have at least 1 character')
    .max(2000, 'Ad tag must not have more than 2000 characters')
    .optional(),
  streamUri: z
    .string()
    .regex(
      /^(http|https):\/\/(.)*$/,
      'Stream URI must start with http or https'
    )
    .optional(),
  description: z
    .string()
    .max(4000, 'Description must not have more than 4000 characters')
    .optional(),
  streamType: z.string().optional(),
  releaseDate: z
    .string()
    .max(20, 'Release date must not have more than 20 characters')
    .regex(
      /^(\d{4}((-\d{2})(-\d{2}))?)?$/,
      'Release date must be in the format YYYY-MM-DD'
    )
    .nullish()
    .optional(),
  genres: z
    .string()
    .max(200, 'Genres must not have more than 200 characters.')
    .optional(),
  ratings: z.string().optional(),
  parentalRatings: z.array(ParentalRatingSchema).optional(),
  externalProvider: z.array(ExternalProviderSchema).optional(),
  platformTagData: z.array(PlatformTagDataSchema).optional(),
  cast: z.array(CastSchema).optional(),
  licenseWindowList: LicenseWindowListSchema.optional(),
  eventWindowList: EventWindowListSchema.optional(),

  seasonNo: z
    .number()
    .max(99999, 'Season number must be less than or equal to 99999')
    .optional(),
  episodeNo: z
    .number()
    .max(99999, 'Episode number must be less than or equal to 99999')
    .optional(),
  quality: z.string().optional(),
  deeplinkPayload: z.string().optional(),
  availableStarting: z.string().optional(),
  expiryDate: z.string().optional(),
  artist: z.string().optional(),

  team1: z
    .string()
    .max(100, 'Team1 must not have more than 100 characters.')
    .optional(),
  team2: z
    .string()
    .max(100, 'Team2 must not have more than 100 characters.')
    .optional(),
});

const AssetSchema = BaseAssetSchema.superRefine((data, ctx) => {
  //validation for rating duplicate body
  if (data.parentalRatings && data.parentalRatings.length > 0) {
    const bodyValues = data.parentalRatings.map((pr) => pr.body);
    const uniqueBodyValues = new Set(bodyValues);
    if (bodyValues.length !== uniqueBodyValues.size) {
      const duplicates = bodyValues.filter(
        (item, index) => bodyValues.indexOf(item) !== index
      );
      const uniqueDuplicates = [...new Set(duplicates)];
      ctx.addIssue({
        code: 'custom',
        message: `Duplicate parental rating organisation values are not allowed. Duplicate(s): ${uniqueDuplicates.join(
          ', '
        )}`,
        path: ['parentalRatings'],
      });
    }
  }

  const { type } = data;

  switch (type) {
    case 'SHOW':
      if (!data.mainTitle) {
        ctx.addIssue({
          code: 'custom',
          message: 'Main Title is required for show type',
          path: ['mainTitle'],
        });
      }
      if (!data.description) {
        ctx.addIssue({
          code: 'custom',
          message: 'Description is required for show type',
          path: ['description'],
        });
      }
      break;

    case 'SEASON':
      if (!data.mainTitle) {
        ctx.addIssue({
          code: 'custom',
          message: 'Main Title is required for season type',
          path: ['mainTitle'],
        });
      }
      if (!data.description) {
        ctx.addIssue({
          code: 'custom',
          message: 'Description is required for season type',
          path: ['description'],
        });
      }
      if (!data.showId) {
        ctx.addIssue({
          code: 'custom',
          message: 'Show ID is required for season type',
          path: ['showId'],
        });
      }

      if (data.seasonNo == undefined) {
        ctx.addIssue({
          code: 'custom',
          message: 'Season number is required for season type',
          path: ['seasonNo'],
        });
      } else if (data.seasonNo < 1) {
        ctx.addIssue({
          code: 'custom',
          message: 'Season number must be greater than 0',
          path: ['seasonNo'],
        });
      }
      break;

    case 'EPISODE':
      const requiredEpisodeFields = [
        'mainTitle',
        'showId',
        'seasonNo',
        'seasonId',
        'episodeNo',
        'description',
        'streamUri',
        'quality',
        'deeplinkPayload',
        'availableStarting',
        'expiryDate',
        'licenseWindowList',
      ] as const;

      requiredEpisodeFields.forEach((field) => {
        if (
          data[field] === undefined ||
          data[field] === null ||
          data[field] === ''
        ) {
          const fieldMessages = {
            mainTitle: 'Main Title is required for episode type',
            showId: 'Show ID is required for episode type',
            seasonNo: 'Season number is required for episode type',
            seasonId: 'Season ID is required for episode type',
            episodeNo: 'Episode number is required for episode type',
            description: 'Description is required for episode type',
            streamUri: 'Stream URI is required for episode type',
            quality: 'Quality is required for episode type',
            deeplinkPayload: 'Deep link payload is required for episode type',
            availableStarting:
              'Available starting date is required for episode type',
            expiryDate: 'Expiry date is required for episode type',
            licenseWindowList: 'License window is required for episode type',
          };

          ctx.addIssue({
            code: 'custom',
            message: fieldMessages[field],
            path: [field],
          });
        }
      });

      if (data.seasonNo && data.seasonNo < 1) {
        ctx.addIssue({
          code: 'custom',
          message: 'Season number must be greater than 0',
          path: ['seasonNo'],
        });
      }
      if (data.episodeNo && data.episodeNo < 1) {
        ctx.addIssue({
          code: 'custom',
          message: 'Episode number must be greater than 0',
          path: ['episodeNo'],
        });
      }

      if (!data.licenseWindowList || data.licenseWindowList.length === 0) {
        ctx.addIssue({
          code: 'custom',
          message: 'License window is required for episode type',
          path: ['licenseWindowList'],
        });
      }
      break;

    case 'MOVIE':
      const requiredMovieFields = [
        'mainTitle',
        'description',
        'streamUri',
        'quality',
        'deeplinkPayload',
        'availableStarting',
        'expiryDate',
        'licenseWindowList',
      ] as const;

      requiredMovieFields.forEach((field) => {
        if (
          data[field] === undefined ||
          data[field] === null ||
          data[field] === ''
        ) {
          const fieldMessages = {
            mainTitle: 'Main Title is required for movie type',
            description: 'Description is required for movie type',
            streamUri: 'Stream URI is required for movie type',
            quality: 'Quality is required for movie type',
            deeplinkPayload: 'Deep link payload is required for movie type',
            availableStarting:
              'Available starting date is required for movie type',
            expiryDate: 'Expiry date is required for movie type',
            licenseWindowList: 'License window is required for movie type',
          };

          ctx.addIssue({
            code: 'custom',
            message: fieldMessages[field],
            path: [field],
          });
        }
      });

      if (!data.licenseWindowList || data.licenseWindowList.length === 0) {
        ctx.addIssue({
          code: 'custom',
          message: 'License window is required for movie type',
          path: ['licenseWindowList'],
        });
      }
      break;

    case 'MUSIC':
      const requiredMusicFields = [
        'mainTitle',
        'description',
        'streamUri',
        'quality',
        'deeplinkPayload',
        'availableStarting',
        'expiryDate',
        'artist',
        'genres',
        'licenseWindowList',
      ] as const;

      requiredMusicFields.forEach((field) => {
        if (
          data[field] === undefined ||
          data[field] === null ||
          data[field] === ''
        ) {
          const fieldMessages = {
            mainTitle: 'Main Title is required for music type',
            description: 'Description is required for music type',
            streamUri: 'Stream URI is required for music type',
            quality: 'Quality is required for music type',
            deeplinkPayload: 'Deep link payload is required for music type',
            availableStarting:
              'Available starting date is required for music type',
            expiryDate: 'Expiry date is required for music type',
            artist: 'Artist is required for music type',
            genres: 'Genres is required for music type',
            licenseWindowList: 'License window is required for music type',
          };

          ctx.addIssue({
            code: 'custom',
            message: fieldMessages[field],
            path: [field],
          });
        }
      });

      if (!data.licenseWindowList || data.licenseWindowList.length === 0) {
        ctx.addIssue({
          code: 'custom',
          message: 'License window is required for music type',
          path: ['licenseWindowList'],
        });
      }
      break;

    case 'SINGLEVOD':
      const requiredSingleVodFields = [
        'mainTitle',
        'description',
        'streamUri',
        'quality',
        'deeplinkPayload',
        'availableStarting',
        'expiryDate',
        'licenseWindowList',
      ] as const;

      requiredSingleVodFields.forEach((field) => {
        if (
          data[field] === undefined ||
          data[field] === null ||
          data[field] === ''
        ) {
          const fieldMessages = {
            mainTitle: 'Main Title is required for single VOD type',
            description: 'Description is required for single VOD type',
            streamUri: 'Stream URI is required for single VOD type',
            quality: 'Quality is required for single VOD type',
            deeplinkPayload:
              'Deep link payload is required for single VOD type',
            availableStarting:
              'Available starting date is required for single VOD type',
            expiryDate: 'Expiry date is required for single VOD type',
            licenseWindowList: 'License window is required for single VOD type',
          };

          ctx.addIssue({
            code: 'custom',
            message: fieldMessages[field],
            path: [field],
          });
        }
      });

      if (!data.licenseWindowList || data.licenseWindowList.length === 0) {
        ctx.addIssue({
          code: 'custom',
          message: 'License window is required for single VOD type',
          path: ['licenseWindowList'],
        });
      }
      break;
  }
});

export type Asset = z.infer<typeof AssetSchema>;

@Injectable({
  providedIn: 'root',
})
export class AssetValidatorService {
  private assetSchema: ZodType<Asset> = AssetSchema;

  constructor() {}

  validateAsset(asset: any): { valid: boolean; errors: string[] | null } {
    try {
      const result = this.assetSchema.parse(asset);
      return {
        valid: true,
        errors: null,
      };
    } catch (error) {
      if (error instanceof ZodError) {
        const errors = this.formatZodError(error);
        return {
          valid: false,
          errors: errors,
        };
      }
      return {
        valid: false,
        errors: ['An unexpected error occurred during validation.'],
      };
    }
  }

  private formatZodError(error: ZodError): string[] {
    return error.issues
      .map((err: any) => {
        console.log(err);
        return err.message;
      })
      .filter((message: string, index: number, array: string[]) => {
        return array.indexOf(message) === index;
      });
  }

  validateAssetPartial(asset: any): {
    valid: boolean;
    errors: string[] | null;
  } {
    try {
      const result = this.assetSchema.safeParse(asset);
      if (result.success) {
        return {
          valid: true,
          errors: null,
        };
      } else {
        const presentFieldErrors = result.error.issues.filter((issue: any) => {
          const path = issue.path.join('.');
          return asset[path.split('.')[0]] !== undefined;
        });

        if (presentFieldErrors.length === 0) {
          return {
            valid: true,
            errors: null,
          };
        }

        return {
          valid: false,
          errors: this.formatZodError(result.error),
        };
      }
    } catch (error) {
      return {
        valid: false,
        errors: ['An unexpected error occurred during validation.'],
      };
    }
  }

  getSchema(): ZodType<Asset> {
    return this.assetSchema;
  }

  safeParseAsset(asset: any): {
    success: boolean;
    data?: Asset;
    errors?: string[];
  } {
    const result = this.assetSchema.safeParse(asset);

    if (result.success) {
      return {
        success: true,
        data: result.data,
      };
    } else {
      return {
        success: false,
        errors: this.formatZodError(result.error),
      };
    }
  }
}

export const isNullish = (value: any) =>
  value === null || value === undefined || value === '';
