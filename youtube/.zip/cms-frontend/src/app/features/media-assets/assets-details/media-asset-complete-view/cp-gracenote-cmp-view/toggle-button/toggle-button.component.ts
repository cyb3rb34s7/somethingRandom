import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-toggle-button',
  standalone: true,
  imports: [MatSlideToggleModule],
  templateUrl: './toggle-button.component.html',
  styleUrl: './toggle-button.component.scss',
})
export class ToggleButtonComponent {
  @Input() label: string;
  @Input() isDisabled: boolean = true;
  @Input() isChecked: boolean = false;
  @Output() currentValue = new EventEmitter<any>();

  onToggleChange($event: any) {
    this.currentValue.emit($event);
  }
}
