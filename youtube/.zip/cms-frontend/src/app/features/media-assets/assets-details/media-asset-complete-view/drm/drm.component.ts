import { Component, Input } from '@angular/core';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { ValidatorsCustom } from '../../asset-constants/asset-fields-constants';

@Component({
    selector: 'app-drm',
    imports: [AppMatInputComponent],
    templateUrl: './drm.component.html',
    styleUrl: './drm.component.scss'
})
export class DrmComponent {
  @Input() currentVodData: any = {};
  externalValidator: ValidatorsCustom = { minLength: 1 };
}
