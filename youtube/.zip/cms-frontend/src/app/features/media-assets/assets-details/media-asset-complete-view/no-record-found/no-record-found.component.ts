import { Component } from '@angular/core';

@Component({
    selector: 'app-no-record-found',
    imports: [],
    templateUrl: './no-record-found.component.html',
    styleUrl: './no-record-found.component.scss'
})
export class NoRecordFoundComponent {

}
