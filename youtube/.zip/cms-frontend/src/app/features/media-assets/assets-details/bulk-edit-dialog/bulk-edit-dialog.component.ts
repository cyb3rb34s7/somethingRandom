import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  EventEmitter,
  Inject,
  inject,
  Output,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatRadioGroupComponent } from '../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { ShowHierarchy } from '../../../../models/show-hierarchy';
import { AssetService } from '../../../../services/asset.service';
import { plainToInstance } from 'class-transformer';
import { AppMatSelectComponent } from '../../../../mat-components/app-mat-select/app-mat-select.component';
import { AppMatInputComponent } from '../../../../mat-components/app-mat-input/app-mat-input.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { SelectAllDirective } from './select-all-directive';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-bulk-edit-dialog',
    imports: [
        CommonModule,
        MatCheckboxModule,
        MatSelectModule,
        MatFormFieldModule,
        MatExpansionModule,
        MatDialogModule,
        MatButtonModule,
        AppMatInputComponent,
        MatChipsModule,
        FormsModule,
        MatIconModule,
        MatFormFieldModule,
        ReactiveFormsModule,
        MatInputModule,
        SelectAllDirective,
    ],
    templateUrl: './bulk-edit-dialog.component.html',
    styleUrl: './bulk-edit-dialog.component.scss'
})
export class BulkEditDialogComponent {
  constructor(
    private assetService: AssetService,
    public dialogRef: MatDialogRef<BulkEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public obj: any
  ) {}

  fSeason = new FormControl<string[] | undefined>([]);

  fEpisode = new FormControl<string[] | undefined>({
    value: [],
    disabled: true,
  });

  allAssetsData: ShowHierarchy[] = [];

  seasons: string[] = [];

  episodesList: string[] = [];

  inValidEpisodes: string[] = [];

  validEpisodes: string[] = [];

  seasonEpisodeMap: any = {};

  selectedEpisodes: ShowHierarchy[] = [];

  alreadySelectedEpisode: ShowHierarchy;

  validSeasons: string[] = [];

  seriesData: any = {};

  seasonCount: number = 0;

  data: any = {};
  private destroy = inject(DestroyRef);

  ngOnInit(): void {
    var keyForFetchData = {
      contentId: this.obj.showId,
      countryCode: this.obj.countryCode,
      vcCpId: this.obj.vcCpId,
    };
    var payload = {
      contentId: this.obj.contentId,
      countryCode: this.obj.countryCode,
      vcCpId: this.obj.vcCpId,
      seasonId: this.obj.seasonId,
      showId: this.obj.showId,
    };
    this.assetService
      .getShowHierarchy(keyForFetchData)
      .subscribe((res: any) => {
        this.allAssetsData = plainToInstance<ShowHierarchy, []>(
          ShowHierarchy,
          res
        );
        for (const val of res) {
          if (val.seasonNo !== null && val.seasonNo !== undefined) {
            if (!(val.seasonNo in this.data)) {
              this.data[val.seasonNo] = [] as ShowHierarchy[];
            }
            this.data[val.seasonNo].push(val);
          }
        }

        this.seasons = this.allAssetsData.map((a) => a.seasonNo.toString());
        this.seasons = this.seasons.filter(
          (item, pos) => this.seasons.indexOf(item) === pos
        );

        this.seasons.forEach((s) => {
          const all = this.allAssetsData.filter(
            (a) => a.seasonNo.toString() === s
          );
          const episodes: any[] = [];
          for (const val of all) {
            if (
              !(
                val.seasonNo === this.obj.seasonNo &&
                val.episodeNo === this.obj.episodeNo &&
                val.contentId === this.obj.contentId
              )
            ) {
              episodes.push(
                `S${s}:E${val.episodeNo}-${val.mainTitle}*&*${val.contentId}`
              );
            } else {
              this.alreadySelectedEpisode = val;
            }
            this.episodeContentIdMap[
              `S${s}:E${val.episodeNo}-${val.mainTitle}*&*${val.contentId}`
            ] = val;
          }

          if (episodes.length > 0) {
            this.seasonEpisodeMap[s] = episodes;
            this.validSeasons.push(s);
          }
        });
        this.seasons = [...this.validSeasons];
      });

    //series info
    this.assetService
      .getSeriesInfo(payload)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.seriesData = { ...res };
      });

    this.fSeason.valueChanges.subscribe((selectedSeasons: any) => {
      this.episodesList = [];
      this.seasonCount = selectedSeasons?.length;
      selectedSeasons?.forEach((s: string) => {
        if (s) {
          this.episodesList = [
            ...this.episodesList,
            ...this.seasonEpisodeMap[s],
          ];
        }
      });

      if (this.fEpisode.value?.length) {
        let episodes = this.fEpisode.value.filter((v) =>
          this.episodesList.includes(v)
        );
        this.fEpisode.setValue(episodes);
      }

      if (this.episodesList.length) {
        this.fEpisode.enable();
      } else {
        this.fEpisode.disable();
      }

      this.inValidEpisodes = this.episodesList.filter((ep: string) => {
        return !this.validStatuses.includes(
          this.episodeContentIdMap[ep].status
        );
      });

      this.validEpisodes = this.episodesList.filter((ep: string) => {
        return this.validStatuses.includes(this.episodeContentIdMap[ep].status);
      });
    });

    this.fEpisode.valueChanges.subscribe((v: any) => {
      this.selectedEpisodes = [];
      for (const ep of v) {
        this.selectedEpisodes.push(this.episodeContentIdMap[ep]);
      }
    });
  }

  episodeContentIdMap: any = {};

  removeSeason(e: Event, s: string) {
    e.stopPropagation();
    let values: string[] = this.fSeason.value || [];
    values = values?.filter((v) => v !== s && v);
    this.fSeason.setValue(values);
  }

  removeEpisode(e: Event, s: string) {
    e.stopPropagation();
    let values: string[] = this.fEpisode.value || [];
    values = values?.filter((v) => v !== s && v);
    this.fEpisode.setValue(values);
  }

  bulkEditAssets() {
    if (this.alreadySelectedEpisode) {
      this.selectedEpisodes.push(this.alreadySelectedEpisode);
    }

    this.seriesData['all'] = { ...this.data };

    this.seriesData['all'][this.alreadySelectedEpisode.seasonNo].push(
      this.alreadySelectedEpisode
    );
    this.seriesData['all']['current'] = this.alreadySelectedEpisode.seasonNo;
    this.dialogRef.close({
      selectedEpisode: this.selectedEpisodes,
      seriesData: this.seriesData,
      seasonCount: this.seasonCount,
    });
  }

  cancel() {
    this.dialogRef.close();
  }
  formControl = new FormControl(['angular']);

  validStatuses: string[] = [
    'Ready for QC',
    'QC in Progress',
    'QC Fail',
    'Ready for Release',
    'Released',
    'Expired',
    'Revoked',
  ];

  validStatus(key: string): boolean {
    return this.validStatuses.includes(key);
  }
}
