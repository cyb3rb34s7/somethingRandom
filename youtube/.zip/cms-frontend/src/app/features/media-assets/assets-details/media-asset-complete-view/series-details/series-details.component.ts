import { Component, Input } from '@angular/core';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';

@Component({
    selector: 'app-series-details',
    imports: [AppMatInputComponent],
    templateUrl: './series-details.component.html',
    styleUrl: './series-details.component.scss'
})
export class SeriesDetailsComponent {
  @Input() data: any = {};
  ngOnInit() {}
}
