import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { AppMatSimpleSearchComponent } from '../../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';

import { AvailablePlatform } from '../../../../../models/asset-available-platform-model';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NoRecordFoundComponent } from '../no-record-found/no-record-found.component';

@Component({
  selector: 'app-available-platform',
  imports: [
    MatCheckbox,
    FormsModule,
    MatSelectModule,
    MatButtonModule,
    AppMatSimpleSearchComponent,
    MatRadioModule,
    MatTooltipModule,
    NoRecordFoundComponent,
  ],
  templateUrl: './available-platform.component.html',
  styleUrl: './available-platform.component.scss',
})
export class AvailablePlatformComponent {
  @Input() assets: any;
  @Input() isDisabled: boolean;
  @Input() bulkEditFlag: boolean;
  @Input() data: any;

  @Output() platformChange = new EventEmitter<any>();
  availablePlatform: AvailablePlatform = {
    type: 'common',
    tvValues: [],
    tvItems: [],
    mobileItems: [],
    mobileValues: [],
    fHubItems: [],
    fHubValues: [],
    webItems: [],
    webValues: [],
  };
  tvItems: { platformName: string; platformAlias?: string }[] = [];
  mobItems: { platformName: string; platformAlias?: string }[] = [];
  fhubItems: { platformName: string; platformAlias?: string }[] = [];
  webItems: { platformName: string; platformAlias?: string }[] = [];
  ngOnInit() {
    this.availablePlatform = { ...this.data };
    this.currentItem =
      this.availablePlatform.type === 'deny'
        ? 2
        : this.availablePlatform.type === 'allow'
        ? 1
        : 0;
    this.tvItems = [...this.availablePlatform.tvItems];
    this.mobItems = [...this.availablePlatform.mobileItems];
    this.webItems = [...this.availablePlatform.webItems];
    this.fhubItems = [...this.availablePlatform.fHubItems];
    for (var item of this.tvItems) {
      item.platformAlias = this.setAliasNamesRule(item.platformName);
    }
    for (var item of this.webItems) {
      item.platformAlias = this.setAliasNamesRule(item.platformName);
    }
    for (var item of this.mobItems) {
      item.platformAlias = this.setAliasNamesRule(item.platformName);
    }
    for (var item of this.fhubItems) {
      item.platformAlias = this.setAliasNamesRule(item.platformName);
    }
  }
  currentItem: number = 0;
  platformButtons: string[] = ['All', 'Platform Allow', 'Platform Deny'];
  temporaryAvailablePlatform: any = {};

  onPlatformClick(index: number) {
    if (this.availablePlatform.type === this.assets['platformTag']) {
      this.temporaryAvailablePlatform = { ...this.availablePlatform };
    }

    this.currentItem = index;
    this.availablePlatform.type =
      index === 0 ? 'common' : index === 1 ? 'allow' : 'deny';
    if (this.availablePlatform.type === this.assets['platformTag']) {
      this.availablePlatform.mobileValues =
        this.temporaryAvailablePlatform['mobileValues'];
      this.availablePlatform.tvValues =
        this.temporaryAvailablePlatform['tvValues'];
      this.availablePlatform.webValues =
        this.temporaryAvailablePlatform['webValues'];
      this.availablePlatform.fHubValues =
        this.temporaryAvailablePlatform['fHubValues'];
    } else {
      this.availablePlatform.mobileValues = [];
      this.availablePlatform.tvValues = [];
      this.availablePlatform.webValues = [];
      this.availablePlatform.fHubValues = [];
    }
    this.emitChanges();
  }

  onSelectAllMobilePlatform(event: any) {
    if (event.checked) {
      this.availablePlatform.mobileValues = [
        ...this.availablePlatform.mobileValues,
        ...this.mobItems,
      ];
    } else {
      this.availablePlatform.mobileValues =
        this.availablePlatform.mobileValues.filter((item) => {
          const exists = this.mobItems.some(
            (it) => it.platformName === item.platformName
          );
          return !exists;
        });
    }
    this.emitChanges();
  }
  onAvailablePlatformChange(
    event: any,
    item: { platformName: string; platformAlias?: string }
  ) {
    const exists = this.availablePlatform.mobileValues.some(
      (ite) => ite.platformName === item.platformName
    );
    if (event.checked) {
      if (!exists) {
        this.availablePlatform.mobileValues.push(item);
      }
    } else {
      this.availablePlatform.mobileValues =
        this.availablePlatform.mobileValues.filter(
          (i) => item.platformName !== i.platformName
        );
    }
    this.emitChanges();
  }
  onSelectAllTvPlatform(event: any) {
    if (event.checked) {
      this.availablePlatform.tvValues = [
        ...this.availablePlatform.tvValues,
        ...this.tvItems,
      ];
    } else {
      this.availablePlatform.tvValues = this.availablePlatform.tvValues.filter(
        (item) => {
          const exists = this.tvItems.some(
            (it) => it.platformName === item.platformName
          );
          return !exists;
        }
      );
    }
    this.emitChanges();
  }
  onAvailableTvPlatformChange(
    event: any,
    item: { platformName: string; platformAlias?: string }
  ) {
    const exists = this.availablePlatform.tvValues.some(
      (ite) => ite.platformName === item.platformName
    );
    if (event.checked) {
      if (!exists) {
        this.availablePlatform.tvValues.push(item);
      }
    } else {
      this.availablePlatform.tvValues = this.availablePlatform.tvValues.filter(
        (i) => item.platformName !== i.platformName
      );
    }
    this.emitChanges();
  }
  onSelectAllWebPlatform(event: any) {
    if (event.checked) {
      this.availablePlatform.webValues = [
        ...this.availablePlatform.webValues,
        ...this.webItems,
      ];
    } else {
      this.availablePlatform.webValues =
        this.availablePlatform.webValues.filter((item) => {
          const exists = this.webItems.some(
            (it) => it.platformName === item.platformName
          );
          return !exists;
        });
    }
    this.emitChanges();
  }
  onAvailableWebPlatformChange(
    event: any,
    item: { platformName: string; platformAlias?: string }
  ) {
    const exists = this.availablePlatform.tvValues.some(
      (ite) => ite.platformName === item.platformName
    );
    if (event.checked) {
      if (!exists) {
        this.availablePlatform.webValues.push(item);
      }
    } else {
      this.availablePlatform.webValues =
        this.availablePlatform.webValues.filter(
          (i) => item.platformName !== i.platformName
        );
    }
    this.emitChanges();
  }
  onSelectAllFHubPlatform(event: any) {
    if (event.checked) {
      this.availablePlatform.fHubValues = [
        ...this.availablePlatform.fHubValues,
        ...this.fhubItems,
      ];
    } else {
      this.availablePlatform.fHubValues =
        this.availablePlatform.fHubValues.filter((item) => {
          const exists = this.fhubItems.some(
            (it) => it.platformName === item.platformName
          );
          return !exists;
        });
    }
    this.emitChanges();
  }
  onAvailableFHubPlatformChange(
    event: any,
    item: { platformName: string; platformAlias?: string }
  ) {
    const exists = this.availablePlatform.tvValues.some(
      (ite) => ite.platformName === item.platformName
    );
    if (event.checked) {
      if (!exists) {
        this.availablePlatform.fHubValues.push(item);
      }
    } else {
      this.availablePlatform.fHubValues =
        this.availablePlatform.fHubValues.filter(
          (i) => item.platformName !== i.platformName
        );
    }
    this.emitChanges();
  }
  emitChanges() {
    this.platformChange.emit({
      ...this.availablePlatform,
    });
  }
  onSearchTrigger(evt: any, type: string) {
    switch (type) {
      case 'TV':
        this.tvItems = [...this.availablePlatform.tvItems];
        this.tvItems = this.tvItems.filter((item) =>
          item.platformAlias?.toLowerCase().includes(evt.toLowerCase())
        );
        break;
      case 'MOB':
        this.mobItems = [...this.availablePlatform.mobileItems];
        this.mobItems = this.mobItems.filter((item) =>
          item.platformAlias?.toLowerCase().includes(evt.toLowerCase())
        );
        break;
      case 'WEB':
        this.webItems = [...this.availablePlatform.webItems];
        this.webItems = this.webItems.filter((item) =>
          item.platformAlias?.toLowerCase().includes(evt.toLowerCase())
        );
        break;
      case 'FHUB':
        this.fhubItems = [...this.availablePlatform.fHubItems];
        this.fhubItems = this.fhubItems.filter((item) =>
          item.platformAlias?.toLowerCase().includes(evt.toLowerCase())
        );
        break;
    }
  }
  checkForSelectAll(typ: any) {
    switch (typ) {
      case 'TV':
        for (var item of this.tvItems) {
          if (!this.availablePlatform.tvValues.includes(item)) {
            return false;
          }
        }
        return true;

      case 'MOB':
        for (var item of this.mobItems) {
          if (!this.availablePlatform.mobileValues.includes(item)) {
            return false;
          }
        }
        return true;
      case 'WEB':
        for (var item of this.webItems) {
          if (!this.availablePlatform.webValues.includes(item)) {
            return false;
          }
        }
        return true;
      case 'FHUB':
        for (var item of this.fhubItems) {
          if (!this.availablePlatform.fHubValues.includes(item)) {
            return false;
          }
        }
        return true;
    }
    return false;
  }
  checkForDisable() {
    if (this.currentItem === 0) return true;
    return this.bulkEditFlag || this.isDisabled;
  }

  setAliasNamesRule(aliasData: any) {
    let year = '';
    let version = '';
    let device = '';
    version = aliasData.match(/[^_]*$/)[0];
    if (version == null) version = '0.0';
    else version = aliasData.match(/[^_]*$/)[0];
    if (aliasData.indexOf('FREESIA') >= 0) {
      device = 'TV';

      if (aliasData.indexOf('ALL') >= 0) {
        device = 'ALL_' + device;
      }

      if (
        aliasData.match(/[^_]+(?=_[^_]*$)/)[0] != null ||
        aliasData.match(/[^_]+(?=_[^_]*$)/)[0] != undefined
      ) {
        if (aliasData.match(/[^_]+(?=_[^_]*$)/)[0] == 'ALL') {
          aliasData = device + '_' + 'v' + version;
        } else {
          year = aliasData.match(/[^_]+(?=_[^_]*$)/)[0];
          aliasData = year + 'Y' + ' ' + device + '_' + 'v' + version;
        }
      }
    } else if (aliasData.indexOf('FHUB') >= 0) {
      device = 'FHUB';
      aliasData = device + '_' + 'v' + version;
    } else if (aliasData.indexOf('ANDROID') >= 0) {
      device = 'ANDROID';
      aliasData = device + '_' + 'v' + version;
    } else if (aliasData.indexOf('WEB') >= 0) {
      device = 'WEB';
      aliasData = device + '_' + 'v' + version;
    }
    return aliasData;
  }

  checkForSelected(
    item: { platformName: string; platformAlias?: string },
    type: string
  ) {
    var exists = false;
    switch (type) {
      case 'TV':
        exists = this.availablePlatform.tvValues.some(
          (ite) => ite.platformName === item.platformName
        );
        return exists || this.currentItem === 0;

      case 'MOB':
        exists = this.availablePlatform.mobileValues.some(
          (ite) => ite.platformName === item.platformName
        );
        return exists || this.currentItem === 0;
      case 'WEB':
        exists = this.availablePlatform.webValues.some(
          (ite) => ite.platformName === item.platformName
        );
        return exists || this.currentItem === 0;
      case 'FHUB':
        exists = this.availablePlatform.fHubValues.some(
          (ite) => ite.platformName === item.platformName
        );
        return exists || this.currentItem === 0;
    }
    return exists;
  }
}
