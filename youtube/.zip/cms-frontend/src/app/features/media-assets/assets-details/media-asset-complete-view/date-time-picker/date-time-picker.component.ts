import { Component, Inject, Input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
    selector: 'app-date-time-picker',
    imports: [
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule,
        ReactiveFormsModule,
        FormsModule,
        MatButtonModule,
    ],
    providers: [],
    templateUrl: './date-time-picker.component.html',
    styleUrl: './date-time-picker.component.scss'
})
export class DateTimePickerComponent {
  constructor(
    public dialogRef: MatDialogRef<DateTimePickerComponent>,
    @Inject(MAT_DIALOG_DATA) public inputDate: any
  ) {}
  selectedDate: string = '';
  selectedTime: string = '';
  dateTime: string = '';
  onDateChange(event: any) {
    this.selectedDate = event.target.value;
  }
  onTimeChange(event: any) {
    this.selectedTime = event.target.value;
  }

  onSubmit() {
    this.dateTime = this.selectedDate + ' ' + this.selectedTime;
    this.dialogRef.close(this.dateTime);
  }
  ngOnInit() {
    if (this.inputDate?.date) {
      const [date, time] = this.inputDate?.date?.split(' ');
      this.selectedDate = date;
      this.selectedTime = time;
    }
  }
  isValid() {
    if (!this.selectedDate || !this.selectedTime) {
      return false;
    }
    return true;
  }
}
