import {
  Component,
  EventEmitter,
  Input,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { AppMatSelectComponent } from '../../modals/app-mat-select/app-mat-select.component';
import { NoRecordFoundComponent } from '../../no-record-found/no-record-found.component';
import { MatButtonModule } from '@angular/material/button';
import { RatingData } from '../../../../../../interfaces/rating-data';
import { boolean } from 'zod';

@Component({
  selector: 'app-parental-ratings',
  imports: [AppMatSelectComponent, NoRecordFoundComponent, MatButtonModule],
  templateUrl: './parental-ratings.component.html',
  styleUrl: './parental-ratings.component.scss',
})
export class ParentalRatingsComponent {
  constructor() {}

  @Input() parentalRatings: any;
  @Input() ratings: string;
  @Input() disabled: boolean = false;
  @Input() name: string;
  masterData: { [key: string]: string[] } = {};
  orgList: string[] = [];
  ratingList: string[] = [];

  @Output() currentValue = new EventEmitter<any>();

  @ViewChildren('matSelect', { read: AppMatSelectComponent })
  matSelects: QueryList<AppMatSelectComponent>;

  parentalRatingsCopy: RatingData[] | any[] = [];

  ngOnInit() {
    //this.parentalRatingsCopy = JSON.parse(JSON.stringify(this.parentalRatings));

    for (const obj of this.parentalRatings) {
      this.masterData[obj.body] = obj.ratings.split(',');
    }
    if (this.ratings) {
      for (const rating of this.ratings?.split(',')) {
        const org = Object.keys(this.masterData).find((el) =>
          this.masterData[el].includes(rating)
        );
        if (org) {
          this.parentalRatingsCopy.push({
            body: org,
            ratings: rating,
          });
        }
      }
    }

    this.orgList = Object.keys(this.masterData);
  }

  dropDownValueChangeRatings(obj: any, index: number, key: 'body' | 'ratings') {
    this.parentalRatingsCopy[index][key] = obj['value']?.trim();
    if (
      !this.getRatingsItemList(
        index,
        this.parentalRatingsCopy[index]['body']
      ).includes(this.parentalRatingsCopy[index]['ratings'])
    ) {
      this.parentalRatingsCopy[index]['ratings'] = '';
    }
    this.emitChanges();
  }

  deleteRatings(index: number) {
    if (!this.disabled) {
      this.parentalRatingsCopy.splice(index, 1);
      this.emitChanges(true);
      this.matSelects.forEach((select) => {
        select.selectFormControl?.markAsDirty();
      });
    }
  }
  emitChanges(change?: boolean) {
    const newRatingVal = this.parentalRatingsCopy
      .map((el) => el.ratings)
      .join(',');

    this.currentValue.emit({
      name: this.name,
      valid: true,
      value: newRatingVal,
      parentalVal: [...this.parentalRatingsCopy],
    });
  }
  addEmptyParentalRatings() {
    this.parentalRatingsCopy.push({
      body: '',
      ratings: '',
    });
  }
  getRatingsItemList(index: number, body: string) {
    return this.masterData[body];
  }

  triggerValidation() {
    this.matSelects.forEach((select) => select.triggerElement());
  }
}
