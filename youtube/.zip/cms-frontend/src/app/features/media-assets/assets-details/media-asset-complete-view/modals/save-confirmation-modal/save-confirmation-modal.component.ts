import { Component, DestroyRef, inject, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../../../mat-components/app-mat-select/app-mat-select.component';
import { MatRadioGroupComponent } from '../../../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { AssetService } from '../../../../../../services/asset.service';
import { SIDE_NAV_ROUTES } from '../../../../../../constants/app-consts';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';

@Component({
    selector: 'app-save-confirmation-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './save-confirmation-modal.component.html',
    styleUrl: './save-confirmation-modal.component.scss'
})
export class SaveConfirmationModalComponent {
  changedArray: string[] = [];
  ngOnInit() {
    this.changedArray = this.data.changedArray;
  }
  private destroy = inject(DestroyRef);

  constructor(
    public dialogRef: MatDialogRef<SaveConfirmationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private assetService: AssetService,
    private toastr: CustomToastrService,
    private router: Router
  ) {}

  onUpdate() {
    if (
      this.data.data.contentIds !== null &&
      this.data.data.contentIds.length > 0 &&
      this.changedArray.length > 0
    ) {
      this.assetService
        .updateAssetByBulk(this.data.data)
        .pipe(takeUntilDestroyed(this.destroy))
        .subscribe((res) => {
          this.toastr.success(res);
          this.dialogRef.close(true);
          this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
        });
    } else if (this.changedArray.length > 0) {
      this.assetService
        .updateAsset(this.data.data)
        .pipe(takeUntilDestroyed(this.destroy))
        .subscribe((res) => {
          this.toastr.success(res);
          this.dialogRef.close(true);
          this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
        });
    } else {
      this.dialogRef.close(true);
      this.router.navigate(['/' + SIDE_NAV_ROUTES.MEDIA.route_link]);
    }
  }
}
