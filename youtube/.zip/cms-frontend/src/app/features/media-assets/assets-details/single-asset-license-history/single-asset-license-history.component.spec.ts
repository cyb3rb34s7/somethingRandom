import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleAssetLicenseHistoryComponent } from './single-asset-license-history.component';

describe('SingleAssetLicenseHistoryComponent', () => {
  let component: SingleAssetLicenseHistoryComponent;
  let fixture: ComponentFixture<SingleAssetLicenseHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SingleAssetLicenseHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SingleAssetLicenseHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
