import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwitchConfirmationModelComponent } from './switch-confirmation-model.component';

describe('SwitchConfirmationModelComponent', () => {
  let component: SwitchConfirmationModelComponent;
  let fixture: ComponentFixture<SwitchConfirmationModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SwitchConfirmationModelComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SwitchConfirmationModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
