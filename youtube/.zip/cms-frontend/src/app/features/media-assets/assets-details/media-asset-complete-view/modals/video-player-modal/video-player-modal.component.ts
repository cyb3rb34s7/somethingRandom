import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  ElementRef,
  Inject,
  inject,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import Hls from 'hls.js';
import { AssetVideoSegment } from '../../../../../../models/asset-video-segment-model';
import { AppMatTableComponent } from '../../../../../../mat-components/app-mat-table/app-mat-table.component';
import { CommonModule } from '@angular/common';
import { AppMatSelectComponent } from '../app-mat-select/app-mat-select.component';
import { TABLE_CONSTS } from '../../../../../../constants/table-consts';
import { MatTabsModule } from '@angular/material/tabs';
import { DOTS_CONSTS } from '../../../../../../constants/color-dots-consts';
import { STATUS_CONSTANTS } from '../../../../../../constants/status-consts';
import { AssetService } from '../../../../../../services/asset.service';
import { Clipboard } from '@angular/cdk/clipboard';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CopyTooltipDirective } from '../../../../../../directives/copy-tooltip.directive';

@Component({
    selector: 'app-video-player-modal',
    imports: [
        MatDialogModule,
        AppMatTableComponent,
        CommonModule,
        AppMatSelectComponent,
        MatTabsModule,
        MatTooltipModule,
        CopyTooltipDirective,
    ],
    templateUrl: './video-player-modal.component.html',
    styleUrl: './video-player-modal.component.scss'
})
export class VideoPlayerModalComponent {
  handleTabChange($event: Event) {
    throw new Error('Method not implemented.');
  }
  labels: any;
  constructor(
    private assetService: AssetService,
    public dialogRef: MatDialogRef<VideoPlayerModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private changeDetectorRef: ChangeDetectorRef,
    private clipBoard: Clipboard
  ) {}

  allSegmentData: any[];
  tableData: any[] = [];
  expandedTableData: any[] = [];

  currentVideoSrc: string;
  currentVersion: any;

  drm: boolean = this.data['drm'] === 'Y';
  videoDuration: number = this.data['runningTime'];
  @ViewChild('videoPlayer', { static: false })
  videoPlayer!: ElementRef<HTMLVideoElement>;

  ads: { time: number; duration: number }[] = [];
  progressPercentage: number = 0;
  adMarkerColor: string = '#AB00FF';
  movieMarkerColor: string = '#05004E';

  hls: Hls;
  qualityLevels: string[] = [];
  isHlsSupported: boolean = false;
  qualityTypes: { quality: string; resolution: number }[] = [
    { quality: 'LD', resolution: 360 },
    { quality: 'SD', resolution: 480 },
    { quality: 'HD', resolution: 720 },
    { quality: 'FHD', resolution: 1080 },
    { quality: '4K', resolution: 2160 },
    { quality: 'UHD', resolution: 4320 },
  ];
  myQualityMap: { [key: string]: number } = {};

  private destroy = inject(DestroyRef);

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngAfterViewInit() {
    this.fetchSegments();
  }

  updateQuality(newQuality: string): void {
    if (newQuality === 'Auto') {
      this.hls.currentLevel = -1;
      return;
    }

    const qualityHeight = this.myQualityMap[newQuality];

    for (const [levelInd, level] of this.hls.levels.entries()) {
      if (level.height === qualityHeight) {
        this.hls.currentLevel = levelInd;

        console.log({
          'Current Level': this.hls.currentLevel,
          'New Level Index': levelInd,
          'New Resolution': qualityHeight + 'p',
          'Found Quality Match With': newQuality,
        });

        break;
      }
    }
  }

  fetchSegments(): void {
    this.assetService
      .getStreamUriAddBreaks(
        this.data['contentId'],
        this.data['vcCpId'],
        this.data['countryCode']
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((resp: any) => {
        resp = resp.sort((a: any, b: any) => b.version - a.version);
        this.playVideo(resp[0]);
        this.allSegmentData = resp;

        this.prepareTableData(this.allSegmentData);
      });
  }

  prepareTableData(segments: any) {
    segments = segments.sort((a: any, b: any) => b.version - a.version);
    let isProdFound: boolean = false;
    segments = segments.map((val: any, index: number) => {
      if (index === 0 && val.status === 'Revoked') {
        val.onStg = 'N';
      } else if (index === 0) {
        val.onStg = 'Y';
      } else {
        val.onStg = 'N/A';
      }
      return val;
    });
    segments = segments.map((val: any) => {
      if (val.onPrd === 'Y' && !isProdFound) {
        val.onPrd = 'Y';
        isProdFound = true;
      } else if (val.onPrd === 'Y' && isProdFound) {
        val.onPrd = 'N/A';
      } else if (val.onPrd === 'N') {
        val.onPrd = 'N';
      }
      return val;
    });
    this.tableData = segments.map((v: any, index: number) => {
      const obj: any = {};
      obj[TABLE_CONSTS.RENDER_VIDEO_PLAYBACK_URL] = [index, v.streamUri, v];
      obj['Version'] = String(v.version);
      obj[TABLE_CONSTS.RENDER_VIDEO_ON_STAG_STATUS_COLUMN] = [
        this.fetchStagAndProdStatus(v.onStg),
        '',
        v.onStg === 'Y' ? 'Active' : v.onStg === 'N' ? 'Inactive' : 'N/A',
      ];
      obj[TABLE_CONSTS.RENDER_VIDEO_ON_PROD_STATUS_COLUMN] = [
        this.fetchStagAndProdStatus(v.onPrd),
        '',
        v.onPrd === 'Y' ? 'Active' : v.onPrd === 'N' ? 'Inactive' : 'N/A',
      ];
      obj[TABLE_CONSTS.RENDER_STATUS_COLUMN] = [
        this.fetchQCStatusDot(v.status),
        '',
        v.status,
      ];
      obj[TABLE_CONSTS.RENDER_ADD_BREAKS] = this.prepareExpandedRows(
        v['adBreaks']
      );

      return obj;
    });
  }

  prepareExpandedRows(segments: AssetVideoSegment[]) {
    this.expandedTableData = segments
      .sort((a, b) => a.order - b.order)
      .map((segment: any) => {
        const obj: any = {};
        obj['Mark In'] = segment.markIn;
        obj['Mark Out'] = segment.markOut;
        obj['Duration'] = segment.duration;
        obj['Order'] = String(segment.order);
        obj['AD Break Duration (Sec)'] = segment.adBreakDurationSeconds
          ? String(segment.adBreakDurationSeconds)
          : segment.adBreakDurationSeconds;

        return obj;
      });
    return this.expandedTableData;
  }

  convertToSecond(time: string): number {
    const timeArr: string[] = time?.split(';');
    const arr: number[] = timeArr[0]?.split(':').map((x) => +x);
    if (arr.length == 3) return arr[0] * 3600 + arr[1] * 60 + arr[2];
    else if (arr.length == 2) return arr[0] * 60 + arr[1];
    else return arr[0];
  }

  updateProgressBar(currentTime: number) {
    this.progressPercentage = (currentTime / this.videoDuration) * 100;
  }

  fetchQCStatusDot(value: string) {
    if (!value) return;
    if (value.includes(STATUS_CONSTANTS.EXPIRED)) {
      return DOTS_CONSTS.STATUS_DOT_EXPIRED;
    } else if (value.includes(STATUS_CONSTANTS.INPROGRESS)) {
      return DOTS_CONSTS.STATUS_DOT_IN_PROGRESS;
    } else if (value.includes(STATUS_CONSTANTS.QCFAIL)) {
      return DOTS_CONSTS.STATUS_DOT_QCFAIL;
    } else if (value.includes(STATUS_CONSTANTS.QCPASS)) {
      return DOTS_CONSTS.STATUS_DOT_QCPASS;
    } else if (value.includes(STATUS_CONSTANTS.QCREADY)) {
      return DOTS_CONSTS.STATUS_DOT_READY;
    } else if (value.includes(STATUS_CONSTANTS.RELEASED)) {
      return DOTS_CONSTS.STATUS_DOT_RELEASED;
    } else if (value.includes(STATUS_CONSTANTS.RELEASEREADY)) {
      return DOTS_CONSTS.STATUS_DOT_RELEASEREADY;
    } else if (value.includes(STATUS_CONSTANTS.TQCPASS)) {
      return DOTS_CONSTS.STATUS_DOT_TQCPASS;
    } else if (value.includes(STATUS_CONSTANTS.UNTRACKABLE)) {
      return '';
    } else if (
      value.toLowerCase().includes(STATUS_CONSTANTS.ACTIVE.toLowerCase())
    ) {
      return DOTS_CONSTS.STATUS_DOT_ACTIVE;
    } else if (value.includes(STATUS_CONSTANTS.REVOKED)) {
      return DOTS_CONSTS.STATUS_DOT_REVOKED;
    } else return '';
  }

  fetchStagAndProdStatus(value: String) {
    if (value === 'Y') {
      return DOTS_CONSTS.STATUS_DOT_ACTIVE;
    } else if (value === 'N') {
      return DOTS_CONSTS.STATUS_DOT_INACTIVE;
    } else if (value === 'N/A') {
      return '';
    } else return '';
  }

  playVideo(segment: any) {
    const video = this.videoPlayer.nativeElement;
    this.currentVideoSrc = segment.streamUri;
    this.currentVersion = segment.version;
    const videoSrc = segment.streamUri;

    if (Hls.isSupported()) {
      this.hls = new Hls();
      this.isHlsSupported = true;
      this.hls.loadSource(videoSrc);
      this.hls.attachMedia(video);
      this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
        this.qualityLevels = ['Auto'];
        this.myQualityMap = {};

        this.hls.levels.forEach((level) => {
          let levelQuality: string = 'Auto';
          for (const { quality, resolution } of this.qualityTypes) {
            if (resolution <= level.height) {
              levelQuality = quality;
            } else {
              break;
            }
          }
          this.myQualityMap[levelQuality] = level.height;
          this.qualityLevels.push(levelQuality);
        });

        video.play();
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = videoSrc;
      video.addEventListener('loadedmetadata', () => {
        video.play();
      });
    }

    this.creatAddsForVideo(segment);
  }

  creatAddsForVideo(segment: any) {
    this.ads = [];
    for (let addBreak of segment['adBreaks']) {
      if (
        addBreak.insertAdMarkers === 'Y' &&
        this.convertToSecond(addBreak.markOut) < this.videoDuration
      ) {
        this.ads.push({
          time: this.convertToSecond(addBreak.markIn),
          duration:
            this.convertToSecond(addBreak.markOut) -
            this.convertToSecond(addBreak.markIn),
        });
      }
    }
  }

  onAction(eventIcon: any, eventData: any) {
    this.playVideo(eventData);
  }
  copyUrl() {
    this.clipBoard.copy(this.currentVideoSrc);
  }
  min(a: any, b: any) {
    if (a < b) return a;
    return b;
  }
  ngOnDestroy() {
    this.hls?.destroy();
    const video = this.videoPlayer?.nativeElement;
    video?.pause();
    video?.remove();
  }
}
