import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaAssetCompleteViewComponent } from './media-asset-complete-view.component';

describe('MediaAssetCompleteViewComponent', () => {
  let component: MediaAssetCompleteViewComponent;
  let fixture: ComponentFixture<MediaAssetCompleteViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MediaAssetCompleteViewComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(MediaAssetCompleteViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
