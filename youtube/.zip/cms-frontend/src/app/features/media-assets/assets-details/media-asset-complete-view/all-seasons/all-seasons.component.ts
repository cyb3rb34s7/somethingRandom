import { Component, Input } from '@angular/core';
import { MatAccordianComponent } from '../../../../../mat-components/mat-accordian/mat-accordian.component';

import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';

@Component({
    selector: 'app-all-seasons',
    imports: [MatListModule, MatExpansionModule],
    templateUrl: './all-seasons.component.html',
    styleUrl: './all-seasons.component.scss'
})
export class AllSeasonsComponent {
  @Input() data: any = {};
  seasons: number[] = [];
  ngOnInit() {
    for (var key in this.data) {
      if (key && key !== 'current') {
        this.seasons.push(+key);
      }
    }
  }
}
