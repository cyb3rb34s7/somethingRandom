import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoComparisonAvailableComponent } from './no-comparison-available.component';

describe('NoComparisonAvailableComponent', () => {
  let component: NoComparisonAvailableComponent;
  let fixture: ComponentFixture<NoComparisonAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NoComparisonAvailableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NoComparisonAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
