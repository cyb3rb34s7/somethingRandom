import { TestBed } from '@angular/core/testing';

import { AssetHelperService } from './utils/asset-helper.service';

describe('AssetHelperService', () => {
  let service: AssetHelperService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetHelperService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
