import { Component, EventEmitter, Inject, Output } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { FormsModule } from '@angular/forms';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../../../mat-components/app-mat-select/app-mat-select.component';

@Component({
  selector: 'app-deeplink-info-modal',
  templateUrl: './deeplink-info-modal.component.html',
  styleUrls: ['./deeplink-info-modal.component.scss'],
  imports: [
    MatDialogModule,
    CommonModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatIconModule,
    MatExpansionModule,
    FormsModule,
    AppMatInputComponent,
  ],
})
export class DeeplinkInfoModalComponent {
  deeplinkData: any = {};
  parsedDeeplink: any = {};
  isEventActive: boolean = false;
  originalDeeplinkData: any = {};

  constructor(
    public dialogRef: MatDialogRef<DeeplinkInfoModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.deeplinkData = data.deeplinkData || {};
    this.originalDeeplinkData = this.deeplinkData;
    this.parseDeeplinkData();
  }

  parseDeeplinkData() {
    try {
      const payload = JSON.parse(this.deeplinkData);
      this.parsedDeeplink = payload.deeplink_data || {};
      this.isEventActive = this.parsedDeeplink.event === 'Y';
    } catch (error) {
      console.error('Error parsing deeplink data:', error);
      this.parsedDeeplink = {};
    }
  }

  onClose(): void {
    this.dialogRef.close();
  }
}
