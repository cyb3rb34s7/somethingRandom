export const assetBasicInformation: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Program Id',
    value: 'contentId',
    validators: { minLength: 1, maxLength: 125 },
  },
  {
    key: 'Asset Id',
    value: 'assetId',
    validators: { minLength: 1, maxLength: 100 },
  },
  {
    key: 'Program Type',
    value: 'type',
    validators: {
      minLength: 1,
      maxLength: 20,
    },
  },
  {
    key: 'Country',
    value: 'countryCode',
    validators: { maxLength: 2 },
  },
  {
    key: 'Main Title',
    value: 'mainTitle',
    validators: { minLength: 1, maxLength: 200 },
  },
  {
    key: 'Main Title Language',
    value: 'language',
    validators: { minLength: 1, maxLength: 200 },
  },
  {
    key: 'Short Title',
    value: 'shortTitle',
    validators: { minLength: 1, maxLength: 200 },
  },
  {
    key: 'Short Title Language',
    value: 'language',
    validators: { minLength: 1, maxLength: 200 },
  },

  {
    key: 'Show ID',
    value: 'showId',
    validators: { pattern: '^[0-9A-Za-z_-]+$' },
  },
  {
    key: 'Show Title',
    value: 'showTitle',
    validators: {},
  },
  {
    key: 'Season ID',
    value: 'seasonId',
    validators: {
      type: 'text',
      pattern: '^[0-9A-Za-z_-]+$',
      maxLength: 125,
      minLength: 0,
    },
  },
  {
    key: 'Season Title',
    value: 'seasonTitle',
    validators: {},
  },
  {
    key: 'Season Number',
    value: 'seasonNo',
    validators: {
      type: 'number',
      minValue: 1,
      maxValue: 99999,
    },
  },
  {
    key: 'Episode Number',
    value: 'episodeNo',
    validators: {
      type: 'number',
      minValue: 1,
      maxValue: 99999,
    },
  },
  {
    key: 'Duration (sec)',
    value: 'runningTime',
    validators: {
      type: 'number',
      maxLength: 20,
      maxValue: 21600,
      minValue: 1,
      pattern: '^0*[1-9]\\d*$',
    },
  },
  {
    key: 'Ad Tags',
    value: 'adTag',
    validators: { minLength: 1, maxLength: 2000 },
  },
  {
    key: 'Stream URL',
    value: 'streamUri',
    validators: {
      type: 'url',
      pattern: '^(http|https)://(.)*$',
    },
  },

  {
    key: 'Description Language',
    value: 'language',
    validators: { minLength: 1, maxLength: 200 },
  },
  {
    key: 'Synopsis Description',
    value: 'description',
    validators: { minLength: 1, maxLength: 4000 },
  },
  {
    key: 'Stream Type',
    value: 'streamType',
    validators: {},
  },
];

export const assetDetails: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Original Release Date',
    value: 'releaseDate',
    validators: {
      maxLength: 20,
      pattern: '^(\\d{4}((-\\d{2})(-\\d{2}))?)?$',
      type: 'date',
    },
  },
  { key: 'Genre', value: 'genres', validators: { maxLength: 200 } },

  {
    key: 'Images',
    value: '[imageLandscape,imageCircle,imagePortrait ]',
    validators: {},
  },

  { key: 'Rating', value: 'ratings', validators: {} },
];

export const assetDetailsSingleValues: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Original Release Date',
    value: 'releaseDate',
    validators: {
      maxLength: 20,
      pattern: '^(\\d{4}((-\\d{2})(-\\d{2}))?)?$',
      type: 'date',
    },
  },
  { key: 'Genre', value: 'genres', validators: { maxLength: 200 } },
  { key: 'Rating', value: 'ratings', validators: {} },
];

export const ratingValues: {
  key: string;
  value: string;
}[] = [
  {
    key: 'Rating Organisation',
    value: 'body',
  },
  {
    key: 'Rating',
    value: 'ratings',
  },
];

export const drmValues: {
  key: string;
  value: string;
}[] = [
  {
    key: 'License URL',
    value: 'licenseUrl',
  },
  {
    key: 'Type',
    value: 'type',
  },
];

export const externalProviderValues: {
  key: string;
  value: string;
}[] = [
  {
    key: 'External Program Id',
    value: 'externalProgramId',
  },
  {
    key: 'Provider',
    value: 'provider',
  },
  {
    key: 'Id Type',
    value: 'idType',
  },
];

export const assetSpecifications: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Deeplink Payload',
    value: 'deeplinkPayload',
    validators: { type: 'text', maxLength: 1000, json: true },
  },
  {
    key: 'Chapter Time',
    value: 'chapterTime',
    validators: { type: 'text', maxLength: 1000 },
  },
  {
    key: 'Audio Language',
    value: 'audioLang',
    validators: { maxLength: 2000 },
  },
  {
    key: 'Subtitle Language',
    value: 'subtitleLang',
    validators: { maxLength: 2000 },
  },
  {
    key: 'AI Live Translate',
    value: 'onDeviceTrans',
    validators: {},
  },
  { key: 'DRM', value: 'drm', validators: {} },
  { key: 'Quality', value: 'quality', validators: { maxLength: 10 } },

  {
    key: 'Scene Preview Url',
    value: 'webVttUrl',
    validators: {},
  },
  {
    key: 'Attributes',
    value: 'attributes',
    validators: {},
  },
  {
    key: 'Chapter Description',
    value: 'chapterDescription',
    validators: { minLength: 1, maxLength: 4000 },
  },
];
export const externalProvider: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'External Program ID',
    value: 'externalProgramId',
    validators: { maxLength: 125, pattern: '^[0-9A-Za-z_-]*$' },
  },
  { key: 'ID Type', value: 'idType', validators: {} },
  { key: 'TMS/Gracenote ID', value: 'tmsId', validators: {} },
  { key: 'ID Provider', value: 'idProvider', validators: {} },
];

export const licenseDetail: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Content Partner/Licensor',
    value: 'contentPartner',
    validators: { maxLength: 200 },
  },
  {
    key: 'Total Available Starting',
    value: 'totalAvailableStarting',
    validators: { maxLength: 30 },
  },
  {
    key: 'Total Available Ending',
    value: 'totalAvailableEnding',
    validators: { maxLength: 30 },
  },
  { key: 'Content Tier', value: 'contentTier', validators: { maxLength: 100 } },
  { key: 'License Window', value: 'licenseWindowList', validators: {} },
  { key: 'Event Window', value: 'eventWindowList', validators: {} },
];

export const licenseWindow: {
  key: string;
  value: string;
}[] = [
  {
    key: 'Window Start Date (UTC)',
    value: 'availableStarting',
  },
  {
    key: 'Window End Date (UTC)',
    value: 'availableEnding',
  },
  {
    key: 'Status',
    value: 'windowStatus',
  },
];

export const eventWindow: {
  key: string;
  value: string;
}[] = [
  {
    key: 'Event Start Date (UTC)',
    value: 'eventStarting',
  },
  {
    key: 'Event End Date (UTC)',
    value: 'eventEnding',
  },
];

export const licenseDetailSingleValues: {
  key: string;
  value: string;
  validators: ValidatorsCustom;
}[] = [
  {
    key: 'Content Partner/Licensor',
    value: 'contentPartner',
    validators: { maxLength: 200 },
  },

  { key: 'Content Tier', value: 'contentTier', validators: { maxLength: 100 } },
];

export const castValues: {
  key: string;
  value: string;
}[] = [
  {
    key: 'Person Role',
    value: 'role',
  },

  { key: 'Person name', value: 'name' },
  { key: 'Character name', value: 'characterName' },
];

export const imageFields: { key: string; value: string }[] = [
  { value: 'imageLandscapeOriginal', key: 'Banner Landscape Image' },
  { value: 'imagePortraitOriginal', key: 'Banner Portrait Image' },

  { value: 'imageLandscapeIconicOriginal', key: 'Iconic Landscape Image' },
  { value: 'imagePortraitIconicOriginal', key: 'Iconic Portrait Image' },
  { value: 'imagePortraitBackdropOriginal', key: 'Backdrop Portrait Image' },
  { value: 'imageLandscapeBackdropOriginal', key: 'Backdrop Landscape Image' },
  { value: 'imageTitleTreatmentOriginal', key: 'Title Treatment Image' },
];

export const sportsInformation: { key: string; value: string }[] = [
  {
    key: 'Sub Type',
    value: 'subType',
  },
  {
    key: 'Team1',
    value: 'team1',
  },
  {
    key: 'Team2',
    value: 'team2',
  },
];
export const geoRestrictions: { key: string; value: string }[] = [];

export const validCheck: { name: string; status: boolean }[] = [
  { name: 'contentId', status: true },
  { name: 'countryCode', status: true },
  { name: 'type', status: true },
  { name: 'mainTitle', status: true },
  { name: 'shortTitle', status: true },
  { name: 'runningTime', status: true },
  { name: 'genres', status: true },
  { name: 'director', status: true },
  { name: 'starring', status: true },
  { name: 'ratings', status: true },
  { name: 'description', status: true },
  { name: 'episodeNo', status: true },
  { name: 'seasonNo', status: true },
  { name: 'seasonId', status: true },
  { name: 'streamUri', status: true },
  { name: 'imageLandscape', status: true },
  { name: 'expiryDate', status: true },
  { name: 'showId', status: true },
  { name: 'releaseDate', status: true },
  { name: 'regDate', status: true },
  { name: 'updateDate', status: true },
  { name: 'regrId', status: true },
  { name: 'crctrId', status: true },
  { name: 'imagePortrait', status: true },
  { name: 'vcCpId', status: true },
  { name: 'imageCircle', status: true },
  { name: 'webVttUrl', status: true },
  { name: 'thumbnailUrl', status: true },
  { name: 'audioLang', status: true },
  { name: 'subtitleLang', status: true },
  { name: 'deeplinkPayload', status: true },
  { name: 'audioCode', status: true },
  { name: 'subtitleCode', status: true },
  { name: 'quality', status: true },
  { name: 'vcSvcId', status: true },
  { name: 'deeplinkId', status: true },
  { name: 'fileName', status: true },
  { name: 'dataplusYn', status: true },
  { name: 'nonAdStreamUri', status: true },
  { name: 'imageLandscapeOrigin', status: true },
  { name: 'imagePortraitOriginal', status: true },
  { name: 'imageCircleOriginal', status: true },
  { name: 'processedImageUrl', status: true },
  { name: 'artist', status: true },
  { name: 'availableStarting', status: true },
  { name: 'cpName', status: true },
  { name: 'licenseWindow', status: true },
  { name: 'status', status: true },
  { name: 'addedFrom', status: true },
  { name: 'drm', status: true },
  { name: 'externalProvider', status: true },
  { name: 'externalId', status: true },
  { name: 'seriesDescription', status: true },
  { name: 'contentPartner', status: true },
  { name: 'licenseWindowList', status: true },
  { name: 'eventWindowList', status: true },
  { name: 'attributes', status: true },
];

export const mandatoryFields: { type: string; value: string[] }[] = [
  {
    type: 'EPISODE',
    value: [
      'type',
      'mainTitle',
      'showId',
      'seasonNo',
      'seasonId',
      'episodeNo',
      'contentId',
      'description',
      'streamUri',
      'quality',
      'deeplinkPayload',
      'availableStarting',
      'expiryDate',
      'countryCode',
      'vcCpId',
    ],
  },
  {
    type: 'SHOW',
    value: [
      'type',
      'mainTitle',
      'description',
      'contentId',
      'type',
      'countryCode',
      'vcCpId',
      'deeplinkPayload',
    ],
  },
  {
    type: 'SEASON',
    value: [
      'type',
      'mainTitle',
      'showId',
      'seasonNo',
      'contentId',
      'description',
      'countryCode',
      'vcCpId',
      'deeplinkPayload',
    ],
  },
  {
    type: 'MUSIC',
    value: [
      'type',
      'mainTitle',
      'contentId',
      'description',
      'streamUri',
      'quality',
      'deeplinkPayload',
      'availableStarting',
      'expiryDate',
      'artist',
      'genres',
      'countryCode',
      'vcCpId',
    ],
  },
  {
    type: 'MOVIE',
    value: [
      'type',
      'mainTitle',
      'contentId',
      'description',
      'streamUri',
      'quality',
      'deeplinkPayload',
      'availableStarting',
      'expiryDate',
      'countryCode',
      'vcCpId',
    ],
  },
  {
    type: 'SINGLEVOD',
    value: [
      'type',
      'mainTitle',
      'contentId',
      'description',
      'streamUri',
      'quality',
      'deeplinkPayload',
      'availableStarting',
      'expiryDate',
      'countryCode',
      'vcCpId',
    ],
  },
];
export const notEditableInSingleEdit: { type: string; value: string[] }[] = [
  {
    type: 'EPISODE',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
  {
    type: 'SHOW',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
  {
    type: 'SEASON',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
  {
    type: 'MUSIC',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
  {
    type: 'MOVIE',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
  {
    type: 'SINGLEVOD',
    value: [
      'type',
      'contentId',
      'runningTime',
      'chapterTime',
      'chapterDescription',
      'streamUri',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'adTag',
      'seasonId',
      'showId',
      'seasonNo',
      'webVttUrl',
      'countryCode',
      'language',
      'showTitle',
      'seasonTitle',
      'attributes',
    ],
  },
];
export const bulkEditMandatoryFields: string[] = [
  'mainTitle',
  'showId',
  'seasonNo',
  'seasonId',
  'description',
  'starring',
  'quality',
  'availableStarting',
  'expiryDate',
];

export const bulkEditEditableFields: string[] = [
  'mainTitle',
  'releaseDate',
  'description',
  'shortTitle',
  'starring',
  'ratings',
  'genres',
  'availableStarting',
  'expiryDate',
  'contentPartner',
  'director',
  'artist',
];

export const playBackUriEditable: string[] = [];

export const notEditableByExternal: {
  key: string;
  value: string[];
}[] = [
  {
    key: 'SHOW',
    value: [
      'releaseDate',
      'genres',
      'starring',
      'director',
      'mainTitle',
      'shortTitle',
      'description',
      'imageLandscapeIconicOriginal',
      'imageLandscapeOriginal',
      'imageLandscapeIconic',
      'imageLandscape',
      'imageLandscapeIconicDimension',
      'imageLandscapeDimension',
    ],
  },
  {
    key: 'SEASON',
    value: [
      'releaseDate',
      'genres',
      'starring',
      'director',
      'mainTitle',
      'shortTitle',
      'description',
      'imageLandscapeIconicOriginal',
      'imageLandscapeOriginal',
      'imageLandscapeIconic',
      'imageLandscape',
      'imageLandscapeIconicDimension',
      'imageLandscapeDimension',
    ],
  },
  {
    key: 'SINGLEVOD',
    value: [
      'releaseDate',
      'genres',
      'starring',
      'director',
      'mainTitle',
      'shortTitle',
      'description',
      'imageLandscapeIconicOriginal',
      'imageLandscapeOriginal',
      'imageLandscapeIconic',
      'imageLandscape',
      'imageLandscapeIconicDimension',
      'imageLandscapeDimension',
    ],
  },

  {
    key: 'MOVIE',
    value: [
      'releaseDate',
      'genres',
      'starring',
      'director',
      'mainTitle',
      'shortTitle',
      'description',
      'imageLandscapeIconicOriginal',
      'imageLandscapeOriginal',
      'imagePortraitOriginal',
      'imagePortraitIconicOriginal',
      'imageLandscapeIconicDimension',
      'imageLandscapeDimension',
      'imagePortraitDimension',
      'imagePortraitIconicDimension',
      'imageLandscapeIconic',
      'imageLandscape',
      'imagePortrait',
      'imagePortraitIconic',
    ],
  },
];

export const videoQualityList: string[] = [
  'SD',
  'HD',
  'FHD',
  'UHD',
  '4K',
  '8K',
  '32K',
];

export const notVisibleFields: { type: string; value: string[] }[] = [
  {
    type: 'EPISODE',
    value: ['totalAvailableStarting', 'totalAvailableEnding'],
  },
  {
    type: 'SHOW',
    value: [
      'episodeNo',
      'seasonNo',
      'availableStarting',
      'expiryDate',
      'quality',
      'audioLang',
      'subtitleLang',
      'runningTime',
      'streamUri',
      'showId',
      'seasonId',
      'showTitle',
      'seasonTitle',
      'drm',
      'chapterTime',
      'chapterDescription',
      'webVttUrl',
      'contentTier',
      'licenseWindowList',
      'eventWindowList',
      'totalAvailableStarting',
      'totalAvailableEnding',
      'attributes',
      'onDeviceTrans',
    ],
  },
  {
    type: 'SEASON',
    value: [
      'seasonId',
      'seasonTitle',
      'episodeNo',
      'runningTime',
      'streamUri',
      'availableStarting',
      'expiryDate',
      'quality',
      'audioLang',
      'subtitleLang',
      'drm',
      'licenseWindowList',
      'eventWindowList',
      'totalAvailableStarting',
      'totalAvailableEnding',
      'attributes',
      'chapterTime',
      'chapterDescription',
      'webVttUrl',
      'onDeviceTrans',
    ],
  },
  {
    type: 'MUSIC',
    value: [
      'episodeNo',
      'seasonNo',
      'seasonId',
      'showId',
      'showTitle',
      'seasonTitle',
      'totalAvailableStarting',
      'totalAvailableEnding',
    ],
  },
  {
    type: 'MOVIE',
    value: [
      'episodeNo',
      'seasonNo',
      'seasonId',
      'showId',
      'showTitle',
      'seasonTitle',
      'totalAvailableStarting',
      'totalAvailableEnding',
    ],
  },
  {
    type: 'SINGLEVOD',
    value: [
      'episodeNo',
      'seasonNo',
      'seasonId',
      'showId',
      'showTitle',
      'seasonTitle',
      'totalAvailableStarting',
      'totalAvailableEnding',
    ],
  },
];

export const gracenoteFields = [
  'genres',
  'releaseDate',
  'mainTitle',
  'shortTitle',
  'starring',
  'director',
  'description',
  'imagePortraitIconic',
  'imageLandscapeIconic',
  'imageLandscape',
  'imagePortrait',
  'feedWorker',
  'imageLandscapeDimension',
  'imagePortraitDimension',
  'imageLandscapeIconicDimension',
  'imagePortraitIconicDimension',
  'episodeNo',
  'seasonNo',
  'imageTitleTreatment',
  'imageTitleTreatmentDimension',
  'imageLandscapeBackdrop',
  'imageLandscapeBackdropDimension',
];

export const genres: string[] = [
  'Action',
  'Arts/Culture',
  'Cartoons/Puppets',
  'Comedy',
  'Cooking',
  'Crime',
  'Documentary',
  'Drama',
  'Education',
  'Entertainment',
  'Fantasy',
  'History',
  'Horror',
  'KIDS',
  'Music',
  'Mystery',
  'News',
  'Reality',
  'Romance',
  'Science fiction',
  'Shopping',
  'Sports',
  'Talk',
  'Travel',
];

export const musicGenres: string[] = [
  'Afro',
  'Ambient',
  'Arab',
  'Bluegrass',
  'Blues',
  'Caribbean',
  'Classical',
  'Concert',
  'Country',
  'Dance',
  'Disco',
  'Electronic',
  'Flamenco',
  'Folk & Acoustic',
  'Funk',
  'Gospel',
  'Hip-Hop',
  'Holiday',
  'Indie & Alternative',
  'Jazz',
  'Karaoke',
  'Kids',
  'Latin',
  'Metal',
  'New Age',
  'Opera',
  'Pop',
  'Punk',
  'R&B',
  'Reggae',
  'Reggaeton',
  'Religious',
  'Rock',
  'Salsa',
  'Ska',
  'Soul',
  'Traditional',
];

export const notVisibleBlock: { type: string; value: string[] }[] = [
  {
    type: 'EPISODE',
    value: ['Additional Details', 'Sports Information', 'Geo Restriction'],
  },
  {
    type: 'SHOW',
    value: [
      'DRM',
      'Additional Details',
      'Available Platforms',
      'License Details',
      'Sports Information',
      'Geo Restriction',
    ],
  },
  {
    type: 'SEASON',
    value: [
      'DRM',
      'Additional Details',
      'Available Platforms',
      'License Details',
      'Sports Information',
      'Geo Restriction',
    ],
  },
  {
    type: 'MUSIC',
    value: ['Additional Details', 'Sports Information', 'Geo Restriction'],
  },
  {
    type: 'MOVIE',
    value: ['Additional Details', 'Sports Information', 'Geo Restriction'],
  },
  {
    type: 'SINGLEVOD',
    value: ['Additional Details', 'Sports Information', 'Geo Restriction'],
  },
];

export const imageResponseKey: string[] = [
  'imageLandscapeOriginal',
  'imagePortraitOriginal',
  'imageLandscapeIconicOriginal',
  'imagePortraitIconicOriginal',
  'imageCircleOriginal',
  'imageLandscape',
  'imagePortrait',
  'imageLandscapeIconic',
  'imagePortraitIconic',
  'imageLandscapeDimension',
  'imagePortraitDimension',
  'imageLandscapeIconicDimension',
  'imagePortraitIconicDimension',
  'imageCircle',
  'imagePortraitBackdropOriginal',
  'imagePortraitBackdrop',
  'imagePortraitBackdropDimension',
  'imageLandscapeBackdropOriginal',
  'imageLandscapeBackdrop',
  'imageLandscapeBackdropDimension',
  'imageTitleTreatmentOriginal',
  'imageTitleTreatment',
  'imageTitleTreatmentDimension',
];

export type ValidatorsCustom = {
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  type?: string;
  maxValue?: number;
  minValue?: number;
  json?: boolean;
  commaSeparated?: boolean;
};
export const assetViewTitle: string[] = [
  'Asset Basic Information',
  'Asset Details',
  'Casts',
  'Asset Specifications',
  'DRM',
  'External Provider',
  'License Details',
  'Available Platforms',
  'Sports Information',
  'Geo Restriction',
];
