import { Router } from '@angular/router';
import { TABLE_CONSTS } from '../../constants/table-consts';
import { Asset } from '../../models/asset-model';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { ICONS_CONSTS } from '../../constants/icons-consts';
import { STATUS_CONSTANTS } from '../../constants/status-consts';
import { Column, Filter } from '../../models/assets-columns-filters-model';
import { STATUS_HTML } from '../../constants/status-html-const';

function prepareTableData(allAssetsData: Asset[], columns: Column[]) {
  const possibleColumns = columns.filter((c) => c.selected);
  const tableAllData = allAssetsData?.map((objAsset: Asset) => {
    const obj: any = {};

    obj[TABLE_CONSTS.RENDER_CHECKBOX_COLUMN] = '';
    obj[TABLE_CONSTS.NO_RENDER_COLUMN] = objAsset.contentId;

    possibleColumns.forEach((pc) => {
      const hasValueForKey: any = (objAsset as any)[pc.key]
        ? (objAsset as any)[pc.key].toString()
        : null;
      // console.log('--------', pc.name);

      if (hasValueForKey) {
        switch (pc.key) {
          case 'status':
            switch (hasValueForKey) {
              case STATUS_CONSTANTS.ACTIVE:
                obj[pc.name] = STATUS_HTML.ACTIVE + hasValueForKey;
                break;
              case STATUS_CONSTANTS.EXPIRED:
                obj[pc.name] = STATUS_HTML.EXPIRED + hasValueForKey;
                break;
              case STATUS_CONSTANTS.INPROGRESS:
                obj[pc.name] = STATUS_HTML.INPROGRESS + hasValueForKey;
                break;
              case STATUS_CONSTANTS.QCFAIL:
                obj[pc.name] = STATUS_HTML.QCFAIL + hasValueForKey;
                break;
              case STATUS_CONSTANTS.QCPASS:
                obj[pc.name] = STATUS_HTML.QCPASS + hasValueForKey;
                break;
              case STATUS_CONSTANTS.QCREADY:
                obj[pc.name] = STATUS_HTML.QCREADY + hasValueForKey;
                break;
              case STATUS_CONSTANTS.RELEASED:
                obj[pc.name] = STATUS_HTML.RELEASED + hasValueForKey;
                break;
              case STATUS_CONSTANTS.RELEASEREADY:
                obj[pc.name] = STATUS_HTML.RELEASEREADY + hasValueForKey;
                break;
              case STATUS_CONSTANTS.REVOKED:
                obj[pc.name] = STATUS_HTML.REVOKED + hasValueForKey;
                break;
              case STATUS_CONSTANTS.TQCPASS:
                obj[pc.name] = STATUS_HTML.TQCPASS + hasValueForKey;
                break;
              case STATUS_CONSTANTS.SMF_IMPORTED:
                obj[pc.name] = STATUS_HTML.TQCPASS + hasValueForKey;
                break;
              case STATUS_CONSTANTS.UNTRACKABLE:
                obj[pc.name] = STATUS_HTML.UNTRACKABLE + hasValueForKey;
                break;
              default:
                obj[pc.name] = hasValueForKey;
            }
            break;
          case 'licenseWindow':
            switch (hasValueForKey) {
              case STATUS_CONSTANTS.ACTIVE:
                obj[pc.name] = STATUS_HTML.ACTIVE + hasValueForKey;
                break;
              case STATUS_CONSTANTS.EXPIRED:
                obj[pc.name] = STATUS_HTML.EXPIRED + hasValueForKey;
                break;
              default:
                obj[pc.name] = hasValueForKey;
            }
            if (hasValueForKey.includes(STATUS_CONSTANTS.INCLUDES_EXPIRING)) {
              obj[
                pc.name
              ] = `<i class="bi bi-exclamation-triangle status-with-text-red"></i> <span class='status-with-text-red'>${hasValueForKey}</span>`;
            } else if (
              hasValueForKey.includes(STATUS_CONSTANTS.INCLUDES_UPCOMING)
            ) {
              obj[pc.name] = STATUS_HTML.INPROGRESS + hasValueForKey;
            } else {
              obj[pc.name] = obj[pc.name];
            }
            break;
          case 'updateDate':
            obj[pc.name] = hasValueForKey;
            break;
          case 'expiryDate':
          case 'availableStarting':
            obj[pc.name] = formatDate(hasValueForKey);
            break;
          case 'mainTitle':
            obj[pc.name] = hasValueForKey;
            break;
          case 'type':
            obj[pc.name] =
              hasValueForKey.charAt(0).toUpperCase() +
              hasValueForKey.slice(1).toLowerCase();
            break;
          case 'dbStatus':
            obj[pc.name] =
              objAsset['status'] === STATUS_CONSTANTS.UNTRACKABLE
                ? STATUS_HTML.UNTRACKABLE + 'Untrackable'
                : getDotHtml(hasValueForKey) + hasValueForKey;
            break;
          case 'onDeviceTrans':
            obj[pc.name] =
              hasValueForKey === 'Yes'
                ? STATUS_HTML.ACTIVE + hasValueForKey
                : STATUS_HTML.EXPIRED + hasValueForKey;
            break;
          case 'liveOnDevice':
            if (hasValueForKey === 'Untrackable') {
              obj[pc.name] = STATUS_HTML.UNTRACKABLE + hasValueForKey;
            } else if (hasValueForKey === 'Yes') {
              obj[pc.name] = STATUS_HTML.RELEASED + hasValueForKey;
            } else if (hasValueForKey === 'No') {
              obj[pc.name] = STATUS_HTML.EXPIRED + hasValueForKey;
            }

            break;
          default:
            obj[pc.name] = hasValueForKey;
        }
      } else if (pc.key === 'dbStatus') {
        obj[pc.name] =
          objAsset['status'] === STATUS_CONSTANTS.UNTRACKABLE
            ? STATUS_HTML.UNTRACKABLE + 'Untrackable'
            : STATUS_HTML.INPROGRESS + 'Not Released';
      } else {
        obj[pc.name] = null;
      }
    });

    if (objAsset.qcPassReason) {
      obj[TABLE_CONSTS.QC_PASS_REASON_NO_RENDER] = objAsset.qcPassReason;
    }

    obj[TABLE_CONSTS.DETAILS_NO_RENDER] = {
      contentId: objAsset?.contentId,
      cpId: objAsset?.vcCpId,
      countryCode: objAsset?.countryCode,
    };

    return obj;
  });
  // console.log('tabledata =====', tableAllData);
  return tableAllData;
}

function onViewDetail(data: any, router: Router, allAssetsData: Asset[]) {
  const asset = allAssetsData.find(
    (a) => a.contentId === data[TABLE_CONSTS.NO_RENDER_COLUMN]
  );
  router.navigate([`/${SIDE_NAV_ROUTES.MEDIA_DETAILED_VIEW.route_link}`], {
    queryParams: {
      contentId: asset?.contentId,
      cpId: asset?.vcCpId,
      countryCode: asset?.countryCode,
    },
  });
}

function formatDate(date: string): string {
  if (date === null || date === undefined) {
    return date;
  }
  return date.replace('T', ' ').replace('Z', '').split('.')[0].split(' ')[0];
}

function formatCellValueForTable(
  key: string,
  value: any,
  status: string
): string {
  if (key) {
    switch (key) {
      case 'updateDate':
      case 'expiryDate':
      case 'availableStarting':
        return formatDate(value);
      case 'type':
        return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      case 'isReleased':
        if (status === 'Untrackable') return 'Untrackable';
        else return value ? 'Released' : 'Not Released';
      default:
        return value;
    }
  }
  return '';
}

export { prepareTableData, onViewDetail, formatCellValueForTable };
function getDotHtml(key: string): any {
  if (key === 'STG') {
    return STATUS_HTML.INPROGRESS;
  } else if (key === 'PRD & STG') {
    return STATUS_HTML.ACTIVE;
  } else {
    return STATUS_HTML.EXPIRED;
  }
}
