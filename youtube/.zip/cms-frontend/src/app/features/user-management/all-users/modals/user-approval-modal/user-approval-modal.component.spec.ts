import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserApprovalModalComponent } from './user-approval-modal.component';

describe('UserApprovalModalComponent', () => {
  let component: UserApprovalModalComponent;
  let fixture: ComponentFixture<UserApprovalModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserApprovalModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(UserApprovalModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
