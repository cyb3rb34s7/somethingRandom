import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import { MatDialog } from '@angular/material/dialog';
import { plainToInstance } from 'class-transformer';
import { UserAssignRoleStatusModalComponent } from './modals/user-assign-role-status-modal/user-assign-role-status-modal.component';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { User } from '../../../models/user-model';
import { UserService } from '../../../services/user.service';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { StateStoreService } from '../../../services/store/state-store.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { prepareUserTableData } from '../_helper';
import { UserApprovalModalComponent } from './modals/user-approval-modal/user-approval-modal.component';
import { ICONS_CONSTS } from '../../../constants/icons-consts';
import { UserRole } from '../../../models/user-role-model';
import { AppMatSelectComponent } from '../../media-assets/assets-details/media-asset-complete-view/modals/app-mat-select/app-mat-select.component';

@Component({
    selector: 'app-all-users',
    imports: [
        AppMatSimpleSearchComponent,
        AppMatTableComponent,
        AppMatSelectComponent,
    ],
    templateUrl: './all-users.component.html',
    styleUrl: './all-users.component.scss'
})
export class AllUsersComponent {
  private destroy = inject(DestroyRef);

  allUserData: User[];

  tableData: any[];

  loggedInUser: User;

  statusList: string[] = ['All', 'Pending', 'Inactive', 'Active'];

  currStatusFilter: string = 'All';

  @ViewChild(AppMatSimpleSearchComponent)
  searchBar: AppMatSimpleSearchComponent;

  constructor(
    public dialog: MatDialog,
    private userService: UserService,
    private storeService: StateStoreService,
  ) {}

  ngOnInit() {
    this.getUsersFromStorage();
  }

  getUsersFromStorage() {
    this.storeService.stateStore[STORE_CONSTS.USERS]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.allUserData = this.storeService.getStoreState(STORE_CONSTS.USERS);
        if (!this.allUserData.length) {
          this.fetchUsers();
        } else {
          this.prepareTableData(this.allUserData);
        }
      });
  }

  getLoggedInUserFromStorage() {
    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((user: User) => {
        this.loggedInUser = user;
      });
  }

  fetchUsers() {
    this.userService
      .getAllUsers()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.allUserData = plainToInstance<User, []>(User, res);
        this.storeService.setStoreState(
          STORE_CONSTS.USERS,
          plainToInstance<User, []>(User, res),
        );
      });
  }

  fetchRoles() {
    this.userService
      .getAllRolesAndAssignedUsers()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.storeService.setStoreState(
          STORE_CONSTS.ROLES,
          plainToInstance<UserRole, []>(UserRole, res),
        );
      });
  }

  prepareTableData(userData: User[]) {
    this.getLoggedInUserFromStorage();
    if (this.currStatusFilter !== 'All') {
      userData = userData.filter(
        (user) => user.status === this.currStatusFilter,
      );
    }
    this.tableData = prepareUserTableData(userData, this.loggedInUser);
  }

  handleSearch(value: string) {
    if (value) {
      const data = this.allUserData.filter((d) => {
        const searchIn = (d.userName + d.emailId + d.roleName).toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
    } else {
      this.prepareTableData(this.allUserData);
    }
  }

  onAction(icon: string, data: any) {
    const userData = this.allUserData.find(
      (u) => u.guid === data[TABLE_CONSTS.NO_RENDER_COLUMN],
    );
    if (icon === ICONS_CONSTS.TABLE_EDIT) {
      this.openAssignRoleModal({
        action: icon === ICONS_CONSTS.TABLE_EDIT ? 'edit' : 'assign',
        user: userData,
      });
    } else if (icon === ICONS_CONSTS.TABLE_ASSIGN) {
      this.openApprovalModal({
        action: icon === ICONS_CONSTS.TABLE_EDIT ? 'edit' : 'assign',
        user: userData,
      });
    }
  }

  openAssignRoleModal(data: any) {
    const dialogRef = this.dialog.open(UserAssignRoleStatusModalComponent, {
      data: { ...data },
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.fetchUsers();
          this.fetchRoles();
        }
      });
  }

  openApprovalModal(data: any) {
    const dialogRef = this.dialog.open(UserApprovalModalComponent, {
      data: { ...data },
      panelClass: 'assign-role-modal',
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.fetchUsers();
          this.fetchRoles();
        }
      });
  }

  clearSearch() {
    this.searchBar.clear();
  }

  handleStatusFilter(status: string) {
    this.currStatusFilter = status;
    this.clearSearch();
    this.prepareTableData(this.allUserData);
  }
}
