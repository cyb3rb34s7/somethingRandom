import { Component, DestroyRef, Inject, inject } from '@angular/core';
import { MatRadioGroupComponent } from '../../../../../mat-components/mat-radio-group/mat-radio-group.component';
import { AppMatSelectComponent } from '../../../../../mat-components/app-mat-select/app-mat-select.component';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { instanceToInstance, plainToInstance } from 'class-transformer';
import { User } from '../../../../../models/user-model';
import { UserRole } from '../../../../../models/user-role-model';
import { UserService } from '../../../../../services/user.service';
import { MatButtonModule } from '@angular/material/button';
import { StateStoreService } from '../../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../../constants/store-consts';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';

@Component({
    selector: 'app-user-approval-modal',
    imports: [
        MatRadioGroupComponent,
        AppMatSelectComponent,
        AppMatInputComponent,
        MatDialogModule,
        MatButtonModule,
    ],
    templateUrl: './user-approval-modal.component.html',
    styleUrl: './user-approval-modal.component.scss'
})
export class UserApprovalModalComponent {
  Active: string = 'Active';
  private destroy = inject(DestroyRef);

  roleNames: string[] = [];
  userData: User;
  user: User;

  allRoles: UserRole[];
  defaultRoleName: string | undefined;

  constructor(
    public dialogRef: MatDialogRef<UserApprovalModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private userService: UserService,
    private toastr: CustomToastrService,
    private storeService: StateStoreService,
  ) {
    this.userData = instanceToInstance<User>(data.user);
    this.user = this.storeService.getStoreState(STORE_CONSTS.CURRENT_USER);
    if (!this.user.userId) {
      this.fetchUserData();
    }

    this.userService
      .getAllRoles()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((r: any) => {
        this.allRoles = plainToInstance<UserRole, []>(UserRole, r);
        this.roleNames = this.allRoles.map((r: UserRole) => r.roleName);

        const defaultRoleObj = this.allRoles.find((r) => r.isDefault);
        this.defaultRoleName = defaultRoleObj
          ? defaultRoleObj.roleName
          : undefined;
        this.userData.roleId = defaultRoleObj ? defaultRoleObj!.roleId : NaN;
      });
  }

  onRoleChange(newRoleName: string) {
    const objRole = this.allRoles.find((r) => r.roleName === newRoleName);
    this.userData.roleId = objRole ? objRole!.roleId : NaN;
  }

  onStatusChange(newStatus: string) {
    this.userData.status = newStatus;
  }

  onCommentChange(newComment: string) {
    this.userData.comment = newComment;
  }

  approve() {
    this.userService
      .approveUser(
        this.userData.guid,
        this.userData.roleId,
        this.userData.comment,
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  reject() {
    this.userService
      .rejectUser(this.userData.guid, this.userData.comment)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  fetchUserData() {
    this.userService
      .getUserDetails()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.storeService.setStoreState(
          STORE_CONSTS.CURRENT_USER,
          plainToInstance<User, {}>(User, res.user),
        );
        this.user = res.user;
      });
  }
}
