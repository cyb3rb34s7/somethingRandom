import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  Output,
  QueryList,
  SimpleChanges,
  ViewChildren,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { EvaluationFilterModel } from '../../../models/evaluation-filter-model';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { EVALUATION_CONSTS } from '../../../constants/evaluation-consts';
import { STORE_CONSTS } from "../../../constants/store-consts";
import { StateStoreService } from "../../../services/store/state-store.service";

@Component({
    selector: 'app-assets-evaluation-filter-modal',
    imports: [
        MatButtonModule,
        MatCheckbox,
        MatExpansionModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatIconModule,
        CommonModule,
        MatNativeDateModule,
        MatInputModule,
        MatDialogModule,
        FormsModule,
        AppMatSimpleSearchComponent,
    ],
    templateUrl: './evaluation-assets-filter-modal.component.html',
    styleUrl: './evaluation-assets-filter-modal.component.scss',
    providers: []
})
export class EvaluationAssetsFilterModalComponent implements OnChanges {
  @Output() closed = new EventEmitter<void>();

  @Input() allFiltersList: { [key: string]: string[] } = {};
  @Input() showDateFilter: boolean = true;
  @Input() resetTrigger: number = 0;
  @Output() filtersApplied = new EventEmitter<EvaluationFilterModel[]>();
  @Output() filterReset = new EventEmitter<void>();
  @Output() appliedFiltersCount = new EventEmitter<any>();
  @ViewChildren(AppMatSimpleSearchComponent)
  innerSearchFlds!: QueryList<AppMatSimpleSearchComponent>;
  filters: EvaluationFilterModel[] = [];

  appliedFilters: EvaluationFilterModel[] = [];
  selectedFilters: EvaluationFilterModel[] = [];

  selectedSearchText: any = {};
  appliedSearchText: any = {};

  isOpen = false;
  searchText: any;
  EC = EVALUATION_CONSTS;

  colSpan: any = {
    programType: 2,
    coverageStatus: 3,
    comparisonStatus: 3,
  };

  expandedFiltersMap: any = {};

  backupValues: any = {};

  constructor(private storeService: StateStoreService) {}

  ngOnInit() {
    const filters: EvaluationFilterModel[] = this.storeService.getStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS);
    if(filters != null && filters.length > 0) {
      this.selectedFilters = JSON.parse(JSON.stringify(filters));
      this.applyFilters(true);
    }
  }

  open() {
    this.isOpen = true;
    this.selectedFilters = JSON.parse(JSON.stringify(this.appliedFilters));
    this.selectedSearchText = JSON.parse(JSON.stringify(this.appliedSearchText));
    this.backupValues = JSON.parse(JSON.stringify(this.allFiltersList));
  }

  close() {
    this.isOpen = false;
    this.selectedFilters = [];
    this.resetSearchText();
    this.innerSearchFlds.forEach((c: AppMatSimpleSearchComponent) => c.clear());
    this.closed.emit();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['resetTrigger'] && !changes['resetTrigger'].firstChange) {
      this.resetFilters();
    }
  }
  resetSearchText(): void {
    const keys = Object.keys(this.selectedSearchText);
    keys.forEach((key) => {this.selectedSearchText[key] = '';});
  }
  @HostListener('keydown.enter', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.applyFilters();
  }
  get filtersCount() {
    return this.selectedFilters.length < 10
      ? '0' + this.selectedFilters.length
      : this.selectedFilters.length;
  }

  get selectedCountMap(): { [key: string]: string } {
    const map: { [key: string]: string } = {};
    this.selectedFilters.forEach((filter) => {
      const valuesLength = filter.values.length;
      const cnt =
        valuesLength < 10 ? '0' + valuesLength : valuesLength.toString();
      map[filter.key] = cnt;
    });
    return map;
  }

  updateFilters(key: string, option: string, isChecked: boolean) {
    const filterIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === key
    );

    if (filterIndex > -1) {
      if (isChecked) {
        this.selectedFilters[filterIndex].values.push(option);
      } else {
        const valueIndex =
          this.selectedFilters[filterIndex].values.indexOf(option);
        if (valueIndex > -1) {
          this.selectedFilters[filterIndex].values.splice(valueIndex, 1);
        }
      }
      if (this.selectedFilters[filterIndex].values.length === 0) {
        this.selectedFilters.splice(filterIndex, 1);
      }
    } else if (isChecked) {
      this.selectedFilters.push({
        type: 'filter',
        key: key,
        values: [option],
      });
    }
  }
  updateSearchableFilter(filterKey: string) {
    const customFilterIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === filterKey
    );

    if (this.selectedSearchText[filterKey]?.trim()) {
      if (customFilterIndex > -1) {
        this.selectedFilters[customFilterIndex].values = [
          this.selectedSearchText[filterKey],
        ];
      } else {
        this.selectedFilters.push({
          type: 'search',
          key: filterKey,
          values: [this.selectedSearchText[filterKey]],
        });
      }
    } else if (customFilterIndex > -1) {
      this.selectedFilters.splice(customFilterIndex, 1);
    }
  }

  isSelected(key: string, option: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    return filter ? filter.values.includes(option) : false;
  }

  isAllSelected(key: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    if (!filter) return false;
    const allOptions = this.allFiltersList[key];
    return filter.values.length === allOptions.length;
  }

  isSomeSelected(key: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    if (!filter) return false;

    const allOptions = this.allFiltersList[key];
    return filter.values.length > 0 && filter.values.length < allOptions.length;
  }

  selectAllOptions(key: string, isChecked: boolean): void {
    if (isChecked) {
      const allOptions = this.allFiltersList[key];
      const filterIndex = this.selectedFilters.findIndex(
        (filter) => filter.key === key
      );
      const newFilter: EvaluationFilterModel = {
        type: 'filter',
        key: key,
        values: [...allOptions],
      };

      if (filterIndex > -1) {
        this.selectedFilters[filterIndex] = newFilter;
      } else {
        this.selectedFilters.push(newFilter);
      }
    } else {
      const filterIndex = this.selectedFilters.findIndex(
        (filter) => filter.key === key
      );
      if (filterIndex > -1) {
        this.selectedFilters.splice(filterIndex, 1);
      }
    }
  }

  applyFilters(isFromStore: boolean = false) {
    this.appliedFilters = JSON.parse(JSON.stringify(this.selectedFilters));
    this.appliedSearchText = JSON.parse(JSON.stringify(this.selectedSearchText));
    this.resetSearchText();
    this.appliedFiltersCount.emit(this.filtersCount);
    this.selectedFilters = [];

    if(!isFromStore) {
      this.filtersApplied.emit(this.appliedFilters);
      this.close();
    }
  }

  resetFilters() {
    this.selectedFilters = [];
    this.resetSearchText();
  }

  findFilterName(key: string): string {
    switch (key) {
      case this.EC.PROGRAM_ID_FILTER_TEXT:
        return this.EC.PROGRAM_ID_HEADER_TEXT;
      case this.EC.PROGRAM_TITLE_FILTER_TEXT:
        return this.EC.PROGRAM_TITLE_HEADER_TEXT;
      case this.EC.PROGRAM_TYPE_FILTER_TEXT:
        return this.EC.PROGRAM_TYPE_HEADER_TEXT;
      case this.EC.COVERAGE_FILTER_TEXT:
        return this.EC.COVERAGE_HEADER_TEXT;
      case this.EC.COMPARISON_FILTER_TEXT:
        return this.EC.COMPARISON_HEADER_TEXT;
      case this.EC.TMS_ID_FILTER_TEXT:
        return this.EC.TMS_ID_HEADER_TEXT;
      case this.EC.FEED_WORKER_FILTER_TEXT:
        return this.EC.FEED_WORKER_HEADER_TEXT;
      default:
        return this.EC.NONE_HEADER_TEXT;
    }
  }

  findFilterValue(key: string): string {
    const customFilterIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === key
    );

    if(customFilterIndex > -1) {
      return this.selectedFilters[customFilterIndex].values[0];
    } else return '';
  }

  isSearchable(key: string): boolean {
    return this.EC.SEARCHABLE_FILTERS.includes(key);
  }

  handleInnerSearch(filter: any, txt: string) {
    if (txt.length) {
      filter.value = this.backupValues[filter.key].filter((v: string) =>
        v.toLowerCase().includes(txt.toLowerCase())
      );
    } else {
      filter.value = [...this.backupValues[filter.key]];
    }
  }
}
