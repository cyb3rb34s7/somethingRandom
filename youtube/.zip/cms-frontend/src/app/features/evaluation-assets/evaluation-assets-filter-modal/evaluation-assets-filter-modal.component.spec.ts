import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationAssetsFilterModalComponent } from './evaluation-assets-filter-modal.component';

describe('EvaluationAssetsFilterModalComponent', () => {
  let component: EvaluationAssetsFilterModalComponent;
  let fixture: ComponentFixture<EvaluationAssetsFilterModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationAssetsFilterModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EvaluationAssetsFilterModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
