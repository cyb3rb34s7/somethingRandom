import { AfterViewInit, Component, DestroyRef, inject, ViewChild, ChangeDetectorRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpErrorResponse } from '@angular/common/http';
import { MatTooltip } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { MatButton, MatButtonModule } from '@angular/material/button';
import { plainToInstance} from 'class-transformer';
import { EvaluationService } from '../../services/evaluation.service';
import { AppMatSimpleSearchComponent } from '../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import {
  EvaluationFilterModel,
  FilterRequestBody,
} from '../../models/evaluation-filter-model';
import { AssetEvaluation } from '../../models/asset-evaluation-model';
import { EvaluationAssetsFilterModalComponent } from './evaluation-assets-filter-modal/evaluation-assets-filter-modal.component';
import { EvaluationAssetsTableComponent } from './evaluation-assets-table/evaluation-assets-table.component';
import { StateStoreService } from "../../services/store/state-store.service";
import { onViewDetail } from '../evaluation-assets/_helper';
import { ICONS_CONSTS } from '../../constants/icons-consts';
import { STORE_CONSTS } from "../../constants/store-consts";
import { EVALUATION_CONSTS } from '../../constants/evaluation-consts';
import { getFileName } from "../change-history/_helper";
import { AssetExcelExportService } from "../../services/asset-excel-export.service";
import {CustomToastrService} from "../../services/custom-toastr.service";

const SESSION_KEY = 'evaluation-asset-table-data';
@Component({
    selector: 'app-evaluation-assets',
    imports: [
        MatTooltip,
        MatButton,
        MatButtonModule,
        EvaluationAssetsFilterModalComponent,
        EvaluationAssetsTableComponent,
        AppMatSimpleSearchComponent,
    ],
    templateUrl: './evaluation-assets.component.html',
    styleUrl: './evaluation-assets.component.scss'
})
export class EvaluationAssetsComponent implements AfterViewInit {
  private destroy = inject(DestroyRef);
  AssetEvaluationData: AssetEvaluation[] = [];
  tableData: any[];
  resetTrigger = 0;
  EvaluationFilters: { [key: string]: string[] } = {};
  filterBody: FilterRequestBody = {
    filters: [],
    pagination: {
      limit: 1000,
      offset: 0,
    },
  };
  appliedFilterCount: any;
  searchText: string = EVALUATION_CONSTS.EMPTY_STRING;
  noMoreDataAvailable: boolean = false;
  offsetIndex: any = 0;
  evaluationAssetsCount: number;
  totalRecordsOriginal: number;
  coveredCount: number;
  coveredRate: number;
  matchedCount: number;
  matchedRate: number;
  totalCount: number;
  EC = EVALUATION_CONSTS;

  constructor(
    private evaluationService: EvaluationService,
    private router: Router,
    private storeService: StateStoreService,
    private changeDetectorRef: ChangeDetectorRef,
    private excelExportService: AssetExcelExportService,
    private toastr: CustomToastrService,
  ) {}

  ngOnInit() {
    this.fetchEvaluationAssets();
    this.fetchEvaluationFilters();
    this.fetchEvaluationCount();
  }

  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges()
  }

  @ViewChild(EvaluationAssetsFilterModalComponent)
  filterSidebar: EvaluationAssetsFilterModalComponent;

  @ViewChild(EvaluationAssetsTableComponent)
  assetEvaluationTable: EvaluationAssetsTableComponent;

  onLoadMore(e: any) {
    if (!this.searchText && !this.noMoreDataAvailable) {
      if (this.filterBody.pagination?.offset != null) {
        this.offsetIndex++;
        this.filterBody.pagination.offset = this.offsetIndex * 1000;
      }
      this.fetchEvaluationAssets();
    }
  }

  fetchEvaluationAssets(isRefresh: boolean = false) {
    const filters = this.storeService.getStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS);
    const observable = this.evaluationService.getEvaluationData(
      filters,
      this.filterBody.pagination
    );

    observable.pipe(takeUntilDestroyed(this.destroy)).subscribe({
      next: (res) => {
        if (isRefresh) {
          this.AssetEvaluationData.splice(this.offsetIndex * 1000);
          this.AssetEvaluationData = this.AssetEvaluationData.concat(
            plainToInstance<AssetEvaluation, []>(
              AssetEvaluation,
              res.data
            )
          );
        } else if (this.filterBody.pagination?.offset === 0) {
          this.AssetEvaluationData = plainToInstance<AssetEvaluation, []>(
            AssetEvaluation,
            res.data
          );
        } else {
          this.AssetEvaluationData = this.AssetEvaluationData.concat(
            plainToInstance<AssetEvaluation, []>(
              AssetEvaluation,
              res.data
            )
          );
        }

        if (res.data.length < 1000) {
          this.noMoreDataAvailable = true;
        } else {
          this.noMoreDataAvailable = false;
        }

        if (this.assetEvaluationTable?.paginator) {
          this.assetEvaluationTable.paginator.pageIndex = this.setPageIndex();
        }

        this.prepareTableData(this.AssetEvaluationData);
        this.handleSearch(this.searchText);
      },
      error: (error: HttpErrorResponse) => {
        console.log('====Error===', error);
      },
    });
  }

  setPageIndex(): number {
    const isData = sessionStorage.getItem(SESSION_KEY);
    if (isData) {
      const { paginationData } = JSON.parse(isData);
      if (paginationData) {
        return paginationData.pageIndex;
      }
    }

    return this.offsetIndex;
  }

  fetchEvaluationFilters() {
    this.evaluationService
      .getEvaluationFilterData()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.EvaluationFilters = res;
      });
  }

  fetchEvaluationCount() {
    const filters = this.storeService.getStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS);

    this.evaluationService
      .getEvaluationCountData(filters)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.coveredCount = res.coveredCount.toLocaleString();
        this.coveredRate = res.coveredRate;
        this.matchedCount = res.matchedCount.toLocaleString();
        this.matchedRate = res.matchedRate;
        this.totalCount = res.totalCount.toLocaleString();
      });
  }

  prepareTableData(assetEvaluationData: AssetEvaluation[]) {
    this.tableData = assetEvaluationData
      .map((objMetadata: AssetEvaluation) => {
        const obj: any = {};

        try {
          obj[this.EC.PROGRAM_ID_HEADER_TEXT] = objMetadata.programId;
          obj[this.EC.PROGRAM_TYPE_HEADER_TEXT] = objMetadata.programType;
          obj[this.EC.PROGRAM_TITLE_HEADER_TEXT] = objMetadata.programTitle;
          obj[this.EC.FEED_WORKER_HEADER_TEXT] = objMetadata.feedWorker;
          obj[this.EC.TMS_ID_HEADER_TEXT] = objMetadata.tmsId;
          obj[this.EC.COVERAGE_HEADER_TEXT] = objMetadata.coverageStatus;
          obj[this.EC.COMPARISON_HEADER_TEXT] = objMetadata.comparisonStatus;

          return obj;
        } catch (error) {
          return null;
        }
      })
      .filter((row) => row !== null);
  }

  openFilterSidebar() {
    this.filterSidebar.open();
  }

  onEvaluationFiltersApply(filters: EvaluationFilterModel[]) {
    this.offsetIndex = 0;
    this.filterBody = {
      filters: filters,
      pagination: {
        limit: 1000,
        offset: 0,
      },
    };
    if (this.assetEvaluationTable?.paginator) {
      this.assetEvaluationTable.paginator.firstPage();
    }

    this.storeService.setStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS, filters);
    this.filterBody.filters = filters;

    this.fetchEvaluationAssets();
    this.fetchEvaluationCount();
  }

  onFiltersReset() {
    this.storeService.setStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS, []);
  }

  setAppliedFiltersCount(event: any) {
    this.appliedFilterCount = event;
  }

  handleAction(e: any) {
    if (e.icon === ICONS_CONSTS.TABLE_DETAILS) {
      onViewDetail(e.data, this.router, this.AssetEvaluationData);
    }
  }

  handleSearch(value: string) {
    this.searchText = value;
    if (value) {
      const data = this.AssetEvaluationData.filter((d) => {
        const searchIn = (d.programId + d.programTitle).toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
      if (this.assetEvaluationTable?.paginator) {
        this.assetEvaluationTable.paginator.firstPage();
      }
      this.evaluationAssetsCount = data.length;
    } else {
      this.prepareTableData(this.AssetEvaluationData);
      this.evaluationAssetsCount = this.totalRecordsOriginal;
    }
  }

  exportExcel() {
    const filters = this.storeService.getStoreState(STORE_CONSTS.EVALUATION_ASSETS_FILTERS);
    this.handleExport(filters);
  }

  private handleExport(filters: any) {
    const filename = getFileName('EvaluationAssets');
    this.storeService.setStoreState(
      STORE_CONSTS.EXCEL_DOWNLOAD_FILENAME,
      filename
    );
    const filterBody: FilterRequestBody = {
      filters: filters,
    };

    return (this.excelExportService.currentExportSubscription =
      this.excelExportService.exportAssetToExcel(filterBody, true).subscribe({
        next: (res) => {
          if (res) {
            const fileName = this.extractFileName(res.headers);
            this.downloadFile(res.body, fileName);
            this.toastr.success('Data is Exported Successfully');
          }
        },
        error: (error) => {
          this.toastr.error('Export Failed');
        },
      }));
  }

  private extractFileName(headers: any): string {
    let fileName;
    const contentDisposition =
      headers.get('Content-Disposition') || headers.get('content-disposition');
    if (contentDisposition) {
      const matches = contentDisposition.match(/filename\s*=\s*"?([^";\s]+)"?/);
      if (matches && matches[1]) {
        fileName = matches[1];
        return fileName;
      }
    }
    return '';
  }

  downloadFile(data: any, fileName: string) {
    const url = window.URL.createObjectURL(new Blob([data]));
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
}
