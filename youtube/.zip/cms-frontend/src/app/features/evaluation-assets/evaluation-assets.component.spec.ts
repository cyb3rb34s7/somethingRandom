import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationAssetsComponent } from './evaluation-assets.component';

describe('EvaluationAssetsComponent', () => {
  let component: EvaluationAssetsComponent;
  let fixture: ComponentFixture<EvaluationAssetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationAssetsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EvaluationAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
