import { Router } from '@angular/router';
import { TABLE_CONSTS } from '../../constants/table-consts';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { AssetEvaluation } from '../../models/asset-evaluation-model';

function onViewDetail(
  data: any,
  router: Router,
  assetsEvaluationData: AssetEvaluation[]
) {
  const asset = assetsEvaluationData.find(
    (a) => a.programId === data[TABLE_CONSTS.PROGRAM_ID]
  );
  router.navigate([`/${SIDE_NAV_ROUTES.EVALUATION_DETAILED_VIEW.route_link}`], {
    queryParams: {
      contentId: asset?.programId,
      cpId: asset?.cpId,
    },
  });
}

export { onViewDetail };
