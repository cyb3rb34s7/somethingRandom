import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationAssetsTableComponent } from './evaluation-assets-table.component';

describe('EvaluationAssetsTableComponent', () => {
  let component: EvaluationAssetsTableComponent;
  let fixture: ComponentFixture<EvaluationAssetsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationAssetsTableComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EvaluationAssetsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
