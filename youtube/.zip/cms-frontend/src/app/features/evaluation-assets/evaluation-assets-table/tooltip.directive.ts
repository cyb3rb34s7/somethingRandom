import { Directive, Input, ElementRef, HostListener } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';

@Directive({
  selector: '[tooltip]',
  standalone: true,
  providers: [MatTooltip],
})
export class Tooltip {
  @Input('tooltip') tooltip: string;

  private span: HTMLElement;

  constructor(private el: ElementRef, private _tooltip: MatTooltip) {
    this.span = this.el.nativeElement;
  }

  @HostListener('mouseover') mouseover() {
    if (this.span.offsetWidth < this.span.scrollWidth) {
      this._tooltip.message = this.tooltip;
      this._tooltip.show();
    }
  }
  @HostListener('mouseleave') mouseleave() {
    this._tooltip.hide();
  }
}
