import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  HostBinding,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
  MatPaginator,
  MatPaginatorIntl,
  MatPaginatorModule,
} from '@angular/material/paginator';
import { ResizeColumnDirective } from './resizable-column.directive';
import { Tooltip } from './tooltip.directive';

import { ICONS_CONSTS } from '../../../constants/icons-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { EVALUATION_CONSTS } from "../../../constants/evaluation-consts";

const SESSION_KEY = 'evaluation-asset-table-data';
@Component({
    selector: 'app-evaluation-assets-table',
    imports: [
        CommonModule,
        MatCheckboxModule,
        MatPaginatorModule,
        ResizeColumnDirective,
        Tooltip,
    ],
    templateUrl: './evaluation-assets-table.component.html',
    styleUrl: './evaluation-assets-table.component.scss'
})
export class EvaluationAssetsTableComponent {
  @HostBinding('class.noData') noData: boolean = true;
  @HostBinding('class.detailsShown') detailsShown: boolean = false;
  @ViewChild('header') header: ElementRef;
  @ViewChild('body') body: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  tableDataBackup: any[];
  selection: any[] = [];
  private _tableData: any[];

  @Input() set tableData(value: any) {
    this._tableData = [...value];
    this.tableDataBackup = [...value];
    this.currentDisplayedData = [];

    if (this._tableData.length === 0) {
      this.noData = true;
      return;
    }
    this.noData = false;
    this.restoreSessionData();
    if (this.sort) {
      this.sortData();
    }
    setTimeout(() => {
      this.setRange();
    }, 0);
  }

  get tableData(): any {
    return this._tableData;
  }

  private _overrideTotalCount: number;

  @Input() set overrideTotalCount(value: any) {
    this._overrideTotalCount = parseInt(value, 10);
  }

  get overrideTotalCount(): number {
    return this._overrideTotalCount;
  }

  @Output() loadMore: EventEmitter<any> = new EventEmitter();
  @Output() action: EventEmitter<any> = new EventEmitter();

  orderedHeaders: any[];
  displayedColumns: any[];
  currentDisplayedData: any[] = [];

  TC = TABLE_CONSTS;
  EC = EVALUATION_CONSTS;

  pageIndex: number = 0;
  pageSize: number = this.TC.PAGE_SIZE_OPTIONS[0];
  sort: { active: string; direction: string } | null;
  $scrollableCont: HTMLElement;
  $hCells: HTMLElement[];
  $reSizers: HTMLElement[];

  constructor() {
    this.restoreSessionData();
  }

  restoreSessionData() {
    const isData = sessionStorage.getItem(SESSION_KEY);
    if (isData) {
      const { paginationData } = JSON.parse(isData);
      if (paginationData) {
        this.pageIndex = paginationData.pageIndex;
        this.pageSize = paginationData.pageSize;
      }
    }
  }

  ngOnInit() {
    this.setCurrentPageData();
    if (this.currentDisplayedData.length === 0) {
      setTimeout(() => {
        if (this.paginator) {
          this.paginator.pageIndex = 0;
        }
      }, 100);
    }
  }

  ngAfterViewInit() {
    this.paginator._intl = new MatPaginatorIntl();
    this.paginator._intl.itemsPerPageLabel = TABLE_CONSTS.ITEMS_PER_PAGE_LABEL;
    this.paginator.pageSize = this.pageSize;
    this.paginator.pageIndex = this.pageIndex;
  }

  setRange() {
    setTimeout(() => {
      this.$scrollableCont = this.body.nativeElement;
      this.$hCells = this.body.nativeElement.querySelectorAll('.h-cell');
      this.$reSizers =
        this.body.nativeElement.querySelectorAll('.resize-holder');
      if (this.body.nativeElement) {
        this.$hCells = this.body.nativeElement.querySelectorAll('.h-cell');
        this.$reSizers =
          this.body.nativeElement.querySelectorAll('.resize-holder');
      }
    }, 100);

    this.checkLoadMore();

    this.setCurrentPageData();

    if (this.currentDisplayedData.length) {
      this.prepareColumns(this.currentDisplayedData);
    }
  }

  checkLoadMore() {
    const nextData = this.tableData.slice(
      this.pageSize * (this.pageIndex + 1),
      this.pageSize * (this.pageIndex + 2)
    );
    if (nextData.length < this.pageSize) {
      this.loadMore.emit();
    }
  }

  setCurrentPageData() {
    let td: any = this.tableData.slice(
      this.pageSize * this.pageIndex,
      this.pageSize * (this.pageIndex + 1)
    );
    if (td.length === 0 && this.tableData.length) {
      this.pageIndex--;
      if (this.paginator) {
        this.paginator.pageIndex = this.pageIndex;
      }
      this.setCurrentPageData();
    } else {
      this.currentDisplayedData = td;
    }
  }

  prepareColumns(td: any) {
    this.displayedColumns = [];
    const headers = this.prepareColumnHeaders(td);
    headers.forEach((h) => {
      let column = [];
      column.push(h);

      td.forEach((d: any) => {
        column.push(d[h]);
      });
      this.displayedColumns = [...this.displayedColumns, column];
    });
  }

  prepareColumnHeaders(td: any) {
    let headers = Object.keys(td[0]);

    if (this.orderedHeaders) {
      let oHeaders: string[] = [];
      let extra: string[] = [];
      headers.forEach((h: any) => {
        let ind = this.orderedHeaders.findIndex((oh) => oh === h);
        if (ind > -1) {
          oHeaders[ind] = h;
        } else {
          extra.push(h);
        }
      });
      oHeaders = oHeaders.filter((oh) => oh);
      headers = [...oHeaders, ...extra];
    }
    // console.log('**********************', headers);
    return headers;
  }

  handlePagination(e: any) {
    this.pageSize = e.pageSize;
    this.pageIndex = e.pageIndex;
    this.setSessionData({ paginationData: { ...e } });
    this.setRange();
  }

  handleSorting(column: string) {
    if (this.sort) {
      if (this.sort.active === column) {
        this.sort.direction =
          this.sort.direction === 'asc'
            ? 'dsc'
            : this.sort.direction === 'dsc'
              ? ''
              : 'asc';
      } else {
        this.sort.direction = 'asc';
      }
      if (this.sort.direction) {
        this.sort.active = column;
      } else {
        this.sort = null;
      }
    } else {
      this.sort = { active: column, direction: 'asc' };
    }

    this.setSessionData({ sortData: this.sort });
    this.sortData();
    this.setRange();
  }

  sortData() {
    const keys = Object.keys(this._tableData[0]);
    if (
      !this.sort ||
      this.sort?.direction === '' ||
      !keys.includes(this.sort.active)
    ) {
      this._tableData = this.tableDataBackup.slice();
    } else {
      this._tableData.sort((a: any, b: any) => {
        const isAsc = this.sort?.direction === 'asc';
        return this.sort
          ? this.compare(a[this.sort.active], b[this.sort.active], isAsc)
          : 0;
      });
    }
  }

  compare(a: string, b: string, isAsc: boolean) {
    if (a === b) {
      return 0;
    }

    if (a === null) {
      return 1;
    }
    if (b === null) {
      return -1;
    }

    if (isAsc) {
      return a < b ? -1 : 1;
    }

    return a < b ? 1 : -1;
  }

  openDetails(data: any) {
    this.action.emit({ icon: ICONS_CONSTS.TABLE_DETAILS, data: { ...data } });
  }

  setSessionData(data: any) {
    let _data = sessionStorage.getItem(SESSION_KEY);
    _data = _data ? JSON.parse(_data) : {};
    _data = { ...(_data as Object), ...data };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(_data));
  }

  clearSessionData() {
    sessionStorage.removeItem(SESSION_KEY);
  }

  protected readonly TABLE_CONSTS = TABLE_CONSTS;
}
