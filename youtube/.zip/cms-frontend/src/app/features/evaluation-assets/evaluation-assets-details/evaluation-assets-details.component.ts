import { Component, DestroyRef, inject } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatDialog } from '@angular/material/dialog';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatLabel } from '@angular/material/form-field';
import {
  imageFields,
  imageResponseKey,
  notEditableByExternal,
} from '../../media-assets/assets-details/asset-constants/asset-fields-constants';
import { AssetHelperService } from '../../media-assets/assets-details/media-asset-complete-view/utils/asset-helper.service';
import { EvaluationService } from '../../../services/evaluation.service';
import { DatePickerComponent } from '../../media-assets/assets-details/media-asset-complete-view/date-picker/date-picker.component';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { ChipInputComponent } from '../../media-assets/assets-details/media-asset-complete-view/cp-gracenote-cmp-view/chip-input/chip-input.component';
import { ImagesViewEditModalComponent } from '../../media-assets/assets-details/media-asset-complete-view/modals/images-view-edit-modal/images-view-edit-modal.component';
import { MatButton } from '@angular/material/button';
import { SIDE_NAV_ROUTES } from '../../../constants/app-consts';
import { EVALUATION_CONSTS } from '../../../constants/evaluation-consts';

@Component({
  selector: 'app-evaluation-assets-details',
  imports: [MatRadioModule, CommonModule, ChipInputComponent, MatButton],
  templateUrl: './evaluation-assets-details.component.html',
  styleUrl: './evaluation-assets-details.component.scss',
})
export class EvaluationAssetsDetailComponent {
  private destroy = inject(DestroyRef);
  cpProviderData: any = {};
  gvdData: any = {};
  onData: any = {};
  allData: any = [];
  externalIdFlag: any;
  nonEditableFields: any;
  disabled: boolean = true;
  imageFields: any = imageFields;
  coverageStatus: '';
  comparisonStatus: '';
  highLightValues: string[] = ['COVERED', 'MATCHING'];
  contentId: '';
  EC = EVALUATION_CONSTS;

  constructor(
    public dialog: MatDialog,
    public assetHelperService: AssetHelperService,
    private evaluationService: EvaluationService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  fieldList: { key: string; value: string; isDifferent: boolean }[] = [
    {
      key: 'dataType',
      value: '',
      isDifferent: false,
    },
    {
      key: 'mainTitle',
      value: 'Program Main Title',
      isDifferent: false,
    },
    {
      key: 'shortTitle',
      value: 'Program Short Title',
      isDifferent: false,
    },
    {
      key: 'releaseDate',
      value: 'Release Date',
      isDifferent: false,
    },
    { key: 'genres', value: 'Genre', isDifferent: false },
    {
      key: 'description',
      value: 'Synopsis',
      isDifferent: false,
    },
    { key: 'director', value: 'Director', isDifferent: false },
    { key: 'starring', value: 'Actor', isDifferent: false },
    { key: 'image', value: 'Images', isDifferent: false },
  ];

  defaultFieldList: any = {
    mainTitle: null,
    shortTitle: null,
    releaseDate: null,
    genres: null,
    description: null,
    image: null,
    director: null,
    starring: null,
  };

  ngOnInit() {
    this.externalIdFlag = this.cpProviderData['externalId'] === 'Y';
    if (this.externalIdFlag) {
      this.nonEditableFields =
        notEditableByExternal.find(
          (obj) => obj.key === this.cpProviderData['type']
        )?.value ?? [];
    }
    this.contentId = this.route.snapshot.queryParams['contentId'];
    this.getDetailData();
  }

  getDetailData() {
    this.evaluationService
      .getEvaluationDetailData(
        this.route.snapshot.queryParams['contentId'],
        this.route.snapshot.queryParams['cpId']
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.cpProviderData =
          res.content == null ? this.defaultFieldList : res.content;
        this.gvdData =
          res.umd == null
            ? JSON.parse(JSON.stringify(this.defaultFieldList))
            : res.umd;
        this.onData =
          res.onApi == null
            ? JSON.parse(JSON.stringify(this.defaultFieldList))
            : res.onApi;
        this.setImage(this.cpProviderData);
        this.setImage(this.gvdData);
        this.setImage(this.onData);
        this.coverageStatus = res.coverageStatus;
        this.comparisonStatus = res.comparisonStatus;
        this.cpProviderData[EVALUATION_CONSTS.HEADER] =
          EVALUATION_CONSTS.CP_PROVIDER_TITLE;
        this.gvdData[EVALUATION_CONSTS.HEADER] = EVALUATION_CONSTS.GVD_TITLE;
        this.onData[EVALUATION_CONSTS.HEADER] = EVALUATION_CONSTS.ON_TITLE;
        this.setIsDifferentBetweenGvdAndOn(this.gvdData, this.onData);
        this.allData = [this.cpProviderData, this.gvdData, this.onData];
      });
  }

  setImage(data: any) {
    if (
      !data['imageLandscape'] &&
      !data['imagePortrait'] &&
      !data['imageLandscapeIconic'] &&
      !data['imagePortraitIconic']
    ) {
      data['isImage'] = false;
      return;
    } else {
      data['isImage'] = true;
    }

    data['image'] = [
      {
        key: 'imageLandscape',
        value: data['imageLandscape'],
        type: 'landscape',
        label: 'Landscape Banner (16:9)',
        size: data['imageLandscapeDimension'],
      },
      {
        key: 'imagePortrait',
        value: data['imagePortrait'],
        type: 'portrait',
        label: 'Portrait Banner (2:3)',
        size: data['imagePortraitDimension'],
      },
      {
        key: 'imageLandscapeIconic',
        value: data['imageLandscapeIconic'],
        type: 'landscape',
        label: 'Landscape Iconic (16:9)',
        size: data['imageLandscapeIconicDimension'],
      },
      {
        key: 'imagePortraitIconic',
        value: data['imagePortraitIconic'],
        type: 'portrait',
        label: 'Portrait Iconic (2:3)',
        size: data['imagePortraitIconicDimension'],
      },
    ];
  }

  setIsDifferentBetweenGvdAndOn(gvdData: any, onData: any) {
    const multiValues = ['genres', 'starring', 'director'];

    this.fieldList.forEach((field) => {
      if (field.key != 'image') {
        if (
          multiValues.includes(field.key) &&
          gvdData[field.key] &&
          onData[field.key]
        ) {
          const gvd: [] = gvdData[field.key].split(',');
          const on: [] = onData[field.key].split(',');

          gvd.sort();
          on.sort();

          field.isDifferent = JSON.stringify(gvd) != JSON.stringify(on);
        } else {
          field.isDifferent = gvdData[field.key] != onData[field.key];
        }
      } else {
        if (
          gvdData['imageLandscapeDimension'] !=
            onData['imageLandscapeDimension'] ||
          gvdData['imageLandscapeIconicDimension'] !=
            onData['imageLandscapeIconicDimension'] ||
          gvdData['imagePortraitDimension'] !=
            onData['imagePortraitDimension'] ||
          gvdData['imagePortraitIconicDimension'] !=
            onData['imagePortraitIconicDimension'] ||
          this.assetHelperService.setImageCount(imageFields, gvdData) !=
            this.assetHelperService.setImageCount(imageFields, onData)
        )
          field.isDifferent = true;
      }
    });
  }

  isHighLighted(value: string) {
    return this.highLightValues.includes(value);
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.EVALUATION.route_link]);
  }
}
