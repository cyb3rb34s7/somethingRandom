import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationAssetsDetailComponent } from './evaluation-assets-details.component';

describe('EvaluationAssetsDetailComponent', () => {
  let component: EvaluationAssetsDetailComponent;
  let fixture: ComponentFixture<EvaluationAssetsDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationAssetsDetailComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EvaluationAssetsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
