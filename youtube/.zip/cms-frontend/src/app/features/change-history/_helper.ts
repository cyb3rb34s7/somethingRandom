import { DOTS_CONSTS } from '../../constants/color-dots-consts';
import { STATUS_CONSTANTS } from '../../constants/status-consts';
import { StatusHistoryChange } from '../../models/asset-status-history';
import { LicenseHistoryChange } from '../../models/license-history-model';
import { DynamicObject } from '../../models/metadata-history-model';

function formatTxnDateForUI(dateTime: string): {
  date: string;
  time: string;
} {
  const tempdate: string = dateTime?.replace('T', ' ').replace('Z', '');
  const date = tempdate?.split(' ')[0];
  const time = tempdate?.split(' ')[1]?.split('.')[0];
  return { date, time };
}

function fetchStatusDot(status: string) {
  switch (status) {
    case STATUS_CONSTANTS.ACTIVE:
      return DOTS_CONSTS.STATUS_DOT_ACTIVE;
    case STATUS_CONSTANTS.EXPIRED:
      return DOTS_CONSTS.STATUS_DOT_EXPIRED;
    case STATUS_CONSTANTS.INPROGRESS:
      return DOTS_CONSTS.STATUS_DOT_IN_PROGRESS;
    case STATUS_CONSTANTS.QCFAIL:
      return DOTS_CONSTS.STATUS_DOT_EXPIRED;
    case STATUS_CONSTANTS.QCPASS:
      return DOTS_CONSTS.STATUS_DOT_RELEASED;
    case STATUS_CONSTANTS.QCREADY:
      return DOTS_CONSTS.STATUS_DOT_READY;
    case STATUS_CONSTANTS.RELEASED:
      return DOTS_CONSTS.STATUS_DOT_RELEASED;
    case STATUS_CONSTANTS.RELEASEREADY:
      return DOTS_CONSTS.STATUS_DOT_READY;
    case STATUS_CONSTANTS.REVOKED:
      return DOTS_CONSTS.STATUS_DOT_REVOKED;
    case STATUS_CONSTANTS.TQCPASS:
      return DOTS_CONSTS.STATUS_DOT_ACTIVE;
    default:
      return DOTS_CONSTS.STATUS_DOT_EXPIRED;
  }
}

function fetchLicenseWindowDot(value: string) {
  if (!value) return;

  if (value.includes(STATUS_CONSTANTS.INCLUDES_EXPIRING)) {
    return DOTS_CONSTS.STATUS_EXPIRING_IN;
  } else if (value.includes(STATUS_CONSTANTS.EXPIRED)) {
    return DOTS_CONSTS.STATUS_DOT_EXPIRED;
  } else if (value.includes(STATUS_CONSTANTS.INCLUDES_UPCOMING)) {
    return DOTS_CONSTS.STATUS_DOT_UPCOMING;
  } else if (
    value.toLowerCase().includes(STATUS_CONSTANTS.ACTIVE.toLowerCase())
  ) {
    return DOTS_CONSTS.STATUS_DOT_ACTIVE;
  } else {
    return DOTS_CONSTS.STATUS_DOT_REVOKED;
  }
}

const ColumnMap: any = {
  contentId: 'Program ID',
  cpName: 'CP Name',
  mainTitle: 'Program Title/Episode Title',
  shortTitle: 'Short Title',
  type: 'Type',
  countryCode: 'Country',
  subTitle: 'Subtitle',
  licenseWindow: 'License Window',
  status: 'Status',
  updateDate: 'Updated Date',
  showId: 'Show ID',
  seasonNo: 'Season No',
  seasonId: 'Season ID',
  episodeNo: 'Episode No',
  vcCpId: 'CP ID',
  externalId: 'TMS/Gracenote ID',
  releaseDate: 'Original Release Date',
  runningTime: 'Duration (sec)',
  description: 'Synopsis/Description',
  starring: 'Cast (Person Name)',
  genres: 'Genre',
  drm: 'DRM',
  availableStarting: 'Window Start Date',
  expiryDate: 'Window End Date',

  director: 'Director',
  ratings: 'Ratings',
  streamUri: 'Stream Uri',
  regDate: 'Registered Date',
  crctrId: 'Available Starting',
  webVttUrl: 'Web Vtt Url',
  thumbnailUrl: 'Thumbnail URL',
  audioLang: 'Audio Language',
  subtitleLang: 'Subtitle Language',
  deeplinkPayload: 'Deep Link Payload',
  audioCode: 'Audio Code',
  subtitleCode: 'Subtitle Code',
  quality: 'Quality',
  vcSvcId: 'Vc Svc Id',
  deeplinkId: 'Deep Link Id',
  fileName: 'FileName',
  dataplusYn: 'DataPlus Yn',
  nonAdStreamUri: 'Non Ad Stream Uri',

  artist: 'Artist',
  identifierId: 'Identifier ID',
  contentTier: 'Content Tier',
  chapterTime: 'Chapter Time',
  chapterDescription: 'Chapter Description',
  assetId: 'Asset ID',
  adTag: 'Ad Tag',
  platformTag: 'Platform Tag',
  contentPartner: 'Content Partner',
  role: 'Role',
  externalProgramId: 'External Program Id',
  idType: 'Id Type',
  externalProvider: 'External Provider',
  qcPassReason: 'QC pass Reason',
  tiName: 'Tech Integrator',
  adBreak: 'Ad Break',
  imageLandscapeOriginal: 'Banner Landscape Image',
  imagePortraitOriginal: 'Banner Portrait Image',
  imageLandscapeIconicOriginal: 'Iconic Landscape Image',
  imagePortraitIconicOriginal: 'Iconic Portrait Image',
  imageCircleOriginal: 'Circle Image',
  imageLandscape: 'Processed Banner Landscape Image',
  imagePortrait: 'Processed Banner Portrait Image',
  imageLandscapeIconic: 'Processed Iconic Landscape Image',
  imagePortraitIconic: 'Processed Iconic Portrait Image',
  imageLandscapeDimension: 'Landscape Image Dimension',
  imagePortraitDimension: 'Portrait Image Dimension',
  imageLandscapeIconicDimension: 'Iconic Landscape Image Dimension',
  imagePortraitIconicDimension: 'Iconic Portrait Image Dimension',
  imageCircle: 'Processed Circle Image',
  cast: 'Cast',
  name: 'Name',
  characterName: 'Character Name',
  idProvider: 'Provider ID',
  provider: 'Provider',
  platformTagData: 'Platform Tag Data',
  platform: 'Platform',
  parentalRatings: 'Parental Ratings',
  body: 'Rating Organization',
  stream_url: 'Stream URL',
  ad_tags: 'Ad Tags',
  ad_breaks: 'Ad Breaks',
  chapter_time: 'Chapter Time',
  chapter_description: 'Chapter Description',
  audio_languages: 'Audio Languages',
  subtitle_languages: 'Subtitle Languages',
  running_time: 'Running Time',
  scenepreview_webvtt: 'Scene Preview Url',
  mark_in: 'Mark In',
  mark_out: 'Mark Out',
  duration: 'Duration',
  order: 'Order',
  insert_ad_markers: 'Ad Markers',
  ad_break_duration_seconds: 'Ad Duration',
  license_url: 'License URL',
  custom_header_name: 'Header Name',
  custom_header_value: 'Header Value',
  currentStatus: 'Current Status',
  alias: 'Alias',
  availableEnding: 'Window End Date',
  licenseWindowList: 'License Window',
  licenseId: 'License Id',
  license_id: 'License Id',
  available_ending: 'Window End Date',
  available_starting: 'Window Start Date',
  streamType: 'Stream Type',
  onDeviceTrans: 'On Device Trans',
  eventWindowList: 'Event Window',
  eventStarting: 'Event Starting',
  eventEnding: 'Event Ending',
  event_id: 'Event Id',
  event_starting: 'Event Starting',
  event_ending: 'Event Ending',
  eventId: 'Event Id',
  externalProvidersList: 'External Providers',
  externalProviderList: 'External Providers',
  totalAvailableStarting: 'Total Available Starting',
  totalAvailableEnding: 'Total Available Ending',
  imagePortraitBackdropOriginal: 'Image Portrait Backdrop Original',
  imagePortraitBackdrop: 'Image Portrait Backdrop',
  imagePortraitBackdropDimension: 'Image Portrait Backdrop Dimension',
  imageLandscapeBackdropOriginal: 'Image Landscape Backdrop Original',
  imageLandscapeBackdrop: 'Image Landscape Backdrop',
  imageLandscapeBackdropDimension: 'Image Landscape Backdrop Dimension',
  imageTitleTreatmentOriginal: 'Image Title Treatment Original',
  imageTitleTreatment: 'Image Title Treatment',
  imageTitleTreatmentDimension: 'Image Title Treatment Dimension',
  attributes: 'Attributes',
  subtitle: 'Subtitle',
  lang_cd: 'Lang Code',
  url: 'URL',
  geoRestrictionList: 'Geo Restrictions',
  teamRegion: 'Team Region',
  geoRestrictionYn: 'Geo Restriction Flag',
  accessType: 'Access Type',
  restrictionType: 'Restriction Type',
  geo_restrictions: 'Geo Restrictions',
  team1: 'Team 1',
  team2: 'Team 2',
};

function downloadFile(data: any, fileName: string) {
  const blob = new Blob([data], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;

  link.setAttribute('download', getFileName(fileName));
  document.body.appendChild(link);
  link.click();
  link.remove();
}
function getFileName(graph: string): string {
  const currentDateTime = new Date();

  const year = currentDateTime.getFullYear();
  const month = ('0' + (currentDateTime.getMonth() + 1)).slice(-2);
  const day = ('0' + currentDateTime.getDate()).slice(-2);
  const hours = ('0' + currentDateTime.getHours()).slice(-2);
  const minutes = ('0' + currentDateTime.getMinutes()).slice(-2);
  const seconds = ('0' + currentDateTime.getSeconds()).slice(-2);

  // Format as YYYYMMDDhhmmss
  const formattedDateTime = `${year}${month}${day}${hours}${minutes}${seconds}`;
  return graph + '_' + formattedDateTime + '.xlsx';
}

function isISODateString(val: any): boolean {
  const isoDatePattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}?Z$/;
  return isoDatePattern.test(val);
}

function formatValueForUI(value: any, colorArray: any): any {
  const parsedValue = typeof value === 'string' ? parseValue(value) : value;

  // If parsed value is an array of objects
  if (Array.isArray(parsedValue) && parsedValue.length > 0) {
    // Get all unique keys from the objects
    let allKeys = Array.from(
      new Set(parsedValue.flatMap((obj) => Object.keys(obj)))
    );
    //process Data to Format Inner Table Dates
    const processedData = parsedValue.map((obj) => {
      const processedObj = { ...obj };
      allKeys.forEach((key) => {
        if (
          typeof processedObj[key] === 'string' &&
          isISODateString(processedObj[key])
        ) {
          processedObj[key] = processedObj[key]
            .replace('T', ' ')
            .replace('Z', '');
        }
      });
      return processedObj;
    });

    // allKeys = allKeys.filter((key) => key !== 'color');

    // Generate HTML for the dynamic table
    const htmlContent = `
        <div class="modern-table-container">
          <table class="modern-table">
            <thead>
              <tr>
                ${allKeys
                  .map(
                    (key) => `
                  <th style=" overflow:hidden; ">
                    ${ColumnMap[key] || key}
                  </th>
                `
                  )
                  .join('')}
              </tr>
            </thead>
            <tbody>
              ${processedData
                .map(
                  (obj, ind) => `
                <tr>
                  ${allKeys
                    .map(
                      (key) => `

                      <td ${
                        ind < colorArray[key].length && colorArray[key][ind]
                          ? 'style="color:' + colorArray[key][ind] + '"'
                          : ''
                      }>

                      <div class="dynamic-cell"
                        style="text-overflow: ellipsis;
                        white-space: nowrap;
                        overflow: hidden;"
                        title="${obj[key] || '-'}"
                    >

                      ${obj[key] || '-'}
                    </div>

                    </td>
                  `
                    )
                    .join('')}
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>
        </div>
      `;
    return htmlContent;
  }

  if (Array.isArray(parsedValue) && parsedValue.length === 0) return null;
  const val: string = String(value ?? '');
  if (val && isISODateString(val)) {
    return val.replace('T', ' ').replace('Z', '');
  }
  return val === '' || val === '""' ? null : val;
}
function parseValue(value: string): string | number | DynamicObject[] {
  if (typeof value === 'string') {
    try {
      const parsedValue = JSON.parse(value);

      if (
        Array.isArray(parsedValue) &&
        parsedValue.every((item) => typeof item === 'object' && item !== null)
      ) {
        return parsedValue as DynamicObject[];
      }
      if (typeof parsedValue === 'object' && parsedValue !== null) {
        return [parsedValue as DynamicObject];
      }
      if (typeof parsedValue === 'number' || typeof parsedValue === 'string') {
        return parsedValue;
      }
    } catch {
      return value;
    }
  }
  return value;
}

function prepareExpandedRowsForStatus(history: StatusHistoryChange[]) {
  const data: any[] = [];

  history.map((historyChange) => {
    const obj: any = {};
    obj['Change Date'] = historyChange.changeDateTime;
    obj['Change Time'] = historyChange.changeDateTime;
    obj['Old Asset Status'] = historyChange.oldStatus;

    obj['New Asset Status'] = historyChange.newStatus;
    obj['Updated By'] = historyChange.updatedBy;

    data.push(obj);
  });
  return data;
}
function prepareExpandedRowsForLicense(
  history: LicenseHistoryChange[],
  vodType: string
) {
  const data: any[] = [];

  history.map((historyChange) => {
    const obj: any = {};

    obj['Change Date'] = historyChange.changeDateTime;
    obj['Change Time'] = historyChange.changeDateTime;
    if (vodType) {
      obj['Type'] = vodType;
    }
    obj['License Start Date (UTC)'] =
      historyChange.releaseDate?.replace('T', ' ')?.replace('Z', '') ?? '';
    obj['License End Date (UTC)'] =
      historyChange.expiryDate?.replace('T', ' ')?.replace('Z', '') ?? '';

    obj['Updated By'] = historyChange.updatedBy;
    obj['License Status'] = [
      fetchLicenseWindowDot(historyChange.oldStatus),
      '',
      historyChange.oldStatus,
    ];

    data.push(obj);
  });

  return data;
}

export {
  formatTxnDateForUI,
  fetchStatusDot,
  fetchLicenseWindowDot,
  ColumnMap,
  downloadFile,
  isISODateString,
  formatValueForUI,
  getFileName,
  parseValue,
  prepareExpandedRowsForStatus,
  prepareExpandedRowsForLicense,
};
