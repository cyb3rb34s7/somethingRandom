import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  Output,
  QueryList,
  SimpleChanges,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import {
  MatDatepicker,
  MatDatepickerModule,
} from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { LicenseFilterModel } from '../../../models/license-filter-model';
import { HISTORY_CONSTS } from '../../../constants/history-consts';
import { DateRangeSelectorComponent } from '../../../components/date-range-selector/date-range-selector.component';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
@Component({
    selector: 'app-filter-modal',
    imports: [
        MatButtonModule,
        MatExpansionModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatIconModule,
        CommonModule,
        MatCheckbox,
        MatNativeDateModule,
        MatDatepickerModule,
        MatInputModule,
        MatDialogModule,
        FormsModule,
        DateRangeSelectorComponent,
        AppMatSimpleSearchComponent,
    ],
    templateUrl: './filter-modal.component.html',
    styleUrl: './filter-modal.component.scss',
    providers: []
})
export class FilterModalComponent implements OnChanges {
  @Output() closed = new EventEmitter<void>();

  @Input() allFiltersList: { [key: string]: string[] } = {};
  @Input() showDateFilter: boolean = true;
  @Input() resetTrigger: number = 0;
  @Output() filtersApplied = new EventEmitter<LicenseFilterModel[]>();
  @Output() filterReset = new EventEmitter<void>();
  @Output() appliedFiltersCount = new EventEmitter<any>();
  @ViewChildren(MatDatepicker) datePickers!: QueryList<MatDatepicker<any>>;
  @ViewChildren(AppMatSimpleSearchComponent)
  innerSearchFlds!: QueryList<AppMatSimpleSearchComponent>;

  appliedFilters: LicenseFilterModel[] = [];
  selectedFilters: LicenseFilterModel[] = [];
  selectedSearchText: any;
  appliedSearchText: any;
  selectedDateRange: any[] = ['', ''];
  appliedDateRange: any[] = ['', ''];
  dateRangeError: string = '';
  isOpen = false;
  searchText: any;
  dateRangeText: string = 'Date Range';

  colSpan: any = {
    type: 2,
    currentStatus: 3,
    licenseStatus: 3,
  };

  expandedFiltersMap: any = {};

  backupValues: any = {};

  constructor() {}

  open() {
    this.isOpen = true;
    this.selectedFilters = JSON.parse(JSON.stringify(this.appliedFilters));
    this.selectedDateRange = JSON.parse(JSON.stringify(this.appliedDateRange));
    this.selectedSearchText = this.appliedSearchText;
    this.backupValues = JSON.parse(JSON.stringify(this.allFiltersList));
  }

  close() {
    this.isOpen = false;
    this.selectedFilters = [];
    this.selectedDateRange = ['', ''];
    this.selectedSearchText = '';
    this.innerSearchFlds.forEach((c: AppMatSimpleSearchComponent) => c.clear());
    this.closed.emit();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['resetTrigger'] && !changes['resetTrigger'].firstChange) {
      this.resetFilters();
    }
  }
  @HostListener('keydown.enter', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    this.datePickers.forEach((picker) => {
      if (picker.opened) {
        picker.close();
      }
    });
    event.preventDefault();
    event.stopPropagation();
    this.applyFilters();
  }
  get filtersCount() {
    return this.selectedFilters.length < 10
      ? '0' + this.selectedFilters.length
      : this.selectedFilters.length;
  }

  get selectedCountMap(): { [key: string]: string } {
    const map: { [key: string]: string } = {};
    this.selectedFilters.forEach((filter) => {
      const valuesLength = filter.values.length;
      const cnt =
        valuesLength < 10 ? '0' + valuesLength : valuesLength.toString();
      map[filter.key] = cnt;
    });
    return map;
  }

  updateFilters(key: string, option: string, isChecked: boolean) {
    const filterIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === key
    );

    if (filterIndex > -1) {
      if (isChecked) {
        this.selectedFilters[filterIndex].values.push(option);
      } else {
        const valueIndex =
          this.selectedFilters[filterIndex].values.indexOf(option);
        if (valueIndex > -1) {
          this.selectedFilters[filterIndex].values.splice(valueIndex, 1);
        }
      }
      if (this.selectedFilters[filterIndex].values.length === 0) {
        this.selectedFilters.splice(filterIndex, 1);
      }
    } else if (isChecked) {
      this.selectedFilters.push({
        type: 'filter',
        key: key,
        values: [option],
      });
    }
  }
  updateSearchableFilter(filterKey: string) {
    const customFilterIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === filterKey
    );

    if (this.selectedSearchText?.trim()) {
      if (customFilterIndex > -1) {
        this.selectedFilters[customFilterIndex].values = [
          this.selectedSearchText,
        ];
      } else {
        this.selectedFilters.push({
          type: 'search',
          key: filterKey,
          values: [this.selectedSearchText],
        });
      }
    } else if (customFilterIndex > -1) {
      this.selectedFilters.splice(customFilterIndex, 1);
    }
  }

  updateDateRange() {
    const dateRangeIndex = this.selectedFilters.findIndex(
      (filter) => filter.key === 'dateFilter'
    );
    if (this.selectedDateRange.findIndex((e) => e != '') != -1) {
      // any is selected
      const isValidDate = (date: Date) => !isNaN(date.getTime());
      const startDate = new Date(this.selectedDateRange[0]);
      const endDate = new Date(this.selectedDateRange[1]);
      const dateRangeFilter: LicenseFilterModel = {
        type: 'filter',
        key: 'dateFilter',
        values: [
          isValidDate(startDate) ? this.dateFormatUtil(startDate) : '',
          isValidDate(endDate) ? this.dateFormatUtil(endDate) : '',
        ],
      };
      if (dateRangeIndex > -1) {
        this.selectedFilters[dateRangeIndex] = dateRangeFilter;
      } else {
        this.selectedFilters.push(dateRangeFilter);
      }
    }

    // if no date filter present
    if (
      dateRangeIndex > -1 &&
      this.selectedDateRange.findIndex((e) => e != '') == -1
    ) {
      this.selectedFilters.splice(dateRangeIndex, 1);
    }
  }

  isSelected(key: string, option: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    return filter ? filter.values.includes(option) : false;
  }

  isAllSelected(key: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    if (!filter) return false;
    const allOptions = this.allFiltersList[key];
    return filter.values.length === allOptions.length;
  }

  isSomeSelected(key: string): boolean {
    const filter = this.selectedFilters.find((filter) => filter.key === key);
    if (!filter) return false;

    const allOptions = this.allFiltersList[key];
    return filter.values.length > 0 && filter.values.length < allOptions.length;
  }

  selectAllOptions(key: string, isChecked: boolean): void {
    if (isChecked) {
      const allOptions = this.allFiltersList[key];
      const filterIndex = this.selectedFilters.findIndex(
        (filter) => filter.key === key
      );
      const newFilter: LicenseFilterModel = {
        type: 'filter',
        key: key,
        values: [...allOptions],
      };

      if (filterIndex > -1) {
        this.selectedFilters[filterIndex] = newFilter;
      } else {
        this.selectedFilters.push(newFilter);
      }
    } else {
      const filterIndex = this.selectedFilters.findIndex(
        (filter) => filter.key === key
      );
      if (filterIndex > -1) {
        this.selectedFilters.splice(filterIndex, 1);
      }
    }
  }

  applyFilters() {
    this.updateDateRange();
    this.appliedFilters = JSON.parse(JSON.stringify(this.selectedFilters));
    this.appliedDateRange = JSON.parse(JSON.stringify(this.selectedDateRange));
    this.appliedSearchText = this.selectedSearchText;
    this.selectedDateRange = ['', ''];
    this.selectedSearchText = '';

    this.appliedFiltersCount.emit(this.filtersCount);
    this.selectedFilters = [];
    this.filtersApplied.emit(this.appliedFilters);
    this.close();
  }

  resetFilters() {
    this.selectedFilters = [];
    this.selectedDateRange = ['', ''];
    this.selectedSearchText = '';
    this.dateRangeError = '';
  }

  findFilterName(key: string): string {
    switch (key) {
      case 'licenseStatus':
        return 'License Status';
      case 'type':
        return 'Media Type';
      case 'allStatus':
        return 'Media Status';
      case 'currentRole':
        return 'User Role';
      case 'currentStatus':
        return 'User Status';
      case 'tiName':
        return 'Tech Integrator';
      case 'contentPartner':
        return 'Content Partner';
      default:
        return 'Filter Name Not Found!';
    }
  }

  dateFormatUtil(d: Date): string {
    const days = d.getDate() < 10 ? '0' + d.getDate() : d.getDate();
    const months =
      d.getMonth() + 1 < 10 ? '0' + (d.getMonth() + 1) : d.getMonth() + 1;
    const year = d.getFullYear();
    return year + '-' + months + '-' + days;
  }

  isHidden(key: string, searchTerm: string) {
    if (searchTerm && searchTerm.length) {
      return !key.toLowerCase().includes(searchTerm.trim().toLowerCase());
    } else if (searchTerm && !searchTerm.length) {
      return true;
    }
    return false;
  }

  isSearchable(key: string): boolean {
    return HISTORY_CONSTS.SEARCHABLE_FILTERS.includes(key);
  }

  handleInnerSearch(filter: any, txt: string) {
    if (txt.length) {
      console.log(filter, this.backupValues[filter.key]);
      filter.value = this.backupValues[filter.key].filter((v: string) =>
        v.toLowerCase().includes(txt.toLowerCase())
      );
      console.log(filter);
    } else {
      filter.value = [...this.backupValues[filter.key]];
    }
  }

  handleDateRange(date: any, dateRange: 'dateFrom' | 'dateTo') {
    if (dateRange === 'dateFrom') {
      this.selectedDateRange[0] = date.value;
      this.selectedDateRange[1] = this.selectedDateRange[1] ?? '';
    } else {
      this.selectedDateRange[1] = date.value;
      this.selectedDateRange[0] = this.selectedDateRange[0] ?? '';
    }
    this.selectedDateRange = [...this.selectedDateRange];
  }
}
