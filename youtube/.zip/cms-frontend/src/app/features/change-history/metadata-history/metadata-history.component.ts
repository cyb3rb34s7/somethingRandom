import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, Input, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltip } from '@angular/material/tooltip';
import { plainToInstance } from 'class-transformer';
import { HISTORY_CONSTS } from '../../../constants/history-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import {
  FilterRequestBody,
  LicenseFilterModel,
} from '../../../models/license-filter-model';
import {
  MetaDataHistory,
  MetaDataHistoryChanges,
} from '../../../models/metadata-history-model';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { MetadataHistoryService } from '../../../services/metadata-history.service';
import { ColumnMap, downloadFile, formatValueForUI } from '../_helper';
import { FilterModalComponent } from '../filter-modal/filter-modal.component';
import { colorGroupingByHistoryChange } from '../helperForTable';
import { HistoryMatTableComponent } from '../history-mat-table/history-mat-table.component';

@Component({
  selector: 'app-metadata-history',
  imports: [
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    AppMatSimpleSearchComponent,
    FilterModalComponent,
    MatMenuModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    MatTooltip,
    HistoryMatTableComponent,
  ],
  templateUrl: './metadata-history.component.html',
  styleUrl: './metadata-history.component.scss',
})
export class MetadataHistoryComponent {
  private destroy = inject(DestroyRef);
  @Input() assetId: string | null = null;
  @Input()
  MetadataHistoryData: MetaDataHistory[] = [];
  tableData: any[];
  resetTrigger = 0;
  MetaDataFiltersAll: { [key: string]: string[] } = {};
  filterBody: FilterRequestBody = {
    filters: [],
    sortBy: {
      field: 'changeDateTime',
      order: 'DESC',
    },
    pagination: {
      limit: 1000,
      offset: 0,
    },
  };
  appliedFilterCount: any;
  searchText: string = HISTORY_CONSTS.EMPTY_STRING;
  noMoreDataAvailable: boolean = false;
  offsetIndex: any = 0;
  metadataHistoryCount: number;
  totalRecordsOriginal: number;

  constructor(
    public metadataHistoryService: MetadataHistoryService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {
    this.fetchMetadataHistory();
    this.fetchMetadataFilters();
  }
  @ViewChild(FilterModalComponent) filterSidebar: FilterModalComponent;
  @ViewChild(HistoryMatTableComponent) historyTable: HistoryMatTableComponent;

  openFilterSidebar() {
    this.filterSidebar.open();
  }

  onSidebarClosed() {}

  setAppliedFiltersCount(event: any) {
    this.appliedFilterCount = event;
  }
  onLoadMore(e: any) {
    if (!this.searchText && !this.noMoreDataAvailable) {
      if (this.filterBody.pagination?.offset != null) {
        this.offsetIndex++;
        this.filterBody.pagination.offset = this.offsetIndex * 1000;
      }
      this.fetchMetadataHistory();
    }
  }

  fetchMetadataHistory(isRefresh: boolean = false) {
    const observable = this.assetId
      ? this.metadataHistoryService.getMetaDataHistoryById(
          this.assetId,
          this.filterBody
        )
      : this.metadataHistoryService.getMetaDataHistory(this.filterBody);
    observable.pipe(takeUntilDestroyed(this.destroy)).subscribe({
      next: (res) => {
        if (isRefresh) {
          this.MetadataHistoryData.splice(this.offsetIndex * 1000);
          this.MetadataHistoryData = this.MetadataHistoryData.concat(
            plainToInstance<MetaDataHistory, []>(MetaDataHistory, res.data)
          );
        } else if (this.filterBody.pagination?.offset === 0) {
          this.MetadataHistoryData = plainToInstance<MetaDataHistory, []>(
            MetaDataHistory,
            res.data
          );
        } else {
          this.MetadataHistoryData = this.MetadataHistoryData.concat(
            plainToInstance<MetaDataHistory, []>(MetaDataHistory, res.data)
          );
        }

        if (res.data.length < 1000) {
          this.noMoreDataAvailable = true;
        } else {
          this.noMoreDataAvailable = false;
        }
        this.metadataHistoryCount = res.count;
        this.totalRecordsOriginal = res.count;

        this.prepareTableData(this.MetadataHistoryData);
        this.handleSearch(this.searchText);
      },
      error: (error: HttpErrorResponse) => {
        console.log('====Error===', error);
      },
    });
  }
  fetchMetadataFilters() {
    this.metadataHistoryService
      .getAllMetadataFilters()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.MetaDataFiltersAll = res;
      });
  }

  onMetadataFiltersApply(filters: LicenseFilterModel[]) {
    this.offsetIndex = 0;
    this.filterBody = {
      filters: filters,
      pagination: {
        limit: 1000,
        offset: 0,
      },
      sortBy: {
        field: 'changeDateTime',
        order: 'DESC',
      },
    };
    if (this.historyTable?.paginator) {
      this.historyTable.paginator.firstPage();
    }

    this.fetchMetadataHistory();
  }
  onFiltersReset() {}

  prepareTableData(metadataHistory: MetaDataHistory[]) {
    this.tableData = metadataHistory
      .map((objMetadata: MetaDataHistory) => {
        const obj: any = {};

        try {
          const changesArray = JSON.parse(objMetadata.changes);

          if (changesArray.length === 0) return null;

          obj[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS] =
            this.prepareExpandedRows(changesArray);

          obj['Change Date'] = objMetadata.changeDateTime;
          obj['Change Time'] = objMetadata.changeDateTime;
          obj['Program ID'] = objMetadata.assetId;
          obj['CP Name'] = objMetadata.contentPartner;
          obj['Tech Integrator'] = objMetadata.tiName;
          obj['Program Title'] = objMetadata.mediaTitle;
          obj['Last Updated By'] = objMetadata.updatedBy;

          return obj;
        } catch (error) {
          console.error(
            `Error parsing changes for asset ID ${objMetadata.assetId}:${objMetadata.changeDateTime} ${error}`
          );
          return null;
        }
      })
      .filter((row) => row !== null);
  }
  prepareExpandedRows(history: MetaDataHistoryChanges[]) {
    const data: any[] = [];
    history.forEach((historyChange) => {
      const obj: any = {};
      const fieldName: string =
        ColumnMap[historyChange.field] || historyChange.field;
      obj['Field'] = fieldName;
      if (historyChange.field === 'deeplinkPayload') {
        obj['Old Value'] = historyChange.oldValue;
        obj['New Value'] = historyChange.newValue;
      } else if (
        historyChange.field === 'cast' ||
        historyChange.field === 'parentalRatings' ||
        historyChange.field === 'externalProvider' ||
        historyChange.field === 'drm' ||
        historyChange.field === 'platformTagData' ||
        historyChange.field === 'Platforms' ||
        historyChange.field === 'ad_breaks' ||
        historyChange.field === 'licenseWindowList' ||
        historyChange.field === 'eventWindowList' ||
        historyChange.field === 'assetImageList' ||
        historyChange.field === 'subtitle' ||
        historyChange.field === 'geoRestrictionList'
      ) {
        let oldAndNewValueColorArray = colorGroupingByHistoryChange(
          historyChange.oldValue,
          historyChange.newValue
        );
        obj['Old Value'] = formatValueForUI(
          historyChange.oldValue,
          oldAndNewValueColorArray[0]
        );
        obj['New Value'] = formatValueForUI(
          historyChange.newValue,
          oldAndNewValueColorArray[1]
        );
      } else {
        obj['Old Value'] = formatValueForUI(historyChange.oldValue, []);
        obj['New Value'] = formatValueForUI(historyChange.newValue, []);
      }

      data.push(obj);
    });

    return data;
  }

  handleSearch(value: string) {
    this.searchText = value;
    if (value) {
      const data = this.MetadataHistoryData.filter((d) => {
        const searchIn = (
          d.assetId +
          d.mediaTitle +
          d.tiName +
          d.updatedBy
        ).toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
      if (this.historyTable?.paginator) {
        this.historyTable.paginator.firstPage();
      }
      this.metadataHistoryCount = data.length;
    } else {
      this.prepareTableData(this.MetadataHistoryData);
      this.metadataHistoryCount = this.totalRecordsOriginal;
    }
  }
  handleMetadataHistoryExport() {
    const exportfilterBody: FilterRequestBody = {
      filters: this.filterBody.filters,
      pagination: {
        limit: HISTORY_CONSTS.EXPORT_EXCEL_COUNT,
        offset: 0,
      },
      sortBy: {
        field: 'changeDateTime',
        order: 'DESC',
      },
    };

    this.metadataHistoryService
      .exportMetadataHistoryToExcel(exportfilterBody)
      .subscribe((res) => {
        downloadFile(res, 'MediaAssetsHistory');
        this.toastr.success('Data is exported Successfully!');
      });
  }
}
