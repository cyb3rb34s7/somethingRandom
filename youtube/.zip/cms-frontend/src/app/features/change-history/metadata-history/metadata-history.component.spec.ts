import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataHistoryComponent } from './metadata-history.component';

describe('MetadataHistoryComponent', () => {
  let component: MetadataHistoryComponent;
  let fixture: ComponentFixture<MetadataHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MetadataHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MetadataHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
