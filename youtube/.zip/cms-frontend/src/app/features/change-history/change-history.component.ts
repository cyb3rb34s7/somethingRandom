import { Component } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { ITabLabel } from '../../interfaces/i-tab-label';
import { AssetStatusHistoryComponent } from './asset-status-history/asset-status-history.component';
import { LicenseHistoryComponent } from './license-history/license-history.component';
import { MetadataHistoryComponent } from './metadata-history/metadata-history.component';
import { UserHistoryComponent } from './user-history/user-history.component';

@Component({
    selector: 'app-change-history',
    imports: [
        MatTabsModule,
        LicenseHistoryComponent,
        UserHistoryComponent,
        MetadataHistoryComponent,
        AssetStatusHistoryComponent,
    ],
    templateUrl: './change-history.component.html',
    styleUrl: './change-history.component.scss'
})
export class ChangeHistoryComponent {
  labels: ITabLabel[] = [];

  selectedTabIndex = 0;

  constructor() {
    this.labels = [
      {
        text: 'Metadata',
        count: -1,
      },
      {
        text: 'User Management',
        count: -1,
      },
      {
        text: 'License Window',
        count: -1,
      },
      {
        text: 'Asset Status',
        count: -1,
      },
    ];
  }

  handleTabChange(index: number) {
    this.selectedTabIndex = index;
  }
}
