import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetStatusHistoryComponent } from './asset-status-history.component';

describe('AssetStatusHistoryComponent', () => {
  let component: AssetStatusHistoryComponent;
  let fixture: ComponentFixture<AssetStatusHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetStatusHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AssetStatusHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
