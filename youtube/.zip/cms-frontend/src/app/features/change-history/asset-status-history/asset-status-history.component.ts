import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { plainToInstance } from 'class-transformer';
import { HISTORY_CONSTS } from '../../../constants/history-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import { AssetStatusHistoryModel } from '../../../models/asset-status-history';
import {
  FilterRequestBody,
  LicenseFilterModel,
} from '../../../models/license-filter-model';
import { AssetStatusHistoryService } from '../../../services/asset-status-history.service';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { downloadFile } from '../_helper';
import { FilterModalComponent } from '../filter-modal/filter-modal.component';
import { HistoryMatTableComponent } from '../history-mat-table/history-mat-table.component';

@Component({
    selector: 'app-asset-status-history',
    imports: [
        AppMatSimpleSearchComponent,
        FilterModalComponent,
        MatCardModule,
        MatButtonModule,
        MatIconModule,
        HistoryMatTableComponent,
        MatTooltip,
    ],
    templateUrl: './asset-status-history.component.html',
    styleUrl: './asset-status-history.component.scss'
})
export class AssetStatusHistoryComponent {
  private destroy = inject(DestroyRef);
  searchText: string = HISTORY_CONSTS.EMPTY_STRING;
  AssetStatusHistoryData: AssetStatusHistoryModel[] = [];
  tableData: any[];
  AssetStatusHistoryFilters: { [key: string]: string[] } = {};
  filterBody: FilterRequestBody = {
    filters: [],
    sortBy: {
      field: 'latestChangeDateTime',
      order: 'DESC',
    },
    pagination: {
      limit: 1000,
      offset: 0,
    },
  };
  appliedFilterCount: any;
  noMoreDataAvailable: boolean = false;
  offsetIndex: any = 0;
  statusHistoryCount: number;
  totalRecordsOriginal: number;

  constructor(
    public statusHistoryService: AssetStatusHistoryService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {
    this.fetchAssetStatusHistory();
    this.fetchStatusHistoryFilters();
  }

  @ViewChild(FilterModalComponent) filterSidebar: FilterModalComponent;
  @ViewChild(HistoryMatTableComponent) historyTable: HistoryMatTableComponent;

  openFilterSidebar() {
    this.filterSidebar.open();
  }

  onSidebarClosed() {}

  onLoadMore(e: any) {
    if (!this.searchText && !this.noMoreDataAvailable) {
      if (this.filterBody.pagination?.offset != null) {
        this.offsetIndex++;
        this.filterBody.pagination.offset = this.offsetIndex * 1000;
      }
      this.fetchAssetStatusHistory();
    }
  }

  fetchAssetStatusHistory(isRefresh: boolean = false) {
    this.statusHistoryService
      .getAllAssetStatusHistory(this.filterBody)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          if (isRefresh) {
            this.AssetStatusHistoryData.splice(this.offsetIndex * 1000);
            this.AssetStatusHistoryData = this.AssetStatusHistoryData.concat(
              plainToInstance<AssetStatusHistoryModel, []>(
                AssetStatusHistoryModel,
                res.data
              )
            );
          } else if (this.filterBody.pagination?.offset === 0) {
            this.AssetStatusHistoryData = plainToInstance<
              AssetStatusHistoryModel,
              []
            >(AssetStatusHistoryModel, res.data);
          } else {
            this.AssetStatusHistoryData = this.AssetStatusHistoryData.concat(
              plainToInstance<AssetStatusHistoryModel, []>(
                AssetStatusHistoryModel,
                res.data
              )
            );
          }
          if (res.data.length < 1000) {
            this.noMoreDataAvailable = true;
          } else {
            this.noMoreDataAvailable = false;
          }
          this.statusHistoryCount = res.count;
          this.totalRecordsOriginal = res.count;

          this.prepareTableData(this.AssetStatusHistoryData);
          this.handleSearch(this.searchText);
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }
  fetchStatusHistoryFilters() {
    this.statusHistoryService
      .getAllStatusHistoryFilters()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.AssetStatusHistoryFilters = res;
      });
  }

  onStatusHistoryFiltersApply(filters: LicenseFilterModel[]) {
    this.offsetIndex = 0;
    this.filterBody = {
      filters: filters,
      pagination: {
        limit: 1000,
        offset: 0,
      },
      sortBy: {
        field: 'latestChangeDateTime',
        order: 'DESC',
      },
    };
    if (this.historyTable?.paginator) {
      this.historyTable.paginator.firstPage();
    }

    this.fetchAssetStatusHistory();
  }
  onFiltersReset() {}

  prepareTableData(statusHistory: AssetStatusHistoryModel[]) {
    this.tableData = statusHistory.map(
      (objStatusHistory: AssetStatusHistoryModel) => {
        const obj: any = {};

        obj[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS] = [];
        obj['CP Name'] = objStatusHistory.contentPartner;
        obj['Tech Integrator'] = objStatusHistory.tiName;
        obj['Program ID'] = objStatusHistory.assetId;
        obj['Program Title'] = objStatusHistory.mediaTitle;
        obj['Type'] = objStatusHistory.type;
        obj['Last Updated By'] = objStatusHistory.latestUpdatedBy;
        obj['Change Date'] = objStatusHistory.latestChangeDateTime;
        obj['Change Time'] = objStatusHistory.latestChangeDateTime;
        return obj;
      }
    );
  }

  handleSearch(value: string) {
   this.searchText = value;
    if (value) {
      const data = this.AssetStatusHistoryData.filter((d) => {
        const searchIn = (d.assetId + d.mediaTitle).toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
      if (this.historyTable?.paginator) {
        this.historyTable.paginator.firstPage();
      }
      this.statusHistoryCount = data.length;
    } else {
      this.prepareTableData(this.AssetStatusHistoryData);
      this.statusHistoryCount = this.totalRecordsOriginal;
    }
  }

  handleAssetStatusHistoryExport() {
    const exportfilterBody: FilterRequestBody = {
      filters: this.filterBody.filters,
      pagination: {
        limit: HISTORY_CONSTS.EXPORT_EXCEL_COUNT,
        offset: 0,
      },
      sortBy: {
        field: 'latestChangeDateTime',
        order: 'DESC',
      },
    };

    this.statusHistoryService
      .exportAssetStatusHistoryToExcel(exportfilterBody)
      .subscribe((res) => {
        downloadFile(res, 'StatusHistory');
        this.toastr.success('Data is exported Successfully!');
      });
  }
}
