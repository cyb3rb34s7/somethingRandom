import { parseValue } from './_helper';
import { DynamicObject } from '../../models/metadata-history-model';

function colorGroupingByHistoryChange(oldValue: any, newValue: any): any {
  var oldValueArray =
    typeof oldValue === 'string' ? parseValue(oldValue) : oldValue;
  var newValueArray =
    typeof newValue === 'string' ? parseValue(newValue) : newValue;

  let oldKeys: string[] = [];
  if (
    oldValueArray !== undefined &&
    Array.isArray(oldValueArray) &&
    oldValueArray.length !== 0
  ) {
    oldKeys = Array.from(
      new Set(oldValueArray.flatMap((obj: any) => Object.keys(obj)))
    );
  }

  let newKeys: string[] = [];
  if (
    newValueArray !== undefined &&
    Array.isArray(newValueArray) &&
    newValueArray.length !== 0
  ) {
    newKeys = Array.from(
      new Set(newValueArray.flatMap((obj: any) => Object.keys(obj)))
    );
  }

  var oldArrayColor: { [key: string]: (string | null)[] } = {};
  oldKeys.forEach((key: string) => {
    oldArrayColor[key] = new Array(oldValueArray.length).fill(null);
  });

  var newArrayColor: { [key: string]: (string | null)[] } = {};
  newKeys.forEach((key: string) => {
    newArrayColor[key] = new Array(newValueArray.length).fill(null);
  });

  // If parsed value is an array of objects
  if (
    Array.isArray(oldValueArray) &&
    oldValueArray.length > 0 &&
    Array.isArray(newValueArray) &&
    newValueArray.length > 0
  ) {
    var visitedOldArray: boolean[] = new Array(oldValueArray.length).fill(
      false
    );
    var visitednewArray: boolean[] = new Array(newValueArray.length).fill(
      false
    );

    for (var i = 0; i < oldValueArray.length; i++) {
      for (var j = 0; j < newValueArray.length; j++) {
        var flag = isSameObject(oldValueArray[i], newValueArray[j]);
        if (flag) {
          visitednewArray[j] = true;
          visitedOldArray[i] = true;
          giveSpecifyColor(oldValueArray[i], 'black', i, oldArrayColor);
          giveSpecifyColor(newValueArray[j], 'black', j, newArrayColor);
          break;
        }
      }
    }
    for (var i = 0; i < oldValueArray.length; i++) {
      if (visitedOldArray[i] === false) {
        var index = -1;
        var result = 0;
        for (var j = 0; j < newValueArray.length; j++) {
          if (visitednewArray[j] === false) {
            var value = findMatch(oldValueArray[i], newValueArray[j]);
            if (value > result) {
              index = j;
              result = value;
            }
          }
        }
        if (result > 0) {
          visitednewArray[index] = true;
          giveColorOnChangeFields(
            oldValueArray[i],
            newValueArray[index],
            index,
            newArrayColor,
            'green'
          );
          giveColorOnChangeFields(
            newValueArray[index],
            oldValueArray[i],
            i,
            oldArrayColor,
            'red'
          );
        } else {
          giveSpecifyColor(oldValueArray[i], 'red', i, oldArrayColor);
        }
      }
    }
    for (var j = 0; j < newValueArray.length; j++) {
      if (visitednewArray[j] === false) {
        giveSpecifyColor(newValueArray[j], 'green', j, newArrayColor);
      }
    }
    var ans = [oldArrayColor, newArrayColor];
    return ans;
  } else if (Array.isArray(oldValueArray) && oldValueArray.length > 0) {
    for (var j = 0; j < oldValueArray.length; j++) {
      giveSpecifyColor(oldValueArray[j], 'red', j, oldArrayColor);
    }
    var ans = [oldArrayColor, newArrayColor];
    return ans;
  } else {
    for (var j = 0; j < newValueArray.length; j++) {
      giveSpecifyColor(newValueArray[j], 'green', j, newArrayColor);
    }
    var ans = [oldArrayColor, newArrayColor];
    return ans;
  }
}

function isSameObject(object1: any, object2: any): any {
  if (Object.keys(object1).length !== Object.keys(object2).length) {
    return false;
  }
  for (let key of Object.keys(object1)) {
    if (key === 'color') continue;
    if (key in object2) {
      if (object1[key] !== object2[key]) {
        return false;
      }
    } else {
      return false;
    }
  }
  return true;
}
function findMatch(object1: any, object2: any): any {
  var count = 0;
  for (let key of Object.keys(object1)) {
    if (key === 'color') continue;
    if (key in object2) {
      if (object1[key] === object2[key]) {
        count++;
      }
    }
  }
  return count;
}
function giveColorOnChangeFields(
  object1: { [key: string]: any },
  object2: { [key: string]: any },
  index: any,
  oldArrayColor: any,
  color: any
) {
  for (let key of Object.keys(object1)) {
    if (key in object2) {
      if (object1[key] !== object2[key]) {
        oldArrayColor[key][index] = color;
      }
    }
  }
  for (let key of Object.keys(object2)) {
    if (key in object1) {
      if (object1[key] !== object2[key]) {
        oldArrayColor[key][index] = color;
      }
    }
  }
}
function giveSpecifyColor(
  object: { [key: string]: any },
  color: string,
  index: any,
  oldArrayColor: any
) {
  if (object) {
    for (let key of Object.keys(object)) {
      if (key) {
        oldArrayColor[key][index] = color;
      }
    }
  }
}

export { colorGroupingByHistoryChange };
