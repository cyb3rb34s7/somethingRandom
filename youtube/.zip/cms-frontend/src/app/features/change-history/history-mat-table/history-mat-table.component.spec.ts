import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoryMatTableComponent } from './history-mat-table.component';

describe('HistoryMatTableComponent', () => {
  let component: HistoryMatTableComponent;
  let fixture: ComponentFixture<HistoryMatTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HistoryMatTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HistoryMatTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
