import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { JsonPipe, NgClass } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  DestroyRef,
  ElementRef,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
  MatPaginator,
  MatPaginatorIntl,
  MatPaginatorModule,
} from '@angular/material/paginator';
import {
  MatSlideToggle,
  MatSlideToggleModule,
} from '@angular/material/slide-toggle';
import { MatSort, MatSortModule, Sort } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { plainToInstance } from 'class-transformer';
import { prepareExpandedRowsForDevStatusHistory } from '../../../components/dev-console/dev-helper';
import { ICONS_CONSTS } from '../../../constants/icons-consts';
import { STORE_CONSTS } from '../../../constants/store-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import { EllipsesDirective } from '../../../mat-components/app-mat-table/ellipses.directive';
import { ResizeColumnDirective } from '../../../mat-components/app-mat-table/resizable-column.directive';
import { SafeHtmlPipe } from '../../../mat-components/app-mat-table/safe-html-pipe';
import { StatusHistoryChange } from '../../../models/asset-status-history';
import { DevStatusHistoryModel } from '../../../models/dev-status-history';
import { LicenseHistoryChange } from '../../../models/license-history-model';
import { User } from '../../../models/user-model';
import { TimezoneFormatPipe } from '../../../pipes/timezone-format.pipe';
import { AssetStatusHistoryService } from '../../../services/asset-status-history.service';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { DevConsoleService } from '../../../services/dev-console.service';
import { LicenseService } from '../../../services/license.service';
import { MetadataHistoryService } from '../../../services/metadata-history.service';
import { StateStoreService } from '../../../services/store/state-store.service';
import { UserService } from '../../../services/user.service';
import {
  prepareExpandedRowsForLicense,
  prepareExpandedRowsForStatus,
} from '../_helper';

@Component({
    selector: 'app-history-mat-table',
    animations: [
        trigger('detailExpand', [
            state('collapsed,void', style({ height: '0px', minHeight: '0' })),
            state('expanded', style({ height: '*' })),
            transition('expanded <=> collapsed', animate('0ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ],
    imports: [
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatCheckboxModule,
        MatTooltipModule,
        NgClass,
        EllipsesDirective,
        MatSlideToggleModule,
        SafeHtmlPipe,
        MatButtonModule,
        TimezoneFormatPipe,
    ],
    templateUrl: './history-mat-table.component.html',
    styleUrl: './history-mat-table.component.scss'
})
export class HistoryMatTableComponent implements OnChanges {
  @ViewChild('target', { read: ElementRef }) target: ElementRef;

  @Input() tableData: any[];

  @Input() imageData: { fileName: string; alt: string; msg: string };

  @Input() isPaginated: boolean;

  @Input() supportRowExpansion: boolean;

  @Input() keepExpansion: boolean;

  @Output() actionIconClicked: EventEmitter<{ icon: string; data: any }> =
    new EventEmitter();

  @Output() paginationEvent: EventEmitter<any> = new EventEmitter();

  @Output() sortingEvent: EventEmitter<any> = new EventEmitter();
  @Output() loadMore: EventEmitter<any> = new EventEmitter();
  @Input() sourceTab: string;

  @ViewChild(MatSort, { static: false })
  set sort(value: MatSort) {
    if (this.dataSource) {
      this.dataSource.sort = value;
    }
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;

  duration: number = 0;

  expandedRows: any[] = [];

  dataSource: MatTableDataSource<any>;

  displayedColumns: string[];

  columnNamesToDisplay: any;

  selectedRows: any = [];

  pageSizeOptions = TABLE_CONSTS.PAGE_SIZE_OPTIONS;

  currentTableData: any[] = [];

  lastPageSize: number = this.pageSizeOptions[0];

  lastPageIndex: number = 0;

  TC = TABLE_CONSTS;

  columnWidth: number;

  loggedInUser: User;

  iconToolTipMsg: { [key: string]: string } = {
    'bi-pencil': 'Edit',
    'bi-person-plus': 'Assign Role',
    'bi-eye': 'View',
    'bi-trash': 'Delete',
    'bi-ban': 'Cannot Edit Self',
  };

  iconColor: { [key: string]: string } = {
    'bi-pencil': '#3136D1',
    'bi-person-plus': '#3136D1',
    'bi-eye': '#555766',
    'bi-trash': '#F22525',
    'bi-ban': '#A0AAB7',
  };

  _tableDataCopy: any;

  totalCount: number;

  $scrollRef: HTMLElement | null;

  $clone: HTMLElement | null;

  private _overrideTotalCount: number;
  @Input() set overrideTotalCount(value: any) {
    this._overrideTotalCount = parseInt(value, 10);
  }

  get overrideTotalCount(): number {
    return this._overrideTotalCount;
  }

  private destroy = inject(DestroyRef);
  private currExpandedRow: any;

  constructor(
    private userService: UserService,
    private toastr: CustomToastrService,
    private storeService: StateStoreService,
    private metaService: MetadataHistoryService,
    private statusService: AssetStatusHistoryService,
    private elementRef: ElementRef,
    private devconsoleService: DevConsoleService,
    private licenseService: LicenseService
  ) {}

  ngAfterViewInit() {
    // this.setSorting();
    this.setPaginator();
  }

  ngOnInit() {
    this.dataSource = this.isPaginated
      ? new MatTableDataSource(this.currentTableData)
      : new MatTableDataSource(this.tableData);
    this.setDisplayColumns();
    // this.setSorting();
    this.setPaginator();

    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((user: User) => {
        this.loggedInUser = user;
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.tableData && this.tableData.length) {
      this.resetExpansionScroll();
      this._tableDataCopy = this.tableData.slice();
      const tblDtaChgs = changes['tableData'];
      const condition =
        JSON.stringify(tblDtaChgs.currentValue) !==
        JSON.stringify(tblDtaChgs.previousValue);

      if (condition) {
        // this.lastPageIndex = 0;
        if (this.paginator) {
          // this.paginator.pageIndex = 0;
        }

        // this.paginator.pageSize
        this.dataSource = this.isPaginated
          ? new MatTableDataSource(this.currentTableData)
          : new MatTableDataSource(this.tableData);

        this.selectedRows = [];

        this.setDisplayColumns();
        // this.setSorting();
        this.setPaginator();
        setTimeout(() => {
          this.target?.nativeElement
            .querySelectorAll('.expanded-row .bi-plus-square')
            .forEach((el: HTMLElement, i: number) => {
              if (this.keepExpansion) {
                setTimeout(() => {
                  el.click();
                }, 10 * (i + 1));
              }
            });
        }, 0);
      }
    }
  }

  // setSorting() {
  //   if (this.dataSource && this.sort) {
  //     this.dataSource.sort = this.sort;
  //   }
  // }

  sortData(sort: Sort) {
    this.sortingEvent.emit(sort);
    if (!sort.active || sort.direction === '') {
      this.tableData = this._tableDataCopy.slice();
    } else {
      this.tableData = this.tableData.sort((a, b) => {
        const isAsc = sort.direction === 'asc';
        return this.compare(a[sort.active], b[sort.active], isAsc);
      });
    }

    this.handlePagination({
      pageSize: this.lastPageSize,
      pageIndex: this.lastPageIndex,
    });
  }

  compare(a: string, b: string, isAsc: boolean) {
    if (a === null) {
      return -1 * (isAsc ? 1 : -1);
    }
    if (b === null) {
      return 1 * (isAsc ? 1 : -1);
    }

    if (isNaN(parseInt(a)) && isNaN(parseInt(b))) {
      let ret = 0;
      if (a.toLowerCase() < b.toLowerCase()) ret = -1;
      if (a.toLowerCase() > b.toLowerCase()) ret = 1;

      return ret * (isAsc ? 1 : -1);
    }

    return (parseInt(a) < parseInt(b) ? -1 : 1) * (isAsc ? 1 : -1);
  }

  setPaginator() {
    // console.log('setPaginator : ', this.dataSource, this.paginator);
    if (this.dataSource && this.paginator) {
      this.paginator._intl = new MatPaginatorIntl();
      this.paginator._intl.itemsPerPageLabel =
        TABLE_CONSTS.ITEMS_PER_PAGE_LABEL;

      this.handlePagination({
        pageSize: this.lastPageSize,
        pageIndex: this.lastPageIndex,
      });
    }
  }

  setDisplayColumns() {
    if (this.tableData && this.tableData.length) {
      this.displayedColumns = this.tableData.length
        ? Object.keys(this.tableData[0])
        : [];
      this.columnNamesToDisplay = {};
      this.displayedColumns.forEach((c) => {
        this.columnNamesToDisplay[c] = this.tableData[0][c]?.headerText
          ? this.tableData[0][c]?.headerText
          : c;
      });
    }
  }

  handleActionIconClick(icon: string, data: any) {
    if (icon !== ICONS_CONSTS.BUTTON_NOT_ALLOWED) {
      this.actionIconClicked.emit({ icon, data });
    }
  }

  resetExpansionScroll() {
    if (this.$clone) {
      this.$clone.remove();
      this.$clone = null;
    }
    if (this.$scrollRef) {
      this.$scrollRef
        .querySelector('.trim-body')
        ?.classList.remove('trim-body');
    }
  }

  removefromExpandedRows(row: any) {
    this.expandedRows = this.expandedRows.filter((r: any) => r !== row);

    this.resetExpansionScroll();
  }

  addExpandedRows(row: any) {
    this.currExpandedRow = row;
    if (this.sourceTab === 'statusHistory') {
      this.fetchStatusHistoryChanges(row);
      return;
    } else if (this.sourceTab === 'devStatusHistory') {
      this.fetchDevStatusHistory(row);
      return;
    } else if (this.sourceTab === 'licenseHistory') {
      this.fetchLicenseHistoryChanges(row);
      return;
    }

    this.resetExpansionScroll();
    const foundIndex = this.expandedRows.findIndex(
      (r: any) => r[this.TC.NO_RENDER_COLUMN] == row[this.TC.NO_RENDER_COLUMN]
    );
    if (foundIndex > -1) {
      this.expandedRows[foundIndex] = row;
    } else {
      if (this.keepExpansion) {
        this.expandedRows.push(row);
      } else {
        this.expandedRows = [row];
      }
    }
  }

  checkInExpandedRows(row: any) {
    const foundIndex = this.expandedRows.findIndex(
      (r: any) => r[this.TC.NO_RENDER_COLUMN] == row[this.TC.NO_RENDER_COLUMN]
    );

    return foundIndex > -1;
  }

  selectDeselectAll() {
    if (this.selectedRows.length === this.dataSource.data.length) {
      this.selectedRows = [];
    } else if (this.selectedRows.length < this.dataSource.data.length) {
      this.selectedRows = this.dataSource.data.map((d) => d);
    }
    this.handleActionIconClick(this.TC.RENDER_CHECKBOX_COLUMN, [
      ...this.selectedRows,
    ]);
  }

  deselectAllCheckbox() {
    this.selectedRows = [];
  }

  selectDeselectRow(row: any) {
    const found = this.selectedRows.find(
      (r: any) => r[this.TC.NO_RENDER_COLUMN] === row[this.TC.NO_RENDER_COLUMN]
    );
    if (found) {
      this.selectedRows = this.selectedRows.filter(
        (r: any) =>
          r[this.TC.NO_RENDER_COLUMN] !== row[this.TC.NO_RENDER_COLUMN]
      );
    } else {
      this.selectedRows = [...this.selectedRows, row];
    }
    this.handleActionIconClick(this.TC.RENDER_CHECKBOX_COLUMN, [
      ...this.selectedRows,
    ]);
  }

  isSelectedRow(row: any) {
    return this.selectedRows.find(
      (r: any) => r[this.TC.NO_RENDER_COLUMN] === row[this.TC.NO_RENDER_COLUMN]
    );
  }

  handlePagination(e: any) {
    console.log('handlePagination');
    this.removefromExpandedRows(this.currExpandedRow);
    const data = [...this.tableData];
    this.paginationEvent.emit(e);
    this.lastPageSize = e.pageSize;
    this.lastPageIndex = e.pageIndex;
    this.currentTableData = data.slice(
      e.pageIndex * e.pageSize,
      e.pageIndex * e.pageSize + e.pageSize
    );
    this.checkLoadMore();
    setTimeout(() => {
      this.dataSource.data = this.currentTableData;
    }, 100);
  }
  checkLoadMore() {
    const nextData = this.tableData.slice(
      this.lastPageSize * (this.lastPageIndex + 1),
      this.lastPageSize * (this.lastPageIndex + 2)
    );
    if (nextData.length < this.lastPageSize) {
      this.loadMore.emit();
    }
  }

  setCurrentPage(page: number) {
    if (this.paginator) {
      this.paginator.pageIndex = page;
    }
  }

  onImsAdminChange(ref: MatSlideToggle, user: User) {
    this.userService
      .updateImsSuperAdmin(user.userId, !user.superAdmin ? 'Y' : 'N')
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.toastr.success(res.message);
        ref.toggle();
      });
  }
  isHtml(str: string): boolean {
    const doc = new DOMParser().parseFromString(str, 'text/html');
    return Array.from(doc.body.childNodes).some((node) => node.nodeType === 1);
  }
  isTextTruncated(element: HTMLElement): boolean {
    return element.scrollWidth > element.clientWidth;
  }

  handleScroll(e: Event) {
    this.$scrollRef = e.target as HTMLElement;
    if (this.$scrollRef) {
      const $triggerRow = this.$scrollRef.querySelector(
        '.expanded-details'
      ) as HTMLElement;
      const $detail = this.$scrollRef.querySelector(
        '.expanded-details + tr '
      ) as HTMLElement;

      if (this.$clone) {
        if (
          this.$scrollRef.scrollTop >=
          this.$clone.offsetTop + this.$clone.offsetHeight
        ) {
          $detail.classList.remove('trim-body');
          $triggerRow.classList.add('no-sticky');
          // this.$scrollRef.scrollTop = this.$scrollRef.scrollTop + 52;
        } else {
          $detail.classList.add('trim-body');
          $triggerRow.classList.remove('no-sticky');
        }
      }

      if ($detail && !this.$clone) {
        this.$clone = $detail.cloneNode(true) as HTMLElement;
        $detail.classList.add('trim-body');
        this.$clone.classList.add('trim-header');
        $detail.insertAdjacentElement('afterend', this.$clone);
      }
    }
  }

  fetchStatusHistoryChanges(row: any) {
    var temp: StatusHistoryChange[] = [];
    this.statusService
      .getStatusHistoryById(row['Program ID'])
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          temp = plainToInstance<StatusHistoryChange, []>(
            StatusHistoryChange,
            res
          );

          row['DETAILS'] = prepareExpandedRowsForStatus(temp);
          this.resetExpansionScroll();
          const foundIndex = this.expandedRows.findIndex(
            (r: any) =>
              r[this.TC.NO_RENDER_COLUMN] == row[this.TC.NO_RENDER_COLUMN]
          );
          if (foundIndex > -1) {
            this.expandedRows[foundIndex] = row;
          } else {
            if (this.keepExpansion) {
              this.expandedRows.push(row);
            } else {
              this.expandedRows = [row];
            }
          }
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }
  fetchLicenseHistoryChanges(row: any) {
    var temp: LicenseHistoryChange[] = [];
    this.licenseService
      .getAllLicenseHistoryById(row['Program ID'])
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          temp = plainToInstance<LicenseHistoryChange, []>(
            LicenseHistoryChange,
            res.data
          );

          row['DETAILS'] = prepareExpandedRowsForLicense(temp, '');
          this.resetExpansionScroll();
          const foundIndex = this.expandedRows.findIndex(
            (r: any) =>
              r[this.TC.NO_RENDER_COLUMN] == row[this.TC.NO_RENDER_COLUMN]
          );
          if (foundIndex > -1) {
            this.expandedRows[foundIndex] = row;
          } else {
            if (this.keepExpansion) {
              this.expandedRows.push(row);
            } else {
              this.expandedRows = [row];
            }
          }
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }

  fetchDevStatusHistory(row: any) {
    var temp: DevStatusHistoryModel[] = [];

    this.devconsoleService
      .assetStatusHistoryByAssetId(row['Program Id'])
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          temp = plainToInstance<DevStatusHistoryModel, []>(
            DevStatusHistoryModel,
            res
          );

          row['DETAILS'] = prepareExpandedRowsForDevStatusHistory(temp);
          this.resetExpansionScroll();
          const foundIndex = this.expandedRows.findIndex(
            (r: any) =>
              r[this.TC.NO_RENDER_COLUMN] == row[this.TC.NO_RENDER_COLUMN]
          );
          if (foundIndex > -1) {
            this.expandedRows[foundIndex] = row;
          } else {
            if (this.keepExpansion) {
              this.expandedRows.push(row);
            } else {
              this.expandedRows = [row];
            }
          }
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }
}
