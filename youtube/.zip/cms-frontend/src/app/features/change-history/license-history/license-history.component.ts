import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, Input, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { plainToInstance } from 'class-transformer';
import { HISTORY_CONSTS } from '../../../constants/history-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../mat-components/app-mat-select/app-mat-select.component';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import {
  FilterRequestBody,
  LicenseFilterModel,
} from '../../../models/license-filter-model';
import {
  License,
  LicenseHistoryChange,
} from '../../../models/license-history-model';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { LicenseService } from '../../../services/license.service';
import { StateStoreService } from '../../../services/store/state-store.service';
import {
  downloadFile,
  fetchLicenseWindowDot,
  prepareExpandedRowsForLicense,
} from '../_helper';
import { FilterModalComponent } from '../filter-modal/filter-modal.component';
import { HistoryMatTableComponent } from '../history-mat-table/history-mat-table.component';

@Component({
    selector: 'app-license-history',
    imports: [
        AppMatTableComponent,
        AppMatSimpleSearchComponent,
        FilterModalComponent,
        MatIconModule,
        MatCardModule,
        MatButtonModule,
        MatTooltip,
        HistoryMatTableComponent,
    ],
    templateUrl: './license-history.component.html',
    styleUrl: './license-history.component.scss'
})
export class LicenseHistoryComponent {
  private destroy = inject(DestroyRef);
  @Input() assetId: string | null = null;
  @Input() vodType: string | null = null;

  LicenseHistoryData: License[];
  tableData: any[];
  expandedTableData: any[] = [];
  LicenseFiltersAll: { [key: string]: string[] } = {};
  filterBody: FilterRequestBody = {
    filters: [],
    pagination: {
      limit: 1000,
      offset: 0,
    },
    sortBy: {
      field: 'latestchangedatetime',
      order: 'DESC',
    },
  };
  appliedFilterCount: any;
  searchText: string = HISTORY_CONSTS.EMPTY_STRING;
  noMoreDataAvailable: boolean = false;
  offsetIndex: any = 0;
  licenseHistoryCount: number;
  totalRecordsOriginal: number;

  constructor(
    public dialog: MatDialog,
    public licenseService: LicenseService,
    private storeService: StateStoreService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {
    this.fetchFilters();

    if (this.assetId) {
      this.fetchLicenseById(this.assetId);
    } else {
      this.fetchLicense();
    }
  }

  @ViewChild(FilterModalComponent) filterSidebar: FilterModalComponent;
  @ViewChild(HistoryMatTableComponent) historyTable: HistoryMatTableComponent;

  openFilterSidebar() {
    this.filterSidebar.open();
  }

  onSidebarClosed() {}

  fetchFilters() {
    this.licenseService
      .getAllFilters()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.LicenseFiltersAll = res;
      });
  }
  onLoadMore(e: any) {
    if (!this.searchText && !this.noMoreDataAvailable) {
      if (this.filterBody.pagination?.offset != null) {
        this.offsetIndex++;
        this.filterBody.pagination.offset = this.offsetIndex * 1000;
      }
      this.fetchLicense();
    }
  }
  fetchLicense(isRefresh: boolean = false) {
    const observable = this.assetId
      ? this.licenseService.getAllLicenseHistoryById(this.assetId)
      : this.licenseService.getAllLicenseHistory(this.filterBody);

    observable.pipe(takeUntilDestroyed(this.destroy)).subscribe({
      next: (res) => {
        if (isRefresh) {
          this.LicenseHistoryData.splice(this.offsetIndex * 1000);
          this.LicenseHistoryData = this.LicenseHistoryData.concat(
            plainToInstance<License, []>(License, res.data)
          );
        } else if (this.filterBody.pagination?.offset === 0) {
          this.LicenseHistoryData = plainToInstance<License, []>(
            License,
            res.data
          );
        } else {
          this.LicenseHistoryData = this.LicenseHistoryData.concat(
            plainToInstance<License, []>(License, res.data)
          );
        }
        if (res.data.length < 1000) {
          this.noMoreDataAvailable = true;
        } else {
          this.noMoreDataAvailable = false;
        }
        this.licenseHistoryCount = res.count;
        this.totalRecordsOriginal = res.count;

        this.prepareTableData(this.LicenseHistoryData);
        this.handleSearch(this.searchText);
      },
      error: (error: HttpErrorResponse) => {
        console.log('====Error===', error);
      },
    });
  }
  fetchLicenseById(id: string) {
    this.licenseService
      .getAllLicenseHistoryById(id)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          const licenseHistoryChanges: any[] = plainToInstance<
            LicenseHistoryChange,
            []
          >(LicenseHistoryChange, res.data);
          this.expandedTableData = prepareExpandedRowsForLicense(
            licenseHistoryChanges,
            this.vodType ?? ''
          );
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }

  prepareTableData(licenseHistory: License[]) {
    this.tableData = licenseHistory.map((objLicense: License) => {
      const obj: any = {};
      obj[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS] = [];
      obj['CP Name'] = objLicense.contentPartner;
      obj['Tech Integrator'] = objLicense.tiName;
      obj['Program ID'] = objLicense.assetId;
      obj['Program Title'] = objLicense.mediaTitle;
      obj['License Type'] = objLicense.type;
      obj['License Start Date (UTC)'] = objLicense.currentReleaseDate
        ?.replace('T', ' ')
        ?.replace('Z', '');
      obj['License End Date (UTC)'] = objLicense.currentExpiryDate
        ?.replace('T', ' ')
        ?.replace('Z', '');

      obj['License Status'] = [
        fetchLicenseWindowDot(objLicense.currentStatus),
        '',
        objLicense.currentStatus,
      ];

      return obj;
    });
  }

  handleSearch(value: string) {
    this.searchText = value;
    if (value) {
      const data = this.LicenseHistoryData.filter((d) => {
        const searchIn = (d.tiName + d.mediaTitle + d.assetId).toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
      if (this.historyTable?.paginator) {
        this.historyTable.paginator.firstPage();
      }
      this.licenseHistoryCount = data.length;
    } else {
      this.prepareTableData(this.LicenseHistoryData);
      this.licenseHistoryCount = this.totalRecordsOriginal;
    }
  }
  onFiltersApply(filters: LicenseFilterModel[]) {
    this.offsetIndex = 0;
    this.filterBody = {
      filters: filters,
      pagination: {
        limit: 1000,
        offset: 0,
      },
    };
    if (this.historyTable?.paginator) {
      this.historyTable.paginator.firstPage();
    }
    this.fetchLicense();
  }
  onFiltersReset() {}
  handleLicenseHistoryExport() {
    const exportfilterBody: FilterRequestBody = {
      filters: this.filterBody.filters,
      pagination: {
        limit: HISTORY_CONSTS.EXPORT_EXCEL_COUNT,
        offset: 0,
      },
      sortBy: {
        field: 'latestChangeDateTime',
        order: 'DESC',
      },
    };

    this.licenseService
      .exportLicenseHistoryToExcel(exportfilterBody)
      .subscribe((res) => {
        downloadFile(res, 'LicenseHistory');
        this.toastr.success('Data is exported Successfully!');
      });
  }
}
