import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { plainToInstance } from 'class-transformer';
import { DOTS_CONSTS } from '../../../constants/color-dots-consts';
import { TABLE_CONSTS } from '../../../constants/table-consts';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { AppMatTableComponent } from '../../../mat-components/app-mat-table/app-mat-table.component';
import {
  FilterRequestBody,
  LicenseFilterModel,
} from '../../../models/license-filter-model';
import { UserHistory, UserHistoryChanges } from '../../../models/user-history';
import { UserHistoryService } from '../../../services/user-history.service';
import { ColumnMap } from '../_helper';
import { FilterModalComponent } from '../filter-modal/filter-modal.component';

@Component({
    selector: 'app-user-history',
    imports: [
        AppMatTableComponent,
        MatIconModule,
        MatCardModule,
        MatButtonModule,
        AppMatSimpleSearchComponent,
        FilterModalComponent,
        MatTooltip,
    ],
    templateUrl: './user-history.component.html',
    styleUrl: './user-history.component.scss'
})
export class UserHistoryComponent {
  private destroy = inject(DestroyRef);

  UserHistoryData: UserHistory[] = [];

  tableData: any[];
  UserHistoryFiltersAll: { [key: string]: string[] } = {};
  filterBody: FilterRequestBody = {
    filters: [],
    sortBy: {
      field: 'changeDateTime',
      order: 'DESC',
    },
  };
  appliedFilterCount: any;
  constructor(public userHistoryService: UserHistoryService) {}

  ngOnInit() {
    this.fetchUserHistory();
    this.fetchUserFilters();
  }
  @ViewChild(FilterModalComponent) filterSidebar: FilterModalComponent;

  openFilterSidebar() {
    this.filterSidebar.open();
  }

  onSidebarClosed() {}

  fetchUserHistory() {
    this.userHistoryService
      .getAllUserHistory(this.filterBody)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          this.UserHistoryData = plainToInstance<UserHistory, []>(
            UserHistory,
            res
          );

          this.prepareTableData(this.UserHistoryData);
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }
  fetchUserFilters() {
    this.userHistoryService
      .getAllUserHistoryFilters()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.UserHistoryFiltersAll = res;
      });
  }

  onUserHistoryFiltersApply(filters: LicenseFilterModel[]) {
    this.filterBody.filters = filters;
    this.fetchUserHistory();
  }
  onFiltersReset() {}
  prepareTableData(userHistory: UserHistory[]) {
    this.tableData = userHistory.map((objUserHistory: UserHistory) => {
      const obj: any = {};

      obj[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS] = this.prepareExpandedRows(
        JSON.parse(objUserHistory.change)
      );
      obj['User Name'] = objUserHistory.userName;
      obj['Change Date'] = objUserHistory.changeDateTime;
      obj['Change Time'] = objUserHistory.changeDateTime;
      obj['Updated By'] = objUserHistory.updatedByName;
      obj['Current Role'] = objUserHistory.currentRole;
      obj[TABLE_CONSTS.RENDER_STATUS_COLUMN] = [
        objUserHistory.currentStatus === 'Active'
          ? DOTS_CONSTS.STATUS_DOT_ACTIVE
          : DOTS_CONSTS.STATUS_DOT_INACTIVE,
        '',
        objUserHistory.currentStatus,
      ];

      return obj;
    });
  }
  prepareExpandedRows(history: UserHistoryChanges[]) {
    const data: any[] = [];

    history.map((historyChange) => {
      const obj: any = {};

      obj['Field'] = ColumnMap[historyChange.field] || historyChange.field;
      obj['Old Value'] = historyChange.oldVal ?? '';
      obj['New Value'] = historyChange.newVal ?? '';

      data.push(obj);
    });
    return data;
  }

  handleSearch(value: String) {
    if (value) {
      const data = this.UserHistoryData.filter((d) => {
        const searchIn = d.userName.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
    } else {
      this.prepareTableData(this.UserHistoryData);
    }
  }
}
