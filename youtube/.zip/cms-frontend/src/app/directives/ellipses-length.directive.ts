import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';

@Directive({
  selector: '[appEllipsesLength]',
  standalone: true,
  providers: [MatTooltip],
})
export class EllipsesLengthDirective {
  @Input({ required: true })
  maxLength: number;

  originalText: string;
  truncatedText: string;

  constructor(
    private elementRef: ElementRef,
    private tooltip: MatTooltip,
  ) {}

  ngOnInit() {
    this.tooltip.position = 'above';
    this.getTruncatedText();
  }

  private getTruncatedText(): void {
    const element: HTMLElement = this.elementRef.nativeElement;
    this.originalText = element.innerText;

    if (this.originalText.length > this.maxLength) {
      this.truncatedText =
        element.innerText.substring(0, this.maxLength - 3) + '...';
    } else {
      this.truncatedText = this.originalText;
    }

    element.innerText = this.truncatedText;
  }

  @HostListener('mouseenter')
  onMouseEnter(): void {
    if (this.originalText.length > this.maxLength) {
      this.tooltip.message = this.originalText;
      this.tooltip.show();
    }
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.tooltip.hide();
  }
}
