import { EllipsesLengthDirective } from './ellipses-length.directive';

describe('EllipsesLengthDirective', () => {
  it('should create an instance', () => {
    const directive = new EllipsesLengthDirective();
    expect(directive).toBeTruthy();
  });
});
