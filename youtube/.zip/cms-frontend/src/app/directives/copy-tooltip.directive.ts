import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';

@Directive({
  selector: '[appCopyTooltip]',
  standalone: true,
  providers: [MatTooltip],
})
export class CopyTooltipDirective {
  constructor(private elementRef: ElementRef, private tooltip: MatTooltip) {}

  ngOnInit() {
    this.tooltip.position = 'above';
  }

  @HostListener('mouseenter')
  onMouseEnter(): void {
    this.tooltip.message = 'Copy';
    this.tooltip.show();
  }

  @HostListener('click')
  onMouseClick(): void {
    this.tooltip.message = 'Copied';
    this.tooltip.show();
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.tooltip.hide();
  }
}
