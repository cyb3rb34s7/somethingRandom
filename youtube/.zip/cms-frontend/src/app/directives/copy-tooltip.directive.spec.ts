import { CopyTooltipDirective } from './copy-tooltip.directive';

describe('CopyTooltipDirective', () => {
  it('should create an instance', () => {
    const directive = new CopyTooltipDirective();
    expect(directive).toBeTruthy();
  });
});
