export enum AssetTypes {
  EPISODE = 'EPISODE',
  MOVIE = 'MOVIE',
  SHOW = 'SHOW',
  SEASON = 'SEASON',
  SINGLEVOD = 'SINGLEVOD',
  MUSIC = 'MUSIC',
}
