export const STATUS_HTML = {
  ACTIVE: `<i class="bi bi-dot status-with-dot-green"></i>`,
  RELEASED: `<i class="bi bi-dot status-with-dot-cyan"></i>`,
  EXPIRED: `<i class="bi bi-dot status-with-dot-red"></i>`,
  QCREADY: `<i class="bi bi-dot status-with-dot-orange"></i>`,
  INPROGRESS: `<i class="bi bi-dot status-with-dot-yellow"></i>`,
  QCPASS: `<i class="bi bi-dot status-with-dot-cyan"></i>`,
  QCFAIL: `<i class="bi bi-dot status-with-dot-red"></i>`,
  TQCPASS: `<i class="bi bi-dot status-with-dot-green"></i>`,
  RELEASEREADY: `<i class="bi bi-dot status-with-dot-orange"></i>`,
  REVOKED: `<i class="bi bi-dot status-with-dot-black"></i>`,
  MISSING: `<i class="bi bi-exclamation-triangle status-with-dot-red"></i>`,
  UNTRACKABLE: `<i class="bi bi-dash-circle"></i>`,
};
