import { environment } from '../../environments/environment';

export const apis = {
  getUsers: 'admin/getUsers',
  getUserRoles: 'admin/mapUserToRole/get',
  updateImsSuperAdmin: 'admin/updateUserIMSAdmin',
  assignRoleAndStatusToUser: 'admin/mapUserToRole/updateOrAssignRoleOrStatus',
  createRoleAndAssignMultiple:
    'admin/mapUserToRole/createRoleAndAssignMultiple',
  updateRoleAndAssignMultiple: 'admin/mapUserToRole/upsertMultiple',
  getAssetView: 'admin/asset/view',
  getAssetViewPrd: 'admin/asset/view/prd',
  getAssets: 'admin/asset/list',
  getAssetsFilters: 'admin/asset/filters',
  getAssetsMasterPlatformData: 'admin/asset/platforms',
  getAssetsColumns: 'getAssetsColumns',
  getAssetsFilterTemplates: 'admin/user/template/get',
  upsertAssetsFilterTemplate: 'admin/user/template/upsert',
  deleteAssetsFilterTemplate: 'admin/user/template/delete?template_id=',
  exportAssets: 'admin/asset/export',
  bulkTemplateAssets: 'admin/asset/exportTemplate',

  getAllRolesAndAssignedUsers: 'admin/mapUserToRole/get',
  getAllRoles: 'admin/roles/getAll',

  getAllMenuApi: 'admin/dev/allApiAccessControl',
  getAllMenuList: 'admin/dev/allMenuList',
  updateApiInfo: 'admin/dev/updateApiAccessControl',
  creatNewApi: 'admin/dev/insertNewApiAccessControl',
  deleteApi: 'admin/dev/deleteApiAccessControl',

  allAssetStatusHistory: 'admin/dev/statusHistory/get',

  getMenuRoleAccess: 'admin/mapRoleToMenu/get/',
  deleteRoleById: 'admin/roles/delete?role_id=',
  deleteMultipleRoles: 'admin/roles/deleteMultiple',
  getLoggedInUserDetails: 'admin/user/userDetail',
  mapRoleToMenuAccess: 'admin/mapRoleToMenu/replace?role_id=',
  getAllMenus: 'admin/menu/getAll',
  approveUser: 'admin/userApproval',

  getAllTickets: 'ticket/all',
  getJiraLink: 'ticket/jiraLink',
  createTicket: 'ticket/create',
  updateTicket: 'ticket/update?ticketId=',

  updateSingleAsset: 'admin/asset/update',
  updateUserProfile: 'admin/user/updateUserProfile',
  getAllLicenseHistory: 'admin/history/license/get',
  getAllLicenseHistoryById: 'admin/history/license/get/asset',
  exportLicenseHistory: 'admin/history/license/export',

  updateAssetStatus: 'admin/asset/updateStatus',
  getCountries: 'admin/asset/countryCodes',
  getAllCountries: 'admin/asset/allCountryCodes',
  postFileData: 'admin/asset/uploadUpdates',
  getLicenseFilters: 'admin/history/license/filters',
  getMetaDataHistory: 'admin/history/metadata/get',
  getMetaDataHistoryById: 'admin/history/metadata/get/asset',
  getMetaDataFilters: 'admin/history/metadata/filters',
  exportMetadataHistory: 'admin/history/metadata/export',

  getAssetStatusHistory: 'admin/history/asset/status/get',
  exportAssetStatusHistory: 'admin/history/asset/status/export',

  getAssetStatusHistoryFilters: 'admin/history/asset/status/filters',

  getUserHistory: 'admin/history/user/get',
  getUserHistoryFilters: 'admin/history/user/filters',
  uploadImage: 'admin/asset/uploadImage',
  uploadSingleImage: 'admin/asset/uploadSingleImage',
  getVideoSegments: 'admin/asset/getVideoSegments',
  getShowHierarchy: 'admin/asset/getShowHierarchy',
  updateAssetByBulk: 'admin/asset/updateAssetByBulk',
  dashboard: 'admin/dashboard/list',
  getAssetsMasterLanguages: 'admin/asset/languages',
  getAssetViewEpisodeHierarchy: 'admin/asset/view/episode/hierarchy',
  getAssetsMasterData: 'admin/asset/view/filters',
  getAssetsMasterDataPrd: 'admin/asset/view/filters/prd',
  existingUpdates: 'admin/asset/existingUpdates',
  uploadUpdates: 'admin/asset/uploadUpdates',
  uploadAction: 'admin/asset/uploadAction?request=',
  getAssetsCounts: 'admin/asset/count?tab=', //all , prod , qc
  validateAssetDetails: 'admin/asset/validateAssetDetails',
  getAssetsHierarchy: 'admin/asset/bulkRevokeHierarchy',
  getStreamUriAddbreaks: 'admin/asset/view/streamUris',

  getAllVocabulary: 'help-support/vocab/get',
  insertVocabulary: 'help-support/vocab/insert',
  updateVocabulary: 'help-support/vocab/update',
  deleteVocabulary: 'help-support/vocab/delete',
  deleteVocabularyInBulk: 'help-support/vocab/delete/bulk',

  getCpData: 'admin/asset/view/cp',
  updateCPData: 'admin/asset/update/cp',
  getGracenoteData: 'admin/asset/view/gracenote',

  getInvalidAssets: 'admin/dev/invalid-assets',
  getInvalidLicenseAssets: 'admin/dev/invalid-license-window',
  getControlQueueUrls: 'admin/dev/controlQueueUrls',
  updateControlQueueUrl: 'admin/dev/updateControlQueue',
  insertControlQueueUrl: 'admin/dev/insertControlQueue',
  deleteControlQueueUrl: 'admin/dev/deleteControlQueue',

  getStaticJsonFromS3: 'admin/asset/get/static-json',
  getFIleFromS3: 'admin/asset/download/file',
  getFileWithS3Input: 'admin/asset/download/file/s3',

  getDeveloperEmail: 'admin/dev/getDevEmails',
  getTiData: 'admin/dev/getTiData',
  allocateTi: 'admin/dev/allocateTI',
  deallocateTi: 'admin/dev/deallocateTI',
  updateTiFeedworker: 'admin/dev/updateTiFeedworker',
  logoutUrl: 'admin/logout-redirect',

  getUserAssetPref: 'admin/user/assetPref',
  updateUserAssetPref: 'admin/user/updateAssetPref',

  getSmfFileName: 'admin/asset/get/smf-filename',

  getEvaluationAssets: 'admin/evaluation/comparison/program/list',
  getEvaluationFilters: 'admin/evaluation/comparison/filter/list',
  getEvaluationAssetDetails: 'admin/evaluation/comparison/detail',
  getEvaluationAssetsCount: 'admin/evaluation/comparison/count',
  exportEvaluationAssets: 'admin/evaluation/comparison/export',
};

export const jsonUrls = {
  MEDIA_ASSETS_COLUMNS_AND_FILTERS_STATIC_JSON_URL: environment.staticJson,

  MEDIA_ASSETS_COLUMNS_AND_FILTERS_STATIC_JSON_ASSET_URL:
    'assets/StaticDefaultContent.json?123',

  ASSETS_STATUS_MAPPING_STATIC_JSON_URL: 'assets/AssetsStatusMapping.json',

  ASSET_VALIDATOR_SCHEMA_STATIC_JSON_URL: 'assets/schemas/asset-schema.json',
  ASSET_STATIC_JSON_URL: 'assets/schemas/StaticAssetContent.json',
};
