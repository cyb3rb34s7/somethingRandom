import { MatSnackBarConfig } from '@angular/material/snack-bar';

export const SIDE_NAV_ROUTES = {
  DASHBOARD: {
    route_link: 'dashboard',
    title: 'Dashboard',
  },
  MEDIA: {
    route_link: 'media-assets',
    title: 'Media Assets',
  },
  MEDIA_DETAILED_VIEW: {
    route_link: 'media-assets/view-asset',
    title: 'View Assets',
  },
  IMPORTED_ASSETS: {
    route_link: 'media-assets/imported-assets',
    title: 'Media Assets',
  },
  HISTORY: {
    route_link: 'change-history',
    title: 'Change History',
  },
  LICENSE_HISTORY: {
    route_link: 'media-assets/change-history/license-history',
    title: 'Media Assets',
  },
  METADATA_HISTORY: {
    route_link: 'media-assets/change-history/metadata-history',
    title: 'Media Assets',
  },
  USER: {
    route_link: 'user-management',
    title: 'User Management',
  },
  HELP: {
    route_link: 'help-n-support',
    title: 'Help & Support',
  },
  BLANK: {
    route_link: '',
    title: '',
  },
  LOGOUT: {
    route_link: 'admin/logout-redirect',
    title: 'Logout',
  },
  USER_PROFILE: {
    route_link: 'user-management/user-profile',
    title: 'Profile',
  },
  CONSOLE1: {
    route_link: 'admin',
    title: 'Developer Console',
  },
  CONSOLE: {
    route_link: 'admin/console',
    title: 'Developer Console',
  },
  INVALID_ASSETS: {
    route_link: 'admin/console/invalid-assets',
    title: 'Invalid Assets',
  },
  INVALID_LICENSE_ASSETS: {
    route_link: 'admin/console/invalid-license-assets',
    title: 'Invalid License Assets',
  },
  TECH_INTEGRATOR_MANAGEMENT: {
    route_link: 'admin/console/tech-integrator',
    title: 'Tech Integrator Management',
  },
  UPDATE_MENU: {
    route_link: 'admin/console/api-access-control',
    title: 'Access Control Management',
  },
  CONTROL_QUEUE_URLS: {
    route_link: 'admin/console/control-queue-urls',
    title: 'Control Queue URLS',
  },
  ASSET_STATUS_HISTORY_CONSOLE: {
    route_link: 'admin/console/asset-status-history',
    title: 'Status History',
  },
  STG_PRD_ASSET_COMPARISON: {
    route_link: 'admin/console/stg-prd-asset-comparison',
    title: 'Asset Validator',
  },
  EVALUATION: {
    route_link: 'evaluation-assets',
    title: 'Evaluation Assets',
  },
  EVALUATION_DETAILED_VIEW: {
    route_link: 'evaluation-assets/view-asset',
    title: 'Evaluation Assets',
  },
};

export const LAYOUT_CONSTS = {
  PAGINATOR_MAX_VISIBLE_PAGE_COUNT: 5,
};

export const SNACKBAR_CONST = {
  horizontalPosition: 'end',
  verticalPosition: 'top',
  panelClass: ['custom-snackbar'],
} as MatSnackBarConfig;
