export const EVALUATION_CONSTS = {
  SEARCHABLE_FILTERS: ['programId', 'programTitle', 'externalProgramId'],
  EMPTY_STRING: '',
  HEADER: 'header',
  CP_PROVIDER_TITLE: 'CP Provider',
  GVD_TITLE: 'GVD',
  ON_TITLE: 'On',

  // FILTER
  PROGRAM_ID_FILTER_TEXT: 'programId',
  PROGRAM_TYPE_FILTER_TEXT: 'programType',
  PROGRAM_TITLE_FILTER_TEXT: 'programTitle',
  TMS_ID_FILTER_TEXT: 'externalProgramId',
  COVERAGE_FILTER_TEXT: 'coverageStatus',
  COMPARISON_FILTER_TEXT: 'comparisonStatus',
  FEED_WORKER_FILTER_TEXT: 'feedWorker',

  // HEADER
  PROGRAM_ID_HEADER_TEXT: 'Program ID',
  PROGRAM_TYPE_HEADER_TEXT: 'Program Type',
  PROGRAM_TITLE_HEADER_TEXT: 'Program Title',
  TMS_ID_HEADER_TEXT: 'External Program ID',
  COVERAGE_HEADER_TEXT: 'On Status',
  COMPARISON_HEADER_TEXT: 'GVD - On',
  ACTION_HEADER_TEXT: 'Action',
  FEED_WORKER_HEADER_TEXT: 'Source',

  NONE_HEADER_TEXT: 'Filter Name Not Found!'
};
