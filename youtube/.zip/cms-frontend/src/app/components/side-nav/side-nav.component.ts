import {
  Component,
  DestroyRef,
  ElementRef,
  HostBinding,
  HostListener,
  inject,
  ViewChild,
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { SIDE_NAV_ROUTES } from '.././../constants/app-consts';
import { NgClass } from '@angular/common';
import { StateStoreService } from '../../services/store/state-store.service';
import { STORE_CONSTS } from '../../constants/store-consts';
import { take } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-side-nav',
  imports: [RouterLink, RouterLinkActive, NgClass, MatTooltipModule],
  templateUrl: './side-nav.component.html',
  styleUrl: './side-nav.component.scss',
})
export class SideNavComponent {
  private destroy = inject(DestroyRef);
  @HostBinding('class.collapsed') expanded = false;
  routeConsts = SIDE_NAV_ROUTES;

  isSuperAdmin: boolean;

  appVersion: string;

  timeout: any;

  @HostListener('window:resize', ['$event'])
  onResize() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    this.timeout = setTimeout(() => {
      if (document.body.clientWidth < 1440) {
        this.expanded = true;
      } else {
        this.expanded = false;
      }
    }, 500);
  }

  constructor(private storeService: StateStoreService) {
    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        const user = this.storeService.getStoreState(STORE_CONSTS.CURRENT_USER);

        this.isSuperAdmin = user.superAdmin;

        this.appVersion = user.appVersion;
      });
  }

  ngOnInit() {
    if (document.body.clientWidth < 1440) {
      this.expanded = true;
    } else {
      this.expanded = false;
    }
  }
}
