import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import {
  Router,
  RouterOutlet,
  NavigationEnd,
  RouterLink,
} from '@angular/router';
import { Location } from '@angular/common';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { filter } from 'rxjs/internal/operators/filter';

@Component({
    selector: 'app-feature-container',
    imports: [RouterOutlet, MatCardModule],
    templateUrl: './feature-container.component.html',
    styleUrl: './feature-container.component.scss'
})
export class FeatureContainerComponent {}
