import { Component } from '@angular/core';

import {
  MatButtonToggleChange,
  MatButtonToggleModule,
} from '@angular/material/button-toggle';
import { StateStoreService } from '../../services/store/state-store.service';
import { STORE_CONSTS } from '../../constants/store-consts';

@Component({
    selector: 'app-region-selector',
    imports: [MatButtonToggleModule],
    templateUrl: './region-selector.component.html',
    styleUrl: './region-selector.component.scss'
})
export class RegionSelectorComponent {
  region: string;

  constructor(private storeService: StateStoreService) {}
  ngOnInit() {
    this.region = this.storeService.getStoreState(STORE_CONSTS.REGION);
  }

  regionChange(_change: MatButtonToggleChange) {
    sessionStorage.removeItem('allAssets');
    sessionStorage.removeItem('assetsInQC');
    sessionStorage.removeItem('assetsInProduction');
    sessionStorage.removeItem('assets-last-tab');
    this.storeService.setStoreState(STORE_CONSTS.REGION, _change.value);
    window.location.reload();
  }
}
