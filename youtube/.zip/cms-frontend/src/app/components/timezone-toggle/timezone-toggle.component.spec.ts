import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimezoneToggleComponent } from './timezone-toggle.component';

describe('TimezoneToggleComponent', () => {
  let component: TimezoneToggleComponent;
  let fixture: ComponentFixture<TimezoneToggleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TimezoneToggleComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TimezoneToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
