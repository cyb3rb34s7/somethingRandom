import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { StateStoreService } from '../../services/store/state-store.service';
import { STORE_CONSTS } from '../../constants/store-consts';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-timezone-toggle',
  imports: [MatMenuModule, MatButtonModule],
  templateUrl: './timezone-toggle.component.html',
  styleUrl: './timezone-toggle.component.scss',
})
export class TimezoneToggleComponent implements OnInit {
  private destroy = inject(DestroyRef);
  timeZone: string;
  localTimezone: string = STORE_CONSTS.LOCAL_TIMEZONE;
  utcTimezone: string = STORE_CONSTS.UTC_TIMEZONE;
  constructor(private storeService: StateStoreService) {
    this.storeService.stateStore[STORE_CONSTS.TIMEZONE]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(() => {
        this.timeZone = this.storeService.getStoreState(STORE_CONSTS.TIMEZONE);
      });
  }
  setTimeZone(val: string) {
    this.storeService.setStoreState(STORE_CONSTS.TIMEZONE, val);
  }

  ngOnInit(): void {}
}
