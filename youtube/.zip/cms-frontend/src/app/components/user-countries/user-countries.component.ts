import { Component } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { AppMatSelectComponent } from '../../mat-components/app-mat-select/app-mat-select.component';
import { AppMatSimpleSearchComponent } from '../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { plainToInstance } from 'class-transformer';
import { STORE_CONSTS } from '../../constants/store-consts';
import { Country } from '../../models/country-model';
import { User } from '../../models/user-model';
import { StateStoreService } from '../../services/store/state-store.service';
import { UserService } from '../../services/user.service';
import { FormsModule } from '@angular/forms';
import { count } from 'rxjs';

@Component({
    selector: 'app-user-countries',
    imports: [
        MatFormFieldModule,
        MatSelectModule,
        MatCheckbox,
        AppMatSimpleSearchComponent,
        FormsModule,
    ],
    templateUrl: './user-countries.component.html',
    styleUrl: './user-countries.component.scss'
})
export class UserCountriesComponent {
  masterCountries: any = [];
  userDetails: any;
  userPrefferedCountryCodes: any = [];
  userPrefferedCountries: any = [];
  countriesForFilter: Country[] = [];

  constructor(
    private userService: UserService,
    private storeService: StateStoreService
  ) {}

  ngOnInit() {
    this.getCountriesFromStore();
  }

  getCountriesFromStore() {
    const countries: Country[] = this.storeService.getStoreState(
      STORE_CONSTS.MASTER_COUNTRIES
    );
    if (countries.length !== 0) {
      this.masterCountries = countries;
      this.getUserData();
    } else {
      this.fetchCountries();
    }
  }

  fetchCountries() {
    this.userService.getCountries().subscribe((res: any) => {
      this.masterCountries = plainToInstance<Country, []>(Country, res);
      this.storeService.setStoreState(
        STORE_CONSTS.MASTER_COUNTRIES,
        plainToInstance<Country, {}>(Country, res)
      );
      this.getUserData();
    });
  }

  selectedCountries(event: any, country: Country) {
    if (event.checked) {
      let foundItem = this.countriesForFilter.find(
        (item) => item.countryCode == country.countryCode
      );
      if (!foundItem) {
        this.countriesForFilter.push(country);
        this.setStoreForFilterCountries();
      }
    } else {
      this.countriesForFilter = this.countriesForFilter.filter(
        (item) => item.countryCode !== country.countryCode
      );
      this.setStoreForFilterCountries();
    }
  }

  getUserData() {
    this.storeService.stateStore[STORE_CONSTS.CURRENT_USER].subscribe(
      (user: User) => {
        this.userDetails = user;
        console.log(user);
        this.userPrefferedCountryCodes = this.userDetails.prefCountryCodes;
        this.userPrefferedCountries = [];
        this.masterCountries.forEach((country: any) => {
          if (this.userPrefferedCountryCodes?.includes(country.countryCode)) {
            this.userPrefferedCountries.push(country);
          }
        });
        this.userPrefferedCountries.sort((a: any, b: any) =>
          a.countryName > b.countryName ? 1 : -1
        );
        this.setCountriesForFilters();
      }
    );
  }

  setCountriesForFilters() {
    this.countriesForFilter = [...this.userPrefferedCountries];
    this.setStoreForFilterCountries();
  }

  setStoreForFilterCountries() {
    this.storeService.setStoreState(
      STORE_CONSTS.COUNTRIES_FOR_FILTERS,
      plainToInstance<Country, {}>(Country, this.countriesForFilter)
    );
  }
  handleSearch(value: string) {
    console.log(value);

    if (value) {
      const filteredCountries = this.userPrefferedCountries.filter((val: any) =>
        val.countryName.toLowerCase().startsWith(value.toLowerCase())
      );
      this.userPrefferedCountries = filteredCountries;
    } else {
      this.userPrefferedCountries = [];
      this.getUserData();
    }
  }
}
