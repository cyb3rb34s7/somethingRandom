import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  inject,
  Input,
} from '@angular/core';
import { UserService } from '../../services/user.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { Location, NgClass } from '@angular/common';
import { AppMatInputComponent } from '../../mat-components/app-mat-input/app-mat-input.component';
import { MatRadioGroupComponent } from '../../mat-components/mat-radio-group/mat-radio-group.component';
import { MatLabel } from '@angular/material/form-field';
import { Country } from '../../models/country-model';
import { IMAGE_CONSTS } from '../../constants/image-consts';
import { MatChipsModule } from '@angular/material/chips';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { User } from '../../models/user-model';
import { StateStoreService } from '../../services/store/state-store.service';
import { STORE_CONSTS } from '../../constants/store-consts';
import { plainToInstance } from 'class-transformer';
import { CustomToastrService } from '../../services/custom-toastr.service';
import { AssetColumnsAndFiltersAndFilterTemplates } from '../../models/assets-columns-filters-model';
import { MatRadioModule } from '@angular/material/radio';
import { ICONS_CONSTS } from '../../constants/icons-consts';

@Component({
  selector: 'app-user-profile',
  imports: [
    MatButtonModule,
    AppMatInputComponent,
    MatRadioGroupComponent,
    MatLabel,
    MatChipsModule,
    MatSelectModule,
    FormsModule,
    MatRadioModule,
  ],
  templateUrl: './user-profile.component.html',
  styleUrl: './user-profile.component.scss'
})
export class UserProfileComponent {
  private destroy = inject(DestroyRef);

  userDetails: User;

  editMode: boolean;

  @Input() disabled: boolean;

  //masterCountries: Country[] = [];
  masterUSCountries: Country[] = [];
  masterEUCountries: Country[] = [];
  countries: Country[] = [];

  selectedCountryCodes: string[] = [];

  selectedAvatarUrl: string = '';

  prefRegion: string = 'US';

  regionOptions: string[] = ['US', 'EU'];

  searchCountry: string = '';

  filteredCountries: Country[] = [];

  IC = ICONS_CONSTS;

  optionImages: string[] = [
    IMAGE_CONSTS.AVATAR_1_IMAGE,
    IMAGE_CONSTS.AVATAR_2_IMAGE,
    IMAGE_CONSTS.AVATAR_3_IMAGE,
    IMAGE_CONSTS.AVATAR_4_IMAGE,
    IMAGE_CONSTS.AVATAR_5_IMAGE,
    IMAGE_CONSTS.AVATAR_6_IMAGE,
    IMAGE_CONSTS.AVATAR_7_IMAGE,
    IMAGE_CONSTS.AVATAR_8_IMAGE,
    IMAGE_CONSTS.AVATAR_9_IMAGE,
    IMAGE_CONSTS.AVATAR_10_IMAGE,
  ];

  userData: { key: string; value: string }[] = [
    { key: 'First Name', value: 'firstName' },
    { key: 'Last Name', value: 'lastName' },
    { key: 'Email', value: 'emailId' },
    { key: 'Role', value: 'roleName' },
  ];

  countryName(code: string) {
    return (
      this.countries.find((c) => c.countryCode === code)?.countryName || code
    );
  }

  constructor(
    private userService: UserService,
    private storeService: StateStoreService,
    private changeDetectorRef: ChangeDetectorRef,
    private toastr: CustomToastrService,
    private location: Location
  ) { }

  ngOnInit() {
    this.initializeUserData();
    this.userService
      .getAllCountries()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe(
        (res: any) => {
          this.masterEUCountries = plainToInstance<Country, []>(
            Country,
            res.euCountries
          );
          this.masterUSCountries = plainToInstance<Country, []>(
            Country,
            res.usCountries
          );
          this.getUserDetailsFromStore();
        },
        (err: any) => {
          this.getUserDetailsFromStore();
        }
      );
  }
  ngAfterViewChecked(): void {
    this.changeDetectorRef.detectChanges();
  }
  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
  }

  ///Added for search in dropdown
  filterCountries() {
    if (this.searchCountry.length > 0) {
      const selected = this.selectedCountryCodes.map((cd: string) => {
        return this.countries.find((c) => c.countryCode === cd);
      });
      this.filteredCountries = [
        ...selected,
        ...this.countries
          .filter(
            (c: Country) => !this.selectedCountryCodes.includes(c.countryCode)
          )
          .filter((d: Country) =>
            d.countryName
              .toLowerCase()
              .includes(this.searchCountry.toLowerCase())
          ),
      ] as Country[];
    } else {
      this.filteredCountries = this.countries;
    }
    return this.filteredCountries;
  }
  clearSearch() {
    this.searchCountry = '';
  }
  ///Added for search in dropdown

  initializeUserData() {
    this.userData = [
      { key: 'First Name', value: 'firstName' },
      { key: 'Last Name', value: 'lastName' },
      { key: 'Email', value: 'emailId' },
      { key: 'Role', value: 'roleName' },
    ];
  }

  sortAsPerOrder(arr: Country[], codes: string[]) {
    codes.forEach((cc: string) => {
      const found = arr.find((c) => c.countryCode === cc);
      if (found) {
        arr = [found, ...arr.filter((c) => c.countryCode !== cc)];
      }
    });
    return arr;
  }

  initializeUserDetails() {
    this.selectedAvatarUrl = this.userDetails.avatarUrl;
    this.initializeUserData();

    this.userData.map((ud) => {
      ud.value = (this.userDetails as any)[ud.value];
      return ud;
    });
    this.prefRegion = this.userDetails.prefRegion;
    this.countries =
      this.prefRegion === 'US'
        ? this.sortAsPerOrder(
          this.masterUSCountries,
          this.userDetails.orderedPrefUSCountryCodes
        )
        : this.sortAsPerOrder(
          this.masterEUCountries,
          this.userDetails.orderedPrefEUCountryCodes
        );
    this.setSelectedCountryCodes();
  }

  getUserDetailsFromStore() {
    const user: User = this.storeService.getStoreState(
      STORE_CONSTS.CURRENT_USER
    );

    if (user.userId) {
      this.userDetails = user;
      this.initializeUserDetails();
    } else {
      this.fetchUserData();
    }
  }

  fetchUserData() {
    this.userService.getUserDetails().subscribe((res: any) => {
      this.storeService.setStoreState(
        STORE_CONSTS.CURRENT_USER,
        plainToInstance<User, {}>(User, res.user)
      );

      this.userDetails = this.storeService.getStoreState(
        STORE_CONSTS.CURRENT_USER
      );
      this.initializeUserDetails();
    });
  }
  setSelectedCountryCodes() {
    this.selectedCountryCodes = [];
    this.selectedCountryCodes =
      this.prefRegion === 'US'
        ? [...this.userDetails.prefUSCountryCodes]
        : [...this.userDetails.prefEUCountryCodes];
  }
  setCountriesBasedonRegionChange() {
    //Resetting the search in dropdown when region is changed
    this.searchCountry = '';
    //Resetting the search in dropdown when region is changed
    this.countries =
      this.prefRegion === 'US'
        ? this.sortAsPerOrder(
          this.masterUSCountries,
          this.userDetails.orderedPrefUSCountryCodes
        )
        : this.sortAsPerOrder(
          this.masterEUCountries,
          this.userDetails.orderedPrefEUCountryCodes
        );
    this.setSelectedCountryCodes();
  }

  changeEditMode() {
    this.editMode = !this.editMode;
  }
  reset() {
    this.editMode = !this.editMode;
    this.getUserDetailsFromStore();
  }
  goBack() {
    this.location.back();
  }
  onStatusChange(avatarUrl: string) {
    this.selectedAvatarUrl = avatarUrl;
  }

  remove(countryCode: string) {
    this.selectedCountryCodes = this.selectedCountryCodes.filter(
      (c) => c !== countryCode
    );
  }
  saveChanges() {
    this.userService
      .updateCountryAndAvatar(
        this.selectedAvatarUrl,
        this.selectedCountryCodes,
        this.prefRegion
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        if (res) {
          const globalRegion = this.storeService.getStoreState(
            STORE_CONSTS.REGION
          );

          this.toastr.success(res.message);

          this.editMode = !this.editMode;
          const updatedUser = this.userDetails;
          updatedUser.avatarUrl = this.selectedAvatarUrl;
          updatedUser.prefRegion = this.prefRegion;

          if (
            this.prefRegion ===
            this.storeService.getStoreState(STORE_CONSTS.REGION)
          ) {
            updatedUser.prefCountryCodes = [...this.selectedCountryCodes];
          }

          if (this.prefRegion === 'US') {
            updatedUser.prefUSCountryCodes = [...this.selectedCountryCodes];
          }
          if (this.prefRegion === 'EU') {
            updatedUser.prefEUCountryCodes = [...this.selectedCountryCodes];
          }
          if (globalRegion === this.prefRegion) {
            const tmp: AssetColumnsAndFiltersAndFilterTemplates =
              this.storeService.getStoreState(
                STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES
              );

            tmp.filters.forEach((f) => {
              if (f.key === 'countryCode') {
                f.selected = this.selectedCountryCodes;
              }
            });
            this.storeService.setStoreState(
              STORE_CONSTS.ASSETS_COLUMNS_AND_FILTERS_AND_FILTER_TEMPLATES,
              tmp
            );
          }
          this.storeService.setStoreState(
            STORE_CONSTS.CURRENT_USER,
            updatedUser
          );
        }
      });
  }
}
