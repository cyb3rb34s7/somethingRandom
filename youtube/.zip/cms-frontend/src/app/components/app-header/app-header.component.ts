import { Component } from '@angular/core';
import { AvatarComponent } from '../avatar/avatar.component';
import { TitleComponent } from '../title/title.component';
import { ExcelExportProgressBarComponent } from '../../features/media-assets/excel-export-progress-bar/excel-export-progress-bar.component';

@Component({
  selector: 'app-header',
  imports: [AvatarComponent, TitleComponent, ExcelExportProgressBarComponent],
  templateUrl: './app-header.component.html',
  styleUrl: './app-header.component.scss',
})
export class AppHeaderComponent {}
