import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  inject,
  Inject,
} from '@angular/core';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogModule,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { DevConsoleService } from '../../../../../services/dev-console.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  ACTION_TYPES,
  HTTP_METHOD,
  updateApiAcessTypeData,
} from '../../../../../interfaces/dev-console-api-access-data-type';
import { MatRadioButton, MatRadioGroup } from '@angular/material/radio';
import { FormsModule } from '@angular/forms';
import { StateStoreService } from '../../../../../services/store/state-store.service';
import { User } from '../../../../../models/user-model';
import { STORE_CONSTS } from '../../../../../constants/store-consts';
import { plainToInstance } from 'class-transformer';
import { UserService } from '../../../../../services/user.service';

@Component({
    selector: 'app-api-edit-modal',
    imports: [
        AppMatInputComponent,
        MatDialogModule,
        MatButtonModule,
        MatDialogClose,
        MatButtonModule,
        FormsModule,
        AppMatInputComponent,
        MatRadioButton,
        MatRadioGroup,
        MatDialogContent,
        MatDialogTitle,
        MatDialogClose,
        MatDialogActions,
        MatDialogClose,
        MatButtonModule,
    ],
    templateUrl: './api-edit-modal.component.html',
    styleUrl: './api-edit-modal.component.scss'
})
export class ApiEditModalComponent {
  private destroy = inject(DestroyRef);
  user: any;
  menuData: updateApiAcessTypeData = {
    menuId: -1,
    menuName: '',
    actionType: ACTION_TYPES.READ,
    apiPath: '',
    httpMethod: HTTP_METHOD.GET,
    mdfrId: '',
    isDefault: false,
  };

  parentMenuData: updateApiAcessTypeData = {
    menuId: -1,
    menuName: '',
    actionType: ACTION_TYPES.READ,
    apiPath: '',
    httpMethod: HTTP_METHOD.GET,
    mdfrId: '',
    isDefault: false,
  };

  HTTP_METHOD: string[] = ['GET', 'POST', 'UPDATE', 'DELETE'];
  ACTION_TYPES: { title: string; value: string }[] = [
    { title: 'READ', value: ACTION_TYPES.READ },
    { title: 'WRITE', value: ACTION_TYPES.WRITE },
    { title: 'UPDATE', value: ACTION_TYPES.UPDATE },
    { title: 'DELETE', value: ACTION_TYPES.DELETE },
  ];
  IS_DEFAULT_YES_NO: { title: string; value: Boolean }[] = [
    { title: 'Yes', value: true },
    { title: 'No', value: false },
  ];
  disableState: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<ApiEditModalComponent>,
    private toastr: CustomToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private devConsoleService: DevConsoleService,
    private storeService: StateStoreService,
    private userService: UserService
  ) {
    this.menuData.menuId = this.data.data['Menu Id'];
    this.menuData.apiPath = this.data.data['Api Path'];
    this.menuData.actionType = this.data.data['Action Type'];
    this.menuData.httpMethod = this.data.data['Http Method'];
    this.menuData.menuName = this.data.data['Menu Name'];
    this.menuData.isDefault =
      this.data.data['Is Default'] === 'Yes' ? true : false;

    this.parentMenuData.menuId = this.data.data['Menu Id'];
    this.parentMenuData.apiPath = this.data.data['Api Path'];
    this.parentMenuData.actionType = this.data.data['Action Type'];
    this.parentMenuData.httpMethod = this.data.data['Http Method'];
    this.parentMenuData.menuName = this.data.data['Menu Name'];
    this.parentMenuData.isDefault =
      this.data.data['Is Default'] === 'Yes' ? true : false;
  }

  ngOnInit() {
    this.user = this.storeService.getStoreState(STORE_CONSTS.CURRENT_USER);
    if (!this.user.userId) {
      this.fetchUserData();
    }
    this.menuData.mdfrId = this.user.userId;
    this.parentMenuData.mdfrId = this.user.userId;
  }
  handleMenuName(inputString: string): void {
    if (inputString.length) {
      this.menuData.menuName = inputString;
    } else {
      this.menuData.menuName = '';
    }
  }

  handleApiPath(inputString: string): void {
    if (inputString.length) {
      this.menuData.apiPath = inputString;
    } else {
      this.menuData.apiPath = '';
    }
  }
  selectApiType(event: any) {
    this.menuData.httpMethod = event.value;
  }

  selectActionType(event: any) {
    this.menuData.actionType = event.value;
  }

  selectDefault(event: any) {
    this.menuData.isDefault = event;
  }

  isDisabled(): boolean {
    return (
      (this.menuData.actionType === this.parentMenuData.actionType &&
        this.menuData.httpMethod === this.parentMenuData.httpMethod &&
        this.menuData.menuName === this.parentMenuData.menuName &&
        this.menuData.apiPath === this.parentMenuData.apiPath &&
        this.menuData.isDefault === this.parentMenuData.isDefault) ||
      this.menuData.menuName === '' ||
      this.menuData.apiPath === ''
    );
  }

  editApiUrl() {
    if (
      this.menuData.actionType === this.parentMenuData.actionType &&
      this.menuData.httpMethod === this.parentMenuData.httpMethod &&
      this.menuData.menuName === this.parentMenuData?.menuName &&
      this.menuData.apiPath === this.parentMenuData?.apiPath &&
      this.menuData.isDefault === this.parentMenuData.isDefault
    ) {
      this.dialogRef.close({
        update: false,
      });
      return;
    }
    this.devConsoleService
      .updateApiUrl(this.menuData)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close({ update: true });
      });
  }

  fetchUserData() {
    this.userService
      .getUserDetails()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.storeService.setStoreState(
          STORE_CONSTS.CURRENT_USER,
          plainToInstance<User, {}>(User, res.user)
        );
        this.user = res.user;
      });
  }
}
