import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidLicenseAssetsDetailComponent } from './invalid-license-assets-detail.component';

describe('InvalidLicenseAssetsDetailComponent', () => {
  let component: InvalidLicenseAssetsDetailComponent;
  let fixture: ComponentFixture<InvalidLicenseAssetsDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvalidLicenseAssetsDetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InvalidLicenseAssetsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
