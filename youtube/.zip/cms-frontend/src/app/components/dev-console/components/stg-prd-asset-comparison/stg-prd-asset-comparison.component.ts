import { Component, DestroyRef, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { MatButton } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { SearchAssetModalComponent } from './search-asset-modal/search-asset-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { AvailablePlatform } from '../../../../models/asset-available-platform-model';
import {
  assetBasicInformation,
  assetDetailsSingleValues,
  assetSpecifications,
  assetViewTitle,
  genres,
  musicGenres,
  videoQualityList,
  licenseDetailSingleValues,
  ratingValues,
  castValues,
  licenseWindow,
  drmValues,
  externalProviderValues,
  imageFields,
  eventWindow,
} from '../../../../features/media-assets/assets-details/asset-constants/asset-fields-constants';
import { CurrentDataViewComponent } from '../../../../features/media-assets/assets-details/media-asset-complete-view/current-data-view/current-data-view.component';
import { AssetHelperService } from '../../../../features/media-assets/assets-details/media-asset-complete-view/utils/asset-helper.service';
import { NoComparisonAvailableComponent } from '../../../../features/media-assets/assets-details/media-asset-complete-view/no-comparison-available/no-comparison-available.component';
import { forkJoin } from 'rxjs';
import { AssetService } from '../../../../services/asset.service';
import { CustomToastrService } from '../../../../services/custom-toastr.service';
import { MismatchValue } from '../../../../models/asset-mismatch-model';
import { ShowChangesModalComponent } from './show-changes-modal/show-changes-modal.component';
import assetStaticJson from '../../../../../assets/schemas/StaticAssetContent.json';

@Component({
  selector: 'app-stg-prd-asset-comparison',
  imports: [
    MatButton,
    CurrentDataViewComponent,
    NoComparisonAvailableComponent,
  ],
  templateUrl: './stg-prd-asset-comparison.component.html',
  styleUrl: './stg-prd-asset-comparison.component.scss',
})
export class StgPrdAssetComparisonComponent {
  assetKey: {
    countryCode: String;
    contentId: String;
    cpId: String;
    type: String;
  } = {
    countryCode: '',
    contentId: '',
    cpId: '',
    type: '',
  };
  private destroy = inject(DestroyRef);
  noCompare: boolean = false;
  assetViewTitleStg: any = assetViewTitle;
  comparisionData: any;
  languageListStg: { text: string; code: string }[] = [];
  languageStg: string[] = [];
  parentalRatingsStg: any[] = [];
  assetsStg: any;
  vodAssetDtoStg: any = {};
  genresStg: string[] = [];
  videoQualityListStg = videoQualityList;
  availablePlatformStg: AvailablePlatform = {
    type: 'common',
    tvValues: [],
    tvItems: [],
    mobileItems: [],
    mobileValues: [],
    fHubItems: [],
    fHubValues: [],
    webItems: [],
    webValues: [],
  };

  assetViewTitlePrd: any = assetViewTitle;
  languageListPrd: { text: string; code: string }[] = [];
  languagePrd: string[] = [];
  parentalRatingsPrd: any[] = [];
  assetsPrd: any;
  vodAssetDtoPrd: any = {};
  genresPrd: string[] = [];
  videoQualityListPrd = videoQualityList;
  availablePlatformPrd: AvailablePlatform = {
    type: 'common',
    tvValues: [],
    tvItems: [],
    mobileItems: [],
    mobileValues: [],
    fHubItems: [],
    fHubValues: [],
    webItems: [],
    webValues: [],
  };
  readyToView: boolean = false;
  isResponseOk: boolean = false;
  overallChanges: String[] = [];

  assetBasicInformationChanges: MismatchValue[] = [];
  imageChanges: MismatchValue[] = [];
  assetDetailsChanges: any = {};
  assetSpecificationsChanges: MismatchValue[] = [];
  ratingChanges: any = {};
  drmDataChanges: any = {};
  licenseDetailsChanges: any = {};
  externalProviderChanges: any = {};
  castChanges: any = {};
  changesPltPrd: any;
  changesPltStg: any;
  availablePlatformChanges: any = {};

  assetMasterData: any;
  attributesList: string[] = [];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    public assetHelperService: AssetHelperService,
    private route: ActivatedRoute,

    private assetService: AssetService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {
    this.assetMasterData = { ...assetStaticJson };
    if (this.route.snapshot.queryParamMap.get('assetId') !== null) {
      (this.assetKey.contentId =
        this.route.snapshot.queryParamMap.get('assetId')!),
        (this.assetKey.countryCode =
          this.route.snapshot.queryParamMap.get('countryCode')!),
        (this.assetKey.cpId = this.route.snapshot.queryParamMap.get('cpId')!),
        (this.assetKey.type = this.route.snapshot.queryParamMap.get('type')!);
      this.getForkedData();
    } else this.openModal();
    //this.openModal();
    //this.detectChanges();
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  openModal() {
    this.noCompare = false;
    const dialogRef = this.dialog.open(SearchAssetModalComponent, {
      panelClass: 'create-role-modal',
      disableClose: true,
      data: {},
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        this.showData(result);
      });
  }

  getForkedData() {
    const payload = {
      contentId: this.assetKey.contentId,
      vcCpId: this.assetKey.cpId,
      countryCode: this.assetKey.countryCode,
      type: this.assetKey.type,
    };
    forkJoin({
      assetDataStg: this.assetService.getAssetDetailedView(
        this.assetKey.contentId,
        this.assetKey.cpId,
        this.assetKey.countryCode
      ),
      filterDataStg: this.assetService.getViewFilters(payload),
      assetDataPrd: this.assetService.getAssetDetailedViewPrd(
        this.assetKey.contentId,
        this.assetKey.cpId,
        this.assetKey.countryCode
      ),

      filterDataPrd: this.assetService.getViewFiltersPrd(payload),
    })
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (
          result.assetDataStg === null &&
          result.assetDataPrd === null &&
          result.filterDataStg === null &&
          result.filterDataPrd === null
        ) {
          this.toastr.error('Invalid Asset Details');
        } else {
          this.showData(result);
        }
      });
  }

  showData(result: any) {
    if (result.assetDataPrd === null || result.filterDataPrd === null) {
      this.noCompare = true;
    } else if (result.assetDataStg === null || result.filterDataStg === null) {
      this.noCompare = true;
    } else {
      this.readyToView = true;
      // this.isResponseOk = true;
      if (result.assetKey) {
        this.router.navigate(
          [SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.route_link],
          {
            queryParams: {
              assetId: result.assetKey.contentId,
              countryCode: result.assetKey.countryCode,
              cpId: result.assetKey.cpId,
              type: result.assetKey.type,
            },
          }
        );
      }
      this.comparisionData = result;
      this.assetsStg = this.comparisionData.assetDataStg;
      this.assetsPrd = this.comparisionData.assetDataPrd;
      this.attributesList = this.assetMasterData?.attributes;

      this.vodAssetDtoStg = JSON.parse(
        JSON.stringify(this.comparisionData.assetDataStg)
      );
      this.vodAssetDtoPrd = JSON.parse(
        JSON.stringify(this.comparisionData.assetDataPrd)
      );
      this.genresStg =
        this.assetsStg['type'] === 'MUSIC' ? musicGenres : genres;

      this.genresPrd =
        this.assetsPrd['type'] === 'MUSIC' ? musicGenres : genres;

      this.assetHelperService.intializeCastData(
        this.assetsStg,
        this.vodAssetDtoStg
      );
      this.assetHelperService.intializeCastData(
        this.assetsPrd,
        this.vodAssetDtoPrd
      );
      this.intializePlatformValues();
      this.intializeDropDownValues();
      this.isResponseOk = true;
      // this.readyToView = true;
    }
  }

  intializeDropDownValues() {
    this.languageListStg =
      this.comparisionData.filterDataStg['languages'] ?? [];
    this.languageStg = this.languageListStg.map((item) => item.text);

    this.languageListPrd =
      this.comparisionData.filterDataPrd['languages'] ?? [];
    this.languagePrd = this.languageListPrd.map((item) => item.text);

    this.comparisionData.filterDataStg['platforms']?.forEach(
      (item: { type: string; platform: string }) => {
        if (item.type === 'TV') {
          this.availablePlatformStg.tvItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'MOB') {
          this.availablePlatformStg.mobileItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'FHUB') {
          this.availablePlatformStg.fHubItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'WEB') {
          this.availablePlatformStg.webItems.push({
            platformName: item.platform,
          });
        }
      }
    );

    this.comparisionData.filterDataPrd['platforms']?.forEach(
      (item: { type: string; platform: string }) => {
        if (item.type === 'TV') {
          this.availablePlatformPrd.tvItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'MOB') {
          this.availablePlatformPrd.mobileItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'FHUB') {
          this.availablePlatformPrd.fHubItems.push({
            platformName: item.platform,
          });
        } else if (item.type === 'WEB') {
          this.availablePlatformPrd.webItems.push({
            platformName: item.platform,
          });
        }
      }
    );

    this.parentalRatingsStg =
      this.comparisionData.filterDataStg['parentalRatings'];
    this.parentalRatingsPrd =
      this.comparisionData.filterDataPrd['parentalRatings'];
    this.detectChanges();
  }

  intializePlatformValues() {
    this.availablePlatformStg = {
      type: 'common',
      tvValues: [],
      tvItems: [],
      mobileItems: [],
      mobileValues: [],
      fHubItems: [],
      fHubValues: [],
      webItems: [],
      webValues: [],
    };
    this.availablePlatformPrd = {
      type: 'common',
      tvValues: [],
      tvItems: [],
      mobileItems: [],
      mobileValues: [],
      fHubItems: [],
      fHubValues: [],
      webItems: [],
      webValues: [],
    };
    this.availablePlatformStg.type = this.assetsStg['platformTag'];
    this.availablePlatformPrd.type = this.assetsPrd['platformTag'];

    this.assetsStg['platformTagData']?.forEach(
      (item: { type: string; platform: string; alias: string }) => {
        if (item.type === 'TV') {
          this.availablePlatformStg.tvValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'MOB') {
          this.availablePlatformStg.mobileValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'FHUB') {
          this.availablePlatformStg.fHubValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'WEB') {
          this.availablePlatformStg.webValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        }
      }
    );
    this.assetsPrd['platformTagData']?.forEach(
      (item: { type: string; platform: string; alias: string }) => {
        if (item.type === 'TV') {
          this.availablePlatformPrd.tvValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'MOB') {
          this.availablePlatformPrd.mobileValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'FHUB') {
          this.availablePlatformPrd.fHubValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        } else if (item.type === 'WEB') {
          this.availablePlatformPrd.webValues.push({
            platformName: item.platform,
            platformAlias: item.alias,
          });
        }
      }
    );
  }

  detectChanges() {
    this.compareAssetBasicInformation();
    this.compareAssetDetails();
    this.compareCast();
    this.compareAssetSpecifications();
    this.compareDrmData();
    this.compareExternalProvider();
    this.compareLicenseDetails();
    this.compareAvailablePlatforms();
  }
  redirectToConsole() {
    this.overallChanges = [];
    this.router.navigate([SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.route_link]);
    this.readyToView = false;
    this.openModal();
  }

  //1) Asset Basic Information - Final Done
  compareAssetBasicInformation() {
    this.assetBasicInformationChanges = assetBasicInformation
      .filter(({ value }) => this.assetsPrd[value] !== this.assetsStg[value])
      .map(({ key, value }) => ({
        ['Key']: key,
        ['Prd Value']:
          this.assetsPrd[value] !== undefined
            ? this.assetsPrd[value].toString()
            : this.assetsPrd[value],
        ['Stg Value']:
          this.assetsStg[value] !== undefined
            ? this.assetsStg[value].toString()
            : this.assetsStg[value],
      }));

    if (this.assetBasicInformationChanges.length !== 0) {
      this.overallChanges.push('Asset Basic Information');
    }
  }

  //2) Asset Details - Final Done
  compareAssetDetails() {
    const assetDetailsPropChanges = assetDetailsSingleValues
      .filter(({ value }) => this.assetsPrd[value] !== this.assetsStg[value])
      .map(({ key, value }) => ({
        ['Key']: key,
        ['Prd Value']: this.assetsPrd[value],
        ['Stg Value']: this.assetsStg[value],
      }));

    this.assetDetailsChanges.propChanges = assetDetailsPropChanges;

    const imageCahnges: boolean = this.compareImages();
    const ratingChanges: boolean = this.compareRatings();

    if (assetDetailsPropChanges.length !== 0 || imageCahnges || ratingChanges) {
      this.overallChanges.push('Asset Details');
    }
  }

  compareImages(): boolean {
    this.imageChanges = imageFields
      .filter(({ value }) => this.assetsPrd[value] !== this.assetsStg[value])
      .map(({ key, value }) => ({
        ['Key']: key,
        ['Prd Value']: this.assetsPrd[value],
        ['Stg Value']: this.assetsStg[value],
      }));
    this.assetDetailsChanges.imageChanges = this.imageChanges;
    if (this.imageChanges.length !== 0) {
      return true;
    } else return false;
  }

  compareRatings(): boolean {
    let missingInStg = (
      Array.isArray(this.assetsPrd.parentalRatings)
        ? this.assetsPrd.parentalRatings
        : []
    ).filter(
      (prdItem: any) =>
        !(
          Array.isArray(this.assetsStg.parentalRatings)
            ? this.assetsStg.parentalRatings
            : []
        ).some((stgItem: any) => this.isEqual(prdItem, stgItem))
    );

    let missingInPrd = (
      Array.isArray(this.assetsStg.parentalRatings)
        ? this.assetsStg.parentalRatings
        : []
    ).filter(
      (stgItem: any) =>
        !(
          Array.isArray(this.assetsPrd.parentalRatings)
            ? this.assetsPrd.parentalRatings
            : []
        ).some((prdItem: any) => this.isEqual(prdItem, stgItem))
    );

    missingInPrd = this.changeKeys(missingInPrd, ratingValues);
    missingInStg = this.changeKeys(missingInStg, ratingValues);
    this.ratingChanges = { missingInPrd, missingInStg };
    this.assetDetailsChanges.ratingChanges = this.ratingChanges;
    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      return true;
    }
    return false;
  }

  changeKeys(
    data: any,
    keys: {
      key: string;
      value: string;
    }[]
  ) {
    const transformedData = data.map((item: any) => {
      const newObj: any = {};
      keys.forEach(({ key, value }) => {
        newObj[key] = item[value];
      });
      return newObj;
    });

    return transformedData;
  }

  //3) Cast - Final Done
  compareCast() {
    let missingInStg = (
      Array.isArray(this.assetsPrd.cast) ? this.assetsPrd.cast : []
    ).filter(
      (prdItem: any) =>
        !(Array.isArray(this.assetsStg.cast) ? this.assetsStg.cast : []).some(
          (stgItem: any) => this.isEqual(prdItem, stgItem)
        )
    );

    let missingInPrd = (
      Array.isArray(this.assetsStg.cast) ? this.assetsStg.cast : []
    ).filter(
      (stgItem: any) =>
        !(Array.isArray(this.assetsPrd.cast) ? this.assetsPrd.cast : []).some(
          (prdItem: any) => this.isEqual(prdItem, stgItem)
        )
    );

    missingInPrd = this.changeKeys(missingInPrd, castValues);
    missingInStg = this.changeKeys(missingInStg, castValues);

    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      this.overallChanges.push('Casts');
    }
    this.castChanges.casts = { missingInPrd, missingInStg };
  }

  isEqual = (a: any, b: any): boolean => {
    if (a === b) return true;
    if (
      typeof a !== 'object' ||
      typeof b !== 'object' ||
      a === null ||
      b === null
    )
      return false;

    const keysA = Object.keys(a);
    const keysB = Object.keys(b);

    if (keysA.length !== keysB.length) return false;
    for (let key of keysA) {
      if (!keysB.includes(key) || !this.isEqual(a[key], b[key])) return false;
    }
    return true;
  };

  //4) Asset Specifications Change - Final Done
  compareAssetSpecifications() {
    this.assetSpecificationsChanges = assetSpecifications
      .filter(({ value }) => this.assetsPrd[value] !== this.assetsStg[value])
      .map(({ key, value }) => ({
        ['Key']: key,
        ['Prd Value']: this.assetsPrd[value],
        ['Stg Value']: this.assetsStg[value],
      }));

    if (this.assetSpecificationsChanges.length !== 0) {
      this.overallChanges.push('Asset Specifications');
    }
  }

  //5) DRM - Final Done
  compareDrmData() {
    let filteredData1 = (
      Array.isArray(this.assetsPrd.drmData) ? this.assetsPrd.drmData : []
    ).map(({ licenseUrl, type }: { licenseUrl: String; type: String }) => ({
      licenseUrl,
      type,
    }));

    let filteredData2 = (
      Array.isArray(this.assetsStg.drmData) ? this.assetsStg.drmData : []
    ).map(({ licenseUrl, type }: { licenseUrl: String; type: String }) => ({
      licenseUrl,
      type,
    }));
    let missingInStg = filteredData1.filter(
      (prdItem: any) =>
        !filteredData2.some((stgItem: any) => this.isEqual(prdItem, stgItem))
    );

    let missingInPrd = filteredData2.filter(
      (stgItem: any) =>
        !filteredData1.some((prdItem: any) => this.isEqual(prdItem, stgItem))
    );

    missingInPrd = this.changeKeys(missingInPrd, drmValues);
    missingInStg = this.changeKeys(missingInStg, drmValues);

    const drmChanges = { missingInPrd, missingInStg };
    this.drmDataChanges.drm = drmChanges;

    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      this.overallChanges.push('DRM');
    }
  }

  //6) External Provider - Final Done
  compareExternalProvider() {
    let missingInStg = (
      Array.isArray(this.assetsPrd.externalProvider)
        ? this.assetsPrd.externalProvider
        : []
    ).filter(
      (prdItem: any) =>
        !(
          Array.isArray(this.assetsStg.externalProvider)
            ? this.assetsStg.externalProvider
            : []
        ).some((stgItem: any) => this.isEqual(prdItem, stgItem))
    );

    let missingInPrd = (
      Array.isArray(this.assetsStg.externalProvider)
        ? this.assetsStg.externalProvider
        : []
    ).filter(
      (stgItem: any) =>
        !(
          Array.isArray(this.assetsPrd.externalProvider)
            ? this.assetsPrd.externalProvider
            : []
        ).some((prdItem: any) => this.isEqual(prdItem, stgItem))
    );

    missingInPrd = this.changeKeys(missingInPrd, externalProviderValues);
    missingInStg = this.changeKeys(missingInStg, externalProviderValues);

    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      this.overallChanges.push('External Provider');
    }
    const externalProviderChanges = { missingInPrd, missingInStg };
    this.externalProviderChanges.externalProvider = externalProviderChanges;
  }

  //License Details-Final Done
  compareLicenseDetails() {
    const licenseDetailsPropChanges = licenseDetailSingleValues
      .filter(({ value }) => this.assetsPrd[value] !== this.assetsStg[value])
      .map(({ key, value }) => ({
        ['Key']: key,
        ['Prd Value']: this.assetsPrd[value],
        ['Stg Value']: this.assetsStg[value],
      }));

    this.licenseDetailsChanges.propChanges = licenseDetailsPropChanges;
    let changesInlicenseWindowList = this.comparelicenseWindowList();
    let changesInEventWindowList = this.compareEventWindowList();

    if (
      licenseDetailsPropChanges.length !== 0 ||
      changesInlicenseWindowList ||
      changesInEventWindowList
    ) {
      this.overallChanges.push('License Details');
    }
  }

  comparelicenseWindowList(): boolean {
    let missingInStg = (
      Array.isArray(this.assetsPrd.licenseWindowList)
        ? this.assetsPrd.licenseWindowList
        : []
    ).filter(
      (prdItem: any) =>
        !(
          Array.isArray(this.assetsStg.licenseWindowList)
            ? this.assetsStg.licenseWindowList
            : []
        ).some((stgItem: any) => this.isEqual(prdItem, stgItem))
    );

    let missingInPrd = (
      Array.isArray(this.assetsStg.licenseWindowList)
        ? this.assetsStg.licenseWindowList
        : []
    ).filter(
      (stgItem: any) =>
        !(
          Array.isArray(this.assetsPrd.licenseWindowList)
            ? this.assetsPrd.licenseWindowList
            : []
        ).some((prdItem: any) => this.isEqual(prdItem, stgItem))
    );

    missingInPrd = this.changeKeys(missingInPrd, licenseWindow);
    missingInStg = this.changeKeys(missingInStg, licenseWindow);
    const licenseWindowListChanges = { missingInPrd, missingInStg };
    this.licenseDetailsChanges.licenseDetails = licenseWindowListChanges;
    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      return true;
    } else return false;

    //console.log('License Window List changes', licenseWindowListChanges);
  }

  compareEventWindowList(): boolean {
    let missingInStg = (
      Array.isArray(this.assetsPrd.eventWindowList)
        ? this.assetsPrd.eventWindowList
        : []
    ).filter(
      (prdItem: any) =>
        !(
          Array.isArray(this.assetsStg.eventWindowList)
            ? this.assetsStg.eventWindowList
            : []
        ).some((stgItem: any) => this.isEqual(prdItem, stgItem))
    );

    let missingInPrd = (
      Array.isArray(this.assetsStg.eventWindowList)
        ? this.assetsStg.eventWindowList
        : []
    ).filter(
      (stgItem: any) =>
        !(
          Array.isArray(this.assetsPrd.eventWindowList)
            ? this.assetsPrd.eventWindowList
            : []
        ).some((prdItem: any) => this.isEqual(prdItem, stgItem))
    );

    missingInPrd = this.changeKeys(missingInPrd, eventWindow);
    missingInStg = this.changeKeys(missingInStg, eventWindow);
    const eventWindowListChanges = { missingInPrd, missingInStg };
    this.licenseDetailsChanges.eventDetails = eventWindowListChanges;
    if (missingInPrd.length !== 0 || missingInStg.length !== 0) {
      return true;
    } else return false;
  }

  //Available Platform
  compareAvailablePlatforms() {
    let platformTagStg =
      this.assetsStg.platformTag === undefined
        ? 'common'
        : this.assetsStg.platformTag;
    let platformTagPrd =
      this.assetsPrd.platformTag === undefined
        ? 'common'
        : this.assetsPrd.platformTag;

    if (platformTagPrd === 'common' && platformTagStg === 'common') {
      const fHubItemsMissingInPrd = this.availablePlatformStg.fHubItems.filter(
        (prdItem: any) =>
          !this.availablePlatformPrd.fHubItems.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const fHubItemsMissingInStg = this.availablePlatformPrd.fHubItems.filter(
        (stgItem: any) =>
          !this.availablePlatformStg.fHubItems.some((prdItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const mobileItemsMissingInPrd =
        this.availablePlatformStg.mobileItems.filter(
          (stgItem: any) =>
            !this.availablePlatformPrd.mobileItems.some((prdItem: any) =>
              this.isEqual(prdItem, stgItem)
            )
        );

      const mobileItemsMissingInStg =
        this.availablePlatformPrd.mobileItems.filter(
          (prdItem: any) =>
            !this.availablePlatformStg.mobileItems.some((stgItem: any) =>
              this.isEqual(prdItem, stgItem)
            )
        );

      const tvItemsMissingInStg = this.availablePlatformPrd.tvItems.filter(
        (stgItem: any) =>
          !this.availablePlatformStg.tvItems.some((prdItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const tvItemsMissingInPrd = this.availablePlatformStg.tvItems.filter(
        (prdItem: any) =>
          !this.availablePlatformPrd.tvItems.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const webItemsMissingInPrd = this.availablePlatformStg.webItems.filter(
        (prdItem: any) =>
          !this.availablePlatformPrd.webItems.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const webItemsMissingInStg = this.availablePlatformPrd.webItems.filter(
        (prdItem: any) =>
          !this.availablePlatformStg.webItems.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      this.changesPltPrd = {
        type: 'common',
        tvValues: [],
        tvItems: [],
        mobileItems: [],
        mobileValues: [],
        fHubItems: [],
        fHubValues: [],
        webItems: [],
        webValues: [],
      };

      this.changesPltStg = {
        type: 'common',
        tvValues: [],
        tvItems: [],
        mobileItems: [],
        mobileValues: [],
        fHubItems: [],
        fHubValues: [],
        webItems: [],
        webValues: [],
      };

      this.changesPltPrd.tvItems = tvItemsMissingInPrd;
      this.changesPltPrd.mobileItems = mobileItemsMissingInPrd;
      this.changesPltPrd.fHubItems = fHubItemsMissingInPrd;
      this.changesPltPrd.webItems = webItemsMissingInPrd;

      this.changesPltStg.tvItems = tvItemsMissingInStg;
      this.changesPltStg.mobileItems = mobileItemsMissingInStg;
      this.changesPltStg.fHubItems = fHubItemsMissingInStg;
      this.changesPltStg.webItems = webItemsMissingInStg;

      if (
        !(
          tvItemsMissingInPrd.length == 0 &&
          mobileItemsMissingInPrd.length == 0 &&
          fHubItemsMissingInPrd.length == 0 &&
          webItemsMissingInPrd.length == 0 &&
          tvItemsMissingInStg.length == 0 &&
          mobileItemsMissingInStg.length == 0 &&
          fHubItemsMissingInStg.length == 0 &&
          webItemsMissingInStg.length == 0
        )
      ) {
        this.overallChanges.push('Available Platforms');
        this.availablePlatformChanges = {
          missingInPrd: this.changesPltPrd,
          missingInStg: this.changesPltStg,
        };
      }
    }

    if (platformTagStg !== platformTagPrd) {
      this.overallChanges.push('Available Platforms');
      this.availablePlatformChanges.platformTag = [
        {
          ['Key']: 'Platform Tag',
          ['Prd Value']: platformTagPrd,
          ['Stg Value']: platformTagStg,
        },
      ];
    } else {
      const fHubItemsMatchingInPrd = this.availablePlatformPrd.fHubItems
        .map((pn) => {
          const match = this.availablePlatformPrd.fHubValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const fHubItemsMatchingInStg = this.availablePlatformStg.fHubItems
        .map((pn) => {
          const match = this.availablePlatformStg.fHubValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const mobileItemsMatchingInPrd = this.availablePlatformPrd.mobileItems
        .map((pn) => {
          const match = this.availablePlatformPrd.mobileValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const mobileItemsMatchingInStg = this.availablePlatformStg.mobileItems
        .map((pn) => {
          const match = this.availablePlatformStg.mobileValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const tvItemsMatchingInStg = this.availablePlatformStg.tvItems
        .map((pn) => {
          const match = this.availablePlatformStg.tvValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const tvItemsMatchingInPrd = this.availablePlatformPrd.tvItems
        .map((pn) => {
          const match = this.availablePlatformPrd.tvValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const webItemsMatchingInPrd = this.availablePlatformPrd.webItems
        .map((pn) => {
          const match = this.availablePlatformPrd.webValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const webItemsMatchingInStg = this.availablePlatformStg.webItems
        .map((pn) => {
          const match = this.availablePlatformStg.webValues.find(
            (pv) => pv.platformName === pn.platformName
          );
          return match
            ? {
                platformName: pn.platformName,
                platformAlias: match.platformAlias,
              }
            : null;
        })
        .filter(
          (item): item is { platformName: string; platformAlias: string } =>
            item !== null
        );

      const fHubItemsMissingInPrd = fHubItemsMatchingInStg.filter(
        (prdItem: any) =>
          !fHubItemsMatchingInPrd.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const fHubItemsMissingInStg = fHubItemsMatchingInPrd.filter(
        (stgItem: any) =>
          !fHubItemsMatchingInStg.some((prdItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const mobileItemsMissingInPrd = mobileItemsMatchingInStg.filter(
        (stgItem: any) =>
          !mobileItemsMatchingInPrd.some((prdItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const mobileItemsMissingInStg = mobileItemsMatchingInPrd.filter(
        (prdItem: any) =>
          !mobileItemsMatchingInStg.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const tvItemsMissingInStg = tvItemsMatchingInPrd.filter(
        (stgItem: any) =>
          !tvItemsMatchingInStg.some((prdItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const tvItemsMissingInPrd = tvItemsMatchingInStg.filter(
        (prdItem: any) =>
          !tvItemsMatchingInPrd.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const webItemsMissingInPrd = webItemsMatchingInStg.filter(
        (prdItem: any) =>
          !webItemsMatchingInPrd.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      const webItemsMissingInStg = webItemsMatchingInPrd.filter(
        (prdItem: any) =>
          !webItemsMatchingInStg.some((stgItem: any) =>
            this.isEqual(prdItem, stgItem)
          )
      );

      this.changesPltPrd = {
        type: 'common',
        tvValues: [],
        tvItems: [],
        mobileItems: [],
        mobileValues: [],
        fHubItems: [],
        fHubValues: [],
        webItems: [],
        webValues: [],
      };

      this.changesPltStg = {
        type: 'common',
        tvValues: [],
        tvItems: [],
        mobileItems: [],
        mobileValues: [],
        fHubItems: [],
        fHubValues: [],
        webItems: [],
        webValues: [],
      };

      this.changesPltPrd.tvItems = tvItemsMissingInPrd;
      this.changesPltPrd.mobileItems = mobileItemsMissingInPrd;
      this.changesPltPrd.fHubItems = fHubItemsMissingInPrd;
      this.changesPltPrd.webItems = webItemsMissingInPrd;

      this.changesPltStg.tvItems = tvItemsMissingInStg;
      this.changesPltStg.mobileItems = mobileItemsMissingInStg;
      this.changesPltStg.fHubItems = fHubItemsMissingInStg;
      this.changesPltStg.webItems = webItemsMissingInStg;

      if (
        !(
          tvItemsMissingInPrd.length == 0 &&
          mobileItemsMissingInPrd.length == 0 &&
          fHubItemsMissingInPrd.length == 0 &&
          webItemsMissingInPrd.length == 0 &&
          tvItemsMissingInStg.length == 0 &&
          mobileItemsMissingInStg.length == 0 &&
          fHubItemsMissingInStg.length == 0 &&
          webItemsMissingInStg.length == 0
        )
      ) {
        this.overallChanges.push('Available Platforms');
        this.availablePlatformChanges = {
          missingInPrd: this.changesPltPrd,
          missingInStg: this.changesPltStg,
        };
      }
    }
  }

  openShowChangesModal(event: any) {
    let conflictingData: any = {};
    switch (event) {
      case 'Asset Basic Information':
        {
          conflictingData = this.assetBasicInformationChanges;
        }

        break;

      case 'Asset Details':
        {
          conflictingData = this.assetDetailsChanges;
        }
        break;

      case 'Casts':
        {
          conflictingData = this.castChanges;
        }
        break;

      case 'Asset Specifications':
        {
          conflictingData = this.assetSpecificationsChanges;
        }
        break;

      case 'DRM':
        {
          conflictingData = this.drmDataChanges;
        }
        break;

      case 'External Provider':
        {
          conflictingData = this.externalProviderChanges;
        }
        break;

      case 'License Details':
        {
          conflictingData = this.licenseDetailsChanges;
        }
        break;

      case 'Available Platforms':
        {
          conflictingData = this.availablePlatformChanges;
        }
        break;

      default:
        break;
    }
    this.dialog.open(ShowChangesModalComponent, {
      width: 'auto',
      data: {
        type: event,
        changes: conflictingData,
      },
    });
  }
}
