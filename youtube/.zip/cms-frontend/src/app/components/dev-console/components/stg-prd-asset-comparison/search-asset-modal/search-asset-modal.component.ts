import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  Inject,
  inject,
} from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';

import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule } from '@angular/forms';
import { StateStoreService } from '../../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../../constants/store-consts';
import { AssetService } from '../../../../../services/asset.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { forkJoin, Observable, switchMap } from 'rxjs';
import { Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../../constants/app-consts';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { UserService } from '../../../../../services/user.service';
import { Country } from '../../../../../models/country-model';
import { plainToInstance } from 'class-transformer';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
    selector: 'app-search-asset-modal',
    imports: [
        MatDialogModule,
        AppMatInputComponent,
        MatButtonModule,
        MatSelectModule,
        MatRadioModule,
        FormsModule,
    ],
    templateUrl: './search-asset-modal.component.html',
    styleUrl: './search-asset-modal.component.scss'
})
export class SearchAssetModalComponent {
  private destroy = inject(DestroyRef);
  countries: string[];
  countryData: Country[];
  programType: any[] = [
    'SHOW',
    'SEASON',
    'EPISODE',
    'MOVIE',
    'MUSIC',
    'SINGLEVOD',
  ];
  assetKey = {
    countryCode: '',
    contentId: '',
    cpId: '',
    type: '',
  };

  assetFilterObject: { columns: string[]; filters: any[]; pagination: any } = {
    columns: ['countryCode', 'contentId', 'type', 'vcCpId'],
    filters: [
      {
        key: 'contentId',
        type: 'search',
        values: [],
      },
    ],
    pagination: {
      limit: 1000,
      offset: 0,
    },
  };

  constructor(
    private storeService: StateStoreService,
    private changeDetectorRef: ChangeDetectorRef,
    private assetService: AssetService,
    public dialogRef: MatDialogRef<SearchAssetModalComponent>,
    private router: Router,
    private toastr: CustomToastrService,
    private userService: UserService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    if (this.data.assetId != null) {
      this.assetKey.countryCode = this.data.countryCode;
      this.assetKey.contentId = this.data.assetId;
      this.assetKey.cpId = this.data.cpId;
      this.assetKey.type = this.data.type;
      this.getForkedData();
    }
    this.getCountriesFromStore();
  }

  getAssetKeyDetails(assetId: string) {
    this.assetFilterObject.filters[0].values.push(assetId.trim());
    this.assetService
      .getAssets(this.assetFilterObject)
      .pipe(
        switchMap((res: any) => {
          this.assetKey.countryCode = res[0].countryCode;
          this.assetKey.cpId = res[0].vcCpId;
          this.assetKey.type = res[0].type;
          return this.getForkedData();
        })
      )
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (
          result.assetDataStg === null &&
          result.assetDataPrd === null &&
          result.filterDataStg === null &&
          result.filterDataPrd === null
        ) {
          this.toastr.error('Invalid Asset Details');
        } else {
          (result as any).assetKey = this.assetKey;
          this.dialogRef.close(result);
        }
      });
  }

  ngAfterContentChecked() {
    this.changeDetectorRef.detectChanges();
  }

  getCountriesFromStore() {
    const countries: Country[] = this.storeService.getStoreState(
      STORE_CONSTS.MASTER_COUNTRIES
    );
    if (countries.length !== 0) {
      this.countryData = countries;
      this.prepareCountryData(this.countryData);
    } else {
      this.fetchCountries();
    }
  }

  fetchCountries() {
    this.userService.getCountries().subscribe((res: any) => {
      this.countryData = plainToInstance<Country, []>(Country, res);
      this.prepareCountryData(this.countryData);
      this.storeService.setStoreState(
        STORE_CONSTS.MASTER_COUNTRIES,
        plainToInstance<Country, {}>(Country, res)
      );
    });
  }

  prepareCountryData(data: any[]) {
    const countryData: string[] = data.map(
      (country) => `${country.countryName} (${country.countryCode})`
    );
    this.countries = countryData;
  }

  getForkedData(): Observable<any> {
    const payload = {
      contentId: this.assetKey.contentId.trim(),
      vcCpId: this.assetKey.cpId,
      countryCode: this.assetKey.countryCode,
      type: this.assetKey.type,
    };

    this.assetFilterObject.filters[0].values.push(this.assetKey.contentId);

    return forkJoin({
      assetDataStg: this.assetService.getAssetDetailedView(
        this.assetKey.contentId.trim(),
        this.assetKey.cpId,
        this.assetKey.countryCode
      ),
      filterDataStg: this.assetService.getViewFilters(payload),
      assetDataPrd: this.assetService.getAssetDetailedViewPrd(
        this.assetKey.contentId.trim(),
        this.assetKey.cpId,
        this.assetKey.countryCode
      ),
      filterDataPrd: this.assetService.getViewFiltersPrd(payload),
    });
  }

  submit() {
    this.getAssetKeyDetails(this.assetKey.contentId);
  }

  redirectToConsole() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
    this.dialogRef.close();
  }

  areAllFieldsFilled(): boolean {
    if (!this.assetKey.contentId || !this.assetKey.contentId.trim())
      return false;
    else return true;
  }
}
