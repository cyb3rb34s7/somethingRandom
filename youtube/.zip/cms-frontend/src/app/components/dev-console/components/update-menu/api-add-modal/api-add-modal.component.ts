import { Component, DestroyRef, inject, Inject, Input } from '@angular/core';
import { AppMatSelectComponent } from '../../../../../mat-components/app-mat-select/app-mat-select.component';
import { AppMatInputComponent } from '../../../../../mat-components/app-mat-input/app-mat-input.component';
import { MatRadioButton, MatRadioGroup } from '@angular/material/radio';
import {
  MAT_DIALOG_DATA,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { DevConsoleService } from '../../../../../services/dev-console.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ChangeDetectorRef } from '@angular/core';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import {
  ACTION_TYPES,
  createApiAcessTypeData,
  HTTP_METHOD,
} from '../../../../../interfaces/dev-console-api-access-data-type';
import { plainToInstance } from 'class-transformer';
import { STORE_CONSTS } from '../../../../../constants/store-consts';
import { User } from '../../../../../models/user-model';
import { UserService } from '../../../../../services/user.service';
import { StateStoreService } from '../../../../../services/store/state-store.service';

@Component({
    selector: 'app-api-add-modal',
    imports: [
        FormsModule,
        AppMatSelectComponent,
        AppMatInputComponent,
        MatRadioButton,
        MatRadioGroup,
        MatDialogContent,
        MatDialogTitle,
        MatDialogClose,
        MatDialogActions,
        MatDialogClose,
        MatButtonModule,
    ],
    templateUrl: './api-add-modal.component.html',
    styleUrl: './api-add-modal.component.scss'
})
export class ApiAddModalComponent {
  private destroy = inject(DestroyRef);
  menuId: any[] = [];
  user: User;
  menuIdNum: number;

  menuData: createApiAcessTypeData = {
    menuId: -1,
    apiPath: '',
    menuName: '',
    httpMethod: HTTP_METHOD.GET,
    actionType: ACTION_TYPES.READ,
    userName: '',
    regrId: '',
    mdfrId: '',
    isDefault: false,
  };

  HTTP_METHOD: string[] = ['GET', 'POST', 'UPDATE', 'DELETE'];
  ACTION_TYPES: { title: string; value: string }[] = [
    { title: 'READ', value: ACTION_TYPES.READ },
    { title: 'WRITE', value: ACTION_TYPES.WRITE },
    { title: 'UPDATE', value: ACTION_TYPES.UPDATE },
    { title: 'DELETE', value: ACTION_TYPES.DELETE },
  ];
  IS_DEFAULT_YES_NO: { title: string; value: Boolean }[] = [
    { title: 'Yes', value: true },
    { title: 'No', value: false },
  ];
  constructor(
    public dialogRef: MatDialogRef<ApiAddModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toastr: CustomToastrService,
    private devConsoleService: DevConsoleService,
    private cdref: ChangeDetectorRef,
    private userService: UserService,
    private storeService: StateStoreService
  ) {
    this.menuId = this.data.map(
      (id: any) => id.menuId.toString() + ' ' + id.menuName
    );
  }
  ngOnInit() {
    this.user = this.storeService.getStoreState(STORE_CONSTS.CURRENT_USER);

    if (!this.user.userId) {
      this.fetchUserData();
    }
    this.menuData.regrId = this.user.userId;
    this.menuData.mdfrId = this.user.userId;
  }
  handleMenuId(event: string) {
    this.menuData.menuId = Number(event.split(' ')[0]);
  }
  handleApiPath(inputString: string): void {
    if (inputString.length) {
      this.menuData.apiPath = inputString;
    } else {
      this.menuData.apiPath = '';
    }
  }
  createNewApiUrl(data: any) {
    this.devConsoleService
      .createNewApi(this.menuData)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  fetchUserData() {
    this.userService
      .getUserDetails()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.storeService.setStoreState(
          STORE_CONSTS.CURRENT_USER,
          plainToInstance<User, {}>(User, res.user)
        );
        this.user = res.user;
      });
  }
  isDisabled(): boolean {
    return (
      !this.menuData.apiPath ||
      !this.menuData.actionType ||
      !this.menuData.httpMethod ||
      !this.menuData.menuId ||
      this.menuData.isDefault == null ||
      this.menuData.apiPath == ''
    );
  }
  selectDefault(event: any) {
    this.menuData.isDefault = event;
  }
}
