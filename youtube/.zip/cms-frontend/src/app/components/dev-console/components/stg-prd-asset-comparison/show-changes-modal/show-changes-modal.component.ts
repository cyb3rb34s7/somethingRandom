import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { AppMatTableComponent } from '../../../../../mat-components/app-mat-table/app-mat-table.component';
import { MatButtonModule } from '@angular/material/button';
import { MissingDataComponentComponent } from '../missing-data-component/missing-data-component.component';
import { ShowMissingPlatformsComponent } from '../show-missing-platforms/show-missing-platforms.component';
import { AssetHelperService } from '../../../../../features/media-assets/assets-details/media-asset-complete-view/utils/asset-helper.service';

@Component({
  selector: 'app-show-changes-modal',
  imports: [
    AppMatTableComponent,
    MatDialogModule,
    MissingDataComponentComponent,
    ShowMissingPlatformsComponent,
    MatButtonModule,
  ],
  templateUrl: './show-changes-modal.component.html',
  styleUrl: './show-changes-modal.component.scss',
})
export class ShowChangesModalComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public assetHelperService: AssetHelperService
  ) {}

  ngOnInit() {
    if (this.data.type === 'License Details') {
      const licenseDetails = this.data.changes.licenseDetails;
      [licenseDetails.missingInPrd, licenseDetails.missingInStg].forEach(
        (source) => {
          source.forEach((item: any) => {
            item['Window Start Date (UTC)'] =
              this.assetHelperService.getDateTimeWithoutTZ(
                item['Window Start Date (UTC)']
              );
            item['Window End Date (UTC)'] =
              this.assetHelperService.getDateTimeWithoutTZ(
                item['Window End Date (UTC)']
              );
          });
        }
      );

      const eventDetails = this.data.changes.eventDetails;
      [eventDetails.missingInPrd, eventDetails.missingInStg].forEach(
        (source) => {
          source.forEach((item: any) => {
            item['Event Start Date (UTC)'] =
              this.assetHelperService.getDateTimeWithoutTZ(
                item['Event Start Date (UTC)']
              );
            item['Event End Date (UTC)'] =
              this.assetHelperService.getDateTimeWithoutTZ(
                item['Event End Date (UTC)']
              );
          });
        }
      );
    }
  }
}
