import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SqsManagementComponent } from './sqs-management.component';

describe('SqsManagementComponent', () => {
  let component: SqsManagementComponent;
  let fixture: ComponentFixture<SqsManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SqsManagementComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SqsManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
