import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MissingDataComponentComponent } from './missing-data-component.component';

describe('MissingDataComponentComponent', () => {
  let component: MissingDataComponentComponent;
  let fixture: ComponentFixture<MissingDataComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MissingDataComponentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MissingDataComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
