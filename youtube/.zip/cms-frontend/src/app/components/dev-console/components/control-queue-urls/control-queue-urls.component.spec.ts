import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlQueueUrlsComponent } from './control-queue-urls.component';

describe('ControlQueueUrlsComponent', () => {
  let component: ControlQueueUrlsComponent;
  let fixture: ComponentFixture<ControlQueueUrlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ControlQueueUrlsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ControlQueueUrlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
