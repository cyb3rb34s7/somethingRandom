import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApiEditModalComponent } from './api-edit-modal.component';

describe('ApiEditModalComponent', () => {
  let component: ApiEditModalComponent;
  let fixture: ComponentFixture<ApiEditModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApiEditModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ApiEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
