import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAssetModalComponent } from './search-asset-modal.component';

describe('SearchAssetModalComponent', () => {
  let component: SearchAssetModalComponent;
  let fixture: ComponentFixture<SearchAssetModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchAssetModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SearchAssetModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
