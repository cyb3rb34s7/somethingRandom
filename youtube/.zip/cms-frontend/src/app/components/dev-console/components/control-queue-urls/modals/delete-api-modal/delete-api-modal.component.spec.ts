import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteApiModalComponent } from './delete-api-modal.component';

describe('DeleteApiModalComponent', () => {
  let component: DeleteApiModalComponent;
  let fixture: ComponentFixture<DeleteApiModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteApiModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteApiModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
