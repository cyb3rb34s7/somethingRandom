import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechIntegratorManagementComponent } from './tech-integrator-management.component';

describe('TechIntegratorManagementComponent', () => {
  let component: TechIntegratorManagementComponent;
  let fixture: ComponentFixture<TechIntegratorManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TechIntegratorManagementComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TechIntegratorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
