import { Component, Input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-show-missing-platforms',
    imports: [MatTooltipModule, MatIconModule],
    templateUrl: './show-missing-platforms.component.html',
    styleUrl: './show-missing-platforms.component.scss'
})
export class ShowMissingPlatformsComponent {
  @Input() missingChangesPrd!: any;
  @Input() missingChangesStg!: any;
  @Input() platformType!: any;

  ngOnInit() {}
}
