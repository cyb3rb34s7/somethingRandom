import { Component, DestroyRef, Inject, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';
import { DevConsoleService } from '../../../../../../services/dev-console.service';
import { ControlQueueUrls } from '../../../../../../models/control-queue-urls-model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-delete-api-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './delete-api-modal.component.html',
    styleUrl: './delete-api-modal.component.scss'
})
export class DeleteApiModalComponent {
  private destroy = inject(DestroyRef);

  constructor(
    public dialogRef: MatDialogRef<DeleteApiModalComponent>,
    private toastr: CustomToastrService,
    private devConsoleService: DevConsoleService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  deleteApi() {
    const dataToDelete: ControlQueueUrls = {
      country: this.data['Country'],
      licenseURL: this.data['License Sqs Url'],
      region: this.data['Region'],
      assetUrl: this.data['Asset Sql Url'],
      queueNumber: Number(this.data['Queue Number']),
      isActive: this.data['Active Status'] === 'Yes' ? true : false,
    };

    this.devConsoleService
      .deleteControlQueueUrl(dataToDelete)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((r) => {
        this.toastr.success(r.message);
        this.dialogRef.close(true);
      });
  }
}
