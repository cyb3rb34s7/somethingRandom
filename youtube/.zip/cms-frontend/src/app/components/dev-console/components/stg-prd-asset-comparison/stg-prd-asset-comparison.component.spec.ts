import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StgPrdAssetComparisonComponent } from './stg-prd-asset-comparison.component';

describe('StgPrdAssetComparisonComponent', () => {
  let component: StgPrdAssetComparisonComponent;
  let fixture: ComponentFixture<StgPrdAssetComparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StgPrdAssetComparisonComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StgPrdAssetComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
