import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AppMatTableComponent } from '../../../../mat-components/app-mat-table/app-mat-table.component';
import { InvalidAsset } from '../../../../models/invalid-asset-model';
import { DevConsoleService } from '../../../../services/dev-console.service';
import { Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { SearchFilterBoxComponent } from '../../search-filter-box/search-filter-box.component';
import { ExeljsService } from '../../../../services/exeljs.service';

@Component({
    selector: 'app-invalid-assets-detail',
    imports: [
        AppMatTableComponent,
        MatButtonModule,
        MatTableModule,
        SearchFilterBoxComponent,
    ],
    templateUrl: './invalid-assets-detail.component.html',
    styleUrl: './invalid-assets-detail.component.scss'
})
export class InvalidAssetsDetailComponent {
  invalidAssetData: any[];
  tableData: any[] = [];
  searchFilterOptions: string[] = ['Program Id', 'Provider Id', 'Country'];
  lastFilter: any = null;
  @ViewChild(SearchFilterBoxComponent)
  matSearch: SearchFilterBoxComponent;
  constructor(
    private devConsoleService: DevConsoleService,
    private router: Router,
    private exlSvc: ExeljsService
  ) {}
  private destroy = inject(DestroyRef);

  ngOnInit() {
    this.fetchInvalidAssets();
  }
  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  fetchInvalidAssets() {
    this.devConsoleService
      .getInValidAssets()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        res.sort((a: any, b: any) => {
          let date1 = new Date(a.errorDatetime);
          let date2 = new Date(b.errorDatetime);
          return date1 < date2 ? 1 : -1;
        });
        this.invalidAssetData = res;
        this.tableData = this.prepareColumnNames(this.invalidAssetData);
      });
  }

  refreshInvalidAssets() {
    this.lastFilter = null;
    this.matSearch.clear();
    this.fetchInvalidAssets();
  }

  prepareColumnNames(data: InvalidAsset[]) {
    let changedKeyData = data.map((item: InvalidAsset) => {
      const obj: any = {};
      obj['Program Id'] = item.programId;
      obj['Provider Id'] = item.contentProvider;
      obj['Country'] = item.country;
      obj['Error'] = item.error;
      obj['Date'] =
        item.errorDatetime.split(' ')[0] +
        ' ' +
        item.errorDatetime.split(' ')[1].split('.')[0];
      return obj;
    });

    return changedKeyData;
  }

  handleSearch(value: { category: string; queryString: string }) {
    this.lastFilter = value;
    let data = this.prepareColumnNames(this.invalidAssetData);
    if (
      value &&
      this.searchFilterOptions.includes(value.category) &&
      value.queryString !== ''
    ) {
      data = data.filter((ti: any) => {
        let str: string = ti[value.category];
        str = str.toLowerCase();
        return str.includes(value.queryString.toLowerCase());
      });
    }
    this.tableData = data;
  }

  exportExcel() {
    const arr = [Object.keys(this.tableData[0])];
    this.tableData.forEach((d: any) => {
      arr.push(Object.values(d));
    });
    this.exlSvc.create('Invalid_Assets', arr, 'Invalid_Assets');
  }
}
