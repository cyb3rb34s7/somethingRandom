import { HttpErrorResponse } from '@angular/common/http';
import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { plainToInstance } from 'class-transformer';

import { MatTooltip } from '@angular/material/tooltip';
import { DevConsoleService } from '../../../../services/dev-console.service';

import { CustomToastrService } from '../../../../services/custom-toastr.service';
import { TABLE_CONSTS } from '../../../../constants/table-consts';
import { HistoryMatTableComponent } from '../../../../features/change-history/history-mat-table/history-mat-table.component';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { Router } from '@angular/router';
import {
  DevStatusHistoryModel,
  Pagination,
} from '../../../../models/dev-status-history';

@Component({
    selector: 'app-asset-status-history',
    imports: [
        AppMatSimpleSearchComponent,
        MatCardModule,
        MatButtonModule,
        MatIconModule,
        MatTooltip,
        HistoryMatTableComponent,
    ],
    templateUrl: './status-history-page.component.html',
    styleUrl: './status-history-page.component.scss'
})
export class AssetStatusHistoryComponent {
  private destroy = inject(DestroyRef);

  AssetStatusHistoryData: DevStatusHistoryModel[] = [];
  tableData: any[];
  pagination: Pagination = { limit: 1000, offset: 0 };
  noMoreDataAvailable: boolean = false;
  offsetIndex: any = 0;
  statusHistoryCount: number;

  constructor(
    public devConsoleService: DevConsoleService,
    private toastr: CustomToastrService,
    private router: Router
  ) {}

  ngOnInit() {
    this.fetchAssetStatusHistory();
  }

  onSidebarClosed() {}

  onLoadMore(e: any) {
    if (!this.noMoreDataAvailable) {
      if (this.pagination?.offset != null) {
        this.offsetIndex++;
        this.pagination.offset = this.offsetIndex * 1000;
      }
      this.fetchAssetStatusHistory();
    }
  }

  fetchAssetStatusHistory(isRefresh: boolean = false) {
    this.devConsoleService
      .allAssetStatusHistory(this.pagination)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe({
        next: (res) => {
          if (isRefresh) {
            this.AssetStatusHistoryData.splice(this.offsetIndex * 1000);
            this.AssetStatusHistoryData = this.AssetStatusHistoryData.concat(
              plainToInstance<DevStatusHistoryModel, []>(
                DevStatusHistoryModel,
                res.data
              )
            );
          } else if (this.pagination?.offset === 0) {
            this.AssetStatusHistoryData = plainToInstance<
              DevStatusHistoryModel,
              []
            >(DevStatusHistoryModel, res.data);
            console.log('checking page');
          } else {
            this.AssetStatusHistoryData = this.AssetStatusHistoryData.concat(
              plainToInstance<DevStatusHistoryModel, []>(
                DevStatusHistoryModel,
                res.data
              )
            );
          }
          if (res.data.length < 1000) {
            this.noMoreDataAvailable = true;
          }

          this.statusHistoryCount = res.count;

          this.prepareTableData(this.AssetStatusHistoryData);
        },
        error: (error: HttpErrorResponse) => {
          console.log('====Error===', error);
        },
      });
  }

  prepareTableData(statusHistory: DevStatusHistoryModel[]) {
    this.tableData = statusHistory.map(
      (objStatusHistory: DevStatusHistoryModel) => {
        const obj: any = {};

        obj[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS] = [];
        obj['Program Id'] = objStatusHistory.assetId;
        obj['Change Date'] = objStatusHistory.date.split(' ')[0];
        obj['Change time'] = objStatusHistory.date.split(' ')[1].split('.')[0];
        obj['New Status'] = objStatusHistory.newStatus;
        obj['Old Status'] = objStatusHistory.oldStatus;
        obj['Last Updated By'] = objStatusHistory.updatedBy;
        obj['Master State'] = objStatusHistory.masterState;

        return obj;
      }
    );
  }

  handleSearch(value: String) {
    if (value) {
      const data = this.AssetStatusHistoryData.filter((d) => {
        const searchIn = d.assetId.toLowerCase();
        return searchIn.includes(value.toLowerCase());
      });
      this.prepareTableData(data);
    } else {
      this.prepareTableData(this.AssetStatusHistoryData);
    }
  }
  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }
}
