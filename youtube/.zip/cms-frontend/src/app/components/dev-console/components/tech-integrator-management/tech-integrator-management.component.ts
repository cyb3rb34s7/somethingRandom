import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { DevConsoleService } from '../../../../services/dev-console.service';
import {
  TechIntegrator,
  TechIntegratorDto,
} from '../../../../interfaces/dev-console-techIntegrator-type';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AppMatTableComponent } from '../../../../mat-components/app-mat-table/app-mat-table.component';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { TABLE_CONSTS } from '../../../../constants/table-consts';
import { CustomToastrService } from '../../../../services/custom-toastr.service';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmModalComponent } from './confirm-modal/confirm-modal.component';
import { SearchFilterBoxComponent } from '../../search-filter-box/search-filter-box.component';

@Component({
    selector: 'app-tech-integrator-management',
    imports: [
        AppMatTableComponent,
        SearchFilterBoxComponent,
        MatIconModule,
        MatCardModule,
        MatButtonModule,
    ],
    templateUrl: './tech-integrator-management.component.html',
    styleUrl: './tech-integrator-management.component.scss'
})
export class TechIntegratorManagementComponent {
  tiData: TechIntegrator[] = [];
  tableData: any[] = [];
  @ViewChild(SearchFilterBoxComponent)
  matSearch: SearchFilterBoxComponent;

  searchFilterOptions: string[] = ['Provider ID', 'Country', 'Tech Integrator', 'Feed Worker'];

  lastFilter: any = null;

  constructor(
    private devConsoleService: DevConsoleService,
    private router: Router,
    private storeService: StateStoreService,
    private toastr: CustomToastrService,
    public dialog: MatDialog
  ) {}

  private destroy = inject(DestroyRef);

  ngOnInit() {
    this.fetchtiData();
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  fetchtiData() {
    this.devConsoleService
      .getTiData()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: TechIntegrator[]) => {
        this.tiData = res;
        this.handleSearch(this.lastFilter);
      });
  }

  handleSearch(value: {category: string, queryString: string} ) {  
    this.lastFilter = value;
    let data = this.prepareColumnNames(this.tiData);
    if (value && this.searchFilterOptions.includes(value.category) && value.queryString !== "") {     
      data = data.filter((ti: any) => {
        let str :string = ti[value.category];
        str = str.toLowerCase();      
        return str.includes(value.queryString.toLowerCase());
      });
    }
    this.tableData = data;
  }

  convertToTechIntegratorDto(ti: any): TechIntegratorDto {    
    let techIntegratorDto: TechIntegratorDto = {
      countryCode: ti['Country'],
      cpId: ti['Provider ID'],
      cmsAllowed: ti['Feed Worker'] === 'TVPLUS',
      region: this.storeService.getStoreState(STORE_CONSTS.REGION),
    };
    return techIntegratorDto;
  }

  openDialog(e: { icon: string; data: any }) {
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      data: { Ti: e.data },
    });
    dialogRef.afterClosed().subscribe((confirm) => {
      if (confirm) {
        this.onAction(e);
      }
    });
  }

  onAction(e: { icon: string; data: any }) {
    const { icon, data } = e;
    if (icon === TABLE_CONSTS.IS_CMS_ALLOWED) {
      let ti: TechIntegratorDto = this.convertToTechIntegratorDto(data);
      if (data['Feed Worker'] === 'TVPLUS') {
        this.devConsoleService
          .allocateTi(ti)
          .pipe(takeUntilDestroyed(this.destroy))
          .subscribe((rsp) => {
            this.toastr.success(rsp.payload.message);
            this.fetchtiData();
          });
      } else {
        this.devConsoleService
          .deallocateTi(ti)
          .pipe(takeUntilDestroyed(this.destroy))
          .subscribe((rsp) => {
            this.toastr.success(rsp.payload.message);
            this.fetchtiData();
          });
      }
    }
  }

  refreshTiData() {
    this.lastFilter = null;
    this.matSearch.clear();
    this.fetchtiData();
  }

  prepareColumnNames(data: TechIntegrator[]) {
    let changedKeyData = data.map((ti) => {
      return {
        'Provider ID': ti.vcCpId,
        Country: ti.countryCode,
        'Tech Integrator': ti.cpName,
        'Is Svc': ti.isSvc,
        'Feed Worker': ti.feedWorker,
        'Bucket Name': ti.bucketName ? ti.bucketName : '',
        'Bucket Key': ti.bucketKey ? ti.bucketKey : '',
        'Is CMS Allowed': ti.feedWorker === 'TVPLUS',
      };
    });

    return changedKeyData;
  }
}
