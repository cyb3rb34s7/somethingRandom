import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidAssetsDetailComponent } from './invalid-assets-detail.component';

describe('InvalidAssetsDetailComponent', () => {
  let component: InvalidAssetsDetailComponent;
  let fixture: ComponentFixture<InvalidAssetsDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvalidAssetsDetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InvalidAssetsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
