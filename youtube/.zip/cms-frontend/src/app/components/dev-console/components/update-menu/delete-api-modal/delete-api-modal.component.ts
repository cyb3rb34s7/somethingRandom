import { Component, DestroyRef, Inject, inject } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { CustomToastrService } from '../../../../../services/custom-toastr.service';
import { DevConsoleService } from '../../../../../services/dev-console.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { deleteApi } from '../../../../../interfaces/dev-console-api-access-data-type';

@Component({
    selector: 'app-delete-api-modal',
    imports: [MatDialogModule, MatButtonModule],
    templateUrl: './delete-api-modal.component.html',
    styleUrl: './delete-api-modal.component.scss'
})
export class DeleteApiModalComponent {
  private destroy = inject(DestroyRef);

  deleteApiData: deleteApi = { menuId: 0, apiPath: '' };

  constructor(
    public dialogRef: MatDialogRef<DeleteApiModalComponent>,
    private toastr: CustomToastrService,
    private devConsoleService: DevConsoleService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.deleteApiData.menuId = this.data.data['Menu Id'];
    this.deleteApiData.apiPath = this.data.data['Api Path'];
  }
  DeleteApi(event: any) {
    this.devConsoleService
      .deleteApi(this.deleteApiData)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        this.toastr.success(result.message);
        this.dialogRef.close(true);
      });
  }
}
