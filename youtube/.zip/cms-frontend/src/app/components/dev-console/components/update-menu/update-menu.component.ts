import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AppMatTableComponent } from '../../../../mat-components/app-mat-table/app-mat-table.component';
import { Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { TABLE_CONSTS } from '../../../../constants/table-consts';
import { ICONS_CONSTS } from '../../../../constants/icons-consts';
import { ApiEditModalComponent } from './api-edit-modal/api-edit-modal.component';
import { MatDialog } from '@angular/material/dialog';
import { DevConsoleService } from '../../../../services/dev-console.service';
import { ApiAddModalComponent } from './api-add-modal/api-add-modal.component';
import { DeleteApiModalComponent } from './delete-api-modal/delete-api-modal.component';
import { createApiAcessTypeData } from '../../../../interfaces/dev-console-api-access-data-type';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { SearchFilterBoxComponent } from '../../search-filter-box/search-filter-box.component';

@Component({
    selector: 'app-update-menu',
    imports: [
        SearchFilterBoxComponent,
        AppMatTableComponent,
        MatTableModule,
        MatButtonModule,
    ],
    templateUrl: './update-menu.component.html',
    styleUrl: './update-menu.component.scss'
})
export class UpdateMenuComponent {
  private destroy = inject(DestroyRef);

  allApis: createApiAcessTypeData[] = [];
  apiTableData: any[] = [];
  filteredTableData: any[] = [];

  menuList: any[] = [];
  tableMenuList: any[] = [];

  searchFilterOptions: string[] = [
    'Api Path',
    'Menu Name',
    'Http Method',
    'User Name',
  ];

  @ViewChild(SearchFilterBoxComponent)
  matSearch: SearchFilterBoxComponent;

  constructor(
    private devConsoleService: DevConsoleService,
    private router: Router,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.fetchAllApis();
    this.fetchMenuList();
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  actionbtnClick(event: { icon: any; data: any }) {
    const { icon, data } = event;
    switch (icon) {
      case ICONS_CONSTS.TABLE_EDIT:
        this.openEditApimodal(event);
        break;
      case ICONS_CONSTS.TABLE_DELETE:
        this.openDeleteModal(event);
        break;
    }
  }

  convertDefault(value: boolean) {
    if (value) return 'Yes';
    return 'No';
  }

  fetchAllApis() {
    this.devConsoleService
      .getAllApi()
      .subscribe((res: createApiAcessTypeData[]) => {
        this.allApis = [...res];
        this.apiTableData = this.filteredTableData = this.allApis.map(
          (row: createApiAcessTypeData) => {
            const obj: any = {};
            obj['Menu Id'] = row.menuId.toString();
            obj['Menu Name'] = row.menuName;
            obj['Api Path'] = row.apiPath;
            obj['Http Method'] = row.httpMethod;
            obj['Action Type'] = row.actionType;
            obj['Is Default'] =
              row.isDefault !== null ? this.convertDefault(row.isDefault) : '';
            obj['User Name'] = row.userName;
            obj[TABLE_CONSTS.RENDER_ACTIONS_COLUMN] = [
              ICONS_CONSTS.TABLE_EDIT,
              ICONS_CONSTS.TABLE_DELETE,
            ];
            return obj;
          }
        );
      });
  }

  fetchMenuList() {
    this.devConsoleService.getAllMenu().subscribe((res: any) => {
      this.menuList = res;
    });
  }

  openEditApimodal(data: any) {
    data['menuList'] = [...this.menuList];
    const dialogRef = this.dialog.open(ApiEditModalComponent, {
      panelClass: 'assign-role-modal',
      disableClose: true,
      data: { ...data },
      width: 'auto',
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result: any) => {
        if (result.update) {
          this.refreshBtn();
        }
      });
  }

  openAddNewApiModal() {
    const dialogRef = this.dialog.open(ApiAddModalComponent, {
      panelClass: 'app-api-add-modal',
      disableClose: true,
      data: [...this.menuList],
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.matSearch.clear();
          this.fetchAllApis();
        }
      });
  }

  openDeleteModal(data: any) {
    data['menuList'] = [...this.menuList];
    const dialogRef = this.dialog.open(DeleteApiModalComponent, {
      panelClass: 'delete-api',
      disableClose: true,
      data: { ...data },
    });
    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.matSearch.clear();
          this.fetchAllApis();
        }
      });
  }
  handleSearch(value: { category: string; queryString: string }) {
    let data = this.apiTableData;
    if (
      value &&
      this.searchFilterOptions.includes(value.category) &&
      value.queryString !== ''
    ) {
      data = data.filter((menu: any) => {
        let str: string = menu[value.category];
        str = str.toLowerCase();
        return str.includes(value.queryString.toLowerCase());
      });
    }
    this.filteredTableData = data;
  }
  refreshBtn() {
    this.matSearch.clear();
    this.fetchAllApis();
  }
}
