import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusHistoryPageComponent } from './status-history-page.component';

describe('StatusHistoryPageComponent', () => {
  let component: StatusHistoryPageComponent;
  let fixture: ComponentFixture<StatusHistoryPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StatusHistoryPageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StatusHistoryPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
