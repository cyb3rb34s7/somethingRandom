import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowMissingPlatformsComponent } from './show-missing-platforms.component';

describe('ShowMissingPlatformsComponent', () => {
  let component: ShowMissingPlatformsComponent;
  let fixture: ComponentFixture<ShowMissingPlatformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowMissingPlatformsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ShowMissingPlatformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
