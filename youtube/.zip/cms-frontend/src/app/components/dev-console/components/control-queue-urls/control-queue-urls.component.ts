import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { DevConsoleService } from '../../../../services/dev-console.service';
import { Router } from '@angular/router';
import { ControlQueueUrls } from '../../../../models/control-queue-urls-model';
import { AppMatTableComponent } from '../../../../mat-components/app-mat-table/app-mat-table.component';
import { MatButton } from '@angular/material/button';
import { AppMatSimpleSearchComponent } from '../../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';
import { ICONS_CONSTS } from '../../../../constants/icons-consts';
import { TABLE_CONSTS } from '../../../../constants/table-consts';
import { StateStoreService } from '../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../constants/store-consts';
import { MatDialog } from '@angular/material/dialog';
import { CreateApiModalComponent } from './modals/create-api-modal/create-api-modal.component';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { DeleteApiModalComponent } from './modals/delete-api-modal/delete-api-modal.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SearchFilterBoxComponent } from '../../search-filter-box/search-filter-box.component';

@Component({
    selector: 'app-control-queue-urls',
    imports: [AppMatTableComponent, MatButton, SearchFilterBoxComponent],
    templateUrl: './control-queue-urls.component.html',
    styleUrl: './control-queue-urls.component.scss'
})
export class ControlQueueUrlsComponent {
  controlQueueUrlData: ControlQueueUrls[];
  tableData: any[];
  currentRegion: any;
  private destroy = inject(DestroyRef);
  searchFilterOptions: string[] = ['Country'];
  lastFilter: any = null;
  @ViewChild(SearchFilterBoxComponent)
  matSearch: SearchFilterBoxComponent;
  constructor(
    private devConsoleService: DevConsoleService,
    private router: Router,
    private storeService: StateStoreService,
    public dialog: MatDialog
  ) {
    this.currentRegion = this.storeService.getStoreState(STORE_CONSTS.REGION);
  }

  ngOnInit() {
    this.fetchControlQueueUrls();
  }

  fetchControlQueueUrls() {
    this.devConsoleService.getControlQueueUrls().subscribe((res: any) => {
      this.controlQueueUrlData = res.filter(
        (item: any) => item.region === this.currentRegion
      );
      this.tableData = this.prepareTableData(this.controlQueueUrlData);
    });
  }

  prepareTableData(data: ControlQueueUrls[]) {
    const finalData = data.map((objRole: any) => {
      const obj: any = {};
      obj['Country'] = objRole.country;
      obj['Region'] = objRole.region;
      obj['Queue Number'] = objRole.queueNumber.toString();
      obj['License Sqs Url'] = objRole.licenseURL;
      obj['Asset Sql Url'] = objRole.assetUrl;
      obj['Created At'] = objRole.createdAt;
      obj['Active Status'] = objRole.isActive ? 'Yes' : 'No';

      obj[TABLE_CONSTS.RENDER_ACTIONS_COLUMN] = [
        ICONS_CONSTS.TABLE_EDIT,
        ICONS_CONSTS.TABLE_DELETE,
      ];
      return obj;
    });

    return finalData;
  }

  handleSearch(value: { category: string; queryString: string }) {
    this.lastFilter = value;
    let data = this.prepareTableData(this.controlQueueUrlData);
    if (
      value &&
      this.searchFilterOptions.includes(value.category) &&
      value.queryString !== ''
    ) {
      data = data.filter((ti: any) => {
        let str: string = ti[value.category];
        str = str.toLowerCase();
        return str.includes(value.queryString.toLowerCase());
      });
    }
    this.tableData = data;
  }

  onAction(e: { icon: string; data: any }) {
    const { icon, data } = e;
    switch (icon) {
      case ICONS_CONSTS.TABLE_EDIT:
        this.openCreateApiModal(data);
        break;
      case ICONS_CONSTS.TABLE_DELETE:
        this.openDeleteApiModal(data);
        break;
    }
  }

  openCreateApiModal(urlData?: ControlQueueUrls) {
    const dialogRef = this.dialog.open(CreateApiModalComponent, {
      panelClass: 'create-role-modal',
      disableClose: true,
      data: urlData,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.fetchControlQueueUrls();
        }
      });
  }

  openDeleteApiModal(urlData?: any) {
    const dialogRef = this.dialog.open(DeleteApiModalComponent, {
      panelClass: 'delete-role-modal',
      disableClose: true,
      data: urlData,
    });

    dialogRef
      .afterClosed()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((result) => {
        if (result) {
          this.fetchControlQueueUrls();
        }
      });
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  refreshControlQueueUrls() {
    this.lastFilter = null;
    this.matSearch.clear();
    this.fetchControlQueueUrls();
  }
}
