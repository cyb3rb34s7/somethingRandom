import {
  ChangeDetectorRef,
  Component,
  DestroyRef,
  inject,
  Inject,
  NgModule,
} from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { AppMatInputComponent } from '../../../../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../../../../features/media-assets/assets-details/media-asset-complete-view/modals/app-mat-select/app-mat-select.component';

import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { StateStoreService } from '../../../../../../services/store/state-store.service';
import { STORE_CONSTS } from '../../../../../../constants/store-consts';
import { FormsModule, NgModel } from '@angular/forms';
import { NgClass } from '@angular/common';
import { ControlQueueUrls } from '../../../../../../models/control-queue-urls-model';
import { DevConsoleService } from '../../../../../../services/dev-console.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CustomToastrService } from '../../../../../../services/custom-toastr.service';

@Component({
    selector: 'app-create-api-modal',
    imports: [
        MatDialogModule,
        AppMatInputComponent,
        AppMatSelectComponent,
        MatButtonModule,
        MatSelectModule,
        MatRadioModule,
        FormsModule,
    ],
    templateUrl: './create-api-modal.component.html',
    styleUrl: './create-api-modal.component.scss'
})
export class CreateApiModalComponent {
  private destroy = inject(DestroyRef);
  regions: string[] = ['US', 'EU'];
  countries: string[];
  countryData: any[];
  apiData = {
    country: '',
    licenseURL: '',
    region: '',
    assetUrl: '',
    queueNumber: '',
    isActive: 'true',
  };

  update: boolean = false;

  constructor(
    private storeService: StateStoreService,
    public dialogRef: MatDialogRef<CreateApiModalComponent>,
    public devConsoleService: DevConsoleService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toastr: CustomToastrService,
    private cdref: ChangeDetectorRef
  ) {
    this.countryData = this.storeService.getStoreState(
      STORE_CONSTS.MASTER_COUNTRIES
    );
    if (data) {
      const result = this.countryData
        .map((c) =>
          c.countryCode === data['Country']
            ? `${c.countryName} (${c.countryCode})`
            : null
        )
        .find((c) => c)!;

      this.update = true;
      this.apiData.country = result;
      this.apiData.licenseURL = data['License Sqs Url'];
      this.apiData.region = data['Region'];
      this.apiData.assetUrl = data['Asset Sql Url'];
      this.apiData.queueNumber = data['Queue Number'];
      this.apiData.isActive =
        data['Active Status'] === 'Yes' ? 'true' : 'false';
    }
  }

  ngOnInit() {
    this.prepareCountryData(this.countryData);
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  prepareCountryData(data: any[]) {
    const countryData: string[] = data.map(
      (country) => `${country.countryName} (${country.countryCode})`
    );
    this.countries = countryData;
  }

  submit() {
    const dataToSend: ControlQueueUrls = {
      country: this.apiData.country.substring(
        this.apiData.country.lastIndexOf('(') + 1,
        this.apiData.country.lastIndexOf(')')
      ),
      licenseURL: this.trimData(this.apiData.licenseURL),
      region: this.apiData.region,
      assetUrl: this.trimData(this.apiData.assetUrl),
      queueNumber: Number(this.apiData.queueNumber),
      isActive: this.apiData.isActive === 'true' ? true : false,
    };

    if (this.update) {
      this.updateApi(dataToSend);
    } else {
      this.createNewApi(dataToSend);
    }
  }

  setActiveStatus(value: string) {
    this.apiData.isActive = value;
  }

  createNewApi(dataToSend: ControlQueueUrls) {
    this.devConsoleService
      .insertControlQueueUrl(dataToSend)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  updateApi(dataToSend: ControlQueueUrls) {
    this.devConsoleService
      .updateControlQueueUrl(dataToSend)
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res) => {
        this.toastr.success(res.message);
        this.dialogRef.close(true);
      });
  }

  isAllFieldsFilled(): boolean {
    if (!this.update) {
      return Object.keys(this.apiData).every(
        (key) =>
          key === 'queueNumber' ||
          (this.apiData[key as keyof typeof this.apiData] !== null &&
            this.trimData(this.apiData[key as keyof typeof this.apiData]) !==
              '')
      );
    } else {
      return Object.values(this.apiData).every(
        (value) => value !== null && this.trimData(value) !== ''
      );
    }
  }

  trimData(data: string): string {
    return data.trim();
  }
}
