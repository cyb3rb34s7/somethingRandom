import { Component, DestroyRef, inject, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AppMatTableComponent } from '../../../../mat-components/app-mat-table/app-mat-table.component';
import { InvalidAsset } from '../../../../models/invalid-asset-model';
import { DevConsoleService } from '../../../../services/dev-console.service';
import { Router } from '@angular/router';
import { SIDE_NAV_ROUTES } from '../../../../constants/app-consts';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { TABLE_CONSTS } from '../../../../constants/table-consts';
import { MatIconModule } from '@angular/material/icon';
import { SearchFilterBoxComponent } from '../../search-filter-box/search-filter-box.component';
import { ExeljsService } from '../../../../services/exeljs.service';

@Component({
    selector: 'app-invalid-license-assets-detail',
    imports: [
        AppMatTableComponent,
        MatButtonModule,
        MatTableModule,
        MatIconModule,
        MatButtonModule,
        SearchFilterBoxComponent,
    ],
    templateUrl: './invalid-license-assets-detail.component.html',
    styleUrl: './invalid-license-assets-detail.component.scss'
})
export class InvalidLicenseAssetsDetailComponent {
  tableData: any[] = [];
  InvalidLicenseAssetsData: any[];
  searchFilterOptions: string[] = [
    'Program Id',
    'Provider Id',
    'Vod Key',
    'Country',
  ];

  keyMapping: any = {
    'Program Id': 'programId',
    'Provider Id': 'contentProvider',
    'Vod Key': 'vodKey',
    Country: 'countryCode',
  };
  lastFilter: any = null;
  @ViewChild(SearchFilterBoxComponent)
  matSearch: SearchFilterBoxComponent;
  constructor(
    private devConsoleService: DevConsoleService,
    private router: Router,
    private exlSvc: ExeljsService
  ) {}
  private destroy = inject(DestroyRef);

  ngOnInit() {
    this.fetchInvalidLicenseAssets();
  }

  fetchInvalidLicenseAssets() {
    this.devConsoleService
      .getInValidLicenseAssets()
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((res: any) => {
        this.InvalidLicenseAssetsData = res;
        const sortedData = this.InvalidLicenseAssetsData.sort((a, b) =>
          a.programId === b.programId
            ? new Date(b.errorDatetime).getTime() -
              new Date(a.errorDatetime).getTime()
            : a.programId - b.programId
        );
        this.tableData = this.prepareTableData(sortedData);
      });
  }

  onBackClick() {
    this.router.navigate([SIDE_NAV_ROUTES.CONSOLE.route_link]);
  }

  prepareTableData(data: any[]) {
    const transformedData = [];
    let currentGroup = null;

    for (const item of data) {
      if (!currentGroup || currentGroup.programId !== item.programId) {
        currentGroup = { ...item, [TABLE_CONSTS.RENDER_EMBEDDED_DETAILS]: [] };
        transformedData.push(currentGroup);
      } else {
        currentGroup[TABLE_CONSTS.RENDER_EMBEDDED_DETAILS].push(item);
      }
    }

    const transformedDataWithFormattedKeys = transformedData.map((item) => ({
      [TABLE_CONSTS.RENDER_EMBEDDED_DETAILS]: item[
        TABLE_CONSTS.RENDER_EMBEDDED_DETAILS
      ].map((detail: InvalidAsset) => ({
        'Program Id': detail.programId,
        'Provider Id': detail.contentProvider,
        'Vod Key': detail.vodKey,
        Country: detail.countryCode,
        Error: detail.error,
        Date:
          detail.errorDatetime.split(' ')[0] +
          ' ' +
          detail.errorDatetime.split(' ')[1].split('.')[0],
      })),
      'Program Id': item.programId,
      'Provider Id': item.contentProvider,
      'Vod Key': item.vodKey,
      Country: item.countryCode,
      Error: item.error,
      Date:
        item.errorDatetime.split(' ')[0] +
        ' ' +
        item.errorDatetime.split(' ')[1].split('.')[0],
    }));
    return transformedDataWithFormattedKeys;
  }

  handleSearch(value: { category: string; queryString: string }) {
    const keyCategory: string = this.keyMapping[value.category];
    let data = this.InvalidLicenseAssetsData;

    if (
      value &&
      this.searchFilterOptions.includes(value.category) &&
      value.queryString !== ''
    ) {
      data = data.filter((ti: any) => {
        let str: string = ti[keyCategory];
        str = str.toLowerCase();
        return str.includes(value.queryString.toLowerCase());
      });
    }

    this.tableData = this.prepareTableData(data);
  }

  refreshInvalidLicenseAssets() {
    this.lastFilter = null;
    this.matSearch.clear();
    this.fetchInvalidLicenseAssets();
  }

  exportExcel() {
    const { exportData, rowsToColor } = this.sortDataForExcel(this.tableData);
    const rows = [];
    rows.push(Object.keys(exportData[0]));
    exportData.forEach((d) => {
      rows.push(Object.values(d));
    });
    this.exlSvc.create('Invalid Assets', rows, 'Invalid_Assets', [
      { i: 1, c: 'D3d3d3' },
      ...rowsToColor.map((r) => ({ i: r, c: 'FFFF00' })),
    ]);
  }

  sortDataForExcel(data: any[]) {
    let exportData: any[] = [];
    let rowNumber = 1;
    let rowsToColor: number[] = [];
    for (let asset of data) {
      exportData.push(this.extractRowData(asset));
      rowNumber += 1;
      rowsToColor.push(rowNumber);
      if (Array.isArray(asset['DETAILS']) && asset['DETAILS'].length > 0) {
        for (let assetHistory of asset['DETAILS']) {
          exportData.push(this.extractRowData(assetHistory));
          rowNumber += 1;
        }
      }
    }
    return { exportData, rowsToColor };
  }

  extractRowData(asset: any) {
    return {
      'Program Id': asset['Program Id'],
      'Provider Id': asset['Provider Id'],
      Country: asset['Country'],
      'Vod Key': asset['Vod Key'],
      Date: asset['Date'],
      Error: asset['Error'],
    };
  }
}
