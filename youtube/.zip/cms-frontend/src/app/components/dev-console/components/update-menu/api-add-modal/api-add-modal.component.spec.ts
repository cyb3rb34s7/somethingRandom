import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApiAddModalComponent } from './api-add-modal.component';

describe('ApiAddModalComponent', () => {
  let component: ApiAddModalComponent;
  let fixture: ComponentFixture<ApiAddModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApiAddModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ApiAddModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
