import { Component, Input } from '@angular/core';
import { AppMatTableComponent } from '../../../../../mat-components/app-mat-table/app-mat-table.component';

@Component({
    selector: 'app-missing-data-component',
    imports: [AppMatTableComponent],
    templateUrl: './missing-data-component.component.html',
    styleUrl: './missing-data-component.component.scss'
})
export class MissingDataComponentComponent {
  @Input() heading!: string;
  @Input() missingChanges!: any;
}
