import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { SimpleMatSelectComponent } from '../../../features/media-assets/asset-search/simple-mat-select/simple-mat-select.component';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AppMatSimpleSearchComponent } from '../../../mat-components/app-mat-simple-search/app-mat-simple-search.component';

@Component({
    selector: 'app-search-filter-box',
    imports: [
        CommonModule,
        SimpleMatSelectComponent,
        AppMatSimpleSearchComponent,
        MatButtonModule,
        MatTooltipModule,
    ],
    templateUrl: './search-filter-box.component.html',
    styleUrl: './search-filter-box.component.scss'
})
export class SearchFilterBoxComponent {
  @ViewChild(AppMatSimpleSearchComponent)
  matInput: AppMatSimpleSearchComponent;

  @Input() placeholder: string = 'Enter search item';

  @Input() searchFilterOptions: string[] = [];

  @Output() searchEmitter = new EventEmitter<{
    category: string;
    queryString: string;
  }>();

  currentFilter: string = '';

  currentSearchString: string = '';

  ngOnInit() {
    this.currentFilter = this.searchFilterOptions[0];
  }

  handleSearchStringChange(newSearchString: string): void {
    if (
      newSearchString.length === 0 &&
      newSearchString?.trim() !== this.currentSearchString?.trim()
    ) {
      this.currentSearchString = newSearchString;
      this.handleSearch();
    } else {
      this.currentSearchString = newSearchString;
    }
  }

  handleSearch(): void {
    this.searchEmitter.emit({
      category: this.currentFilter,
      queryString: this.currentSearchString.trim(),
    });
  }

  clear() {
    this.currentSearchString = '';
    this.matInput.clear();
    this.searchEmitter.emit({
      category: this.currentFilter,
      queryString: this.currentSearchString,
    });
  }

  @HostListener('keydown', ['$event'])
    onKeydown(event: KeyboardEvent): void {
      if (event.key === 'Enter' && this.currentSearchString !== '') {
        this.handleSearch();
      }
    }
}
