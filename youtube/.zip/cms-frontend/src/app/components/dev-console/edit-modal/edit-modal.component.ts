import { ChangeDetectorRef, Component, Inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogModule,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { MatRadioButton, MatRadioGroup } from '@angular/material/radio';
import { AppMatInputComponent } from '../../../mat-components/app-mat-input/app-mat-input.component';
import { AppMatSelectComponent } from '../../../mat-components/app-mat-select/app-mat-select.component';

@Component({
    selector: 'app-edit-modal',
    imports: [
        AppMatInputComponent,
        MatDialogModule,
        MatButtonModule,
        MatDialogClose,
        MatButtonModule,
        FormsModule,
        AppMatInputComponent,
        MatRadioButton,
        MatRadioGroup,
        MatDialogContent,
        MatDialogTitle,
        MatDialogClose,
        MatDialogActions,
        MatDialogClose,
        AppMatSelectComponent,
    ],
    templateUrl: './edit-modal.component.html',
    styleUrl: './edit-modal.component.scss'
})
class EditModalComponent {
  title: string = '';

  orignalValues: { [key: string]: string } = {};
  values: { [key: string]: string } = {};

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { data: editModalInputType[]; title: string; type: string },
    public dialogRef: MatDialogRef<EditModalComponent>,
    private cdref: ChangeDetectorRef
  ) {
    this.title = data?.title ?? '';
    for (let row of data.data) {
      this.orignalValues[row.fieldName] = row.defaultValue;
      this.values[row.fieldName] = row.defaultValue;
    }
  }

  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }

  triggerAction() {
    this.dialogRef.close(this.values);
  }

  checkForChangesAndValidation(): boolean {
    let hasChanges: boolean = false;
    Object.keys(this.values).forEach((key: string) => {
      let checkValidation: boolean = this.checkForValidInput(key);
      if (
        this.values[key]?.trim() !== this.orignalValues[key] &&
        checkValidation
      ) {
        hasChanges = true;
      }
    });
    return hasChanges;
  }

  checkForValidInput(key: string) {
    let fieldEntry = this.data.data.find((entry) => entry.fieldName === key);
    if (fieldEntry) {
      if (fieldEntry?.inputType ?? 'string' === 'string') {
        if (!(fieldEntry?.isNullAllowed ?? false) && this.values[key] == null) {
          return false;
        } else {
          return fieldEntry?.isEmptyStringAllowed ?? false
            ? true
            : this.values[key].trim() !== '';
        }
      }
      return false;
    }
    return false;
  }
}

type editModalInputType = {
  fieldName: string;
  isEditable: boolean;
  type: 'input' | 'radio' | 'select';
  defaultValue: string;
  options: string[];
  isNullAllowed?: boolean;
  isEmptyStringAllowed?: boolean;
  inputType?: 'string' | 'number';
};

export { EditModalComponent, editModalInputType };
