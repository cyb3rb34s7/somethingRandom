import { DevStatusHistoryModel } from '../../models/dev-status-history';

function prepareExpandedRowsForDevStatusHistory(history: any) {
  const data: any[] = [];

  history.map((historyChange: DevStatusHistoryModel) => {
    const obj: any = {};
    obj['Change Date'] = historyChange.date.split(' ')[0];
    obj['Change time'] = historyChange.date.split(' ')[1].split('.')[0];
    obj['New Status'] = historyChange.newStatus;
    obj['Old Status'] = historyChange.oldStatus;
    obj['Last Updated By'] = historyChange.updatedBy;
    obj['Master State'] = historyChange.masterState;

    data.push(obj);
  });
  return data;
}
export { prepareExpandedRowsForDevStatusHistory };
