import { Component } from '@angular/core';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { pageMap } from '../../interfaces/dev-console-routes-data';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-dev-console',
    imports: [MatButtonModule, MatTooltipModule],
    templateUrl: './dev-console.component.html',
    styleUrl: './dev-console.component.scss'
})
export class DevConsoleComponent {
  constructor(private router: Router) {}

  appRoutes = SIDE_NAV_ROUTES;

  pageMap: pageMap = {
    'invalid-asset': {
      title: SIDE_NAV_ROUTES.INVALID_ASSETS.title,
      description: 'Get the list of invalid assets ',
      imageSrc: 'assets/icons/svgs/invalidAsset.png',
      imageAlt: SIDE_NAV_ROUTES.INVALID_ASSETS.title,
      routeTo: SIDE_NAV_ROUTES.INVALID_ASSETS.route_link,
    },
    'invalid-licence-assets': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/invalidlicenceAsset.png',
      title: SIDE_NAV_ROUTES.INVALID_LICENSE_ASSETS.title,
      routeTo: SIDE_NAV_ROUTES.INVALID_LICENSE_ASSETS.route_link,
      description: ' ',
    },
    'tech-integrator-management': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/techIntegratorManagement.PNG',
      title: SIDE_NAV_ROUTES.TECH_INTEGRATOR_MANAGEMENT.title,
      routeTo: SIDE_NAV_ROUTES.TECH_INTEGRATOR_MANAGEMENT.route_link,
      description: ' ',
    },
    'api-access-control': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/accessControlManagement.png',
      title: SIDE_NAV_ROUTES.UPDATE_MENU.title,
      routeTo: SIDE_NAV_ROUTES.UPDATE_MENU.route_link,
      description: ' ',
    },
    'control-queue-urls': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/controlQueues.png',
      title: SIDE_NAV_ROUTES.CONTROL_QUEUE_URLS.title,
      routeTo: SIDE_NAV_ROUTES.CONTROL_QUEUE_URLS.route_link,
      description: ' ',
    },
    'status-history-page': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/assetStatusHistory.png',
      title: SIDE_NAV_ROUTES.ASSET_STATUS_HISTORY_CONSOLE.title,
      routeTo: SIDE_NAV_ROUTES.ASSET_STATUS_HISTORY_CONSOLE.route_link,
      description: ' ',
    },
    'stg-prd-asset-comparison': {
      imageAlt: '',
      imageSrc: 'assets/icons/svgs/stageProdComparasion.PNG',
      title: SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.title,
      routeTo: SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.route_link,
      description: '',
    }
  };

  pageKeys = Object.keys(this.pageMap);

  navigateTo(route: string) {
    this.router.navigate([route]);
  }

  ngOnInit() {}
}
