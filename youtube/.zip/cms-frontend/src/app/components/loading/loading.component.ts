import { Component, HostBinding, inject } from '@angular/core';
import { STORE_CONSTS } from '../../constants/store-consts';
import { StateStoreService } from '../../services/store/state-store.service';
import { DestroyRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { throttleTime } from 'rxjs';

@Component({
    selector: 'app-loading',
    imports: [],
    templateUrl: './loading.component.html',
    styleUrl: './loading.component.scss'
})
export class LoadingComponent {
  @HostBinding('class.visible') isVisible = false;

  private destroy = inject(DestroyRef);

  constructor(private storeService: StateStoreService) {
    this.storeService.stateStore[STORE_CONSTS.LOADING]
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((bVal: boolean) => {
        setTimeout(() => {
          this.isVisible = bVal;
        }, 0);
      });
  }
}
