import { Component } from '@angular/core';
import { apis } from '../../constants/api-consts';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { environment } from '../../../environments/environment';

@Component({
    selector: 'app-logout',
    imports: [],
    templateUrl: './logout.component.html',
    styleUrl: './logout.component.scss'
})
export class LogoutComponent {
  constructor() {
    //window.location.replace(SIDE_NAV_ROUTES.LOGOUT.route_link);
    window.location.replace(environment.rootEndpoint + apis.logoutUrl);
  }
}
