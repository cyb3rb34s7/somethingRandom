import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import {
  MatDatepicker,
  MatDatepickerModule,
} from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

@Component({
    selector: 'app-date-range-selector',
    imports: [
        MatDatepickerModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        FormsModule,
    ],
    templateUrl: './date-range-selector.component.html',
    styleUrl: './date-range-selector.component.scss'
})
export class DateRangeSelectorComponent {
  private _range: any[];

  @Input() disabled: boolean;

  @Input() set range(r: any[]) {
    this._range = r;
    this.df = new Date(r[0]);
    this.dt = new Date(r[1]);
  }
  get range(): any[] {
    return this._range;
  }

  @Input() fromLabel: string;

  @Input() toLabel: string;

  @Output() fromChange: EventEmitter<any> = new EventEmitter();

  @Output() toChange: EventEmitter<any> = new EventEmitter();

  df: Date | null;

  dt: Date | null;

  handleClear(e: Event) {
    e.stopImmediatePropagation();
  }
}
