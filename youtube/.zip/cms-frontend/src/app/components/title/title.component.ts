import { Component, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { SIDE_NAV_ROUTES } from '../../constants/app-consts';
import { Location } from '@angular/common';

@Component({
  selector: 'app-title',
  templateUrl: './title.component.html',
  styleUrl: './title.component.scss',
})
export class TitleComponent {
  private destroy = inject(DestroyRef);

  title: string = '';

  arrRoutes = Object.values(SIDE_NAV_ROUTES);

  constructor(private router: Router, private location: Location) {}

  ngOnInit() {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .pipe(takeUntilDestroyed(this.destroy))
      .subscribe((event) => {
        const currentPath = this.location.path();
        const activeRoute = this.arrRoutes.find(
          (objRoute) => '/' + objRoute.route_link === currentPath
        );
        if (activeRoute) {
          this.title = activeRoute.title;
        }
      });
  }
}
