import { CommonModule } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  inject,
  ViewChild,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { AppMatSelectComponent } from '../../../mat-components/app-mat-select/app-mat-select.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ProgressBarModalComponent } from '../progress-bar-modal/progress-bar-modal.component';
import { Router } from '@angular/router';
import {
  addTimeQueryParam,
  AssetService,
} from '../../../services/asset.service';
import { Asset } from '../../../models/asset-model';
import { plainToInstance } from 'class-transformer';
import { environment } from '../../../../environments/environment';
import { CustomToastrService } from '../../../services/custom-toastr.service';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    selector: 'app-downloads-and-imports',
    imports: [
        MatMenuModule,
        MatButtonModule,
        CommonModule,
        MatProgressBarModule,
        MatTooltipModule,
    ],
    templateUrl: './downloads-and-imports.component.html',
    styleUrl: './downloads-and-imports.component.scss'
})
export class DownloadsAndImportsComponent {
  importsAndDownloads: any = [
    'Import Updates',
    'Download Specs',
    'Download Import Templates',
  ];

  fileToUpload: any;

  progress = 0;

  existingImportData: Asset[];
  private destroy = inject(DestroyRef);

  @ViewChild('file') fileInp: ElementRef;

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private assetService: AssetService,
    private toastr: CustomToastrService
  ) {}

  ngOnInit() {}

  handleFileInput(event: any) {
    let files: FileList = event.target.files;
    this.fileToUpload = files.item(0);

    let formData = new FormData();

    formData.append('file', this.fileToUpload);
    this.openProgressBarModal(formData);
  }

  openProgressBarModal(data: any) {
    const dialogRef = this.dialog.open(ProgressBarModalComponent, {
      data: data,
      panelClass: 'progress-bar-modal',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'Upload Success') {
        this.router.navigate(['/media-assets/imported-assets']);
      }
    });
  }

  routeData() {
    this.router.navigate(['/media-assets/imported-assets']);
  }

  downloadImportTemplates() {
    this.saveFile('ImportTemplate.xlsx');
  }

  private saveFile(fileName: string) {
    this.assetService.downloadSpecs(fileName).subscribe((blob) => {
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(objectUrl);
      this.toastr.success('Sample File Downloaded Successfully!');
    });
  }

  decisionForImport() {
    this.assetService.getExistingUpdates().subscribe((res: any) => {
      if (res.length > 0) {
        this.existingImportData = plainToInstance<Asset, []>(Asset, res);
        this.assetService.existingUpdates = this.existingImportData;
        this.routeData();
      } else {
        this.assetService.existingUpdates = [];
        this.fileInp.nativeElement.click();
      }
    });
  }
}
