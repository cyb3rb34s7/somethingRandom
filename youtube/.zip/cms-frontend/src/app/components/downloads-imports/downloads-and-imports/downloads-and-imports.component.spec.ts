import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadsAndImportsComponent } from './downloads-and-imports.component';

describe('DownloadsAndImportsComponent', () => {
  let component: DownloadsAndImportsComponent;
  let fixture: ComponentFixture<DownloadsAndImportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DownloadsAndImportsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DownloadsAndImportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
