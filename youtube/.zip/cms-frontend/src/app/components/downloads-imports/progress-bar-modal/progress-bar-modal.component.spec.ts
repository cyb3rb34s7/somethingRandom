import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressBarModalComponent } from './progress-bar-modal.component';

describe('ProgressBarModalComponent', () => {
  let component: ProgressBarModalComponent;
  let fixture: ComponentFixture<ProgressBarModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProgressBarModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProgressBarModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
