import { Component, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialogModule,
} from '@angular/material/dialog';
import { AssetService } from '../../../services/asset.service';
import { interval, Subscription, take } from 'rxjs';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { Asset } from '../../../models/asset-model';
import { plainToInstance } from 'class-transformer';

@Component({
    selector: 'app-progress-bar-modal',
    imports: [
        MatProgressBarModule,
        CommonModule,
        MatButtonModule,
        MatDialogModule,
    ],
    templateUrl: './progress-bar-modal.component.html',
    styleUrl: './progress-bar-modal.component.scss'
})
export class ProgressBarModalComponent {
  constructor(
    public dialofRef: MatDialogRef<ProgressBarModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private assetService: AssetService
  ) {}

  progress = 0;

  interval: any;

  subscription: Subscription;

  progressInterval: Subscription | null = null;

  showProgressBar = false;

  existingImportData: Asset[];

  ngOnInit() {
    this.uploadFileToActivity(this.data);
  }

  uploadFileToActivity(formData: FormData) {
    this.showProgressBar = true;

    this.progress = 0;

    this.progressInterval = interval(100).subscribe({
      next: () => {
        if (this.progress < 95) {
          this.progress += 1;
        }
      },
    });

    this.assetService.postFile(formData).subscribe(
      (res: any) => {
        if (res) {
          this.existingImportData = plainToInstance<Asset, []>(Asset, res);
          this.assetService.existingUpdates = this.existingImportData;
          this.setProgressSuccess();
        }
      },
      (err: any) => {
        this.setProgressFailure();
      }
    );
  }

  setProgressSuccess() {
    if (this.progressInterval) {
      this.progressInterval.unsubscribe();
    }
    this.progress = 100;

    this.dialofRef.close('Upload Success');
  }

  setProgressFailure() {
    if (this.progressInterval) {
      this.progressInterval.unsubscribe();
    }

    this.dialofRef.close('Upload Failed');
  }

  cancelUpload() {
    if (this.progressInterval) {
      this.progressInterval.unsubscribe();
    }
    this.dialofRef.close('Upload Cancelled');
  }
}
