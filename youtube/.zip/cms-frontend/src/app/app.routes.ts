import { Routes } from '@angular/router';
import { SIDE_NAV_ROUTES } from './constants/app-consts';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { MediaAssetsComponent } from './features/media-assets/media-assets.component';
import { ChangeHistoryComponent } from './features/change-history/change-history.component';
import { UserManagementComponent } from './features/user-management/user-management.component';
import { HelpNSupportComponent } from './features/help-n-support/help-n-support.component';
import { LogoutComponent } from './components/logout/logout.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { MediaAssetCompleteViewComponent } from './features/media-assets/assets-details/media-asset-complete-view/media-asset-complete-view.component';
import { SingleAssetLicenseHistoryComponent } from './features/media-assets/assets-details/single-asset-license-history/single-asset-license-history.component';
import { SingleAssetMetadataHistoryComponent } from './features/media-assets/assets-details/single-asset-metadata-history/single-asset-metadata-history.component';
import { AssetsImportedComponent } from './features/assets-imported/assets-imported.component';
import { superUserGuard } from './route-guards/super-user-route.guard';
import { assetDetailGuard } from './route-guards/asset-details-route.guard';
import { AuthGuard } from './route-guards/auth.guard';
import { DevConsoleComponent } from './components/dev-console/dev-console.component';
import { InvalidAssetsDetailComponent } from './components/dev-console/components/invalid-assets-detail/invalid-assets-detail.component';
import { InvalidLicenseAssetsDetailComponent } from './components/dev-console/components/invalid-license-assets-detail/invalid-license-assets-detail.component';
import { TechIntegratorManagementComponent } from './components/dev-console/components/tech-integrator-management/tech-integrator-management.component';
import { devUserRouteGuard } from './route-guards/dev-user-route.guard';
import { UpdateMenuComponent } from './components/dev-console/components/update-menu/update-menu.component';
import { ControlQueueUrlsComponent } from './components/dev-console/components/control-queue-urls/control-queue-urls.component';
import { AssetStatusHistoryComponent } from './components/dev-console/components/status-history-page/status-history-page.component';
import { StgPrdAssetComparisonComponent } from './components/dev-console/components/stg-prd-asset-comparison/stg-prd-asset-comparison.component';
import { EvaluationAssetsComponent } from './features/evaluation-assets/evaluation-assets.component';
import { EvaluationAssetsDetailComponent } from './features/evaluation-assets/evaluation-assets-details/evaluation-assets-details.component';

export const routes: Routes = [
  {
    path: SIDE_NAV_ROUTES.BLANK.route_link,
    pathMatch: 'full',
    redirectTo: SIDE_NAV_ROUTES.DASHBOARD.route_link,
  },
  {
    path: SIDE_NAV_ROUTES.DASHBOARD.route_link,
    pathMatch: 'full',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.MEDIA.route_link,
    pathMatch: 'full',
    component: MediaAssetsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.MEDIA_DETAILED_VIEW.route_link,
    pathMatch: 'full',
    component: MediaAssetCompleteViewComponent,
    canActivate: [AuthGuard, assetDetailGuard],
  },
  {
    path: SIDE_NAV_ROUTES.LICENSE_HISTORY.route_link,
    pathMatch: 'full',
    component: SingleAssetLicenseHistoryComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.METADATA_HISTORY.route_link,
    pathMatch: 'full',
    component: SingleAssetMetadataHistoryComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.HISTORY.route_link,
    pathMatch: 'full',
    component: ChangeHistoryComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.USER.route_link,
    pathMatch: 'full',
    component: UserManagementComponent,
    canActivate: [AuthGuard, superUserGuard],
  },
  {
    path: SIDE_NAV_ROUTES.HELP.route_link,
    pathMatch: 'full',
    component: HelpNSupportComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.LOGOUT.route_link,
    pathMatch: 'full',
    component: LogoutComponent,
  },
  {
    path: SIDE_NAV_ROUTES.USER_PROFILE.route_link,
    pathMatch: 'full',
    component: UserProfileComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.IMPORTED_ASSETS.route_link,
    pathMatch: 'full',
    component: AssetsImportedComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.CONSOLE.route_link,
    pathMatch: 'full',
    component: DevConsoleComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.INVALID_ASSETS.route_link,
    pathMatch: 'full',
    component: InvalidAssetsDetailComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.INVALID_LICENSE_ASSETS.route_link,
    pathMatch: 'full',
    component: InvalidLicenseAssetsDetailComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.TECH_INTEGRATOR_MANAGEMENT.route_link,
    pathMatch: 'full',
    component: TechIntegratorManagementComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.UPDATE_MENU.route_link,
    component: UpdateMenuComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.CONTROL_QUEUE_URLS.route_link,
    pathMatch: 'full',
    component: ControlQueueUrlsComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.ASSET_STATUS_HISTORY_CONSOLE.route_link,
    pathMatch: 'full',
    component: AssetStatusHistoryComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.STG_PRD_ASSET_COMPARISON.route_link,
    pathMatch: 'full',
    component: StgPrdAssetComparisonComponent,
    canActivate: [AuthGuard, devUserRouteGuard],
  },
  {
    path: SIDE_NAV_ROUTES.EVALUATION.route_link,
    pathMatch: 'full',
    component: EvaluationAssetsComponent,
    canActivate: [AuthGuard],
  },
  {
    path: SIDE_NAV_ROUTES.EVALUATION_DETAILED_VIEW.route_link,
    pathMatch: 'full',
    component: EvaluationAssetsDetailComponent,
    canActivate: [AuthGuard],
  },
];
