import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppHeaderComponent } from './components/app-header/app-header.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { FeatureContainerComponent } from './components/feature-container/feature-container.component';
import { LoadingComponent } from './components/loading/loading.component';

import { HttpErrorResponse } from '@angular/common/http';
import { plainToInstance } from 'class-transformer';
import { Country } from './models/country-model';
import { STORE_CONSTS } from './constants/store-consts';
import { UserService } from './services/user.service';
import { StateStoreService } from './services/store/state-store.service';
import { AuthService } from './services/auth.service';
import { DestroyRef, inject } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [
    AppHeaderComponent,
    SideNavComponent,
    FeatureContainerComponent,
    LoadingComponent,
  ],
})
export class AppComponent implements OnInit {
  masterCountries: Country[] = [];
  countries: string[] = [];
  isAuthenticated = false;

  private destroy = inject(DestroyRef);

  constructor(
    private userService: UserService,
    private storeService: StateStoreService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    sessionStorage.removeItem('lastSearch');
    sessionStorage.removeItem('lastSearchCategory');

    this.verifyAuthenticationAndInitialize();
  }

  private verifyAuthenticationAndInitialize() {
    this.authService.verifySession().subscribe({
      next: (isAuthenticated: boolean) => {
        if (isAuthenticated) {
          this.isAuthenticated = true;
          this.fetchMasterCountries();
        }
      },
      error: () => {},
    });
  }

  fetchMasterCountries() {
    this.userService.getCountries().subscribe({
      next: (res: any) => {
        this.masterCountries = plainToInstance<Country, []>(Country, res);
        for (let item of this.masterCountries) {
          this.countries.push(item.countryName);
        }
        this.storeService.setStoreState(
          STORE_CONSTS.MASTER_COUNTRIES,
          plainToInstance<Country, {}>(Country, res)
        );
      },
      error: (error: HttpErrorResponse) => {},
    });
  }
}
