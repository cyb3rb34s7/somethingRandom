# TVPlus CMS Admin 
TVPlus CMS -> Asset Management & status tracking <br>
Admin development consists of
- Frontend -> Angular 
- Backend -> Springboot server

# Branch Policy

Branch Meaning
Branch Name | Description
--- | ---
develop (default)| - Default branch <br>- Dev code
release	| - Latest stage code
main	| - Latest production code
feature-{jira_number}-{description}	| - When developing feature, create feature branch from develop branch <br>- After done to develop, merge feature branch to develop branch
urgent-{jira_number}-{description}	| - When defect is found from stage area, create urgent branch from release branch <br>- After fix the defect, merge urgent branch to release and develop branch
hotfix-{jira_number}-{description}	| - When defect is found from production area, create hotfix branch from master branch <br>- After fix the defect, merge master and develop branch


## Links

- [JIRA](https://jira.sec.samsung.net/projects/TVPCMS)
- [Confluence](https://confluence.sec.samsung.net/display/TVPS/04.+TV+Plus+CMS)

## Build Project on Local Environment

Prerequistes for building Admin on local environment requires the following:
	1) Node (Version 20)
	2) Npm (Version 10)
	3) Angular CLI (Version 17), can be installed via: npm install -g @angular/cli@17.0.0
	3) JDK 17
	4) Intellij Idea IDE
	5) Visual Studio Code

	-->Pull the code form develop branch.

Frontend build: Open cms-frontend folder in Visual Studio Code
	1) npm install
 	2) In this file path as specified :- src\environments\environment.development.ts
		Replace this value :  rootEndpoint: 'http://localhost:8080/',
	3) ng serve
	 cms-frontend will be running on port 4200(localhost). 

Backend build: Open cms-backend folder in Intellij IDE
	1) Install Lombok plugin in Intellij IDE
	2) In build.gradle file,2 things need to be commented:
		--> In plugins part, comment the line with id:org.sonarqube
		--> Comment down whole sonarqube task
  	3) Update this in SecurityConfig to run on local :  config.setAllowedOriginPatterns(List.of(localhostURL,"*"));
	4) Gradle dependencies will be synced, or you can manually sync them using gradle icon in build.gradle file
	5) Need to create an application-local.properties under folder src/main/resources/ and put the values for the same in that. Please fill the required environemnts with values of your local db 
	
server.url=http://localhost:8080/login
ims.access.key=
ims.secret.key=
ims.url=https://imsstg.samsungcloud.tv
ims.api.authRedirect=/Auth/Authorize
ims.svc=TVCMS
ims.svc.url=http://localhost:8080/token
ims.domain=https://imsstg.internetat.tv
ims.auth.url=/openapi/system/asso/user/auth
ims.user.url=/openapi/system/asso/user
ims.all.user.url=/openapi/system/asso/user/all
ims.seedkey.url=/openapi/system/asso/auth/seedkey
ims.authtoken.url=/openapi/system/asso/auth/authtoken
svc.redirect.url=http://localhost:4200/
server.security.enabled=true
spring.datasource.url=
spring.datasource.username=
spring.datasource.password=
spring.datasource.properties=connectTimeout=10000&socketTimeout=10000&useSSL=false&allowMultiQueries=true&useUnicode=yes&characterEncoding=UTF-8
mybatis.configuration-properties.schema-name=public
IMS_CONNECT_TIMEOUT=10000;
IMS_READ_TIMEOUT=10000;
REGION=
US_ASSET_OPENAPI_URL=
EU_ASSET_OPENAPI_URL=
US_HISTORY_OPENAPI_URL=
EU_HISTORY_OPENAPI_URL=
US_SYNC_QUEUE_URL=
EU_SYNC_QUEUE_URL=
US_EXIF_URL= 
EU_EXIF_URL= 
US_REGION= 
EU_REGION= 
US_BUCKET_NAME= 
US_BUCKET_NAME_CMS= 
EU_BUCKET_NAME= 
EU_BUCKET_NAME_CMS= 
US_CLOUD_FRONT_URL=
EU_CLOUD_FRONT_URL=
US_UPLOAD_PATH=
EU_UPLOAD_PATH=
EU_ASSET_OPENAPI_URL_NLB=
US_ASSET_OPENAPI_URL_NLB= 
US_CLOUD_FRONT_URL_CMS=https://dlmntzomumu75.cloudfront.net
EU_CLOUD_FRONT_URL_CMS=https://dlmntzomumu75.cloudfront.net
CMS_VOD_CONTENT_LICENSE_DYNAMO= 
CMS_VOD_CONTENT_DYNAMO= 
DEPLOYMENT_ENV=
US_VOD_STATUS_UPDATER_SQS_URL=
EU_VOD_STATUS_UPDATER_SQS_URL=
DEV_EMAILS=
localhost.url=http://localhost:4200/
APP_VERSION=1.2.0
SMF_SPEC_FILENAME=SMF_TVPlus_VOD_1.71.docx
ROLE_ARN=
CMS_NOTIFICATION_SVR_URL=
CMS_NOTIFICATION_API=
BEARER_TOKEN=
ALMANSY_ALARM_URL=
ALMANSY_RESOURCE_NAME=

	
	6) In application.properties, Set env=local, spring.profiles.active=local
	7) In the project structure, right click on cms-backend/src/main/java/CMSAdminApplication.java and hit Run CMSAdminApplication.main()

Generation of session token:
1) try on browser: http://localhost:8080/token, it will redirect to imsstg.samsungcloud.tv, hit on TVPlus CMS service and it will redirect to DEV Portal.
Note: Session token generated for DEV can be used for local, so leave that site as it is.
2) Again hit http://localhost:8080/ in a new tab and boom, you will be redirected to local admin build.

