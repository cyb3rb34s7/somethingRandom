from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Provider
    LLM_PROVIDER: str = "bedrock"

    # Model config
    LLM_MODEL: str = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 2048

    # AWS / Bedrock
    AWS_REGION: str = "us-east-1"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
