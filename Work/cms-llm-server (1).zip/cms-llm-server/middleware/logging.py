import time
import string
import random
import logging
from contextvars import ContextVar

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Trace ID context — Python's equivalent of MDC
# Accessible anywhere in the request lifecycle via get_trace_id()
# ---------------------------------------------------------------------------

_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")

TRACE_ID_HEADER = "X-Trace-ID"
_CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
_TRACE_ID_LENGTH = 10


def _generate_trace_id() -> str:
    """Generates a 10-char trace ID matching the org's TraceIdGenerator format."""
    return "".join(random.choices(_CHARSET, k=_TRACE_ID_LENGTH))


def _is_valid_trace_id(trace_id: str) -> bool:
    if not trace_id or len(trace_id) != _TRACE_ID_LENGTH:
        return False
    return all(c in _CHARSET for c in trace_id)


def get_trace_id() -> str:
    """Returns the trace ID for the current request. Call from anywhere."""
    return _trace_id_var.get()


class LoggingMiddleware(BaseHTTPMiddleware):
    """
    - Reads X-Trace-ID from incoming request header; generates one if missing/invalid
    - Stores trace ID in a context var accessible throughout the request lifecycle
    - Logs request metadata + latency (never logs message content)
    - Echoes X-Trace-ID in every response header
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        # Resolve trace ID
        incoming = request.headers.get(TRACE_ID_HEADER, "")
        trace_id = incoming if _is_valid_trace_id(incoming) else _generate_trace_id()

        # Store in context var — available to all downstream code this request
        token = _trace_id_var.set(trace_id)

        start = time.perf_counter()

        response = await call_next(request)

        latency_ms = round((time.perf_counter() - start) * 1000, 2)

        logger.info(
            "trace_id=%s method=%s path=%s status=%s latency_ms=%s",
            trace_id,
            request.method,
            request.url.path,
            response.status_code,
            latency_ms,
        )

        # Echo trace ID in every response — success and error alike
        response.headers[TRACE_ID_HEADER] = trace_id

        # Reset context var after request completes
        _trace_id_var.reset(token)

        return response
