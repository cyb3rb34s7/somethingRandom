# cms-llm-server

Internal LLM gateway for CMS services. Provides a single, stable HTTP endpoint that abstracts the underlying LLM provider. Today it's AWS Bedrock — tomorrow it can be a different provider — without any changes to calling services.

Auth is handled upstream by the API Gateway. This service is fully open internally.

---

## How It Works

```
CMS Service  →  POST /v1/chat  →  cms-llm-server  →  AWS Bedrock (Converse API)
```

All CMS services call one endpoint. The gateway owns provider selection, model choice, and inference parameters. Callers just send messages. Switching models or providers is a single env var change and a redeploy.

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `LLM_PROVIDER` | No | `bedrock` | Active provider. Currently supported: `bedrock` |
| `LLM_MODEL` | No | `anthropic.claude-3-5-sonnet-20241022-v2:0` | Full model ID for the active provider |
| `LLM_TEMPERATURE` | No | `0.7` | Sampling temperature (0.0 – 1.0) |
| `LLM_MAX_TOKENS` | No | `2048` | Max tokens in the completion |
| `AWS_REGION` | No | `us-east-1` | AWS region where Bedrock is enabled |

### Switching Models

```bash
# Claude (default)
LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0

# Qwen (via Bedrock Marketplace)
LLM_MODEL=<qwen-model-id-from-bedrock>

# Titan
LLM_MODEL=amazon.titan-text-express-v1
```

---

## Trace ID

Every request is assigned a trace ID used to correlate logs across services.

- Pass `X-Trace-ID: <id>` in the request header to carry your trace through
- If the header is absent or invalid, the gateway generates one
- The trace ID is always echoed back in the response header `X-Trace-ID`
- On errors, the trace ID is also included in the response body for easy logging by callers
- All gateway logs include `trace_id=` for grep/query correlation

**Trace ID format:** 10 characters, alphanumeric (`A-Z a-z 2-9`, ambiguous chars excluded). Matches the org-wide `TraceIdGenerator` format used in Java services.

---

## API Reference

### `POST /v1/chat`

**Request Body**

```json
{
  "messages": [
    { "role": "system",    "content": "You are a helpful assistant." },
    { "role": "user",      "content": "Summarize this content." },
    { "role": "assistant", "content": "Sure, here is a summary..." },
    { "role": "user",      "content": "Make it shorter." }
  ],
  "stream": false
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `messages` | array | Yes | Conversation history in order |
| `messages[].role` | string | Yes | `user`, `assistant`, or `system`. Role only appears in the request — the response is always the assistant's reply |
| `messages[].content` | string | Yes | Message text |
| `stream` | boolean | No | Default `false`. Set `true` for SSE streaming |

---

### Response Shapes

All non-streaming responses share the same envelope. Trace ID is always in the `X-Trace-ID` response header.

---

#### ✅ Success — `stream: false`

`HTTP 200` · `Content-Type: application/json` · `X-Trace-ID: aB3kR9mN2p`

```json
{
  "success": true,
  "data": {
    "id": "3f2a1b4c-8d9e-4f0a-b1c2-d3e4f5a6b7c8",
    "content": "Content ingestion is the process of collecting, processing, and storing media assets.",
    "provider": "bedrock",
    "model": "anthropic.claude-3-5-sonnet-20241022-v2:0",
    "usage": {
      "prompt_tokens": 22,
      "completion_tokens": 84,
      "total_tokens": 106
    }
  }
}
```

---

#### ❌ Error — any non-streaming failure

Trace ID appears in both the header and the body so callers can log it directly without parsing headers.

`HTTP 502` · `Content-Type: application/json` · `X-Trace-ID: aB3kR9mN2p`

```json
{
  "success": false,
  "trace_id": "aB3kR9mN2p",
  "error": {
    "code": "BEDROCK_ERROR",
    "message": "Failed to invoke Bedrock model: ..."
  }
}
```

**Error codes:**

| Code | HTTP Status | When |
|---|---|---|
| `VALIDATION_ERROR` | 422 | Bad request shape or missing required fields |
| `BEDROCK_ERROR` | 502 | AWS / boto3 call failed |
| `PROVIDER_UNAVAILABLE` | 503 | Provider unreachable |
| `INTERNAL_ERROR` | 500 | Unexpected unhandled exception |

---

#### ✅ Success — `stream: true`

`HTTP 200` · `Content-Type: text/event-stream` · `X-Trace-ID: aB3kR9mN2p`

Headers (including `X-Trace-ID`) are sent once before streaming begins.

Normal chunks:
```
data: {"delta": "Content", "finished": false, "error": null}

data: {"delta": " ingestion is", "finished": false, "error": null}

data: {"delta": " the process...", "finished": false, "error": null}

data: {"delta": "", "finished": true, "error": null}
```

#### ❌ Error — mid-stream failure

If Bedrock fails after streaming has started, HTTP status is already `200`. The error is delivered as a terminal chunk. Use `X-Trace-ID` from the response header to correlate.

```
data: {"delta": "Content ingestion", "finished": false, "error": null}

data: {"delta": "", "finished": false, "error": {"code": "BEDROCK_ERROR", "message": "Stream interrupted by provider"}}
```

**Caller rule for streaming:** check every chunk for a non-null `error` field. If present, treat the stream as failed.

---

### `GET /health`

`HTTP 200`

```json
{
  "status": "ok",
  "provider": "bedrock",
  "model": "anthropic.claude-3-5-sonnet-20241022-v2:0"
}
```

`status` is `ok` when healthy, `degraded` when the provider is unreachable.

---

### `GET /v1/info`

```json
{
  "provider": "bedrock",
  "model": "anthropic.claude-3-5-sonnet-20241022-v2:0",
  "region": "us-east-1"
}
```

---

## Usage Examples

### Basic Chat (curl)

```bash
curl -X POST https://<gateway-url>/v1/chat \
  -H "Content-Type: application/json" \
  -H "X-Trace-ID: aB3kR9mN2p" \
  -d '{
    "messages": [
      { "role": "user", "content": "What is content ingestion?" }
    ]
  }'
```

### Streaming (curl)

```bash
curl -X POST https://<gateway-url>/v1/chat \
  -H "Content-Type: application/json" \
  -H "X-Trace-ID: aB3kR9mN2p" \
  -d '{
    "messages": [{"role": "user", "content": "Tell me about OTT platforms."}],
    "stream": true
  }'
```

### Python (calling service example)

```python
import httpx

LLM_GATEWAY_URL = "https://<gateway-url>"

def call_llm(messages: list[dict], trace_id: str = None) -> str:
    headers = {"Content-Type": "application/json"}
    if trace_id:
        headers["X-Trace-ID"] = trace_id

    response = httpx.post(
        f"{LLM_GATEWAY_URL}/v1/chat",
        json={"messages": messages},
        headers=headers,
        timeout=60,
    )

    # Grab trace ID from response header for your own logs
    response_trace_id = response.headers.get("X-Trace-ID")

    if not response.is_success:
        error = response.json()
        raise Exception(f"LLM call failed [{response_trace_id}]: {error['error']['message']}")

    return response.json()["data"]["content"]
```

### Java (calling service example)

```java
WebClient client = WebClient.create("https://<gateway-url>");

Map<String, Object> body = Map.of(
    "messages", List.of(
        Map.of("role", "system", "content", "You are a metadata tagging assistant."),
        Map.of("role", "user",   "content", "Suggest tags for this content.")
    )
);

ResponseEntity<JsonNode> response = client.post()
    .uri("/v1/chat")
    .header("X-Trace-ID", traceId)   // pass your service's trace ID
    .bodyValue(body)
    .retrieve()
    .toEntity(JsonNode.class)
    .block();

String responseTraceId = response.getHeaders().getFirst("X-Trace-ID");
String content = response.getBody().get("data").get("content").asText();
```

---

## Running Locally

```bash
# 1. Clone and install
git clone <repo>
cd cms-llm-server
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env — set AWS_REGION, LLM_MODEL etc.
# Ensure AWS credentials are available via `aws configure` or SSO

# 3. Run
uvicorn main:app --reload --port 8000

# 4. Test
curl http://localhost:8000/health

curl -X POST http://localhost:8000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello"}]}'
```

---

## Docker

```bash
# Build
docker build -t cms-llm-server .

# Run locally
docker run -p 8000:8000 \
  -e LLM_PROVIDER=bedrock \
  -e LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0 \
  -e AWS_REGION=us-east-1 \
  -e AWS_ACCESS_KEY_ID=<your-key> \
  -e AWS_SECRET_ACCESS_KEY=<your-secret> \
  cms-llm-server
```

On ECS, **do not pass** `AWS_ACCESS_KEY_ID` or `AWS_SECRET_ACCESS_KEY`. The ECS Task Role handles credentials automatically.

---

## ECS Deployment

### IAM Task Role

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": [
        "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20241022-v2:0"
      ]
    }
  ]
}
```

### ECS Task Definition — Key Settings

```json
{
  "containerDefinitions": [{
    "name": "cms-llm-server",
    "image": "<ecr-repo>/cms-llm-server:latest",
    "portMappings": [{ "containerPort": 8000 }],
    "environment": [
      { "name": "LLM_PROVIDER",    "value": "bedrock" },
      { "name": "LLM_MODEL",       "value": "anthropic.claude-3-5-sonnet-20241022-v2:0" },
      { "name": "LLM_TEMPERATURE", "value": "0.7" },
      { "name": "LLM_MAX_TOKENS",  "value": "2048" },
      { "name": "AWS_REGION",      "value": "us-east-1" }
    ],
    "healthCheck": {
      "command": ["CMD-SHELL", "curl -f http://localhost:8000/health || exit 1"],
      "interval": 30,
      "timeout": 10,
      "retries": 3,
      "startPeriod": 15
    }
  }]
}
```

---

## Adding a New Provider

1. Create `providers/<name>.py` implementing `LLMProvider` (`chat`, `stream`, `health_check`)
2. Raise `BedrockException` or a new typed exception from `providers/exceptions.py`
3. Add an entry in `providers/registry.py`
4. Add a handler in `main.py` if using a new exception type
5. Set `LLM_PROVIDER=<name>` and `LLM_MODEL=<model-id>` in env

No other files change.
