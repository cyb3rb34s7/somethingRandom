from typing import Any, Literal, Optional
from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Inbound
# ---------------------------------------------------------------------------

class Message(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ChatRequest(BaseModel):
    messages: list[Message]
    stream: bool = False


# ---------------------------------------------------------------------------
# Provider internals
# ---------------------------------------------------------------------------

class UsageStats(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatResponse(BaseModel):
    id: str
    content: str
    provider: str
    model: str
    usage: UsageStats


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------

class ErrorDetail(BaseModel):
    code: str
    message: str


class StreamChunk(BaseModel):
    delta: str
    finished: bool
    error: Optional[ErrorDetail] = None


# ---------------------------------------------------------------------------
# Standardized API envelope
# ---------------------------------------------------------------------------

class ApiResponse(BaseModel):
    success: bool
    data: Optional[Any] = None


class ErrorResponse(BaseModel):
    success: bool = False
    trace_id: str
    error: ErrorDetail
