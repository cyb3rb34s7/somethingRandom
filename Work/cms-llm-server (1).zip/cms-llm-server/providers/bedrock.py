import uuid
import logging
from typing import AsyncGenerator

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from config import settings
from models.request import ChatRequest, ChatResponse, StreamChunk, UsageStats, ErrorDetail
from providers.base import LLMProvider
from providers.exceptions import BedrockException

logger = logging.getLogger(__name__)


class BedrockAdapter(LLMProvider):
    """
    AWS Bedrock adapter using the Converse API.
    Works uniformly across Claude, Qwen, Titan, and other Bedrock-hosted models.
    Credentials are resolved automatically via IAM Task Role on ECS,
    or ~/.aws/credentials locally.
    """

    def __init__(self):
        self._client = boto3.client(
            "bedrock-runtime",
            region_name=settings.AWS_REGION,
        )
        self._model = settings.LLM_MODEL
        self._temperature = settings.LLM_TEMPERATURE
        self._max_tokens = settings.LLM_MAX_TOKENS

    def _build_converse_messages(self, request: ChatRequest) -> tuple[list, list]:
        """
        Splits messages into system prompt list and conversation messages list,
        as required by the Converse API.
        """
        system = []
        messages = []

        for msg in request.messages:
            if msg.role == "system":
                system.append({"text": msg.content})
            else:
                messages.append({
                    "role": msg.role,
                    "content": [{"text": msg.content}],
                })

        return system, messages

    async def chat(self, request: ChatRequest) -> ChatResponse:
        system, messages = self._build_converse_messages(request)

        kwargs = {
            "modelId": self._model,
            "messages": messages,
            "inferenceConfig": {
                "temperature": self._temperature,
                "maxTokens": self._max_tokens,
            },
        }
        if system:
            kwargs["system"] = system

        try:
            response = self._client.converse(**kwargs)
        except (BotoCoreError, ClientError) as e:
            logger.error("Bedrock converse failed: %s", e)
            raise BedrockException(f"Failed to invoke Bedrock model: {str(e)}", cause=e)

        content = response["output"]["message"]["content"][0]["text"]
        usage = response.get("usage", {})

        return ChatResponse(
            id=str(uuid.uuid4()),
            content=content,
            provider="bedrock",
            model=self._model,
            usage=UsageStats(
                prompt_tokens=usage.get("inputTokens", 0),
                completion_tokens=usage.get("outputTokens", 0),
                total_tokens=usage.get("totalTokens", 0),
            ),
        )

    async def stream(self, request: ChatRequest) -> AsyncGenerator[StreamChunk, None]:
        system, messages = self._build_converse_messages(request)

        kwargs = {
            "modelId": self._model,
            "messages": messages,
            "inferenceConfig": {
                "temperature": self._temperature,
                "maxTokens": self._max_tokens,
            },
        }
        if system:
            kwargs["system"] = system

        try:
            response = self._client.converse_stream(**kwargs)
        except (BotoCoreError, ClientError) as e:
            logger.error("Bedrock converse_stream failed at start: %s", e)
            raise BedrockException(f"Failed to start Bedrock stream: {str(e)}", cause=e)

        stream = response.get("stream")
        if not stream:
            return

        try:
            for event in stream:
                if "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"]["delta"].get("text", "")
                    if delta:
                        yield StreamChunk(delta=delta, finished=False)

                elif "messageStop" in event:
                    yield StreamChunk(delta="", finished=True)

        except (BotoCoreError, ClientError) as e:
            # Mid-stream failure — emit error chunk, caller handles it
            logger.error("Bedrock stream interrupted: %s", e)
            yield StreamChunk(
                delta="",
                finished=False,
                error=ErrorDetail(
                    code="BEDROCK_ERROR",
                    message="Stream interrupted by provider",
                ),
            )

    async def health_check(self) -> bool:
        try:
            self._client.converse(
                modelId=self._model,
                messages=[{"role": "user", "content": [{"text": "ping"}]}],
                inferenceConfig={"maxTokens": 5},
            )
            return True
        except Exception as e:
            logger.warning("Bedrock health check failed: %s", e)
            return False
