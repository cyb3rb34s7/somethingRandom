from config import settings
from providers.base import LLMProvider
from providers.bedrock import BedrockAdapter


def get_provider() -> LLMProvider:
    """
    Returns the active LLMProvider based on LLM_PROVIDER env var.
    Add new providers here as they are implemented.
    """
    provider = settings.LLM_PROVIDER.lower()

    if provider == "bedrock":
        return BedrockAdapter()

    raise ValueError(
        f"Unsupported LLM_PROVIDER: '{provider}'. "
        f"Supported values: bedrock"
    )


# Singleton — instantiated once at startup
active_provider: LLMProvider = get_provider()
