class BedrockException(Exception):
    """Raised when the Bedrock Converse API call fails."""
    def __init__(self, message: str, cause: Exception = None):
        super().__init__(message)
        self.cause = cause


class ProviderUnavailableException(Exception):
    """Raised when the configured provider cannot be reached."""
    def __init__(self, message: str):
        super().__init__(message)
