from abc import ABC, abstractmethod
from typing import AsyncGenerator

from models.request import ChatRequest, ChatResponse, StreamChunk


class LLMProvider(ABC):

    @abstractmethod
    async def chat(self, request: ChatRequest) -> ChatResponse:
        """Send a chat request and return a complete response."""
        pass

    @abstractmethod
    async def stream(self, request: ChatRequest) -> AsyncGenerator[StreamChunk, None]:
        """Send a chat request and stream back response chunks."""
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """Verify the provider is reachable and credentials are valid."""
        pass
