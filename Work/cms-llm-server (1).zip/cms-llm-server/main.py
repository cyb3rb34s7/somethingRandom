import json
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, StreamingResponse

from config import settings
from middleware.logging import LoggingMiddleware, get_trace_id
from models.request import (
    ApiResponse,
    ChatRequest,
    ErrorDetail,
    ErrorResponse,
)
from providers.exceptions import BedrockException, ProviderUnavailableException
from providers.registry import active_provider

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s trace_id=%(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CMS LLM Server",
    description="Internal LLM gateway for CMS services. Backed by AWS Bedrock.",
    version="1.0.0",
)

app.add_middleware(LoggingMiddleware)


# ---------------------------------------------------------------------------
# Global exception handlers
# ---------------------------------------------------------------------------

@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    trace_id = get_trace_id()
    logger.error("trace_id=%s VALIDATION_ERROR: %s", trace_id, exc.errors())
    return JSONResponse(
        status_code=422,
        content=ErrorResponse(
            trace_id=trace_id,
            error=ErrorDetail(
                code="VALIDATION_ERROR",
                message=str(exc.errors()),
            ),
        ).model_dump(),
    )


@app.exception_handler(BedrockException)
async def bedrock_error_handler(request: Request, exc: BedrockException):
    trace_id = get_trace_id()
    logger.error("trace_id=%s BEDROCK_ERROR: %s", trace_id, str(exc))
    return JSONResponse(
        status_code=502,
        content=ErrorResponse(
            trace_id=trace_id,
            error=ErrorDetail(
                code="BEDROCK_ERROR",
                message=str(exc),
            ),
        ).model_dump(),
    )


@app.exception_handler(ProviderUnavailableException)
async def provider_unavailable_handler(request: Request, exc: ProviderUnavailableException):
    trace_id = get_trace_id()
    logger.error("trace_id=%s PROVIDER_UNAVAILABLE: %s", trace_id, str(exc))
    return JSONResponse(
        status_code=503,
        content=ErrorResponse(
            trace_id=trace_id,
            error=ErrorDetail(
                code="PROVIDER_UNAVAILABLE",
                message=str(exc),
            ),
        ).model_dump(),
    )


@app.exception_handler(Exception)
async def internal_error_handler(request: Request, exc: Exception):
    trace_id = get_trace_id()
    logger.error("trace_id=%s INTERNAL_ERROR: %s", trace_id, str(exc), exc_info=True)
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            trace_id=trace_id,
            error=ErrorDetail(
                code="INTERNAL_ERROR",
                message="An unexpected error occurred",
            ),
        ).model_dump(),
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.post("/v1/chat")
async def chat(request: ChatRequest):
    """
    Send a chat request to the active LLM provider.
    - stream=false (default): single JSON response wrapped in ApiResponse envelope
    - stream=true: SSE stream; caller handles chunks. Each chunk may contain an error field.
    """
    if request.stream:
        return await _stream_response(request)

    response = await active_provider.chat(request)
    return ApiResponse(success=True, data=response)


async def _stream_response(request: ChatRequest) -> StreamingResponse:
    trace_id = get_trace_id()

    async def event_generator():
        async for chunk in active_provider.stream(request):
            yield f"data: {json.dumps(chunk.model_dump())}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "X-Trace-ID": trace_id,
        },
    )


@app.get("/health")
async def health():
    """Health check for ECS target group / ALB."""
    is_healthy = await active_provider.health_check()
    status = "ok" if is_healthy else "degraded"
    return {"status": status, "provider": settings.LLM_PROVIDER, "model": settings.LLM_MODEL}


@app.get("/v1/info")
async def info():
    """Returns active provider and model config."""
    return {
        "provider": settings.LLM_PROVIDER,
        "model": settings.LLM_MODEL,
        "region": settings.AWS_REGION,
    }
